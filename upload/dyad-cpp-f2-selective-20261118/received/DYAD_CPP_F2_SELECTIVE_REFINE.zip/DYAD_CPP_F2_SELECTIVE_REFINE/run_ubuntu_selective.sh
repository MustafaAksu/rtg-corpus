#!/usr/bin/env bash
# [SESSION] Conditional source-backed selective F2 refinement. No point jump / 3c-b.
set -euo pipefail
if [[ $# -ne 8 ]]; then
  echo 'Usage: run_ubuntu_selective.sh REPO V2_DIR BENCH_DIR F1_DIR F2_DIR SUB8_DIR PREVIOUS_FULL_SUB8_RUN NEW_EMPTY_OUT' >&2
  exit 64
fi
repo=$(cd -- "$1" && pwd)
v2=$(cd -- "$2" && pwd)
bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd)
f2=$(cd -- "$5" && pwd)
sub8=$(cd -- "$6" && pwd)
prev=$(cd -- "$7" && pwd)
out=$8
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -e "$out" ]]; then
  if [[ ! -d "$out" || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output directory must be new or empty' >&2;exit 64
  fi
else mkdir -p -- "$out"; fi
out=$(cd -- "$out" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/selective_package_checks.txt"
(cd "$v2" && sha256sum -c SHA256SUMS.txt) > "$out/v2_package_checks.txt"
(cd "$bench" && sha256sum -c SHA256SUMS.txt) > "$out/benchmark_package_checks.txt"
(cd "$f1" && sha256sum -c SHA256SUMS.txt) > "$out/f1_package_checks.txt"
(cd "$f2" && sha256sum -c SHA256SUMS.txt) > "$out/f2_package_checks.txt"
(cd "$sub8" && sha256sum -c SHA256SUMS.txt) > "$out/sub8_package_checks.txt"
# The PI's original complete 8x8 term run is a frozen selection input, not recomputed here.
(cd "$prev" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/previous_run_hash_checks.txt"
python3 "$sub8/source/check_terms.py" "$prev/terms.tsv" > "$out/previous_terms_check.txt"
python3 "$sub8/source/check_completion.py" "$prev/summary.txt" "$prev/terms.tsv" 8 8 0 \
  > "$out/previous_completion_check.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
printf '%s  %s\n' "$expected" "$source_json" | sha256sum -c - > "$out/stage2_source_check.txt"
{
  printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
  printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
  printf 'GCC=';g++ --version | head -1
  printf 'PYTHON=';python3 --version
  printf 'SOURCE_SHA256=%s\n' "$expected"
  printf 'PREVIOUS_TERMS_SHA256=';sha256sum "$prev/terms.tsv" | cut -d' ' -f1
  printf 'SOURCE_GRID=8; SOURCE_SUB=8; CHILD_SUB=2; SELECTED_PARENTS=100\n'
  printf 'SESSION_ONLY=1; requires unchanged tube/graph hypotheses; no stage3c-b\n'
} > "$out/environment.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" --out "$out/phi40_outer_256.txt" \
   > "$out/import.log"
cmp "$prev/phi40_outer_256.txt" "$out/phi40_outer_256.txt" || {
  echo 'STOP: source transfer differs from previous full 8x8 log' >&2;exit 4;
}
common=(-std=c++17 -O2 -Wall -Wextra -pedantic -I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source")
g++ "${common[@]}" "$src/source/selective_f2.cpp" -o "$out/selective_f2"
g++ "${common[@]}" "$src/source/test_selective.cpp" -o "$out/test_selective"
python3 "$src/tests/test_selective_structure.py" > "$out/selective_structure_unit.txt"
"$out/test_selective" "$prev/terms.tsv" > "$out/selective_cpp_unit.txt"
g++ -std=c++17 -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined \
  -Wall -Wextra -I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" \
  "$src/source/test_selective.cpp" -o "$out/test_selective_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 45s \
  "$out/test_selective_sanitized" "$prev/terms.tsv" > "$out/sanitizer_unit.txt" 2> "$out/sanitizer_stderr.txt"
set +e
"$out/selective_f2" >/dev/null 2>&1;rc_empty=$?
"$out/selective_f2" "$source_json" "$prev/terms.tsv" "$out/negative_wrong_source.tsv" >/dev/null 2>&1;rc_source=$?
"$out/selective_f2" "$out/phi40_outer_256.txt" "$source_json" "$out/negative_wrong_log.tsv" >/dev/null 2>&1;rc_log=$?
set -e
if [[ "$rc_empty" != 64 || "$rc_source" != 3 || "$rc_log" != 3 ]]; then
  echo "STOP: negative CLI expected (64,3,3), got ($rc_empty,$rc_source,$rc_log)" >&2;exit 1
fi
printf 'CLI_NEGATIVE_PASS codes=(%s,%s,%s)\n' "$rc_empty" "$rc_source" "$rc_log" > "$out/negative_controls.txt"
set +e
timeout -k 10s 2400s "$out/selective_f2" \
  "$out/phi40_outer_256.txt" "$prev/terms.tsv" "$out/selective_children.tsv" \
  > "$out/summary.txt" 2> "$out/solver_stderr.txt"
rc=$?
set -e
# Preserve every produced file even if the bounded run fails.
if [[ "$rc" -eq 0 || "$rc" -eq 2 ]]; then
  if [[ "$rc" -eq 0 ]]; then
    python3 "$src/source/check_selective.py" "$prev/terms.tsv" "$out/selective_children.tsv" "$out/summary.txt" \
      > "$out/selective_check.txt"
    old_radius=$(grep -o 'final_L1_hull=[0-9.e+-]*' "$prev/summary.txt" | head -1 | cut -d= -f2)
    new_radius=$(grep -o 'prior_hull_L1=[0-9.e+-]*' "$out/summary.txt" | head -1 | cut -d= -f2)
    if [[ "$old_radius" != "$new_radius" ]]; then
      echo "STOP: parent L1 readback $new_radius != $old_radius" >&2;exit 3
    fi
    echo 'PREVIOUS_HULL_READBACK_PASS' > "$out/prior_hull_check.txt"
  fi
fi
(
  cd "$out"
  find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name selective_f2 ! -name test_selective ! -name test_selective_sanitized -printf '%f\0' \
    | sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt
)
if [[ "$rc" -ne 0 ]]; then
  echo "INCONCLUSIVE: selective run exit=$rc, partial files are NOT a complete coverage claim" >&2
  exit 2
fi
cat "$out/summary.txt"
cat "$out/selective_check.txt"
echo 'PASS: CONDITIONAL SELECTIVE SESSION RUN ONLY; no certification, no jump.'
