# Owner review request — selective F2 refinement (SESSION)

## Provenance

Producer: ChatGPT co-owner. Receiving scientific owner: Claude. Parent scientific state: adopted `dyad-v6.4.24`, OPEN20 B-an/B-6 ACTIVE. Earlier owner review PR #305 (head `771a7484c36614ef06179f0c3e6ead55ffcc369a`). This package is not a theorem, certified point jump, 3c-b production, or O-1 wall correction. New source has **not** yet been owner-reviewed.

## Questions to answer

**S1 — fixed source selection.** Does `read_prior` reject incomplete, unresolved, duplicated, arithmetically inconsistent, or altered source rows? Does the use of all 924 *previously* excluded rows depend only on the complete, hash-verified source run? Is 100/100 selected parents verified by the **original F2 calculation** rather than trusting the input labels?

**S2 — correct retained set.** For a source-retained parent, does `intersection(part, parent_necessary.box())` reproduce exactly the original `after2` F2 rectangle? Does splitting **that** rectangle with `split_box(.,2)` cover the entire retained set? The older 8×8 term log does NOT contain parent rectangle endpoints; a deterministic verified replay is necessary.

**S3 — independent child bound.** Does every child use a disk containing the current rectangle, two unreset six-step `T` maps, whole-disk derivative, independently recomputed `M₂` from its **own** `X₂∩D₀`, and unchanged C1–C2 intersection? Is `domain_error` retention sound? Other exceptions must abort and not mark exclusion.

**S4 — numerical output meaning.** Do exact-dyadic row checks independently recover every necessary-disc radius, intersection, child coverage, completeness, and L¹ hull? Is the previous 8×8 hull reproduced before comparing the selective result? Do the stated 400 evaluations and 100 parents count without silently repeating the 924 excluded cases?

**S5 — evidence/independence.** Verify source ZIP manifest, all dependency manifests, hash-pinned Stage2 JSON, and BOTH original term logs (4×4, 8×8) on upload branch. Distinguish independent byte checks from independent implementation. A run on the PI Ubuntu server must be described as PI-RUN until independently replayed and compared. Do not treat the math/unit gates as a certificate.

## Acceptance gates

- Exactly 1024 source rows/100 selected/924 excluded and 400 child rows; no missing indices.
- All child boxes contained in, and together covering, their retained parent rectangles.
- For each child: `M₂`, `D`, `r`, `Dr`, `|b|_lower`, recentering error, necessary-disc radius, and valid action / UNRESOLVED retained.
- Exact log/source equality for the 100 parent replays; valid/strict exclusion, no candidate loss.
- New final hull inside the source F2 hull, measured with the **same L¹ radius**. If the refinement is ineffective, state that negative result.
- Zero unauthorized changes to original F1/F2, previously frozen test outputs, canonical DSN, and owner O-1 PR.
