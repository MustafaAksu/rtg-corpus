# DYAD OPEN 20 — selective second-block F2 refinement (SESSION)

## Scope and status

This package performs **one bounded, conditional development experiment**, not a scientific certificate. It refines only the 100 `RETAINED` rectangles from the PI's complete 8×8 second-stage (`grid=8`, `subdiv=8`, 1,024 rows) term diagnostic. The unchanged, owner-reviewed two-block map and C1–C2 necessary-disk contractor are included at build time from the original dependency packages. Neither 3c-b production/replay, a point-jump result, nor closure of OPEN20 B-an/B-6 is authorized or claimed. The O-1 exact-dyadic wall issue is tracked separately in PR #312.

**Source basis:** `MustafaAksu/rtg-corpus`, governing adopted Dyadic `dyad-v6.4.24` + release record; stage3c-a proof record §§1, 5, 9; owner review of F1/F2 in PR #305 at `771a7484c36614ef06179f0c3e6ead55ffcc369a` (SESSION only). Imported Stage 2 JSON fixed SHA-256: `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.

## Input and algorithm

**Input:** a complete, **unchanged** PI term diagnostic directory from `DYAD_CPP_F2_TERM_AUDIT_SUB8`, with `terms.tsv`, `summary.txt`, `phi40_outer_256.txt`, `RUN_SHA256SUMS.txt`, and supporting logs. The runner refuses missing hashes, incomplete 1024/1024 coverage, unresolved source rows, or mismatched imported coefficients. The selected 100 rows and 924 previously excluded rows must match the source run exactly; this package does **not re-prove** the 924 exclusions. Prior result dependencies remain explicit.

1. Run/verify the first block only for the 16 originally F1-retained initial tiles; calculate the exact **F1-reduced** boxes.
2. For each **source-RETAINED** `(first_tile, second_subtile)` pair, reconstruct the original 8×8 second-stage part and its two-block necessary-disc intersection. Compare **all seven exact integer terms** (`M₂`, `Dr`, `D`, `r`, `|b|_lower`, centre error, radius) with the recorded 8×8 term row. On disagreement, fail loudly; no claimed refinement is output.
3. Split the **already F2-reduced** rectangular parent by unchanged `f2::split_box(parent, 2)`. This covers it exactly. Do **not** revisit the 924 previously excluded parents.
4. Circumscribe each child rectangle by an evaluation disk. Recompute both F blocks **from the original initial lift**, carrying the full tangent chain; compute a **new** `M₂ >= sup_(X₂(child)∩D₀) R₀`, then the unchanged C1–C2 necessary disk on the *whole child disk*.
5. Intersect the necessary-disk box with the **current child rectangle**. A proved empty intersection excludes the child; a successful intersection retains the reduced rectangle; a `domain_error` retains the whole current child rectangle. Unexpected exceptions terminate with `INPUT_FAIL` rather than silently dropping anything.
6. Output all 400 child records with exact 256-bit integer endpoints and `M₂`, `D`, `r`, `Dr`, recentering error, `|b|_lower`, C1–C2 radius, and action. Calculate both previous/updated `L¹` hull radii. Reject empty or enlarged hulls.

**Conditional proposition:** If the actual sectorial graph and tube hypotheses hold through the two images, and the prior run's exclusions are sound, every true `d*` in the initial fibre remains in at least one new retained child rectangle. This does not prove existence of that graph, nor certify a jump.

## Ubuntu commands

Prerequisites: existing extracted folders under `/root` from prior successful runs:
`DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2`, `DYAD_CPP_FORWARD_METHOD_BENCHMARK`, `DYAD_CPP_F1_TUBE_CONTRACTOR`, `DYAD_CPP_F2_TUBE_CONTRACTOR`, `DYAD_CPP_F2_TERM_AUDIT_SUB8`. The PI's complete source run directory is `/root/dyad-f2-term8-full`.

```bash
cd /root
sha256sum DYAD_CPP_F2_SELECTIVE_REFINE.zip
unzip -n DYAD_CPP_F2_SELECTIVE_REFINE.zip

bash /root/DYAD_CPP_F2_SELECTIVE_REFINE/run_ubuntu_selective.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TERM_AUDIT_SUB8 \
  /root/dyad-f2-term8-full \
  /root/dyad-f2-selective-run

echo "exit=$?"
cat /root/dyad-f2-selective-run/summary.txt
cat /root/dyad-f2-selective-run/selective_check.txt
```

The runner creates only a new/empty output directory. It SHA-checks **all six source packages**, the pinned source JSON and the PI's preceding complete run. It includes a 2400-second hard timeout, 1 positive and 4 negative structural tests, a C++ parser/coverage unit, and CLI controls with expected exits (64,3,3).

**Exit semantics:** `0` = all 400 child cases completed with no unresolved and independent exact-integer structural checks passed; `2` = unresolved/timeout/empty cover (`INCONCLUSIVE`); `3` = corrupt input / arithmetic identity or source mismatch; `64` = usage error. Output of a partial or failed run is not a full-horizon result.

## Local development-only dry run

The co-owner completed a **proxy 18-significant-digit** 1024-row source diagnostic followed by all **400** selected children using this code. The 100 source-retained parents were re-evaluated and their exact term rows matched. The proxy run excluded 256 children and retained 144, with no unresolved cases; L¹ radius `5.7237258735e-4 → 2.5011937695e-4`. Exact-integer output checker passed and the approximate W8 centre remained inside four child boxes. See `tests/LOCAL_PROXY_RESULT.md`. **This is not the pinned 80-digit Stage2 run**; the owner/PI must not promote these numbers to real input certification.

Cost accounting: 400 new child two-block evaluations **plus 100 replayed retained-parent two-block evaluations**, not only 400 total numerical propagations. The previously excluded 924 parents are not re-evaluated.

## Optional immutable transfer to GitHub

GitHub **does not already contain** the PI's full 4×4 and 8×8 source term logs. The PI may upload them without changing originals. The two branches below are separate, so the first is not rewritten when the selected run finishes.

```bash
# After obtaining the ZIP, upload the package and BOTH prior logs (unaltered).
bash /root/DYAD_CPP_F2_SELECTIVE_REFINE/upload_exact_evidence.sh inputs \
  /root/rtg-corpus /root/DYAD_CPP_F2_SELECTIVE_REFINE.zip \
  /root/dyad-f2-terms-grid8 /root/dyad-f2-term8-full --push

# After a full PASS, upload the new result separately (unaltered).
bash /root/DYAD_CPP_F2_SELECTIVE_REFINE/upload_exact_evidence.sh results \
  /root/rtg-corpus /root/dyad-f2-selective-run --push
```

Branches: `upload/dyad-cpp-f2-selective-20261118` and `upload/dyad-cpp-f2-selective-results-20261118`; no merge/tag/main modifications. Each branch is created only if absent. Existing full-run outputs and source ZIPs are copied **unchanged**, with their SHA256 manifests revalidated in the receiving Git worktree.

## Evidence boundary

- `[EV-BYTES]` archived source inputs, internally SHA-checked; reviewer should independently compare Git blob IDs after upload.
- `[EV-CODE]` new C++ selection/readback and Python exact-integer checker, not yet owner-reviewed.
- `[EV-RUN]` only local synthetic and bounded proxy work unless the PI reports the full pinned run. Do not equate a checksum or 400/400 PASS with a theorem or jump.
- `R₀` bound is the prior F1-reviewed implementation, using `cwall.l` valid for the current D₀ wall. It is not the Python O-1 `cw.upper()` assumption.
