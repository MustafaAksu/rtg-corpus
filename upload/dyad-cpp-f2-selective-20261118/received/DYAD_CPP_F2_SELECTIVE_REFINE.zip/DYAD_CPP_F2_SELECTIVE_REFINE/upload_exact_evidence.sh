#!/usr/bin/env bash
# [SESSION] Upload unchanged PI-run source logs / results via a new upload/* branch.
# No main changes, no merge, no tag, no release/adoption. Requires --push.
set -euo pipefail
if [[ $# -lt 4 || "$1" != 'inputs' && "$1" != 'results' ]]; then
  echo 'Usage: upload_exact_evidence.sh inputs REPO PACKAGE_ZIP SUB4_FULL_RUN SUB8_FULL_RUN --push' >&2
  echo '    or upload_exact_evidence.sh results REPO SELECTIVE_FULL_RUN --push' >&2
  exit 64
fi
mode=$1;repo=$(cd -- "$2" && pwd)
if [[ "$mode" == inputs ]]; then
  [[ $# -eq 6 && "$6" == --push ]] || exit 64
  package=$(realpath -- "$3");run4=$(cd -- "$4" && pwd);run8=$(cd -- "$5" && pwd)
  [[ -f "$package" ]] || { echo 'missing package ZIP' >&2;exit 3; }
  branch=upload/dyad-cpp-f2-selective-20261118
  for d in "$run4" "$run8"; do (cd "$d" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null);done
  # Require the full 1024-row source, not an incomplete diagnostic sample.
  thisdir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
  sub8="$thisdir/../DYAD_CPP_F2_TERM_AUDIT_SUB8"
  python3 "$sub8/source/check_terms.py" "$run4/terms.tsv" >/dev/null
  python3 "$sub8/source/check_completion.py" "$run4/summary.txt" "$run4/terms.tsv" 8 4 0 >/dev/null
  python3 "$sub8/source/check_terms.py" "$run8/terms.tsv" >/dev/null
  python3 "$sub8/source/check_completion.py" "$run8/summary.txt" "$run8/terms.tsv" 8 8 0 >/dev/null
else
  [[ $# -eq 4 && "$4" == --push ]] || exit 64
  run=$(cd -- "$3" && pwd)
  (cd "$run" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
  [[ -s "$run/selective_check.txt" ]] || { echo 'missing full selective structure check' >&2; exit 3; }
  grep -Fq 'SELECTIVE_F2_STRUCTURE_PASS children=400' "$run/selective_check.txt" || exit 3
  branch=upload/dyad-cpp-f2-selective-results-20261118
fi
# An upload branch is treated as an immutable intake container: no force-push.
git -C "$repo" fetch origin main
git -C "$repo" show-ref --verify --quiet "refs/heads/$branch" && { echo "STOP: local branch exists $branch" >&2;exit 3; }
git -C "$repo" show-ref --verify --quiet "refs/remotes/origin/$branch" && { echo "STOP: remote branch exists $branch" >&2;exit 3; }
tmp=$(mktemp -d /tmp/dyad-f2-sel-upload-XXXXXX)
rmdir "$tmp"
cleanup(){
  git -C "$repo" worktree remove --force "$tmp" >/dev/null 2>&1 || true
}
trap cleanup EXIT
# Isolate intake from the PI's main checkout. Only upload/* is pushed.
git -C "$repo" worktree add -b "$branch" "$tmp" origin/main >/dev/null
prefix="$tmp/$branch"
mkdir -p "$prefix"
if [[ "$mode" == inputs ]]; then
  mkdir -p "$prefix/received" "$prefix/pi-run/sub4" "$prefix/pi-run/sub8"
  cp -p -- "$package" "$prefix/received/DYAD_CPP_F2_SELECTIVE_REFINE.zip"
  cp -a -- "$run4/." "$prefix/pi-run/sub4/"
  cp -a -- "$run8/." "$prefix/pi-run/sub8/"
  sha256sum "$prefix/received/DYAD_CPP_F2_SELECTIVE_REFINE.zip" > "$prefix/received/ZIP_SHA256.txt"
  # The file's SHA line is absolute. Preserve ZIP bytes; include simple name-only sidecar.
  (cd "$prefix/received" && sha256sum DYAD_CPP_F2_SELECTIVE_REFINE.zip > SHA256SUMS.txt)
  (cd "$prefix/pi-run/sub4" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
  (cd "$prefix/pi-run/sub8" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
  rm -- "$prefix/received/ZIP_SHA256.txt"
else
  mkdir -p "$prefix/pi-run/selective"
  cp -a -- "$run/." "$prefix/pi-run/selective/"
  (cd "$prefix/pi-run/selective" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
fi
(
 cd "$tmp"
 git add -- "$branch"
 git commit -m "upload/dyad: receive untouched F2 selective $mode evidence (SESSION)" >/dev/null
 printf 'CREATED_BRANCH=%s\nCOMMIT=%s\n' "$branch" "$(git rev-parse HEAD)"
 git push origin "refs/heads/$branch:refs/heads/$branch"
)
echo 'UPLOAD_ONLY: no merge, no tag, no DSN changes or 3c-b authorization'
