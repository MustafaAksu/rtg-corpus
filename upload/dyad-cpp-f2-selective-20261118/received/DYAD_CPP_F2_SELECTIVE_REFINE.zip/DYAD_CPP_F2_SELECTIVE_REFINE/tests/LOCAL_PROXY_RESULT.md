# Local bounded proxy run — NOT the pinned Stage 2 experiment

**Mode:** SESSION, local Debian/GCC 14.2 C++17, Boost multiprecision. Input: the 39 complex `approximate_18sig_coefs.txt` coefficients in the previously reviewed V2 package, each component padded by ±1e-15; the `c` proxy padded by ±1e-30. This is deliberately **not** the pinned 80-digit Stage 2 JSON transfer. It must not be used to certify or reclassify scientific evidence.

The existing unchanged `f2_term_diagnostic_sub8.cpp` built and ran to completion on a full 8×8 second-stage proxy diagnostic:

- Initial first-stage tiles: 60; first-stage excluded: 44; retained: 16; unresolved: 0.
- Previous second-stage subtiles: 1024/1024; excluded: 924; retained: 100; unresolved: 0.
- Independent `check_terms.py` and `check_completion.py` passed.
- Previous L¹ outer hull radius: `5.7237258735e-04`.

The new `selective_f2.cpp` then **replayed only the 100 retained parents**, compared their exact parent diagnostics with the frozen proxy term log and performed 2×2 refinement:

- Selected parent term rows matched: 100/100.
- Evaluated children: 400/400; additionally excluded: 256; retained: 144; unresolved: 0.
- Exact-dyadic structural check: `SELECTIVE_F2_STRUCTURE_PASS`.
- New L¹ outer hull radius: `2.5011937695e-04`.
- Previously reported approximate W8 forward-leg centre `-4.31673035579418264597772608615e-9 + i*1.99337743786726033784713679474e-8` is inside four surviving child boxes (25,54,3), (26,49,2), (33,14,1), (34,9,0). This is a **[NUM] witness**, not a premise or enclosure of the true `d*`.

**Negative/structural tests:** Python source-format checker 1 positive and 4 mutations PASS; C++ source-log parser and exact `split_box` passed; same parser under ASan/UBSan passed. Unchanged dependency package SHA-256 manifests passed before compilation. No independent proof of graph/tube existence and no 3c-b campaign was run.

**Limitations:** This is not the actual source-backed Ubuntu result. The portable output of the exact 400-child run must be obtained from the PI server, uploaded unchanged under `upload/*`, and owner-reviewed before any stronger claim.
