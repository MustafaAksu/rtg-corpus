#!/usr/bin/env python3
"""[SESSION] Exact-integer positive and mutation controls for selective checker."""
from pathlib import Path
from tempfile import TemporaryDirectory
from subprocess import run
import sys
S=1<<256
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import check_selective as chk

def box(x):return (x,x+16,x-4,x+12)

def pack(a):return ' '.join(map(str,a))

def make(folder):
    old=folder/'prior.tsv';details=folder/'child.tsv';summary=folder/'summary.txt'
    lines=[chk.OLD]
    selected=[]
    for i in range(16):
        for j in range(64):
            retained=len(selected)<100
            if retained:selected.append((i,j))
            M=S;Dr=0;D=0;r=0;lb=S;e=0;rad=S
            lines.append(f'{i} {j} {M} {Dr} {D} {r} {lb} {e} {rad} VALID {"RETAINED" if retained else "EXCLUDED"}')
    old.write_text('\n'.join(lines)+'\n')
    lines=[chk.HEADER]
    parents=[]
    for idx,(i,j) in enumerate(selected):
        p=box(idx*32);parents.append(p)
        for k,c in enumerate(chk.split_four(p)):
            # Huge enough necessary box to contain all children, action RETAINED.
            n=(-2*S,2*S,-2*S,2*S)
            lines.append(f'{i} {j} {k} {pack(p)} {pack(c)} {pack(n)} {pack(c)} {S} 0 0 0 {S} 0 {S} VALID RETAINED')
    details.write_text('\n'.join(lines)+'\n')
    b=chk.l1rad(chk.hull(parents));a=chk.l1rad(chk.hull(parents))
    summary.write_text('MODE=SESSION_CONDITIONAL; F2_SELECTED_REFINEMENT\n'
       'source_first_tiles=16 source_parent_rows=1024 prior_excluded=924 selected_parent_rows=100 checked_parent_rows=100\n'
       'child_attempted=400 child_evaluated=400 child_excluded=0 child_retained=400 child_unresolved=0\n'
       f'prior_hull_L1_256={b} final_hull_L1_256={a}\nNO_CERTIFICATE\n')
    return old,details,summary

with TemporaryDirectory() as td:
    folder=Path(td);old,d,s=make(folder)
    chk.check(old,d,s)
    orig=d.read_text()
    negative=[orig.replace('VALID RETAINED\n','VALID EXCLUDED\n',1),
              '\n'.join(orig.splitlines()[:-1])+'\n',
              '\n'.join(orig.splitlines()+[orig.splitlines()[-1]])+'\n',
              orig.replace(f'{S} 0 0 0 {S} 0 {S}',f'{S} 1 0 0 {S} 0 {S}',1)]
    for i,txt in enumerate(negative):
        d.write_text(txt)
        try:chk.check(old,d,s)
        except AssertionError:pass
        else:raise AssertionError(f'negative mutation {i} not detected')
    d.write_text(orig)
    print('SELECTIVE_STRUCTURE_TEST_PASS positive=1 negative=4')
