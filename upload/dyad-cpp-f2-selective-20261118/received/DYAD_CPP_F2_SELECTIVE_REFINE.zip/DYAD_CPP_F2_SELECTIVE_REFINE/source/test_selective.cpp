// [SESSION] Bounded source-log parser/partition negative controls, no scientific run.
#define DYAD_SELECTIVE_NO_MAIN
#include "selective_f2.cpp"
#include <cassert>
int main(int argc,char** argv){
  if(argc!=2)return 64;
  try {
  using namespace selective;
  auto p=read_prior(argv[1]);
  assert(p.rows.size()==1024 && p.per_tile.size()==16 && p.keep_per_tile.size()>0);
  size_t selected=0;
  for(auto& kv:p.rows)selected+=kv.second.retained;
  assert(selected==100);
  C B(I(-11,19),I(-9,17));
  for(unsigned n: {size_t(2),size_t(4),size_t(8)}){
    auto c=f2::split_box(B,n);assert(c.size()==n*n);
    for(auto& item:c){
      assert(item.re.l>=B.re.l && item.re.h<=B.re.h);
      assert(item.im.l>=B.im.l && item.im.h<=B.im.h);
    }
  }
  std::cout<<"SELECTIVE_PARSER_AND_SPLIT_PASS source=1024 retained=100\n";
  return 0;
  }catch(const std::exception &e){std::cerr<<"INVALID_PREVIOUS_LOG: "<<e.what()<<"\n";return 3;}
}
