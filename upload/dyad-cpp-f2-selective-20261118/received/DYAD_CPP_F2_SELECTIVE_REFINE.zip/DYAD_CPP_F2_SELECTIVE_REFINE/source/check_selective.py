#!/usr/bin/env python3
"""[SESSION] Independent exact-integer structure/radius checks; not a proof of the tube lemma.

Requires a complete, previously validated 8x8 F2 diagnostic log and the new output.
Every retained second-stage parent must contribute four children (0,1,2,3).
"""
import argparse
from collections import defaultdict
from pathlib import Path
import re

S = 1 << 256
HEADER = (
    'tile parent_subtile child parent_re_lo parent_re_hi parent_im_lo parent_im_hi '
    'child_re_lo child_re_hi child_im_lo child_im_hi '
    'necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
    'final_re_lo final_re_hi final_im_lo final_im_hi '
    'M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action'
)
OLD = ('first_tile second_subtile M2_256 Dr_256 D_256 r_256 '
       'lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')

def cd(a,b): return -(-a//b)

def old_selected(path):
    lines=Path(path).read_text().splitlines()
    assert lines and lines[0]==OLD
    ids=set(); rows=set(); tiles=defaultdict(set)
    for line in lines[1:]:
        w=line.split();assert len(w)==11
        i,j=map(int,w[:2]); M,Dr,D,r,lb,e,rad=map(int,w[2:9]); status,action=w[9:]
        assert 0<=i<60 and 0<=j<64 and status=='VALID'
        assert (i,j) not in rows; rows.add((i,j));tiles[i].add(j)
        assert M>0 and D>=0 and r>=0 and lb>0 and e>=0 and rad>=0
        assert Dr==cd(D*r,S) and rad==e+cd((M+Dr)*S,lb)
        assert action in ('EXCLUDED','RETAINED')
        if action=='RETAINED':ids.add((i,j))
    assert len(rows)==1024 and len(tiles)==16 and len(ids)==100
    assert all(len(v)==64 for v in tiles.values())
    return ids

def intersect(a,b):
    c=(max(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),min(a[3],b[3]))
    return c if c[0]<=c[1] and c[2]<=c[3] else None

def split_four(a):
    xl,xh,yl,yh=a;dx=xh-xl;dy=yh-yl
    assert dx>=0 and dy>=0
    ans=[]
    for i in range(2):
        for j in range(2):
            ans.append((xl+(dx*i)//2,xl+cd(dx*(i+1),2),
                        yl+(dy*j)//2,yl+cd(dy*(j+1),2)))
    return ans

def hull(boxes):
    a=list(boxes)
    assert a
    return (min(v[0] for v in a),max(v[1] for v in a),
            min(v[2] for v in a),max(v[3] for v in a))

def l1rad(box):
    xr=box[0:2];yr=box[2:4]
    mx=(xr[0]+xr[1])//2;my=(yr[0]+yr[1])//2
    return max(abs(xr[0]-mx),abs(xr[1]-mx))+max(abs(yr[0]-my),abs(yr[1]-my))

def check(prev_file,details_file,summary_file):
    selected=old_selected(prev_file)
    lines=Path(details_file).read_text().splitlines()
    assert lines and lines[0]==HEADER,(lines[:1],)
    seen=set();parent_boxes={}; final=[]
    counts={'VALID':0,'UNRESOLVED':0,'EXCLUDED':0,'RETAINED':0}
    q=[]
    for line in lines[1:]:
        w=line.split();assert len(w)==28,(len(w),w[:4])
        ints=list(map(int,w[:26]));i,j,k=ints[:3]
        key=(i,j,k)
        assert (i,j) in selected and k in (0,1,2,3) and key not in seen,key
        seen.add(key)
        parent=tuple(ints[3:7]);child=tuple(ints[7:11]);needed=tuple(ints[11:15]);fin=tuple(ints[15:19]);
        M,Dr,D,r,lb,e,rad=ints[19:26]; evaluation,action=w[26:]
        assert evaluation in ('VALID','UNRESOLVED')
        assert action in ('EXCLUDED','RETAINED')
        assert intersect(child,parent)==child
        assert parent[0]<=parent[1] and parent[2]<=parent[3]
        assert child[0]<=child[1] and child[2]<=child[3]
        if (i,j) in parent_boxes:assert parent_boxes[i,j]==parent
        else:parent_boxes[i,j]=parent
        assert child==split_four(parent)[k],('coverage',key)
        if evaluation=='VALID':
            assert M>0 and Dr>=0 and D>=0 and r>=0 and lb>0 and e>=0 and rad>=0
            assert Dr==cd(D*r,S),('directed product',key)
            assert rad==e+cd((M+Dr)*S,lb),('C1C2 radius',key)
            expected=intersect(child,needed)
            assert (expected is not None)==(action=='RETAINED'),('false exclusion',key)
            assert fin==(expected if expected is not None else (0,0,0,0)),('final',key)
            q.append(Dr/M) # diagnostic float only; exact integer gates above
        else:
            assert action=='RETAINED' and fin==child
            assert (M,Dr,D,r,lb,e,rad)==(0,)*7
        if action=='RETAINED':final.append(fin)
        counts[evaluation]+=1;counts[action]+=1
    assert len(lines)-1==400 and len(seen)==400 and len(parent_boxes)==100
    assert set(parent_boxes)==selected
    assert counts['VALID']+counts['UNRESOLVED']==400
    assert counts['EXCLUDED']+counts['RETAINED']==400
    assert final,'no retained cover'
    before=l1rad(hull(parent_boxes.values()))
    after=l1rad(hull(final))
    assert after<=before
    text=Path(summary_file).read_text()
    def field(name):
        m=re.search(r'(?<!\S)'+re.escape(name)+r'=([0-9]+)(?!\S)',text)
        assert m,name
        return int(m.group(1))
    assert 'MODE=SESSION_CONDITIONAL; F2_SELECTED_REFINEMENT' in text
    for n,v in [('source_first_tiles',16),('source_parent_rows',1024),('prior_excluded',924),
                ('selected_parent_rows',100),('checked_parent_rows',100),('child_attempted',400),
                ('child_evaluated',counts['VALID']),('child_unresolved',counts['UNRESOLVED']),
                ('child_excluded',counts['EXCLUDED']),('child_retained',counts['RETAINED']),
                ('prior_hull_L1_256',before),('final_hull_L1_256',after)]:
        assert field(n)==v,(n,field(n),v)
    assert 'NO_CERTIFICATE' in text
    print('SELECTIVE_F2_STRUCTURE_PASS children=400 selected_parents=100 prior_excluded=924')
    print('evaluated={VALID} excluded={EXCLUDED} retained={RETAINED} unresolved={UNRESOLVED}'.format(**counts))
    print('prior_L1_256=',before,'final_L1_256=',after)
    print('prior_L1_approx=%.10e final_L1_approx=%.10e' % (before/S,after/S))
    print('SESSION_ONLY: conditional source-backed contractor; NOT a graph/tube certificate or jump')

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('prior_terms');a.add_argument('new_details');a.add_argument('new_summary')
    x=a.parse_args();check(x.prior_terms,x.new_details,x.new_summary)
