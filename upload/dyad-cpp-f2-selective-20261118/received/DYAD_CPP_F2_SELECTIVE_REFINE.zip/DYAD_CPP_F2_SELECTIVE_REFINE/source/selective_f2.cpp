// [SESSION] Conditional selective F2 refinement of the 100 retained 8x8 second-stage cells.
// The owner-reviewed F1/F2 contractor and interval arithmetic are INCLUDED UNCHANGED.
// This is a new refinement and logging layer, not a point-jump or stage 3c-b certificate.
#define DYAD_F2_NO_MAIN
#include "real_f2_tube.cpp"
#include <map>
#include <set>
#include <sstream>
#include <fstream>

namespace selective {
using namespace dyad;
using namespace dyad::centered;
using Key=std::pair<size_t,size_t>;
struct Prior {
  Z M,Dr,D,r,lb,err,radius;
  bool retained=false;
};
using PriorTable=std::map<Key,Prior>;
struct PriorRead {
  PriorTable rows;
  std::map<size_t,size_t> per_tile;
  std::map<size_t,size_t> keep_per_tile;
};

// The source-backed 8x8 diagnostic is a frozen selection input, not a new proof.
// In particular, every one of the 924 EXCLUDED rows must have been verified in
// the preceding (complete, checksum-checked) F2 diagnostic campaign.
PriorRead read_prior(const std::string& file){
  std::ifstream f(file); if(!f)throw std::runtime_error("missing prior full F2 term log");
  std::string header;
  if(!std::getline(f,header) || header !=
      "first_tile second_subtile M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action")
    throw std::runtime_error("wrong previous F2 TSV header");
  PriorRead out;std::string line;size_t good=0,kept=0;
  while(std::getline(f,line)){
    if(line.empty())throw std::runtime_error("empty previous F2 row");
    std::istringstream s(line);size_t i,j;Prior p;std::string eval,action,extra;
    if(!(s>>i>>j>>p.M>>p.Dr>>p.D>>p.r>>p.lb>>p.err>>p.radius>>eval>>action) || (s>>extra))
      throw std::runtime_error("malformed previous F2 row");
    if(i>=60 || j>=64 || eval!="VALID" || (action!="RETAINED"&&action!="EXCLUDED"))
      throw std::runtime_error("invalid previous F2 row scope or unresolved status");
    if(p.M<=0||p.D<0||p.r<0||p.Dr<0||p.lb<=0||p.err<0||p.radius<0 ||
       p.Dr!=cd(p.D*p.r,SCALE) || p.radius!=p.err+cd((p.M+p.Dr)*SCALE,p.lb))
      throw std::runtime_error("prior necessary disk integer identity failed");
    p.retained=action=="RETAINED";
    if(!out.rows.emplace(Key(i,j),p).second)throw std::runtime_error("duplicate prior row");
    ++good;++out.per_tile[i];if(p.retained){++kept;++out.keep_per_tile[i];}
  }
  if(good!=1024 || kept!=100 || out.per_tile.size()!=16)throw std::runtime_error("incomplete/changed previous F2 run");
  for(const auto& x:out.per_tile)if(x.second!=64)throw std::runtime_error("incomplete source first-stage tile");
  return out;
}

// Print fixed-point dyadic integers, never approximate decimals, for readback.
void print_box(std::ostream& o,const C& a){
  o << a.re.l<<' '<<a.re.h<<' '<<a.im.l<<' '<<a.im.h;
}
struct Stats{
  size_t first_tiles=0,source_parents=0,prior_excluded=0,selected=0,checked_parents=0,
         child_attempted=0,child_evaluated=0,child_excluded=0,child_retained=0,child_unresolved=0;
  std::optional<C> previous_hull,final_hull;
  std::vector<Z> q;
};

void output_row(std::ostream& out,size_t i,size_t j,size_t k,
                const C& parent,const C& child,const C& final,const C& needed_box,
                Z M,Z Dr,Z D,Z r,Z lb,Z center_error,Z radius,
                const char* evaluation,const char* action){
  out<<i<<' '<<j<<' '<<k<<' ';
  print_box(out,parent);out<<' ';print_box(out,child);out<<' ';
  print_box(out,needed_box);out<<' ';print_box(out,final);
  out<<' '<<M<<' '<<Dr<<' '<<D<<' '<<r<<' '<<lb<<' '<<center_error<<' '<<radius
     <<' '<<evaluation<<' '<<action<<'\n';
}

Stats refine(const Data& data,const PriorRead& previous,const std::string& detail_path){
  f1::ForwardTube tube(data.c);
  auto initial=tiles(8);
  if(initial.size()!=60)throw std::runtime_error("unexpected source initial cover size");
  Stats st;st.first_tiles=previous.per_tile.size();st.source_parents=previous.rows.size();
  st.prior_excluded=1024-100;
  std::ofstream out(detail_path);if(!out)throw std::runtime_error("cannot open new details");
  out<<"tile parent_subtile child parent_re_lo parent_re_hi parent_im_lo parent_im_hi "
        "child_re_lo child_re_hi child_im_lo child_im_hi "
        "necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi "
        "final_re_lo final_re_hi final_im_lo final_im_hi "
        "M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action\n";
  for(const auto& per:previous.per_tile){
    const size_t i=per.first;const Disk& tile=initial.at(i);const C first=tile.box();
    // Replay first block only for the 16 source-surviving initial tiles.
    State R1=f2::iter(tube.at_start(),tile,data.phi,1);
    Z M1=tube.upper(R1.a.v).M;
    State P1=f2::iter(tube.at_start(),Disk(tile.c,0),data.phi,1);
    C b1=mid(P1.b.d);
    if(norm_lower(b1)<=0)throw std::runtime_error("source F1 slope mismatch");
    Disk N1=necessary_disk(tile,P1.b.v,R1.b.d,b1,M1);
    auto after1=intersection(first,N1.box());
    if(!after1)throw std::runtime_error("source F1 no longer retains tile");
    auto parents=f2::split_box(*after1,8);
    if(parents.size()!=64)throw std::runtime_error("wrong source parent partition");
    for(size_t j=0;j<64;++j){
      auto iter=previous.rows.find(Key(i,j));
      if(iter==previous.rows.end())throw std::runtime_error("missing prior parent");
      if(!iter->second.retained)continue; // 924 PREVIOUSLY EXCLUDED parents NOT replayed.
      ++st.selected;
      const Prior& recorded=iter->second;
      const C& part=parents[j];Disk d=ball(part);
      try{
        State R2=f2::iter(tube.at_start(),d,data.phi,2);
        Z M2=tube.upper(R2.a.v).M;
        State P2=f2::iter(tube.at_start(),Disk(d.c,0),data.phi,2);
        C b2=mid(P2.b.d);Z lb=norm_lower(b2);
        if(lb<=0)throw std::domain_error("prior second slope includes zero");
        Z D=norm_upper(R2.b.d-b2),Dr=cd(D*d.r,SCALE);
        Disk N2=necessary_disk(d,P2.b.v,R2.b.d,b2,M2);
        C shifted=d.c-P2.b.v/b2;Z ce=norm_upper(shifted-mid(shifted));
        Z radius=ce+cd((M2+Dr)*SCALE,lb);
        // Fail closed if the frozen prior run does not describe this SAME
        // exact-dyadic computation. No source row may silently change action.
        if(recorded.M!=M2||recorded.Dr!=Dr||recorded.D!=D||recorded.r!=d.r||
           recorded.lb!=lb||recorded.err!=ce||recorded.radius!=N2.r||N2.r!=radius)
          throw std::runtime_error("retained F2 parent differs from exact source term log");
        auto retained_parent=intersection(part,N2.box());
        if(!retained_parent)throw std::runtime_error("source RETAINED parent now excludes itself");
        ++st.checked_parents;
        f1::add_hull(st.previous_hull,*retained_parent);
        // Use the actual AFTER-F2 retained rectangle, not the wider part
        // before its necessary-condition intersection.
        const auto children=f2::split_box(*retained_parent,2);
        if(children.size()!=4)throw std::runtime_error("expected four children");
        for(size_t k=0;k<4;++k){
          const C& child=children[k];const Disk disk=ball(child);
          ++st.child_attempted;
          try{
            State Rchild=f2::iter(tube.at_start(),disk,data.phi,2);
            const Z Mc=tube.upper(Rchild.a.v).M;
            State Pchild=f2::iter(tube.at_start(),Disk(disk.c,0),data.phi,2);
            const C slope=mid(Pchild.b.d);Z slope_lb=norm_lower(slope);
            if(slope_lb<=0)throw std::domain_error("child slope includes zero");
            const Z derivative_spread=norm_upper(Rchild.b.d-slope);
            const Z Dr_child=cd(derivative_spread*disk.r,SCALE);
            const Disk necessary=necessary_disk(disk,Pchild.b.v,Rchild.b.d,slope,Mc);
            const C shifted_child=disk.c-Pchild.b.v/slope;
            const Z center_err=norm_upper(shifted_child-mid(shifted_child));
            if(necessary.r!=center_err+cd((Mc+Dr_child)*SCALE,slope_lb))
              throw std::runtime_error("C1-C2 child radius identity changed");
            auto hit=intersection(child,necessary.box());
            ++st.child_evaluated;
            if(hit){
              ++st.child_retained;f1::add_hull(st.final_hull,*hit);
              output_row(out,i,j,k,*retained_parent,child,*hit,necessary.box(),
                         Mc,Dr_child,derivative_spread,disk.r,slope_lb,center_err,necessary.r,"VALID","RETAINED");
            }else{
              ++st.child_excluded;
              output_row(out,i,j,k,*retained_parent,child,C(0),necessary.box(),
                         Mc,Dr_child,derivative_spread,disk.r,slope_lb,center_err,necessary.r,"VALID","EXCLUDED");
            }
            if(Mc>0)st.q.push_back(cd(Dr_child*SCALE,Mc));
          }catch(const std::domain_error& e){
            // Unresolved CHILD is retained at its current (already F2-reduced)
            // box; do not silently drop an unknown candidate.
            ++st.child_unresolved;f1::add_hull(st.final_hull,child);
            output_row(out,i,j,k,*retained_parent,child,child,child,
                       0,0,0,0,0,0,0,"UNRESOLVED","RETAINED");
            if(st.child_unresolved<=6)
              std::cerr<<"UNRESOLVED child="<<i<<','<<j<<','<<k<<" : "<<e.what()<<'\n';
          }
        }
      }catch(const std::domain_error& e){
        // This should not occur for a formerly VALID retained parent, but
        // do not claim any narrower result if it does. Caller exits 2.
        throw std::domain_error(std::string("previous retained parent unevaluable; retain previous F2 cover: ")+e.what());
      }
    }
  }
  if(st.selected!=100 || st.checked_parents!=100 || st.child_attempted!=400 ||
     st.child_evaluated+st.child_unresolved!=400 ||
     st.child_excluded+st.child_retained+st.child_unresolved!=400)
    throw std::runtime_error("source selection/completeness mismatch");
  if(!st.previous_hull || !st.final_hull)
    throw std::domain_error("empty cover is not a certified nonexistence result");
  C& a=*st.previous_hull;C& b=*st.final_hull;
  if(!(a.re.l<=b.re.l&&b.re.h<=a.re.h&&a.im.l<=b.im.l&&b.im.h<=a.im.h))
    throw std::runtime_error("selective final hull grew outside prior F2 cover");
  return st;
}
} // namespace selective


#ifndef DYAD_SELECTIVE_NO_MAIN
int main(int argc,char** argv){
  if(argc!=4){std::cerr<<"Usage: selective_f2 TRANSFER PREVIOUS_COMPLETE_TERMS_TSV NEW_CHILD_DETAILS_TSV\n";return 64;}
  try{
    const Data data=read_data(argv[1]);
    const auto previous=selective::read_prior(argv[2]);
    auto s=selective::refine(data,previous,argv[3]);
    Z before=enclosing_disk(*s.previous_hull).r,after=enclosing_disk(*s.final_hull).r;
    if(after>before)throw std::runtime_error("radius increased after inclusion");
    std::cout<<"MODE=SESSION_CONDITIONAL; F2_SELECTED_REFINEMENT; SOURCE_GRID=8; SOURCE_SUB=8; CHILD_SUB=2\n";
    std::cout<<"source_first_tiles="<<s.first_tiles<<" source_parent_rows="<<s.source_parents
             <<" prior_excluded="<<s.prior_excluded<<" selected_parent_rows="<<s.selected
             <<" checked_parent_rows="<<s.checked_parents<<"\n";
    std::cout<<"child_attempted="<<s.child_attempted<<" child_evaluated="<<s.child_evaluated
             <<" child_excluded="<<s.child_excluded<<" child_retained="<<s.child_retained
             <<" child_unresolved="<<s.child_unresolved<<"\n";
    std::cout<<"prior_hull_L1_256="<<before<<" final_hull_L1_256="<<after<<"\n";
    std::cout<<"prior_hull_L1="<<f1::outdec(before)<<" final_hull_L1="<<f1::outdec(after)<<"\n";
    std::sort(s.q.begin(),s.q.end());
    if(!s.q.empty())std::cout<<"Dr_over_M2_min="<<f1::outdec(s.q.front())
             <<" median="<<f1::outdec(s.q[s.q.size()/2])
             <<" max="<<f1::outdec(s.q.back())<<"\n";
    std::cout<<"NO_CERTIFICATE; conditional on sectorial graph and D0-tube hypotheses; NOT stage3c-b or jump.\n";
    return s.child_unresolved?2:0;
  }catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<"\n";return 2;}
   catch(const std::exception&e){std::cerr<<"INPUT_FAIL: "<<e.what()<<"\n";return 3;}
}

#endif // DYAD_SELECTIVE_NO_MAIN
