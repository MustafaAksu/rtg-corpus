import sys
sys.path.insert(0,'.')
from qw import *
from fractions import Fraction as Fr
from math import factorial
def F_zw(N):
    """Complexified F = T^6 in (z,w) = (W, Wbar) coordinates, degree <= N, coefficients in Q(omega)."""
    X={(1,0):K(1)}; Y={(0,1):K(1)}
    # rho = (z+w)/2 + (z-w)/(2*omega) ; eta = (z-w)/omega ; 1/omega = -omega/3
    io=K(0,Fr(-1,3))
    rho=padd(pscal(padd(X,Y),Fr(1,2)), pscal(padd(X,Y,-1),io*Fr(1,2)))
    eta=pscal(padd(X,Y,-1),io)
    def compose(p,m):  # p polynomial in (rho,eta)-slots given as map m=(m0,m1)
        mi=max([i for i,j in p]+[0]); mj=max([j for i,j in p]+[0])
        P0=[{(0,0):K(1)}]; P1=[{(0,0):K(1)}]
        for _ in range(mi): P0.append(pmul(P0[-1],m[0],N))
        for _ in range(mj): P1.append(pmul(P1[-1],m[1],N))
        r={}
        for (i,j),v in p.items(): r=padd(r,pscal(pmul(P0[i],P1[j],N),v))
        return r
    # T in (rho,eta) with rational coefficients
    sin_e={(0,k):K(Fr((-1)**((k-1)//2),factorial(k))) for k in range(1,N+1,2)}
    em1={(k,0):K(Fr(1,factorial(k))) for k in range(1,N+1)}
    T=(padd({(1,0):K(1)},sin_e,-1), padd(padd({(0,1):K(1)},em1),sin_e,-1))
    m=(rho,eta)
    for _ in range(6): m=(compose(T[0],m),compose(T[1],m))
    Fr_,Fe=m
    half=K(Fr(1,2)); om2=OM*Fr(1,2)
    Fz=padd(padd(Fr_,pscal(Fe,-half)),pscal(Fe,om2))
    Fw=padd(padd(Fr_,pscal(Fe,-half)),pscal(Fe,-om2))
    return Fz,Fw
if __name__=='__main__':
    Fz,Fw=F_zw(5)
    for d in range(1,6):
        print(d,'Fz',{k:v for k,v in sorted(Fz.items()) if sum(k)==d})
        print(d,'Fw',{k:v for k,v in sorted(Fw.items()) if sum(k)==d})
