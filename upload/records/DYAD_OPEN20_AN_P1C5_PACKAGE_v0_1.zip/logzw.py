import sys; sys.path.insert(0,'.')
from qw import K, padd, pmul, pscal
def compose_K(p, m, N):
    mi=max([i for i,j in p]+[0]); mj=max([j for i,j in p]+[0])
    P0=[{(0,0):K(1)}]; P1=[{(0,0):K(1)}]
    for _ in range(mi): P0.append(pmul(P0[-1],m[0],N))
    for _ in range(mj): P1.append(pmul(P1[-1],m[1],N))
    r={}
    for (i,j),v in p.items(): r=padd(r,pscal(pmul(P0[i],P1[j],N),v))
    return r
def log_map_K(F, N):
    out=[]
    for u in ({(1,0):K(1)},{(0,1):K(1)}):
        term=u; tot={}; k=0
        while True:
            k+=1; term=padd(compose_K(term,F,N),term,-1)
            if not term: break
            from fractions import Fraction as Fr
            tot=padd(tot,pscal(term,K(Fr((-1)**(k+1),k))))
        out.append(tot)
    return tuple(out)
