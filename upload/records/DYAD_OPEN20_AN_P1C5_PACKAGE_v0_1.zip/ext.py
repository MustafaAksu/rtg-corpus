# E = K[a]/(A a^2 + B a + C), K = Q(omega); elements p + q*a with p,q in K. Root choice is abstract (both roots at once).
import sys; sys.path.insert(0,'.')
from qw import K
from fractions import Fraction as Fr
class Ext:
    A=B=C=None  # set by setup()
    __slots__=('p','q')
    def __init__(s,p=0,q=0): s.p=K.c(p); s.q=K.c(q)
    @staticmethod
    def c(o): return o if isinstance(o,Ext) else Ext(o,0)
    def __add__(s,o): o=Ext.c(o); return Ext(s.p+o.p,s.q+o.q)
    __radd__=__add__
    def __sub__(s,o): o=Ext.c(o); return Ext(s.p-o.p,s.q-o.q)
    def __rsub__(s,o): return Ext.c(o)-s
    def __neg__(s): return Ext(-s.p,-s.q)
    def __mul__(s,o):
        o=Ext.c(o)
        al=-(Ext.B/Ext.A); be=-(Ext.C/Ext.A)   # a^2 = al a + be
        qq=s.q*o.q
        return Ext(s.p*o.p+qq*be, s.p*o.q+s.q*o.p+qq*al)
    __rmul__=__mul__
    def conjroot(s):   # a -> a' = -B/A - a
        return Ext(s.p+s.q*(-(Ext.B/Ext.A)), -s.q)
    def norm(s):
        return (s*s.conjroot()).p
    def inv(s):
        n=s.norm(); c=s.conjroot(); ni=n.inv(); return Ext(c.p*ni,c.q*ni)
    def __truediv__(s,o): return s*Ext.c(o).inv()
    def iszero(s): return s.p.iszero() and s.q.iszero()
    def __eq__(s,o): o=Ext.c(o); return s.p==o.p and s.q==o.q
    def __repr__(s): return f"[{s.p} + {s.q}*a]"
def setup(A,B,C): Ext.A,Ext.B,Ext.C=A,B,C
