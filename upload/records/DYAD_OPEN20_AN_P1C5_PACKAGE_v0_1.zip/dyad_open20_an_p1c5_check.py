#!/usr/bin/env python3
"""DYAD O20-an P1-c-5b/5c check v0.1. Exact arithmetic in E = Q(omega)[a]/(A a^2 + B a + C) (omega = i sqrt3,
a = a2 = either root; every exact statement holds for both roots at once). Runtime ~10 s. Writes p1c5_check.json
(deterministic) and p1c5_perf.json (timings).
Gates:
  H1  formal curve through z^14: L_k = ell (k* - k) exactly (k <= 11) and the invariance residual vanishes identically
  H2  restricted map g = F_z(z, phi(z)) = z + ell z^4 + g5 z^5 + ...; holomorphic fixed-point index
      iota := Res_0 dz/(z - g(z)) lies in Q(omega) (a-component 0, i.e. the same for both curves) and equals
      49658905924/263611634013 - (40940212120/790834902039) i sqrt3; stable for N = 10 and 14
  H3  Briot-Bouquet data of the formal log Xhat = log F (Mercator, exact) along w = z^2 u: h(0,a) - 2a g(0,a) = 0
      (same quadratic) and lambda := d_u f(0,a) = k* - 2 = -102/19 - (16/19) i sqrt3 exactly (non-real, not in N)
  H4  [NUM consistency] exact a_k evaluated at both numerical roots agree with an independent 60-digit recursion (k <= 9)
Negative controls (must fail):
  M1  index with the wrong orientation (Res of 1/(g - z))
  M2  lambda computed with conj(c40) in place of c40
  M3  index from g truncated before z^7
"""
import sys, json, time
sys.path.insert(0, '.')
from fractions import Fraction as Fr
import mpmath as mp
from qw import K
from fzw import F_zw
from ext import Ext, setup
from logzw import log_map_K
t0 = time.time(); perf = {}
def build(NMAX):
    Fz, Fw = F_zw(NMAX)
    mu = K(Fr(-1, 2), Fr(-2, 3)); c40 = Fz[(4, 0)]; F31 = Fw[(3, 1)]; c05b = Fw[(5, 0)]
    setup(mu.conj() - mu * 2, F31 - c40 * 2, c05b)
    FzE = {k: Ext(v) for k, v in Fz.items()}; FwE = {k: Ext(v) for k, v in Fw.items()}
    N = NMAX
    def mulu(x, y):
        r = [Ext()] * (N + 1)
        for i, xi in enumerate(x):
            if xi.iszero(): continue
            for j in range(N + 1 - i):
                if not y[j].iszero(): r[i + j] = r[i + j] + xi * y[j]
        return r
    def subs(P, phi):
        pw = [[Ext(1)] + [Ext()] * N]
        for _ in range(max(j for i, j in P)): pw.append(mulu(pw[-1], phi))
        r = [Ext()] * (N + 1)
        for (i, j), v in P.items():
            for d in range(N + 1 - i):
                if not pw[j][d].iszero(): r[i + d] = r[i + d] + v * pw[j][d]
        return r
    def ucomp(phi, g):
        r = [Ext()] * (N + 1); p = [Ext(1)] + [Ext()] * N
        for k in range(1, N + 1):
            p = mulu(p, g)
            if not phi[k].iszero():
                for d in range(N + 1): r[d] = r[d] + phi[k] * p[d]
        return r
    def E(phi):
        Aw = subs(FwE, phi); g = subs(FzE, phi); Bc = ucomp(phi, g)
        return [Aw[d] - Bc[d] for d in range(N + 1)], g
    a = Ext(0, 1); ell = Ext(c40) + Ext(mu) * a
    kstar = K(Fr(-64, 19), Fr(-16, 19))
    phi = [Ext()] * (N + 1); phi[2] = a; Lok = True
    for k in range(3, N - 2):
        e0, _ = E(phi); phi[k] = Ext(1); e1, _ = E(phi); phi[k] = Ext()
        L = e1[k + 3] - e0[k + 3]; Lok = Lok and (L == ell * Ext(kstar - K(k)))
        phi[k] = -(e0[k + 3] / L)
    e, g = E(phi)
    return dict(Fz=Fz, Fw=Fw, mu=mu, c40=c40, ell=ell, kstar=kstar, phi=phi, g=g, Lok=Lok,
                resid=all(x.iszero() for x in e), N=N)
def index(g, upto=7, orient=1):
    h = [g[4 + j] if 4 + j <= upto else Ext() for j in range(4)]
    inv = [Ext(1) / h[0]]
    for n in range(1, 4):
        s = Ext()
        for j in range(1, n + 1): s = s + h[j] * inv[n - j]
        inv.append(-(s / h[0]))
    return -inv[3] if orient == 1 else inv[3]
g_ = {}; neg = {}
R10 = build(10); R14 = build(14); perf['build'] = round(time.time() - t0, 2)
g_['H1'] = R14['Lok'] and R14['resid'] and R10['resid']
iota_exp = Ext(K(Fr(49658905924, 263611634013), Fr(-40940212120, 790834902039)))
i10, i14 = index(R10['g']), index(R14['g'])
g_['H2'] = i10 == iota_exp and i14 == iota_exp and i14.q.iszero() and R14['g'][4] == R14['ell']
neg['M1'] = index(R14['g'], orient=-1) == iota_exp
neg['M3'] = index(R14['g'], upto=6) == iota_exp
# H3: Briot-Bouquet data of Xhat
Xz, Xw = log_map_K((R10['Fz'], R10['Fw']), 6)
def bb(c40x):
    a = Ext(0, 1)
    g0 = Ext(c40x) + Ext(Xz[(2, 1)]) * a
    h0 = Ext(Xw[(5, 0)]) + Ext(Xw[(3, 1)]) * a + Ext(Xw[(1, 2)]) * a * a
    root_ok = (h0 - a * g0 * 2).iszero()
    dh = Ext(Xw[(3, 1)]) + Ext(Xw[(1, 2)]) * a * 2; dg = Ext(Xz[(2, 1)])
    lam = (dh - g0 * 2 - a * dg * 2) / g0
    return root_ok, lam
rok, lam = bb(Xz[(4, 0)])
lam_exp = Ext(K(Fr(-102, 19), Fr(-16, 19)))
g_['H3'] = rok and lam == lam_exp and Xz[(4, 0)] == R10['c40'] and Xw[(5, 0)] == R10['Fw'][(5, 0)]
_, lam_bad = bb(Xz[(4, 0)].conj()); neg['M2'] = lam_bad == lam_exp
perf['H1-H3'] = round(time.time() - t0, 2)
# H4: numeric consistency
mp.mp.dps = 60
w = mp.mpc(0, 1) * mp.sqrt(3)
cx = lambda x: mp.mpf(x.a.numerator) / x.a.denominator + w * mp.mpf(x.b.numerator) / x.b.denominator
A, B, C = map(cx, (Ext.A, Ext.B, Ext.C))
FzN = {k: cx(v) for k, v in R14['Fz'].items()}; FwN = {k: cx(v) for k, v in R14['Fw'].items()}
N = 12
def mulu(x, y):
    r = [mp.mpc(0)] * (N + 1)
    for i, xi in enumerate(x):
        if xi == 0: continue
        for j in range(N + 1 - i): r[i + j] += xi * y[j]
    return r
def subsN(P, phi):
    pw = [[mp.mpc(1)] + [mp.mpc(0)] * N]
    for _ in range(max(j for i, j in P)): pw.append(mulu(pw[-1], phi))
    r = [mp.mpc(0)] * (N + 1)
    for (i, j), v in P.items():
        if i > N: continue
        for d in range(N + 1 - i): r[i + d] += v * pw[j][d]
    return r
def EN(phi):
    A_ = subsN(FwN, phi); gm = subsN(FzN, phi)
    r = [mp.mpc(0)] * (N + 1); p = [mp.mpc(1)] + [mp.mpc(0)] * N
    for k in range(1, N + 1):
        p = mulu(p, gm)
        if phi[k] != 0:
            for d in range(N + 1): r[d] += phi[k] * p[d]
    return [A_[d] - r[d] for d in range(N + 1)]
ok4 = True
for s in (1, -1):
    a2 = (-B + s * mp.sqrt(B * B - 4 * A * C)) / (2 * A)
    phi = [mp.mpc(0)] * (N + 1); phi[2] = a2
    for k in range(3, N - 2):
        e0 = EN(phi); phi[k] = mp.mpc(1); e1 = EN(phi); phi[k] = mp.mpc(0)
        phi[k] = -e0[k + 3] / (e1[k + 3] - e0[k + 3])
    for k in range(2, N - 2):
        ex = R14['phi'][k]; val = cx(ex.p) + cx(ex.q) * a2
        ok4 = ok4 and abs(val - phi[k]) < mp.mpf(10) ** -50
g_['H4'] = ok4
perf['total'] = round(time.time() - t0, 2)
out = {'gates': g_, 'negative_controls_pass_should_be_false': neg,
       'a_k_exact (p + q*a)': {k: repr(R14['phi'][k]) for k in range(2, 8)},
       'g_coeffs_exact': {d: repr(R14['g'][d]) for d in range(1, 8)},
       'iota': repr(i14), 'iota_numeric': mp.nstr(cx(i14.p), 20), 'lambda_BB': repr(lam),
       'quadratic': {'A': repr(Ext.A), 'B': repr(Ext.B), 'C': repr(Ext.C)},
       'note': 'omega = i*sqrt(3); a = a2 (either root)'}
txt = json.dumps(out, indent=1, sort_keys=True); print(txt)
open('p1c5_check.json', 'w').write(txt + '\n'); open('p1c5_perf.json', 'w').write(json.dumps(perf) + '\n')
ok = all(g_.values()) and not any(neg.values()); print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
