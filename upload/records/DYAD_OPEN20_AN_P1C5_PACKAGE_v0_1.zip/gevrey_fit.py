import json, sys, math
d=json.load(open(sys.argv[1]))
res={}
for r in ('root+1','root-1'):
    a={int(k):float(v) for k,v in d[r]['abs_a_k'].items()}
    ms=sorted(a)
    ratios={m:a[m]/a[m-3] for m in ms if m-3 in a and m>=8}
    # least squares log a_m = al*m*log m + be*m + ga, m>=lo
    out={}
    for lo in (10,16,22):
        pts=[(m,math.log(a[m])) for m in ms if m>=lo]
        if len(pts)<5: continue
        X=[[m*math.log(m),m,1.0] for m,_ in pts]; Y=[y for _,y in pts]
        # normal equations 3x3
        import itertools
        XtX=[[sum(x[i]*x[j] for x in X) for j in range(3)] for i in range(3)]
        XtY=[sum(x[i]*y for x,y in zip(X,Y)) for i in range(3)]
        # solve
        M=[row[:]+[v] for row,v in zip(XtX,XtY)]
        for i in range(3):
            p=max(range(i,3),key=lambda k:abs(M[k][i])); M[i],M[p]=M[p],M[i]
            for k in range(3):
                if k!=i:
                    f=M[k][i]/M[i][i]; M[k]=[x-f*y for x,y in zip(M[k],M[i])]
        sol=[M[i][3]/M[i][i] for i in range(3)]
        out[f'm>={lo}']={'alpha(m log m)':round(sol[0],4),'beta':round(sol[1],4),'n':len(pts)}
    res[r]={'ratio |a_m/a_(m-3)|':{m:round(v,5) for m,v in ratios.items()},'fits':out,
            'root_test':{m:round(a[m]**(1/m),4) for m in ms}}
print(json.dumps(res,indent=1))
