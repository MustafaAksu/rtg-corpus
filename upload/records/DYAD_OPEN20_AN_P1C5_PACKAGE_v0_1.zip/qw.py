# Exact arithmetic in K = Q(omega), omega^2 = -3 (omega = i*sqrt3); polynomials in two variables as dicts.
from fractions import Fraction as Fr
class K:
    __slots__=('a','b')
    def __init__(s,a=0,b=0): s.a=Fr(a); s.b=Fr(b)
    def __add__(s,o): o=K.c(o); return K(s.a+o.a,s.b+o.b)
    __radd__=__add__
    def __sub__(s,o): o=K.c(o); return K(s.a-o.a,s.b-o.b)
    def __rsub__(s,o): return K.c(o)-s
    def __neg__(s): return K(-s.a,-s.b)
    def __mul__(s,o): o=K.c(o); return K(s.a*o.a-3*s.b*o.b, s.a*o.b+s.b*o.a)
    __rmul__=__mul__
    def conj(s): return K(s.a,-s.b)
    def norm(s): return s.a*s.a+3*s.b*s.b
    def inv(s): n=s.norm(); return K(s.a/n,-s.b/n)
    def __truediv__(s,o): return s*K.c(o).inv()
    def __eq__(s,o): o=K.c(o); return s.a==o.a and s.b==o.b
    def __hash__(s): return hash((s.a,s.b))
    def iszero(s): return s.a==0 and s.b==0
    @staticmethod
    def c(o): return o if isinstance(o,K) else K(o,0)
    def __repr__(s): return f"({s.a}{'+' if s.b>=0 else '-'}{abs(s.b)}w)"
    def cx(s): import mpmath; return mpmath.mpc(s.a.numerator,0)/s.a.denominator + mpmath.mpc(0,1)*mpmath.sqrt(3)*mpmath.mpf(s.b.numerator)/s.b.denominator
OM=K(0,1)
def padd(p,q,c=1):
    r=dict(p)
    for k,v in q.items():
        x=r.get(k,K())+ (v if c==1 else v*c)
        if x.iszero(): r.pop(k,None)
        else: r[k]=x
    return r
def pmul(p,q,N):
    r={}
    for (i1,j1),v1 in p.items():
        for (i2,j2),v2 in q.items():
            if i1+i2+j1+j2<=N:
                k=(i1+i2,j1+j2); r[k]=r.get(k,K())+v1*v2
    return {k:v for k,v in r.items() if not v.iszero()}
def pscal(p,c): return {k:v*c for k,v in p.items() if not (v*c).iszero()}
