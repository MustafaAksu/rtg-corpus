#!/usr/bin/env python3
"""DYAD O20-an P1-c-2 check v0.1 -- hypothesis checks for the imported parabolic-curve literature.
Exact arithmetic in K = Q(omega) (omega = i sqrt3) and in E = K[a]/(A a^2 + B a + C) (a = a2, either root of the
P1-c-5 quadratic; statements in E hold for both formal curves at once). Writes p1c2_check.json (deterministic) and
p1c2_perf.json (timings only).

Gates
  K1  complexified F: DF(0) = I, no quadratic terms, cubic part exactly (mu z^2 w, conj(mu) z w^2): Abate order nu = 3
  K2  non-dicritical (w P3 - z Q3 != 0); singular cone v P3(u,v) - u Q3(u,v) = c u^2 v^2, c != 0:
      singular directions [1:0], [0:1], multiplicity 2 each (total nu_o + 1 = 4)
  K3  Abate residual indices: iota[1:0] = Res_0 P3(1,u)/(Q3(1,u) - u P3(1,u)) = -1/2 + omega/8,
      iota[0:1] = conj = -1/2 - omega/8; sum = -1 (Residual Index Theorem, c1 = -1); both non-real, so not in Q+
  K4  Vivas/Abate-Tovena type: m = 1, n = 2 at both directions (Fuchsian, degenerate); Abate-Tovena residue
      rho = -2 iota (nu_AT = 2), mu_X = 2, mu_Y = 1, Re rho = mu_Y, rho != mu_Y, mu_Y - rho not in N*;
      Vivas region test FALSE under every reading (Thm 7, Thm 1 literal, Prop 2 centre, inverse index, Lemma 4)
  K5  identity k* = 2 / iota[1:0] (k* = -64/19 - 16 omega/19 from P1-c-5)
  K6  LHRRS Section 4 reduction along Gamma (one blow-up w = x w1, y = w1 - J4(phi/x)), exact in E:
      x o F |_{y=0} = x + ell x^4 + O(x^5); y o F |_{y=0} = O(x^5); d_y(y o F)|_{y=0} = 1 + c3 x^3 + O(x^4)
      (c1 = c2 = 0), hence t >= r = 3, so k = 3, p = 0 (Briot-Bouquet case); ell != 0;
      c3 = ell (k* - 1) exactly (one blow-up earlier than K7, whose ratio is k* - 2)
  K7  reduced singularity of Xhat after the two blow-ups w = x^2 u: eigenvalues ell, lambda*ell with
      lambda = k* - 2 non-real (non-degenerate, ratio not in Q+): Gamma is of Briot-Bouquet type
Negative controls (must evaluate False)
  N1  index at [1:0] computed in the wrong chart orientation equals the K3 value
  N2  dicritical detector fails to flag the dicritical model Q3 -> mu z w^2
  N3  y o F |_{y=0} = O(x^5) with a wrong curve (phi = 0 instead of the formal curve)
  N4  positive control of the region test: the point -1/2 + 1/100 + omega/8 is NOT accepted (Thm 7 reading)
"""
import sys, json, time
sys.path.insert(0, '.')
from fractions import Fraction as Fr
from qw import K
from fzw import F_zw
from ext import Ext, setup
from logzw import log_map_K
t0 = time.time(); perf = {}
OM = K(0, 1)
NF = 9
Fz, Fw = F_zw(NF); perf['F'] = round(time.time() - t0, 2)
mu = K(Fr(-1, 2), Fr(-2, 3)); kstar = K(Fr(-64, 19), Fr(-16, 19))
g_ = {}; neg = {}; out = {}
# ---------- K1
deg = lambda P, d: {k: v for k, v in P.items() if sum(k) == d}
k1 = deg(Fz, 1) == {(1, 0): K(1)} and deg(Fw, 1) == {(0, 1): K(1)}
k1 = k1 and not deg(Fz, 2) and not deg(Fw, 2)
P3, Q3 = deg(Fz, 3), deg(Fw, 3)
k1 = k1 and P3 == {(2, 1): mu} and Q3 == {(1, 2): mu.conj()}
g_['K1'] = k1
# ---------- K2
def wP_minus_zQ(P, Q):
    r = {}
    for (i, j), v in P.items(): r[(i, j + 1)] = r.get((i, j + 1), K()) + v
    for (i, j), v in Q.items(): r[(i + 1, j)] = r.get((i + 1, j), K()) - v
    return {k: v for k, v in r.items() if not v.iszero()}
cone = wP_minus_zQ(P3, Q3)   # v P(u,v) - u Q(u,v) with (u,v) = (z,w)
g_['K2'] = list(cone.keys()) == [(2, 2)] and not cone[(2, 2)].iszero()
out['singular_cone'] = {str(k): repr(v) for k, v in cone.items()}
neg['N2'] = not wP_minus_zQ(P3, {(1, 2): mu}) == {}     # True would mean detector misses the dicritical model
# ---------- K3
def series_div_res(Nc, Dc):
    """Residue at 0 of N(u)/D(u), N, D given as coefficient lists in K."""
    n = next(i for i, x in enumerate(Dc) if not x.iszero())
    D = Dc[n:]; L = len(Nc) + 4
    inv = [K(1) / D[0]]
    for s in range(1, L):
        acc = K()
        for j in range(1, min(s, len(D) - 1) + 1): acc = acc + D[j] * inv[s - j]
        inv.append(-(acc / D[0]))
    # N/D = u^{-n} * N * inv ; residue = coeff of u^{n-1} in N*inv
    c = K()
    for i in range(0, n):
        if i < len(Nc): c = c + Nc[i] * inv[n - 1 - i]
    return c
def chart_polys(P, Q, at10=True):
    # [1:0]: p(u) = P(1,u), r(u) = Q(1,u) - u P(1,u) ; [0:1]: p(v) = Q(v,1), r(v) = P(v,1) - v Q(v,1)
    if not at10: P, Q = {(j, i): v for (i, j), v in Q.items()}, {(j, i): v for (i, j), v in P.items()}
    p = [K()] * 6; r = [K()] * 6
    for (i, j), v in P.items(): p[j] = p[j] + v; r[j + 1] = r[j + 1] - v
    for (i, j), v in Q.items(): r[j] = r[j] + v
    return p, r
p10, r10 = chart_polys(P3, Q3, True); p01, r01 = chart_polys(P3, Q3, False)
i10 = series_div_res(p10, r10); i01 = series_div_res(p01, r01)
iexp = K(Fr(-1, 2), Fr(1, 8))
g_['K3'] = (i10 == iexp and i01 == iexp.conj() and (i10 + i01) == K(-1)
            and not i10.b == 0 and not i01.b == 0)
out['abate_index'] = {'[1:0]': repr(i10), '[0:1]': repr(i01)}
p_sw, r_sw = chart_polys(Q3, P3, True)   # wrong chart formula: roles of the two components exchanged
neg['N1'] = series_div_res(p_sw, r_sw) == iexp
# ---------- K4
ordk = lambda c: next(i for i, x in enumerate(c) if not x.iszero())
m10, n10, m01, n01 = ordk(p10), ordk(r10), ordk(p01), ordk(r01)
nuAT = 2; rho = i10 * (-nuAT); muX = n10; muY = muX - 1
def re(z): return z.a
def abs2(z): return z.a * z.a + 3 * z.b * z.b
def inR(z, m, k, plus=False):
    s = Fr(m, k - 1); c = (m + 1 + s) / 2 if plus else (m + 1 - s) / 2; rr = (m + 1 + s) / 2
    return re(z) > -s and abs2(z - K(c)) > rr * rr
def lemma4(beta, m, k):
    a_, b_ = k - 1, m * k + k - 1; cd = K(1) / beta - K(m + 1); h = Fr(b_, 2 * a_)
    return re(cd) > Fr(-b_, a_) and abs2(cd + K(h)) > h * h
kV = 3
readings = {'Thm7: iota in R': inR(i10, 1, kV), 'Thm7: 1/iota in R': inR(K(1) / i10, 1, kV),
            'Thm1 literal: Re(1/iota) in R': inR(K(re(K(1) / i10)), 1, kV),
            'Prop2 centre: iota in R+': inR(i10, 1, kV, True), 'Prop2 centre: 1/iota in R+': inR(K(1) / i10, 1, kV, True),
            'Lemma4 (a=2,b=5,c/d=1/iota-2)': lemma4(i10, 1, kV),
            'Thm7 at [0:1]': inR(i01, 1, kV), 'Lemma4 at [0:1]': lemma4(i01, 1, kV)}
out['vivas_region_tests'] = readings
g_['K4'] = ((m10, n10, m01, n01) == (1, 2, 1, 2) and muX == 2 and muY == 1 and rho == K(1, Fr(-1, 4))
            and re(rho) == muY and not rho == K(muY) and not (K(muY) - rho).b == 0
            and not any(readings.values()))
out['abate_tovena'] = {'m,n [1:0]': [m10, n10], 'm,n [0:1]': [m01, n01], 'mu_X': muX, 'mu_Y': muY, 'rho[1:0]': repr(rho)}
neg['N4'] = not inR(K(Fr(-1, 2) + Fr(1, 100), Fr(1, 8)), 1, kV)
# ---------- K5
g_['K5'] = kstar == K(2) / i10
# ---------- formal curve in E (as in P1-c-5)
c40 = Fz[(4, 0)]; F31 = Fw[(3, 1)]; c05b = Fw[(5, 0)]
setup(mu.conj() - mu * 2, F31 - c40 * 2, c05b)
a = Ext(0, 1); ell = Ext(c40) + Ext(mu) * a
N = NF
def mulu(x, y):
    r = [Ext()] * (N + 1)
    for i, xi in enumerate(x):
        if xi.iszero(): continue
        for j in range(N + 1 - i):
            if not y[j].iszero(): r[i + j] = r[i + j] + xi * y[j]
    return r
FzE = {k: Ext(v) for k, v in Fz.items()}; FwE = {k: Ext(v) for k, v in Fw.items()}
def subs(P, phi):
    pw = [[Ext(1)] + [Ext()] * N]
    for _ in range(max(j for i, j in P)): pw.append(mulu(pw[-1], phi))
    r = [Ext()] * (N + 1)
    for (i, j), v in P.items():
        for d in range(N + 1 - i):
            if not pw[j][d].iszero(): r[i + d] = r[i + d] + v * pw[j][d]
    return r
def ucomp(phi, g):
    r = [Ext()] * (N + 1); p = [Ext(1)] + [Ext()] * N
    for k in range(1, N + 1):
        p = mulu(p, g)
        if not phi[k].iszero():
            for d in range(N + 1): r[d] = r[d] + phi[k] * p[d]
    return r
def Eres(phi):
    Aw = subs(FwE, phi); g = subs(FzE, phi); Bc = ucomp(phi, g)
    return [Aw[d] - Bc[d] for d in range(N + 1)]
phi = [Ext()] * (N + 1); phi[2] = a
for k in range(3, N - 2):
    e0 = Eres(phi); phi[k] = Ext(1); e1 = Eres(phi); phi[k] = Ext()
    phi[k] = -(e0[k + 3] / (e1[k + 3] - e0[k + 3]))
perf['curve'] = round(time.time() - t0, 2)
# ---------- K6: dual numbers in y (pairs (c0, c1)), truncated series in x up to x^M
M = 7
class D:
    __slots__ = ('s',)
    def __init__(s, lst): s.s = lst
    @staticmethod
    def zero(): return D([[Ext(), Ext()] for _ in range(M + 1)])
    def __add__(s, o): return D([[s.s[i][0] + o.s[i][0], s.s[i][1] + o.s[i][1]] for i in range(M + 1)])
    def __sub__(s, o): return D([[s.s[i][0] - o.s[i][0], s.s[i][1] - o.s[i][1]] for i in range(M + 1)])
    def scal(s, c): return D([[x[0] * c, x[1] * c] for x in s.s])
    def __mul__(s, o):
        r = D.zero()
        for i in range(M + 1):
            a0, a1 = s.s[i]
            if a0.iszero() and a1.iszero(): continue
            for j in range(M + 1 - i):
                b0, b1 = o.s[j]
                r.s[i + j][0] = r.s[i + j][0] + a0 * b0
                r.s[i + j][1] = r.s[i + j][1] + a0 * b1 + a1 * b0
        return r
    def shift_down(s):  # divide by x (assumes x | s)
        assert s.s[0][0].iszero() and s.s[0][1].iszero()
        return D(s.s[1:] + [[Ext(), Ext()]])
    def inv1(s):  # 1/s for s = 1 + O(x) + O(y)
        u = D.zero(); u.s[0][0] = Ext(1)
        t = s - u; r = u; p = u
        for _ in range(2 * M + 2):
            p = p * t.scal(Ext(-1)); r = r + p
        return r
def const(c, deg=0):
    d = D.zero(); d.s[deg][0] = c; return d
X = const(Ext(1), 1); Y = D.zero(); Y.s[0][1] = Ext(1)
def poly_eval(P, Xs, Ws):
    mi = max(i for i, j in P); mj = max(j for i, j in P)
    PX = [const(Ext(1))]; PW = [const(Ext(1))]
    for _ in range(mi): PX.append(PX[-1] * Xs)
    for _ in range(mj): PW.append(PW[-1] * Ws)
    r = D.zero()
    for (i, j), v in P.items():
        if i <= M and j <= M: r = r + (PX[i] * PW[j]).scal(v)
    return r
def reduction(psi_coeffs):
    J = D.zero()
    for j, c in psi_coeffs.items(): J.s[j][0] = c
    W1 = J + Y; Wv = X * W1
    X1 = poly_eval(FzE, X, Wv); Wn = poly_eval(FwE, X, Wv)
    W1n = Wn.shift_down() * X1.shift_down().inv1()
    JX = D.zero(); pw = const(Ext(1))
    for j in range(1, max(psi_coeffs) + 1):
        pw = pw * X1
        if j in psi_coeffs: JX = JX + pw.scal(psi_coeffs[j])
    yF = W1n - JX
    return X1, yF
psi = {j: phi[j + 1] for j in range(1, 5)}           # J4(phi/x)
X1, yF = reduction(psi)
x_part = [X1.s[i][0] for i in range(6)]
b_part = [yF.s[i][0] for i in range(6)]
c_part = [yF.s[i][1] for i in range(5)]
k6 = (x_part[0].iszero() and x_part[1] == Ext(1) and x_part[2].iszero() and x_part[3].iszero() and x_part[4] == ell
      and all(b_part[i].iszero() for i in range(5))
      and c_part[0] == Ext(1) and c_part[1].iszero() and c_part[2].iszero()
      and c_part[3] == ell * Ext(kstar - K(1))
      and not ell.norm().iszero())
g_['K6'] = k6
out['LHRRS_reduction'] = {'x o F (y=0), x^0..x^4': [repr(v) for v in x_part[:5]],
                          'y o F (y=0), x^0..x^5': [repr(v) for v in b_part],
                          'd_y(y o F)(y=0), x^0..x^4': [repr(v) for v in c_part],
                          'r': 3, 't_lower_bound': 3, 'k': 3, 'p': 0, 'c3': repr(c_part[3])}
_, yF_bad = reduction({1: Ext()})
neg['N3'] = all(yF_bad.s[i][0].iszero() for i in range(5))
perf['K6'] = round(time.time() - t0, 2)
# ---------- K7 (Briot-Bouquet data of Xhat, as P1-c-5 H3)
F6z, F6w = F_zw(6)
Xz, Xw = log_map_K((F6z, F6w), 6)
g0 = Ext(Xz[(4, 0)]) + Ext(Xz[(2, 1)]) * a
h0 = Ext(Xw[(5, 0)]) + Ext(Xw[(3, 1)]) * a + Ext(Xw[(1, 2)]) * a * a
dh = Ext(Xw[(3, 1)]) + Ext(Xw[(1, 2)]) * a * 2; dg = Ext(Xz[(2, 1)])
lam = (dh - g0 * 2 - a * dg * 2) / g0
g_['K7'] = ((h0 - a * g0 * 2).iszero() and g0 == ell and lam == Ext(kstar - K(2))
            and lam.q.iszero() and not lam.p.b == 0)
out['K7'] = {'eigenvalues': ['ell', 'lambda*ell'], 'lambda': repr(lam)}
perf['total'] = round(time.time() - t0, 2)
res = {'gates': g_, 'negative_controls_pass_should_be_false': neg, 'data': out,
       'note': 'omega = i*sqrt(3); a = a2 (either root of A a^2 + B a + C, P1-c-5)'}
txt = json.dumps(res, indent=1, sort_keys=True); print(txt)
open('p1c2_check.json', 'w').write(txt + '\n'); open('p1c2_perf.json', 'w').write(json.dumps(perf) + '\n')
ok = all(g_.values()) and not any(neg.values()); print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
