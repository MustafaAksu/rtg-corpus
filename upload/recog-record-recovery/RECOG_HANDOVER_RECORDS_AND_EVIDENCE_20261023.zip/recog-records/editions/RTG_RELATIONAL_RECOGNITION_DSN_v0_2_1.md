# RTG_RELATIONAL_RECOGNITION_DSN_v0.2.1

**Title:** RTG Relational Recognition Study — Comparators, Return Defect, and Event Strata on the Dyadic Substrate
**Date:** September 2026
**Scope:** Substrate-level mathematics of *recognition* — how a relational distinction is compared with its transported self or with another distinction, what residue a closed history leaves, and which loci of the comparator/transport geometry qualify as candidate recognition events — worked on the postulated continuous dyad generator $T$ and its diagnostic shear twins. Ontological readings are carried as `[HYP]` only.
**Supersedes:** `RTG_RELATIONAL_RECOGNITION_DSN_v0.2` (post-review, unfrozen) · `RTG_RELATIONAL_RECOGNITION_DSN_v0.1` (draft)
**Companion documents:** `RTG_DYADIC_OSCILLATOR_DSN_v6.4.9` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.4` · `RTG_NUMBER_GENESIS_DSN_v1.15` · `RTG_ONTOLOGICAL_FOUNDATIONS_v0.7` · `RTG_DISCRETE_GENESIS_DSN_v2.12.13` (reference only, no import) · `DSN_METHODOLOGY_v1.2`
**DSN Methodology:** DSN_METHODOLOGY_v1.2
**Programme tier:** Tier 3 — Continuous Programme, downstream of Dyadic and Genesis (see Programme Overview §6). Study prefix `RECOG` is registered with this release: add `RECOG | RTG Relational Recognition` to the DSN_METHODOLOGY RID-prefix table and list the study in Programme Overview Tier 3 at Maturity Level A (downstream diagnostic of Dyadic/Genesis). Both registrations are part of the freeze, not deferred to v1.0.
**Status summary:** Settled: the state comparator $C_\to(a,b)=\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ is an exact consequence of certified Genesis/Dyadic definitions (conjugate orientation to the Genesis $+$ convention); the six-step return multiplier $\chi_6=1+\mu_6Q+O(Q^2)$ is its diagonal specialisation; the swap-projection decomposition $T=T_s+T_b$, the shear-jet law $\mu_6(a,b)=3b-4a^2-i\sqrt3(\tfrac13+2a^2-b)$, and the cubic-return rigidity $|\mu_6(a,b)|\ge\tfrac12$ (hence the return-defect order $k_{\rm ret}(6)=3$ is rigid across the whole real shear-jet family, while return content and radial fate are shear-selected) are exact and certified. Active: the radial swap-parity definition, the $p\mapsto k_{\rm ret}(p)$ map (CELL-A), and the $P_2$ band-scale geometry (CELL-B). Open: the physical recognition-event rule, an intrinsic type-change locus, and the origin of the one-sided ratio shear. Nothing in this document is an ontological theorem; substrate results feed the ontology note under SG-R1.

## Local Tag Aliases

| Local alias | Expands to | Used for |
|---|---|---|
| `[ALG consequence]` | `[RESULT]` `[from: ALG]` [scope: exact consequence of imported certified definitions] | comparator identities that follow from Genesis/Dyadic `[DEF]`/`[THM]` lines (Number Genesis practice) |
| `[ALG conditional]` | `[ALG]` [scope: exact under explicitly listed assumptions] | selection lemma, radial parity |
| `[ALG diagnostic]` | `[ALG]` [scope: diagnostic twin, not a generator candidate] | shear twins $T_s$, $T_{\log}$, $T_{\tanh}$ |

---

## §1. Current Canonical State {#sec-1-state}

**Comparators.** `[DEF]` Two comparators are distinguished and must not be substituted for one another (SG-R2): the *pole comparator* $C_{\rm pole}(A,B)=e^{i\eta}$ between the two poles of one dyad, and the *state comparator* $C_\to(a,b)=\overline W_aW_b$ between two dyad states in the canonical $p=6$ eigenframe $W=\rho+\omega\eta$. `[ALG consequence]` $C_\to(a,b)=a^\top Bb-i\,a^\top BJ_Qb=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ with the certified Genesis $J_Q$ (the conjugate orientation of the Genesis $I+i\tfrac{\sqrt3}{2}\omega$ pairing). `[ALG]` [RID: RECOG-ALG-INVARIANT-FORM] Every symmetric $H$ with $A^\top HA=H$ is $H=cB$; so $C_\to$ is the canonical local comparator induced by the $p=6$, $P_1$ linear transport, up to scale and complex conjugation (SG-R9). $\widehat C$ is defined only for $Q_aQ_b>0$. `[ALG consequence]` Normalised, $\widehat C=C/\sqrt{C(a,a)C(b,b)}=e^{i\theta_{ab}}\in U(1)$, and pair swap acts as $\widehat C\mapsto\widehat C^{-1}$; swap-fixed values are exactly $\widehat C=\pm1$.

**Return defect.** `[DEF]` For a resonant return germ — $F^p$ with identity linear part at the reference fixed point — the return defect is $D_p=F^p-\mathrm{id}$; the return order $k_{\rm ret}(p)$ is the degree of its first nonzero homogeneous term modulo near-identity conjugacy. `[ALG]` [import: Dyadic §6.7 | DYAD-THM-C21] For $p=6$: $k_{\rm ret}=3$, $J_3(W)=\mu_6|W|^2W$, $\mu_6=-\tfrac12-i\tfrac{2\sqrt3}{3}$. `[ALG consequence]` $\chi_6(W)=C_\to(W,T^6W)/C_\to(W,W)=1+\mu_6Q+O(Q^2)$: the eigenvalue is the linearised recognition multiplier; $\chi$ is the diagonal case of $C$. `[ALG]` In a small punctured neighbourhood of $P_1$, $|\chi_6|<1$, hence no nontrivial period-6 points; the recognition content of $p=6$ lives entirely in the nonlinear return germ, not in periodic-orbit spectra.

**Fixed points and swap.** `[ALG]` $\operatorname{Fix}(T)=\{P_1,P_2\}$ on the wrapped phase; $P_1$: $\widehat C_{\rm pole}=+1$, elliptic; $P_2$: $\widehat C_{\rm pole}=-1$, hyperbolic. `[ALG conditional]` Under pole-swap covariance `[HYP]` and the certified linearisation $A$, $\rho$ must be swap-odd. `[ALG conditional]` Under the same covariance plus periodicity, $f(0)=f(\pi)=0$ and lowest-harmonic minimality, the radial forcing is $f(\eta)\propto\sin\eta$.

**Shear decomposition and jet law.** `[ALG]` $T=T_s+T_b$ with $T_s=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta)$ the exact swap-odd projection and $T_b=(0,\cosh\rho-1)$ the entire non-equivariant content; $T_b$ is the only quadratic term of the primitive jet. `[ALG]` [RID: RECOG-ALG-SHEAR-JET] For $g(\rho)=\rho+a\rho^2+b\rho^3+O(\rho^4)$, radial row $\rho'=\rho-\sin\eta$:
$$\boxed{\mu_6(a,b)=3b-4a^2-i\sqrt3\left(\tfrac13+2a^2-b\right)}.$$
Healing $\iff 4a^2>3b$. `[ALG]` [RID: RECOG-ALG-CUBIC-RETURN-RIGIDITY] $|\mu_6(a,b)|^2=12\bigl(b-\tfrac32a^2-\tfrac1{12}\bigr)^2+\tfrac14(2a^2+1)^2\ge\tfrac14$, hence $\mu_6(a,b)\ne0$ and $k_{\rm ret}(6)=3$ for every real $(a,b)$. `[ALG diagnostic]` $\mu_6^{(s)}=\tfrac12-i\tfrac{\sqrt3}{6}$ (expansive), $\mu_6^{(\log)}=-i\tfrac{\sqrt3}{3}$ (radially neutral), $\mu_6^{(\tanh)}=-1-i\tfrac{2\sqrt3}{3}$ (healing, swap-symmetric). `[ALG consequence]` On the radial-fate boundary $4a^2=3b$: $\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$, purely angular and nonzero; at the rigidity minimiser $\mu_6(0,\tfrac1{12})=\tfrac12e^{-i\pi/3}$. `[RESULT]` `[from: ALG]` Within the shear-jet family the return-defect order is rigid — no member delays the first return defect beyond cubic order — while the return content ($\Re\mu$, $\arg\mu$) and hence the radial fate (healing / neutral / expansion) are shear-selected; the fate can change class with $k_{\rm ret}$ unchanged and an angular residue surviving. Healing does **not** require swap-symmetry breaking.

**Candidate strata.** `[DEF]` Three candidate mathematical strata with a prerequisite ladder: rank stratum ($\det DF_x=0$; one state), pair-symmetry stratum ($\widehat C=\pm1$; pole level: primitive co-presence of $A,B$; state level: co-present states or retained self-comparison), loop/spectral stratum ($(\operatorname{tr}M_n,\det M_n)$; closed transport). `[ALG]` Of single-step Jacobian invariants only rank is chart-free. `[OPEN]` [RID: RECOG-OPEN-INTERSECTION] Recognition event $=$ nontrivial algebraic stratum $\cap$ dynamically distinguished stratum — realised by $P_2$, but in the dyad this coincidence is built in, not discovered (§6.5).

**Three-layer mapping.** `[ALG consequence]` comparison $\leftrightarrow C_\to(a,b)$; closure defect $\leftrightarrow\mu_6$; persisted memory $\leftrightarrow\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ (Genesis plateau bridge). These are distinct certified objects; recognition $\ne$ closure defect $\ne$ memory.

---

## §2. Active Frontier / OPEN Registry {#sec-2-open}

---
**OPEN R1 — Radial swap parity** [RID: RECOG-OPEN-RHO-PARITY]

Status: PARTIAL
Owner branch: this document
Exports to: RTG_ONTOLOGICAL_FOUNDATIONS (definition request)

Closed sub-items:
- Under pole-swap covariance and certified $A$, swap-even $\rho$ is excluded ($f'(0)=-1\ne0$) :: `[ALG conditional]` ✓

Active sub-items:
- Adopt $\rho$ as oriented (log-ratio-type) relational coordinate as a primitive `[DEF]` in OFN :: `[OPEN]`
- Status of pole-swap covariance itself as a primitive principle :: `[HYP]`

Dependencies:
- §6.4, §6.5
---

---
**OPEN R2 — CELL-A: return order across the $p$-family** [RID: RECOG-OPEN-KRET-P]

Status: ACTIVE
Owner branch: this document
Imports to: none yet

Active sub-items:
- Extract $\nu_3^{(1,p)}$ for $p=5,6,7$ from the existing cyclotomic one-step engine; evaluate $\mu_p=p\bar\lambda\nu_3^{(1,p)}$ :: `[OPEN]`
- Determine $k_{\rm ret}(p)$; if $\mu_p=0$, proceed to degree 5 — a vanishing cubic coefficient is *not* absence of recognition :: `[OPEN]`

Next required artifact:
- `recog_cell_a_nu3.py` (export of the $(2,1)$ normalised row from `normalize_p_full_onestep_cyclotomic.py`)

Dependencies:
- Dyadic §6.11 OPEN 9 finite ledger (values recorded there are $\nu_5^{(5)}$, $c_{05}^{(1,6)}$, $c_{06}^{(7)}$ — not $\nu_3^{(1,p)}$); Dyadic bridge lemma DYAD-ALG-BRIDGE-LEMMA
---

---
**OPEN R3 — CELL-B: $P_2$ band-scale geometry** [RID: RECOG-OPEN-P2-BAND]

Status: ACTIVE
Owner branch: this document

Closed sub-items:
- Saddle spectrum $\phi^{\pm2}$ fixes width–lifetime scaling $\varepsilon_m\sim\phi^{-2m}$ but not a width; local rescaling $\varepsilon\to c\varepsilon$ leaves eigenvalues invariant :: `[ALG]` ✓ (negative result)

Active sub-items:
- Compute $W^u(P_2)$, $W^s(P_2)$ and their first intersection with the rank stratum $C_0$; report $\delta\eta_{\rm pole}=\operatorname{dist}_{S^1}(\eta_\cap,\pi)$ :: `[OPEN]`
- Alternative intrinsic boundaries (return stratum, invariant-manifold lobes) :: `[OPEN]`

Next required artifact:
- `recog_cell_b_p2_manifolds.py`

Dependencies:
- Dyadic OPEN 12 (P2 saddle manifold); Dyadic §6.1 $C_0$; SG-R2 (output must be a pole-comparator angle); SG-R5 (no TDR-G import)
---

---
**OPEN R4 — Intrinsic type-change locus** [RID: RECOG-OPEN-TYPE-CHANGE]

Status: ACTIVE

Active sub-items:
- Does the primitive-chart locus $\cos\eta=0$ (parabolic, unipotent $J$) have a coordinate-free counterpart via periodic-orbit multipliers in the $(t,d)$-plane or via comparator geometry? :: `[OPEN]`
- Global periodic-orbit inventory of $T$ beyond $P_1,P_2$ (none exist in the small punctured $P_1$ sector) :: `[OPEN]`

Dependencies:
- §6.5, SG-R3
---

---
**OPEN R5 — Why one-sided ratio shear?** [RID: RECOG-OPEN-ONESIDED-SHEAR]

Status: ACTIVE
Exports to: RTG_ONTOLOGICAL_FOUNDATIONS §6.2a (rows 2–3), OPEN-P0 generator selection

Active sub-items:
- Derive why the primitive phase shear is $r-1=e^\rho-1$ (one-sided ratio) rather than $\log r=\rho$ or $\tfrac12(r-r^{-1})=\sinh\rho$; the certified functional consequence is the radial fate via $4a^2\gtrless3b$ :: `[OPEN]`
- Whether large-$|\rho|$ drive behaviour (a "saturation" reading) plays any role — not testable by the cubic jet; requires a nonlocal test before any `[HEUR]` :: `[OPEN]`

Dependencies:
- §6.6, §6.7
---

---
**OPEN R6 — Physical recognition-event rule** [RID: RECOG-OPEN-EVENT-RULE]

Status: ACTIVE

Active sub-items:
- Which comparator values or strata the *dynamics* responds to, beyond fixed-point type; the intersection principle RECOG-OPEN-INTERSECTION (§6.5) is a candidate, not a rule :: `[HYP]`
- Self/encounter unification: verify that $C_\to(r,F_\gamma r)$ and $C_\to(r_a,r_b)$ are the diagonal and off-diagonal cases of one comparison law in a multi-dyad setting (Genesis $I_{ab},\omega_{ab}$ already realise the off-diagonal case) :: `[OPEN]`

Dependencies:
- SG-R6
---

---
**OPEN R7 — Global accessibility of rank loss for shear twins** [RID: RECOG-OPEN-TWIN-ACCESS]

Status: ACTIVE

Active sub-items:
- For $T_s$ ($\Re\mu=+\tfrac12$): does the outward drift reach $|\rho|\ge\operatorname{arccosh}2$ from a small-$Q$ start? Required before any "symmetric twin runs into erasure" statement :: `[OPEN]`
- $Q_c$-type threshold for twins :: `[OPEN]`

Dependencies:
- §6.7; Dyadic §6.4 $Q_c$
---

---

## §3. Scope Guards {#sec-3-guards}

**[SG-R1]** No result in this document is an ontological theorem. Substrate results may be *cited* in the ontology note as realisation witnesses; they may not be *promoted* there. The ontology is prior to RTG, not derived from it.
Violation: category error; the ontological claim is `[HYP]` at best.

**[SG-R2]** The pole comparator $C_{\rm pole}=e^{i\eta}$ and the state comparator $C_\to(a,b)=\overline W_aW_b$ are distinct objects at distinct levels. Neither may be substituted for the other; $\arg W\ne\eta$ ($\arg W(P_2)=2\pi/3$). Any "antipode" statement must name its comparator.
Violation: mis-assigned event angle; CELL-B output becomes meaningless.

**[SG-R3]** The eigenvalue type (elliptic/parabolic/hyperbolic) of a single-step Jacobian $DF_x$ off a fixed point is chart-dependent ($DF_x\mapsto D\varphi_{F(x)}DF_xD\varphi_x^{-1}$). Only rank is pointwise chart-free. Type statements are intrinsic only for closed transports $M_n$ on periodic points.
Violation: the quadrature locus $\cos\eta=0$ is `[ALG]` [scope: primitive chart] only.

**[SG-R4]** Shear twins $T_s$, $T_{\log}$, $T_{\tanh}$ and the $(a,b)$-family are diagnostic objects. They are not generator candidates and export nothing to Genesis, Triadic or TDR-G.
Violation: contaminates OPEN-P0 with unmotivated alternatives.

**[SG-R5]** No continuous↔discrete transfer. The TDR-G antipodal defect band $\mathcal D_k$ and the continuous $P_2$ geometry are related only as *two witnesses*; STAR-NOERASE-1 and the $Q_c$ protection mechanism are witnesses in different substrates. A bridge theorem is required before "same mechanism" claims.
Violation: SG-14 of the Dyadic DSN.

**[SG-R6]** Nontriviality of a comparison ($\widehat C\ne1$, or $D_\gamma\ne0$) is not a recognition *event*. Comparison, event, and memory are three distinct layers (§6.8). "Recognised" is used only for the mathematical residue; "event" is reserved for OPEN R6.
Violation: tautology ("everything compares, hence everything is recognised").

**[SG-R7]** All results inherit `[scope: conditional on postulated continuous generator T]` from the Dyadic export protocol. Jet-law statements are cubic-order, small-$Q$ statements.
Violation: overreach beyond the local germ.

**[SG-R8]** $Q<Q_c$ certifies only that the rank stratum $C_0$ is unreachable *at the crossing step*. It is a sufficient local safety condition, not a no-erasure theorem and not a global statement.
Violation: treating a local barrier as a global protection law.

**[SG-R9]** The metric $B$ is intrinsic up to scale; the complex orientation of the comparator is fixed only after the Genesis $J_Q$ sign branch is chosen. $C_\to=\overline W_aW_b$ carries the conjugate orientation of the Genesis $I+i\tfrac{\sqrt3}{2}\omega$ pairing. Convention-safe quantities: $|C|$, amplitude ratios, the swap-fixed set $\widehat C=\pm1$. Sign-carrying quantities ($\arg\widehat C$, $\Im\mu$) must state the orientation.
Violation: sign errors in phase-defect and memory statements.

---

## §4. Layer Routing {#sec-4-routing}

| Layer | Canonical objects | Owner | Bridge required for |
|---|---|---|---|
| Primitive map | $T(\rho,\eta)$, $J$, $\det J$, $C_0$, $\operatorname{Fix}(T)$, $C_{\rm pole}=e^{i\eta}$ | Dyadic §6.1 | — |
| Birkhoff / normal form | $W$, $Q$, $\mu_6$, $h_2$, six-step jet | Dyadic §6.2, §6.7 | Birkhoff change of variables (certified in source) |
| State comparator | $C_\to(a,b)=\overline W_aW_b$, $\widehat C$, $\chi_6$ | this document §6.1–6.2 | none (exact consequence of Genesis §6.1/§6.6 definitions); orientation per SG-R9 |
| Candidate strata | rank / pair-symmetry / loop strata, $(t,d)$-plane | this document §6.5 | intrinsic type-change (OPEN R4); event rule (OPEN R6) |
| Shear diagnostics | $T_s$, $T_b$, $\mu_6(a,b)$ | this document §6.6–6.7 | none; SG-R4 blocks export |
| Ontology note | recognition = comparison; existence = relational | OFN / ontology thread | SG-R1: witness citation via §6.9 export interface only |
| Discrete (TDR-G) | $\mathcal D_k$, $N/2$ band | Discrete Genesis DSN | SG-R5: no import either way |

<!-- AI_CONTEXT_CORE_END -->

---

## §5. High-Risk Claims Ledger {#sec-5-high-risk}

| Claim | Valid form | Forbidden overclaim | Scope section |
|---|---|---|---|
| "Difference is recognised only by returning" | Intrinsic *spectral* comparison of a non-fixed history needs closed transport `[ALG]` | closure is a prerequisite of all recognition (comparator $C(r,T^nr)$ exists at every $n$) | §6.2, §6.5 |
| $\chi_6=1+\mu_6Q$ is origin-free | distinction-anchored at the zero-distinction state $\mathcal O_0=0$ `[ALG consequence]` | torsor-free comparison on the full state space | §6.2 |
| Comparator sign | $\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ under the Genesis $J_Q$ `[ALG]` | $+i$ pairing with $\overline W_aW_b$ (v0.1 error) | §6.1, SG-R9 |
| Cubic-return rigidity | $|\mu_6(a,b)|\ge\tfrac12$ on the real shear-jet family with radial row $-\sin\eta$ `[ALG]` | rigidity for other radial rows, other $p$, or outside the jet family | §6.7 |
| Eigenphase $\pi/3$ | linear resonance signature of the selected $T$ `[ALG]` | derivation of phase or of $p=6$ | §6.2 |
| $\operatorname{Fix}(T)=\{\widehat C_{\rm pole}=\pm1\}$ | exact, but built into $T$ via $\rho'-\rho=-\sin\eta$ `[ALG]` | independent evidence for the intersection principle | §6.5 |
| Healing from symmetry breaking | one route ($4a^2$ term); swap-symmetric $\tanh$ shear also heals `[ALG]` | "the arrow of history originates in swap breaking" | §6.7 |
| $\Im\mu_6/\Im\mu_6^{(s)}=4$ | Taylor-jet combinatorics of $(a,b)=(\tfrac12,\tfrac16)$ `[ALG]` | a structural $\mathbb Q(\sqrt3)$ mystery; an additive decomposition of the plateau-memory coefficient $\tau$ | §6.7, §6.8 |
| $Q_c$ protection | local, crossing-step, sufficient `[ALG]` | no-erasure theorem | SG-R8 |
| Antipode $=$ recognition | $\widehat C=-1$ is the unique nontrivial swap-fixed value; an event candidate `[ALG consequence]` | definition of recognition | §6.3, §6.5 |
| $\mu_p=0$ | cubic-silent; recognition order moves to degree 5 `[DEF]` | "recognitionless substrate" | OPEN R2 |
| $p=8$ zero degeneracy | belongs to the $q=4,(0,3)$ strobe channel only | $\mu_8=0$ | OPEN R2 |

---

## §6. Main Scientific Ledger {#sec-6-ledger}

### §6.1 Comparators `[ALG consequence / mixed]` {#sec-6-1-comparators}

> **[Local guard SG-R2]** Pole and state comparators are distinct; name the comparator in every antipode statement.

`[DEF]` **Pole comparator.** For a single dyad with relative phase $\eta$, $C_{\rm pole}(A,B)=e^{i\eta}$. Pole swap $A\leftrightarrow B$ sends $\eta\mapsto-\eta$, hence $C_{\rm pole}\mapsto C_{\rm pole}^{-1}$.

`[DEF]` **State comparator.** In the canonical eigenframe $W=\rho+\omega\eta$, $\omega=\tfrac12(-1+i\sqrt3)$ (Dyadic §6.2), for two dyad states $a,b$:
$$C_\to(a,b):=\overline W_aW_b.$$
The arrow marks the orientation: $C_\to(a,b)$ compares $a$ *to* $b$, so that the diagonal specialisation $b=F(a)$ gives $W'/W$ (§6.2).

`[ALG consequence]` [import: Genesis §6.1 ($B$, $Q=r^\top Br$, $A^\top BA=B$), Genesis §6.6 ($I_{ab}$, $\omega_{ab}$, $J_Q=\tfrac{1}{\sqrt3}\begin{psmallmatrix}1&-2\\2&-1\end{psmallmatrix}$, $a^\top BJ_Qb=+\tfrac{\sqrt3}{2}\omega_{ab}$)] [cert: `recog_shear_jet_cert.py` checks (10)] Since $|W|^2=\rho^2-\rho\eta+\eta^2=r^\top Br$ exactly, polarisation gives
$$C_\to(a,b)=a^\top Bb-i\,a^\top BJ_Qb=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab},\qquad W_a\overline W_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}.$$
$C_\to$ is the conjugate orientation of the Genesis $+$ pairing. `[COR]` v0.1 stated $\overline W_aW_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}$; the sign was wrong. See Appendix B, RID: RECOG-DEF-COMPARATOR-SIGN-V01.

`[ALG]` [RID: RECOG-ALG-INVARIANT-FORM] [cert: check (11)] **Invariant-form uniqueness.** With $A=\begin{psmallmatrix}1&-1\\1&0\end{psmallmatrix}$, the linear system $A^\top HA=H$ on symmetric $2\times2$ matrices has the one-dimensional solution space $H=cB$; positive definiteness gives $c>0$. The scale cancels in every ratio below. `[RESULT]` `[from: ALG]` $C_\to$ is the canonical local comparator induced by the $p=6$, $P_1$ linear transport $A$ — up to scale, and up to complex conjugation until the $J_Q$ sign branch is fixed (SG-R9). No global transport-invariance of $C_\to$ over the nonlinear state space is claimed.

`[ALG consequence]` **Normalised comparator and swap.**
$$\widehat C(a,b)=\frac{C_\to(a,b)}{\sqrt{C_\to(a,a)C_\to(b,b)}}=e^{i\theta_{ab}}\in U(1),\qquad \widehat C(b,a)=\overline{\widehat C(a,b)}=\widehat C(a,b)^{-1}.$$
Here $\theta_{ab}=\arg W_b-\arg W_a$ in the $C_\to$ orientation (SG-R9). [scope: $\widehat C$ is defined only for $Q_aQ_b>0$; $C_\to$ itself is defined at the zero-distinction state, $\widehat C$ is not.]
Swap-fixed values: $z=z^{-1}\iff z=\pm1$. $+1$ is the identity comparison; $-1$ is the unique nonidentity swap-fixed comparison. This characterisation is purely algebraic and needs no metric notion of "maximal distinction" (which remains an OFN interpretation).

`[ALG consequence]` **Two-coordinate comparison.** $C_\to(a,b)/C_\to(a,a)=\sqrt{Q_b/Q_a}\,e^{i\theta_{ab}}$; the natural comparison output is the dimensionless pair $(Q_b/Q_a,\ \Delta\theta_{ab})$.

`[HEUR]` The ratio appears here as the output of the comparison form, not as a primitive. This is *not* evidence that ratio precedes difference (Number Genesis guard); it is evidence that closed self-comparison is dimensionless.

### §6.2 Return Defect and the Six-Step Multiplier `[ALG / mixed]` {#sec-6-2-return}

`[DEF]` **Resonant return germ, return defect, return order.** Let $F$ have a fixed point $x_*$ at which $DF^p(x_*)=I$ for some $p$ (a resonant return germ). Define $D_p:=F^p-\mathrm{id}$; its first nonzero homogeneous term (modulo near-identity conjugacy) is the return defect and its degree is $k_{\rm ret}(p)$, with $k_{\rm ret}=\infty$ if $D_p$ vanishes to all orders. $D_n=F^n-\mathrm{id}$ is definable for every $n$; what the resonance condition supplies is a tangent-to-identity return, so that the leading term of $D_p$ is a formal invariant. `[COR]` v0.1 defined $D_\gamma$ over an "exact closed history"; the central object $T^6$ is not a nonlinear closed history off $P_1$. See Appendix B, RID: RECOG-DEF-RETURN-DEFECT-V01. The leading term $J_{k_{\rm ret}}$ is the formal invariant of a tangent-to-identity map under near-identity changes; its magnitude is convention-dependent under linear rescaling $W\mapsto cW$ (the vanishing/non-vanishing and, at fixed orientation convention, $\arg\mu$ and the radial/angular ratio are robust).

`[ALG]` [import: Dyadic §6.7 | DYAD-THM-C21] For $p=6$ the six-step quadratic part vanishes identically (master parity lemma), the cubic residual collapses to the resonant $(2,1)$ channel, and
$$T^6(W)=W+\mu_6|W|^2W+O(|W|^5),\qquad \mu_6=-\tfrac12-i\tfrac{2\sqrt3}{3},\qquad k_{\rm ret}(6)=3.$$

`[ALG consequence]` **Recognition multiplier.** With $b=T^6a$ in §6.1,
$$\chi_6(W):=\frac{C_\to(W,T^6W)}{C_\to(W,W)}=\frac{W'}{W}=\sqrt{\tfrac{Q'}{Q}}\,e^{i\Delta\Theta}=1+\mu_6Q+O(Q^2),$$
consistent with the certified laws $Q'=Q-Q^2+\cdots$, $\Delta\Theta=-\tau Q+\cdots$ (Dyadic §6.8). $\arg W=\Theta$ (ISP) exactly. The one-step eigenvalue $\lambda$ is the linearised special case $R(v)=\lambda v\Rightarrow R(v)/v=\lambda$; at the recognition cycle $\lambda^6=1$ and the linear spectrum carries no information — the content is in $J_3$.

`[ALG]` **Local exact statements.** $Q=0\Rightarrow\chi_6=1$. For $0<Q<\epsilon$: $|\chi_6|=1-\tfrac12Q+O(Q^2)<1$, hence $\chi_6\ne1$ and $T^6$ has no fixed point other than $P_1$ in the punctured sector. Depends on: [import: RTG_NUMBER_GENESIS_DSN_v1.15 | NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION] $Q_{\rm true}(Fx)-Q_{\rm true}(x)=-Q_{\rm true}^2+O(Q_{\rm true}^{5/2})$ with phase-uniform strict contraction on a sufficiently small punctured sector. See §7. Substrate statement: $Q=0\Rightarrow D_6=0$; $0<Q<\epsilon\Rightarrow T^6x\ne x$ with nontrivial return defect. Any reading of this as a witness for an ontological thesis is made in the ontology note, not here (§6.9).

`[ALG]` **Distinction anchoring.** $\chi_6$ compares $W$ with $T^6W$ relative to $W=0$, i.e. relative to the zero-distinction state $\mathcal O_0=0$ of Genesis §6.1 — not relative to an external origin. The definition is *distinction-anchored*, not origin-free; a genuine torsor difference on the state space would use only the phase/winding gauge, which is invisible to the dynamics (Dyadic §6.4) and hence empty.

`[ALG]` **Phase readability.** Phase structure exists at linear order ($\lambda=e^{i\pi/3}$); a *self-readable* phase defect first appears at cubic order, multiplied by amplitude: $\arg\chi_6=-\tau Q+O(Q^2)$. Phase is not created by $Q$; its self-recognition residue opens with $Q$.

`[ALG]` The resonance prerequisite is arithmetic: a tangent-to-identity return $DF^p=I$ exists only for rational rotation number. `[HEUR]` For an irrational-rotation germ no finite $p$ gives a resonant return, so $k_{\rm ret}$ is undefined (not $\infty$); $D_n$ and the comparison $C_\to(r,T^nr)$ nonetheless exist at every $n$. Finite resonance is therefore the prerequisite of finite *self-calibration*, not of comparison as such.

### §6.3 Fixed Points, Antipode, and Swap Structure `[ALG / mixed]` {#sec-6-3-fixed-swap}

`[ALG]` [import: Dyadic §6.1] $\rho'=\rho\Rightarrow\sin\eta=0$; then $\eta'=\eta\Rightarrow e^\rho=1$. Hence on the wrapped phase $\operatorname{Fix}(T)=\{P_1=(0,0),P_2=(0,\pi)\}$, with $P_1$ elliptic ($e^{\pm i\pi/3}$) and $P_2$ hyperbolic ($\phi^{\pm2}$).

`[ALG consequence]` $P_1:\ \widehat C_{\rm pole}=+1$; $P_2:\ \widehat C_{\rm pole}=-1$. The two stationary states are exactly the two swap-fixed pole comparisons. This is a consequence of the radial row being $-\sin\eta$ (§6.4), not an independent coincidence; see §5.

`[ALG]` **Fiber antipode vs state antipode.** $A^3=-I$ reverses a tangent perturbation at $P_1$ (fiber antipode, linear order); $P_2$ is the state-space antipode of the pole comparison and carries no cyclic return (real multipliers). These are distinct objects; "recognition at the antipode" must specify which. `[DEF]` Two candidate recognition classes: *recurrence recognition* (self-comparison along a closed history, realised near $P_1$) and *encounter recognition* (cross-comparison of two co-present relations, realised by $C_\to(r_a,r_b)$ at state level and by the $P_2$ pole configuration at pole level).

### §6.4 Radial Parity and the Selection Lemma `[ALG conditional / mixed]` {#sec-6-4-selection}

`[HYP]` **Pole-swap covariance.** The primitive relational description is covariant under $A\leftrightarrow B$.

`[ALG conditional]` [assumes: pole-swap covariance; certified $A=DT(P_1)$] Write $\rho'=\rho+f(\eta)$. If $\rho$ were swap-even, covariance gives $f(-\eta)=f(\eta)$, hence $f'(0)=0$; but $A$ has radial entry $f'(0)=-1$. Therefore $\rho$ is swap-odd: $S_o(\rho,\eta)=(-\rho,-\eta)$, and $\operatorname{Fix}(S_o)=\{(0,0),(0,\pi)\}=\operatorname{Fix}(T)$ exactly, although $T$ is not $S_o$-equivariant (§6.6). Under swap-even $\rho$ the minimal covariant radial forcing would be $\propto\cos2\eta-1=-2\sin^2\eta$: sign-definite drift, no elliptic $P_1$.

`[ALG conditional]` [RID: RECOG-ALG-SELECTION-SIN] [assumes: pole-swap covariance with $\rho$ odd; $2\pi$-periodicity; stationarity on the swap-fixed strata $f(0)=f(\pi)=0$; lowest nonzero Fourier harmonic] $f(\eta)=a_1\sin\eta$; with orientation/normalisation $a_1=-1$, the radial row of $T$ is recovered. The lemma selects the functional form only; it does not derive the coefficient, and it does not select the shear $g(\rho)$ (any odd $g$ with $g'(0)=1$ is admissible: $\rho$, $\sinh\rho$, $\tanh\rho$, …).

`[RESULT]` `[from: ALG conditional]` The stationarity of $P_1,P_2$ is thereby reframed from an observed coincidence into a generator-construction criterion: swap-special relational states $\Rightarrow$ stationarity $\Rightarrow f(0)=f(\pi)=0\Rightarrow f_{\min}\propto\sin\eta$. This is a candidate derivation for the first row of OFN §6.2a ("why does phase opposition change radial separation"), tagged conditional.

### §6.5 Candidate Mathematical Strata and the Prerequisite Ladder `[DEF / mixed]` {#sec-6-5-strata}

> **[Local guard SG-R3]** One-step Jacobian type is chart-dependent off fixed points; only rank is pointwise intrinsic.

`[DEF]` **Three candidate strata.** These are mathematical loci of the comparator/transport geometry; whether any of them is a physical *event* is OPEN R6 (SG-R6).

| Stratum | Intrinsic object | Prerequisite | Dyad realisation |
|---|---|---|---|
| rank stratum | $\operatorname{rank}DF_x$ | one present state | $C_0=\{\rho\ge\ln2,\ \cos\eta=-1/(e^\rho-1)\}$ |
| pair-symmetry stratum, pole level | $\widehat C_{\rm pole}=\pm1$ | primitive co-presence of $A,B$ (always given in a dyad) | $P_1$ ($+1$), $P_2$ ($-1$) |
| pair-symmetry stratum, state level | $\widehat C(a,b)=\widehat C(b,a)$, i.e. $\widehat C=\pm1$ (domain $Q_aQ_b>0$) | co-present states/modes, or retained self-comparison data | $C_\to(r_a,r_b)$; $A^3=-I$ (fiber level) |
| loop/spectral stratum | $(t_n,d_n)=(\operatorname{tr}M_n,\det M_n)$, $\Delta_n=t_n^2-4d_n$, multiplier $\pm1$ loci $t_n=\pm(1+d_n)$ | closed transport $F^n(x)=x$ | $P_1$ ($t=1,d=1$), $P_2$ ($t=3,d=1$); no other period-6 points near $P_1$ |

`[ALG]` The map is non-symplectic (Dyadic §6.1), so the loop stratum lives in the $(t,d)$-plane; the classical $\operatorname{tr}=\pm2$ criterion holds only on the $d=1$ slice.

`[ALG]` [scope: primitive chart] **Discriminant.** With $c=\cos\eta$: $\operatorname{tr}J=2-c$, $\det J=1+(e^\rho-1)c$, $\Delta_J=c(c-4e^\rho)$. For $\rho>-\ln4$ the sign is $-\operatorname{sign}(c)$: rotational transport for $\cos\eta>0$, stretching for $\cos\eta<0$; the zero locus has the second branch $\cos\eta=4e^\rho$ only for $\rho\le-\ln4$. On $\cos\eta=0$: $\det J=1$, $\Delta_J=0$, $J=\begin{pmatrix}1&0\\e^\rho&1\end{pmatrix}$ — a nontrivial unipotent matrix in the primitive chart. No intrinsic conjugacy-class statement is made off the fixed points (SG-R3). `[OPEN]` intrinsic counterpart: OPEN R4.

`[ALG consequence]` **Pair-symmetry is pairwise, not pointwise.** $\widehat C=-1$ is a property of a pair. At pole level the pair $A,B$ is primitively co-present, so the pole stratum needs no history. At state level a past comparison partner is not automatically part of the present state: [import: RTG_NUMBER_GENESIS_DSN_v1.15 N-1C | NUMGEN-OPEN-N1C] the wrapped-$S^1$ negative control shows that a memoryless wrapped state collapses same-endpoint histories, while the later local primitive-dyad result shows history non-collapse when relational data are retained. Hence state-level self-comparison requires either explicitly retained relational memory/interface data or a current co-realisation; the carrier $U(1)$ being closed is not a dynamical closure. `[COR]` v0.1 overstated the negative control as "a past state is not physically present". See Appendix B, RID: RECOG-DEF-COPRESENCE-V01.

`[HYP]` [RID: RECOG-OPEN-INTERSECTION] **Intersection principle** (registered under OPEN R6). Recognition event $=$ (nontrivial algebraic comparison stratum) $\cap$ (dynamically distinguished stratum). Realised by $P_2$: $\widehat C_{\rm pole}=-1$, $T(P_2)=P_2$, $\operatorname{spec}DT_{P_2}=\{\phi^2,\phi^{-2}\}$. In the dyad the coincidence is built in: $\operatorname{Fix}(T)\subset\{\sin\eta=0\}$ by construction of the radial row. The principle may therefore be used as a *derivation target* for that row (§6.4), not as a fact derived from $T$.

`[RESULT]` `[from: ALG]` Prerequisite ladder: rank and pole-level pair-symmetry need no history; state-level pair-symmetry needs co-presence or retained comparison data; the spectral stratum needs closed transport. Closure is the prerequisite of the spectral stratum only, not of all recognition.

`[HEUR]` Candidate mathematical essence of a recognition event: *failure of continuation within the current equivalence class* — a jump in rank, stabiliser/symmetry, conjugacy class or return normal form — rather than any change of a comparison value. Generic small motion changes $C$ without leaving its stratum and is not an event (SG-R6).

### §6.6 Swap-Projection Decomposition `[ALG]` {#sec-6-6-swap-projection}

> **[Local guard SG-R4]** Twins are diagnostic; no export.

`[ALG]` [RID: RECOG-ALG-SWAP-SPLIT] With $S_o=-I$, the odd and even projections of $T$ are exact:
$$T_s(x)=\tfrac12\bigl(T(x)-T(-x)\bigr)=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta),\qquad T_b(x)=\tfrac12\bigl(T(x)+T(-x)\bigr)=(0,\ \cosh\rho-1),$$
$T=T_s+T_b$. Equivalently $T\circ S_o-S_o\circ T=(0,\,2(\cosh\rho-1))=(0,\rho^2+O(\rho^4))$: $T$ is swap-equivariant at linear order and breaks swap symmetry first at quadratic order. $T_b$ is the *only* quadratic term of the primitive one-step jet; consequently the certified quadratic normal-form coefficients $c_{20},c_{11},c_{02}$ (Dyadic §6.2) are entirely sourced by the symmetry-breaking term.

`[ALG]` In ratio language $r=e^\rho$: $e^\rho-1=r-1$ (one-sided ratio drive), $\sinh\rho=\tfrac12(r-r^{-1})$ (reciprocal-antisymmetrised ratio drive), $\rho=\log r$ (log-ratio drive). $T_s$ is the reciprocal-symmetric twin, not the log twin.

`[ALG diagnostic]` **Twin rank stratum.** $\det J_s=1+(\cosh\rho-1)\cos\eta$; critical locus $\cos\eta=-1/(\cosh\rho-1)$, $|\rho|\ge\operatorname{arccosh}2$: two symmetric branches, versus the one-sided $C_0$ ($\rho\ge\ln2$) of $T$. The one-sidedness of the rank event is sourced by $T_b$.

### §6.7 Shear-Jet Law and Radial Fate `[ALG / mixed]` {#sec-6-7-shear-jet}

`[ALG]` [RID: RECOG-ALG-SHEAR-JET] [cert: `recog_shear_jet_cert.py` checks (1)–(7), (9) → CERTIFICATE PASS; two independent derivations] For the family
$$T_{a,b}(\rho,\eta)=\bigl(\rho-\sin\eta,\ \eta+g(\rho)-\sin\eta\bigr),\qquad g(\rho)=\rho+a\rho^2+b\rho^3+O(\rho^4),$$
the six-step quadratic part vanishes identically and the cubic residual is confined to the $(2,1)$ channel for all real $(a,b)$, with
$$\mu_6(a,b)=3b-4a^2-i\sqrt3\left(\tfrac13+2a^2-b\right).$$
Checks: $(a,b)=(\tfrac12,\tfrac16)$ reproduces DYAD-THM-C21 exactly.

`[ALG diagnostic]` **Instances.**

| shear $g$ | $(a,b)$ | $\mu_6$ | $\Re\mu_6$ | radial fate | swap |
|---|---|---|---|---|---|
| $\rho$ (log) | $(0,0)$ | $-i\sqrt3/3=-i\tau/2$ | $0$ | neutral at cubic order | odd |
| $\sinh\rho$ | $(0,\tfrac16)$ | $\tfrac12-i\sqrt3/6$ | $+\tfrac12$ | expansion | odd |
| $\tanh\rho$ | $(0,-\tfrac13)$ | $-1-i\,2\sqrt3/3$ | $-1$ | healing | odd |
| $e^\rho-1$ (primitive) | $(\tfrac12,\tfrac16)$ | $-\tfrac12-i\,2\sqrt3/3$ | $-\tfrac12$ | healing | broken |
| $(e^{\kappa\rho}-1)/\kappa$ | $(\tfrac\kappa2,\tfrac{\kappa^2}6)$ | $-\tfrac{\kappa^2}{2}-i\tfrac{\sqrt3}{3}(1+\kappa^2)$ | $-\tfrac{\kappa^2}{2}$ | healing for all $\kappa\ne0$ | broken |

`[ALG]` $\mu_{\rm break}:=\mu_6-\mu_6^{(s)}=-1-i\tfrac{\sqrt3}{2}$ is the quadratic symmetry-breaking-mediated contribution (since $T$ and $T_s$ share linear and cubic primitive jets). $\Im\mu_6/\Im\mu_6^{(s)}=4$ exactly, explained by $(\tfrac13+\tfrac12-\tfrac16)/(\tfrac13-\tfrac16)$; no deeper structural reason is claimed.

`[RESULT]` `[from: ALG]` **Radial-fate law.** $\Re\mu_6=3b-4a^2$: healing $\iff4a^2>3b$, neutral $\iff4a^2=3b$, expansion $\iff4a^2<3b$. Two independent routes to healing exist — quadratic swap breaking ($a\ne0$) and a negative cubic contribution ($b<0$). The primitive exponential shear heals because $-4a^2=-1$ overcomes $+3b=+\tfrac12$. Symmetry breaking *reverses* the outward drift of the $\sinh$ twin; it does not create directedness, and it is not necessary for healing ($\tanh$ counterexample).

`[ALG]` [RID: RECOG-ALG-CUBIC-RETURN-RIGIDITY] [cert: checks (8)] **Cubic-return rigidity.** For every real $(a,b)$,
$$\boxed{|\mu_6(a,b)|^2=12\Bigl(b-\tfrac32a^2-\tfrac1{12}\Bigr)^2+\tfrac14\bigl(2a^2+1\bigr)^2\ \ge\ \tfrac14},$$
with equality only at $(a,b)=(0,\tfrac1{12})$. Hence $\mu_6(a,b)\ne0$ on the whole family and, with the universal quadratic cancellation and $(2,1)$ confinement above, $k_{\rm ret}(6)=3$ for every member. Depends on: radial row fixed as $\rho'=\rho-\sin\eta$; real $(a,b)$. `[COR]` v0.1 asserted an imaginary "residue floor" $\Im\mu_6\le-\tau/2$; false ($\Im\mu_6^{(s)}=-\tau/4$). Replaced by this modulus bound. See Appendix B, RID: RECOG-ALG-IM-FLOOR-V01.

`[ALG consequence]` [RID: RECOG-ALG-FATE-BOUNDARY] [cert: checks (12)–(13)] **Radial-fate boundary corollary.** On $4a^2=3b$ the law reduces to $\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$: $\Re\mu_6=0$ but $|\mu_6|\ge1/\sqrt3$. The healing/expansion transition therefore does not coincide with loss of return content — radial fate changes class while $k_{\rm ret}$ is unchanged and a purely angular residue survives. At the rigidity minimiser, $\mu_6(0,\tfrac1{12})=\tfrac14-i\tfrac{\sqrt3}{4}=\tfrac12e^{-i\pi/3}$.

`[RESULT]` `[from: ALG]` The return-defect *order* is rigid across the shear-jet family; the return *content* ($\arg\mu$, $\Re\mu$) and hence the radial fate are shear-selected. $J_3$ may be called a mathematical recognition residue under SG-R6; no physical recognition-event order is asserted. To delay the first return defect beyond cubic order one must leave this family or change the resonance horizon $p$ (CELL-A). `[HEUR]` Whether the healing instances share a large-$|\rho|$ "saturation" feature is not decidable from the cubic jet ($e^\rho-1$ is unbounded as $\rho\to+\infty$); see OPEN R5.

`[HEUR]` [scope: SG-R8, OPEN R7] In $T$, healing keeps small $Q$ below $Q_c$ and away from $C_0$; in $T_s$ small distinctions grow toward larger amplitudes where the symmetric rank locus may become accessible. "Symmetric twin runs into erasure" is **not** certified (global accessibility open).

### §6.8 Comparison – Event – Memory Mapping `[ALG consequence]` {#sec-6-8-three-layers}

`[ALG consequence]` Three certified dyadic objects realise three distinct layers:

| Layer | Object | Source |
|---|---|---|
| comparison | $C_\to(a,b)=\overline W_aW_b$ | §6.1 (Genesis §6.1, §6.6) |
| closure defect | $T^6W-W=\mu_6|W|^2W+\cdots$ | Dyadic §6.7 |
| persisted memory | $\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ | Genesis §6.6 plateau shear bridge `[ALG structure]` |

Recognition $\ne$ closure defect $\ne$ memory (SG-R6). `[ALG]` Three quarters of the primitive *local cubic angular return coefficient* is symmetry-breaking-mediated ($\Im\mu_6^{(s)}=\tfrac14\Im\mu_6$); no additive decomposition of the asymptotic plateau-memory law is claimed, since that law also uses the healing radial backbone, which the expansive twin does not share. `[HYP]` (SG-R1) These are successive layers of one relational geometry.

### §6.9 Ontology Export Interface `[DEF]` {#sec-6-9-export}

> **[Local guard SG-R1]** Witness citations only; no promotion.

`[DEF]` The ontology note (OFN / relational-existence thread) may cite the following RECOG objects as substrate witnesses, each with its tag and scope carried verbatim:
- $C_\to$ comparator structure and the swap-fixed set $\widehat C=\pm1$ (§6.1, SG-R9)
- $k_{\rm ret}(6)=3$ and the recognition multiplier $\chi_6$ (§6.2)
- cubic-return rigidity RECOG-ALG-CUBIC-RETURN-RIGIDITY (§6.7)
- radial-fate law $4a^2\gtrless3b$ (§6.7)
- candidate strata and prerequisite ladder (§6.5), as *candidates*

All interpretive statements formerly listed here ("existence $=$ recognisability", "physics at the intersection of compatible structures", "closure is arithmetic, defect geometric, recognition comparison") are moved to the ontology note as `[HYP]` and are not part of this ledger.

---

## §7. Import Ledger {#sec-7-imports}

- [RID: DYAD-THM-C21] :: $\mu_6=c_{21}=-\tfrac12-i\tfrac{2\sqrt3}{3}$ :: RTG_DYADIC_OSCILLATOR_DSN_v6.4.9 §6.2, §6.7 :: return defect, jet-law anchor :: p=6, K=1, conditional on postulated $T$
- [RID: DYAD-ALG-P6-FACEFLUX] :: $\lambda=e^{i\pi/3}=e^{iF_f/2}$ :: Dyadic §6.2 :: linear resonance signature; not used for derivation :: p=6 only
- [RID: DYAD-ALG-BRIDGE-LEMMA] :: $\mu_p=p\bar\lambda\nu_3^{(1,p)}$ :: Dyadic §6.2 / Genesis §6.2 :: CELL-A target :: normalised one-step frame
- [RID: (none — §6.1 block)] :: dyad map, $J$, $\det J$, $C_0$, $P_1,P_2$, escape law, non-symplecticity :: Dyadic §6.1 :: fixed points, rank stratum, $(t,d)$-plane :: primitive layer
- [RID: (none — §6.4 block)] :: $Q_c=(\arcsin\ln2)^2$, winding-index invisibility, ISP $\Theta$ :: Dyadic §6.4 :: SG-R8, distinction anchoring, $\arg W=\Theta$ :: crossing-step local
- [RID: (none — §6.7/§6.8 block)] :: $M+M^\top=-I$, $Q_{m+1}=Q_m-Q_m^2+\cdots$, $\Theta_{m+1}=\Theta_m-\tau Q_m$ :: Dyadic §6.7–6.8 :: $\chi_6$ reconstruction :: cubic-vector truncation
- [RID: (none — Genesis §6.1)] :: $\mathcal O_0=0$, first dyad $A+B=0$, $B$, $Q=r^\top Br$, $A^\top BA=B$ `[THM]` :: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.1 :: comparator construction, distinction anchoring :: p=6 eigenframe
- [RID: (none — Genesis §6.6)] :: $I_{ab}$, $\omega_{ab}$, $a^\top BJ_Qb=\tfrac{\sqrt3}{2}\omega_{ab}$, plateau phase memory :: Genesis §6.6 :: cross-comparison, memory layer :: phase convention as declared there
- [RID: NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION] :: $Q_{\rm true}(Fx)-Q_{\rm true}(x)=-Q_{\rm true}^2+O(Q_{\rm true}^{5/2})$; phase-uniform strict contraction on a small punctured sector :: RTG_NUMBER_GENESIS_DSN_v1.15 :: §6.2 local exactness; absence of nearby period-6 points :: local, p=6, conditional on $T$ (RID corrected at critique round 2; `NUMGEN-N1C-DYAD-RADIAL` names the downstream Radial Memory Test, not this theorem)
- [RID: NUMGEN-OPEN-N1C] :: wrapped-$S^1$ negative control (memoryless wrapped state collapses same-endpoint histories) and local primitive-dyad history non-collapse :: RTG_NUMBER_GENESIS_DSN_v1.15 N-1C (closed) :: §6.5 co-presence refinement :: negative control is scoped to the memoryless wrapped state; not a universal statement (confirmed at critique round 2)
- [RID: (none — Genesis §6.6 $J_Q$)] :: $J_Q=\tfrac1{\sqrt3}\begin{psmallmatrix}1&-2\\2&-1\end{psmallmatrix}$, $J_Q^\top BJ_Q=B$, $J_Q^2=-I$, sign branch fixed by convention :: Genesis §6.6 :: comparator orientation, SG-R9 :: branch-dependent sign; load-bearing properties branch-independent
- [RID: OFN §6.2a, §7.3] :: open rows "why $\sin\eta$", "why exponential shear"; TDR-G band $k$ underived :: RTG_ONTOLOGICAL_FOUNDATIONS_v0.7 :: export targets for §6.4, OPEN R5 :: motivational layer, no derivation imported

RIDs marked "(none)" have no stable identifier in the source; requesting assignment there is part of the critique round.

---

## §8. Artifact and Script Registry {#sec-8-artifacts}

- [RID: RECOG-ART-SHEAR-JET-CERT] :: `recog_shear_jet_cert.py` (sha256 `e1d2444f9d8d8c940270d73df4ca20d0323504d93f89dbb2fe6da1a9a3fe48a4`) :: exact sympy six-step cubic composition with exact $\omega=\tfrac12(-1+i\sqrt3)$; 18 checks: DYAD-THM-C21 reproduction (parametrised and direct), $T_s$ (parametrised and direct), $T_{\log}$, $T_{\tanh}$, general $\mu_6(a,b)$, quadratic vanishing, $(2,1)$ confinement, completed-square rigidity and its minimum, comparator orientation, Genesis $J_Q$ properties, invariant-form uniqueness, radial-fate boundary corollary, rigidity minimiser; exit 0 on PASS :: `[ENG]` (scientific claims carry their own `[ALG]` tags in §6)
- [RID: RECOG-ART-CELL-A] :: `recog_cell_a_nu3.py` :: planned; $(2,1)$ normalised row export for $p=5,6,7$ :: `[OPEN]`
- [RID: RECOG-ART-CELL-B] :: `recog_cell_b_p2_manifolds.py` :: planned; $W^{u,s}(P_2)$ and first intersection with $C_0$ :: `[OPEN]`

---

## §9. Collaboration and Provenance {#sec-9-provenance}

**Contributors.** Mustafa (PI; ontological thesis, ratio/comparison emphasis, physics–mathematics coincidence stance) · Claude (this draft; independent certificate) · Collaborating AI contributor (spectral/return-defect formulation, swap-projection twin, shear-jet law first derivation; critique round pending).
**Archive.** none yet; to be registered with the ontology note.

| Insight | Provenance | Tag |
|---|---|---|
| Recognition framework shifted from eigenvalue to comparator + return-defect structure | contributor | `[DEF]` |
| $C(a,b)=\overline W_aW_b$ from Genesis definitions | Claude | `[ALG consequence]` |
| Only rank is pointwise chart-free; prerequisite ladder | Claude | `[ALG]` |
| Antipode as unique nontrivial swap-fixed value | Claude (swap), contributor (formalisation) | `[ALG consequence]` |
| $\rho$ swap-odd from certified $A$ | Claude ($\sin^2\eta$ route), contributor ($f'(0)$ route) | `[ALG conditional]` |
| $T=T_s+T_b$, $\mu_6^{(s)}$, $\mu_{\rm break}$ | contributor (derivation), Claude (verification) | `[ALG]` |
| Shear-jet law $\mu_6(a,b)$ | contributor (derivation), Claude (verification) | `[ALG]` |
| $\tanh$ counterexample | Claude | `[ALG]` |
| Comparator sign correction; cubic-return rigidity $|\mu_6|\ge\tfrac12$; return-germ redefinition; Number Genesis provenance; strata/ladder refinement | contributor (critique round 1) | `[ALG]` / `[DEF]` |
| Invariant-form uniqueness $H=cB$ | contributor (suggested), Claude (certificate) | `[ALG]` |
| Radial-fate boundary corollary; rigidity minimiser $\tfrac12e^{-i\pi/3}$; Number Genesis RID correction; wording/domain fixes | contributor (critique round 2) | `[ALG consequence]` |
| Event = class change; intersection principle | contributor / Mustafa (stance) | `[HYP]` (OPEN R6) |

---

## Appendix A — Version History

### v0.2.1 — September 2026 (pre-freeze patch, critique round 2)
- **§7 [import]:** Number Genesis contraction import corrected to `NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION`; `NUMGEN-OPEN-N1C` confirmed; verification notes removed.
- **§0 [governance]:** `RECOG` prefix and Programme Overview Tier 3 (Maturity A) registration made part of this release.
- **§0, §1, §6.7 [wording]:** "recognition order is rigid" → "return-defect order is rigid" (SG-R6 consistency).
- **§6.7 [ALG consequence]:** RECOG-ALG-FATE-BOUNDARY added ($4a^2=3b\Rightarrow\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$); rigidity minimiser recorded as $\tfrac12e^{-i\pi/3}$.
- **§6.1, §6.5 [scope]:** $\widehat C$ domain $Q_aQ_b>0$ stated; comparator intrinsicness narrowed to the $P_1$ linear transport; "largest difference that remains mutual" removed.
- **§6.7 [wording]:** "saturating odd shear" → "negative cubic contribution".
- **§6.2 [SG-R1]:** ontological witness sentence removed; only the substrate statement remains.
- **§9:** stale provenance line updated.
- **§8 [ENG]:** certificate extended to 18 checks; new sha256.

### v0.2 — September 2026
- **§6.1 [COR → ALG consequence]:** comparator sign corrected: $\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ under the Genesis $J_Q$; comparator renamed $C_\to$ with explicit orientation; SG-R9 added.
- **§6.1 [ALG]:** RECOG-ALG-INVARIANT-FORM added (symmetric $A$-invariant forms are exactly $cB$), replacing the imported-as-fact wording.
- **§6.2 [COR → DEF]:** return defect redefined on the resonant return germ ($DF^p=I$ at the fixed point); $D_n$ definable for all $n$; irrational case gives undefined $k_{\rm ret}$, not $\infty$.
- **§6.2, §6.5, §7 [import]:** Number Genesis v1.15 provenance closed (NUMGEN-N1C-DYAD-RADIAL, NUMGEN-OPEN-N1C); split into two entries; negative control rescoped.
- **§6.5 [DEF]:** "event classes" → "candidate mathematical strata"; pole-level and state-level pair-symmetry separated; intrinsic conjugacy-class wording removed; intersection principle re-registered as RECOG-OPEN-INTERSECTION under OPEN R6.
- **§6.7 [COR → ALG]:** false imaginary residue floor retracted; RECOG-ALG-CUBIC-RETURN-RIGIDITY added ($|\mu_6(a,b)|\ge\tfrac12$, $k_{\rm ret}(6)=3$ across the family).
- **§6.8 [ALG]:** $\tau$ decomposition restricted to the local cubic angular coefficient; no plateau-memory decomposition claimed.
- **§6.9 [DEF]:** replaced by an Ontology Export Interface; interpretive `[HYP]` lines moved to the ontology note.
- **§2 [OPEN]:** R5 renamed "Why one-sided ratio shear?"; saturation demoted to an untestable-by-jet sub-item.
- **Governance:** `[COR-in-advance]` removed; `[ALG consequence]` alias re-expanded to `[RESULT]` `[from: ALG]`; artifact tagged `[ENG]`; non-registry RID categories (`HYP`, `SUP`) replaced; local aliases noted as not requiring methodology registration.
- **§8 [ENG]:** certificate extended to 15 checks (exact $\omega$, rigidity, direct primitive-$T$ control, comparator orientation, invariant-form uniqueness); new sha256.

### v0.1 — September 2026
- **§1–§9 [initial]:** First consolidation of the recognition branch (spectral → return defect → comparator → event strata → shear-jet law) from the September 2026 session into DSN form. All numerical claims of §6.6–6.7 certified by `recog_shear_jet_cert.py`. Import RIDs from Dyadic/Genesis partially unassigned; Number Genesis source citation unconfirmed. Draft for critique.

---

## Appendix B — Retired and Rejected Claims

**[SUPERSEDED | RID: RECOG-DEF-SPECTRAL-RECOG]** "Spectral Recognition Hypothesis": recognition $=$ eigenvalue/eigenphase of the return transport. Replaced by: §6.2 (eigenvalue is the linearised recognition multiplier; content is the first nontrivial return jet). Version: v0.1.

**[SUPERSEDED | RID: RECOG-DEF-CLOSURE-PREREQ]** "Without return the spectrum cannot be compared with itself" as a prerequisite of all recognition. Replaced by: §6.5 prerequisite ladder (closure needed for the spectral stratum only). Version: v0.1.

**[SUPERSEDED | RID: RECOG-ALG-QUADRATURE-GLOBAL]** "$\cos\eta=0$ is the unique type-change surface on the whole plane." Replaced by: §6.5 (second branch $\cos\eta=4e^\rho$ for $\rho\le-\ln4$; chart-dependent in any case). Version: v0.1.

**[SUPERSEDED | RID: RECOG-DEF-BREAK-CAUSES-HEALING]** "Healing is caused by swap-symmetry breaking." Replaced by: §6.7 radial-fate law ($4a^2>3b$; $\tanh$ heals without breaking). Version: v0.1.

**[RETRACTED | RID: RECOG-DEF-COMPARATOR-SIGN-V01]** $\overline W_aW_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}$. Reason: sign error against the certified Genesis $J_Q$ convention; direct algebra gives $-i$. Replaced by: §6.1, SG-R9. Version: v0.2.

**[RETRACTED | RID: RECOG-ALG-IM-FLOOR-V01]** "$\Im\mu_6\le-\tau/2$ across the shear family." Reason: contradicted by $\Im\mu_6^{(s)}=-\tau/4$. Replaced by: RECOG-ALG-CUBIC-RETURN-RIGIDITY (§6.7). Version: v0.2.

**[SUPERSEDED | RID: RECOG-DEF-RETURN-DEFECT-V01]** Return defect defined over an exact closed history $\gamma$. Replaced by: resonant return germ definition, §6.2. Version: v0.2.

**[SUPERSEDED | RID: RECOG-DEF-COPRESENCE-V01]** "By the history-collapse criterion a past state is not part of the present state" (universal reading of the wrapped-$S^1$ negative control). Replaced by: §6.5 scoped statement (retained relational data or current co-realisation). Version: v0.2.

**[SUPERSEDED | RID: RECOG-OPEN-SATURATING-SHEAR]** OPEN R5 framed as "why saturating shear". Reason: $e^\rho-1$ is unbounded for $\rho\to+\infty$; the cubic jet cannot test saturation. Replaced by: RECOG-OPEN-ONESIDED-SHEAR. Version: v0.2.

**[FAIL | RID: RECOG-FAIL-K-FROM-SADDLE]** Derive the antipodal band width $k$ from the $P_2$ saddle spectrum alone. Reason: eigenvalues fix width–lifetime scaling, not width; invariant under local rescaling. Closed: v0.1.

---

*END OF DOCUMENT — RTG_RELATIONAL_RECOGNITION_DSN_v0.2.1*
