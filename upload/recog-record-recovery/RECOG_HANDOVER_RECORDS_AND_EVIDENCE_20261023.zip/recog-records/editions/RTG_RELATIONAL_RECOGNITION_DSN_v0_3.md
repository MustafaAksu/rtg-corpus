# RTG_RELATIONAL_RECOGNITION_DSN_v0.3

**Title:** RTG Relational Recognition Study — Comparators, Return Defect, and Event Strata on the Dyadic Substrate
**Date:** 18 September 2026
**Scope:** Substrate-level mathematics of *recognition* — how a relational distinction is compared with its transported self or with another distinction, what residue a closed history leaves, and which loci of the comparator/transport geometry qualify as candidate recognition events — worked on the postulated continuous dyad generator $T$ and its diagnostic shear twins. Ontological readings are carried as `[HYP]` only.
**Supersedes:** `RTG_RELATIONAL_RECOGNITION_DSN_v0.2.1` (frozen core; extended here) · v0.2 · v0.1
**Companion documents:** `RTG_DYADIC_OSCILLATOR_DSN_v6.4.9` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.4` · `RTG_NUMBER_GENESIS_DSN_v1.15` · `RTG_ONTOLOGICAL_FOUNDATIONS_v0.7` · `RTG_DISCRETE_GENESIS_DSN_v2.12.13` (reference only, no import) · `DSN_METHODOLOGY_v1.2`
**DSN Methodology:** DSN_METHODOLOGY_v1.2
**Programme tier:** Tier 3 — Continuous Programme, downstream of Dyadic and Genesis (see Programme Overview §6). Study prefix `RECOG` is registered with this release: add `RECOG | RTG Relational Recognition` to the DSN_METHODOLOGY RID-prefix table and list the study in Programme Overview Tier 3 at Maturity Level A (downstream diagnostic of Dyadic/Genesis). Both registrations are part of the freeze, not deferred to v1.0.
**Status summary (v0.3):** Settled since v0.2.1: (i) the general resonant-return theorem — for every $p\ge5$ the six-step-type return defect is cubic and confined to $Z^2\bar Z$, with closed form $\nu_3(\lambda)=-\tfrac{\lambda^5-\lambda^4-\lambda^3-2\lambda^2+1}{2(\lambda-1)(\lambda+1)(\lambda^2+\lambda+1)}$ whose numerator has no root on the unit circle, hence $k_{\rm ret}(p)=3$ for the whole $p$-family (OPEN R2 closed); (ii) leading-return equivariance and comparator closure through degree $p-2$, with the first non-comparator channel $\bar W^{p-1}$; (iii) for $p=6$ the certified lattice harmonic $c_{05}\ne0$ yields a lattice-readability clock $m_{k+1}/m_k\to\lambda_{\rm DSI}^{1/6}$ and a finite retained lattice phase memory $\Lambda(Q_0,\Theta_0)$ that is not determined by comparator data (identical comparator data, different retained memory — certified counterexample); (iv) `[NUM strong]` $P_2$ manifold geometry: the positive unstable branch reaches the rank stratum after a $278.66^\circ$ lifted pole excursion crossing $-1\to-i\to+1\to+i$, and the negative branch enters the $P_1$ healing regime within 12 steps from its fundamental domain. Blocked upstream: heteroclinic certification (B2) and finite-$Q_0$ lattice-memory bound (D2b) both wait on one Dyadic deliverable — an explicit local enclosure of the six-step return germ. The recognition-event rule (R6) remains open but now has an operational endpoint.

**Status summary (v0.2.1, retained):** Settled: the state comparator $C_\to(a,b)=\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ is an exact consequence of certified Genesis/Dyadic definitions (conjugate orientation to the Genesis $+$ convention); the six-step return multiplier $\chi_6=1+\mu_6Q+O(Q^2)$ is its diagonal specialisation; the swap-projection decomposition $T=T_s+T_b$, the shear-jet law $\mu_6(a,b)=3b-4a^2-i\sqrt3(\tfrac13+2a^2-b)$, and the cubic-return rigidity $|\mu_6(a,b)|\ge\tfrac12$ (hence the return-defect order $k_{\rm ret}(6)=3$ is rigid across the whole real shear-jet family, while return content and radial fate are shear-selected) are exact and certified. Active: the radial swap-parity definition, the $p\mapsto k_{\rm ret}(p)$ map (CELL-A), and the $P_2$ band-scale geometry (CELL-B). Open at v0.2.1: the physical recognition-event rule, an intrinsic type-change locus, and the origin of the one-sided ratio shear. Nothing in this document is an ontological theorem; substrate results feed the ontology note under SG-R1.

## Local Tag Aliases

| Local alias | Expands to | Used for |
|---|---|---|
| `[ALG consequence]` | `[RESULT]` `[from: ALG]` [scope: exact consequence of imported certified definitions] | comparator identities that follow from Genesis/Dyadic `[DEF]`/`[THM]` lines (Number Genesis practice) |
| `[ALG conditional]` | `[ALG]` [scope: exact under explicitly listed assumptions] | selection lemma, radial parity |
| `[ALG diagnostic]` | `[ALG]` [scope: diagnostic twin, not a generator candidate] | shear twins $T_s$, $T_{\log}$, $T_{\tanh}$ |

---

## §1. Current Canonical State {#sec-1-state}

**Comparators.** `[DEF]` Two comparators are distinguished and must not be substituted for one another (SG-R2): the *pole comparator* $C_{\rm pole}(A,B)=e^{i\eta}$ between the two poles of one dyad, and the *state comparator* $C_\to(a,b)=\overline W_aW_b$ between two dyad states in the canonical $p=6$ eigenframe $W=\rho+\omega\eta$. `[ALG consequence]` $C_\to(a,b)=a^\top Bb-i\,a^\top BJ_Qb=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ with the certified Genesis $J_Q$ (the conjugate orientation of the Genesis $I+i\tfrac{\sqrt3}{2}\omega$ pairing). `[ALG]` [RID: RECOG-ALG-INVARIANT-FORM] Every symmetric $H$ with $A^\top HA=H$ is $H=cB$; so $C_\to$ is the canonical local comparator induced by the $p=6$, $P_1$ linear transport, up to scale and complex conjugation (SG-R9). $\widehat C$ is defined only for $Q_aQ_b>0$. `[ALG consequence]` Normalised, $\widehat C=C/\sqrt{C(a,a)C(b,b)}=e^{i\theta_{ab}}\in U(1)$, and pair swap acts as $\widehat C\mapsto\widehat C^{-1}$; swap-fixed values are exactly $\widehat C=\pm1$.

**Return defect.** `[DEF]` For a resonant return germ — $F^p$ with identity linear part at the reference fixed point — the return defect is $D_p=F^p-\mathrm{id}$; the return order $k_{\rm ret}(p)$ is the degree of its first nonzero homogeneous term modulo near-identity conjugacy. `[ALG]` [import: Dyadic §6.7 | DYAD-THM-C21] For $p=6$: $k_{\rm ret}=3$, $J_3(W)=\mu_6|W|^2W$, $\mu_6=-\tfrac12-i\tfrac{2\sqrt3}{3}$. `[ALG consequence]` $\chi_6(W)=C_\to(W,T^6W)/C_\to(W,W)=1+\mu_6Q+O(Q^2)$: the eigenvalue is the linearised recognition multiplier; $\chi$ is the diagonal case of $C$. `[ALG]` In a small punctured neighbourhood of $P_1$, $|\chi_6|<1$, hence no nontrivial period-6 points; the recognition content of $p=6$ lives entirely in the nonlinear return germ, not in periodic-orbit spectra.

**Fixed points and swap.** `[ALG]` $\operatorname{Fix}(T)=\{P_1,P_2\}$ on the wrapped phase; $P_1$: $\widehat C_{\rm pole}=+1$, elliptic; $P_2$: $\widehat C_{\rm pole}=-1$, hyperbolic. `[ALG conditional]` Under pole-swap covariance `[HYP]` and the certified linearisation $A$, $\rho$ must be swap-odd. `[ALG conditional]` Under the same covariance plus periodicity, $f(0)=f(\pi)=0$ and lowest-harmonic minimality, the radial forcing is $f(\eta)\propto\sin\eta$.

**Shear decomposition and jet law.** `[ALG]` $T=T_s+T_b$ with $T_s=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta)$ the exact swap-odd projection and $T_b=(0,\cosh\rho-1)$ the entire non-equivariant content; $T_b$ is the only quadratic term of the primitive jet. `[ALG]` [RID: RECOG-ALG-SHEAR-JET] For $g(\rho)=\rho+a\rho^2+b\rho^3+O(\rho^4)$, radial row $\rho'=\rho-\sin\eta$:
$$\boxed{\mu_6(a,b)=3b-4a^2-i\sqrt3\left(\tfrac13+2a^2-b\right)}.$$
Healing $\iff 4a^2>3b$. `[ALG]` [RID: RECOG-ALG-CUBIC-RETURN-RIGIDITY] $|\mu_6(a,b)|^2=12\bigl(b-\tfrac32a^2-\tfrac1{12}\bigr)^2+\tfrac14(2a^2+1)^2\ge\tfrac14$, hence $\mu_6(a,b)\ne0$ and $k_{\rm ret}(6)=3$ for every real $(a,b)$. `[ALG diagnostic]` $\mu_6^{(s)}=\tfrac12-i\tfrac{\sqrt3}{6}$ (expansive), $\mu_6^{(\log)}=-i\tfrac{\sqrt3}{3}$ (radially neutral), $\mu_6^{(\tanh)}=-1-i\tfrac{2\sqrt3}{3}$ (healing, swap-symmetric). `[ALG consequence]` On the radial-fate boundary $4a^2=3b$: $\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$, purely angular and nonzero; at the rigidity minimiser $\mu_6(0,\tfrac1{12})=\tfrac12e^{-i\pi/3}$. `[RESULT]` `[from: ALG]` Within the shear-jet family the return-defect order is rigid — no member delays the first return defect beyond cubic order — while the return content ($\Re\mu$, $\arg\mu$) and hence the radial fate (healing / neutral / expansion) are shear-selected; the fate can change class with $k_{\rm ret}$ unchanged and an angular residue surviving. Healing does **not** require swap-symmetry breaking.

**Candidate strata.** `[DEF]` Three candidate mathematical strata with a prerequisite ladder: rank stratum ($\det DF_x=0$; one state), pair-symmetry stratum ($\widehat C=\pm1$; pole level: primitive co-presence of $A,B$; state level: co-present states or retained self-comparison), loop/spectral stratum ($(\operatorname{tr}M_n,\det M_n)$; closed transport). `[ALG]` Of single-step Jacobian invariants only rank is chart-free. `[OPEN]` [RID: RECOG-OPEN-INTERSECTION] Recognition event $=$ nontrivial algebraic stratum $\cap$ dynamically distinguished stratum — realised by $P_2$, but in the dyad this coincidence is built in, not discovered (§6.5).

**Resonant-return family ($p\ge5$).** `[ALG]` [RID: RECOG-ALG-LEADING-RETURN-EQUIVARIANCE] If $F^p=\mathrm{id}+G_k+\cdots$ is tangent to identity with $L^p=I$, then $LG_k=G_k\circ L$ (from $F\circ F^p=F^p\circ F$). `[ALG]` [scope: resonant normal-form frame] [RID: RECOG-ALG-COMPARATOR-CLOSURE] Charge selection $\#W-\#\bar W\equiv1\pmod p$ forces literal charge $1$ through degree $p-2$; the return content is then a polynomial in $Q_a$ and $C_\to(a,b)$ for any number of modes; degree $p-1$ admits the first non-comparator channel $\bar W^{p-1}$. `[ALG]` [import: DYAD-ALG-BRIDGE-LEMMA, general form] For $p\ge5$: $[F_p^p-\mathrm{id}]_2=0$, $[F_p^p-\mathrm{id}]_3=p\bar\lambda\nu_3^{(1,p)}Z^2\bar Z$. `[ALG]` [RID: RECOG-ALG-NU3-CLOSED-FORM] $\nu_3(\lambda)$ as in the status summary; verified exactly mod $\Phi_5,\Phi_7$, by raw composition for $p=5\ldots12$, and $6\bar\lambda\nu_3(\zeta_6)=3\mu_6^{W}$. `[ALG]` [RID: RECOG-ALG-NU3-NONVANISHING] numerator $N$ has $\gcd(N,\lambda^5N(1/\lambda))=1$ and $\gcd(N,\Phi_p)=1$ for all $\varphi(p)\le5$, hence $k_{\rm ret}(p)=3$ for every $p\ge5$. `[ALG]`/`[NUM]` $\Re(\bar\lambda\nu_3)=-\tfrac{\theta^2}{4}+\tfrac{\theta^4}{48}+O(\theta^5)$, negative on $(0,2\pi/5]$: healing for every sampled $p$, $\Re\mu_p\to-\pi^2/p$, $\arg\mu_p$ monotone toward $-90^\circ$ ($-120.96^\circ,-113.41^\circ,-108.33^\circ$ at $p=5,6,7$; `[OBS finite-p]`).

**Lattice readability, clock, memory ($p=6$).** `[ALG]` [conv: Lie strict-kernel] $\chi_6=1+\mu Q+(c_{32}+c_{05}e^{-6i\Theta})Q^2+\cdots$; $\log\chi_6=\mu Q+(\beta+c_{05}e^{-6i\Theta})Q^2$, $\beta=c_{32}-\mu^2/2=\tfrac{5}{27}-i\tfrac{119\sqrt3}{648}$, $\Im\beta=c_\theta^{(6)}$. `[ALG]` [RID: RECOG-ALG-LATTICE-STRENGTH] $\mathcal I_{\rm lat}=|c_{05}|/|\mu|^2=\sqrt{9759}/5130\approx0.019257$ (invariant under linear frame and $U(1)$-equivariant residual gauge); $|c_{05}|/|\beta|\approx0.0828$ `[conv]`. `[ALG consequence]` [RID: RECOG-ALG-LATTICE-CLOCK] $\Psi_{\rm lat}=\arg c_{05}-6\Theta$ is frame-invariant; successive lattice thresholds along a healing orbit satisfy $m_{k+1}/m_k\to e^{\pi/(3\tau)}=\lambda_{\rm DSI}^{1/6}=(R^*)^{1/3}\approx2.4766$ (rate imported from NUMGEN defect-threshold theorem); per-threshold modulation fades as $\lambda_{\rm DSI}^{-1/3}$. `[ALG consequence, leading order]` [RID: RECOG-ALG-LATTICE-MEMORY] $\Lambda(Q_0,\Theta_0)=\tfrac{Q_0}{317520}[2767\sin6\Theta_0-1219\sqrt3\cos6\Theta_0]+O(Q_0^2)$; no retained $\log Q$ memory; two pairs with identical comparator data retain different pair memories.

**$P_2$ manifold geometry.** `[NUM strong]` [RID: RECOG-NUM-P2-C0-FIRST] $x_*=W^u_+(P_2)\cap C_0$ at $(\rho_*,\eta_*^{\rm lift})=(2.03336\ldots,8.00517\ldots)$, lifted excursion $278.66^\circ$ in the $\ell=1$ sector, itinerary $-1\to-i\to+1\to+i\to C_0$; wrapped $81.34^\circ$ is derived. `[NUM strong]` [RID: RECOG-NUM-P2-HET-NEG] $W^u_-(P_2)=\bigcup_kT^k(S)$, $S=P_u([-\lambda_u,-1])$, enters $Q<0.3$ within 12 steps with $\det J>0$; heteroclinic to $P_1$ conjectured. `[ALG]` $\rho<0\Rightarrow0<\det J<2$.

**Three-layer mapping.** `[ALG consequence]` comparison $\leftrightarrow C_\to(a,b)$; closure defect $\leftrightarrow\mu_6$; persisted memory $\leftrightarrow\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ (Genesis plateau bridge). These are distinct certified objects; recognition $\ne$ closure defect $\ne$ memory.

---

## §2. Active Frontier / OPEN Registry {#sec-2-open}

---
**OPEN R1 — Radial swap parity** [RID: RECOG-OPEN-RHO-PARITY]

Status: PARTIAL
Owner branch: this document
Exports to: RTG_ONTOLOGICAL_FOUNDATIONS (definition request)

Closed sub-items:
- Under pole-swap covariance and certified $A$, swap-even $\rho$ is excluded ($f'(0)=-1\ne0$) :: `[ALG conditional]` ✓

Active sub-items:
- Adopt $\rho$ as oriented (log-ratio-type) relational coordinate as a primitive `[DEF]` in OFN :: `[OPEN]`
- Status of pole-swap covariance itself as a primitive principle :: `[HYP]`

Dependencies:
- §6.4, §6.5
---

---
**OPEN R2 — CELL-A: return order across the $p$-family** [RID: RECOG-OPEN-KRET-P]

Status: **CLOSED (v0.3)**
Owner branch: this document → general theorem recommended for Dyadic ownership

Closed sub-items:
- $\nu_3^{(1,5)}=(12-\lambda+\lambda^2+8\lambda^3)/10$, $\nu_3^{(1,7)}=(12-4\lambda+\lambda^2+6\lambda^3-3\lambda^4+9\lambda^5)/14$ exact; $\mu_5,\mu_7\ne0$ :: `[ALG]` ✓ (two routes each: archived normaliser / raw composition)
- Closed form $\nu_3(\lambda)$ and empty unit-circle zero set; $k_{\rm ret}(p)=3$ for all $p\ge5$ :: `[ALG]` ✓ (§6.10)
- Successor question "zero set over general $p$" (CELL-A2) :: closed by the same theorem ✓

Residual: none. Cross-$p$ comparison is by $\arg\mu_p$ only (magnitudes are frame-dependent).
---

---
**OPEN R3 — CELL-B: $P_2$ band-scale geometry** [RID: RECOG-OPEN-P2-BAND]

Status: PARTIAL (positive branch `[NUM strong]`; negative branch → OPEN R8)
Owner branch: this document

Closed sub-items:
- Saddle spectrum fixes width–lifetime scaling, not a width :: `[ALG]` ✓ (negative result, RECOG-FAIL-K-FROM-SADDLE)
- First transverse $W^u_+(P_2)\cap C_0$ located; lifted itinerary and derived wrapped angle recorded :: `[NUM strong]` ✓ (§6.11)
- Continuous side supplies an oriented excursion, not a symmetric band :: `[RESULT] [from: NUM]` ✓

Active sub-items:
- Promote the positive-branch encounter to `[ALG via IA]` (interval enclosure of the unstable parameterisation, determinant sign control before the root) :: `[OPEN]`
- $W^s(P_2)$ global geometry (only $v_s=(1,-\phi^{-1})$ certified) :: `[OPEN]`

Dependencies:
- Dyadic OPEN 12; SG-R2; SG-R5
---

---
**OPEN R8 — CELL-B2: heteroclinic entry $W^u_-(P_2)\to P_1$** [RID: RECOG-OPEN-P2-HET-ENTRY]

Status: ACTIVE (RECOG part) / BLOCKED (promotion)
Owner branch: this document; promotion depends on Dyadic/NUMGEN

RECOG-owned target:
- Interval-enclose $S=P_u([-\lambda_u,-1])$ and its $\le12$ forward images; certify $\det J>0$ on all pre-entry iterates and entry into an explicit healing set :: `[OPEN]`

Blocked by:
- explicit local enclosure of the six-step return germ (contraction domain $r_0$, $c$) — see OPEN R10 and the stream memo §3

Dependencies:
- NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION (existential radius); §6.11
---

---
**OPEN R4 — Intrinsic type-change locus** [RID: RECOG-OPEN-TYPE-CHANGE]

Status: ACTIVE

Active sub-items:
- Does the primitive-chart locus $\cos\eta=0$ (parabolic, unipotent $J$) have a coordinate-free counterpart via periodic-orbit multipliers in the $(t,d)$-plane or via comparator geometry? :: `[OPEN]`
- Global periodic-orbit inventory of $T$ beyond $P_1,P_2$ (none exist in the small punctured $P_1$ sector) :: `[OPEN]`

Dependencies:
- §6.5, SG-R3
---

---
**OPEN R5 — Why one-sided ratio shear?** [RID: RECOG-OPEN-ONESIDED-SHEAR]

Status: ACTIVE
Exports to: RTG_ONTOLOGICAL_FOUNDATIONS §6.2a (rows 2–3), OPEN-P0 generator selection

Active sub-items:
- Derive why the primitive phase shear is $r-1=e^\rho-1$ (one-sided ratio) rather than $\log r=\rho$ or $\tfrac12(r-r^{-1})=\sinh\rho$; the certified functional consequence is the radial fate via $4a^2\gtrless3b$ :: `[OPEN]`
- Whether large-$|\rho|$ drive behaviour (a "saturation" reading) plays any role — not testable by the cubic jet; requires a nonlocal test before any `[HEUR]` :: `[OPEN]`

Dependencies:
- §6.6, §6.7
---

---
**OPEN R6 — Physical recognition-event rule** [RID: RECOG-OPEN-EVENT-RULE]

Status: ACTIVE (sharpened v0.3)

Closed sub-items:
- Self/encounter unification: the leading return defect is monodromy-equivariant, hence comparator-closed through degree $p-2$; diagonal and off-diagonal cases are one algebra; uncoupled encounter residue $=$ difference of self-return residues ($\Delta\log C_\to=\bar\mu Q_a+\mu Q_b$, reproducing the Genesis plateau memory) :: `[ALG]` ✓ (§6.12)
- First failure of comparator closure identified: the lattice harmonic $\bar W^{p-1}$; for $p=6$, $c_{05}\ne0$ :: `[ALG]` ✓ (§6.13)
- Retained lattice memory $\Lambda$ and the identical-comparator counterexample :: `[ALG consequence, leading order]` ✓ (§6.13)

Current hierarchy (v0.3): comparison $C_\to$ → return recognition $\mu Q$ → lattice readability $c_{05}Q^2e^{-6i\Theta}$ → lattice clock $m_{k+1}/m_k\to\lambda_{\rm DSI}^{1/6}$ → retained lattice memory $\Lambda(Q_0,\Theta_0)$ → physical event `[OPEN/HYP]`.

Active sub-items:
- `[HYP]` Event-capable recognition is associated not with instantaneous lattice-axis crossings but with non-comparator information that survives their fading modulation as the retained memory $\Lambda$. Crossings are the mechanism that generates/samples $\Lambda$, not the event definition.
- `[HYP]` (older, mechanism-level) intersection principle RECOG-OPEN-INTERSECTION (§6.5).
- Residual question: why should retained non-comparator memory constitute a physical event rather than a correction? :: `[OPEN]`

Dependencies:
- SG-R6, SG-R10
---

---
**OPEN R9 — CELL-D2a: finite-$Q_0$ lattice memory for the truncated normal form** [RID: RECOG-OPEN-LATTICE-MEMORY-NF]

Status: ACTIVE (RECOG-internal)

Target: for the quintic-truncated model $W'=W+\mu|W|^2W+c_{32}|W|^4W+c_{05}\bar W^5$ taken as exact, prove $|\Lambda_{\rm NF}-q\Lambda_1|\le C_2q^2$ with explicit $C_2$.

Inputs already in hand (§6.13): corrected backbone $Q_m=\tfrac qx-\tfrac{7}{54}q^2\tfrac{\log x}{x^2}+O(q^3)$; phase backbone $\Theta_m=\Theta_0-\tau\log x+qH(x)$, $H(x)=\tfrac{7\sqrt3}{81}[1-\tfrac{\log x+1}{x}]-\tfrac{335\sqrt3}{648}[1-\tfrac1x]$, $H(\infty)=-\tfrac{31\sqrt3}{72}$; corrected summand factor $A(x)=-\tfrac{7}{27}\tfrac{\log x}{x}-6iH(x)$; Euler–Maclaurin $q^2\sum F(qm)=\tfrac{q}{1-6i\tau}+\tfrac{q^2}{2}+O(q^3)$; $c_{05}^2$ self-interaction to be bounded.

Dependencies:
- Dyadic §6.5 ($47/54$), §6.9 ($c_\theta^{(6)}$, $c_{32}$, $c_{05}$)
---

---
**OPEN R10 — CELL-D2b / B2 promotion: explicit local enclosure of the six-step return germ** [RID: RECOG-OPEN-RETURN-ENCLOSURE]

Status: BLOCKED (upstream; single deliverable serving R8 and R9)

Requested from Dyadic/NUMGEN: explicit $r_0>0$, $C_7$, $c>0$ with, on $|W|^2\le r_0$ in the Lie strict-kernel chart,
$$|T^6(W)-W-\mu|W|^2W-c_{32}|W|^4W-c_{05}\bar W^5|\le C_7|W|^7,\qquad Q(T^6x)\le Q(x)-cQ(x)^2,$$
plus a scalar sufficient membership criterion. Rationale: $\sum_mQ_m^3=O(q^2)$, so a degree-7 remainder enters $\Lambda$ at the order R9 bounds; the contraction statement is what R8 needs. The same enclosure lifts the existential-radius guard on NUMGEN long-orbit results.
---

---
**OPEN R7 — Global accessibility of rank loss for shear twins** [RID: RECOG-OPEN-TWIN-ACCESS] (unchanged in v0.3)

Status: ACTIVE

Active sub-items:
- For $T_s$ ($\Re\mu=+\tfrac12$): does the outward drift reach $|\rho|\ge\operatorname{arccosh}2$ from a small-$Q$ start? Required before any "symmetric twin runs into erasure" statement :: `[OPEN]`
- $Q_c$-type threshold for twins :: `[OPEN]`

Dependencies:
- §6.7; Dyadic §6.4 $Q_c$
---

---

## §3. Scope Guards {#sec-3-guards}

**[SG-R1]** No result in this document is an ontological theorem. Substrate results may be *cited* in the ontology note as realisation witnesses; they may not be *promoted* there. The ontology is prior to RTG, not derived from it.
Violation: category error; the ontological claim is `[HYP]` at best.

**[SG-R2]** The pole comparator $C_{\rm pole}=e^{i\eta}$ and the state comparator $C_\to(a,b)=\overline W_aW_b$ are distinct objects at distinct levels. Neither may be substituted for the other; $\arg W\ne\eta$ ($\arg W(P_2)=2\pi/3$). Any "antipode" statement must name its comparator.
Violation: mis-assigned event angle; CELL-B output becomes meaningless.

**[SG-R3]** The eigenvalue type (elliptic/parabolic/hyperbolic) of a single-step Jacobian $DF_x$ off a fixed point is chart-dependent ($DF_x\mapsto D\varphi_{F(x)}DF_xD\varphi_x^{-1}$). Only rank is pointwise chart-free. Type statements are intrinsic only for closed transports $M_n$ on periodic points.
Violation: the quadrature locus $\cos\eta=0$ is `[ALG]` [scope: primitive chart] only.

**[SG-R4]** Shear twins $T_s$, $T_{\log}$, $T_{\tanh}$ and the $(a,b)$-family are diagnostic objects. They are not generator candidates and export nothing to Genesis, Triadic or TDR-G.
Violation: contaminates OPEN-P0 with unmotivated alternatives.

**[SG-R5]** No continuous↔discrete transfer. The TDR-G antipodal defect band $\mathcal D_k$ and the continuous $P_2$ geometry are related only as *two witnesses*; STAR-NOERASE-1 and the $Q_c$ protection mechanism are witnesses in different substrates. A bridge theorem is required before "same mechanism" claims.
Violation: SG-14 of the Dyadic DSN.

**[SG-R6]** Nontriviality of a comparison ($\widehat C\ne1$, or $D_\gamma\ne0$) is not a recognition *event*. Comparison, event, and memory are three distinct layers (§6.8). "Recognised" is used only for the mathematical residue; "event" is reserved for OPEN R6.
Violation: tautology ("everything compares, hence everything is recognised").

**[SG-R7]** All results inherit `[scope: conditional on postulated continuous generator T]` from the Dyadic export protocol. Jet-law statements are cubic-order, small-$Q$ statements.
Violation: overreach beyond the local germ.

**[SG-R8]** $Q<Q_c$ certifies only that the rank stratum $C_0$ is unreachable *at the crossing step*. It is a sufficient local safety condition, not a no-erasure theorem and not a global statement.
Violation: treating a local barrier as a global protection law.

**[SG-R9]** The metric $B$ is intrinsic up to scale; the complex orientation of the comparator is fixed only after the Genesis $J_Q$ sign branch is chosen. $C_\to=\overline W_aW_b$ carries the conjugate orientation of the Genesis $I+i\tfrac{\sqrt3}{2}\omega$ pairing. Convention-safe quantities: $|C|$, amplitude ratios, the swap-fixed set $\widehat C=\pm1$. Sign-carrying quantities ($\arg\widehat C$, $\Im\mu$) must state the orientation.
Violation: sign errors in phase-defect and memory statements.

**[SG-R10]** Lattice quantities carry two scopes. $\mathcal I_{\rm lat}$, $\Psi_{\rm lat}$, the clock ratio and the leading $\Lambda$ are invariant under linear frame changes and $U(1)$-equivariant residual gauge; $\arg c_{05}$, $|c_{05}|/|\beta|$, and individual crossing indices are `[conv: Lie strict-kernel]`. $\Lambda$ is leading order in $Q_0$ only; $0.01096\,Q_0$ is not a finite-$Q_0$ bound (R9/R10). Lattice thresholds are a mathematical sequence; "event" is `[HYP]`.
Violation: convention-laden numbers presented as invariants; asymptotic coefficients presented as bounds.

**[SG-R11]** Two rigidity theorems, two families. RECOG-ALG-CUBIC-RETURN-RIGIDITY is over shear jets at $p=6$, $K=1$; RECOG-ALG-NU3-NONVANISHING is over $p$ at fixed primitive shear in the $K_p$ family. They coincide at $p=6$ and must not be merged.
Violation: invoking $|\mu_6(a,b)|\ge\tfrac12$ for $p\ne6$, or the all-$p$ result for modified shears.

---

## §4. Layer Routing {#sec-4-routing}

| Layer | Canonical objects | Owner | Bridge required for |
|---|---|---|---|
| Primitive map | $T(\rho,\eta)$, $J$, $\det J$, $C_0$, $\operatorname{Fix}(T)$, $C_{\rm pole}=e^{i\eta}$ | Dyadic §6.1 | — |
| Birkhoff / normal form | $W$, $Q$, $\mu_6$, $h_2$, six-step jet | Dyadic §6.2, §6.7 | Birkhoff change of variables (certified in source) |
| State comparator | $C_\to(a,b)=\overline W_aW_b$, $\widehat C$, $\chi_6$ | this document §6.1–6.2 | none (exact consequence of Genesis §6.1/§6.6 definitions); orientation per SG-R9 |
| Candidate strata | rank / pair-symmetry / loop strata, $(t,d)$-plane | this document §6.5 | intrinsic type-change (OPEN R4); event rule (OPEN R6) |
| Shear diagnostics | $T_s$, $T_b$, $\mu_6(a,b)$ | this document §6.6–6.7 | none; SG-R4 blocks export |
| $p$-family / normal form | $\nu_3(\lambda)$, $\mu_p$, $c_{32},c_{05},c_\theta^{(6)}$, backbone | Dyadic §6.5, §6.9 (owner); this document §6.10, §6.13 | bridge lemma (certified); SG-R11 |
| $P_2$ invariant manifolds | $W^{u,s}(P_2)$, $S$, $x_*$ | this document §6.11; Dyadic OPEN 12 | promotion via R10 |
| Lattice / memory layer | $\Psi_{\rm lat}$, clock, $\Lambda$ | this document §6.13; NUMGEN threshold rate | SG-R10 |
| Ontology note | recognition = comparison; existence = relational | OFN / ontology thread | SG-R1: witness citation via §6.9 export interface only |
| Discrete (TDR-G) | $\mathcal D_k$, $N/2$ band | Discrete Genesis DSN | SG-R5: no import either way |

<!-- AI_CONTEXT_CORE_END -->

---

## §5. High-Risk Claims Ledger {#sec-5-high-risk}

| Claim | Valid form | Forbidden overclaim | Scope section |
|---|---|---|---|
| "Difference is recognised only by returning" | Intrinsic *spectral* comparison of a non-fixed history needs closed transport `[ALG]` | closure is a prerequisite of all recognition (comparator $C(r,T^nr)$ exists at every $n$) | §6.2, §6.5 |
| $\chi_6=1+\mu_6Q$ is origin-free | distinction-anchored at the zero-distinction state $\mathcal O_0=0$ `[ALG consequence]` | torsor-free comparison on the full state space | §6.2 |
| Comparator sign | $\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ under the Genesis $J_Q$ `[ALG]` | $+i$ pairing with $\overline W_aW_b$ (v0.1 error) | §6.1, SG-R9 |
| Cubic-return rigidity | $|\mu_6(a,b)|\ge\tfrac12$ on the real shear-jet family with radial row $-\sin\eta$ `[ALG]` | rigidity for other radial rows, other $p$, or outside the jet family | §6.7 |
| Eigenphase $\pi/3$ | linear resonance signature of the selected $T$ `[ALG]` | derivation of phase or of $p=6$ | §6.2 |
| $\operatorname{Fix}(T)=\{\widehat C_{\rm pole}=\pm1\}$ | exact, but built into $T$ via $\rho'-\rho=-\sin\eta$ `[ALG]` | independent evidence for the intersection principle | §6.5 |
| Healing from symmetry breaking | one route ($4a^2$ term); swap-symmetric $\tanh$ shear also heals `[ALG]` | "the arrow of history originates in swap breaking" | §6.7 |
| $\Im\mu_6/\Im\mu_6^{(s)}=4$ | Taylor-jet combinatorics of $(a,b)=(\tfrac12,\tfrac16)$ `[ALG]` | a structural $\mathbb Q(\sqrt3)$ mystery; an additive decomposition of the plateau-memory coefficient $\tau$ | §6.7, §6.8 |
| $Q_c$ protection | local, crossing-step, sufficient `[ALG]` | no-erasure theorem | SG-R8 |
| Antipode $=$ recognition | $\widehat C=-1$ is the unique nontrivial swap-fixed value; an event candidate `[ALG consequence]` | definition of recognition | §6.3, §6.5 |
| $\mu_p=0$ | cubic-silent; recognition order moves to degree 5 `[DEF]` | "recognitionless substrate" | OPEN R2 |
| $p=8$ zero degeneracy | belongs to the $q=4,(0,3)$ strobe channel only; cubic $\nu_3(\zeta_8)\ne0$ `[ALG]` | $\mu_8=0$ | §6.10 |
| $k_{\rm ret}(p)=3$ for all $p\ge5$ | $\nu_3$ numerator has no unit-circle root `[ALG]` | rigidity of $k_{\rm ret}$ under modified shears at $p\ne6$ | §6.10, SG-R11 |
| "$8.66^\circ$ inside quadrature toward the antipode" | encounter is $8.66^\circ$ *past* the second quadrature, approached from the identity side after $278.66^\circ$ lifted; the offset is derived from $\rho_*$ `[NUM strong]` | an independent angular datum; a band half-width | §6.11 |
| Comparator closure | exact for the leading return defect (gauge-free) and through degree $p-2$ in the normal-form frame `[ALG]` | closure of all raw higher-order terms | §6.12 |
| "Onset of lattice content is an event" | lattice content is an order in the germ; thresholds form a clock; retained $\Lambda$ is the candidate event content `[HYP]` | a state-space trigger; a $Q$-threshold $Q_{\rm lat}$ (none exists) | §6.13, R6 |
| $\tau$ decomposition | three-quarters of the local cubic angular coefficient is swap-breaking-mediated `[ALG]` | additive decomposition of the plateau memory | §6.8 |
| Equal-amplitude pairs build no relative phase | true at cubic order (uncoupled) `[ALG]`; false at the memory layer once $c_{05}\ne0$ | comparator completeness of memory | §6.12–6.13 |

---

## §6. Main Scientific Ledger {#sec-6-ledger}

### §6.1 Comparators `[ALG consequence / mixed]` {#sec-6-1-comparators}

> **[Local guard SG-R2]** Pole and state comparators are distinct; name the comparator in every antipode statement.

`[DEF]` **Pole comparator.** For a single dyad with relative phase $\eta$, $C_{\rm pole}(A,B)=e^{i\eta}$. Pole swap $A\leftrightarrow B$ sends $\eta\mapsto-\eta$, hence $C_{\rm pole}\mapsto C_{\rm pole}^{-1}$.

`[DEF]` **State comparator.** In the canonical eigenframe $W=\rho+\omega\eta$, $\omega=\tfrac12(-1+i\sqrt3)$ (Dyadic §6.2), for two dyad states $a,b$:
$$C_\to(a,b):=\overline W_aW_b.$$
The arrow marks the orientation: $C_\to(a,b)$ compares $a$ *to* $b$, so that the diagonal specialisation $b=F(a)$ gives $W'/W$ (§6.2).

`[ALG consequence]` [import: Genesis §6.1 ($B$, $Q=r^\top Br$, $A^\top BA=B$), Genesis §6.6 ($I_{ab}$, $\omega_{ab}$, $J_Q=\tfrac{1}{\sqrt3}\begin{psmallmatrix}1&-2\\2&-1\end{psmallmatrix}$, $a^\top BJ_Qb=+\tfrac{\sqrt3}{2}\omega_{ab}$)] [cert: `recog_shear_jet_cert.py` checks (10)] Since $|W|^2=\rho^2-\rho\eta+\eta^2=r^\top Br$ exactly, polarisation gives
$$C_\to(a,b)=a^\top Bb-i\,a^\top BJ_Qb=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab},\qquad W_a\overline W_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}.$$
$C_\to$ is the conjugate orientation of the Genesis $+$ pairing. `[COR]` v0.1 stated $\overline W_aW_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}$; the sign was wrong. See Appendix B, RID: RECOG-DEF-COMPARATOR-SIGN-V01.

`[ALG]` [RID: RECOG-ALG-INVARIANT-FORM] [cert: check (11)] **Invariant-form uniqueness.** With $A=\begin{psmallmatrix}1&-1\\1&0\end{psmallmatrix}$, the linear system $A^\top HA=H$ on symmetric $2\times2$ matrices has the one-dimensional solution space $H=cB$; positive definiteness gives $c>0$. The scale cancels in every ratio below. `[RESULT]` `[from: ALG]` $C_\to$ is the canonical local comparator induced by the $p=6$, $P_1$ linear transport $A$ — up to scale, and up to complex conjugation until the $J_Q$ sign branch is fixed (SG-R9). No global transport-invariance of $C_\to$ over the nonlinear state space is claimed.

`[ALG consequence]` **Normalised comparator and swap.**
$$\widehat C(a,b)=\frac{C_\to(a,b)}{\sqrt{C_\to(a,a)C_\to(b,b)}}=e^{i\theta_{ab}}\in U(1),\qquad \widehat C(b,a)=\overline{\widehat C(a,b)}=\widehat C(a,b)^{-1}.$$
Here $\theta_{ab}=\arg W_b-\arg W_a$ in the $C_\to$ orientation (SG-R9). [scope: $\widehat C$ is defined only for $Q_aQ_b>0$; $C_\to$ itself is defined at the zero-distinction state, $\widehat C$ is not.]
Swap-fixed values: $z=z^{-1}\iff z=\pm1$. $+1$ is the identity comparison; $-1$ is the unique nonidentity swap-fixed comparison. This characterisation is purely algebraic and needs no metric notion of "maximal distinction" (which remains an OFN interpretation).

`[ALG consequence]` **Two-coordinate comparison.** $C_\to(a,b)/C_\to(a,a)=\sqrt{Q_b/Q_a}\,e^{i\theta_{ab}}$; the natural comparison output is the dimensionless pair $(Q_b/Q_a,\ \Delta\theta_{ab})$.

`[HEUR]` The ratio appears here as the output of the comparison form, not as a primitive. This is *not* evidence that ratio precedes difference (Number Genesis guard); it is evidence that closed self-comparison is dimensionless.

### §6.2 Return Defect and the Six-Step Multiplier `[ALG / mixed]` {#sec-6-2-return}

`[DEF]` **Resonant return germ, return defect, return order.** Let $F$ have a fixed point $x_*$ at which $DF^p(x_*)=I$ for some $p$ (a resonant return germ). Define $D_p:=F^p-\mathrm{id}$; its first nonzero homogeneous term (modulo near-identity conjugacy) is the return defect and its degree is $k_{\rm ret}(p)$, with $k_{\rm ret}=\infty$ if $D_p$ vanishes to all orders. $D_n=F^n-\mathrm{id}$ is definable for every $n$; what the resonance condition supplies is a tangent-to-identity return, so that the leading term of $D_p$ is a formal invariant. `[COR]` v0.1 defined $D_\gamma$ over an "exact closed history"; the central object $T^6$ is not a nonlinear closed history off $P_1$. See Appendix B, RID: RECOG-DEF-RETURN-DEFECT-V01. The leading term $J_{k_{\rm ret}}$ is the formal invariant of a tangent-to-identity map under near-identity changes; its magnitude is convention-dependent under linear rescaling $W\mapsto cW$ (the vanishing/non-vanishing and, at fixed orientation convention, $\arg\mu$ and the radial/angular ratio are robust).

`[ALG]` [import: Dyadic §6.7 | DYAD-THM-C21] For $p=6$ the six-step quadratic part vanishes identically (master parity lemma), the cubic residual collapses to the resonant $(2,1)$ channel, and
$$T^6(W)=W+\mu_6|W|^2W+O(|W|^5),\qquad \mu_6=-\tfrac12-i\tfrac{2\sqrt3}{3},\qquad k_{\rm ret}(6)=3.$$

`[ALG consequence]` **Recognition multiplier.** With $b=T^6a$ in §6.1,
$$\chi_6(W):=\frac{C_\to(W,T^6W)}{C_\to(W,W)}=\frac{W'}{W}=\sqrt{\tfrac{Q'}{Q}}\,e^{i\Delta\Theta}=1+\mu_6Q+O(Q^2),$$
consistent with the certified laws $Q'=Q-Q^2+\cdots$, $\Delta\Theta=-\tau Q+\cdots$ (Dyadic §6.8). $\arg W=\Theta$ (ISP) exactly. The one-step eigenvalue $\lambda$ is the linearised special case $R(v)=\lambda v\Rightarrow R(v)/v=\lambda$; at the recognition cycle $\lambda^6=1$ and the linear spectrum carries no information — the content is in $J_3$.

`[ALG]` **Local exact statements.** $Q=0\Rightarrow\chi_6=1$. For $0<Q<\epsilon$: $|\chi_6|=1-\tfrac12Q+O(Q^2)<1$, hence $\chi_6\ne1$ and $T^6$ has no fixed point other than $P_1$ in the punctured sector. Depends on: [import: RTG_NUMBER_GENESIS_DSN_v1.15 | NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION] $Q_{\rm true}(Fx)-Q_{\rm true}(x)=-Q_{\rm true}^2+O(Q_{\rm true}^{5/2})$ with phase-uniform strict contraction on a sufficiently small punctured sector. See §7. Substrate statement: $Q=0\Rightarrow D_6=0$; $0<Q<\epsilon\Rightarrow T^6x\ne x$ with nontrivial return defect. Any reading of this as a witness for an ontological thesis is made in the ontology note, not here (§6.9).

`[ALG]` **Distinction anchoring.** $\chi_6$ compares $W$ with $T^6W$ relative to $W=0$, i.e. relative to the zero-distinction state $\mathcal O_0=0$ of Genesis §6.1 — not relative to an external origin. The definition is *distinction-anchored*, not origin-free; a genuine torsor difference on the state space would use only the phase/winding gauge, which is invisible to the dynamics (Dyadic §6.4) and hence empty.

`[ALG]` **Phase readability.** Phase structure exists at linear order ($\lambda=e^{i\pi/3}$); a *self-readable* phase defect first appears at cubic order, multiplied by amplitude: $\arg\chi_6=-\tau Q+O(Q^2)$. Phase is not created by $Q$; its self-recognition residue opens with $Q$.

`[ALG]` The resonance prerequisite is arithmetic: a tangent-to-identity return $DF^p=I$ exists only for rational rotation number. `[HEUR]` For an irrational-rotation germ no finite $p$ gives a resonant return, so $k_{\rm ret}$ is undefined (not $\infty$); $D_n$ and the comparison $C_\to(r,T^nr)$ nonetheless exist at every $n$. Finite resonance is therefore the prerequisite of finite *self-calibration*, not of comparison as such.

### §6.3 Fixed Points, Antipode, and Swap Structure `[ALG / mixed]` {#sec-6-3-fixed-swap}

`[ALG]` [import: Dyadic §6.1] $\rho'=\rho\Rightarrow\sin\eta=0$; then $\eta'=\eta\Rightarrow e^\rho=1$. Hence on the wrapped phase $\operatorname{Fix}(T)=\{P_1=(0,0),P_2=(0,\pi)\}$, with $P_1$ elliptic ($e^{\pm i\pi/3}$) and $P_2$ hyperbolic ($\phi^{\pm2}$).

`[ALG consequence]` $P_1:\ \widehat C_{\rm pole}=+1$; $P_2:\ \widehat C_{\rm pole}=-1$. The two stationary states are exactly the two swap-fixed pole comparisons. This is a consequence of the radial row being $-\sin\eta$ (§6.4), not an independent coincidence; see §5.

`[ALG]` **Fiber antipode vs state antipode.** $A^3=-I$ reverses a tangent perturbation at $P_1$ (fiber antipode, linear order); $P_2$ is the state-space antipode of the pole comparison and carries no cyclic return (real multipliers). These are distinct objects; "recognition at the antipode" must specify which. `[DEF]` Two candidate recognition classes: *recurrence recognition* (self-comparison along a closed history, realised near $P_1$) and *encounter recognition* (cross-comparison of two co-present relations, realised by $C_\to(r_a,r_b)$ at state level and by the $P_2$ pole configuration at pole level).

### §6.4 Radial Parity and the Selection Lemma `[ALG conditional / mixed]` {#sec-6-4-selection}

`[HYP]` **Pole-swap covariance.** The primitive relational description is covariant under $A\leftrightarrow B$.

`[ALG conditional]` [assumes: pole-swap covariance; certified $A=DT(P_1)$] Write $\rho'=\rho+f(\eta)$. If $\rho$ were swap-even, covariance gives $f(-\eta)=f(\eta)$, hence $f'(0)=0$; but $A$ has radial entry $f'(0)=-1$. Therefore $\rho$ is swap-odd: $S_o(\rho,\eta)=(-\rho,-\eta)$, and $\operatorname{Fix}(S_o)=\{(0,0),(0,\pi)\}=\operatorname{Fix}(T)$ exactly, although $T$ is not $S_o$-equivariant (§6.6). Under swap-even $\rho$ the minimal covariant radial forcing would be $\propto\cos2\eta-1=-2\sin^2\eta$: sign-definite drift, no elliptic $P_1$.

`[ALG conditional]` [RID: RECOG-ALG-SELECTION-SIN] [assumes: pole-swap covariance with $\rho$ odd; $2\pi$-periodicity; stationarity on the swap-fixed strata $f(0)=f(\pi)=0$; lowest nonzero Fourier harmonic] $f(\eta)=a_1\sin\eta$; with orientation/normalisation $a_1=-1$, the radial row of $T$ is recovered. The lemma selects the functional form only; it does not derive the coefficient, and it does not select the shear $g(\rho)$ (any odd $g$ with $g'(0)=1$ is admissible: $\rho$, $\sinh\rho$, $\tanh\rho$, …).

`[RESULT]` `[from: ALG conditional]` The stationarity of $P_1,P_2$ is thereby reframed from an observed coincidence into a generator-construction criterion: swap-special relational states $\Rightarrow$ stationarity $\Rightarrow f(0)=f(\pi)=0\Rightarrow f_{\min}\propto\sin\eta$. This is a candidate derivation for the first row of OFN §6.2a ("why does phase opposition change radial separation"), tagged conditional.

### §6.5 Candidate Mathematical Strata and the Prerequisite Ladder `[DEF / mixed]` {#sec-6-5-strata}

> **[Local guard SG-R3]** One-step Jacobian type is chart-dependent off fixed points; only rank is pointwise intrinsic.

`[DEF]` **Three candidate strata.** These are mathematical loci of the comparator/transport geometry; whether any of them is a physical *event* is OPEN R6 (SG-R6).

| Stratum | Intrinsic object | Prerequisite | Dyad realisation |
|---|---|---|---|
| rank stratum | $\operatorname{rank}DF_x$ | one present state | $C_0=\{\rho\ge\ln2,\ \cos\eta=-1/(e^\rho-1)\}$ |
| pair-symmetry stratum, pole level | $\widehat C_{\rm pole}=\pm1$ | primitive co-presence of $A,B$ (always given in a dyad) | $P_1$ ($+1$), $P_2$ ($-1$) |
| pair-symmetry stratum, state level | $\widehat C(a,b)=\widehat C(b,a)$, i.e. $\widehat C=\pm1$ (domain $Q_aQ_b>0$) | co-present states/modes, or retained self-comparison data | $C_\to(r_a,r_b)$; $A^3=-I$ (fiber level) |
| loop/spectral stratum | $(t_n,d_n)=(\operatorname{tr}M_n,\det M_n)$, $\Delta_n=t_n^2-4d_n$, multiplier $\pm1$ loci $t_n=\pm(1+d_n)$ | closed transport $F^n(x)=x$ | $P_1$ ($t=1,d=1$), $P_2$ ($t=3,d=1$); no other period-6 points near $P_1$ |

`[ALG]` The map is non-symplectic (Dyadic §6.1), so the loop stratum lives in the $(t,d)$-plane; the classical $\operatorname{tr}=\pm2$ criterion holds only on the $d=1$ slice.

`[ALG]` [scope: primitive chart] **Discriminant.** With $c=\cos\eta$: $\operatorname{tr}J=2-c$, $\det J=1+(e^\rho-1)c$, $\Delta_J=c(c-4e^\rho)$. For $\rho>-\ln4$ the sign is $-\operatorname{sign}(c)$: rotational transport for $\cos\eta>0$, stretching for $\cos\eta<0$; the zero locus has the second branch $\cos\eta=4e^\rho$ only for $\rho\le-\ln4$. On $\cos\eta=0$: $\det J=1$, $\Delta_J=0$, $J=\begin{pmatrix}1&0\\e^\rho&1\end{pmatrix}$ — a nontrivial unipotent matrix in the primitive chart. No intrinsic conjugacy-class statement is made off the fixed points (SG-R3). `[OPEN]` intrinsic counterpart: OPEN R4.

`[ALG consequence]` **Pair-symmetry is pairwise, not pointwise.** $\widehat C=-1$ is a property of a pair. At pole level the pair $A,B$ is primitively co-present, so the pole stratum needs no history. At state level a past comparison partner is not automatically part of the present state: [import: RTG_NUMBER_GENESIS_DSN_v1.15 N-1C | NUMGEN-OPEN-N1C] the wrapped-$S^1$ negative control shows that a memoryless wrapped state collapses same-endpoint histories, while the later local primitive-dyad result shows history non-collapse when relational data are retained. Hence state-level self-comparison requires either explicitly retained relational memory/interface data or a current co-realisation; the carrier $U(1)$ being closed is not a dynamical closure. `[COR]` v0.1 overstated the negative control as "a past state is not physically present". See Appendix B, RID: RECOG-DEF-COPRESENCE-V01.

`[HYP]` [RID: RECOG-OPEN-INTERSECTION] **Intersection principle** (registered under OPEN R6). Recognition event $=$ (nontrivial algebraic comparison stratum) $\cap$ (dynamically distinguished stratum). Realised by $P_2$: $\widehat C_{\rm pole}=-1$, $T(P_2)=P_2$, $\operatorname{spec}DT_{P_2}=\{\phi^2,\phi^{-2}\}$. In the dyad the coincidence is built in: $\operatorname{Fix}(T)\subset\{\sin\eta=0\}$ by construction of the radial row. The principle may therefore be used as a *derivation target* for that row (§6.4), not as a fact derived from $T$.

`[RESULT]` `[from: ALG]` Prerequisite ladder: rank and pole-level pair-symmetry need no history; state-level pair-symmetry needs co-presence or retained comparison data; the spectral stratum needs closed transport. Closure is the prerequisite of the spectral stratum only, not of all recognition.

`[HEUR]` Candidate mathematical essence of a recognition event: *failure of continuation within the current equivalence class* — a jump in rank, stabiliser/symmetry, conjugacy class or return normal form — rather than any change of a comparison value. Generic small motion changes $C$ without leaving its stratum and is not an event (SG-R6).

### §6.6 Swap-Projection Decomposition `[ALG]` {#sec-6-6-swap-projection}

> **[Local guard SG-R4]** Twins are diagnostic; no export.

`[ALG]` [RID: RECOG-ALG-SWAP-SPLIT] With $S_o=-I$, the odd and even projections of $T$ are exact:
$$T_s(x)=\tfrac12\bigl(T(x)-T(-x)\bigr)=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta),\qquad T_b(x)=\tfrac12\bigl(T(x)+T(-x)\bigr)=(0,\ \cosh\rho-1),$$
$T=T_s+T_b$. Equivalently $T\circ S_o-S_o\circ T=(0,\,2(\cosh\rho-1))=(0,\rho^2+O(\rho^4))$: $T$ is swap-equivariant at linear order and breaks swap symmetry first at quadratic order. $T_b$ is the *only* quadratic term of the primitive one-step jet; consequently the certified quadratic normal-form coefficients $c_{20},c_{11},c_{02}$ (Dyadic §6.2) are entirely sourced by the symmetry-breaking term.

`[ALG]` In ratio language $r=e^\rho$: $e^\rho-1=r-1$ (one-sided ratio drive), $\sinh\rho=\tfrac12(r-r^{-1})$ (reciprocal-antisymmetrised ratio drive), $\rho=\log r$ (log-ratio drive). $T_s$ is the reciprocal-symmetric twin, not the log twin.

`[ALG diagnostic]` **Twin rank stratum.** $\det J_s=1+(\cosh\rho-1)\cos\eta$; critical locus $\cos\eta=-1/(\cosh\rho-1)$, $|\rho|\ge\operatorname{arccosh}2$: two symmetric branches, versus the one-sided $C_0$ ($\rho\ge\ln2$) of $T$. The one-sidedness of the rank event is sourced by $T_b$.

### §6.7 Shear-Jet Law and Radial Fate `[ALG / mixed]` {#sec-6-7-shear-jet}

`[ALG]` [RID: RECOG-ALG-SHEAR-JET] [cert: `recog_shear_jet_cert.py` checks (1)–(7), (9) → CERTIFICATE PASS; two independent derivations] For the family
$$T_{a,b}(\rho,\eta)=\bigl(\rho-\sin\eta,\ \eta+g(\rho)-\sin\eta\bigr),\qquad g(\rho)=\rho+a\rho^2+b\rho^3+O(\rho^4),$$
the six-step quadratic part vanishes identically and the cubic residual is confined to the $(2,1)$ channel for all real $(a,b)$, with
$$\mu_6(a,b)=3b-4a^2-i\sqrt3\left(\tfrac13+2a^2-b\right).$$
Checks: $(a,b)=(\tfrac12,\tfrac16)$ reproduces DYAD-THM-C21 exactly.

`[ALG diagnostic]` **Instances.**

| shear $g$ | $(a,b)$ | $\mu_6$ | $\Re\mu_6$ | radial fate | swap |
|---|---|---|---|---|---|
| $\rho$ (log) | $(0,0)$ | $-i\sqrt3/3=-i\tau/2$ | $0$ | neutral at cubic order | odd |
| $\sinh\rho$ | $(0,\tfrac16)$ | $\tfrac12-i\sqrt3/6$ | $+\tfrac12$ | expansion | odd |
| $\tanh\rho$ | $(0,-\tfrac13)$ | $-1-i\,2\sqrt3/3$ | $-1$ | healing | odd |
| $e^\rho-1$ (primitive) | $(\tfrac12,\tfrac16)$ | $-\tfrac12-i\,2\sqrt3/3$ | $-\tfrac12$ | healing | broken |
| $(e^{\kappa\rho}-1)/\kappa$ | $(\tfrac\kappa2,\tfrac{\kappa^2}6)$ | $-\tfrac{\kappa^2}{2}-i\tfrac{\sqrt3}{3}(1+\kappa^2)$ | $-\tfrac{\kappa^2}{2}$ | healing for all $\kappa\ne0$ | broken |

`[ALG]` $\mu_{\rm break}:=\mu_6-\mu_6^{(s)}=-1-i\tfrac{\sqrt3}{2}$ is the quadratic symmetry-breaking-mediated contribution (since $T$ and $T_s$ share linear and cubic primitive jets). $\Im\mu_6/\Im\mu_6^{(s)}=4$ exactly, explained by $(\tfrac13+\tfrac12-\tfrac16)/(\tfrac13-\tfrac16)$; no deeper structural reason is claimed.

`[RESULT]` `[from: ALG]` **Radial-fate law.** $\Re\mu_6=3b-4a^2$: healing $\iff4a^2>3b$, neutral $\iff4a^2=3b$, expansion $\iff4a^2<3b$. Two independent routes to healing exist — quadratic swap breaking ($a\ne0$) and a negative cubic contribution ($b<0$). The primitive exponential shear heals because $-4a^2=-1$ overcomes $+3b=+\tfrac12$. Symmetry breaking *reverses* the outward drift of the $\sinh$ twin; it does not create directedness, and it is not necessary for healing ($\tanh$ counterexample).

`[ALG]` [RID: RECOG-ALG-CUBIC-RETURN-RIGIDITY] [cert: checks (8)] **Cubic-return rigidity.** For every real $(a,b)$,
$$\boxed{|\mu_6(a,b)|^2=12\Bigl(b-\tfrac32a^2-\tfrac1{12}\Bigr)^2+\tfrac14\bigl(2a^2+1\bigr)^2\ \ge\ \tfrac14},$$
with equality only at $(a,b)=(0,\tfrac1{12})$. Hence $\mu_6(a,b)\ne0$ on the whole family and, with the universal quadratic cancellation and $(2,1)$ confinement above, $k_{\rm ret}(6)=3$ for every member. Depends on: radial row fixed as $\rho'=\rho-\sin\eta$; real $(a,b)$. `[COR]` v0.1 asserted an imaginary "residue floor" $\Im\mu_6\le-\tau/2$; false ($\Im\mu_6^{(s)}=-\tau/4$). Replaced by this modulus bound. See Appendix B, RID: RECOG-ALG-IM-FLOOR-V01.

`[ALG consequence]` [RID: RECOG-ALG-FATE-BOUNDARY] [cert: checks (12)–(13)] **Radial-fate boundary corollary.** On $4a^2=3b$ the law reduces to $\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$: $\Re\mu_6=0$ but $|\mu_6|\ge1/\sqrt3$. The healing/expansion transition therefore does not coincide with loss of return content — radial fate changes class while $k_{\rm ret}$ is unchanged and a purely angular residue survives. At the rigidity minimiser, $\mu_6(0,\tfrac1{12})=\tfrac14-i\tfrac{\sqrt3}{4}=\tfrac12e^{-i\pi/3}$.

`[RESULT]` `[from: ALG]` The return-defect *order* is rigid across the shear-jet family; the return *content* ($\arg\mu$, $\Re\mu$) and hence the radial fate are shear-selected. $J_3$ may be called a mathematical recognition residue under SG-R6; no physical recognition-event order is asserted. To delay the first return defect beyond cubic order one must leave this family or change the resonance horizon $p$ (CELL-A). `[HEUR]` Whether the healing instances share a large-$|\rho|$ "saturation" feature is not decidable from the cubic jet ($e^\rho-1$ is unbounded as $\rho\to+\infty$); see OPEN R5.

`[HEUR]` [scope: SG-R8, OPEN R7] In $T$, healing keeps small $Q$ below $Q_c$ and away from $C_0$; in $T_s$ small distinctions grow toward larger amplitudes where the symmetric rank locus may become accessible. "Symmetric twin runs into erasure" is **not** certified (global accessibility open).

### §6.8 Comparison – Event – Memory Mapping `[ALG consequence]` {#sec-6-8-three-layers}

`[ALG consequence]` Three certified dyadic objects realise three distinct layers:

| Layer | Object | Source |
|---|---|---|
| comparison | $C_\to(a,b)=\overline W_aW_b$ | §6.1 (Genesis §6.1, §6.6) |
| closure defect | $T^6W-W=\mu_6|W|^2W+\cdots$ | Dyadic §6.7 |
| persisted memory | $\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ | Genesis §6.6 plateau shear bridge `[ALG structure]` |

Recognition $\ne$ closure defect $\ne$ memory (SG-R6). `[ALG]` Three quarters of the primitive *local cubic angular return coefficient* is symmetry-breaking-mediated ($\Im\mu_6^{(s)}=\tfrac14\Im\mu_6$); no additive decomposition of the asymptotic plateau-memory law is claimed, since that law also uses the healing radial backbone, which the expansive twin does not share. `[HYP]` (SG-R1) These are successive layers of one relational geometry.

### §6.9 Ontology Export Interface `[DEF]` {#sec-6-9-export}

> **[Local guard SG-R1]** Witness citations only; no promotion.

`[DEF]` The ontology note (OFN / relational-existence thread) may cite the following RECOG objects as substrate witnesses, each with its tag and scope carried verbatim:
- $C_\to$ comparator structure and the swap-fixed set $\widehat C=\pm1$ (§6.1, SG-R9)
- $k_{\rm ret}(6)=3$ and the recognition multiplier $\chi_6$ (§6.2)
- cubic-return rigidity RECOG-ALG-CUBIC-RETURN-RIGIDITY (§6.7)
- radial-fate law $4a^2\gtrless3b$ (§6.7)
- candidate strata and prerequisite ladder (§6.5), as *candidates*
- all-$p$ return-order theorem and $\nu_3(\lambda)$ (§6.10)
- leading-return equivariance and comparator closure through degree $p-2$ (§6.12)
- lattice clock ratio $\lambda_{\rm DSI}^{1/6}$, retained lattice memory $\Lambda$, and the identical-comparator counterexample (§6.13), with SG-R10 scopes carried verbatim
- the oriented $P_2\to C_0$ excursion and the conjectured $W^u_-(P_2)\to P_1$ connection (§6.11), as `[NUM strong]`

All interpretive statements formerly listed here ("existence $=$ recognisability", "physics at the intersection of compatible structures", "closure is arithmetic, defect geometric, recognition comparison") are moved to the ontology note as `[HYP]` and are not part of this ledger.

---

### §6.10 Resonant Return over the $p$-Family `[ALG]` {#sec-6-10-p-family}

> **[Local guard SG-R11]** $K_p$ family at fixed primitive shear; not the shear-jet family of §6.7.

`[DEF]` **Family.** $\rho'=\rho-\sin\eta$, $\eta'=\eta+K_p(e^\rho-1)-K_p\sin\eta$, $K_p=2-\lambda-\bar\lambda$, $\lambda=e^{2\pi i/p}$; eigenframe $\rho=uZ+\bar u\bar Z$, $\eta=Z+\bar Z$, $u=1/(1-\lambda)$ (as in the archived Dyadic normalisers). The $p=6$ member in this $Z$-frame relates to the $W$-frame by the exact scale $6\bar\lambda\nu_3(\zeta_6)=3\mu_6^{W}$.

`[ALG]` [RID: RECOG-ALG-LEADING-RETURN-EQUIVARIANCE] Leading-defect equivariance $LG_k=G_k\circ L$ (proof in §6.12). Consequence for $p\ge5$ [import: DYAD-ALG-BRIDGE-LEMMA, general form]: $[F_p^p-\mathrm{id}]_2=0$ and $[F_p^p-\mathrm{id}]_3=p\bar\lambda\,\nu_3^{(1,p)}Z^2\bar Z$, so raw $p$-fold composition and normalised-then-bridged routes give the same coefficient. Ownership of this general theorem is recommended for Dyadic (stream memo §1).

`[ALG]` [RID: RECOG-ALG-NU3-CLOSED-FORM] [cert: `recog_cell_a2_nu3_closed_form_cert.py`, 11 checks]
$$\nu_3(\lambda)=-\frac{\lambda^5-\lambda^4-\lambda^3-2\lambda^2+1}{2(\lambda-1)(\lambda+1)(\lambda^2+\lambda+1)},$$
obtained by symbolic $h_2$ normalisation; denominator zeros are exactly the $h_2$-resonant $\lambda$ ($p\le3$). Exact agreement with the archived $p=7$ normaliser ($\nu_3^{(1,7)}$, artifact `normalize_p7_full_onestep_cyclotomic.py`) and the $p=5$ $\mathbb Q(\zeta_5)$ certificate; raw-composition agreement for $p=5\ldots12$ to $10^{-30}$.

`[ALG]` [RID: RECOG-ALG-NU3-NONVANISHING] $N(\lambda)=\lambda^5-\lambda^4-\lambda^3-2\lambda^2+1$: $\gcd(N,\lambda^5N(1/\lambda))=1$ (no root on $|\lambda|=1$; numeric root moduli $0.603,0.688,1.962,1.108,1.108$) and $\gcd(N,\Phi_p)=1$ for $p\in\{1,2,3,4,5,6,8,10,12\}$ (all $p$ with $\varphi(p)\le5$). `[RESULT] [from: ALG]` $\nu_3^{(1,p)}\ne0$ and $k_{\rm ret}(p)=3$ for every $p\ge5$; no cubic-silent horizon exists. OPEN R2 closed.

`[ALG]` **Finite ledger** [cert: `recog_cell_a_p5_rawcomp_cert.py` (10 checks), `recog_cell_a_p7_rawcomp_cert.py` (5 checks)]: $\mu_5=\tfrac{-13-11\lambda-4\lambda^2-12\lambda^3}{2}$, $\nu_3^{(1,5)}=\tfrac{12-\lambda+\lambda^2+8\lambda^3}{10}$; $\mu_7=\tfrac{-16-11\lambda-6\lambda^2-15\lambda^3-3\lambda^4-12\lambda^5}{2}$, $\nu_3^{(1,7)}=\tfrac{12-4\lambda+\lambda^2+6\lambda^3-3\lambda^4+9\lambda^5}{14}$.

`[ALG]` **Small-$\theta$ law.** With $\lambda=e^{i\theta}$: $\bar\lambda\nu_3=-\tfrac{i}{6\theta}-\tfrac{i\theta}{2}-\tfrac{\theta^2}{4}+\tfrac{11i\theta^3}{120}+\tfrac{\theta^4}{48}+O(\theta^5)$, hence $\Re\mu_p=p\Re(\bar\lambda\nu_3)\to-\pi^2/p$. `[NUM]` $\Re(\bar\lambda\nu_3)<0$ on a $4000$-point mesh of $(0,2\pi/5]$. Since $\operatorname{sign}\Re\mu$ and $\arg\mu$ are invariant under $Z\to cZ$: healing for all sampled $p$; $\arg\mu_p=-120.96^\circ,-113.41^\circ,-108.33^\circ$ at $p=5,6,7$, monotone toward $-90^\circ$ `[OBS finite-p]` (three points; no monotonicity theorem).

### §6.11 $P_2$ Invariant Manifolds `[NUM strong / mixed]` {#sec-6-11-p2-manifolds}

> **[Local guard SG-R2]** All angles below are pole-comparator angles $\eta$. **[SG-R5]** No TDR-G transfer.

`[ALG]` [import: Dyadic §6.1] $J(P_2)=\begin{psmallmatrix}1&1\\1&2\end{psmallmatrix}$, $\lambda_{u,s}=\phi^{\pm2}$, $v_u=(1,\phi)$, $v_s=(1,-\phi^{-1})$. Parameterisation $P_u(t)=\lim_nT^n(P_2+t\lambda_u^{-n}v_u)$, $P_u'(0)=v_u$, $P_u(\lambda_ut)=T(P_u(t))$.

`[NUM strong]` [RID: RECOG-NUM-P2-C0-FIRST] [cert: `recog_cell_b_p2_manifolds.py`] On $W^u_+(P_2)$ the first transverse encounter with $C_0$ is at $x_*=(\rho_*,\eta_*^{\rm lift})=(2.033364438914269\ldots,\ 8.005165051501685\ldots)$, $t_*=2.98946\ldots$, $Q_*=3.5984>Q_{\min}(C_0)$; $d\det J/dt\approx-9.38$ (transverse); $n=30\to35$ approximant change $<10^{-38}$. Both $\rho(t)$ and lifted $\eta(t)$ increase monotonically to $t_*$; comparator crossings at $\eta=\tfrac{3\pi}{2}$ ($\rho=0.9110425492$), $2\pi$ ($\rho=1.6327172351$), $\tfrac{5\pi}{2}$ ($\rho=2.0203832926$): itinerary $-1\to-i\to+1\to+i\to C_0$ in the $\ell=1$ lifted sector; excursion $\eta_*^{\rm lift}-\pi=4.8635724\,{\rm rad}=278.6621718^\circ$. Wrapped: $\eta_*^{\rm wrap}=1.7219797$, $\operatorname{dist}_{S^1}(\eta_*^{\rm wrap},\pi)=81.3378282^\circ$, with $\delta=\arccos\!\big(1/(e^{\rho_*}-1)\big)$ and $\eta_*^{\rm lift}=3\pi-\delta$, so the $8.662^\circ$ offset past the second quadrature is derived, not independent. The chart-free object is $x_*$; $\rho_*$ is its primitive-chart coordinate.

`[RESULT] [from: NUM]` The continuous dyad supplies an **oriented, $\ell=1$ lifted antipode-to-rank-loss excursion**, not a symmetric band; the wrapped $81.34^\circ$ is its shadow. Bridge questions for TDR-G (SG-R5): wrapped half-width vs lifted excursion; spacing statistic $n_{k+1}/n_k\stackrel?\to\lambda_{\rm DSI}^{1/6}$ (§6.13); memory statistic (comparator-completeness of retained discrete state).

`[ALG]` **Negative half-plane.** $\rho<0\Rightarrow e^\rho-1\in(-1,0)\Rightarrow0<\det J<2$: no rank loss on any segment confined to $\rho<0$. `[NUM strong]` [RID: RECOG-NUM-P2-HET-NEG] $W^u_-(P_2)=\bigcup_{k\ge0}T^k(S)$ with $S=P_u([-\lambda_u,-1])$ (exact). Every sampled point of $S$ reaches $Q<0.3$ within 12 primitive steps; max $Q$ en route $3.95$; min $\det J$ en route $0.1367$; $W^u_-$ is not confined to $\rho<0$ (reaches $\rho\approx0.62$ near $\eta\approx-0.07$); six-step $Q$ from $P_u(-1)$ decreases monotonically through $m=200$ ($Q_{1200}\approx0.0048$). Heteroclinic connection $W^u_-(P_2)\to P_1$ conjectured; certification is OPEN R8, blocked by R10.

### §6.12 Leading-Return Equivariance and Comparator Closure `[ALG / mixed]` {#sec-6-12-equivariance}

`[ALG]` [RID: RECOG-ALG-LEADING-RETURN-EQUIVARIANCE] **Theorem.** Let $F=L+F_2+\cdots$ with $L^p=I$ and $F^p=\mathrm{id}+G_k+O(k+1)$, $G_k\ne0$. Then $LG_k(x)=G_k(Lx)$.
*Proof.* Expand $F\circ F^p=F^p\circ F$ at degree $k$: the left side gives $LG_k(x)+F_k(x)$, the right side $F_k(x)+G_k(Lx)$ (all other contributions have degree $\ge k+1$). $\square$ Gauge-independent; valid for any number of modes with $L=\operatorname{diag}(A,\ldots,A)$.

`[ALG]` [scope: resonant normal-form frame] [RID: RECOG-ALG-COMPARATOR-CLOSURE] In the eigenframe, $\mathbb Z_p$-equivariance of an output-$W_a$ monomial requires $\#W-\#\bar W\equiv1\pmod p$. For total degree $\le p-2$ this forces $\#W-\#\bar W=1$, i.e. $U(1)$-equivariance, so every such term is $\sum\alpha\,W_bC_\to(c,d)$: the return content lies in the comparator algebra $\{Q_a,C_\to(a,b)\}$. At degree $p-1$ the monomial $\bar W^{p-1}$ ($\#W-\#\bar W=-(p-1)\equiv1$) is the first symmetry-allowed non-comparator channel. Genesis' certified $\Delta Q_d^{(4)}$, written entirely in $Q,I_{ab},\omega_{ab}$, is an instance.

`[ALG consequence]` **Uncoupled pair.** For two states of one map, $\Delta\log C_\to=\bar\mu Q_a+\mu Q_b+O(Q^2)$, so $\Delta\theta_{ab}=-\tau(Q_b-Q_a)$: the encounter residue is the difference of the two self-return residues; equal amplitudes build no relative phase at cubic order; integrating along $Q_k(t)=q_k/(1+q_kt)$ reproduces $\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ (Genesis §6.6). Genuine encounter content is the off-diagonal $\alpha$ of coupled systems (Genesis torque channels).

`[RESULT] [from: ALG]` Recurrence recognition and encounter recognition are the diagonal and off-diagonal cases of one comparator algebra through degree $p-2$; R6's unification sub-item is closed.

### §6.13 Lattice Readability, Clock, and Retained Memory `[ALG / mixed]` {#sec-6-13-lattice}

> **[Local guard SG-R10]** Invariant vs `[conv: Lie strict-kernel]` quantities are marked; $\Lambda$ is leading order.

`[ALG]` [import: Dyadic §6.9, Lie strict-kernel] $c_{32}=-\tfrac{77}{216}+i\tfrac{97\sqrt3}{648}$, $c_{05}=-\tfrac{61}{2160}-i\tfrac{43\sqrt3}{6480}$, $c_\theta^{(6)}=-\tfrac{119\sqrt3}{648}$; $47/54=|\mu|^2+2\Re c_{32}$ (Dyadic §6.5). [cert: `recog_cell_c_lattice_readability_cert.py`, 7 checks] With $W=\sqrt Qe^{i\Theta}$:
$$\chi_6=1+\mu Q+\bigl(c_{32}+c_{05}e^{-6i\Theta}\bigr)Q^2+\cdots,\qquad \log\chi_6=\mu Q+\bigl(\beta+c_{05}e^{-6i\Theta}\bigr)Q^2+\cdots,\quad\beta=c_{32}-\tfrac{\mu^2}{2}=\tfrac{5}{27}-i\tfrac{119\sqrt3}{648}.$$
$\Im\beta=c_\theta^{(6)}$ exactly (consistency with the Dyadic ledger). Recognition is phase-blind through order $Q$ and acquires sixfold angular modulation at order $Q^2$.

`[ALG]` [RID: RECOG-ALG-LATTICE-STRENGTH] $|c_{05}|=\sqrt{9759}/3240$, $|\mu|^2=19/12$; $\mathcal I_{\rm lat}:=|c_{05}|/|\mu|^2=\sqrt{9759}/5130\approx0.0192569$, invariant under $W\to cW$ (both scale as $|c|^{-4}$) and under $U(1)$-equivariant residual gauge (charge $-5$ cannot be generated from the charge $+1$ sector). Operationally, lattice amplitude / leading comparator amplitude $=\mathcal I_{\rm lat}\,|\mu|Q$. `[conv]` $|c_{05}|/|\beta|\approx0.08284$, $|c_{05}|/|\Re\beta|\approx0.1646$, $|c_{05}|/|\Im\beta|\approx0.0959$. No amplitude $Q_{\rm lat}$ at which anisotropic and isotropic quintic content cross exists (both $\propto Q^2$); the "leading-crossing" value $|\mu|/|c_{05}|\approx41.3$ is outside the local regime.

`[ALG consequence]` [RID: RECOG-ALG-LATTICE-CLOCK] $\Psi_{\rm lat}:=\arg c_{05}-6\Theta\pmod{2\pi}$ is exactly invariant under $W\to cW$ ($\tilde c_{05}=c\bar c^{-5}c_{05}$, $\tilde\Theta=\Theta+\phi$). Along the backbone $\Theta_m\approx\Theta_0-\tau\log m$, successive thresholds $\Psi_{\rm lat}=\psi_0+2\pi k$ (accumulated defect $\pi/3$ each) occur at $m_k=A(x_0,\psi_0)e^{k\pi/(3\tau)}(1+o(1))$, hence $m_{k+1}/m_k\to e^{\pi/(3\tau)}=\lambda_{\rm DSI}^{1/6}=(R^*)^{1/3}=2.476632\ldots$ [import: NUMGEN defect-threshold rate; Dyadic §6.3 constants]. Per-threshold modulation $A_{{\rm lat},k}\sim|c_{05}|/m_k^2$ fades by $\lambda_{\rm DSI}^{-1/3}$ per threshold; relative to the leading residue by $\lambda_{\rm DSI}^{-1/6}$. The prefactor is orbit- and convention-dependent at subleading order; the ratio is universal in the local $p=6$ healing sector.

`[ALG consequence, leading order]` [RID: RECOG-ALG-LATTICE-MEMORY] [cert: `recog_cell_d_lattice_memory_cert.py`, 19 checks] Let $z_m=c_{05}Q_m^2e^{-6i\Theta_m}$. The direct phase kick $\Im z_m$ and the radial kick $2Q_m\Re z_m$ (propagated through $Y=1/Q$: $\delta Y=-2\Re[Z_0(x^{6i\tau}-1)/(6i\tau)]$, fed back via $-\tau Q$) sum absolutely, giving
$$\boxed{\Lambda(Q_0,\Theta_0)=\Delta\Theta_{\rm lat}(\infty)=Q_0\,\Im\!\Bigl[\tfrac{1-2i\tau}{1-6i\tau}c_{05}e^{-6i\Theta_0}\Bigr]+O(Q_0^2)=\tfrac{Q_0}{317520}\bigl[2767\sin6\Theta_0-1219\sqrt3\cos6\Theta_0\bigr]+O(Q_0^2)},$$
with $|1-6i\tau|=7$ exactly, $\tfrac{1-2i\tau}{1-6i\tau}=\tfrac{17+4i\tau}{49}$, $\tfrac{1-2i\tau}{1-6i\tau}c_{05}=-\tfrac{2767+1219\sqrt3\,i}{317520}$. Invariant form: $\Lambda=\tfrac q\gamma\Im[\tfrac{1-2i\sigma}{1-6i\sigma}c_{05}e^{-6i\Theta_0}]+O(q^2)$, $\gamma=-2\Re\mu$, $\sigma=-\Im\mu/\gamma$ (canonical: $\gamma=1,\sigma=\tau$); $\tfrac q\gamma c_{05}e^{-6i\Theta_0}$ is exactly frame-invariant. Numerics (normal-form map with/without $c_{05}$): relative error $0.28,0.14,0.067$ at $Q_0=0.04,0.02,0.01$ — an $O(Q_0)$ correction, as expected. No retained multiplicative/$\log Q$ memory ($|\Delta\log Q|<10^{-7}$); a bounded log-periodic oscillation in $1/Q$ is not excluded. Leading amplitude $|\Lambda|\le0.010962\,Q_0$ — leading order only (R9, R10).

`[ALG consequence]` **Comparator-completeness counterexample.** Pairs $\mathcal P_\alpha$: $(Q_a,Q_b)=(q,q)$, $(\Theta_a,\Theta_b)=(\alpha,\alpha+\tfrac\pi6)$. All $\mathcal P_\alpha$ have identical comparator data ($Q_b/Q_a=1$, $\Delta\theta=\pi/6$), yet retain $\Delta\Phi_{\rm lat}(\alpha)=-2\Lambda(q,\alpha)+O(q^2)$, which depends on $\alpha$ (certified: $+2.52\times10^{-4}$ vs $-3.50\times10^{-4}$ at $q=0.02$, $\alpha=0,0.25$). `[RESULT] [from: ALG]` $(Q_a/Q_b,\Delta\theta_{ab})$ is insufficient to determine asymptotic memory once $c_{05}\ne0$; the missing datum is the lattice phase. Comparator closure fails at the memory layer, at $O(Q_0)$.

`[ALG]` **Corrected backbone for R9.** With $a=47/54$, $x=1+qm$: $Q_m=\tfrac qx-\tfrac{7}{54}q^2\tfrac{\log x}{x^2}+O(q^3)$; $\Theta_m=\Theta_0-\tau\log x+qH(x)+O(q^2)$, $H(x)=\tfrac{7\sqrt3}{81}\bigl[1-\tfrac{\log x+1}{x}\bigr]-\tfrac{335\sqrt3}{648}\bigl[1-\tfrac1x\bigr]$ (the $-\tau/2$ Euler–Maclaurin boundary of the $-\tau Q$ sum is included in the second coefficient), $H(\infty)=-\tfrac{31\sqrt3}{72}$; summand $z_m=c_{05}q^2x^{-2+6i\tau}e^{-6i\Theta_0}[1+qA(x)+O(q^2)]$, $A(x)=-\tfrac{7}{27}\tfrac{\log x}{x}-6iH(x)$; $q^2\sum_{m\ge0}(1+qm)^{-2+6i\tau}=\tfrac{q}{1-6i\tau}+\tfrac{q^2}{2}+O(q^3)$. A finite-$Q_0$ bound additionally needs the degree-$\ge7$ return remainder ($\sum Q_m^3=O(q^2)$): R10.

`[HEUR]` The factor $1/(1-6i\tau)$ has the same resolvent/alias form as the Dyadic OPEN 16 value $G_-(\pi/\tau)=1/(1-i\tau)$, at the sixth logarithmic harmonic. Structural match generated independently here; not an import (OPEN 16's full operator is open).

## §7. Import Ledger {#sec-7-imports}

- [RID: DYAD-THM-C21] :: $\mu_6=c_{21}=-\tfrac12-i\tfrac{2\sqrt3}{3}$ :: RTG_DYADIC_OSCILLATOR_DSN_v6.4.9 §6.2, §6.7 :: return defect, jet-law anchor :: p=6, K=1, conditional on postulated $T$
- [RID: DYAD-ALG-P6-FACEFLUX] :: $\lambda=e^{i\pi/3}=e^{iF_f/2}$ :: Dyadic §6.2 :: linear resonance signature; not used for derivation :: p=6 only
- [RID: DYAD-ALG-BRIDGE-LEMMA] :: $\mu_p=p\bar\lambda\nu_3^{(1,p)}$ :: Dyadic §6.2 / Genesis §6.2 :: CELL-A target :: normalised one-step frame
- [RID: (none — §6.1 block)] :: dyad map, $J$, $\det J$, $C_0$, $P_1,P_2$, escape law, non-symplecticity :: Dyadic §6.1 :: fixed points, rank stratum, $(t,d)$-plane :: primitive layer
- [RID: (none — §6.4 block)] :: $Q_c=(\arcsin\ln2)^2$, winding-index invisibility, ISP $\Theta$ :: Dyadic §6.4 :: SG-R8, distinction anchoring, $\arg W=\Theta$ :: crossing-step local
- [RID: (none — §6.7/§6.8 block)] :: $M+M^\top=-I$, $Q_{m+1}=Q_m-Q_m^2+\cdots$, $\Theta_{m+1}=\Theta_m-\tau Q_m$ :: Dyadic §6.7–6.8 :: $\chi_6$ reconstruction :: cubic-vector truncation
- [RID: (none — Genesis §6.1)] :: $\mathcal O_0=0$, first dyad $A+B=0$, $B$, $Q=r^\top Br$, $A^\top BA=B$ `[THM]` :: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.1 :: comparator construction, distinction anchoring :: p=6 eigenframe
- [RID: (none — Genesis §6.6)] :: $I_{ab}$, $\omega_{ab}$, $a^\top BJ_Qb=\tfrac{\sqrt3}{2}\omega_{ab}$, plateau phase memory :: Genesis §6.6 :: cross-comparison, memory layer :: phase convention as declared there
- [RID: NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION] :: $Q_{\rm true}(Fx)-Q_{\rm true}(x)=-Q_{\rm true}^2+O(Q_{\rm true}^{5/2})$; phase-uniform strict contraction on a small punctured sector :: RTG_NUMBER_GENESIS_DSN_v1.15 :: §6.2 local exactness; absence of nearby period-6 points :: local, p=6, conditional on $T$ (RID corrected at critique round 2; `NUMGEN-N1C-DYAD-RADIAL` names the downstream Radial Memory Test, not this theorem)
- [RID: NUMGEN-OPEN-N1C] :: wrapped-$S^1$ negative control (memoryless wrapped state collapses same-endpoint histories) and local primitive-dyad history non-collapse :: RTG_NUMBER_GENESIS_DSN_v1.15 N-1C (closed) :: §6.5 co-presence refinement :: negative control is scoped to the memoryless wrapped state; not a universal statement (confirmed at critique round 2)
- [RID: (none — Genesis §6.6 $J_Q$)] :: $J_Q=\tfrac1{\sqrt3}\begin{psmallmatrix}1&-2\\2&-1\end{psmallmatrix}$, $J_Q^\top BJ_Q=B$, $J_Q^2=-I$, sign branch fixed by convention :: Genesis §6.6 :: comparator orientation, SG-R9 :: branch-dependent sign; load-bearing properties branch-independent
- [RID: DYAD-ALG-BRIDGE-LEMMA] (general form) :: $\mu_p=p\bar\lambda\nu_3^{(1,p)}$ for all $p\ge5$ :: Dyadic §6.9; general proof supplied in §6.12 (ownership offered to Dyadic) :: §6.10 :: $K_p$ family
- [RID: (none — Dyadic §6.3)] :: $\tau$, $R^*=e^{\pi/\tau}$, $\lambda_{\rm DSI}=e^{\pi\sqrt3}$ :: Dyadic §6.3 :: lattice clock identities $\lambda_{\rm DSI}^{1/6}=(R^*)^{1/3}$ :: canonical constants
- [RID: (none — Dyadic §6.5)] :: quintic backbone $Q_{m+1}=Q_m-Q_m^2+\tfrac{47}{54}Q_m^3$; $47/54=19/12+2\Re c_{32}$ :: Dyadic §6.5 :: R9 corrected backbone :: asymptotic backbone, not one-block burst
- [RID: DYAD-ALG-LIEGAUGE-NORM; (none — §6.9 table)] :: $c_{32}$, $c_{05}$, $c_\theta^{(6)}$ in Lie strict-kernel gauge; $\Im\nu_5$ non-invariance `[FAIL]` :: Dyadic §6.9 :: §6.13 :: `[conv: Lie strict-kernel]`; SG-R10
- [RID: DYAD-ALG-ALIAS-PHASE] :: $G_-(\pi/\tau)=1/(1-i\tau)$ :: Dyadic OPEN 16 :: §6.13 `[HEUR]` cross-reference only :: not an import of $G_-^{(6)}$
- [RID: (NUMGEN defect-threshold rate — RID to confirm)] :: $D_M=\tau\log M+C_D+o(1)$; $\pi/3$-threshold first crossings $M_{k+1}/M_k\to e^{\pi/(3\tau)}$ :: RTG_NUMBER_GENESIS_DSN_v1.15 :: lattice clock rate (§6.13) :: certified on the local healing tube; RECOG adds the $c_{05}$ reading
- [RID: (archived Dyadic artifact)] :: `normalize_p7_full_onestep_cyclotomic.py` — exact $\nu_3^{(1,7)}$ (`nu3_full^(7)` renamed on import) :: Dyadic OPEN 9 tooling :: §6.10 :: one-step full sequential normalisation, not $p$-step
- [RID: OFN §6.2a, §7.3] :: open rows "why $\sin\eta$", "why exponential shear"; TDR-G band $k$ underived :: RTG_ONTOLOGICAL_FOUNDATIONS_v0.7 :: export targets for §6.4, OPEN R5 :: motivational layer, no derivation imported

RIDs marked "(none)" have no stable identifier in the source; requesting assignment there is part of the critique round.

---

## §8. Artifact and Script Registry {#sec-8-artifacts}

- [RID: RECOG-ART-SHEAR-JET-CERT] :: `recog_shear_jet_cert.py` (sha256 `e1d2444f9d8d8c940270d73df4ca20d0323504d93f89dbb2fe6da1a9a3fe48a4`) :: exact sympy six-step cubic composition with exact $\omega=\tfrac12(-1+i\sqrt3)$; 18 checks: DYAD-THM-C21 reproduction (parametrised and direct), $T_s$ (parametrised and direct), $T_{\log}$, $T_{\tanh}$, general $\mu_6(a,b)$, quadratic vanishing, $(2,1)$ confinement, completed-square rigidity and its minimum, comparator orientation, Genesis $J_Q$ properties, invariant-form uniqueness, radial-fate boundary corollary, rigidity minimiser; exit 0 on PASS :: `[ENG]` (scientific claims carry their own `[ALG]` tags in §6)
- [RID: RECOG-ART-CELL-A-P5] :: `recog_cell_a_p5_rawcomp_cert.py` (contributor; sha256 `0a87d59d600a11414fb1b26dd90ef770d3e2ae282a2e5da7b61c8ab648f84383`) :: exact $\mathbb Q(\zeta_5)$ raw five-fold composition; $\mu_5$, bridge-implied $\nu_3^{(1,5)}$; 10 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-A-P7-RAW] :: `recog_cell_a_p7_rawcomp_cert.py` (sha256 `0414f3a031a4bf9bfe2d1a7d508128114f78d2ca5a28f7b3e99823a62f1979ab`) :: raw seven-fold composition, 50 dps; independent $\mu_7$; 5 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-A2] :: `recog_cell_a2_nu3_closed_form_cert.py` (sha256 `222c964532a48e04dd37baeb86017620060b8dece250a135552b83d3e3cab2cd`) :: symbolic $h_2$ normalisation → $\nu_3(\lambda)$; exact checks mod $\Phi_5,\Phi_7$; zero-set; series; sign mesh; 11 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-B] :: `recog_cell_b_p2_manifolds.py` (contributor; sha256 `7ea5e161b9ffa244b279681a067047e66a0a477a29477d0946637694f10b216e`) :: $W^u_+(P_2)\cap C_0$ by parameterisation-limit continuation (mpmath, 90 dps); transversality; scans; 6 diagnostics :: `[ENG]` (diagnostic, not IA)
- [RID: RECOG-ART-CELL-C] :: `recog_cell_c_lattice_readability_cert.py` (contributor; sha256 `73a919e24fe5349e7a0944e4c1dc4aeb9fc7d1bd43f8d89f3e25e29ee1476083`) :: $\beta$ identity, $c_\theta$ consistency, moduli, readability fractions, sixfold axes; 7 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-D] :: `recog_cell_d_lattice_memory_cert.py` rev. 2 (sha256 `5c67805145d7aa3afa3b4402461e203a6fb3f0990726e13ceff160fc3d35d3ad`) :: $|1-6i\tau|=7$, exact transfer coefficient, orbit-difference vs closed form with $O(Q_0)$ error scaling, no $\log Q$ memory, pair tests including identical-comparator counterexample; 19 checks :: `[ENG]`
- [RID: RECOG-ART-MEMO] :: `RECOG_MEMO_TO_STREAMS_2026-09-17.md` (amended 18 Sep: §3 single enclosure deliverable) :: cross-stream handovers and requests :: `[DEF]`

---

## §9. Collaboration and Provenance {#sec-9-provenance}

**Contributors.** Mustafa (PI; ontological thesis, ratio/comparison emphasis, physics–mathematics coincidence stance) · Claude (this draft; independent certificate) · Collaborating AI contributor (spectral/return-defect formulation, swap-projection twin, shear-jet law first derivation; critique round pending).
**Archive.** none yet; to be registered with the ontology note.

| Insight | Provenance | Tag |
|---|---|---|
| Recognition framework shifted from eigenvalue to comparator + return-defect structure | contributor | `[DEF]` |
| $C(a,b)=\overline W_aW_b$ from Genesis definitions | Claude | `[ALG consequence]` |
| Only rank is pointwise chart-free; prerequisite ladder | Claude | `[ALG]` |
| Antipode as unique nontrivial swap-fixed value | Claude (swap), contributor (formalisation) | `[ALG consequence]` |
| $\rho$ swap-odd from certified $A$ | Claude ($\sin^2\eta$ route), contributor ($f'(0)$ route) | `[ALG conditional]` |
| $T=T_s+T_b$, $\mu_6^{(s)}$, $\mu_{\rm break}$ | contributor (derivation), Claude (verification) | `[ALG]` |
| Shear-jet law $\mu_6(a,b)$ | contributor (derivation), Claude (verification) | `[ALG]` |
| $\tanh$ counterexample | Claude | `[ALG]` |
| Comparator sign correction; cubic-return rigidity $|\mu_6|\ge\tfrac12$; return-germ redefinition; Number Genesis provenance; strata/ladder refinement | contributor (critique round 1) | `[ALG]` / `[DEF]` |
| Invariant-form uniqueness $H=cB$ | contributor (suggested), Claude (certificate) | `[ALG]` |
| Radial-fate boundary corollary; rigidity minimiser $\tfrac12e^{-i\pi/3}$; Number Genesis RID correction; wording/domain fixes | contributor (critique round 2) | `[ALG consequence]` |
| Event = class change; intersection principle | contributor / Mustafa (stance) | `[HYP]` (OPEN R6) |
| CELL-B: $W^u_+(P_2)\cap C_0$ continuation; negative-branch long iterates; $\det J$ lemma phrasing; B2 split | contributor (numerics), Claude (lifted itinerary correction, fundamental-domain reduction, upstream dependency) | `[NUM strong]` / `[ALG]` |
| CELL-A: $p=7$ archived normaliser run; $p=5$ exact certificate; finite ledger table | contributor | `[ALG]` |
| Raw-composition independence of the bridge; general resonant-return theorem; closed form $\nu_3(\lambda)$; empty zero set; small-$\theta$ law | Claude | `[ALG]` |
| Leading-return equivariance theorem; comparator closure; uncoupled-pair reduction; first non-comparator channel $\bar W^{p-1}$ | Claude (theorem), contributor (leading-vs-all scope, normal-form-frame scope) | `[ALG]` |
| CELL-C: $\beta$ identity, readability fractions, no $Q_{\rm lat}$, axis analysis, event-guard | contributor | `[ALG]` |
| Lattice clock ($\lambda_{\rm DSI}^{1/6}$, $R^*$ link); $\mathcal I_{\rm lat}$ | Claude; contributor (NUMGEN provenance, $\Psi_{\rm lat}$ invariance, fading law, hierarchy) | `[ALG consequence]` |
| CELL-D: retained lattice memory $\Lambda$; radial-memory vanishing; memory-version R6 hypothesis | Claude (formula, certificate), contributor ($Y=1/Q$ derivation, exact $317520$ form, identical-comparator counterexample, invariant form, D2a/D2b split, fourth remainder source, corrected backbone $H(x)$) | `[ALG consequence, leading order]` |
| Single upstream enclosure deliverable serving R8 and R10 | contributor (observation), Claude (specification) | `[DEF]` |

---

## Appendix A — Version History

### v0.3 — 18 September 2026
- **§6.10 [new, ALG]:** general resonant-return theorem for $p\ge5$; closed form $\nu_3(\lambda)$ (RECOG-ALG-NU3-CLOSED-FORM); empty unit-circle zero set (RECOG-ALG-NU3-NONVANISHING); $k_{\rm ret}(p)=3$ for all $p\ge5$; finite $p=5,7$ ledger; small-$\theta$ law $\Re\mu_p\to-\pi^2/p$. OPEN R2 closed.
- **§6.11 [new, NUM strong]:** $P_2$ manifolds — RECOG-NUM-P2-C0-FIRST with lifted itinerary $-1\to-i\to+1\to+i\to C_0$ ($278.66^\circ$), derived wrapped $81.34^\circ$; RECOG-NUM-P2-HET-NEG with fundamental-domain reduction; $\rho<0\Rightarrow\det J>0$. OPEN R3 partial; OPEN R8 opened.
- **§6.12 [new, ALG]:** RECOG-ALG-LEADING-RETURN-EQUIVARIANCE; RECOG-ALG-COMPARATOR-CLOSURE (normal-form scope); uncoupled-pair reduction; R6 unification sub-item closed.
- **§6.13 [new]:** lattice readability (CELL-C), RECOG-ALG-LATTICE-STRENGTH, RECOG-ALG-LATTICE-CLOCK ($\lambda_{\rm DSI}^{1/6}$), RECOG-ALG-LATTICE-MEMORY ($\Lambda$, exact $317520$ form, invariant form, identical-comparator counterexample); corrected backbone for R9; OPEN 16 structural cross-reference.
- **§2:** R2 CLOSED; R3 PARTIAL; R6 rewritten around the six-layer hierarchy with the memory-version `[HYP]`; R8, R9, R10 opened (R10 = single upstream enclosure deliverable).
- **§3:** SG-R10 (lattice scopes), SG-R11 (two rigidity families) added.
- **§5, §7, §8, §9:** rows/entries for all of the above; seven artifacts registered with hashes; memo registered.
- **Appendix B:** three v0.2.1-era statements superseded (see below).

### v0.2.1 — September 2026 (pre-freeze patch, critique round 2)
- **§7 [import]:** Number Genesis contraction import corrected to `NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION`; `NUMGEN-OPEN-N1C` confirmed; verification notes removed.
- **§0 [governance]:** `RECOG` prefix and Programme Overview Tier 3 (Maturity A) registration made part of this release.
- **§0, §1, §6.7 [wording]:** "recognition order is rigid" → "return-defect order is rigid" (SG-R6 consistency).
- **§6.7 [ALG consequence]:** RECOG-ALG-FATE-BOUNDARY added ($4a^2=3b\Rightarrow\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$); rigidity minimiser recorded as $\tfrac12e^{-i\pi/3}$.
- **§6.1, §6.5 [scope]:** $\widehat C$ domain $Q_aQ_b>0$ stated; comparator intrinsicness narrowed to the $P_1$ linear transport; "largest difference that remains mutual" removed.
- **§6.7 [wording]:** "saturating odd shear" → "negative cubic contribution".
- **§6.2 [SG-R1]:** ontological witness sentence removed; only the substrate statement remains.
- **§9:** stale provenance line updated.
- **§8 [ENG]:** certificate extended to 18 checks; new sha256.

### v0.2 — September 2026
- **§6.1 [COR → ALG consequence]:** comparator sign corrected: $\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ under the Genesis $J_Q$; comparator renamed $C_\to$ with explicit orientation; SG-R9 added.
- **§6.1 [ALG]:** RECOG-ALG-INVARIANT-FORM added (symmetric $A$-invariant forms are exactly $cB$), replacing the imported-as-fact wording.
- **§6.2 [COR → DEF]:** return defect redefined on the resonant return germ ($DF^p=I$ at the fixed point); $D_n$ definable for all $n$; irrational case gives undefined $k_{\rm ret}$, not $\infty$.
- **§6.2, §6.5, §7 [import]:** Number Genesis v1.15 provenance closed (NUMGEN-N1C-DYAD-RADIAL, NUMGEN-OPEN-N1C); split into two entries; negative control rescoped.
- **§6.5 [DEF]:** "event classes" → "candidate mathematical strata"; pole-level and state-level pair-symmetry separated; intrinsic conjugacy-class wording removed; intersection principle re-registered as RECOG-OPEN-INTERSECTION under OPEN R6.
- **§6.7 [COR → ALG]:** false imaginary residue floor retracted; RECOG-ALG-CUBIC-RETURN-RIGIDITY added ($|\mu_6(a,b)|\ge\tfrac12$, $k_{\rm ret}(6)=3$ across the family).
- **§6.8 [ALG]:** $\tau$ decomposition restricted to the local cubic angular coefficient; no plateau-memory decomposition claimed.
- **§6.9 [DEF]:** replaced by an Ontology Export Interface; interpretive `[HYP]` lines moved to the ontology note.
- **§2 [OPEN]:** R5 renamed "Why one-sided ratio shear?"; saturation demoted to an untestable-by-jet sub-item.
- **Governance:** `[COR-in-advance]` removed; `[ALG consequence]` alias re-expanded to `[RESULT]` `[from: ALG]`; artifact tagged `[ENG]`; non-registry RID categories (`HYP`, `SUP`) replaced; local aliases noted as not requiring methodology registration.
- **§8 [ENG]:** certificate extended to 15 checks (exact $\omega$, rigidity, direct primitive-$T$ control, comparator orientation, invariant-form uniqueness); new sha256.

### v0.1 — September 2026
- **§1–§9 [initial]:** First consolidation of the recognition branch (spectral → return defect → comparator → event strata → shear-jet law) from the September 2026 session into DSN form. All numerical claims of §6.6–6.7 certified by `recog_shear_jet_cert.py`. Import RIDs from Dyadic/Genesis partially unassigned; Number Genesis source citation unconfirmed. Draft for critique.

---

## Appendix B — Retired and Rejected Claims

**[SUPERSEDED | RID: RECOG-DEF-SPECTRAL-RECOG]** "Spectral Recognition Hypothesis": recognition $=$ eigenvalue/eigenphase of the return transport. Replaced by: §6.2 (eigenvalue is the linearised recognition multiplier; content is the first nontrivial return jet). Version: v0.1.

**[SUPERSEDED | RID: RECOG-DEF-CLOSURE-PREREQ]** "Without return the spectrum cannot be compared with itself" as a prerequisite of all recognition. Replaced by: §6.5 prerequisite ladder (closure needed for the spectral stratum only). Version: v0.1.

**[SUPERSEDED | RID: RECOG-ALG-QUADRATURE-GLOBAL]** "$\cos\eta=0$ is the unique type-change surface on the whole plane." Replaced by: §6.5 (second branch $\cos\eta=4e^\rho$ for $\rho\le-\ln4$; chart-dependent in any case). Version: v0.1.

**[SUPERSEDED | RID: RECOG-DEF-BREAK-CAUSES-HEALING]** "Healing is caused by swap-symmetry breaking." Replaced by: §6.7 radial-fate law ($4a^2>3b$; $\tanh$ heals without breaking). Version: v0.1.

**[RETRACTED | RID: RECOG-DEF-COMPARATOR-SIGN-V01]** $\overline W_aW_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}$. Reason: sign error against the certified Genesis $J_Q$ convention; direct algebra gives $-i$. Replaced by: §6.1, SG-R9. Version: v0.2.

**[RETRACTED | RID: RECOG-ALG-IM-FLOOR-V01]** "$\Im\mu_6\le-\tau/2$ across the shear family." Reason: contradicted by $\Im\mu_6^{(s)}=-\tau/4$. Replaced by: RECOG-ALG-CUBIC-RETURN-RIGIDITY (§6.7). Version: v0.2.

**[SUPERSEDED | RID: RECOG-DEF-RETURN-DEFECT-V01]** Return defect defined over an exact closed history $\gamma$. Replaced by: resonant return germ definition, §6.2. Version: v0.2.

**[SUPERSEDED | RID: RECOG-DEF-COPRESENCE-V01]** "By the history-collapse criterion a past state is not part of the present state" (universal reading of the wrapped-$S^1$ negative control). Replaced by: §6.5 scoped statement (retained relational data or current co-realisation). Version: v0.2.

**[SUPERSEDED | RID: RECOG-NUM-P2-C0-FIRST-V1]** "The first rank-loss encounter lies $8.66^\circ$ inside quadrature, toward the antipode; $81.34^\circ$ is an oriented antipode-to-rank-loss scale." Reason: the unstable branch traverses $278.66^\circ$ of lifted pole angle, crossing $-i,+1,+i$, and reaches $C_0$ $8.66^\circ$ past the second quadrature from the identity side; $81.34^\circ$ is the wrapped shadow and the offset is derived from $\rho_*$. Replaced by: §6.11. Version: v0.3.

**[SUPERSEDED | RID: RECOG-DEF-KRET-OPEN-V021]** "$k_{\rm ret}(p)$ unknown for $p\ne6$; $\mu_p=0$ possible at exceptional horizons." Replaced by: §6.10 (no cubic-silent horizon for $p\ge5$). Version: v0.3.

**[SUPERSEDED | RID: RECOG-DEF-LATTICE-ONSET-EVENT]** "A recognition event is the onset of lattice-harmonic content." Reason: onset is an order in the germ, not a locus; no $Q$-threshold exists. Replaced by: §6.13 clock and retained-memory formulation; R6 memory-version `[HYP]`. Version: v0.3.

**[SUPERSEDED | RID: RECOG-DEF-NEGATIVE-BRANCH-CONFINED]** "$W^u_-(P_2)$ stays in $\rho<0$, hence rank loss is excluded on it." Reason: the branch reaches $\rho\approx0.62$; the lemma covers only segments confined to $\rho<0$. Replaced by: §6.11. Version: v0.3.

**[SUPERSEDED | RID: RECOG-OPEN-SATURATING-SHEAR]** OPEN R5 framed as "why saturating shear". Reason: $e^\rho-1$ is unbounded for $\rho\to+\infty$; the cubic jet cannot test saturation. Replaced by: RECOG-OPEN-ONESIDED-SHEAR. Version: v0.2.

**[FAIL | RID: RECOG-FAIL-K-FROM-SADDLE]** Derive the antipodal band width $k$ from the $P_2$ saddle spectrum alone. Reason: eigenvalues fix width–lifetime scaling, not width; invariant under local rescaling. Closed: v0.1.

---

*END OF DOCUMENT — RTG_RELATIONAL_RECOGNITION_DSN_v0.3*
