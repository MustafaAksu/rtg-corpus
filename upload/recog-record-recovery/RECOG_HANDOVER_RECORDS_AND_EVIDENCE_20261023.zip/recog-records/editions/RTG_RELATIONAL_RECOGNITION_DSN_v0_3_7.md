# RTG_RELATIONAL_RECOGNITION_DSN_v0.3.7

**Title:** RTG Relational Recognition Study — Comparators, Return Defect, and Event Strata on the Dyadic Substrate
**Date:** 30 September 2026 (v0.3.7)
**Scope:** Substrate-level mathematics of *recognition* — how a relational distinction is compared with its transported self or with another distinction, what residue a closed history leaves, and which loci of the comparator/transport geometry qualify as candidate recognition events — worked on the postulated continuous dyad generator $T$ and its diagnostic shear twins. Ontological readings are carried as `[HYP]` only.
**Supersedes:** `RTG_RELATIONAL_RECOGNITION_DSN_v0.3.6` (frozen, sha256 `fc790fad…16eb`; R6 identifiability audit here) · v0.3.5 (frozen, sha256 `3ba74002…abd6`) · v0.3.4 (frozen, sha256 `39665f89…80df`) · v0.3.3 (frozen 26 Sep 2026, sha256 `701d56ac…decb`) · v0.3.2 (frozen 25 Sep 2026) · v0.3.1 (frozen 19 Sep 2026) · v0.3 · v0.2.1 · v0.2 · v0.1
**Companion documents:** `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10` (adopted 24 Sep 2026; supersedes v6.4.9 for all imports below) · `RTG_GENESIS_GEOMETRY_DSN_v2.8.4` · `RTG_NUMBER_GENESIS_DSN_v1.20.4` · `RTG_ONTOLOGICAL_FOUNDATIONS_v0.7` · `RTG_DISCRETE_GENESIS_DSN_v2.12.13` (reference only, no import) · `DSN_METHODOLOGY_v1.3`
**DSN Methodology:** DSN_METHODOLOGY_v1.3 (current adopted edition; `RECOG | RTG Relational Recognition` confirmed in its namespace registry)
**Programme tier:** Tier 3 — Continuous Programme, downstream of Dyadic and Genesis (see Programme Overview §6). Study prefix `RECOG` registration **confirmed** in the owner records: DSN_METHODOLOGY_v1.3 namespace registry and Programme Overview v1.2 Tier 3 (the Programme entry still selects RECOG v0.3; updating its selected edition/status is ordinary programme synchronisation).


**Status summary (v0.3.7):** R6's first cell (CELL-F1, §6.16) is registered. `[RESULT]` RECOG-RESULT-EVENT-UNDERDETERMINATION: the certified package does not determine a unique physical-event predicate — retained non-comparator memory without rank loss is theorem-grade (R9 window inside the rank-safe tube), a lattice threshold does not by definition mark a dynamical class change, equal clock ratios with the Number Genesis 7-gap stream are not an identification, and rank events have no registered retained witness. Representation safety: the rank locus is chart-invariant; the limiting R9 pair phase is asymptotically track-independent; individual lattice thresholds are gauge-dependent (only the clock ratio is invariant); the 7-gap's relation to RECOG charts is unestablished. `[DEF candidate]` RECOG-DEF-EVENT-TOKEN-SCHEMA (representation safety, nongenericity, finite witnessability, dynamical distinction, consequence type R/E/N) is registered as a test schema, not adopted. R6 stays ACTIVE; next F2(b) (eventwise 7-gap vs lifted phase-lag crossings, `[NUM]`), then F2(c0) (Whitney-fold certificate at $x_*$). No scientific result of v0.3.6 changes.

**Status summary (v0.3.6):** R7's first active item is closed at theorem grade. `[THM]` [RID: RECOG-THM-TWIN-RADIAL-ACCESS] [scope: diagnostic twin $T_s$ (SG-R4), conditional on its definition; lifted primitive chart] For every $x$ with $0<Q(x)<\tfrac7{200}$ there is $n\ge0$ with $|\rho(T_s^nx)|\ge\operatorname{arccosh}2$. The uniform bound $n\le256$ holds only for the leg from the annulus $\mathcal A=\{\tfrac7{200}\le Q<\tfrac{58107}{1600000}\}$ to the threshold; from arbitrary small $Q_0$ the number of six-step blocks needed to reach $\mathcal A$ is finite for each orbit but unbounded as $Q_0\to0$. No claim about $D_s<0$, first hits, or the rank locus $C_0^{(s)}$ itself. [proof: `[ALG]` E2A phase-uniform raw-frame expansion + E2B exact annulus entry + `[ALG via IA]` E2C certified annular transport] Evidence chain: CELL-E1 `[NUM]` survey (all interior sampled twin seeds, $r_0\in\{0.03,0.02,0.01\}$, leave the local disk on the predicted $1/Q_0$ schedule; the $r_0=0.05$ family starts on the boundary; all 480 sampled seeds enter $D_s\le0$; primitive $T$ control never does); E2A certifies $Q+c_-Q^2\le Q(T_s^6x)\le Q+c_+Q^2$ with $c_->\tfrac{19}{20}$, $c_+<\tfrac{43}{40}$ on $0<Q\le\tfrac1{25}$ using exact oddness (no normalizer); E2B gives exact entry into $\mathcal A$; E2C certifies all $131{,}072$ tiles of the half-annulus ($130{,}965$ directly, $107$ budget-exhausted parents by exact $2\times2$ local refinement, $428$ children), gate v2 PASS. R7 is now PARTIAL: the twin $Q_c$-type threshold remains open; entry into $D_s<0$ (Stage 2) and accessibility of $C_0^{(s)}$ itself (IVT/root) are not claimed. **OPEN census:** R2, R8, R9, R10, R11 CLOSED; R1, R3 ($W^s(P_2)$ only), R7 (first item closed) PARTIAL; R4, R5, R6 ACTIVE. Priority frontier: R6, with R7 Stage 2 optional.

**Status summary (v0.3.5):** The positive unstable branch of $P_2$ is promoted to theorem grade. `[THM]` [RID: RECOG-THM-P2-C0-FIRST] [scope: conditional on postulated continuous generator $T$] Parametrise $W^u_+(P_2)$ outward from $P_2$. There exists a unique first outward parameter value $p_*$ at which $W^u_+(P_2)$ meets $C_0$; $\det DT>0$ at every earlier branch point, and the first encounter is transverse; $(\rho_*,\eta_*^{\rm lift})\in B_*=\bigl(\tfrac{101667}{50000},\tfrac{101671}{50000}\bigr)\times\bigl(\tfrac{5003}{625},\tfrac{80059}{10000}\bigr)$, i.e. $2.03334<\rho_*<2.03342$, $8.0048<\eta_*^{\rm lift}<8.0059$. No assertion about later re-intersections. [proof: `[ALG]` R8 quadratic cusp + `[ALG via IA]` unstable-cone lemma + `[ALG via IA]` Lohner+tangent transport and root isolation] Corollary `[THM]`: $\eta_*^{\rm lift}>5\pi/2$ and $278.64^\circ<\eta_*^{\rm lift}-\pi<278.70^\circ$; by continuity the branch hits $\widehat C_{\rm pole}=-i,\,+1,\,+i$ before $C_0$, in that first-hit order (monotonicity of $\eta$ remains `[NUM strong]`; "each value crossed exactly once" is not claimed). **Both unstable futures of the antipodal saddle are now theorem-grade:** $W^u_-(P_2)\to P_1$ with $W^u_-(P_2)\cap C_0=\varnothing$ (RECOG-THM-P2-HET), and $W^u_+(P_2)$ reaches $C_0$ at its unique first transverse encounter (RECOG-THM-P2-C0-FIRST). R3 remains PARTIAL only for the global geometry of $W^s(P_2)$. **OPEN census:** R2, R8, R9, R10, R11 CLOSED; R1 PARTIAL; R3 PARTIAL ($W^s(P_2)$ only); R4, R5, R6, R7 ACTIVE. Priority frontier: R7, then R6. Certificate `recog_cell_b3_p2_c0_first.py` + `b3_cert.json` (§8).

**Status summary (v0.3.4):** OPEN R9 is CLOSED at theorem grade. The retained memory is defined intrinsically on a single orbit of the delivered exact map — the asymptotic phase $\Psi=\Theta-\tau\log q$, $M(z_0)=\Psi_\infty-\Psi(z_0)$ — with no lattice-free comparison dynamics. `[THM]` [RID: RECOG-THM-R9-MEMORY] [scope: conditional on postulated $T$; exact normalised return $\widehat F$ in the DYAD-ALG-NF6 chart; comparator track $C_z$] For $0<q_0\le q_{\max}$: $M(z_0)=q_0[c_{\rm iso}+\Lambda_1(\Theta_0)]+R$, $|R|\le C_2q_0^2$, with $c_{\rm iso}=-\tfrac{4\sqrt3}{27}$, $\Lambda_1(\Theta)=\tfrac{43\sin6\Theta-5611\sqrt3\cos6\Theta}{1270080}$; rows (not mixed): $(C_2,q_{\max})=(517,\tfrac1{400})$ on $|z|\le\tfrac1{20}$, $(163,\tfrac1{1600})$ on $|z|\le\tfrac1{40}$. Corollary `[THM]`: two orbits with identical $C_z$ data retain different asymptotic pair phases whenever $q_0<|G|/C_2$ ($1.48\times10^{-5}$ / $4.69\times10^{-5}$ on the two rows) — the non-comparator memory witness of R6 is now theorem-grade on that smaller window; its reading as a physical event remains `[HYP]`. Proof by an averaging function (§6.13a), certificate `recog_cell_r9_memory_cert.py`. **OPEN census:** R8, R9, R10, R11 CLOSED (R2 closed at v0.3). Still open: R1 PARTIAL (primitive status of oriented $\rho$ and of pole-swap covariance); R3 PARTIAL (positive-branch $C_0$ encounter IA promotion; global $W^s(P_2)$ geometry); R4 ACTIVE (intrinsic type-change counterpart; global periodic-orbit inventory); R5 ACTIVE (origin of the one-sided exponential shear); R6 ACTIVE (physical event rule); R7 ACTIVE (shear-twin accessibility). **Priority next-work frontier:** R3, R6, R7 — not the only remaining OPENs.

**Status summary (v0.3.3):** OPEN R8 is CLOSED at theorem grade. `[THM]` [RID: RECOG-THM-P2-HET] [scope: conditional on postulated continuous generator $T$] $W^u_-(P_2)\setminus\{P_2\}\subset\mathcal B(P_1)$. [proof: `[ALG]` local quadratic-cusp shell + `[ALG via IA]` Arb/Lohner finite transport + import DYAD-THM-PRIM-CTR] Corollary `[THM]`: $W^u_-(P_2)\cap C_0=\varnothing$. The negative unstable branch of the antipodal saddle is captured by the healing attractor and never meets the rank stratum. Certificate: 4096 Arb-validated pieces covering the local shell, entry after 3655–3673 primitive steps into $U=\{0<Q_{\rm prim}\le\tfrac1{625}\}$, $\min\inf\det DT=0.13665$, exit-coded gate PASS (§6.11, §8). The positive branch (first $C_0$ encounter) remains `[NUM strong]`; the two-future picture of $P_2$ is therefore mixed `[THM]`/`[NUM strong]`. Next: R9.

**Freeze status:** v0.3.7 freeze candidate, 30 Sep 2026; supersedes frozen v0.3.6 (`fc790fad…16eb`). The final freeze hash is recorded by the external release record after the consistency pass. *Earlier freeze history:* v0.3.6 freeze candidate, 30 Sep 2026; supersedes frozen v0.3.5 (`3ba74002…abd6`). The final freeze hash is recorded by the external release record after the consistency pass. *Earlier freeze history:* v0.3.5 freeze candidate, 28 Sep 2026; supersedes frozen v0.3.4 (`39665f89…80df`). The final freeze hash is recorded by the external release record after the consistency pass, not by this document. *Earlier freeze history:* v0.3.1 frozen 19 Sep 2026. **v0.3.2 (25 Sep 2026) is a scope patch, not a reopening:** it accepts the Dyadic v6.4.10 local return-enclosure package as consumer, fills the R11 ledger in the owner's $h$-chart, and restates R8/R9/R10 accordingly. No RECOG scientific result of v0.3.1 is changed; the v0.3 backbone paragraph is retired (Appendix B).

**Status summary (v0.3.2):** Dyadic v6.4.10 §6.14 delivered, owner-adopted, the single upstream object RECOG R10 asked for: an exact degree-six polynomial conjugacy chart $W=h(z,\bar z)$ with six-step jet $J=z+\mu z^2\bar z+a_{32}z^3\bar z^2+a_{05}\bar z^5$ (`DYAD-ALG-NF6`), the raw-$c_{05}$ obstruction (`DYAD-ALG-NF6-OBS`), primitive contraction with a six-phase invariant tube $(108,\tfrac1{400},\tfrac1{625},\tfrac12)$ (`DYAD-THM-PRIM-CTR`), a quantitative inverse chart (`DYAD-THM-NF-INV`) and radius-indexed remainders $C_7=100/30$, $C_D=1000/250$ on $|z|\le\tfrac1{20}/\tfrac1{40}$ (`DYAD-THM-NF-REM`), plus normalised one-orbit contraction $\sum_mq_m^3\le2q_0^2$. RECOG accepts these (§7) and, per Dyadic SG-19, owns the final-chart ledger (R11): chart-native laws derived from $J$ — $q'=q-q^2+[\tfrac{245}{216}+2\Re(a_{05}e^{-6i\Theta})]q^3+O(q^4)$, $\Delta\Theta=-\tau q+[\tfrac{89\sqrt3}{324}+\Im(a_{05}e^{-6i\Theta})]q^2+O(q^3)$ — with two typed comparator tracks ($C_z=\bar z_az_b$ native; $C_W^{(h)}=\overline{h(z_a)}h(z_b)$ transported), the exact swap object $S_h$, and an explicit refusal of $\tfrac{47}{54}$, $c_\theta^{(6)}$, $a_1$, $a_2$ as chart inputs (§6.14, cert. `recog_r11_chart_ledger_cert.py`). Consequences: R9 now has an explicit degree-7 budget $2C_7q_0^2$ and the leading lattice memory is the dominant term only for $q_0\lesssim4\times10^{-5}$ ($C_7=100$) / $1.3\times10^{-4}$ ($C_7=30$); R8's entry target is the primitive tube $Q_{\rm prim}\le\tfrac1{625}$, with hand-over to normalised contraction via $\widehat U_T\subset\{|z|<\tfrac1{20}\}$; R10 is delivered and accepted. Representation typing follows the RRF Registry convention (noncanonical, cited for convention only). Physical pole relabeling (RRF OPEN-A) and network transfer (SG-R5) remain open.

**Status summary (v0.3.1):** External audit of v0.2.1/v0.3 (two rounds) accepted in full. Principal scientific correction: the quintic coefficients used in CELL-C/CELL-D (v0.3) were the *raw* six-step coefficients of Dyadic §6.9, in whose frame a nonzero quartic jet is present; the normal-form (post-$H_2$) values are $c_{32}=-\tfrac{97}{432}+i\tfrac{197\sqrt3}{324}$, $c_{05}=-\tfrac{49}{8640}-i\tfrac{307\sqrt3}{25920}$, the latter confirmed by the Dyadic one-step ledger through the bridge $6\bar\lambda\nu_5^{(1,6)}$. All lattice numbers are restated in that frame (§6.13); the mechanism, the clock ratio and the identical-comparator counterexample are unchanged, the coefficients are not. Domain corrections: winding fixed points on the wrapped cylinder, lifted-chart convention for $W$, continuous extension $\chi_6(0):=1$, raw-frame remainder $O(Q^{3/2})$, chart-free determinant sign, plateau memory retagged `[ALG structure]`. New exact identity: $\Re(\bar\lambda\nu_3)=-\sin^2(\theta/2)$, hence $\Re\mu_p=-p\sin^2(\pi/p)$. OPEN R11 (quintic-frame reconciliation with Dyadic) opened; R10 depends on it.

**Status summary (v0.3):** Settled since v0.2.1: (i) the general resonant-return theorem — for every $p\ge5$ the six-step-type return defect is cubic and confined to $Z^2\bar Z$, with closed form $\nu_3(\lambda)=-\tfrac{\lambda^5-\lambda^4-\lambda^3-2\lambda^2+1}{2(\lambda-1)(\lambda+1)(\lambda^2+\lambda+1)}$ whose numerator has no root on the unit circle, hence $k_{\rm ret}(p)=3$ for the whole $p$-family (OPEN R2 closed); (ii) leading-return equivariance and comparator closure through degree $p-2$, with the first non-comparator channel $\bar W^{p-1}$; (iii) for $p=6$ the certified lattice harmonic $c_{05}\ne0$ yields a lattice-readability clock $m_{k+1}/m_k\to\lambda_{\rm DSI}^{1/6}$ and a finite retained lattice phase memory $\Lambda(Q_0,\Theta_0)$ that is not determined by comparator data (identical comparator data, different retained memory — certified counterexample); (iv) `[NUM strong]` $P_2$ manifold geometry: the positive unstable branch reaches the rank stratum after a $278.66^\circ$ lifted pole excursion crossing $-1\to-i\to+1\to+i$, and the negative branch enters the $P_1$ healing regime within 12 steps from its fundamental domain. Blocked upstream: heteroclinic certification (B2) and finite-$Q_0$ lattice-memory bound (D2b) both wait on one Dyadic deliverable — an explicit local enclosure of the six-step return germ. The recognition-event rule (R6) remains open but now has an operational endpoint.

**Status summary (v0.2.1, retained):** Settled: the state comparator $C_\to(a,b)=\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ is an exact consequence of certified Genesis/Dyadic definitions (conjugate orientation to the Genesis $+$ convention); the six-step return multiplier $\chi_6=1+\mu_6Q+O(Q^2)$ is its diagonal specialisation; the swap-projection decomposition $T=T_s+T_b$, the shear-jet law $\mu_6(a,b)=3b-4a^2-i\sqrt3(\tfrac13+2a^2-b)$, and the cubic-return rigidity $|\mu_6(a,b)|\ge\tfrac12$ (hence the return-defect order $k_{\rm ret}(6)=3$ is rigid across the whole real shear-jet family, while return content and radial fate are shear-selected) are exact and certified. Active: the radial swap-parity definition, the $p\mapsto k_{\rm ret}(p)$ map (CELL-A), and the $P_2$ band-scale geometry (CELL-B). Open at v0.2.1: the physical recognition-event rule, an intrinsic type-change locus, and the origin of the one-sided ratio shear. Nothing in this document is an ontological theorem; substrate results feed the ontology note under SG-R1.

## Local Tag Aliases

| Local alias | Expands to | Used for |
|---|---|---|
| `[ALG consequence]` | `[RESULT]` `[from: ALG]` [scope: exact consequence of imported certified definitions] | comparator identities that follow from Genesis/Dyadic `[DEF]`/`[THM]` lines (Number Genesis practice) |
| `[ALG conditional]` | `[ALG]` [scope: exact under explicitly listed assumptions] | selection lemma, radial parity |
| `[ALG diagnostic]` | `[ALG]` [scope: diagnostic twin, not a generator candidate] | shear twins $T_s$, $T_{\log}$, $T_{\tanh}$ |

---

## §1. Current Canonical State {#sec-1-state}

**Comparators.** `[DEF]` Two comparators are distinguished and must not be substituted for one another (SG-R2): the *pole comparator* $C_{\rm pole}(A,B)=e^{i\eta}$ between the two poles of one dyad, and the *state comparator* $C_\to(a,b)=\overline W_aW_b$ between two dyad states in the canonical $p=6$ eigenframe $W=\rho+\omega\eta$. `[ALG consequence]` $C_\to(a,b)=a^\top Bb-i\,a^\top BJ_Qb=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ with the certified Genesis $J_Q$ (the conjugate orientation of the Genesis $I+i\tfrac{\sqrt3}{2}\omega$ pairing). `[ALG]` [RID: RECOG-ALG-INVARIANT-FORM] Every symmetric $H$ with $A^\top HA=H$ is $H=cB$; so $C_\to$ is the canonical local comparator induced by the $p=6$, $P_1$ linear transport, up to scale and complex conjugation (SG-R9). $\widehat C$ is defined only for $Q_aQ_b>0$. `[ALG consequence]` Normalised, $\widehat C=C/\sqrt{C(a,a)C(b,b)}=e^{i\theta_{ab}}\in U(1)$, and pair swap acts as $\widehat C\mapsto\widehat C^{-1}$; swap-fixed values are exactly $\widehat C=\pm1$.

**Return defect.** `[DEF]` For a resonant return germ — $F^p$ with identity linear part at the reference fixed point — the return defect is $D_p=F^p-\mathrm{id}$; the return order $k_{\rm ret}(p)$ is the degree of its first nonzero homogeneous term modulo near-identity conjugacy. `[ALG]` [import: Dyadic §6.7 | DYAD-THM-C21] For $p=6$: $k_{\rm ret}=3$, $J_3(W)=\mu_6|W|^2W$, $\mu_6=-\tfrac12-i\tfrac{2\sqrt3}{3}$. `[ALG consequence]` $\chi_6(W)=C_\to(W,T^6W)/C_\to(W,W)=1+\mu_6Q+O(Q^{3/2})$ (raw $W$; $O(Q^2)$ post-$H_2$): the eigenvalue is the linearised recognition multiplier; $\chi$ is the diagonal case of $C$. `[ALG]` In the raw eigenframe $T^6(W)=W+\mu_6QW+O(|W|^4)$ and $\chi_6=1+\mu_6Q+O(Q^{3/2})$ (the $O(Q^2)$ remainder holds post-$H_2$, §6.2); $\chi_6(0):=1$ by continuous extension. In a small punctured neighbourhood of $P_1$, $|\chi_6|<1$, hence no nontrivial period-6 points; the recognition content of $p=6$ lives entirely in the nonlinear return germ, not in periodic-orbit spectra.

**Fixed points and swap.** `[ALG]` Zero-winding fixed points $\{P_1,P_2\}$; on the wrapped cylinder there are additional winding fixed points $(\log(1+2\pi k),0),(\log(1+2\pi k),\pi)$, $k\ge1$ (§6.3); $P_1$: $\widehat C_{\rm pole}=+1$, elliptic; $P_2$: $\widehat C_{\rm pole}=-1$, hyperbolic. `[ALG conditional]` Under pole-swap covariance `[HYP]` and the certified linearisation $A$, $\rho$ must be swap-odd. `[ALG conditional]` Under the same covariance plus periodicity, $f(0)=f(\pi)=0$ and lowest-harmonic minimality, the radial forcing is $f(\eta)\propto\sin\eta$.

**Shear decomposition and jet law.** `[ALG]` $T=T_s+T_b$ with $T_s=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta)$ the exact swap-odd projection and $T_b=(0,\cosh\rho-1)$ the entire non-equivariant content; $T_b$ is the only quadratic term of the primitive jet. `[ALG]` [RID: RECOG-ALG-SHEAR-JET] For $g(\rho)=\rho+a\rho^2+b\rho^3+O(\rho^4)$, radial row $\rho'=\rho-\sin\eta$:
$$\boxed{\mu_6(a,b)=3b-4a^2-i\sqrt3\left(\tfrac13+2a^2-b\right)}.$$
Healing $\iff 4a^2>3b$. `[ALG]` [RID: RECOG-ALG-CUBIC-RETURN-RIGIDITY] $|\mu_6(a,b)|^2=12\bigl(b-\tfrac32a^2-\tfrac1{12}\bigr)^2+\tfrac14(2a^2+1)^2\ge\tfrac14$, hence $\mu_6(a,b)\ne0$ and $k_{\rm ret}(6)=3$ for every real $(a,b)$. `[ALG diagnostic]` $\mu_6^{(s)}=\tfrac12-i\tfrac{\sqrt3}{6}$ (expansive), $\mu_6^{(\log)}=-i\tfrac{\sqrt3}{3}$ (radially neutral), $\mu_6^{(\tanh)}=-1-i\tfrac{2\sqrt3}{3}$ (healing, swap-symmetric). `[ALG consequence]` On the radial-fate boundary $4a^2=3b$: $\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$, purely angular and nonzero; at the rigidity minimiser $\mu_6(0,\tfrac1{12})=\tfrac12e^{-i\pi/3}$. `[RESULT]` `[from: ALG]` Within the shear-jet family the return-defect order is rigid — no member delays the first return defect beyond cubic order — while the return content ($\Re\mu$, $\arg\mu$) and hence the radial fate (healing / neutral / expansion) are shear-selected; the fate can change class with $k_{\rm ret}$ unchanged and an angular residue surviving. Healing does **not** require swap-symmetry breaking.

**Candidate strata.** `[DEF]` Three candidate mathematical strata with a prerequisite ladder: rank stratum ($\det DF_x=0$; one state), pair-symmetry stratum ($\widehat C=\pm1$; pole level: primitive co-presence of $A,B$; state level: co-present states or retained self-comparison), loop/spectral stratum ($(\operatorname{tr}M_n,\det M_n)$; closed transport). `[ALG]` Of single-step Jacobian invariants, rank and the sign of $\det DF_x$ are pointwise chart-free on a connected chart; eigenvalue type is not. `[OPEN]` [RID: RECOG-OPEN-INTERSECTION] Recognition event $=$ nontrivial algebraic stratum $\cap$ dynamically distinguished stratum — realised by $P_2$, but in the dyad this coincidence is built in, not discovered (§6.5).

**Resonant-return family ($p\ge5$).** `[ALG]` [RID: RECOG-ALG-LEADING-RETURN-EQUIVARIANCE] If $F^p=\mathrm{id}+G_k+\cdots$ is tangent to identity with $L^p=I$, then $LG_k=G_k\circ L$ (from $F\circ F^p=F^p\circ F$). `[ALG]` [scope: resonant normal-form frame] [RID: RECOG-ALG-COMPARATOR-CLOSURE] Charge selection $\#W-\#\bar W\equiv1\pmod p$ forces literal charge $1$ through degree $p-2$; the return content is then a polynomial in $Q_a$ and $C_\to(a,b)$ for any number of modes; degree $p-1$ admits the first non-comparator channel $\bar W^{p-1}$. `[ALG]` [import: DYAD-ALG-BRIDGE-LEMMA, general form] For $p\ge5$: $[F_p^p-\mathrm{id}]_2=0$, $[F_p^p-\mathrm{id}]_3=p\bar\lambda\nu_3^{(1,p)}Z^2\bar Z$. `[ALG]` [RID: RECOG-ALG-NU3-CLOSED-FORM] $\nu_3(\lambda)$ as in the status summary; verified exactly mod $\Phi_5,\Phi_7$, by raw composition for $p=5\ldots12$, and $6\bar\lambda\nu_3(\zeta_6)=3\mu_6^{W}$. `[ALG]` [RID: RECOG-ALG-NU3-NONVANISHING] numerator $N$ has $\gcd(N,\lambda^5N(1/\lambda))=1$ and $\gcd(N,\Phi_p)=1$ for all $\varphi(p)\le5$, hence $k_{\rm ret}(p)=3$ for every $p\ge5$. `[ALG]` $\Re(\bar\lambda\nu_3(e^{i\theta}))=-\sin^2(\theta/2)$ exactly, hence $\Re\mu_p=-p\sin^2(\pi/p)<0$ for all $p$ in the $Z$-frame: healing for every $p$, $\Re\mu_p\sim-\pi^2/p$, $\arg\mu_p$ monotone toward $-90^\circ$ ($-120.96^\circ,-113.41^\circ,-108.33^\circ$ at $p=5,6,7$; `[OBS finite-p]`).

**Lattice readability, clock, memory ($p=6$).** `[ALG]` [frame: post-$H_2$ six-step normal form] $\chi_6=1+\mu Q+(c_{32}+c_{05}e^{-6i\Theta})Q^2+\cdots$ with $c_{32}=-\tfrac{97}{432}+i\tfrac{197\sqrt3}{324}$, $c_{05}=-\tfrac{49}{8640}-i\tfrac{307\sqrt3}{25920}$ (derived from the primitive map with the Dyadic $h_2$; §6.13). `[ALG]` [RID: RECOG-ALG-LATTICE-STRENGTH] $\mathcal I_{\rm lat}=|c_{05}|/|\mu|^2\approx0.013443$ (linear-frame and $U(1)$-equivariant-residual-gauge invariant). `[ALG consequence]` [RID: RECOG-ALG-LATTICE-CLOCK] $\Psi_{\rm lat}=\arg c_{05}-6\Theta$ is invariant under linear frame changes (not under nonlinear equivariant gauge, SG-R10); successive lattice thresholds along a healing orbit satisfy $m_{k+1}/m_k\to e^{\pi/(3\tau)}=\lambda_{\rm DSI}^{1/6}=(R^*)^{1/3}\approx2.4766$ (rate imported from NUMGEN defect-threshold theorem); per-threshold modulation fades as $\lambda_{\rm DSI}^{-1/3}$. `[ALG consequence, leading order]` [RID: RECOG-ALG-LATTICE-MEMORY] $\Lambda(Q_0,\Theta_0)=\tfrac{Q_0}{1270080}[43\sin6\Theta_0-5611\sqrt3\cos6\Theta_0]+O(Q_0^2)$ (post-$H_2$ frame); no retained $\log Q$ memory. `[THM]` In the delivered exact $\widehat F$, $M=q_0[c_{\rm iso}+\Lambda_1(\Theta_0)]+O(q_0^2)$ with explicit row-dependent bounds; on the $C_z$ track, identical comparator data can retain different asymptotic pair phases for $q_0<|G|/C_2$ (§6.13a).

**$h$-chart ledger (R11, v0.3.2).** `[ALG]` [import: DYAD-ALG-NF6, DYAD-THM-NF-REM] [cert: `recog_r11_chart_ledger_cert.py`] In the owner's conjugacy chart, finite-jet identities from $J$: $|J|^2=q-q^2+[\tfrac{245}{216}+2\Re(a_{05}e^{-6i\Theta})]q^3+O(q^4)$ with $\tfrac{245}{216}=|\mu|^2+2\Re a_{32}$; $\arg(J/z)=-\tau q+[\tfrac{89\sqrt3}{324}+\Im(a_{05}e^{-6i\Theta})]q^2+O(q^3)$ with $\tfrac{89\sqrt3}{324}=\Im(a_{32}-\mu^2/2)$ — opposite in sign to the archival $c_\theta^{(6)}$, which is therefore not transferred. Two comparator tracks: $C_z(a,b)=\bar z_az_b$ (native, exactly $(-I)$-covariant) and $C_W^{(h)}(a,b)=\overline{h(z_a)}h(z_b)=\bar z_az_b+\overline{h_2(z_a)}z_b+\bar z_ah_2(z_b)+O(4)$ (transport of the canonical Genesis comparator); $q\ne Q_{\rm prim}=|h(z)|^2$ ($Q_{\rm prim}=t^2-\tfrac34t^3+\ldots$ on the real ray). Exact swap object $S_h=h\circ(-I)\circ h^{-1}$; $\mathcal J_{\le6}(f\circ S_h-S_hf)=0$ only; canonical comparator covariance defect $C_W(S_ht,S_ht)-C_W(t,t)=\tfrac32t^3+O(t^4)$.

**$P_2$ manifold geometry.** `[THM]` [RID: RECOG-THM-P2-C0-FIRST] [scope: conditional on postulated continuous generator $T$] Parametrise $W^u_+(P_2)$ outward from $P_2$. There exists a unique first outward parameter value $p_*$ at which $W^u_+(P_2)$ meets $C_0$; $\det DT>0$ at every earlier branch point, and the first encounter is transverse; $(\rho_*,\eta_*^{\rm lift})\in B_*=\bigl(\tfrac{101667}{50000},\tfrac{101671}{50000}\bigr)\times\bigl(\tfrac{5003}{625},\tfrac{80059}{10000}\bigr)$, i.e. $2.03334<\rho_*<2.03342$, $8.0048<\eta_*^{\rm lift}<8.0059$. No assertion about later re-intersections. [proof: `[ALG]` R8 quadratic cusp + `[ALG via IA]` unstable-cone lemma + `[ALG via IA]` Lohner+tangent transport and root isolation] Historical `[NUM strong]` evidence [RID: RECOG-NUM-P2-C0-FIRST]: high-precision point $(2.03336\ldots,8.00517\ldots)$, lifted excursion $278.66^\circ$ in the $\ell=1$ sector (now certified in $(278.64^\circ,278.70^\circ)$), first-hit itinerary $-1\to-i\to+1\to+i\to C_0$ (now `[THM]` as first-hit order); wrapped $81.34^\circ$ is derived. `[NUM strong]` [RID: RECOG-NUM-P2-HET-NEG] The sampled fundamental domain $S=P_u([-\lambda_u,-1])$ and its forward images cover the $t\le-1$ portion of the branch and enter $Q<0.3$ within 12 steps with $\det J>0$; this historical evidence is superseded as the basis of the heteroclinic claim by the theorem: `[THM]` [RID: RECOG-THM-P2-HET] [scope: conditional on postulated continuous generator $T$] $W^u_-(P_2)\setminus\{P_2\}\subset\mathcal B(P_1)$. [proof: `[ALG]` local quadratic-cusp shell + `[ALG via IA]` Arb/Lohner finite transport + import DYAD-THM-PRIM-CTR] Corollary `[THM]`: $W^u_-(P_2)\cap C_0=\varnothing$. (§6.11). `[ALG]` $\rho<0\Rightarrow0<\det J<2$.

**Three-layer mapping.** `[ALG consequence]` comparison $\leftrightarrow C_\to(a,b)$; closure defect $\leftrightarrow\mu_6$; persisted memory $\leftrightarrow\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ (Genesis plateau bridge). These are distinct certified objects; recognition $\ne$ closure defect $\ne$ memory.

---

## §2. Active Frontier / OPEN Registry {#sec-2-open}

---
**OPEN R1 — Radial swap parity** [RID: RECOG-OPEN-RHO-PARITY]

Status: PARTIAL
Owner branch: this document
Exports to: RTG_ONTOLOGICAL_FOUNDATIONS (definition request)

Closed sub-items:
- Under pole-swap covariance and certified $A$, swap-even $\rho$ is excluded ($f'(0)=-1\ne0$) :: `[ALG conditional]` ✓

Active sub-items:
- Adopt $\rho$ as oriented (log-ratio-type) relational coordinate as a primitive `[DEF]` in OFN :: `[OPEN]`
- Status of pole-swap covariance itself as a primitive principle :: `[HYP]`

Dependencies:
- §6.4, §6.5
---

---
**OPEN R2 — CELL-A: return order across the $p$-family** [RID: RECOG-OPEN-KRET-P]

Status: **CLOSED (v0.3)**
Owner branch: this document → general theorem recommended for Dyadic ownership

Closed sub-items:
- $\nu_3^{(1,5)}=(12-\lambda+\lambda^2+8\lambda^3)/10$, $\nu_3^{(1,7)}=(12-4\lambda+\lambda^2+6\lambda^3-3\lambda^4+9\lambda^5)/14$ exact; $\mu_5,\mu_7\ne0$ :: `[ALG]` ✓ (two routes each: archived normaliser / raw composition)
- Closed form $\nu_3(\lambda)$ and empty unit-circle zero set; $k_{\rm ret}(p)=3$ for all $p\ge5$ :: `[ALG]` ✓ (§6.10)
- Successor question "zero set over general $p$" (CELL-A2) :: closed by the same theorem ✓

Residual: none. Cross-$p$ comparison is by $\arg\mu_p$ only (magnitudes are frame-dependent).
---

---
**OPEN R3 — CELL-B: $P_2$ band-scale geometry** [RID: RECOG-OPEN-P2-BAND]

Status: PARTIAL — both unstable branches closed at theorem grade (negative: RECOG-THM-P2-HET, v0.3.3; positive first $C_0$ encounter: RECOG-THM-P2-C0-FIRST, v0.3.5); only the global geometry of $W^s(P_2)$ remains OPEN
Owner branch: this document

Closed sub-items:
- Saddle spectrum fixes width–lifetime scaling, not a width :: `[ALG]` ✓ (negative result, RECOG-FAIL-K-FROM-SADDLE)
- RECOG-THM-P2-C0-FIRST: unique first transverse $W^u_+(P_2)\cap C_0$, exact-rational $B_*$, first-hit pole order :: `[THM]` ✓ (§6.11)
- RECOG-NUM-P2-C0-FIRST retained as historical high-precision evidence (lifted itinerary, derived wrapped angle) :: `[NUM strong]` ✓
- Continuous side supplies an oriented excursion, not a symmetric band :: `[RESULT] [from: NUM]` ✓

Active sub-items:
- $W^s(P_2)$ global geometry (only $v_s=(1,-\phi^{-1})$ certified) :: `[OPEN]`

Dependencies:
- Dyadic OPEN 12; SG-R2; SG-R5
---

---
**OPEN R8 — CELL-B2: heteroclinic entry $W^u_-(P_2)\to P_1$** [RID: RECOG-OPEN-P2-HET-ENTRY]

Status: **CLOSED (v0.3.3)** by RECOG-THM-P2-HET (§6.11). Certificate `recog_cell_r8_hetero_enclosure.py` + `r8_cert.jsonl` + gate `recog_cell_r8_gate.py` (§8). Text below retained as the v0.3.2 specification; the primitive entry criterion was met exactly as stated (primitive $Q_{\rm prim}$, exact $\tfrac1{625}$, no $q$ substitution); the v0.3.2 parametrised-domain route was superseded by the stronger local-shell proof.
Owner branch: this document

RECOG-owned target (v0.3.2 restatement):
- Interval-enclose $S=P_u([-\lambda_u,-1])$ (plus the local segment $-1<t<0$ or its image) and its forward iterates until entry into the **primitive** tube $U=\{0<Q_{\rm prim}\le\tfrac1{625}\}$ of DYAD-THM-PRIM-CTR (or $Q_{\rm prim}\le\tfrac1{400}$), with $\det J>0$ on all pre-entry iterates. The sampled 12-step entry into $Q<0.3$ is **not** an entry certificate for this target; on the backbone the additional cost is $\approx400$ six-step blocks. Membership is certified in the primitive scalar $Q_{\rm prim}$; the hand-over to the normalised sequence uses $\widehat U_T=h^{-1}(\mathcal L(U_T))\subset\{|z|<\tfrac1{20}\}$ (DYAD-THM-NF-REM), never $Q_{\rm prim}\mapsto q$ :: `[OPEN]`
- ~~Initial-state indexing: $Q(P_u(-1))=5.215$ must be included in the enclosure specification~~ — **removed in v0.3.3**: the proof uses the local quadratic-cusp shell $\Sigma$, not the parametrised domain $S=P_u([-\lambda_u,-1])$; the value remains historical `[NUM strong]` evidence in §6.11.

No longer blocked upstream: the contraction domain and tube exist (DYAD-THM-PRIM-CTR). **Discharged in v0.3.3 by RECOG-THM-P2-HET; retained above only as the historical v0.3.2 target.**

Dependencies:
- DYAD-THM-PRIM-CTR (entry set and tube), DYAD-THM-NF-INV / NF-REM (hand-over to normalised contraction); §6.11, §6.14
---

---
**OPEN R4 — Intrinsic type-change locus** [RID: RECOG-OPEN-TYPE-CHANGE]

Status: ACTIVE

Active sub-items:
- Does the primitive-chart locus $\cos\eta=0$ (parabolic, unipotent $J$) have a coordinate-free counterpart via periodic-orbit multipliers in the $(t,d)$-plane or via comparator geometry? :: `[OPEN]`
- Global periodic-orbit inventory of $T$ beyond $P_1,P_2$ (none exist in the small punctured $P_1$ sector) :: `[OPEN]`

Dependencies:
- §6.5, SG-R3
---

---
**OPEN R5 — Why one-sided ratio shear?** [RID: RECOG-OPEN-ONESIDED-SHEAR]

Status: ACTIVE
Exports to: RTG_ONTOLOGICAL_FOUNDATIONS §6.2a (rows 2–3), OPEN-P0 generator selection

Active sub-items:
- Derive why the primitive phase shear is $r-1=e^\rho-1$ (one-sided ratio) rather than $\log r=\rho$ or $\tfrac12(r-r^{-1})=\sinh\rho$; the certified functional consequence is the radial fate via $4a^2\gtrless3b$ :: `[OPEN]`
- Whether large-$|\rho|$ drive behaviour (a "saturation" reading) plays any role — not testable by the cubic jet; requires a nonlocal test before any `[HEUR]` :: `[OPEN]`

Dependencies:
- §6.6, §6.7
---

---
**OPEN R6 — Physical recognition-event rule** [RID: RECOG-OPEN-EVENT-RULE]

Status: ACTIVE (sharpened v0.3; identifiability audited v0.3.7)

Closed sub-items:
- Event-rule identifiability audit (CELL-F1): the present package does not determine a unique physical-event predicate — RECOG-RESULT-EVENT-UNDERDETERMINATION; test schema RECOG-DEF-EVENT-TOKEN-SCHEMA :: `[RESULT]` / `[DEF candidate]` ✓ (§6.16)
- Self/encounter unification: the leading return defect is monodromy-equivariant, hence comparator-closed through degree $p-2$; diagonal and off-diagonal cases are one algebra; uncoupled encounter residue $=$ difference of self-return residues ($\Delta\log C_\to=\bar\mu Q_a+\mu Q_b$, reproducing the Genesis plateau memory) :: `[ALG]` ✓ (§6.12)
- First failure of comparator closure identified: the lattice harmonic $\bar W^{p-1}$; for $p=6$, $c_{05}\ne0$ :: `[ALG]` ✓ (§6.13)
- Retained lattice memory $\Lambda$ and the identical-comparator counterexample :: `[ALG consequence, leading order]` ✓ (§6.13)

Current hierarchy (v0.3): comparison $C_\to$ → return recognition $\mu Q$ → lattice readability $c_{05}Q^2e^{-6i\Theta}$ → lattice clock $m_{k+1}/m_k\to\lambda_{\rm DSI}^{1/6}$ → retained lattice memory $\Lambda(Q_0,\Theta_0)$ → physical event `[OPEN/HYP]`.

Active sub-items:
- `[THM]` (v0.3.4) The non-comparator-memory premise has a theorem-grade witness for the delivered exact map: RECOG-THM-R9-MEMORY and its corollary (identical $C_z$ data, different retained pair phase) on the certified window $q_0<|G|/C_2$. That such retained memory constitutes a **physical event** remains `[HYP]`/`[OPEN]`.
- `[import: RTG_NUMBER_GENESIS_DSN_v1.20.4 N-5A-S1-INF / GAP-LOCK Lemma 3]` `[HEUR cross-reference]` Number Genesis proves that the dynamically defined physical 7-gap event times satisfy $M_{k+1}^{({\rm phys})}/M_k^{({\rm phys})}\to e^{\pi/(3\tau)}=\lambda_{\rm DSI}^{1/6}$, the same asymptotic ratio as RECOG's lattice thresholds. GAP-LOCK Lemma 2 gives only the weaker mean-exponential statement $(1/k)\log M_k^{({\rm phys})}\to\pi/(3\tau)$; Lemma 3 gives the consecutive-ratio limit. Equal asymptotic rate does **not** identify the two event streams or promote RECOG's lattice thresholds to physical events (SG-R6). The parallel defect-threshold theorem is owner-RID `NUMGEN-THM-N5AS1-DEFECT-THRESHOLD-RATIO`; no RID is inferred here for GAP-LOCK Lemma 3.
- `[HYP]` Event-capable recognition is associated not with instantaneous lattice-axis crossings but with non-comparator information that survives their fading modulation as the retained memory $\Lambda$. Crossings are the mechanism that generates/samples $\Lambda$, not the event definition. **Reading (v0.3.2, per RRF Wrap-up "readability emergence"):** the lattice phase that comparator data cannot recover is *retained* information made operationally readable by the $\bar W^{p-1}$ channel — not information created; failure of isolated comparator completeness therefore does not imply an ontically new datum. The ontology note owns the interpretation; RECOG supplies the witness (SG-R1).
- `[HYP]` (older, mechanism-level) intersection principle RECOG-OPEN-INTERSECTION (§6.5).
- Residual question (restated v0.3.7): the missing object is a representation-safe event **tokenisation/selection** principle; retained memory alone is event-capable information, not a token :: `[OPEN]`
- F2(a) representation audit; F2(b) eventwise 7-gap vs lifted phase-lag crossings `[NUM]`; F2(c0) Whitney-fold certificate at $x_*$, then F2(c) consequence type :: `[OPEN]` (§6.16)

Dependencies:
- SG-R6, SG-R10
---

---
**OPEN R9 — CELL-D2a: finite-$Q_0$ lattice memory for the truncated normal form** [RID: RECOG-OPEN-LATTICE-MEMORY-NF]

Status: **CLOSED (v0.3.4)** by RECOG-THM-R9-MEMORY (§6.13), for the delivered exact map rather than the truncated model, via an averaging function instead of the Euler–Maclaurin/backbone route below. The text below is retained as the historical v0.3.2 specification; its target ($|\Lambda-q_0\Lambda_1|\le C_2q_0^2$ with explicit $C_2$) is met in the stronger form $M-c_{\rm iso}q_0=q_0\Lambda_1(\Theta_0)+R$.

Target (v0.3.2 restatement, in the owner's $h$-chart): for the exact normalised return $\widehat F=h^{-1}F_Wh$ with $|\widehat F-J|\le C_7|z|^7$, prove $|\Lambda-q_0\Lambda_1(\Theta_0)|\le C_2q_0^2$ with explicit $C_2$, where $\Lambda_1$ is the leading lattice-memory coefficient of §6.13 (chart values).

Inputs (all chart-native, §6.14): $q$-law $q'=q-q^2+[\tfrac{245}{216}+2\Re(a_{05}e^{-6i\Theta})]q^3+O(q^4)$; $\Theta$-law $\Delta\Theta=-\tau q+[\tfrac{89\sqrt3}{324}+\Im(a_{05}e^{-6i\Theta})]q^2+O(q^3)$; one-orbit bounds $q-\tfrac32q^2\le q'\le q-\tfrac12q^2$, $q_m\le q_0/(1+\tfrac12q_0m)$, $\sum q_m^3\le2q_0^2$ (DYAD-THM-NF-REM); Euler–Maclaurin $q^2\sum F(qm)=\tfrac{q}{1-6i\tau}+\tfrac{q^2}{2}+O(q^3)$; $a_{05}^2$ self-interaction to be bounded.

Degree-$\ge7$ budget `[ALG]`: per block the phase error is $\le C_7q^3$, hence the degree-7 contribution to $\Lambda$ is $\le2C_7q_0^2$ ($200q_0^2$ on $|z|\le\tfrac1{20}$, $60q_0^2$ on $|z|\le\tfrac1{40}$). Against $|\Lambda_1|\le0.0076520$, the leading term dominates only for $q_0<3.8\times10^{-5}$ ($C_7=100$) or $1.28\times10^{-4}$ ($C_7=30$), before the D2a terms. R9's theorem will carry a $q_0$ threshold of this order unless $C_7$ is sharpened (Dyadic §6.14 `[HEUR]`: deferred until a downstream budget shows need — this is that budget). The one-return sign bound $|\chi_1(-z)-\chi_1(z)|\le2C_7|z|^6$ (RRF Registry) is of the same order and is not an input to the leading term.

The v0.3 "corrected backbone" ($47/54$, $c_\theta^{(6)}$, $H(x)$) is retired (Appendix B): its inputs are archival/raw-frame objects that Dyadic SG-19 forbids transferring into the chart.

Dependencies:
- DYAD-ALG-NF6, DYAD-THM-NF-REM; §6.14
---

---
**OPEN R11 — Final-chart ledger (typed observable transport)** [RID: RECOG-OPEN-QUINTIC-FRAME]

Status: **CLOSED (v0.3.2)** — representation ledger complete (dynamics, two comparator tracks, amplitude typing, swap action, domain, refusal line; §6.14). Follow-ons routed: typed memory-observable propagation → R9; physical pole relabeling → RRF OPEN-A (not RECOG-owned). R11 is defined as the representation ledger, not as the finite-$q_0$ memory theorem.

Resolution history: v0.3.1 framed R11 as "raw vs post-$H_2$". Dyadic v6.4.10 supplies the chart (`DYAD-ALG-NF6`), names the obstruction (`DYAD-ALG-NF6-OBS`: $c_{05}^{\rm raw}-a_{05}=\tfrac{-13+3i\sqrt3}{576}$), rescopes $\tfrac{47}{54}$ as the raw fixed-radius angular mean $\mathcal A_{\rm raw}$ (not a pointwise law), and declares $c_\theta^{(6)},a_1,a_2$ archival Lie-gauge quantities not transferred to the chart (SG-19). The final-chart ledger is therefore **RECOG-owned** and is filled in §6.14 with a typed package — dynamics, observables, constraints, relabeling action, domain — following the RRF Registry convention.

Closed sub-items (v0.3.2, §6.14):
- chart $q$-law and $\Theta$-law from $J$; $\tfrac{245}{216}$ and $+\tfrac{89\sqrt3}{324}$; sign reversal relative to archival $c_\theta^{(6)}$ :: `[ALG]` ✓
- two comparator tracks $C_z$ / $C_W^{(h)}$ with transport through $O(3)$; $q\ne Q_{\rm prim}$ :: `[ALG]` ✓
- exact swap object $S_h$, degree-6 commutation scope, canonical-comparator covariance defect $\tfrac32t^3$ :: `[ALG]` / `[import]` ✓
- refusal line: $\tfrac{47}{54}$, $c_\theta^{(6)}$, $a_1$, $a_2$, any long-orbit backbone — not chart inputs :: `[DEF]` ✓

Routed elsewhere (not R11 sub-items):
- Memory observable, typed: which two trajectories, which comparator track, which normaliser branch, and error propagation → **R9**
- Whether $-I_{\rm NF}\leftrightarrow S_h\leftrightarrow\mathcal L^{-1}S_h\mathcal L$ is the *physical* pole relabeling → **RRF OPEN-A** (not RECOG-owned); RECOG records only that its comparator statements are typed per track

**Former OPEN R11 text (v0.3.1), retained for the record:**

Finding (external audit, confirmed here): Dyadic §6.9 lists $c_{32},c_{05},c_\theta^{(6)}$ as *raw six-step* coefficients (linear eigenframe, nonzero quartic jet) while attaching a Lie-gauge qualifier; the post-$H_2$ six-step jet has zero quartic part and $c_{32}^{\rm NF}=-\tfrac{97}{432}+i\tfrac{197\sqrt3}{324}$, $c_{05}^{\rm NF}=-\tfrac{49}{8640}-i\tfrac{307\sqrt3}{25920}$; the latter equals $6\bar\lambda\nu_5^{(1,6)}$ from Dyadic §6.11 exactly. Consequently $47/54$ and $c_\theta^{(6)}$ are raw-$Q$-variable quantities and $|\mu|^2+2\Re c_{32}^{\rm NF}=245/216\ne47/54$.

Active sub-items:
- Dyadic to state which frame its quintic ledger and asymptotic backbone refer to, and to record both frames with the $H_2$ relation :: `[OPEN]` (request in memo §1)
- Re-derive the R9 backbone ($a$, $c_\theta$) in the post-$H_2$ frame, or transform $\Lambda$'s derivation to the raw-$Q$ variable consistently :: `[OPEN]`
- CELL-C readability fractions restated in the post-$H_2$ frame (only $\mathcal I_{\rm lat}$ and the transfer coefficient are restated in v0.3.1) :: `[OPEN]`
- **Comparator transport across $H_2$.** With raw $w=H_2(z)=z+h_2(z,\bar z)$: $C_\to^{\rm raw}(a,b)=\bar z_az_b+\overline{h_2(z_a)}z_b+\bar z_ah_2(z_b)+O(|z|^4)$, $Q_{\rm raw}=|z|^2+2\Re(\bar zh_2)+O(|z|^4)$. This cubic correction is why raw backbone data cannot be attached to post-$H_2$ quintic coefficients. The identical-comparator counterexample is certified for identical post-$H_2$ $(Q,\Delta\Theta)$ (rev. 3) and for identical **canonical raw** comparator data transported through $H_2^{-1}$ (rev. 4: $+3.45\times10^{-4}$ vs $-3.35\times10^{-4}$ at $\alpha=0,0.5$) :: `[ALG consequence]` ✓ / `[OPEN]` for the final frame
- Required deliverable: one explicit coordinate ledger $W_{\rm raw}\xleftrightarrow{H_2}W_{H_2}\xleftrightarrow{\text{residual gauge}}W_{\rm final}$ recording, per frame, the six-step jet through degree 5, $Q$, $\Theta$, $C_\to$, backbone coefficients, $c_\theta$, $c_{32}$, $c_{05}$; R9 and R10 resume only afterwards :: `[OPEN]`

Dependencies:
- Dyadic §6.2 ($h_2$), §6.9, §6.11; R9; R10
---

---
**OPEN R10 — CELL-D2b / B2 promotion: explicit local enclosure of the six-step return germ** [RID: RECOG-OPEN-RETURN-ENCLOSURE]

Status: **DELIVERED and ACCEPTED (v0.3.2)** — owner adoption Dyadic v6.4.10 §6.14 (24 Sep 2026); RECOG consumer acceptance recorded in §7. The template below is now instantiated by DYAD-THM-NF-REM in the chart of DYAD-ALG-NF6 with the two radius-indexed profiles (rows not to be mixed), and by DYAD-THM-PRIM-CTR for the contraction half. Residual: $C_7$ sharpening is a non-blocking optimisation (R9 is closed); it would widen the exact-map comparator-incompleteness window of §6.13a roughly proportionally.

Template (to be posed only after R11 fixes the chart): explicit $r_0>0$, $C_7$, $c>0$ with, on $|W|^2\le r_0$ in the R11-resolved normal-form chart,
$$|T^6(W)-W-\mu|W|^2W-c_{32}|W|^4W-c_{05}\bar W^5|\le C_7|W|^7,\qquad Q(T^6x)\le Q(x)-cQ(x)^2,$$
with $c_{32},c_{05}$ the coefficients of that same chart, plus a scalar sufficient membership criterion. Rationale: $\sum_mQ_m^3=O(q^2)$, so a degree-7 remainder enters $\Lambda$ at the order R9 bounds; the contraction statement is what R8 needs. The same enclosure lifts the existential-radius guard on NUMGEN long-orbit results.
---

---
**OPEN R7 — Global accessibility of rank loss for shear twins** [RID: RECOG-OPEN-TWIN-ACCESS]

Status: **PARTIAL (v0.3.6)**

Closed sub-items:
- For $T_s$ ($\Re\mu=+\tfrac12$): small-$Q$ outward drift reaches $|\rho|\ge\operatorname{arccosh}2$ — RECOG-THM-TWIN-RADIAL-ACCESS (§6.15) :: `[THM]` ✓ (still not a statement that "the symmetric twin runs into erasure": neither $D_s<0$ nor $C_0^{(s)}$ is claimed)

Active sub-items:
- $Q_c$-type threshold for twins :: `[OPEN]`
- Stage 2 (optional): every orbit from $\mathcal A$ enters $D_s<0$ — same certified cover, different stopping test :: `[OPEN]`
- Accessibility of $C_0^{(s)}$ itself, $\exists x,n:\ D_s(T_s^nx)=0$ — separate IVT/root cell and RID :: `[OPEN]`

Dependencies:
- §6.7; Dyadic §6.4 $Q_c$
---

---

## §3. Scope Guards {#sec-3-guards}

**[SG-R1]** No result in this document is an ontological theorem. Substrate results may be *cited* in the ontology note as realisation witnesses; they may not be *promoted* there. The ontology is prior to RTG, not derived from it.
Violation: category error; the ontological claim is `[HYP]` at best.

**[SG-R2]** The pole comparator $C_{\rm pole}=e^{i\eta}$ and the state comparator $C_\to(a,b)=\overline W_aW_b$ are distinct objects at distinct levels. Neither may be substituted for the other; $\arg W\ne\eta$ ($\arg W(P_2)=2\pi/3$). Any "antipode" statement must name its comparator.
Violation: mis-assigned event angle; CELL-B output becomes meaningless.

**[SG-R3]** The eigenvalue type (elliptic/parabolic/hyperbolic) of a single-step Jacobian $DF_x$ off a fixed point is chart-dependent ($DF_x\mapsto D\varphi_{F(x)}DF_xD\varphi_x^{-1}$). Pointwise chart-free under this conjugacy on a connected chart: the rank and the **sign of $\det DF_x$** (orientation character), since $\det D\varphi$ has constant sign; the rank-loss locus $C_0$ is the boundary between orientation-preserving and orientation-reversing transport. Type statements are intrinsic only for closed transports $M_n$ on periodic points.
Violation: the quadrature locus $\cos\eta=0$ is `[ALG]` [scope: primitive chart] only.

**[SG-R4]** Shear twins $T_s$, $T_{\log}$, $T_{\tanh}$ and the $(a,b)$-family are diagnostic objects. They are not generator candidates and export nothing to Genesis, Triadic or TDR-G.
Violation: contaminates OPEN-P0 with unmotivated alternatives.

**[SG-R5]** No continuous↔discrete transfer. The TDR-G antipodal defect band $\mathcal D_k$ and the continuous $P_2$ geometry are related only as *two witnesses*; STAR-NOERASE-1 and the $Q_c$ protection mechanism are witnesses in different substrates. A bridge theorem is required before "same mechanism" claims.
Violation: SG-14 of the Dyadic DSN.

**[SG-R6]** Nontriviality of a comparison ($\widehat C\ne1$, or $D_\gamma\ne0$) is not a recognition *event*. Comparison, event, and memory are three distinct layers (§6.8). "Recognised" is used only for the mathematical residue; "event" is reserved for OPEN R6.
Violation: tautology ("everything compares, hence everything is recognised").

**[SG-R7]** All results inherit `[scope: conditional on postulated continuous generator T]` from the Dyadic export protocol. Jet-law statements are cubic-order, small-$Q$ statements.
Violation: overreach beyond the local germ.

**[SG-R8]** $Q<Q_c$ certifies only that the rank stratum $C_0$ is unreachable *at the crossing step*. It is a sufficient local safety condition, not a no-erasure theorem and not a global statement.
Violation: treating a local barrier as a global protection law.

**[SG-R9]** The metric $B$ is intrinsic up to scale; the complex orientation of the comparator is fixed only after the Genesis $J_Q$ sign branch is chosen. $C_\to=\overline W_aW_b$ carries the conjugate orientation of the Genesis $I+i\tfrac{\sqrt3}{2}\omega$ pairing. Convention-safe quantities: $|C|$, amplitude ratios, the swap-fixed set $\widehat C=\pm1$. Sign-carrying quantities ($\arg\widehat C$, $\Im\mu$) must state the orientation.
Violation: sign errors in phase-defect and memory statements.

**[SG-R10]** Lattice quantities carry three scopes. $\mathcal I_{\rm lat}$, the clock ratio and the leading $\Lambda$ are invariant under linear frame changes and $U(1)$-equivariant residual gauge; $\Psi_{\rm lat}$ is invariant under linear frame changes only (under $\widetilde W=e^{ia|W|^2}W$ it shifts by $-6aQ$); $\arg c_{05}$, $|c_{05}|/|\beta|$ and individual crossing indices are frame-convention quantities. **All quintic coefficients must name their frame** (raw six-step vs post-$H_2$ vs final gauge); v0.3 numbers quoted without a frame are superseded (Appendix B). $\Lambda$ is leading order in $Q_0$ only; the quoted leading amplitude (currently $0.007652\,Q_0$, post-$H_2$) is not a finite-$Q_0$ bound (R9/R10/R11). Lattice thresholds are a mathematical sequence; "event" is `[HYP]`.
Violation: convention-laden numbers presented as invariants; asymptotic coefficients presented as bounds.

**[SG-R11]** Two rigidity theorems, two families. RECOG-ALG-CUBIC-RETURN-RIGIDITY is over shear jets at $p=6$, $K=1$; RECOG-ALG-NU3-NONVANISHING is over $p$ at fixed primitive shear in the $K_p$ family. They coincide at $p=6$ and must not be merged.
Violation: invoking $|\mu_6(a,b)|\ge\tfrac12$ for $p\ne6$, or the all-$p$ result for modified shears.

**[SG-R13]** (v0.3.2, adopts Dyadic SG-19) Three operations are all historically called "normalization": the archival coordinate change $\Phi_{\rm archive}$, the log-channel projection $G_{\rm proj}$, and the polynomial conjugacy $\mathcal J_{\le6}(f\circ h-h\circ n)=0$ with additive $h$. RECOG uses only the third; every "normalized" coefficient names its operation; no coefficient is transferred between operations. Grammar: $\widehat f_{\rm form}$ (formal normal form), $\widehat f_6$/$J$ (finite jets), $\widehat F$ (delivered exact map on its proved domain) are distinct symbols; a symmetry of $J$ or of the formal normal form is never stated as a symmetry of $\widehat F$; conjugacy identities carry the $\mathcal J_{\le6}$ qualifier.
Violation: inserting raw $c_{05}$, $c_\theta^{(6)}$, $a_1$, $a_2$ or a long-orbit backbone into the chart; writing $f\circ h=h\circ n$ without $\mathcal J_{\le6}$; calling $-z$ an exact symmetry of $\widehat F$.

**[SG-R14]** (v0.3.2) Comparator typing. Every comparator statement names its track: $C_{\rm pole}=e^{i\eta}$ (pole level); $C_W=\overline W_aW_b$ (canonical Genesis, raw $\mathcal L$-frame); $C_z=\bar z_az_b$ (NF-native); $C_W^{(h)}=\overline{h(z_a)}h(z_b)$ (canonical transported to the chart); $C^W_{\rm cov}=(h^{-1})^*C_z$ (NF-native transported to $W$). Covariance belongs to the pair (observable, action), not to a chart: $C_z$ is exactly $(-I)$-covariant, $C_W$ is $S_h$-covariant only to $O(2)$. Two $z$-states may be compared by $C_z$ only as preimages under the same registered $h$.
Violation: an untyped "the comparator"; treating $S_h$-covariance of $C_W$ as exact; identifying $q$ with $Q_{\rm prim}$.
*Raw-track scope (v0.3.4).* Identical $C_W^{(h)}$ data **need not** give identical $C_z$ data: $h_2$ is not $U(1)$-equivariant, so the induced $C_z$-track mismatch is **generically** $O(\sqrt{q_0})$ (special configurations may cancel it). Raw-comparator equality therefore does not control the $C_z$ datum to the $O(q_0)$ precision needed to isolate lattice memory; memory-incompleteness statements are made in the $C_z$ track. Because $h(z)=z+O(z^2)$, the chart correction to phase vanishes as $z\to0$, so the *limiting* pair phase agrees between the two tracks — final observables are track-independent, finite-initial-state comparator data are not.

**[SG-R12]** The linear eigenframe $W=\rho+\omega\eta$ does not descend to the phase cylinder ($W(\rho,\eta+2\pi)=W+2\pi\omega$). $Q$, $C_\to$ and state-comparator phases are defined on a lifted chart, or with the Dyadic wrap $\eta_{\rm wrap}\in(-\pi,\pi]$ and its seam convention; $W(P_2)$ uses the representative $+\pi$ ($\arg W=2\pi/3$; $-\pi$ gives the negative). $|C_\to|$ is not invariant under $B\to cB$; $\widehat C$ and amplitude ratios are.
Violation: comparing state comparators across the seam or across lifts.

---

## §4. Layer Routing {#sec-4-routing}

| Layer | Canonical objects | Owner | Bridge required for |
|---|---|---|---|
| Primitive map | $T(\rho,\eta)$, $J$, $\det J$, $C_0$, $\operatorname{Fix}(T)$, $C_{\rm pole}=e^{i\eta}$ | Dyadic §6.1 | — |
| Birkhoff / normal form | $W$, $Q$, $\mu_6$, $h_2$, six-step jet | Dyadic §6.2, §6.7 | Birkhoff change of variables (certified in source) |
| State comparator | $C_\to(a,b)=\overline W_aW_b$, $\widehat C$, $\chi_6$ | this document §6.1–6.2 | none (exact consequence of Genesis §6.1/§6.6 definitions); orientation per SG-R9 |
| Candidate strata | rank / pair-symmetry / loop strata, $(t,d)$-plane | this document §6.5 | intrinsic type-change (OPEN R4); event rule (OPEN R6) |
| Shear diagnostics | $T_s$, $T_b$, $\mu_6(a,b)$ | this document §6.6–6.7 | none; SG-R4 blocks export |
| $p$-family / normal form | $\nu_3(\lambda)$, $\mu_p$, $c_{32},c_{05},c_\theta^{(6)}$, backbone | Dyadic §6.5, §6.9 (owner); this document §6.10, §6.13 | bridge lemma (certified); SG-R11 |
| $P_2$ invariant manifolds | $W^{u,s}(P_2)$, $\Sigma$, $x_*$ | this document §6.11; Dyadic OPEN 12 | negative branch closed by RECOG-THM-P2-HET; positive first $C_0$ encounter closed by RECOG-THM-P2-C0-FIRST; only global $W^s(P_2)$ geometry remains open under R3 |
| Lattice / memory layer | $\Psi_{\rm lat}$, clock, $\Lambda_1$; exact-map $\Psi$, $M$ (RECOG-THM-R9-MEMORY) | this document §6.13, §6.13a; NUMGEN threshold rate | SG-R10, SG-R14 ($C_z$ track) |
| Ontology note | recognition = comparison; existence = relational | OFN / ontology thread | SG-R1: witness citation via §6.9 export interface only |
| Discrete (TDR-G) | $\mathcal D_k$, $N/2$ band | Discrete Genesis DSN | SG-R5: no import either way |

<!-- AI_CONTEXT_CORE_END -->

---

## §5. High-Risk Claims Ledger {#sec-5-high-risk}

| Claim | Valid form | Forbidden overclaim | Scope section |
|---|---|---|---|
| "Difference is recognised only by returning" | Intrinsic *spectral* comparison of a non-fixed history needs closed transport `[ALG]` | closure is a prerequisite of all recognition (comparator $C(r,T^nr)$ exists at every $n$) | §6.2, §6.5 |
| $\chi_6=1+\mu_6Q$ is origin-free | distinction-anchored at the zero-distinction state $\mathcal O_0=0$ `[ALG consequence]` | torsor-free comparison on the full state space | §6.2 |
| Comparator sign | $\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ under the Genesis $J_Q$ `[ALG]` | $+i$ pairing with $\overline W_aW_b$ (v0.1 error) | §6.1, SG-R9 |
| Cubic-return rigidity | $|\mu_6(a,b)|\ge\tfrac12$ on the real shear-jet family with radial row $-\sin\eta$ `[ALG]` | rigidity for other radial rows, other $p$, or outside the jet family | §6.7 |
| Eigenphase $\pi/3$ | linear resonance signature of the selected $T$ `[ALG]` | derivation of phase or of $p=6$ | §6.2 |
| Zero-winding fixed points lie on the swap-fixed pole stratum | $\operatorname{Fix}_0(T)=\{P_1,P_2\}\subsetneq\{\widehat C_{\rm pole}=\pm1\}$; the containment follows from $\rho'-\rho=-\sin\eta$ `[ALG]` | equality of the fixed-point set with the pole stratum; independent evidence for the intersection principle | §6.3, §6.5 |
| Healing from symmetry breaking | one route ($4a^2$ term); swap-symmetric $\tanh$ shear also heals `[ALG]` | "the arrow of history originates in swap breaking" | §6.7 |
| $\Im\mu_6/\Im\mu_6^{(s)}=4$ | Taylor-jet combinatorics of $(a,b)=(\tfrac12,\tfrac16)$ `[ALG]` | a structural $\mathbb Q(\sqrt3)$ mystery; an additive decomposition of the plateau-memory coefficient $\tau$ | §6.7, §6.8 |
| $Q_c$ protection | local, crossing-step, sufficient `[ALG]` | no-erasure theorem | SG-R8 |
| Antipode $=$ recognition | $\widehat C=-1$ is the unique nontrivial swap-fixed value; an event candidate `[ALG consequence]` | definition of recognition | §6.3, §6.5 |
| $\mu_p=0$ | cubic-silent; recognition order moves to degree 5 `[DEF]` | "recognitionless substrate" | OPEN R2 |
| $p=8$ zero degeneracy | belongs to the $q=4,(0,3)$ strobe channel only; cubic $\nu_3(\zeta_8)\ne0$ `[ALG]` | $\mu_8=0$ | §6.10 |
| $k_{\rm ret}(p)=3$ for all $p\ge5$ | $\nu_3$ numerator has no unit-circle root `[ALG]` | rigidity of $k_{\rm ret}$ under modified shears at $p\ne6$ | §6.10, SG-R11 |
| "$8.66^\circ$ inside quadrature toward the antipode" | encounter is $8.66^\circ$ *past* the second quadrature, approached from the identity side after $278.66^\circ$ lifted; the offset is derived from $\rho_*$ `[NUM strong]` | an independent angular datum; a band half-width | §6.11 |
| Comparator closure | exact for the leading return defect (gauge-free) and through degree $p-2$ in the normal-form frame `[ALG]` | closure of all raw higher-order terms | §6.12 |
| "Onset of lattice content is an event" | lattice content is an order in the germ; thresholds form a clock; retained $\Lambda$ is the candidate event content `[HYP]` | a state-space trigger; a $Q$-threshold $Q_{\rm lat}$ (none exists) | §6.13, R6 |
| $\tau$ decomposition | three-quarters of the local cubic angular coefficient is swap-breaking-mediated `[ALG]` | additive decomposition of the plateau memory | §6.8 |
| Equal-amplitude pairs build no relative phase | true at cubic order (uncoupled) `[ALG]`; false at the memory layer once $c_{05}\ne0$ | comparator completeness of memory | §6.12–6.13 |
| Lattice coefficients $c_{32},c_{05}$ | post-$H_2$ values derived from the primitive map; $c_{05}^{\rm NF}=6\bar\lambda\nu_5^{(1,6)}$ `[ALG]` | raw six-step values as normal-form coefficients (v0.3 error) | §6.13, R11 |
| $\operatorname{Fix}(T)=\{P_1,P_2\}$ | zero-winding fixed points; wrapped cylinder also has $(\log(1+2\pi k),0/\pi)$ `[ALG]` | complete fixed-point inventory; $\operatorname{Fix}=\{\widehat C_{\rm pole}=\pm1\}$ (stratum contains all $\rho$) | §6.3 |
| Plateau memory law | leading plateau surrogate, `[ALG structure]` (Genesis tag) | exact asymptotic identity for the full map | §6.8 |
| Retained memory / comparator incompleteness (R9) | RECOG-THM-R9-MEMORY on $0<q_0\le q_{\max}$; incompleteness certified only for $q_0<|G|/C_2$; track $C_z$ | incompleteness on the whole memory domain; raw-track ($C_W^{(h)}$) incompleteness at $O(q_0)$; "memory is a physical event" | §6.13a, SG-R14, R6 |
| Event rule (R6) | RECOG-RESULT-EVENT-UNDERDETERMINATION; schema RECOG-DEF-EVENT-TOKEN-SCHEMA as a test instrument only | "retained memory is an event"; "a lattice crossing is a physical token"; identifying the lattice stream with the NG 7-gap stream from equal rates; "rank loss erases information" before a fold certificate and a history analysis; treating the schema as an adopted definition | §6.16, SG-R6 |
| Twin radial access (R7) | RECOG-THM-TWIN-RADIAL-ACCESS `[THM]` for $0<Q_0<\tfrac7{200}$; $n\le256$ only from $\mathcal A$ | a uniform time bound from arbitrary small $Q_0$; entry into $D_s<0$; hitting $C_0^{(s)}$; "the symmetric twin runs into erasure"; any statement about the primitive $T$ (SG-R4: diagnostic twin) | §6.15 |
| Two unstable futures of $P_2$ | RECOG-THM-P2-HET (negative branch $\to P_1$, $C_0$ avoided) and RECOG-THM-P2-C0-FIRST (positive branch: unique **first** transverse $C_0$ encounter in $B_*$), both `[THM]`, conditional on the postulated $T$ | any claim about later re-intersections of $W^u_+$ with $C_0$; monotonicity of lifted $\eta$ or "each pole value crossed exactly once"; anything about $W^s(P_2)$ | §6.11 |
| Chart backbone | $q'=q-q^2+\tfrac{245}{216}q^3+\ldots$ (isotropic part) and $+\tfrac{89\sqrt3}{324}$ phase coefficient, from $J$ `[ALG]`; $\tfrac{47}{54}$ is the raw angular mean $\mathcal A_{\rm raw}$ | any use of $\tfrac{47}{54}$, $c_\theta^{(6)}$, $a_1$, $a_2$ in the chart; a pointwise $47/54$ law | §6.14, SG-R13 |
| Lattice memory as a theorem about $\widehat F$ | RECOG-THM-R9-MEMORY: $M=q_0[c_{\rm iso}+\Lambda_1(\Theta_0)]+R$, $|R|\le C_2q_0^2$ on the full certified row; comparator incompleteness only for $q_0<|G|/C_2$, track $C_z$ | treating $\Lambda_1q_0$ as the whole exact memory; claiming incompleteness on the whole memory domain; applying the theorem directly in the raw $C_W^{(h)}$ track | §6.13a, SG-R14 |
| $-z$ symmetry | exact for the formal normal form and for $J$; degree-6 certified for $\widehat f_6$; one-return bound $2C_7|z|^6$ for $\widehat F$ | all-orders symmetry of the delivered map | SG-R13, §6.14 |
| Radial neutrality at $4a^2=3b$ | cubic order only; $g=\rho+\gamma\rho^5$ gives $Q(T^6(t,0))-t^2=6\gamma t^6$ of either sign `[ALG]` | exact amplitude conservation | §6.7 |

---

## §6. Main Scientific Ledger {#sec-6-ledger}

### §6.1 Comparators `[ALG consequence / mixed]` {#sec-6-1-comparators}

> **[Local guard SG-R2]** Pole and state comparators are distinct; name the comparator in every antipode statement.

`[DEF]` **Pole comparator.** For a single dyad with relative phase $\eta$, $C_{\rm pole}(A,B)=e^{i\eta}$. Pole swap $A\leftrightarrow B$ sends $\eta\mapsto-\eta$, hence $C_{\rm pole}\mapsto C_{\rm pole}^{-1}$.

`[DEF]` **State comparator.** In the canonical eigenframe $W=\rho+\omega\eta$, $\omega=\tfrac12(-1+i\sqrt3)$ (Dyadic §6.2), for two dyad states $a,b$:
$$C_\to(a,b):=\overline W_aW_b.$$
The arrow marks the orientation: $C_\to(a,b)$ compares $a$ *to* $b$, so that the diagonal specialisation $b=F(a)$ gives $W'/W$ (§6.2).

`[ALG consequence]` [import: Genesis §6.1 ($B$, $Q=r^\top Br$, $A^\top BA=B$), Genesis §6.6 ($I_{ab}$, $\omega_{ab}$, $J_Q=\tfrac{1}{\sqrt3}\begin{psmallmatrix}1&-2\\2&-1\end{psmallmatrix}$, $a^\top BJ_Qb=+\tfrac{\sqrt3}{2}\omega_{ab}$)] [cert: `recog_shear_jet_cert.py` checks (10)] Since $|W|^2=\rho^2-\rho\eta+\eta^2=r^\top Br$ exactly, polarisation gives
$$C_\to(a,b)=a^\top Bb-i\,a^\top BJ_Qb=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab},\qquad W_a\overline W_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}.$$
$C_\to$ is the conjugate orientation of the Genesis $+$ pairing. `[COR]` v0.1 stated $\overline W_aW_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}$; the sign was wrong. See Appendix B, RID: RECOG-DEF-COMPARATOR-SIGN-V01.

`[ALG]` [RID: RECOG-ALG-INVARIANT-FORM] [cert: check (11)] **Invariant-form uniqueness.** With $A=\begin{psmallmatrix}1&-1\\1&0\end{psmallmatrix}$, the linear system $A^\top HA=H$ on symmetric $2\times2$ matrices has the one-dimensional solution space $H=cB$; positive definiteness gives $c>0$. The scale cancels in every ratio below. `[RESULT]` `[from: ALG]` $C_\to$ is the canonical local comparator induced by the $p=6$, $P_1$ linear transport $A$ — up to scale, and up to complex conjugation until the $J_Q$ sign branch is fixed (SG-R9). No global transport-invariance of $C_\to$ over the nonlinear state space is claimed.

`[ALG consequence]` **Normalised comparator and swap.**
$$\widehat C(a,b)=\frac{C_\to(a,b)}{\sqrt{C_\to(a,a)C_\to(b,b)}}=e^{i\theta_{ab}}\in U(1),\qquad \widehat C(b,a)=\overline{\widehat C(a,b)}=\widehat C(a,b)^{-1}.$$
Here $\theta_{ab}=\arg W_b-\arg W_a$ in the $C_\to$ orientation (SG-R9). [scope: $\widehat C$ is defined only for $Q_aQ_b>0$; $C_\to$ itself is defined at the zero-distinction state, $\widehat C$ is not.]
Swap-fixed values: $z=z^{-1}\iff z=\pm1$. $+1$ is the identity comparison; $-1$ is the unique nonidentity swap-fixed comparison. This characterisation is purely algebraic and needs no metric notion of "maximal distinction" (which remains an OFN interpretation).

`[DEF]` **Chart.** $W$ is taken on the lifted $(\rho,\eta)$ plane or on the Dyadic wrap $\eta_{\rm wrap}\in(-\pi,\pi]$ (SG-R12); all comparator values below are chart-relative in this sense, and $|C_\to|$ carries the scale of $B$.

`[ALG consequence]` **Two-coordinate comparison.** $C_\to(a,b)/C_\to(a,a)=\sqrt{Q_b/Q_a}\,e^{i\theta_{ab}}$; the natural comparison output is the dimensionless pair $(Q_b/Q_a,\ \Delta\theta_{ab})$.

`[HEUR]` The ratio appears here as the output of the comparison form, not as a primitive. This is *not* evidence that ratio precedes difference (Number Genesis guard); it is evidence that closed self-comparison is dimensionless.

### §6.2 Return Defect and the Six-Step Multiplier `[ALG / mixed]` {#sec-6-2-return}

`[DEF]` **Resonant return germ, return defect, return order.** Let $F$ have a fixed point $x_*$ at which $DF^p(x_*)=I$ for some $p$ (a resonant return germ). Define $D_p:=F^p-\mathrm{id}$; its first nonzero homogeneous term (modulo near-identity conjugacy) is the return defect and its degree is $k_{\rm ret}(p)$, with $k_{\rm ret}=\infty$ if $D_p$ vanishes to all orders. $D_n=F^n-\mathrm{id}$ is definable for every $n$; what the resonance condition supplies is a tangent-to-identity return, so that the leading term of $D_p$ is a formal invariant. `[COR]` v0.1 defined $D_\gamma$ over an "exact closed history"; the central object $T^6$ is not a nonlinear closed history off $P_1$. See Appendix B, RID: RECOG-DEF-RETURN-DEFECT-V01. The leading term $J_{k_{\rm ret}}$ is the formal invariant of a tangent-to-identity map under near-identity changes; its magnitude is convention-dependent under linear rescaling $W\mapsto cW$ (the vanishing/non-vanishing and, at fixed orientation convention, $\arg\mu$ and the radial/angular ratio are robust).

`[ALG]` [import: Dyadic §6.7 | DYAD-THM-C21] For $p=6$ the six-step quadratic part vanishes identically (master parity lemma), the cubic residual collapses to the resonant $(2,1)$ channel, and
$$T^6(W)=W+\mu_6|W|^2W+O(|W|^5),\qquad \mu_6=-\tfrac12-i\tfrac{2\sqrt3}{3},\qquad k_{\rm ret}(6)=3.$$

`[ALG]` **Remainder order by frame** [`[COR]` after external audit]. In the raw eigenframe the quartic six-step jet is nonzero (channels $(4,0),(3,1),(2,2),(1,3)$; on $(\rho,\eta)=(t,0)$: $W(T^6(t,0))=t+\mu_6t^3-\tfrac{5+25i\sqrt3}{48}t^4+O(t^5)$), so $T^6(W)=W+\mu_6QW+O(|W|^4)$ and $\chi_6=1+\mu_6Q+O(Q^{3/2})$, $|\chi_6|=1-\tfrac12Q+O(Q^{3/2})$, $\arg\chi_6=-\tau Q+O(Q^{3/2})$. The $O(|W|^5)$ / $O(Q^2)$ remainder holds in the post-$H_2$ frame, which is *not* the linear $W$ of the exact comparator identity. Leading coefficient, return order and local strict contraction are frame-independent.

`[ALG consequence]` **Recognition multiplier.** With $b=T^6a$ in §6.1,
$$\chi_6(W):=\frac{C_\to(W,T^6W)}{C_\to(W,W)}=\frac{W'}{W}=\sqrt{\tfrac{Q'}{Q}}\,e^{i\Delta\Theta}=1+\mu_6Q+O(Q^{3/2})\quad(\text{raw }W;\ O(Q^2)\text{ in the post-}H_2\text{ coordinate}),$$
consistent with the certified laws $Q'=Q-Q^2+\cdots$, $\Delta\Theta=-\tau Q+\cdots$ (Dyadic §6.8). $\arg W=\Theta$ (ISP) exactly. The one-step eigenvalue $\lambda$ is the linearised special case $R(v)=\lambda v\Rightarrow R(v)/v=\lambda$; at the recognition cycle $\lambda^6=1$ and the linear spectrum carries no information — the content is in $J_3$.

`[ALG]` **Local exact statements.** $\chi_6$ is defined for $W\ne0$; $\lim_{W\to0}\chi_6=1$, so $\chi_6(0):=1$ is a continuous extension (the map gives $D_6(0)=0$ directly). For $0<Q<\epsilon$: $|\chi_6|=1-\tfrac12Q+O(Q^{3/2})<1$ (raw $W$), hence $\chi_6\ne1$ and $T^6$ has no fixed point other than $P_1$ in the punctured sector. Depends on: [import: RTG_NUMBER_GENESIS_DSN_v1.15 | NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION] $Q_{\rm true}(Fx)-Q_{\rm true}(x)=-Q_{\rm true}^2+O(Q_{\rm true}^{5/2})$ with phase-uniform strict contraction on a sufficiently small punctured sector. See §7. Substrate statement: $Q=0\Rightarrow D_6=0$; $0<Q<\epsilon\Rightarrow T^6x\ne x$ with nontrivial return defect. Any reading of this as a witness for an ontological thesis is made in the ontology note, not here (§6.9).

`[ALG]` **Distinction anchoring.** $\chi_6$ compares $W$ with $T^6W$ relative to $W=0$, i.e. relative to the zero-distinction state $\mathcal O_0=0$ of Genesis §6.1 — not relative to an external origin. The definition is *distinction-anchored*, not origin-free; a genuine torsor difference on the state space would use only the phase/winding gauge, which is invisible to the dynamics (Dyadic §6.4) and hence empty.

`[ALG]` **Phase readability.** Phase structure exists at linear order ($\lambda=e^{i\pi/3}$); a *self-readable* phase defect first appears at cubic order, multiplied by amplitude: $\arg\chi_6=-\tau Q+O(Q^{3/2})$ (raw $W$; $O(Q^2)$ post-$H_2$). Phase is not created by $Q$; its self-recognition residue opens with $Q$.

`[ALG]` The resonance prerequisite is arithmetic: a tangent-to-identity return $DF^p=I$ exists only for rational rotation number. `[HEUR]` For an irrational-rotation germ no finite $p$ gives a resonant return, so $k_{\rm ret}$ is undefined (not $\infty$); $D_n$ and the comparison $C_\to(r,T^nr)$ nonetheless exist at every $n$. Finite resonance is therefore the prerequisite of finite *self-calibration*, not of comparison as such.

### §6.3 Fixed Points, Antipode, and Swap Structure `[ALG / mixed]` {#sec-6-3-fixed-swap}

`[ALG]` [import: Dyadic §6.1] [`[COR]` after external audit] $\rho'=\rho\Rightarrow\sin\eta=0$. On the lift, $\eta'=\eta\Rightarrow e^\rho=1$: $\operatorname{Fix}(T)=\{(0,k\pi)\}$, zero-winding representatives $P_1=(0,0)$ (elliptic, $e^{\pm i\pi/3}$) and $P_2=(0,\pi)$ (hyperbolic, $\phi^{\pm2}$). On the wrapped cylinder the condition is $\eta'\equiv\eta\pmod{2\pi}$, i.e. $e^\rho-1=2\pi k$: $\operatorname{Fix}(\bar T)=\{(\log(1+2\pi k),0),(\log(1+2\pi k),\pi):k\ge0\}$. The $k\ge1$ winding fixed points have $\det J=1\pm2\pi k$ (the $\eta=\pi$ ones lie beyond $C_0$, orientation-reversing). All local statements in this document concern the zero-winding sector. (Dyadic §6.1 lists only $P_1,P_2$; flagged to Dyadic in the memo.)

`[ALG consequence]` $P_1:\ \widehat C_{\rm pole}=+1$; $P_2:\ \widehat C_{\rm pole}=-1$. The zero-winding fixed points lie on the swap-fixed pole stratum $\{\eta\in\{0,\pi\}\}$; the stratum itself contains states of arbitrary $\rho$ (e.g. $C_{\rm pole}(1,0)=1$ but $T(1,0)=(1,e-1)$), so $\operatorname{Fix}\subsetneq\{\widehat C_{\rm pole}=\pm1\}$. The containment is a consequence of the radial row being $-\sin\eta$ (§6.4), not an independent coincidence; see §5.

`[ALG]` **Fiber antipode vs state antipode.** $A^3=-I$ reverses a tangent perturbation at $P_1$ (fiber antipode, linear order); $P_2$ is the state-space antipode of the pole comparison and carries no cyclic return (real multipliers). These are distinct objects; "recognition at the antipode" must specify which. `[DEF]` Two candidate recognition classes: *recurrence recognition* (self-comparison across a resonant return — closed **linear** transport $DT^6(P_1)=I$ with nonlinear return defect $T^6W\ne W$, realised near $P_1$; not a closed nonlinear orbit) and *encounter recognition* (cross-comparison of two co-present relations, realised by $C_\to(r_a,r_b)$ at state level and by the $P_2$ pole configuration at pole level).

### §6.4 Radial Parity and the Selection Lemma `[ALG conditional / mixed]` {#sec-6-4-selection}

`[HYP]` **Pole-swap covariance.** The primitive relational description is covariant under $A\leftrightarrow B$.

`[ALG conditional]` [assumes: pole-swap covariance; certified $A=DT(P_1)$] Write $\rho'=\rho+f(\eta)$. If $\rho$ were swap-even, covariance gives $f(-\eta)=f(\eta)$, hence $f'(0)=0$; but $A$ has radial entry $f'(0)=-1$. Therefore $\rho$ is swap-odd: $S_o(\rho,\eta)=(-\rho,-\eta)$, and on the wrapped cylinder $\operatorname{Fix}(S_o)=\{(0,0),(0,\pi)\}$ coincides with the zero-winding fixed points of $T$ (not with the full wrapped inventory, §6.3), although $T$ is not $S_o$-equivariant (§6.6). **Scope of the covariance premise** [`[COR]` after external audit]: the lemma assumes covariance of the *radial row* (equivalently of $T$ at linear order); the full primitive map violates $S_o$-equivariance at quadratic order ($T_b\ne0$). The selection lemma therefore constrains the radial row; it does not derive the full generator from a symmetry the generator satisfies. Whether the physical swap action involves additional oriented-role data is an OFN-level `[OPEN]` (memo §4) — registered as RRF OPEN-A. In chart terms (v0.3.2): the exact representation-level involution is $S_h=h\circ(-I)\circ h^{-1}$, with $\mathcal J_{\le6}(f\circ S_h-S_h\circ f)=0$; the canonical comparator $C_W$ is $S_h$-covariant only to $O(2)$ (defect $\tfrac32t^3$ on the real ray), while the NF-native $C_z$ is exactly $(-I)$-covariant (SG-R14). The swap-fixed-set result $\widehat C=\pm1$ is an algebraic $U(1)$ statement and is unaffected. Under swap-even $\rho$ the minimal covariant radial forcing would be $\propto\cos2\eta-1=-2\sin^2\eta$: sign-definite drift, no elliptic $P_1$.

`[ALG conditional]` [RID: RECOG-ALG-SELECTION-SIN] [assumes: pole-swap covariance with $\rho$ odd; $2\pi$-periodicity; stationarity on the swap-fixed strata $f(0)=f(\pi)=0$; lowest nonzero Fourier harmonic] $f(\eta)=a_1\sin\eta$; with orientation/normalisation $a_1=-1$, the radial row of $T$ is recovered. The lemma selects the functional form only; it does not derive the coefficient, and it does not select the shear $g(\rho)$ (any odd $g$ with $g'(0)=1$ is admissible: $\rho$, $\sinh\rho$, $\tanh\rho$, …).

`[RESULT]` `[from: ALG conditional]` The stationarity of $P_1,P_2$ is thereby reframed from an observed coincidence into a generator-construction criterion: swap-special relational states $\Rightarrow$ stationarity $\Rightarrow f(0)=f(\pi)=0\Rightarrow f_{\min}\propto\sin\eta$. This is a candidate derivation for the first row of OFN §6.2a ("why does phase opposition change radial separation"), tagged conditional.

### §6.5 Candidate Mathematical Strata and the Prerequisite Ladder `[DEF / mixed]` {#sec-6-5-strata}

> **[Local guard SG-R3]** One-step Jacobian type is chart-dependent off fixed points; rank and the sign of $\det DF_x$ are pointwise intrinsic on a connected chart.

`[DEF]` **Three candidate strata.** These are mathematical loci of the comparator/transport geometry; whether any of them is a physical *event* is OPEN R6 (SG-R6).

| Stratum | Intrinsic object | Prerequisite | Dyad realisation |
|---|---|---|---|
| rank stratum | $\operatorname{rank}DF_x$ | one present state | $C_0=\{\rho\ge\ln2,\ \cos\eta=-1/(e^\rho-1)\}$ |
| pair-symmetry stratum, pole level | $\widehat C_{\rm pole}=\pm1$ | primitive co-presence of $A,B$ (always given in a dyad) | $P_1$ ($+1$), $P_2$ ($-1$) |
| pair-symmetry stratum, state level | $\widehat C(a,b)=\widehat C(b,a)$, i.e. $\widehat C=\pm1$ (domain $Q_aQ_b>0$) | co-present states/modes, or retained self-comparison data | $C_\to(r_a,r_b)$; $A^3=-I$ (fiber level) |
| loop/spectral stratum | $(t_n,d_n)=(\operatorname{tr}M_n,\det M_n)$, $\Delta_n=t_n^2-4d_n$, multiplier $\pm1$ loci $t_n=\pm(1+d_n)$ | closed transport $F^n(x)=x$ | $P_1$ ($t=1,d=1$), $P_2$ ($t=3,d=1$); no other period-6 points near $P_1$ |

`[ALG]` The map is non-symplectic (Dyadic §6.1), so the loop stratum lives in the $(t,d)$-plane; the classical $\operatorname{tr}=\pm2$ criterion holds only on the $d=1$ slice.

`[ALG]` [scope: primitive chart] **Discriminant.** With $c=\cos\eta$: $\operatorname{tr}J=2-c$, $\det J=1+(e^\rho-1)c$, $\Delta_J=c(c-4e^\rho)$. For $\rho>-\ln4$ the sign is $-\operatorname{sign}(c)$: rotational transport for $\cos\eta>0$, stretching for $\cos\eta<0$; the zero locus has the second branch $\cos\eta=4e^\rho$ only for $\rho\le-\ln4$. On $\cos\eta=0$: $\det J=1$, $\Delta_J=0$, $J=\begin{pmatrix}1&0\\e^\rho&1\end{pmatrix}$ — a nontrivial unipotent matrix in the primitive chart. No intrinsic conjugacy-class statement is made off the fixed points (SG-R3). `[OPEN]` intrinsic counterpart: OPEN R4.

`[ALG consequence]` **Pair-symmetry is pairwise, not pointwise.** $\widehat C=-1$ is a property of a pair. At pole level the pair $A,B$ is primitively co-present, so the pole stratum needs no history. At state level a past comparison partner is not automatically part of the present state: [import: RTG_NUMBER_GENESIS_DSN_v1.15 N-1C | NUMGEN-OPEN-N1C] the wrapped-$S^1$ negative control shows that a memoryless wrapped state collapses same-endpoint histories, while the later local primitive-dyad result shows history non-collapse when relational data are retained. Hence state-level self-comparison requires either explicitly retained relational memory/interface data or a current co-realisation; the carrier $U(1)$ being closed is not a dynamical closure. `[COR]` v0.1 overstated the negative control as "a past state is not physically present". See Appendix B, RID: RECOG-DEF-COPRESENCE-V01.

`[HYP]` [RID: RECOG-OPEN-INTERSECTION] **Intersection principle** (registered under OPEN R6). Recognition event $=$ (nontrivial algebraic comparison stratum) $\cap$ (dynamically distinguished stratum). Realised by $P_2$: $\widehat C_{\rm pole}=-1$, $T(P_2)=P_2$, $\operatorname{spec}DT_{P_2}=\{\phi^2,\phi^{-2}\}$. In the dyad the coincidence is built in: $\operatorname{Fix}(T)\subset\{\sin\eta=0\}$ by construction of the radial row. The principle may therefore be used as a *derivation target* for that row (§6.4), not as a fact derived from $T$.

`[RESULT]` `[from: ALG]` Prerequisite ladder: rank and pole-level pair-symmetry need no history; state-level pair-symmetry needs co-presence or retained comparison data; the spectral stratum needs closed transport. Closure is the prerequisite of the spectral stratum only, not of all recognition.

`[HEUR]` Candidate mathematical essence of a recognition event: *failure of continuation within the current equivalence class* — a jump in rank, stabiliser/symmetry, conjugacy class or return normal form — rather than any change of a comparison value. Generic small motion changes $C$ without leaving its stratum and is not an event (SG-R6).

### §6.6 Swap-Projection Decomposition `[ALG]` {#sec-6-6-swap-projection}

> **[Local guard SG-R4]** Twins are diagnostic; no export.

`[ALG]` [RID: RECOG-ALG-SWAP-SPLIT] With $S_o=-I$, the odd and even projections of $T$ are exact:
$$T_s(x)=\tfrac12\bigl(T(x)-T(-x)\bigr)=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta),\qquad T_b(x)=\tfrac12\bigl(T(x)+T(-x)\bigr)=(0,\ \cosh\rho-1),$$
$T=T_s+T_b$. Equivalently $T\circ S_o-S_o\circ T=(0,\,2(\cosh\rho-1))=(0,\rho^2+O(\rho^4))$: $T$ is swap-equivariant at linear order and breaks swap symmetry first at quadratic order. $T_b$ is the *only* quadratic term of the primitive one-step jet; consequently the certified quadratic normal-form coefficients $c_{20},c_{11},c_{02}$ (Dyadic §6.2) are entirely sourced by the symmetry-breaking term.

`[ALG]` In ratio language $r=e^\rho$: $e^\rho-1=r-1$ (one-sided ratio drive), $\sinh\rho=\tfrac12(r-r^{-1})$ (reciprocal-antisymmetrised ratio drive), $\rho=\log r$ (log-ratio drive). $T_s$ is the reciprocal-symmetric twin, not the log twin.

`[ALG diagnostic]` **Twin rank stratum.** $\det J_s=1+(\cosh\rho-1)\cos\eta$; critical locus $\cos\eta=-1/(\cosh\rho-1)$, $|\rho|\ge\operatorname{arccosh}2$: two symmetric branches, versus the one-sided $C_0$ ($\rho\ge\ln2$) of $T$. The one-sidedness of the rank event is sourced by $T_b$.

### §6.7 Shear-Jet Law and Radial Fate `[ALG / mixed]` {#sec-6-7-shear-jet}

`[ALG]` [RID: RECOG-ALG-SHEAR-JET] [cert: `recog_shear_jet_cert.py` checks (1)–(7), (9) → CERTIFICATE PASS; two independent derivations] For the family
$$T_{a,b}(\rho,\eta)=\bigl(\rho-\sin\eta,\ \eta+g(\rho)-\sin\eta\bigr),\qquad g(\rho)=\rho+a\rho^2+b\rho^3+O(\rho^4),$$
the six-step quadratic part vanishes identically and the cubic residual is confined to the $(2,1)$ channel for all real $(a,b)$, with
$$\mu_6(a,b)=3b-4a^2-i\sqrt3\left(\tfrac13+2a^2-b\right).$$
Checks: $(a,b)=(\tfrac12,\tfrac16)$ reproduces DYAD-THM-C21 exactly.

`[ALG diagnostic]` **Instances.**

| shear $g$ | $(a,b)$ | $\mu_6$ | $\Re\mu_6$ | radial fate | swap |
|---|---|---|---|---|---|
| $\rho$ (log) | $(0,0)$ | $-i\sqrt3/3=-i\tau/2$ | $0$ | neutral at cubic order | odd |
| $\sinh\rho$ | $(0,\tfrac16)$ | $\tfrac12-i\sqrt3/6$ | $+\tfrac12$ | expansion | odd |
| $\tanh\rho$ | $(0,-\tfrac13)$ | $-1-i\,2\sqrt3/3$ | $-1$ | healing | odd |
| $e^\rho-1$ (primitive) | $(\tfrac12,\tfrac16)$ | $-\tfrac12-i\,2\sqrt3/3$ | $-\tfrac12$ | healing | broken |
| $(e^{\kappa\rho}-1)/\kappa$ | $(\tfrac\kappa2,\tfrac{\kappa^2}6)$ | $-\tfrac{\kappa^2}{2}-i\tfrac{\sqrt3}{3}(1+\kappa^2)$ | $-\tfrac{\kappa^2}{2}$ | healing for all $\kappa\ne0$ | broken |

`[ALG]` $\mu_{\rm break}:=\mu_6-\mu_6^{(s)}=-1-i\tfrac{\sqrt3}{2}$ is the quadratic symmetry-breaking-mediated contribution (since $T$ and $T_s$ share linear and cubic primitive jets). $\Im\mu_6/\Im\mu_6^{(s)}=4$ exactly, explained by $(\tfrac13+\tfrac12-\tfrac16)/(\tfrac13-\tfrac16)$; no deeper structural reason is claimed.

`[RESULT]` `[from: ALG]` **Radial-fate law.** $\Re\mu_6=3b-4a^2$: healing $\iff4a^2>3b$, neutral $\iff4a^2=3b$, expansion $\iff4a^2<3b$ — **all at cubic order**; e.g. $g=\rho+\gamma\rho^5$ has $(a,b)=(0,0)$ yet $Q(T^6(t,0))-t^2=6\gamma t^6+O(t^8)$ of either sign, so $\Re\mu_6=0$ does not establish amplitude conservation (external audit). Two independent routes to healing exist — quadratic swap breaking ($a\ne0$) and a negative cubic contribution ($b<0$). The primitive exponential shear heals because $-4a^2=-1$ overcomes $+3b=+\tfrac12$. Symmetry breaking *reverses* the outward drift of the $\sinh$ twin; it does not create directedness, and it is not necessary for healing ($\tanh$ counterexample).

`[ALG]` [RID: RECOG-ALG-CUBIC-RETURN-RIGIDITY] [cert: checks (8)] **Cubic-return rigidity.** For every real $(a,b)$,
$$\boxed{|\mu_6(a,b)|^2=12\Bigl(b-\tfrac32a^2-\tfrac1{12}\Bigr)^2+\tfrac14\bigl(2a^2+1\bigr)^2\ \ge\ \tfrac14},$$
with equality only at $(a,b)=(0,\tfrac1{12})$. Hence $\mu_6(a,b)\ne0$ on the whole family and, with the universal quadratic cancellation and $(2,1)$ confinement above, $k_{\rm ret}(6)=3$ for every member. Depends on: radial row fixed as $\rho'=\rho-\sin\eta$; real $(a,b)$. `[COR]` v0.1 asserted an imaginary "residue floor" $\Im\mu_6\le-\tau/2$; false ($\Im\mu_6^{(s)}=-\tau/4$). Replaced by this modulus bound. See Appendix B, RID: RECOG-ALG-IM-FLOOR-V01.

`[ALG consequence]` [RID: RECOG-ALG-FATE-BOUNDARY] [cert: checks (12)–(13)] **Radial-fate boundary corollary.** On $4a^2=3b$ the law reduces to $\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$: $\Re\mu_6=0$ but $|\mu_6|\ge1/\sqrt3$. The healing/expansion transition therefore does not coincide with loss of return content — radial fate changes class while $k_{\rm ret}$ is unchanged and a purely angular residue survives. At the rigidity minimiser, $\mu_6(0,\tfrac1{12})=\tfrac14-i\tfrac{\sqrt3}{4}=\tfrac12e^{-i\pi/3}$.

`[RESULT]` `[from: ALG]` The return-defect *order* is rigid across the shear-jet family; the return *content* ($\arg\mu$, $\Re\mu$) and hence the radial fate are shear-selected. $J_3$ may be called a mathematical recognition residue under SG-R6; no physical recognition-event order is asserted. To delay the first return defect beyond cubic order one must leave this family or change the resonance horizon $p$ (CELL-A). `[HEUR]` Whether the healing instances share a large-$|\rho|$ "saturation" feature is not decidable from the cubic jet ($e^\rho-1$ is unbounded as $\rho\to+\infty$); see OPEN R5.

`[HEUR]` [scope: SG-R8, OPEN R7] In $T$, healing keeps sufficiently small $Q$ in the local protected regime. In $T_s$, small distinctions expand and RECOG-THM-TWIN-RADIAL-ACCESS proves that every $0<Q_0<\tfrac7{200}$ orbit reaches $|\rho|\ge\operatorname{arccosh}2$. Whether such orbits subsequently enter $D_s<0$, or whether $C_0^{(s)}$ itself is accessible, remains OPEN. "The symmetric twin runs into erasure" is **not** certified.

### §6.8 Comparison – Event – Memory Mapping `[ALG consequence]` {#sec-6-8-three-layers}

`[ALG consequence]` Three certified dyadic objects realise three distinct layers:

| Layer | Object | Source |
|---|---|---|
| comparison | $C_\to(a,b)=\overline W_aW_b$ | §6.1 (Genesis §6.1, §6.6) |
| closure defect | $T^6W-W=\mu_6|W|^2W+\cdots$ | Dyadic §6.7 |
| persisted memory | $\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ | Genesis §6.6 plateau shear bridge — `[ALG structure]`, leading plateau surrogate $\dot Q_k=-Q_k^2$, not an exact full-map identity; in RECOG's orientation $\theta^\to_{ab}=-\Phi_{ab}$ so $\theta^\to_{ab}(\infty)=\theta^\to_{ab}(0)+\tau\log(q_a/q_b)$; CELL-D's $\Lambda$ is one of the finite higher-order corrections this surrogate omits |

Recognition $\ne$ closure defect $\ne$ memory (SG-R6). `[ALG]` Three quarters of the primitive *local cubic angular return coefficient* is symmetry-breaking-mediated ($\Im\mu_6^{(s)}=\tfrac14\Im\mu_6$); no additive decomposition of the asymptotic plateau-memory law is claimed, since that law also uses the healing radial backbone, which the expansive twin does not share. `[HYP]` (SG-R1) These are successive layers of one relational geometry.

### §6.9 Ontology Export Interface `[DEF]` {#sec-6-9-export}

> **[Local guard SG-R1]** Witness citations only; no promotion.

`[DEF]` The ontology note (OFN / relational-existence thread) may cite the following RECOG objects as substrate witnesses, each with its tag and scope carried verbatim:
- $C_\to$ comparator structure and the swap-fixed set $\widehat C=\pm1$ (§6.1, SG-R9)
- $k_{\rm ret}(6)=3$ and the recognition multiplier $\chi_6$ (§6.2)
- cubic-return rigidity RECOG-ALG-CUBIC-RETURN-RIGIDITY (§6.7)
- radial-fate law $4a^2\gtrless3b$ (§6.7)
- candidate strata and prerequisite ladder (§6.5), as *candidates*
- all-$p$ return-order theorem and $\nu_3(\lambda)$ (§6.10)
- leading-return equivariance and comparator closure through degree $p-2$ (§6.12)
- lattice clock ratio $\lambda_{\rm DSI}^{1/6}$ and the leading lattice coefficient $\Lambda_1$ (§6.13), with SG-R10 scopes carried verbatim
- RECOG-THM-R9-MEMORY `[THM]` (§6.13a): retained memory $M=q_0[c_{\rm iso}+\Lambda_1(\Theta_0)]+R$ of the exact map, with the exact-map comparator-incompleteness corollary — exported only with its $C_z$ track and its smaller window $q_0<|G|/C_2$
- the two unstable futures of $P_2$ as `[THM]` (§6.11): RECOG-THM-P2-HET with its $C_0$-avoidance corollary, and RECOG-THM-P2-C0-FIRST (unique first transverse $C_0$ encounter in $B_*$, first-hit pole order, excursion in $(278.64^\circ,278.70^\circ)$); monotonicity of $\eta$ exported only as `[NUM strong]`

All interpretive statements formerly listed here ("existence $=$ recognisability", "physics at the intersection of compatible structures", "closure is arithmetic, defect geometric, recognition comparison") are moved to the ontology note as `[HYP]` and are not part of this ledger.

---

### §6.10 Resonant Return over the $p$-Family `[ALG]` {#sec-6-10-p-family}

> **[Local guard SG-R11]** $K_p$ family at fixed primitive shear; not the shear-jet family of §6.7.

`[DEF]` **Family.** $\rho'=\rho-\sin\eta$, $\eta'=\eta+K_p(e^\rho-1)-K_p\sin\eta$, $K_p=2-\lambda-\bar\lambda$, $\lambda=e^{2\pi i/p}$; eigenframe $\rho=uZ+\bar u\bar Z$, $\eta=Z+\bar Z$, $u=1/(1-\lambda)$ (as in the archived Dyadic normalisers). The $p=6$ member in this $Z$-frame relates to the $W$-frame by the exact scale $6\bar\lambda\nu_3(\zeta_6)=3\mu_6^{W}$.

`[ALG]` [RID: RECOG-ALG-LEADING-RETURN-EQUIVARIANCE] Leading-defect equivariance $LG_k=G_k\circ L$ (proof in §6.12). Consequence for $p\ge5$ [import: DYAD-ALG-BRIDGE-LEMMA, general form]: $[F_p^p-\mathrm{id}]_2=0$ and $[F_p^p-\mathrm{id}]_3=p\bar\lambda\,\nu_3^{(1,p)}Z^2\bar Z$, so raw $p$-fold composition and normalised-then-bridged routes give the same coefficient. Ownership of this general theorem is recommended for Dyadic (stream memo §1).

`[ALG]` [RID: RECOG-ALG-NU3-CLOSED-FORM] [cert: `recog_cell_a2_nu3_closed_form_cert.py`, 11 checks]
$$\nu_3(\lambda)=-\frac{\lambda^5-\lambda^4-\lambda^3-2\lambda^2+1}{2(\lambda-1)(\lambda+1)(\lambda^2+\lambda+1)},$$
obtained by symbolic $h_2$ normalisation; denominator zeros are exactly the $h_2$-resonant $\lambda$ ($p\le3$). Exact agreement with the archived $p=7$ normaliser ($\nu_3^{(1,7)}$, artifact `normalize_p7_full_onestep_cyclotomic.py`) and the $p=5$ $\mathbb Q(\zeta_5)$ certificate; raw-composition agreement for $p=5\ldots12$ to $10^{-30}$.

`[ALG]` [RID: RECOG-ALG-NU3-NONVANISHING] $N(\lambda)=\lambda^5-\lambda^4-\lambda^3-2\lambda^2+1$: $\gcd(N,\lambda^5N(1/\lambda))=1$ (no root on $|\lambda|=1$; numeric root moduli $0.603,0.688,1.962,1.108,1.108$) and $\gcd(N,\Phi_p)=1$ for $p\in\{1,2,3,4,5,6,8,10,12\}$ (all $p$ with $\varphi(p)\le5$). `[RESULT] [from: ALG]` $\nu_3^{(1,p)}\ne0$ and $k_{\rm ret}(p)=3$ for every $p\ge5$; no cubic-silent horizon exists. OPEN R2 closed.

`[ALG]` **Finite ledger** [cert: `recog_cell_a_p5_rawcomp_cert.py` (10 checks), `recog_cell_a_p7_rawcomp_cert.py` (5 checks)]: $\mu_5=\tfrac{-13-11\lambda-4\lambda^2-12\lambda^3}{2}$, $\nu_3^{(1,5)}=\tfrac{12-\lambda+\lambda^2+8\lambda^3}{10}$; $\mu_7=\tfrac{-16-11\lambda-6\lambda^2-15\lambda^3-3\lambda^4-12\lambda^5}{2}$, $\nu_3^{(1,7)}=\tfrac{12-4\lambda+\lambda^2+6\lambda^3-3\lambda^4+9\lambda^5}{14}$.

`[ALG]` **Exact radial identity** (external audit; verified symbolically here): $\Re\!\bigl(\bar\lambda\nu_3(e^{i\theta})\bigr)=\tfrac{\cos\theta-1}{2}=-\sin^2(\theta/2)$, hence in the $Z$-frame $\Re\mu_p=-p\sin^2(\pi/p)<0$ for every $p$, $\Re\mu_p\sim-\pi^2/p$. The series $\bar\lambda\nu_3=-\tfrac{i}{6\theta}-\tfrac{i\theta}{2}-\tfrac{\theta^2}{4}+\tfrac{11i\theta^3}{120}+\tfrac{\theta^4}{48}+O(\theta^5)$ and the v0.3 sign mesh are consequences. Since $\operatorname{sign}\Re\mu$ and $\arg\mu$ are invariant under $Z\to cZ$: healing for all sampled $p$; $\arg\mu_p=-120.96^\circ,-113.41^\circ,-108.33^\circ$ at $p=5,6,7$, monotone toward $-90^\circ$ `[OBS finite-p]` (three points; no monotonicity theorem). Note: at $p=5$ the quartic $\bar W^4$ channel is resonant ($p-1=4$); had $\mu_5$ vanished, $k_{\rm ret}(5)$ would have been decided at degree 4, not 5 — moot since $\mu_5\ne0$, but recorded against the v0.2.1 wording.

### §6.11 $P_2$ Invariant Manifolds `[THM / ALG / NUM historical]` {#sec-6-11-p2-manifolds}

> **[Local guard SG-R2]** All angles below are pole-comparator angles $\eta$. **[SG-R5]** No TDR-G transfer.

`[ALG]` [import: Dyadic §6.1] $J(P_2)=\begin{psmallmatrix}1&1\\1&2\end{psmallmatrix}$, $\lambda_{u,s}=\phi^{\pm2}$, $v_u=(1,\phi)$, $v_s=(1,-\phi^{-1})$. Parameterisation $P_u(t)=\lim_nT^n(P_2+t\lambda_u^{-n}v_u)$, $P_u'(0)=v_u$, $P_u(\lambda_ut)=T(P_u(t))$.

*(Historical `[NUM strong]` evidence, superseded as the basis of the positive-branch claim by RECOG-THM-P2-C0-FIRST below.)* `[NUM strong]` [RID: RECOG-NUM-P2-C0-FIRST] [cert: `recog_cell_b_p2_manifolds.py`] On $W^u_+(P_2)$ the first transverse encounter with $C_0$ is at $x_*=(\rho_*,\eta_*^{\rm lift})=(2.033364438914269\ldots,\ 8.005165051501685\ldots)$, $t_*=2.98946\ldots$, $Q_*=3.5984>Q_{\min}(C_0)$; $d\det J/dt\approx-9.38$ (transverse); $n=30\to35$ approximant change $<10^{-38}$. Both $\rho(t)$ and lifted $\eta(t)$ increase monotonically to $t_*$; comparator crossings at $\eta=\tfrac{3\pi}{2}$ ($\rho=0.9110425492$), $2\pi$ ($\rho=1.6327172351$), $\tfrac{5\pi}{2}$ ($\rho=2.0203832926$): itinerary $-1\to-i\to+1\to+i\to C_0$ in the $\ell=1$ lifted sector; excursion $\eta_*^{\rm lift}-\pi=4.8635724\,{\rm rad}=278.6621718^\circ$. Wrapped: $\eta_*^{\rm wrap}=1.7219797$, $\operatorname{dist}_{S^1}(\eta_*^{\rm wrap},\pi)=81.3378282^\circ$, with $\delta=\arccos\!\big(1/(e^{\rho_*}-1)\big)$ and $\eta_*^{\rm lift}=3\pi-\delta$, so the $8.662^\circ$ offset past the second quadrature is derived, not independent. The chart-free object is $x_*$; $\rho_*$ is its primitive-chart coordinate.

`[RESULT] [from: NUM]` The continuous dyad supplies an **oriented, $\ell=1$ lifted antipode-to-rank-loss excursion**, not a symmetric band; the wrapped $81.34^\circ$ is its shadow. Bridge questions for TDR-G (SG-R5): wrapped half-width vs lifted excursion; spacing statistic $n_{k+1}/n_k\stackrel?\to\lambda_{\rm DSI}^{1/6}$ (§6.13); memory statistic (comparator-completeness of retained discrete state).

`[ALG]` **Negative half-plane.** $\rho<0\Rightarrow e^\rho-1\in(-1,0)\Rightarrow0<\det J<2$: no rank loss on any segment confined to $\rho<0$. `[NUM strong]` [RID: RECOG-NUM-P2-HET-NEG] $\bigcup_{k\ge0}T^k(S)$ with $S=P_u([-\lambda_u,-1])$ covers the branch portion $t\le-1$ exactly; the local segment $-1<t<0$ is not covered but flows into $S$ (external audit). Every sampled point of $S$ (201 samples, independently reproduced) reaches $Q<0.3$ within 11–12 primitive steps; max $Q$ along the *post-initial* iterates $3.95$ — the initial state $P_u(-1)\approx(-0.9420,1.6619)$ itself has $Q=5.215$, which an enclosure specification must include; min $\det J$ en route $0.1367$; $W^u_-$ is not confined to $\rho<0$ (reaches $\rho\approx0.62$ near $\eta\approx-0.07$); six-step $Q$ from $P_u(-1)$ decreases monotonically through $m=200$ ($Q_{1200}\approx0.0048$). (Historical, v0.3–v0.3.2: heteroclinic connection conjectured on this evidence.)

`[THM]` [RID: RECOG-THM-P2-HET] [scope: conditional on postulated continuous generator $T$] $W^u_-(P_2)\setminus\{P_2\}\subset\mathcal B(P_1)$. [proof: `[ALG]` local quadratic-cusp shell + `[ALG via IA]` Arb/Lohner finite transport + import DYAD-THM-PRIM-CTR] Corollary `[THM]`: $W^u_-(P_2)\cap C_0=\varnothing$.

*Stage 1* `[ALG]` [exact symbolic constants + rational transcendental remainder bounds: $\sqrt5$ enclosed by rationals verified by squaring; $e^x\le1+x+\tfrac{x^2}{2(1-x/3)}$; $|\sin v-v|\le|v|^3/6$]. In eigen-coordinates $(s,w)$ at $P_2$ along $v_u=(1,\varphi)$, $v_s=(1,-1/\varphi)$, with $\delta=10^{-5}$, $\kappa=2$, $N=\{|s|,|w|\le\delta\}$, $R=\{|w|\le\kappa s^2\}$: (A) $T(R\cap N)\subset R$; (B) on $N\setminus R$, $|w(Ty)|\le\theta|w(y)|$ with $\theta=0.60560$; (C) on $R\cap N$, $s(Ty)/s(y)\in[\lambda_-,\lambda_+]$, $\lambda_-=2.618032$; (D) $\kappa\delta^2\le\delta$. The local unstable graph is $C^\omega$ and tangent to $v_u$, so $w=h(s)=O(s^2)$; the certified complement contraction (B) and the invariant boundary $|w|=\kappa s^2$ (A) force the local negative unstable graph into $R$ — the quadratic bound is proved, not inferred from tangency. With outward monotonicity (C) and backward convergence of $W^u_-(P_2)$ to $P_2$, every nonfixed branch point $x$ can be written $x=T^ky$ for some $k\ge0$ and some $y\in W^u_-(P_2)\cap\Sigma$, where $\Sigma=\{s\in[-\delta,-\delta/\lambda_+],\ |w|\le\kappa s^2\}$ (backward iteration along the branch reaches the local shell). Certifying that every point of the two-dimensional shell $\Sigma$ enters $U$ therefore certifies the whole negative unstable branch a fortiori, since $T^ky$ enters $U$ whenever $y$ does; no evaluation of $P_u(t)$ enters the proof.

*Transport* `[ALG via IA]` (rep: primitive-lift) (transport: $T$). $\Sigma$ is tiled by 4096 exact-rational $s$-intervals; each piece is enclosed as $X=c+R_kE$ (point centre, exact point frame $R_k$, Arb ball box $E$) and advanced by the mean-value inclusion $T(X)\subset T([c])+\bigl(DT(\mathrm{hull}(X\cup c))R_k\bigr)E$. The new frame $R_{k+1}$ is $Q$-orthonormal (the $P_1$ linear map $L$ satisfies $L^\top BL=B$), oriented on the image of the long axis of $E$; any frame is admissible, and its inverse is enclosed in Arb. Entry is tested on the primitive $Q_{\rm prim}=\rho^2-\rho\eta+\eta^2$ against the exact rational $\tfrac1{625}$, with certified positivity. Result: all 4096 pieces enter $U$ after 3655–3673 steps; entry $Q_{\rm prim}\in[0.0015897542,\,0.0015999994]$; $\min\inf\det DT=0.1366523$ over all pre-entry enclosures; maximum box width $6.71\times10^{-4}$; no splits. Arb (python-flint 0.9.0, 120 bits) is the trust anchor; an mpmath.iv prototype agreed on test pieces and contributes nothing to the grade.

*Tail* `[import: DYAD-THM-PRIM-CTR]`: every trajectory in $U$ stays in the six-phase tube $U_T$ and tends to $P_1$.

*Corollary.* Pre-entry: $\det DT\ge0.1366523>0$. In the tube: $U_T\subset\{Q_{\rm prim}<2209\times10^{-6}\}$ and $Q_{\rm prim}\ge\tfrac34\rho^2$ give $|\rho|<0.0543$, hence $\det DT=1+(e^\rho-1)\cos\eta\ge\min\{e^{-0.0543},2-e^{0.0543}\}>0.944$. So $\det DT>0$ everywhere on $W^u_-(P_2)$: the negative branch never meets $C_0$.

(v0.3.3–v0.3.4 recorded this as mixed grade; retired in v0.3.5.)

`[THM]` [RID: RECOG-THM-P2-C0-FIRST] [scope: conditional on postulated continuous generator $T$] Parametrise $W^u_+(P_2)$ outward from $P_2$. There exists a unique first outward parameter value $p_*$ at which $W^u_+(P_2)$ meets $C_0$; $\det DT>0$ at every earlier branch point, and the first encounter is transverse; $(\rho_*,\eta_*^{\rm lift})\in B_*=\bigl(\tfrac{101667}{50000},\tfrac{101671}{50000}\bigr)\times\bigl(\tfrac{5003}{625},\tfrac{80059}{10000}\bigr)$, i.e. $2.03334<\rho_*<2.03342$, $8.0048<\eta_*^{\rm lift}<8.0059$. No assertion about later re-intersections. [proof: `[ALG]` R8 quadratic cusp + `[ALG via IA]` unstable-cone lemma + `[ALG via IA]` Lohner+tangent transport and root isolation]

*Stage 1* `[ALG]`: the R8 quadratic-cusp lemma at $P_2$ ($\delta=10^{-5}$, $\kappa=2$) is symmetric in the sign of $s$ and is reused unchanged; $\lambda_-$ is recomputed as an exact rational (the R8 float export is not a lower bound). *Stage 1b* `[ALG via IA]`: the unstable cone $\{|dw|\le\tfrac1{100}|ds|\}$ is forward-invariant under $DT$ on $N=\{|s|,|w|\le\delta\}$ (Arb), so the tangent of the local unstable graph is $v_u+mv_s$, $|m|\le\tfrac1{100}$; $\det DT\ge0.99998$ on $N$. *Shell placement*: $s\in[s_0,s_1]$ with $s_1=\tfrac54s^*_{\rm design}$, $s_0=s_1/\lambda_+$; re-checked on the certified bracket, $s_1/\lambda_-<s^*\in[4.20646,4.20725]\times10^{-6}<s_1$, so no step-$(K-1)$ image of the shell lies after the encounter. *Transport and root isolation* `[ALG via IA]`: 4096 pieces, Lohner enclosures with tangent enclosures $v_{k+1}\in DT(H_k)v_k$; $\det DT>0$ certified on every enclosure at steps $1,\dots,13$; at $K=14$ the zero-containing pieces form one contiguous block (one piece), every earlier piece has $\det>0$, the next has $\det<0$, and $\nabla\det\cdot v_{14}<0$ on the block. Hence $f(s)=\det DT(T^{14}\gamma(s))$ has exactly one zero there and none before. "First" refers to the outward parametrisation; no injectivity of the branch is used. $B_*$ and the excursion bound are compared directly as Arb enclosures against exact rationals; tighter hulls in the result record are `num_display` only. The script hashes the R8 engine before import and refuses to run on mismatch.

`[RESULT]` `[from: THM]` **Two unstable futures of the antipodal saddle, both theorem-grade:** $W^u_-(P_2)\to P_1$ with $W^u_-(P_2)\cap C_0=\varnothing$; $W^u_+(P_2)$ reaches $C_0$ at its unique first transverse encounter, after the first-hit pole itinerary $-i\to+1\to+i$. Monotonicity of $\eta$ stays `[NUM strong]`; later re-intersections and $W^s(P_2)$ are not addressed.

### §6.12 Leading-Return Equivariance and Comparator Closure `[ALG / mixed]` {#sec-6-12-equivariance}

`[ALG]` [RID: RECOG-ALG-LEADING-RETURN-EQUIVARIANCE] **Theorem.** Let $F=L+F_2+\cdots$ with $L^p=I$ and $F^p=\mathrm{id}+G_k+O(k+1)$, $G_k\ne0$. Then $LG_k(x)=G_k(Lx)$.
*Proof.* Expand $F\circ F^p=F^p\circ F$ at degree $k$: the left side gives $LG_k(x)+F_k(x)$, the right side $F_k(x)+G_k(Lx)$ (all other contributions have degree $\ge k+1$). $\square$ Gauge-independent; valid for any number of modes with $L=\operatorname{diag}(A,\ldots,A)$.

`[ALG]` [scope: resonant normal-form frame] [RID: RECOG-ALG-COMPARATOR-CLOSURE] In the eigenframe, $\mathbb Z_p$-equivariance of an output-$W_a$ monomial requires $\#W-\#\bar W\equiv1\pmod p$. For total degree $\le p-2$ this forces $\#W-\#\bar W=1$, i.e. $U(1)$-equivariance, so every such term is $\sum_bW_bP_{ab}(\{C_\to(c,d)\})$ (cubic: $\sum\alpha W_bC_\to(c,d)$): the return content lies in the comparator algebra $\{Q_a,C_\to(a,b)\}$. At degree $p-1$ the monomial $\bar W^{p-1}$ ($\#W-\#\bar W=-(p-1)\equiv1$) is the first symmetry-allowed non-comparator channel. Genesis' certified $\Delta Q_d^{(4)}$, written entirely in $Q,I_{ab},\omega_{ab}$, is an instance.

`[ALG consequence]` **Uncoupled pair.** For two states of one map, $\Delta\log C_\to=\bar\mu Q_a+\mu Q_b+O(Q^2)$, so $\Delta\theta_{ab}=-\tau(Q_b-Q_a)$: the encounter residue is the difference of the two self-return residues; equal amplitudes build no relative phase at cubic order; integrating along $Q_k(t)=q_k/(1+q_kt)$ reproduces $\Phi_{ab}(\infty)=\Phi_{ab}(0)-\tau\log(q_a/q_b)$ (Genesis §6.6). Genuine encounter content is the off-diagonal $\alpha$ of coupled systems (Genesis torque channels).

`[RESULT] [from: ALG]` Recurrence recognition and encounter recognition are the diagonal and off-diagonal cases of one comparator algebra through degree $p-2$; R6's unification sub-item is closed.

### §6.13 Lattice Readability, Clock, and Retained Memory `[ALG / mixed]` {#sec-6-13-lattice}

> **[Local guard SG-R10]** Invariant vs `[conv: Lie strict-kernel]` quantities are marked; $\Lambda$ is leading order.

`[COR]` **Frame correction (external audit, confirmed by independent $H_2$ conjugation here).** Dyadic §6.9's $c_{32}=-\tfrac{77}{216}+i\tfrac{97\sqrt3}{648}$, $c_{05}=-\tfrac{61}{2160}-i\tfrac{43\sqrt3}{6480}$ are coefficients of the **raw** six-step map in the linear eigenframe, where the quartic jet is nonzero; $47/54=|\mu|^2+2\Re c_{32}^{\rm raw}$ and $\Im\beta^{\rm raw}=c_\theta^{(6)}$ are identities in that frame. Conjugating $T^6$ by $H_2=\mathrm{id}+h_2$ (Dyadic §6.2) gives zero quartic jet, unchanged $\mu$, and
$$c_{32}^{\rm NF}=-\tfrac{97}{432}+i\tfrac{197\sqrt3}{324},\qquad c_{05}^{\rm NF}=-\tfrac{49}{8640}-i\tfrac{307\sqrt3}{25920}=6\bar\lambda\,\nu_5^{(1,6)}\ \text{(Dyadic §6.11, exact)}.$$
A cubic residual gauge cannot generate the charge $-5$ channel, so $c_{05}^{\rm NF}$ is the lattice coefficient of the normal form; $c_{32}$ remains subject to the residual-gauge caveat of Dyadic §6.9. v0.3 used the raw values inside a normal-form model; those numbers are superseded (Appendix B) and restated below in the post-$H_2$ frame where computed; the remaining raw-frame quantities are historical; the chart-native values are those of the completed §6.14 ledger (R11 CLOSED). [cert: `recog_cell_d_lattice_memory_cert.py` rev. 4, checks 1–6 derive both frames from the primitive map.] [cert: `recog_cell_c_lattice_readability_cert.py`, 6 checks — raw-frame identities, retained as identities of their inputs only.] With $W=\sqrt Qe^{i\Theta}$ in the post-$H_2$ frame:
$$\chi_6=1+\mu Q+\bigl(c_{32}^{\rm NF}+c_{05}^{\rm NF}e^{-6i\Theta}\bigr)Q^2+\cdots,\qquad \log\chi_6=\mu Q+\bigl(\beta^{\rm NF}+c_{05}^{\rm NF}e^{-6i\Theta}\bigr)Q^2+\cdots,\quad\beta^{\rm NF}=c_{32}^{\rm NF}-\tfrac{\mu^2}{2}=\tfrac{137}{432}+i\tfrac{89\sqrt3}{324}.$$
(Raw frame: $\beta^{\rm raw}=\tfrac{5}{27}-i\tfrac{119\sqrt3}{648}$ with $\Im\beta^{\rm raw}=c_\theta^{(6)}$ — a raw-frame identity.) Recognition is phase-blind through order $Q$ and acquires sixfold angular modulation at order $Q^2$ in either frame.

`[ALG]` [RID: RECOG-ALG-LATTICE-STRENGTH] $|\mu|^2=19/12$; $\mathcal I_{\rm lat}:=|c_{05}^{\rm NF}|/|\mu|^2\approx0.0134426$ (post-$H_2$; the v0.3 value $0.0192569$ was the raw-frame number), invariant under $W\to cW$ (both scale as $|c|^{-4}$) and under $U(1)$-equivariant residual gauge. Operationally, lattice amplitude / leading comparator amplitude $=\mathcal I_{\rm lat}\,|\mu|Q$. `[historical, raw frame — superseded by the completed §6.14 ledger]` $|c_{05}|/|\beta|\approx0.0828$, $|c_{05}|/|\Re\beta|\approx0.165$, $|c_{05}|/|\Im\beta|\approx0.096$; $\arg c_{05}^{\rm NF}=-105.45^\circ$ vs raw $-157.85^\circ$, so the sixfold axes of v0.3 are also superseded. No amplitude $Q_{\rm lat}$ at which anisotropic and isotropic quintic content cross exists (both $\propto Q^2$); the "leading-crossing" value $|\mu|/|c_{05}|\approx41.3$ is outside the local regime.

`[ALG consequence]` [RID: RECOG-ALG-LATTICE-CLOCK] $\Psi_{\rm lat}:=\arg c_{05}-6\Theta\pmod{2\pi}$ is exactly invariant under linear $W\to cW$ ($\tilde c_{05}=c\bar c^{-5}c_{05}$, $\tilde\Theta=\Theta+\phi$) but not under nonlinear equivariant gauge ($\widetilde W=e^{ia|W|^2}W$ shifts it by $-6aQ$); the asymptotic ratio below is unaffected. Along the backbone $\Theta_m\approx\Theta_0-\tau\log m$, successive thresholds $\Psi_{\rm lat}=\psi_0+2\pi k$ (accumulated defect $\pi/3$ each) occur at $m_k=A(x_0,\psi_0)e^{k\pi/(3\tau)}(1+o(1))$, hence $m_{k+1}/m_k\to e^{\pi/(3\tau)}=\lambda_{\rm DSI}^{1/6}=(R^*)^{1/3}=2.476632\ldots$ [import: RTG_NUMBER_GENESIS_DSN_v1.20.4 | NUMGEN-THM-N5AS1-DEFECT-THRESHOLD-RATIO] [import: Dyadic §6.3 constants]. Per-threshold modulation $A_{{\rm lat},k}\sim|c_{05}|/m_k^2$ fades by $\lambda_{\rm DSI}^{-1/3}$ per threshold; relative to the leading residue by $\lambda_{\rm DSI}^{-1/6}$. The prefactor is orbit- and convention-dependent at subleading order; the ratio is universal in the local $p=6$ healing sector.

`[ALG consequence, leading order]` [RID: RECOG-ALG-LATTICE-MEMORY] [cert: `recog_cell_d_lattice_memory_cert.py` rev. 4, 26 checks] Let $z_m=c_{05}Q_m^2e^{-6i\Theta_m}$. The direct phase kick $\Im z_m$ and the radial kick $2Q_m\Re z_m$ (propagated through $Y=1/Q$: $\delta Y=-2\Re[Z_0(x^{6i\tau}-1)/(6i\tau)]$, fed back via $-\tau Q$) sum absolutely, giving
$$\boxed{\Lambda(Q_0,\Theta_0)=\Delta\Theta_{\rm lat}(\infty)=Q_0\,\Im\!\Bigl[\tfrac{1-2i\tau}{1-6i\tau}c_{05}^{\rm NF}e^{-6i\Theta_0}\Bigr]+O(Q_0^2)=\tfrac{Q_0}{1270080}\bigl[43\sin6\Theta_0-5611\sqrt3\cos6\Theta_0\bigr]+O(Q_0^2)},$$
with $|1-6i\tau|=7$ exactly, $\tfrac{1-2i\tau}{1-6i\tau}=\tfrac{17+4i\tau}{49}$, $\tfrac{1-2i\tau}{1-6i\tau}c_{05}^{\rm NF}=-\tfrac{43+5611\sqrt3\,i}{1270080}$ (raw-frame v0.3 value $-\tfrac{2767+1219\sqrt3\,i}{317520}$ superseded). Invariant form: $\Lambda=\tfrac q\gamma\Im[\tfrac{1-2i\sigma}{1-6i\sigma}c_{05}e^{-6i\Theta_0}]+O(q^2)$, $\gamma=-2\Re\mu$, $\sigma=-\Im\mu/\gamma$ (canonical: $\gamma=1,\sigma=\tau$); $\tfrac q\gamma c_{05}e^{-6i\Theta_0}$ is exactly frame-invariant. Numerics (post-$H_2$ truncated model with/without $c_{05}^{\rm NF}$, rev. 4; unchanged from rev. 3): relative error $0.22,0.11,0.050$ at $Q_0=0.04,0.02,0.01$ — an $O(Q_0)$ correction, as expected. No retained multiplicative/$\log Q$ memory ($|\Delta\log Q|<10^{-6}$ on all runs; a bounded log-periodic oscillation in $1/Q$ is not excluded). Leading amplitude $|\Lambda|\le0.007652\,Q_0$ — leading order only, for the truncated model (R9, R10, R11).

`[ALG consequence]` [historical truncated-model diagnostic; theorem: §6.13a] **Comparator-completeness counterexample.** Pairs $\mathcal P_\alpha$: $(Q_a,Q_b)=(q,q)$, $(\Theta_a,\Theta_b)=(\alpha,\alpha+\tfrac\pi6)$. All $\mathcal P_\alpha$ have identical comparator data ($Q_b/Q_a=1$, $\Delta\theta=\pi/6$), yet retain $\Delta\Phi_{\rm lat}(\alpha)=-2\Lambda(q,\alpha)+O(q^2)$, which depends on $\alpha$ (certified, rev. 4: $+3.13\times10^{-4}$ vs $-3.12\times10^{-4}$ at $q=0.02$, $\alpha=0,0.5$ for identical post-$H_2$ data, and $+3.45\times10^{-4}$ vs $-3.35\times10^{-4}$ for identical canonical raw comparator data; $\alpha=0.25$ lies near a node of the post-$H_2$ lattice phase). `[RESULT] [from: ALG]` $(Q_a/Q_b,\Delta\theta_{ab})$ is insufficient to determine asymptotic memory once $c_{05}\ne0$; the missing datum is the lattice phase. Comparator closure fails at the memory layer, at $O(Q_0)$.

`[COR v0.3.2]` The v0.3 "corrected backbone for R9" (built on $\tfrac{47}{54}$ and $c_\theta^{(6)}$) is retired to Appendix B: both inputs are archival/raw-frame objects that Dyadic v6.4.10 SG-19 forbids transferring into the chart ($\tfrac{47}{54}$ is the raw fixed-radius angular mean $\mathcal A_{\rm raw}$, not a pointwise recurrence). The chart-native backbone is in §6.14; the Euler–Maclaurin kernel identity $q^2\sum_{m\ge0}(1+qm)^{-2+6i\tau}=\tfrac{q}{1-6i\tau}+\tfrac{q^2}{2}+O(q^3)$ is frame-free and retained. **Typing of the counterexamples (SG-R14):** the rev. 3 pair test (identical $(q,\Delta\Theta)$) is the $C_z$ track; the rev. 4 pair test (identical raw $\bar w_aw_b$ transported through $h^{-1}$, both preimages under the same $h$) is the $C_W^{(h)}$ track; historical truncated-model incompleteness diagnostics were exhibited in both tracks; RECOG-THM-R9-MEMORY and its exact-map incompleteness corollary are certified on the $C_z$ track only. Neither historical diagnostic certifies the exact-map observable; that certification is supplied separately by RECOG-THM-R9-MEMORY in §6.13a.

`[HEUR]` The factor $1/(1-6i\tau)$ has the same resolvent/alias form as the Dyadic OPEN 16 value $G_-(\pi/\tau)=1/(1-i\tau)$, at the sixth logarithmic harmonic. Structural match generated independently here; not an import (OPEN 16's full operator is open).

#### §6.13a Retained memory of the exact map (R9) `[THM]` {#sec-6-13a-r9}

> **[SG-R13, SG-R14 apply]** (rep: NF chart $z$ of DYAD-ALG-NF6, track $C_z$) (transport: exact six-step normalised return $\widehat F=h^{-1}F_Wh$).

`[DEF]` **Observable.** $q=|z|^2$; $\Theta$ = continuous lift of $\arg z$ along the orbit (each step $|\widehat F(z)/z-1|<1$); $\Psi(z)=\Theta-\tau\log q$, $\tau=\tfrac{2\sqrt3}{3}$; $M(z_0)=\Psi_\infty-\Psi(z_0)$, $\Psi_\infty=\lim_m\Psi(z_m)$. One orbit, one chart, no comparison dynamics. `[DEF]` **Averaging function.** $g(\Theta)=c_{\rm iso}+\Im(Ge^{-6i\Theta})$, $\Phi=\Psi+q\,g(\Theta)$, with $c_{\rm iso}=\Im[(1-2i\tau)\beta]=-\tfrac{4\sqrt3}{27}$ ($\beta=a_{32}-\mu^2/2$) and $(1-6i\tau)G=(1-2i\tau)a_{05}$, i.e. $G=-\tfrac{43+5611\sqrt3\,i}{1270080}$, $|G|=0.0076520$.

`[THM]` [RID: RECOG-THM-R9-MEMORY] [scope: conditional on postulated $T$; exact normalised return $\widehat F$ in the DYAD-ALG-NF6 chart; comparator track $C_z$] For $0<q_0\le q_{\max}$: $M(z_0)=q_0[c_{\rm iso}+\Lambda_1(\Theta_0)]+R$, $|R|\le C_2q_0^2$, with $c_{\rm iso}=-\tfrac{4\sqrt3}{27}$, $\Lambda_1(\Theta)=\tfrac{43\sin6\Theta-5611\sqrt3\cos6\Theta}{1270080}$; rows (not mixed): $(C_2,q_{\max})=(517,\tfrac1{400})$ on $|z|\le\tfrac1{20}$, $(163,\tfrac1{1600})$ on $|z|\le\tfrac1{40}$.

*Proof.* The $q^2$-increment of $\Psi$ is $[c_{\rm iso}+\Im((1-2i\tau)a_{05}e^{-6i\Theta})]q^2$ and $\Delta(qg)=-(g+\tau g')q^2+O(q^3)$; the choice of $g$ makes $g+\tau g'$ equal to that increment (cohomological identity checked exactly), so $|\Delta\Phi|\le K_\Phi q^3$ on the row's domain, with $K_\Phi$ built from the jet coefficients, $C_7$ (DYAD-THM-NF-REM) and four elementary remainder inequalities, all constants enclosed in Arb ($K_\Phi\le258.49$ / $81.44$). Forward invariance and $\sum_mq_m^3\le2q_0^2$ (NF-REM) give convergence of $\Phi(z_m)$; $q_mg\to0$ gives $\Psi_\infty=\Phi(z_0)+\sum_m\Delta\Phi_m$, hence $|R|\le2K_\Phi q_0^2=C_2q_0^2$. $\square$ No Euler–Maclaurin step and no fitted backbone are used.

`[THM]` **Corollary (exact-map $C_z$ comparator incompleteness).** For $q_a=q_b=q_0$, $\Theta_b-\Theta_a=\delta$: $\lim_m(\Theta_{b,m}-\Theta_{a,m})=\delta+q_0[\Lambda_1(\Theta_a+\delta)-\Lambda_1(\Theta_a)]+(R_b-R_a)$, $|R_b-R_a|\le2C_2q_0^2$ (the $\tau\log(q_b/q_a)$ term vanishes since $1/q_m=m+O(\log m)$). With $\delta=\pi/6$ the sixfold harmonic reverses sign and a suitable $\Theta_a$ gives difference $2|G|$; the lattice memory is therefore certified nonzero whenever $q_0<|G|/C_2$.

| Row | domain | $q_{\max}$ | $C_2$ | memory theorem | certified incompleteness window |
|---|---|---|---|---|---|
| large | $|z|\le\tfrac1{20}$, $C_7=100$ | $\tfrac1{400}$ | $517$ | $0<q_0\le\tfrac1{400}$ | $q_0<|G|/517=1.48\times10^{-5}$ |
| small | $|z|\le\tfrac1{40}$, $C_7=30$ | $\tfrac1{1600}$ | $163$ | $0<q_0\le\tfrac1{1600}$ | $q_0<|G|/163=4.69\times10^{-5}$ |

The memory theorem holds on the whole row; the incompleteness witness only on the smaller window. The window is $C_7$-limited (a $[{\rm NUM}]$ check on $J$ gives $|M-q_0g|/q_0^2\approx0.934$, flat in $q_0$, so $C_2$ is conservative by $\sim$170–550); the deferred $C_7$ sharpening would widen it roughly proportionally.

`[DEF]` **RID hierarchy.** RECOG-ALG-LATTICE-MEMORY remains the algebraic leading lattice coefficient $\Lambda_1(\Theta)$ (§6.13); RECOG-THM-R9-MEMORY is its finite-$q_0$ exact-map promotion, adding the isotropic term $c_{\rm iso}q_0$ that the earlier with/without-$c_{05}$ comparison hid. The CELL-D rev. 3/rev. 4 counterexamples are retained as historical truncated-model diagnostics; they are no longer the source of the theorem.

### §6.14 The $h$-Chart Ledger (R11) `[ALG / import]` {#sec-6-14-chart-ledger}

> **[Local guards SG-R13, SG-R14 apply]** · **[SG-R7: conditional on the postulated generator $T$]**

`[import: Dyadic v6.4.10 §6.14]` **Owner package (accepted).** Chart $W=h(z,\bar z)$, $h=\mathrm{id}+h_2+\cdots+h_6$, resonant monomial coefficients of each $h_n$ zero (`DYAD-ALG-NF6`; 23 coefficients in $\mathbb Q(i\sqrt3)$, table in the P2-B v2 evidence archive); six-step jet $J(z)=z+\mu z^2\bar z+a_{32}z^3\bar z^2+a_{05}\bar z^5$, $\mu=-\tfrac12-\tfrac{2i\sqrt3}{3}$, $a_{32}=-\tfrac{97}{432}+\tfrac{197i\sqrt3}{324}$, $a_{05}=-\tfrac{49}{8640}-\tfrac{307i\sqrt3}{25920}=6\bar\lambda n_{05}$; obstruction $c_{05}^{\rm raw}-a_{05}=\tfrac{-13+3i\sqrt3}{576}\ne0$ (`DYAD-ALG-NF6-OBS`); inverse chart on $|z|\le\tfrac1{10}$, $|W|\le\tfrac9{100}$, $\tfrac{225}{256}|z|^2\le Q_{\rm prim}\le\tfrac{289}{256}|z|^2$ (`DYAD-THM-NF-INV`); $|\widehat F-J|\le C_7|z|^7$, $\|D\widehat F-DJ\|_2\le C_D|z|^6$ with $(C_7,C_D)=(100,1000)$ on $|z|\le\tfrac1{20}$ and $(30,250)$ on $|z|\le\tfrac1{40}$, rows not to be mixed; $\widehat U_T\subset\{|z|<\tfrac1{20}\}$; $0<q-\tfrac32q^2\le|\widehat F(z)|^2\le q-\tfrac12q^2$ on $0<q\le\tfrac1{400}$, $\sum q_m^3\le2q_0^2$ (`DYAD-THM-NF-REM`); primitive contraction $(108,\tfrac1{400},\tfrac1{625},\tfrac12)$ with tube $U_T$ (`DYAD-THM-PRIM-CTR`). Independent checks in this session: the referee harness §3 (20/20) and a reconstruction of the degree-9 jet, $h$, $J$, $D_{\rm poly}$ (§8). The values $a_{32},a_{05}$ coincide with RECOG's post-$H_2$ $c_{32}^{\rm NF},c_{05}^{\rm NF}$ (v0.3.1): higher $h_3..h_6$ leave the resonant quintic slots unchanged.

`[ALG]` [RID: RECOG-ALG-CHART-LAWS] [cert: `recog_r11_chart_ledger_cert.py` checks 1–4] **Chart-native laws (finite-jet identities from $J$).** With $z=\sqrt qe^{i\Theta}$:
$$|J(z)|^2=q-q^2+\Bigl[\tfrac{245}{216}+2\Re\bigl(a_{05}e^{-6i\Theta}\bigr)\Bigr]q^3+O(q^4),\qquad \tfrac{245}{216}=|\mu|^2+2\Re a_{32};$$
$$\arg\frac{J(z)}{z}=-\tau q+\Bigl[\tfrac{89\sqrt3}{324}+\Im\bigl(a_{05}e^{-6i\Theta}\bigr)\Bigr]q^2+O(q^3),\qquad \tfrac{89\sqrt3}{324}=\Im\bigl(a_{32}-\tfrac{\mu^2}{2}\bigr).$$
With `NF-REM` these become laws for the exact $\widehat F$ with remainders $O(q^4)$ (amplitude: $|q'-|J|^2|\le(2|J|C_7+C_7^2|z|^6)|z|^7$) and $O(q^3)$ (phase: $|(\widehat F-J)/z|\le C_7|z|^6=C_7q^3$, the per-block term of the R9 budget) respectively. The chart quintic phase coefficient is **positive**, opposite in sign to the archival $c_\theta^{(6)}=-\tfrac{119\sqrt3}{648}$; the chart isotropic quintic amplitude coefficient $\tfrac{245}{216}$ differs from the raw angular mean $\tfrac{47}{54}$. These are the concrete reasons no archival quantity is transferred.

`[DEF]` **Refusal line.** $\tfrac{47}{54}$ ($\mathcal A_{\rm raw}$), $c_\theta^{(6)}$, $a_1$, $a_2$ (Lie-gauge archival object) and any fitted long-orbit backbone are not inputs to any RECOG statement in the chart.

`[ALG]` [cert: checks 5–7] **Comparator tracks.** Native: $C_z(a,b)=\bar z_az_b$, $q=|z|^2$; exact identities $C_z(-a,-b)=C_z(a,b)$, $C_z(-a,b)=-C_z(a,b)$. Transported canonical: $C_W^{(h)}(a,b)=\overline{h(z_a)}h(z_b)=\bar z_az_b+\overline{h_2(z_a)}z_b+\bar z_ah_2(z_b)+O(|z|^4)$, $Q_{\rm prim}=|h(z)|^2=t^2-\tfrac34t^3+O(t^4)$ on the real ray. The two tracks differ at cubic order; comparison by $C_z$ is admissible only for preimages under the same registered $h$ (RRF common-realisation condition). RECOG's leading-return theorems (§6.2, §6.12) are track-independent; historical truncated-model incompleteness diagnostics (§6.13) were exhibited in both tracks; RECOG-THM-R9-MEMORY and its exact-map incompleteness corollary are certified on the $C_z$ track only (§6.13a).

`[ALG]`/`[import: RRF Registry v0.4 §2.3–4.2, convention only]` [cert: check 9] **Relabeling action.** $S_h=h\circ(-I)\circ h^{-1}$ is an exact involution on $h(D)$; $\mathcal J_{\le6}(f\circ S_h-S_h\circ f)=0$ (degree-6 certified, not all-orders); $C_W(S_ht,S_ht)-C_W(t,t)=\tfrac32t^3+O(t^4)$ (verified here with an independently reconstructed $h$). Whether $S_h$ is the physical pole relabeling is RRF OPEN-A, outside RECOG.

`[ALG]` [cert: check 8] **R9 budget.** Degree-$\ge7$ contribution to the retained memory $\le2C_7q_0^2$; leading coefficient $|\Lambda_1|\le0.0076520$; dominance threshold $q_0<|\Lambda_1|/(2C_7)=3.83\times10^{-5}$ ($C_7=100$), $1.28\times10^{-4}$ ($C_7=30$).

`[DEF]` **Network guard (SG-R5 extension).** The single-dyad chart does not transport linear network closure: $W_{AB}+W_{BC}+W_{CA}=0$ becomes $h(z_{AB})+h(z_{BC})+h(z_{CA})=0$, not $\sum z_e=0$; no $z$ appears in a network incidence equation (RRF `RRF-NET-W-RAW`, bridge `[OPEN]`).

---

### §6.15 Global Radial Access of the Symmetric Twin (R7) `[THM / ALG / NUM]` {#sec-6-15-twin-access}

> **[Local guard SG-R4]** $T_s(\rho,\eta)=(\rho-\sin\eta,\ \eta+\sinh\rho-\sin\eta)$ is a diagnostic twin; nothing here transfers to the primitive $T$ or exports to Genesis/Triadic/TDR-G. (rep:) primitive-lift / raw $P_1$ eigenframe $W=\rho+\omega\eta$, $Q=|W|^2$; (transport:) $T_s$.

`[NUM]` [RID: RECOG-NUM-E1-TWIN-SURVEY] [cert: `recog_cell_e1_twin_survey.py`, `e1_survey.json`] Binary64 fate survey, four radii × 120 angles in a $60^\circ$ sector plus exact antipodes. All 480 twin seeds enter $D_s\le0$ (none escape, return or stay bounded); exits from $Q\le\tfrac1{400}$ match $n\approx6(1/Q_0-400)$ ($4268$–$4270$, $12604$–$12605$, $57608$–$57609$ vs predicted $4266.7$, $12600$, $57600$); post-exit transit $\approx2421$–$2448$ steps; hit branch ($\rho\gtrless0$) phase-dependent. The primitive $T$ control never enters $D\le0$. Antipodal seeds built by exact negation give identical determinant histories (odd symmetry check). The $r_0=0.05$ family starts on the exit boundary. Contributor extension (not an artifact): full $2\pi$ sweep, 720 angles per radius, all enter $D_s\le0$, branches split exactly $360/360$. `RANK` means entry into $D_s\le0$, not a hit on $C_0^{(s)}$.

`[ALG]` [RID: RECOG-ALG-TWIN-EXPANSION] [cert: `recog_cell_e2a_twin_expansion.py`] $T_s$ is exactly odd, so $F=T_s^6$ has no even-degree terms; by leading-return equivariance its cubic term is $\mu_s|W|^2W$, $\mu_s=\tfrac12-\tfrac{i\sqrt3}{6}$, $2\Re\mu_s=1$, $|\mu_s|^2=\tfrac13$. With the Arb jet through degree 9 ($b_5\le0.643$, $b_7\le0.691$, $b_9\le0.574$) and the majorant $\Psi_s(t)=t+2(\sinh at-at)$, $a=\tfrac76>\tfrac2{\sqrt3}$ (checked in Arb against exact rationals): $Q+c_-Q^2\le Q(F(W))\le Q+c_+Q^2$ on $0<Q\le\tfrac1{25}$ with $c_->\tfrac{19}{20}$, $c_+<\tfrac{43}{40}$, uniformly in phase. No normalizer is needed.

`[ALG]` [RID: RECOG-ALG-TWIN-ANNULUS] (E2B, in the same certificate) $q_1=\tfrac7{200}$, $q_2=q_1+\tfrac{43}{40}q_1^2=\tfrac{58107}{1600000}<\tfrac1{25}$. If $0<Q_0<q_1$, the six-step sequence satisfies $Q_{m+1}\ge Q_m+\tfrac{19}{20}Q_m^2$, so it crosses $q_1$, and at the first crossing $Q_{m_*}<q_2$: every such orbit has a six-step iterate in $\mathcal A=\{q_1\le Q<q_2\}$.

`[ALG via IA]` [RID: RECOG-ALG-TWIN-ANNULUS-TRANSPORT] (E2C) Every point of $\mathcal A$ reaches $|\rho|\ge\operatorname{arccosh}2$ within 256 primitive steps. Cover: half-annulus $\theta\in[0,\pi)$ (exact oddness and antipodal invariance of the target give $[\pi,2\pi)$), $4096\times32$ sectors with exact angles $k\pi/4096$ and exact rational $Q$-edges; each sector enclosed exactly in a rotated $W$-rectangle and a $Q$-orthonormal frame. Transport: frozen R8 Lohner mathematics (hash-gated) with $T_s$, local frame-native split-and-recentre, split width $0.05$, leaf budget $4096$ (pure hard stop), $N_{\max}=256$, Arb 120 bits. Per-tile stopping when the whole hull has $\rho\ge\operatorname{arccosh}2$ or $\rho\le-\operatorname{arccosh}2$; straddling enclosures are clipped to the closed strip $|\rho|\le\rho_c^+$, which is sound for this per-point existence claim: every not-yet-successful point has its current image in $X_n\cap\{|\rho|<\rho_c\}$ (clipping retires successful image mass, not preimage pieces). Production: 131,072 parent tiles; 130,965 certified directly; 107 parents (angular band $105.3^\circ\le\theta\le107.1^\circ$, rings $k_r\in\{6,7,22,\dots\}$) exhausted the leaf budget at steps 175–184 and were certified by exact local refinement: children $(k_\theta m+a,k_rm+b)$ on the $8192\times64$ grid partition each parent exactly, all 428 children certified by the unchanged core with unchanged parameters. Aggregate: max leaves 4083, latest hit step 188, max width 0.178, min positive margin $6.5\times10^{-9}$; 131,393 leaves succeeded by positive margin, 0 by certified-empty clip. Gate v2 PASS; the frozen gate v1 and gate v2 without the refinement file both fail closed on the first budget-exhausted parent.

`[THM]` [RID: RECOG-THM-TWIN-RADIAL-ACCESS] [scope: diagnostic twin $T_s$ (SG-R4), conditional on its definition; lifted primitive chart] For every $x$ with $0<Q(x)<\tfrac7{200}$ there is $n\ge0$ with $|\rho(T_s^nx)|\ge\operatorname{arccosh}2$. The uniform bound $n\le256$ holds only for the leg from the annulus $\mathcal A=\{\tfrac7{200}\le Q<\tfrac{58107}{1600000}\}$ to the threshold; from arbitrary small $Q_0$ the number of six-step blocks needed to reach $\mathcal A$ is finite for each orbit but unbounded as $Q_0\to0$. No claim about $D_s<0$, first hits, or the rank locus $C_0^{(s)}$ itself. [proof: `[ALG]` E2A phase-uniform raw-frame expansion + E2B exact annulus entry + `[ALG via IA]` E2C certified annular transport]

`[ENG]` [RID: E2C-ENG-SPLIT-REFINEMENT] The inherited R8 Lohner propagation remains sound under subdivision, but its unused split path is refinement-inefficient because subtiles retain the parent centre; recentering through an axis-aligned physical-coordinate normalization further destroys thin frame geometry. E2C uses local frame-native split-and-recentre and optional success-region clipping. R8/B3 scientific certificates are unaffected because their certified runs used zero splits.

`[ENG]` Provenance of the production: calibration (clipped, $4096\times32$) 150/150 sample tiles and 47/47 adversarial parents; witness-containment audit (5587 checks through transport, split, recentre and clip, 0 violations; the boundary-targeted clip audit was waived as non-blocking). Production chunks 0–32767 run in the session, 32768–131071 run by the PI (Windows, flint 0.9.0); the refinement and gate v2 were run in the session over the PI's chunk files. The contributor independently reproduced the gate/proof assembly (v2 PASS, certificate byte-identical, both fail-closed controls) over the supplied Arb outputs; the 131,393 Arb leaf certificates themselves were not independently recomputed (python-flint unavailable in the contributor environment).

### §6.16 CELL-F1 — Event-Rule Identifiability Audit (R6) `[RESULT / DEF / mixed]` {#sec-6-16-event-audit}

> **[Local guards SG-R1, SG-R6, SG-R10, SG-R14 apply.]** This cell asks whether the currently certified RECOG package already determines a physical recognition-event predicate. It does not adopt an event rule.

`[RESULT]` [RID: RECOG-RESULT-EVENT-UNDERDETERMINATION] **Event-rule underdetermination.** Within the currently registered candidate structures — rank transition, lattice threshold, retained non-comparator memory, and the Number Genesis physical 7-gap token — the certified relations do not identify a unique physical-event predicate. At least one implication that would be required to identify these structures is refuted at theorem grade, another is not entailed by the definition of the threshold, and the remaining identifications require bridges not presently supplied. Therefore any physical-event rule selecting or identifying these structures requires an additional selection/bridge principle.

The result is supported by the following graded separation ledger.

| Proposed implication / identification | Current witness | Grade | Status |
|---|---|---|---|
| retained non-comparator memory $\Rightarrow$ rank event | The RECOG-THM-R9-MEMORY comparator-incompleteness witness lies in its certified small-$q$ window ($q_0<|G|/C_2$). By DYAD-THM-NF-INV this window maps inside the primitive contraction neighbourhood $Q_{\rm prim}<\tfrac1{625}$; DYAD-THM-PRIM-CTR then keeps every primitive phase in the six-phase tube $U_T\subset\{Q_{\rm prim}<2209\times10^{-6}\}$, where $\det DT>0.944$ (§6.11). Thus theorem-grade retained comparator-incomplete information exists without rank loss. | `[THM]` + `[ALG consequence]` | **FALSE** |
| lattice threshold $\Rightarrow$ dynamically distinguished class change | A RECOG lattice threshold is defined by a level crossing of the registered lattice-phase observable. Its definition does not involve the map's rank, its normal-form class, or its return combinatorics; sufficiently late thresholds occur inside the rank-safe healing regime. Whether a crossing *coincides* with a change of return word (e.g. a 6→7 primitive return) is not settled here and is the subject of F2(b). | `[DEF consequence]` / `[ALG]` for rank-safe late crossings | **NOT ENTAILED** |
| RECOG lattice-threshold stream $=$ Number Genesis physical 7-gap stream | Both have the theorem-grade asymptotic consecutive ratio $e^{\pi/(3\tau)}=\lambda_{\rm DSI}^{1/6}$, but no termwise event identification or common tokenisation theorem exists. Equality of asymptotic rate is not stream identity. | `[HEUR cross-reference]` / SG-R6 guard | **OPEN — no identification** |
| rank event $\Rightarrow$ retained witness | No registered theorem establishes a retained post-event discriminator for a $C_0$ crossing. Local noninjectivity, if a fold is certified, would concern recoverability of the present-state map and is not automatically identical to physical information erasure. | `[OPEN]` | **OPEN** |

`[ALG]` **Representation-safety ledger.**

* **Rank event.** The critical locus $\operatorname{rank}DF_x<2$, equivalently $\det DF_x=0$ in the present two-dimensional chart, is invariant under local diffeomorphism: under $y=\varphi(x)$,
$$\det D(\varphi F\varphi^{-1})_{\varphi(x)}=\frac{\det D\varphi_{F(x)}}{\det D\varphi_x}\det DF_x,$$
and the prefactor is nonzero. The zero set is therefore representation-safe.
* **Retained exact-map memory.** RECOG-THM-R9-MEMORY is certified in the registered $C_z$ track. Finite-initial-state comparator data are track-typed (SG-R14), but the chart correction to phase vanishes as $z\to0$; consequently the limiting pair phase is track-independent. The retained observable is asymptotically representation-safe even though its finite-time comparator input is not track-free.
* **RECOG lattice thresholds.** The individual lattice phase $\Psi_{\rm lat}=\arg c_{05}-6\Theta$ is invariant under linear frame changes but shifts under the nonlinear equivariant gauge $\widetilde W=e^{ia|W|^2}W$ by $-6aQ$ (§6.13). Individual threshold locations/indices are therefore representation-convention quantities; the asymptotic clock ratio is invariant. A lattice crossing cannot be promoted to a physical token without an additional representation/tokenisation bridge.
* **Number Genesis physical 7-gap.** The token is defined inside the Number Genesis representation as a primitive return-time event. Its relation to RECOG chart changes or to the RECOG lattice threshold has not been established.

`[DEF candidate]` [RID: RECOG-DEF-EVENT-TOKEN-SCHEMA] **Event-tokenisation schema.** A candidate event rule is a typed map from an admissible relational history to a discrete token stream
$$\mathcal E_{\mathcal R}:\mathcal H_{\mathcal R}\longrightarrow\{(n_j,\sigma_j)\}_{j\ge1},$$
where $\mathcal R$ names the registered representation. This is a schema for testing candidate rules, not an adopted physical definition. A candidate tokenisation is assessed against:

1. **Representation safety.** Event occurrence is invariant/covariant under the registered representation changes, or an explicit bridge transports the token.
2. **Nongenericity.** Generic smooth variation of comparator values does not emit tokens.
3. **Finite witnessability.** Event occurrence is decidable from finite registered state/history data.
4. **Dynamical distinction.** The token marks a change in a registered structural status — e.g. rank/recoverability class, return word, stabiliser, admissible continuation, or another explicitly defined dynamical class — rather than an arbitrary numerical threshold alone.
5. **Consequence type.** The post-token consequence is recorded, without prejudging its physical interpretation, as `R` — retained/recoverable discriminator; `E` — certified loss of recoverability/noninjectivity; `N` — neither established.

Criterion 5 is deliberately a classifier rather than an admissibility axiom. Whether a physical **recognition** event requires `R`, permits `E`, or obeys a stronger no-erasure condition remains outside CELL-F1 (SG-R1: the ontology note owns that reading).

`[RESULT]` **F1 conclusion.** The present package supplies comparison, structural transitions, mathematical threshold streams, and theorem-grade retained memory, but no theorem selects one of these as *the* physical recognition-event predicate. R6 therefore remains **ACTIVE**. The missing object is a representation-safe tokenisation/selection principle, to be tested rather than stipulated.

**CELL-F2 targets.**

* **F2(a): representation audit.** Complete the representation-safety table for the rank, lattice and Number Genesis 7-gap streams and identify any required bridge.
* **F2(b): eventwise clock/token test.** On common realised orbits, compare Number Genesis physical 7-gap tokens against lifted RECOG phase-lag level crossings; output an overshoot/residual sequence, not another clock ratio. The Number Genesis definitions of $G$, $M_j$, $s_j$, the section and its phase convention are imported literally from the owner text before the script is written. First grade `[NUM]`; no identification is inferred from equal asymptotic ratios alone.
* **F2(c): rank-transition consequence.** F2(c0) first certifies or refutes the local Whitney-fold condition at the B3 encounter $x_*$ (corank one, kernel field $k$, $d(\det DT)_{x_*}(k)\ne0$). Only if the fold condition is certified, classify the resulting local loss of inverse uniqueness under criterion 5 (`E`) and separately ask whether any registered history variable retains the branch information (`R`). No ontological erasure claim is made in RECOG.

Order: F2(b) before F2(c0).

## §7. Import Ledger {#sec-7-imports}

- [RID: DYAD-THM-C21] :: $\mu_6=c_{21}=-\tfrac12-i\tfrac{2\sqrt3}{3}$ :: RTG_DYADIC_OSCILLATOR_DSN_v6.4.10 §6.2, §6.7 :: return defect, jet-law anchor :: p=6, K=1, conditional on postulated $T$
- [RID: DYAD-ALG-NF6] :: chart $h$ (degree 6, resonant coefficients zero), jet $J$, $\mu=6\bar\lambda n_{21}$, $a_{05}=6\bar\lambda n_{05}$, $(3,2)$ iteration formula :: Dyadic v6.4.10 §6.14 :: §6.14 ledger :: **consumer acceptance recorded v0.3.2** (Dyadic §7 proposed-consumer row); finite-jet identities only
- [RID: DYAD-ALG-NF6-OBS] :: $c_{05}^{\rm raw}-a_{05}=\tfrac{-13+3i\sqrt3}{576}$ :: Dyadic v6.4.10 §6.14 :: closes the v0.3 frame error as a named obstruction :: accepted
- [RID: DYAD-THM-PRIM-CTR] (consumed by RECOG-THM-P2-HET, v0.3.3) :: primitive contraction $(108,\tfrac1{400},\tfrac1{625},\tfrac12)$, tube $U_T$, $\sum Q_m^3\le2Q_0^2$ :: Dyadic v6.4.10 §6.14 :: R8 entry target; contraction half of former R10 :: accepted; radius sufficient not optimal
- [RID: DYAD-THM-NF-INV] :: inverse chart, $\|Dh^{-1}\|<\tfrac87$, $\tfrac{225}{256}|z|^2\le Q_{\rm prim}\le\tfrac{289}{256}|z|^2$, comparator transport $\overline{h(z_a)}h(z_b)$ :: Dyadic v6.4.10 §6.14 :: §6.14 :: accepted; $q\ne Q_{\rm prim}$
- [RID: DYAD-THM-NF-REM] :: $C_7/C_D$ profiles $(100,1000)$ on $\tfrac1{20}$, $(30,250)$ on $\tfrac1{40}$; $\widehat U_T\subset\{|z|<\tfrac1{20}\}$; normalised one-orbit contraction :: Dyadic v6.4.10 §6.14 :: R9 budget, R8 hand-over :: accepted; rows not mixed; certificate values 85.07/27.60
- [RID: (none — RRF Registry v0.4, noncanonical, PI adoption pending)] :: profile names, observable typing (native/transported), $S_h$ object and its degree-6 scope, common-realisation condition, network guard :: `RTG_RRF_REPRESENTATION_REGISTRY_v0_4` :: SG-R13/R14 wording, §6.14 :: **convention only**; no scientific import; the reported even degree-ten term of $\widehat F$ is not used
- [RID: (none — PRR Wrap-up v0.2, noncanonical)] :: representation-discipline principle; readability emergence :: `RTG_PRIMORDIAL_RELATIONAL_REPRESENTATION_WRAPUP_v0_2` :: R6 reading :: interpretive only (SG-R1)
- [RID: DYAD-ALG-P6-FACEFLUX] :: $\lambda=e^{i\pi/3}=e^{iF_f/2}$ :: Dyadic §6.2 :: linear resonance signature; not used for derivation :: p=6 only
- [RID: DYAD-ALG-BRIDGE-LEMMA] :: $\mu_p=p\bar\lambda\nu_3^{(1,p)}$ :: Dyadic §6.9 (location corrected) :: CELL-A target :: normalised one-step frame
- [RID: (none — §6.1 block)] :: dyad map, $J$, $\det J$, $C_0$, $P_1,P_2$, escape law, non-symplecticity :: Dyadic §6.1 :: fixed points, rank stratum, $(t,d)$-plane :: primitive layer
- [RID: (none — §6.4 block)] :: $Q_c=(\arcsin\ln2)^2$, winding-index invisibility, ISP $\Theta$ :: Dyadic §6.4 :: SG-R8, distinction anchoring, $\arg W=\Theta$ :: crossing-step local
- [RID: (none — §6.7/§6.8 block)] :: $M+M^\top=-I$, $Q_{m+1}=Q_m-Q_m^2+\cdots$, $\Theta_{m+1}=\Theta_m-\tau Q_m$ :: Dyadic §6.7–6.8 :: $\chi_6$ reconstruction :: cubic-vector truncation
- [RID: (none — Genesis §6.1)] :: $\mathcal O_0=0$, first dyad $A+B=0$, $B$, $Q=r^\top Br$, $A^\top BA=B$ `[THM]` :: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.1 :: comparator construction, distinction anchoring :: p=6 eigenframe
- [RID: (none — Genesis §6.6)] :: $I_{ab}$, $\omega_{ab}$, $a^\top BJ_Qb=\tfrac{\sqrt3}{2}\omega_{ab}$, plateau phase memory :: Genesis §6.6 :: cross-comparison, memory layer :: phase convention as declared there
- [RID: NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION] (source pin v1.15 retained; RID resolves in v1.20.4) :: $Q_{\rm true}(Fx)-Q_{\rm true}(x)=-Q_{\rm true}^2+O(Q_{\rm true}^{5/2})$; phase-uniform strict contraction on a small punctured sector :: RTG_NUMBER_GENESIS_DSN_v1.15 :: §6.2 local exactness; absence of nearby period-6 points :: local, p=6, conditional on $T$ (RID corrected at critique round 2; `NUMGEN-N1C-DYAD-RADIAL` names the downstream Radial Memory Test, not this theorem)
- [RID: NUMGEN-OPEN-N1C] (source pin v1.15 retained; RID resolves in v1.20.4) :: wrapped-$S^1$ negative control (memoryless wrapped state collapses same-endpoint histories) and local primitive-dyad history non-collapse :: RTG_NUMBER_GENESIS_DSN_v1.15 N-1C (closed) :: §6.5 co-presence refinement :: negative control is scoped to the memoryless wrapped state; not a universal statement (confirmed at critique round 2)
- [RID: (none — Genesis §6.6 $J_Q$)] :: $J_Q=\tfrac1{\sqrt3}\begin{psmallmatrix}1&-2\\2&-1\end{psmallmatrix}$, $J_Q^\top BJ_Q=B$, $J_Q^2=-I$, sign branch fixed by convention :: Genesis §6.6 :: comparator orientation, SG-R9 :: branch-dependent sign; load-bearing properties branch-independent
- [RID: DYAD-ALG-BRIDGE-LEMMA] (general form) :: $\mu_p=p\bar\lambda\nu_3^{(1,p)}$ for all $p\ge5$ :: Dyadic §6.9; general proof supplied in §6.12 (ownership offered to Dyadic) :: §6.10 :: $K_p$ family
- [RID: (none — Dyadic §6.3)] :: $\tau$, $R^*=e^{\pi/\tau}$, $\lambda_{\rm DSI}=e^{\pi\sqrt3}$ :: Dyadic §6.3 :: lattice clock identities $\lambda_{\rm DSI}^{1/6}=(R^*)^{1/3}$ :: canonical constants
- [RID: (none — Dyadic §6.5)] :: $\tfrac{47}{54}=|\mu|^2+2\Re c^{\rm raw}_{32}=[W^3\bar W^3]\Delta Q_6$, rescoped in v6.4.10 as the raw fixed-radius angular mean $\mathcal A_{\rm raw}(Q)$ :: Dyadic v6.4.10 §6.5 :: historical/raw comparison only; **not an R9 chart input** — superseded for R9 by RECOG-ALG-CHART-LAWS (§6.14); retained to document the SG-19 non-transfer :: averaging operator, not a pointwise recurrence
- [RID: DYAD-ALG-LIEGAUGE-NORM; §6.9 table] `[v6.4.10 update]` :: Dyadic now labels the row $c^{({\rm raw},6)}_{32},c^{({\rm raw},6)}_{05}$ as six-step raw coefficients and declares $c_\theta^{(6)},a_1,a_2$ archival Lie-gauge quantities not transferred to the chart (SG-19) — the v0.3.1 RECOG correction is thereby confirmed by the owner :: source-declared (historical): the §6.9 row carries a Lie-strict-kernel label and lists $c_{32}^{({\rm raw},6)}$, $c_{05}^{({\rm raw},6)}$, $c_\theta^{(6)}$; $\Im\nu_5$ non-invariance `[FAIL]` :: Dyadic §6.9 :: §6.13 :: **RECOG correction (R11):** the listed $c_{32},c_{05}$ values are raw six-step coefficients (nonzero quartic jet), not normal-form coefficients; $c_\theta^{(6)}$'s final-frame ownership is part of R11; Dyadic SG-5 forbids identifying raw and normalised $p$-step coefficients without a bridge
- [RID: DYAD-ALG-ALIAS-PHASE] :: $G_-(\pi/\tau)=1/(1-i\tau)$ :: Dyadic OPEN 16 :: §6.13 `[HEUR]` cross-reference only :: not an import of $G_-^{(6)}$
- [RID: NUMGEN-THM-N5AS1-DEFECT-THRESHOLD-RATIO] :: $D_M=\tau\log M+C_D+o(1)$; defect-threshold first crossings satisfy $M^{(\rm def)}_{k+1}/M^{(\rm def)}_k\to e^{\pi/(3\tau)}=e^{\sqrt3\pi/6}$ :: RTG_NUMBER_GENESIS_DSN_v1.20.4 N-5A-S1-INF :: lattice clock rate (§6.13) :: theorem-grade on the local healing tube; GAP-LOCK Lemmas 1–3 are CLOSED there, and Lemma 3 separately proves the same consecutive-ratio limit for physical 7-gap event times without identifying the two event sequences term-by-term; RECOG adds the $c_{05}$ readability interpretation
- [RID: (none — Dyadic §6.2 $h_2$)] :: $h_2(z,\bar z)=-\tfrac{1+i\sqrt3}{12}z^2-\tfrac13z\bar z+\tfrac{1-i\sqrt3}{24}\bar z^2$ :: Dyadic §6.2 :: §6.13 frame correction :: exact
- [RID: (none — Dyadic §6.11)] :: one-step normalised $\nu_5^{(1,6)}=\tfrac{43}{17280}-i\tfrac{227\sqrt3}{155520}$ :: Dyadic §6.11 :: confirms $c_{05}^{\rm NF}$ via the bridge :: normalised one-step frame
- [RID: STAR-NOERASE-1] :: clean-star blow-up injectivity witness ($N\le20$) :: relational-existence ontology thread (not a DSN document; not in the corpus) :: SG-R5 wording :: witness only
- [RID: (ontology note)] :: interpretive `[HYP]` lines of §6.9 :: relational-existence thread (not in the corpus) :: §6.9 export interface :: SG-R1
- [RID: (archived Dyadic artifact)] :: `normalize_p7_full_onestep_cyclotomic.py` — exact $\nu_3^{(1,7)}$ (`nu3_full^(7)` renamed on import) :: Dyadic OPEN 9 tooling :: §6.10 :: one-step full sequential normalisation, not $p$-step
- [RID: OFN §6.2a, §7.3] :: open rows "why $\sin\eta$", "why exponential shear"; TDR-G band $k$ underived :: RTG_ONTOLOGICAL_FOUNDATIONS_v0.7 :: export targets for §6.4, OPEN R5 :: motivational layer, no derivation imported

RIDs marked "(none)" have no stable identifier in the source; requesting assignment there is part of the critique round.

---

## §8. Artifact and Script Registry {#sec-8-artifacts}

- [RID: RECOG-ART-SHEAR-JET-CERT] :: `recog_shear_jet_cert.py` (sha256 `e1d2444f9d8d8c940270d73df4ca20d0323504d93f89dbb2fe6da1a9a3fe48a4`) :: exact sympy six-step cubic composition with exact $\omega=\tfrac12(-1+i\sqrt3)$; 18 checks: DYAD-THM-C21 reproduction (parametrised and direct), $T_s$ (parametrised and direct), $T_{\log}$, $T_{\tanh}$, general $\mu_6(a,b)$, quadratic vanishing, $(2,1)$ confinement, completed-square rigidity and its minimum, comparator orientation, Genesis $J_Q$ properties, invariant-form uniqueness, radial-fate boundary corollary, rigidity minimiser; exit 0 on PASS :: `[ENG]` (scientific claims carry their own `[ALG]` tags in §6)
- [RID: RECOG-ART-CELL-A-P5] :: `recog_cell_a_p5_rawcomp_cert.py` (contributor; sha256 `0a87d59d600a11414fb1b26dd90ef770d3e2ae282a2e5da7b61c8ab648f84383`) :: exact $\mathbb Q(\zeta_5)$ raw five-fold composition; $\mu_5$, bridge-implied $\nu_3^{(1,5)}$; 10 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-A-P7-RAW] :: `recog_cell_a_p7_rawcomp_cert.py` (sha256 `0414f3a031a4bf9bfe2d1a7d508128114f78d2ca5a28f7b3e99823a62f1979ab`) :: raw seven-fold composition, 50 dps; independent $\mu_7$; 5 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-A2] :: `recog_cell_a2_nu3_closed_form_cert.py` (sha256 `222c964532a48e04dd37baeb86017620060b8dece250a135552b83d3e3cab2cd`) :: symbolic $h_2$ normalisation → $\nu_3(\lambda)$; exact checks mod $\Phi_5,\Phi_7$; zero-set; series; sign mesh; 11 checks :: `[ENG]`
- [RID: RECOG-ART-CELL-B] :: `recog_cell_b_p2_manifolds.py` (contributor; sha256 `7ea5e161b9ffa244b279681a067047e66a0a477a29477d0946637694f10b216e`) :: $W^u_+(P_2)\cap C_0$ by parameterisation-limit continuation (mpmath, 90 dps); transversality; scans; 6 diagnostics :: `[ENG]` (diagnostic, not IA)
- [RID: RECOG-ART-CELL-C] :: `recog_cell_c_lattice_readability_cert.py` (contributor; sha256 `73a919e24fe5349e7a0944e4c1dc4aeb9fc7d1bd43f8d89f3e25e29ee1476083`) :: $\beta$ identity, $c_\theta$ consistency, moduli, readability fractions, sixfold axes; 6 checks — **raw-frame inputs**; identities of its inputs only, numbers historical/raw; superseded by the completed §6.14 ledger :: `[ENG]`
- [RID: RECOG-ART-CELL-D] :: `recog_cell_d_lattice_memory_cert.py` rev. 4 (sha256 `242b13e33357b7e41c5575a4a39d6eff24b26773fa38360a4effcf85592a8b7f`; rev. 3 `b92b9936…59cd` superseded) :: derives raw and post-$H_2$ six-step jets from the primitive map with the Dyadic $h_2$ (quartic vanishing, $c_{05}^{\rm NF}=6\bar\lambda\nu_5^{(1,6)}$), $|1-6i\tau|=7$, exact transfer coefficient, orbit-difference vs closed form with $O(Q_0)$ error scaling, no $\log Q$ memory, pair tests including identical-comparator counterexamples in both the post-$H_2$ and the canonical raw comparator (transported through $H_2^{-1}$); 26 checks :: `[ENG]` (rev. 2, sha256 `5c678051…d3ad`, superseded: raw coefficients)
- [RID: RECOG-ART-R8-TRANSPORT] :: `recog_cell_r8_hetero_enclosure.py` (sha256 `1f8876a8a3fc31428d5ffb4873e62eb0780c08763b80281e1edeb8c1ab1223fd`) :: Stage 1 quadratic-cusp lemma (exact) + Arb/Lohner transport of the shell to $U$; writes one metadata record per run (script hash, flint 0.9.0, 120 bits, $\delta=1/100000$, $\kappa=2$, 4096 pieces, Dyadic v6.4.10 sha256 `7455811928606076b3bc3075632275dc2a24e37fdbf0ae20036db5529a1b56b7`); its built-in `summary` mode is deprecated (stale report line) — the external gate is authoritative :: `[ENG]`
- [RID: RECOG-ART-R8-RESULTS] :: `r8_cert.jsonl` (sha256 `3e98c447af2a28c796eb96fe1c60f1f4106930d3415f1d9b37cdfef70feb0997`) :: 4096 piece records + 2 metadata records (runs [0,2600), [2600,4096)), homogeneous hash and parameters; total compute 426.5 s :: `[ENG]`

- [RID: RECOG-ART-E1] :: `recog_cell_e1_twin_survey.py` (sha256 `b7d481e906743a05022f7e8366ee02b717ac7a5f9c9b0d619bb4f3c776da9702`), `e1_survey.json` (`6cf4a0a37ec7373d2b7bb4eaa304d31bcd2985cf01ec9443af79fa2d44fac253`) :: binary64 twin survey, exact-negation symmetry check :: `[NUM]`
- [RID: RECOG-ART-E2A] :: `recog_cell_e2a_twin_expansion.py` (sha256 `7f58c163598ebae58f13beef180879e9e5638ac41394d056d85ac29bd8d72967`) :: Arb jet of $T_s^6$, majorant tail, expansion rows, exact corollaries $c_->19/20$, $c_+<43/40$, E2B annulus :: `[ENG]`
- [RID: RECOG-ART-E2C-CORE] :: `recog_cell_e2c_twin_radial_access.py` (sha256 `e0522aec291a6d3573ccb15e28045ad42b32e4e7225b5a616eeae34a0e1a1b22`) :: calibrated core (tile construction, $T_s$ engine, split-and-recentre, clip, stopping); calibration record `e2c_calibration_clip.jsonl` (`26da4ccaabf7834a5a444db4e429977f2b60231d4b98d90599e81c78e04a51a6`); witness audit `e2c_witness_audit.py` (`09632da1d709c115912aba85ace7b9f099ec5e677bd9bc699a5726a08537e97a`) :: `[ENG]`
- [RID: RECOG-ART-E2C-PRODUCTION] :: `e2c_production_driver.py` (`0c42131cf3ab209f7ea1f2b7fafddf96267cb5e0317fa334fde42d018074cb4b`, hash-gates the core); frozen gate v1 `e2c_production_gate.py` (`d8364d439f876ac2df9fcad82a3ade609f9dbf55fefbd6eb34f315f72fc2fc40`); 29 chunk files over $[0,131072)$ (two of them in `failures/`, retained as the source of refinement parents); hashes in the release manifest :: `[ENG]`
- [RID: RECOG-ART-E2C-REFINEMENT] :: `e2c_refine_driver.py` (`4762077256f0cfb113c22e4f9898b9c77e0afb374f308eb2127c68677a095ca2`), `e2c_refine_m2.jsonl` (`5f354fc163e49e53818e963ccdcaeb198441da063594fdb423a23cf9d83bbd99`; binds both failure-file hashes, core, R8, 120 bits, $8192\times64$ child grid) :: `[ENG]`
- [RID: RECOG-ART-E2C-GATE-V2] :: `e2c_production_gate_v2.py` (`daa3abb3012723370987767d98161a045ab234341b4bf4c2b90ba1fa64caa842`) and `e2c_production_certificate_v2.json` (`1d58749b12f187d879ef142a79d60c9a507c76cb325cf9888d4717a06b697c15`) — authoritative for RECOG-THM-TWIN-RADIAL-ACCESS :: `[ENG]`
- [RID: RECOG-ART-B3-FIRST] :: `recog_cell_b3_p2_c0_first.py` (sha256 `738e80a95e7da3acf233ca24cc5f5f422938d4bbfe13a48d3b5364bbef3f77b9`) :: exact-rational $\lambda_-$; Stage 1b cone lemma; 4096-piece Arb Lohner+tangent transport ($K=14$); contiguous crossing block, transversality, certified-bracket shell placement; theorem-owned rational box $B_*$ and excursion bound checked on live Arb enclosures; asserts the R8 engine hash `1f8876a8a3fc31428d5ffb4873e62eb0780c08763b80281e1edeb8c1ab1223fd` before import (must be archived with RECOG-ART-R8-TRANSPORT) :: `[ENG]`
- [RID: RECOG-ART-B3-RESULT] :: `b3_cert.json` (sha256 `f50e1a23b41d4cbcf9079b9a02f6639477d7b3a1e468bba8e61519a6e5e27bfd`) :: run record bound to the script and R8 hashes; flint 0.9.0, 120 bits, 4096 pieces, crossing piece 2770, `theorem_box` (exact fractions), `num_display` (float displays of Arb endpoints, not theorem-owned), `all_checks_pass: true`. Contributor audited the source/result binding; the Arb run was not independently re-executed (python-flint unavailable in the reviewer environment) :: `[ENG]`
- [RID: RECOG-ART-R9-MEMORY] :: `recog_cell_r9_memory_cert.py` (sha256 `c033fa85ae48054cbcc6ae411e59b4dc9c6536672a69676b05f72e655c3c1717`) :: Arb-enclosed ($200$-bit) constants: $c_{\rm iso}=-4\sqrt3/27$, $G$, $|1-6i\tau|=7$, cohomological identity, log-branch condition, $K_\Phi$ and $C_2$ for both NF-REM rows and the incompleteness windows; plus a `[NUM]` $J$-model sanity check (averaging-function tail estimator) not part of the proof; 7 certified checks :: `[ENG]`. **Consumer-side cross-check (non-certificate):** the contributor independently reconstructed $c_{\rm iso}$, $|G|$, both $C_2$ bounds and the resulting incompleteness windows at high precision from the published formulas; all values agree with RECOG-ART-R9-MEMORY. This check does not replace or independently rerun the Arb enclosure.
- [RID: RECOG-ART-R8-GATE] :: `recog_cell_r8_gate.py` (sha256 `a492d1636e93ad392d22364a34f40ea4b86aed8b8c9b773ad238b3d9474f087c`) :: exit-coded audit: Stage 1 re-verified from recorded parameters; ids exactly 0..4095; exact contiguous rational tiling of $[-\delta,-\delta/\lambda_+]$; every leaf $0<Q_{\rm entry}\le\tfrac1{625}$; $\inf\det DT>0$ pre-entry; Arb backend; script hash and single parameter set — 7/7 PASS, independently re-run by the contributor :: `[ENG]`
- [RID: RECOG-ART-R11-LEDGER] :: `recog_r11_chart_ledger_cert.py` (sha256 `a4950ed525f2e6ee4be0ddd7f9607b2c3c14d8e31052a88db6ae163fa5d6e5e5`) :: chart $q$-law and $\Theta$-law from $J$ (exact), $\tfrac{245}{216}$, $\tfrac{89\sqrt3}{324}$, sign reversal vs archival $c_\theta$, comparator tracks through $O(3)$, $Q_{\rm prim}$ real-ray expansion, R9 budget thresholds, $S_h$ covariance defect $\tfrac32t^3$ with independently reconstructed $h$; 11 checks :: `[ENG]`
- [RID: (session record)] :: Dyadic referee harness `dyad_referee_p2b_v2.py` §3 (majorant/profiles, 20/20 PASS run here; §1–2 require the `qchi` backend, not supplied) and an independent degree-9 reconstruction of $F_W$, $h$, $J$, $D_{\rm poly}$ (session code) :: consumer-side verification of the v6.4.10 package :: not a RECOG artifact; recorded for provenance
- [RID: RECOG-ART-MEMO] :: `RECOG_MEMO_TO_STREAMS_2026-09-17.md` (amended 18 Sep: §3 single enclosure deliverable) :: cross-stream handovers and requests :: `[DEF]`

---

## §9. Collaboration and Provenance {#sec-9-provenance}

**Contributors.** Mustafa (PI; ontological thesis, ratio/comparison emphasis, physics–mathematics coincidence stance) · Claude (this draft; independent certificate) · Collaborating AI contributor (spectral/return-defect formulation, swap-projection twin, shear-jet law first derivation; critique round pending).
**Archive.** none yet; to be registered with the ontology note.

| Insight | Provenance | Tag |
|---|---|---|
| Recognition framework shifted from eigenvalue to comparator + return-defect structure | contributor | `[DEF]` |
| $C(a,b)=\overline W_aW_b$ from Genesis definitions | Claude | `[ALG consequence]` |
| Rank (and, after audit, $\operatorname{sgn}\det$) pointwise chart-free; prerequisite ladder | Claude; external auditor (det sign) | `[ALG]` |
| Antipode as unique nontrivial swap-fixed value | Claude (swap), contributor (formalisation) | `[ALG consequence]` |
| $\rho$ swap-odd from certified $A$ | Claude ($\sin^2\eta$ route), contributor ($f'(0)$ route) | `[ALG conditional]` |
| $T=T_s+T_b$, $\mu_6^{(s)}$, $\mu_{\rm break}$ | contributor (derivation), Claude (verification) | `[ALG]` |
| Shear-jet law $\mu_6(a,b)$ | contributor (derivation), Claude (verification) | `[ALG]` |
| $\tanh$ counterexample | Claude | `[ALG]` |
| Comparator sign correction; cubic-return rigidity $|\mu_6|\ge\tfrac12$; return-germ redefinition; Number Genesis provenance; strata/ladder refinement | contributor (critique round 1) | `[ALG]` / `[DEF]` |
| Invariant-form uniqueness $H=cB$ | contributor (suggested), Claude (certificate) | `[ALG]` |
| Radial-fate boundary corollary; rigidity minimiser $\tfrac12e^{-i\pi/3}$; Number Genesis RID correction; wording/domain fixes | contributor (critique round 2) | `[ALG consequence]` |
| Event = class change; intersection principle | contributor / Mustafa (stance) | `[HYP]` (OPEN R6) |
| CELL-B: $W^u_+(P_2)\cap C_0$ continuation; negative-branch long iterates; $\det J$ lemma phrasing; B2 split | contributor (numerics), Claude (lifted itinerary correction, fundamental-domain reduction, upstream dependency) | `[NUM strong]` / `[ALG]` |
| CELL-A: $p=7$ archived normaliser run; $p=5$ exact certificate; finite ledger table | contributor | `[ALG]` |
| Raw-composition independence of the bridge; general resonant-return theorem; closed form $\nu_3(\lambda)$; empty zero set; small-$\theta$ law | Claude | `[ALG]` |
| Leading-return equivariance theorem; comparator closure; uncoupled-pair reduction; first non-comparator channel $\bar W^{p-1}$ | Claude (theorem), contributor (leading-vs-all scope, normal-form-frame scope) | `[ALG]` |
| CELL-C: $\beta$ identity, readability fractions, no $Q_{\rm lat}$, axis analysis, event-guard | contributor | `[ALG]` |
| Lattice clock ($\lambda_{\rm DSI}^{1/6}$, $R^*$ link); $\mathcal I_{\rm lat}$ | Claude; contributor (NUMGEN provenance, $\Psi_{\rm lat}$ invariance, fading law, hierarchy) | `[ALG consequence]` |
| CELL-D: retained lattice memory $\Lambda$; radial-memory vanishing; memory-version R6 hypothesis | Claude (formula, certificate), contributor ($Y=1/Q$ derivation, exact $317520$ form, identical-comparator counterexample, invariant form, D2a/D2b split, fourth remainder source, corrected backbone $H(x)$) | `[ALG consequence, leading order]` |
| Single upstream enclosure deliverable serving R8 and R10 | contributor (observation), Claude (specification) | `[DEF]` |
| External audit (two rounds): raw vs post-$H_2$ quintic frame; winding fixed points; chart/seam; $\chi_6(0)$ extension; raw remainder order; det-sign chart-freeness; $p=5$ quartic channel; cubic-order neutrality; plateau-memory scope; covariance premise; $\Psi_{\rm lat}$ nonlinear-gauge; fundamental-domain coverage; $Q(P_u(-1))$; $\Re(\bar\lambda\nu_3)=-\sin^2(\theta/2)$ | external auditor (findings), Claude ($H_2$ conjugation confirmation, rev. 3 certificate, integration) | `[COR]` / `[ALG]` |
| NUMGEN defect-rate repin to `NUMGEN-THM-N5AS1-DEFECT-THRESHOLD-RATIO`; GAP-LOCK Lemma 3 same-rate physical-event cross-reference | contributor (owner-file audit); Number Genesis v1.20.4 owner record | `[import]` / `[HEUR]` |
| Local return enclosure (P2-A v2 / P2-B v2): chart, contraction, inverse, remainders | ChatGPT (producer/validator, Dyadic side); Claude (three reviewer records, referee harness); adopted Dyadic v6.4.10 | `[import]` |
| R8 / RECOG-THM-P2-HET: quadratic-cusp Stage 1, Arb/Lohner engine ($E$-oriented, $Q$-orthonormal frames), certificate and gate | Claude (implementation, run); contributor (fundamental-shell formulation, quadratic cusp, Arb trust anchor, six-item gate, symbol hygiene, tube determinant bound, independent re-run of the gate) | `[THM]` / `[ENG]` |
| R6 / CELL-F1: underdetermination result, graded separation ledger, representation-safety ledger, tokenisation schema, F2 targets | contributor (framing, event-token schema, R/E/N classifier, window and gauge corrections, F2 ordering); Claude (graded-separation structure, representation-safety observations, 7-gap/phase-lag conjecture, fold/erasure caution) | `[RESULT]` / `[DEF]` |
| R7 / RECOG-THM-TWIN-RADIAL-ACCESS: E1 survey, E2A expansion, E2B annulus, E2C core, engine repairs, clipping, production driver, refinement, gates | Claude (design, implementation, calibration, refinement, gate v2); contributor (raw-frame oddness route, exact annulus, locked E2C choices, clipping soundness acceptance, gate specification, reproduction of the gate assembly); PI (production run 32768–131071 on local hardware) | `[THM]` / `[ENG]` |
| CELL-B3 / RECOG-THM-P2-C0-FIRST: shell placement relative to $s^*$, cone lemma, tangent transport, root isolation, certificate | Claude (design, implementation, runs); contributor (exact-$\lambda_-$ rigor fix, run binding, first-encounter scope, excursion correction, Arb-direct theorem box, self-policing dependency) | `[THM]` / `[ENG]` |
| R9 / RECOG-THM-R9-MEMORY: intrinsic observable $\Psi$, averaging-function proof, certificate | Claude (construction, certificate); contributor (independent constant reconstruction, RID hierarchy, window/domain separation, raw-track wording) | `[THM]` |
| R11 chart ledger: chart laws, two comparator tracks, refusal line, R9 budget; typed-package reading of R11 | Claude (computation, certificate); contributor (RRF/PRR synthesis, two-track framing, SG-19 grammar); RRF Registry (convention) | `[ALG]` / `[DEF]` |

---

## Appendix A — Version History

### v0.3.7 — 30 September 2026 (R6 identifiability audit)
- **§6.16 [new]:** CELL-F1 — RECOG-RESULT-EVENT-UNDERDETERMINATION with graded separation and representation-safety ledgers; RECOG-DEF-EVENT-TOKEN-SCHEMA (candidate); F2(a)–(c) targets with F2(b) first.
- **§2 R6:** F1 recorded as closed sub-item; residual question restated as the tokenisation/selection problem; F2 items added. Status stays ACTIVE.
- **§5, §9:** high-risk row and provenance row.
- **Editorial (in F1 table, row 2):** the return-word clause is phrased as not settled by the definition and deferred to F2(b), so the audit does not prejudge the F2(b) test.
- **Unchanged:** every result and OPEN of v0.3.6 other than R6's sub-items.

### v0.3.6 — 30 September 2026 (twin radial-access theorem)
- **§6.15 [new, THM/ALG/NUM]:** CELL-E1 survey; RECOG-ALG-TWIN-EXPANSION; RECOG-ALG-TWIN-ANNULUS; RECOG-ALG-TWIN-ANNULUS-TRANSPORT; RECOG-THM-TWIN-RADIAL-ACCESS; E2C-ENG-SPLIT-REFINEMENT; production and reproduction provenance.
- **§2 R7:** ACTIVE → PARTIAL (first item closed; $Q_c$-type threshold, Stage 2 and $C_0^{(s)}$ accessibility open).
- **§5, §8, §9:** theorem-scope row, artifact entries, provenance row.
- **§7 (editorial):** v1.15 source pins for the two older Number Genesis imports marked as retained with their RIDs resolving in v1.20.4.
- **Freeze pass (contributor audit of `b95ec47f`):** status-summary E1 clause restricted to interior seeds ($r_0=0.05$ starts on the boundary); §6.7 inherited sentence updated (radial accessibility proved; $D_s<0$ and $C_0^{(s)}$ accessibility OPEN; erasure not certified). E2A artifact `7f58c163…d72967` confirmed present in the release archive.
- **Unchanged:** every other result and OPEN of v0.3.5.

### v0.3.5 — 28 September 2026 (positive-branch theorem)
- **§1, §2 R3, §6.11 [NUM strong → THM]:** RECOG-THM-P2-C0-FIRST — unique first transverse $C_0$ encounter of $W^u_+(P_2)$ in the exact-rational box $B_*$; first-hit pole order and excursion bound as corollaries; the mixed-grade two-futures statement retired (both unstable futures `[THM]`); R3 PARTIAL only for $W^s(P_2)$.
- **§5:** two-futures row (forbids later re-intersection, monotonicity and $W^s$ claims).
- **§6.9:** export interface lists both unstable futures as `[THM]`.
- **Freeze pass (contributor audit of `22a4afe9`):** R3 closed sub-items updated and the obsolete positive-branch IA line removed (only $W^s(P_2)$ active); §4 routing cell updated; §6.11 heading `[THM / ALG / NUM historical]`; freeze-status line records v0.3.5 as freeze candidate superseding frozen v0.3.4.
- **Pre-freeze Number Genesis sync (29 Sep):** companion pointer repinned to Number Genesis v1.20.4; RECOG-ALG-LATTICE-CLOCK now imports `NUMGEN-THM-N5AS1-DEFECT-THRESHOLD-RATIO`; the stale `NUMGEN-OPEN-N5AS1-GAPLOCK` reference is removed; R6 records GAP-LOCK Lemma 3's physical 7-gap consecutive-ratio limit as a guarded `[HEUR]` cross-reference, with equal rate explicitly not treated as event identity.
- **§8, §9:** B3 script and result record registered with the R8 dependency; provenance row.
- **Appendix B:** RECOG-NUM-P2-C0-FIRST superseded as evidentiary basis; historical numbers retained.
- **Unchanged:** every other result and OPEN of v0.3.4. Next: R7.

### v0.3.4 — 27 September 2026 (R9 theorem)
- **§6.13a [new, THM]:** observable $\Psi$, $M$; averaging function $\Phi$; RECOG-THM-R9-MEMORY with both NF-REM rows; exact-map $C_z$ incompleteness corollary with its smaller windows; RID hierarchy (RECOG-ALG-LATTICE-MEMORY retained as the leading coefficient).
- **§2:** R9 CLOSED; R6 non-comparator-memory premise has a theorem-grade witness on the certified window, event reading `[HYP]`.
- **SG-R14:** raw-track scope ("need not", "generically $O(\sqrt{q_0})$"); final pair phase track-independent.
- **§6.13:** CELL-D counterexamples marked historical truncated-model diagnostics.
- **§5, §8, §9:** rows/entries; certificate registered.
- **Freeze pass 2 (contributor audit of `b0ffe44b`):** companion methodology v1.3; stale "OPEN R11"/"pending R11" phrases in §6.13 and §8 (CELL-C) replaced by "historical/raw; superseded by the completed §6.14 ledger"; rev. 3/rev. 4 closing sentence retyped; R10 residual restated as non-blocking $C_7$ optimisation; §4 lattice/memory routing row and §6.9 export interface include RECOG-THM-R9-MEMORY with its $C_z$ track and window; status summary carries an explicit OPEN census (R1, R3, R4, R5, R6, R7 open; priority frontier R3, R6, R7).
- **Freeze pass (contributor audit):** §5 lattice-memory row replaced by the R9 theorem row; §1 canonical lattice sentence typed to the $C_z$ track and window; the two "both tracks" sentences restricted to historical truncated diagnostics; §8 consumer-side cross-check line; header records `RECOG` registration as confirmed in Methodology v1.3 and Programme Overview v1.2.

### v0.3.3 — 26 September 2026 (theorem promotion)
- **§6.11, §1, §2 [NUM strong → THM]:** RECOG-THM-P2-HET $W^u_-(P_2)\setminus\{P_2\}\subset\mathcal B(P_1)$ and corollary $W^u_-(P_2)\cap C_0=\varnothing$; OPEN R8 CLOSED. The positive branch is retained as `[NUM strong]`; the two-future picture is recorded as mixed grade.
- **R8 requirements:** $Q(P_u(-1))=5.215$ removed (proof uses the local shell); kept as historical evidence.
- **Stage 1:** the quadratic-cusp shell is the operative proof; the linear-cone Stage 1 from the parallel working session is superseded (Appendix B).
- **§5, §6.9, §7, §8, §9:** rows/entries for the theorem and its three artifacts.
- **Freeze pass (contributor audit):** §1 fundamental-domain clause corrected (covers $t\le-1$ only; historical); Stage-1 shell argument restated in the correct direction ($x=T^ky$, $y\in\Sigma$); R3 status updated; routing-table cell and closed-R8 closing sentence updated; entry-criterion wording made exact; methodology header synchronised to v1.3.
- **Unchanged:** every other result and OPEN of v0.3.2. Next: R9.

### v0.3.2 — 25 September 2026 (scope patch: Dyadic v6.4.10 consumer acceptance; R11 ledger)
- **§7 [import]:** five Dyadic v6.4.10 RIDs accepted (NF6, NF6-OBS, PRIM-CTR, NF-INV, NF-REM); RRF Registry v0.4 and PRR Wrap-up v0.2 cited for convention/interpretation only; §6.9 owner relabelling recorded.
- **§6.14 [new, ALG/import]:** $h$-chart ledger — chart-native $q$-law and $\Theta$-law from $J$ ($\tfrac{245}{216}$, $+\tfrac{89\sqrt3}{324}$), refusal line, two comparator tracks, $S_h$ with degree-6 scope and the $\tfrac32t^3$ covariance defect, R9 budget and $q_0$ thresholds, network guard. Certificate `recog_r11_chart_ledger_cert.py` (11 checks).
- **§2:** R10 delivered and accepted; R11 closed as the representation ledger (memory-observable propagation routed to R9, physical relabeling to RRF OPEN-A); R8 retargeted to the primitive tube with certified hand-over; R9 rebuilt from $J$ + NF-REM with the $2C_7q_0^2$ budget; R6 `[HYP]` reworded with readability emergence.
- **§3:** SG-R13 (normalization-object grammar, adopts Dyadic SG-19) and SG-R14 (comparator typing) added.
- **§6.4, §6.13:** comparator typing of the swap premise and of the rev. 3/rev. 4 counterexamples; v0.3 backbone paragraph retired.
- **§5, §8, §9, Appendix B:** rows/entries for the above.
- **Freeze pass (25 Sep, contributor audit of v0.3.2):** R8 status/dependencies updated (no upstream blocker); §6.11 "blocked by R10" removed; §6.14 exact-map phase remainder corrected to $O(q^3)$; §7 $\tfrac{47}{54}$ row rescoped as historical/raw, not an R9 input; R11 status set to CLOSED with explicit scope.
- **Unchanged:** every RECOG scientific result of v0.3.1; the RECOG prefix and Programme Overview Tier 3 registrations remain to be added by their owners.

### v0.3.1 — 18 September 2026 (external audit rounds 1–2)
- **§6.13 [COR → ALG]:** quintic coefficients re-derived from the primitive map in both frames; CELL-C/D numbers restated post-$H_2$ ($\mathcal I_{\rm lat}\approx0.013443$, transfer coefficient $-\tfrac{43+5611\sqrt3 i}{1270080}$, $|\Lambda|\le0.007652\,Q_0$); raw-frame numbers superseded; CELL-D rev. 3 (25 checks).
- **§2:** OPEN R11 (quintic-frame reconciliation) opened; R9 inputs flagged raw-frame; R10 made dependent on R11.
- **§6.2, §6.3, §6.4, §6.7, §6.8, §6.10, §6.11, §6.12 [COR]:** raw remainder $O(|W|^4)$/$O(Q^{3/2})$; $\chi_6(0):=1$ extension; wrapped winding fixed points; $\operatorname{Fix}\subsetneq$ pole stratum; closed-linear-transport wording; covariance premise scope; cubic-order neutrality; plateau memory `[ALG structure]` with orientation relation; exact $\Re(\bar\lambda\nu_3)=-\sin^2(\theta/2)$; $p=5$ quartic channel note; fundamental-domain coverage and initial-$Q$ indexing; general $P_{ab}$ form.
- **§3:** SG-R3 (det sign chart-free), SG-R10 (three scopes; frame naming mandatory), SG-R12 (lifted chart / seam) revised or added.
- **§7:** NUMGEN defect-rate line made definitive (no RID; nested under N5AS1-INF; dedicated RID requested); bridge lemma location §6.9; $h_2$, $\nu_5^{(1,6)}$, STAR-NOERASE-1 and ontology-note provenance entries added.
- **§8:** CELL-C check count 6; CELL-D rev. 4 hash (26 checks; canonical-comparator pair test added).
- **Freeze tag (19 Sep, after contributor re-read):** §5 fixed-point row corrected to $\operatorname{Fix}_0(T)\subsetneq\{\widehat C_{\rm pole}=\pm1\}$; SG-R10 amplitude wording made current; §6.13 provenance updated to rev. 4.
- **Text cleanup (freeze pass, 19 Sep):** raw-comparator remainders $O(Q^{3/2})$ in §1/§6.2; "only rank" wording removed from §1, §6.5 guard and §9; §6.13 count; R10 rephrased as a template in the R11-resolved chart; §7 Dyadic §6.9 entry split into source-declared vs RECOG correction; R11 extended with the $H_2$ comparator-transport formula and the coordinate-ledger deliverable.

### v0.3 — 18 September 2026
- **§6.10 [new, ALG]:** general resonant-return theorem for $p\ge5$; closed form $\nu_3(\lambda)$ (RECOG-ALG-NU3-CLOSED-FORM); empty unit-circle zero set (RECOG-ALG-NU3-NONVANISHING); $k_{\rm ret}(p)=3$ for all $p\ge5$; finite $p=5,7$ ledger; small-$\theta$ law $\Re\mu_p\to-\pi^2/p$. OPEN R2 closed.
- **§6.11 [new, NUM strong]:** $P_2$ manifolds — RECOG-NUM-P2-C0-FIRST with lifted itinerary $-1\to-i\to+1\to+i\to C_0$ ($278.66^\circ$), derived wrapped $81.34^\circ$; RECOG-NUM-P2-HET-NEG with fundamental-domain reduction; $\rho<0\Rightarrow\det J>0$. OPEN R3 partial; OPEN R8 opened.
- **§6.12 [new, ALG]:** RECOG-ALG-LEADING-RETURN-EQUIVARIANCE; RECOG-ALG-COMPARATOR-CLOSURE (normal-form scope); uncoupled-pair reduction; R6 unification sub-item closed.
- **§6.13 [new]:** lattice readability (CELL-C), RECOG-ALG-LATTICE-STRENGTH, RECOG-ALG-LATTICE-CLOCK ($\lambda_{\rm DSI}^{1/6}$), RECOG-ALG-LATTICE-MEMORY ($\Lambda$, exact $317520$ form, invariant form, identical-comparator counterexample); corrected backbone for R9; OPEN 16 structural cross-reference.
- **§2:** R2 CLOSED; R3 PARTIAL; R6 rewritten around the six-layer hierarchy with the memory-version `[HYP]`; R8, R9, R10 opened (R10 = single upstream enclosure deliverable).
- **§3:** SG-R10 (lattice scopes), SG-R11 (two rigidity families) added.
- **§5, §7, §8, §9:** rows/entries for all of the above; seven artifacts registered with hashes; memo registered.
- **Appendix B:** three v0.2.1-era statements superseded (see below).

### v0.2.1 — September 2026 (pre-freeze patch, critique round 2)
- **§7 [import]:** Number Genesis contraction import corrected to `NUMGEN-RESULT-L1-PRIMITIVE-CONTRACTION`; `NUMGEN-OPEN-N1C` confirmed; verification notes removed.
- **§0 [governance]:** `RECOG` prefix and Programme Overview Tier 3 (Maturity A) registration made part of this release.
- **§0, §1, §6.7 [wording]:** "recognition order is rigid" → "return-defect order is rigid" (SG-R6 consistency).
- **§6.7 [ALG consequence]:** RECOG-ALG-FATE-BOUNDARY added ($4a^2=3b\Rightarrow\mu_6=-i\tfrac{\sqrt3}{3}(1+2a^2)$); rigidity minimiser recorded as $\tfrac12e^{-i\pi/3}$.
- **§6.1, §6.5 [scope]:** $\widehat C$ domain $Q_aQ_b>0$ stated; comparator intrinsicness narrowed to the $P_1$ linear transport; "largest difference that remains mutual" removed.
- **§6.7 [wording]:** "saturating odd shear" → "negative cubic contribution".
- **§6.2 [SG-R1]:** ontological witness sentence removed; only the substrate statement remains.
- **§9:** stale provenance line updated.
- **§8 [ENG]:** certificate extended to 18 checks; new sha256.

### v0.2 — September 2026
- **§6.1 [COR → ALG consequence]:** comparator sign corrected: $\overline W_aW_b=I_{ab}-i\tfrac{\sqrt3}{2}\omega_{ab}$ under the Genesis $J_Q$; comparator renamed $C_\to$ with explicit orientation; SG-R9 added.
- **§6.1 [ALG]:** RECOG-ALG-INVARIANT-FORM added (symmetric $A$-invariant forms are exactly $cB$), replacing the imported-as-fact wording.
- **§6.2 [COR → DEF]:** return defect redefined on the resonant return germ ($DF^p=I$ at the fixed point); $D_n$ definable for all $n$; irrational case gives undefined $k_{\rm ret}$, not $\infty$.
- **§6.2, §6.5, §7 [import]:** Number Genesis v1.15 provenance closed (NUMGEN-N1C-DYAD-RADIAL, NUMGEN-OPEN-N1C); split into two entries; negative control rescoped.
- **§6.5 [DEF]:** "event classes" → "candidate mathematical strata"; pole-level and state-level pair-symmetry separated; intrinsic conjugacy-class wording removed; intersection principle re-registered as RECOG-OPEN-INTERSECTION under OPEN R6.
- **§6.7 [COR → ALG]:** false imaginary residue floor retracted; RECOG-ALG-CUBIC-RETURN-RIGIDITY added ($|\mu_6(a,b)|\ge\tfrac12$, $k_{\rm ret}(6)=3$ across the family).
- **§6.8 [ALG]:** $\tau$ decomposition restricted to the local cubic angular coefficient; no plateau-memory decomposition claimed.
- **§6.9 [DEF]:** replaced by an Ontology Export Interface; interpretive `[HYP]` lines moved to the ontology note.
- **§2 [OPEN]:** R5 renamed "Why one-sided ratio shear?"; saturation demoted to an untestable-by-jet sub-item.
- **Governance:** `[COR-in-advance]` removed; `[ALG consequence]` alias re-expanded to `[RESULT]` `[from: ALG]`; artifact tagged `[ENG]`; non-registry RID categories (`HYP`, `SUP`) replaced; local aliases noted as not requiring methodology registration.
- **§8 [ENG]:** certificate extended to 15 checks (exact $\omega$, rigidity, direct primitive-$T$ control, comparator orientation, invariant-form uniqueness); new sha256.

### v0.1 — September 2026
- **§1–§9 [initial]:** First consolidation of the recognition branch (spectral → return defect → comparator → event strata → shear-jet law) from the September 2026 session into DSN form. All numerical claims of §6.6–6.7 certified by `recog_shear_jet_cert.py`. Import RIDs from Dyadic/Genesis partially unassigned; Number Genesis source citation unconfirmed. Draft for critique.

---

## Appendix B — Retired and Rejected Claims

**[SUPERSEDED | RID: RECOG-DEF-SPECTRAL-RECOG]** "Spectral Recognition Hypothesis": recognition $=$ eigenvalue/eigenphase of the return transport. Replaced by: §6.2 (eigenvalue is the linearised recognition multiplier; content is the first nontrivial return jet). Version: v0.1.

**[SUPERSEDED | RID: RECOG-DEF-CLOSURE-PREREQ]** "Without return the spectrum cannot be compared with itself" as a prerequisite of all recognition. Replaced by: §6.5 prerequisite ladder (closure needed for the spectral stratum only). Version: v0.1.

**[SUPERSEDED | RID: RECOG-ALG-QUADRATURE-GLOBAL]** "$\cos\eta=0$ is the unique type-change surface on the whole plane." Replaced by: §6.5 (second branch $\cos\eta=4e^\rho$ for $\rho\le-\ln4$; chart-dependent in any case). Version: v0.1.

**[SUPERSEDED | RID: RECOG-DEF-BREAK-CAUSES-HEALING]** "Healing is caused by swap-symmetry breaking." Replaced by: §6.7 radial-fate law ($4a^2>3b$; $\tanh$ heals without breaking). Version: v0.1.

**[RETRACTED | RID: RECOG-DEF-COMPARATOR-SIGN-V01]** $\overline W_aW_b=I_{ab}+i\tfrac{\sqrt3}{2}\omega_{ab}$. Reason: sign error against the certified Genesis $J_Q$ convention; direct algebra gives $-i$. Replaced by: §6.1, SG-R9. Version: v0.2.

**[RETRACTED | RID: RECOG-ALG-IM-FLOOR-V01]** "$\Im\mu_6\le-\tau/2$ across the shear family." Reason: contradicted by $\Im\mu_6^{(s)}=-\tau/4$. Replaced by: RECOG-ALG-CUBIC-RETURN-RIGIDITY (§6.7). Version: v0.2.

**[SUPERSEDED | RID: RECOG-DEF-RETURN-DEFECT-V01]** Return defect defined over an exact closed history $\gamma$. Replaced by: resonant return germ definition, §6.2. Version: v0.2.

**[SUPERSEDED | RID: RECOG-DEF-COPRESENCE-V01]** "By the history-collapse criterion a past state is not part of the present state" (universal reading of the wrapped-$S^1$ negative control). Replaced by: §6.5 scoped statement (retained relational data or current co-realisation). Version: v0.2.

**[SUPERSEDED | RID: RECOG-NUM-P2-C0-FIRST-BASIS]** RECOG-NUM-P2-C0-FIRST `[NUM strong]` as the basis of the positive-branch $C_0$ claim, and the v0.3.3–v0.3.4 "two futures, mixed grade" statement. Replaced by: RECOG-THM-P2-C0-FIRST `[THM]` (§6.11). The high-precision point $(2.033364438914269\ldots,\,8.005165051501685\ldots)$, the transversality diagnostic $\approx-9.38$ and the lifted itinerary remain as historical evidence. Version: v0.3.5.

**[SUPERSEDED | RID: RECOG-NUM-P2-HET-NEG-CONJ]** "Heteroclinic connection $W^u_-(P_2)\to P_1$ conjectured" (v0.3–v0.3.2, `[NUM strong]`). Replaced by: RECOG-THM-P2-HET `[THM]` (§6.11). The sampling evidence (12-step entry into $Q<0.3$, $Q(P_u(-1))=5.215$, long-orbit decay) is retained as history. Version: v0.3.3.

**[SUPERSEDED | RID: RECOG-ALG-R8-STAGE1-LINEAR-CONE]** Linear-cone local lemma at $P_2$ (parallel working session, not registered). Reason: the quadratic cusp $|w|\le\kappa s^2$ is sharper and is the operative Stage 1 of the registered certificate. Version: v0.3.3.

**[SUPERSEDED | RID: RECOG-DEF-BACKBONE-V03]** The v0.3 "corrected backbone for R9": $Q_m=\tfrac qx-\tfrac{7}{54}q^2\tfrac{\log x}{x^2}$, $\Theta_m=\Theta_0-\tau\log x+qH(x)$ with $H$ built from $\tfrac{47}{54}$ and $c_\theta^{(6)}$, $H(\infty)=-\tfrac{31\sqrt3}{72}$, $A(x)$. Reason: $\tfrac{47}{54}$ is the raw fixed-radius angular mean, not a pointwise law, and $c_\theta^{(6)}$ is an archival Lie-gauge quantity; Dyadic v6.4.10 SG-19 forbids their transfer into the conjugacy chart, and the chart values differ ($\tfrac{245}{216}$; phase coefficient of opposite sign). Replaced by: §6.14 chart laws; R9. Version: v0.3.2.

**[SUPERSEDED | RID: RECOG-DEF-R10-TEMPLATE]** R10 as an unposed template "in the R11-resolved chart". Replaced by: DYAD-THM-NF-REM / DYAD-THM-PRIM-CTR accepted (§7, §6.14). Version: v0.3.2.

**[SUPERSEDED | RID: RECOG-ALG-LATTICE-RAWFRAME-V03]** All v0.3 lattice numbers computed with the raw six-step $c_{32},c_{05}$ as normal-form coefficients: $\mathcal I_{\rm lat}=0.0192569$, $|c_{05}|/|\beta|=0.0828$, axes at $33.69^\circ\pmod{60^\circ}$, transfer coefficient $-\tfrac{2767+1219\sqrt3 i}{317520}$, $|\Lambda|\le0.010962\,Q_0$. Reason: those coefficients belong to the raw frame with nonzero quartic jet; post-$H_2$ values differ and the lattice one is fixed by the Dyadic one-step ledger. Replaced by: §6.13 (post-$H_2$), OPEN R11. Version: v0.3.1.

**[SUPERSEDED | RID: RECOG-DEF-FIX-TWO-POINTS]** "$\operatorname{Fix}(T)=\{P_1,P_2\}$ on the wrapped phase; $\operatorname{Fix}(S_o)=\operatorname{Fix}(T)$." Reason: wrapped cylinder has winding fixed points $(\log(1+2\pi k),0/\pi)$; the pole stratum contains all $\rho$. Replaced by: §6.3, §6.4. Version: v0.3.1.

**[SUPERSEDED | RID: RECOG-DEF-ONLY-RANK-CHARTFREE]** "Only rank is pointwise chart-free." Reason: sign of $\det DF_x$ is also invariant under connected-chart conjugacy. Replaced by: SG-R3. Version: v0.3.1.

**[SUPERSEDED | RID: RECOG-DEF-PSILAT-GAUGE]** "$\Psi_{\rm lat}$ invariant under $U(1)$-equivariant residual gauge." Reason: $\widetilde W=e^{ia|W|^2}W$ shifts it by $-6aQ$. Replaced by: SG-R10, §6.13. Version: v0.3.1.

**[SUPERSEDED | RID: RECOG-DEF-RAW-REMAINDER-O5]** "$T^6(W)=W+\mu_6|W|^2W+O(|W|^5)$ in the linear eigenframe." Reason: raw quartic jet is nonzero. Replaced by: §6.2. Version: v0.3.1.

**[SUPERSEDED | RID: RECOG-NUM-P2-C0-FIRST-V1]** "The first rank-loss encounter lies $8.66^\circ$ inside quadrature, toward the antipode; $81.34^\circ$ is an oriented antipode-to-rank-loss scale." Reason: the unstable branch traverses $278.66^\circ$ of lifted pole angle, crossing $-i,+1,+i$, and reaches $C_0$ $8.66^\circ$ past the second quadrature from the identity side; $81.34^\circ$ is the wrapped shadow and the offset is derived from $\rho_*$. Replaced by: §6.11. Version: v0.3.

**[SUPERSEDED | RID: RECOG-DEF-KRET-OPEN-V021]** "$k_{\rm ret}(p)$ unknown for $p\ne6$; $\mu_p=0$ possible at exceptional horizons." Replaced by: §6.10 (no cubic-silent horizon for $p\ge5$). Version: v0.3.

**[SUPERSEDED | RID: RECOG-DEF-LATTICE-ONSET-EVENT]** "A recognition event is the onset of lattice-harmonic content." Reason: onset is an order in the germ, not a locus; no $Q$-threshold exists. Replaced by: §6.13 clock and retained-memory formulation; R6 memory-version `[HYP]`. Version: v0.3.

**[SUPERSEDED | RID: RECOG-DEF-NEGATIVE-BRANCH-CONFINED]** "$W^u_-(P_2)$ stays in $\rho<0$, hence rank loss is excluded on it." Reason: the branch reaches $\rho\approx0.62$; the lemma covers only segments confined to $\rho<0$. Replaced by: §6.11. Version: v0.3.

**[SUPERSEDED | RID: RECOG-OPEN-SATURATING-SHEAR]** OPEN R5 framed as "why saturating shear". Reason: $e^\rho-1$ is unbounded for $\rho\to+\infty$; the cubic jet cannot test saturation. Replaced by: RECOG-OPEN-ONESIDED-SHEAR. Version: v0.2.

**[FAIL | RID: RECOG-FAIL-K-FROM-SADDLE]** Derive the antipodal band width $k$ from the $P_2$ saddle spectrum alone. Reason: eigenvalues fix width–lifetime scaling, not width; invariant under local rescaling. Closed: v0.1.

---

*END OF DOCUMENT — RTG_RELATIONAL_RECOGNITION_DSN_v0.3.7*
