#!/usr/bin/env python
"""release_v2_8_7.py — metadata-only adoption transform: reviewed v2.8.7 DRAFT -> adopted v2.8.7.
Usage: python release_v2_8_7.py <draft.md> <out.md> --date "<D Month YYYY>" --decision "<owner decision ref>" [--preview]
--preview prepends a one-line non-adoption banner; without it the output is the adopted release.
A non-preview run refuses placeholder decision text."""
import sys, re, hashlib, argparse
DRAFT_SHA = "81a9bd9c954f6e71d47e2cb28a9417f6dd27b51fe6132b2efe72134bf3ea7a22"
PACKAGE_SHA = "114ff19b27a121ab15f5d0714651cf738027998fe6e9b06f8692d4386646d4c7"
PLACEHOLDER = "[PENDING OWNER DECISION]"
BANNER = "> **ADOPTION PREVIEW — NOT ADOPTED.** This file shows the exact release bytes below this line; adoption requires the owner decision. Adopted owner remains v2.8.6.\n\n"
def edits(date, decision):
    E = []
    def ed(i, o, n): E.append((i, o, n))
    ed("R-title", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.7_DRAFT\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.7\n")
    ed("R-date", "**Date:** 18 October 2026 (draft)  \n**Document status:** DRAFT owner successor — Stage B (six-step K3 factor theorem, chiral cubic factor lemma, mean-feedback family). **Not adopted**; adopted owner remains v2.8.6 (`294c6fc2…a269`).  \n",
       f"**Date:** {date}  \n**Document status:** ADOPTED owner ledger — six-step K3 factor theorem, chiral cubic factor lemma, mean-feedback family.  \n")
    ed("R-supersedes", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.6` ·", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.6` ·")
    ed("R-summary", "*(v2.8.7 draft on the adopted v2.8.6 base;", "*(v2.8.7 adopted release on the v2.8.6 base;")
    ed("R-h5", "**v2.8.7 draft addition:**", "**v2.8.7 addition:**")
    ed("R-k1a", "six-step factor obstruction (v2.8.7 draft).** The projected", "six-step factor obstruction (v2.8.7).** The projected")
    ed("R-k1b", "**Mean-feedback six-step obstruction (v2.8.7 draft; conditional).**", "**Mean-feedback six-step obstruction (v2.8.7; conditional).**")
    ed("R-sg16", "**Six-step and mean-feedback scope guard (v2.8.7 draft).**", "**Six-step and mean-feedback scope guard (v2.8.7).**")
    ed("R-h631", "#### §6.3a.1 Six-Step Clock `[THM]` (v2.8.7 draft) {#", "#### §6.3a.1 Six-Step Clock `[THM]` (v2.8.7) {#")
    ed("R-n631", "*(v2.8.7 draft; source: `K3_KAPPA_SIX_STEP_CLOCK_NOTE_v0_3.md`", "*(v2.8.7; source: `K3_KAPPA_SIX_STEP_CLOCK_NOTE_v0_3.md`")
    ed("R-h63b", "Triad Family `[DEF / ALG / THM]` (v2.8.7 draft) {#", "Triad Family `[DEF / ALG / THM]` (v2.8.7) {#")
    ed("R-n63b", "*(v2.8.7 draft; source: K3-6S v0.3 §1", "*(v2.8.7; source: K3-6S v0.3 §1")
    ed("R-exp", "`[DEF]` **(v2.8.7 draft) RRF G2-CLOCK six-step export.** On adoption, Genesis exports", "`[DEF]` **(v2.8.7) RRF G2-CLOCK six-step export.** Genesis exports")
    ed("R-art1", "\\(\\beta\\neq0\\) (v2.8.7 draft) :: `[THM]`", "\\(\\beta\\neq0\\) (v2.8.7) :: `[THM]`")
    ed("R-art2", "six-step factor obstruction (v2.8.7 draft) :: `[THM]`", "six-step factor obstruction (v2.8.7) :: `[THM]`")
    ed("R-art3", "on \\(\\mathbb R^6\\) (v2.8.7 draft) :: `[DEF]`", "on \\(\\mathbb R^6\\) (v2.8.7) :: `[DEF]`")
    ed("R-art4", "mean-feedback six-step obstruction (v2.8.7 draft) :: `[THM]`", "mean-feedback six-step obstruction (v2.8.7) :: `[THM]`")
    ed("R-appA", "### v2.8.7 — 18 October 2026 — DRAFT record (not adopted)\n",
       f"### v2.8.7 — {date} — Adopted owner release\n\n**Adoption:** {decision}. Scientific payload is the reviewed DRAFT bytes `{DRAFT_SHA}` (independent receiving review, 18 October 2026: 17/17 gates PASS in `--final` mode, 0 SKIP; package `{PACKAGE_SHA}`). The adoption transform `release_v2_8_7.py` changes metadata, status, history and footer only; `check_release_v2_8_7.py` proves it. `k3_six_step_factor_check.py` remains HISTORICAL / CONFIRMATORY / NOT REPLAYED and is not a proof input; M2c is unchanged; the Dyadic v6.4.12.1 repin remains deferred (D5). Outbound notices (RRF G2-CLOCK six-step; FMS/OFN terminology) are issued after adoption.\n\n#### v2.8.7 — DRAFT record, 18 October 2026 — Stage B\n")
    ed("R-foot", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.7_DRAFT*  \n*Draft successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.6 (not adopted).",
       "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.7*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.6.")
    return E
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("draft"); ap.add_argument("out")
    ap.add_argument("--date", required=True); ap.add_argument("--decision", required=True); ap.add_argument("--preview", action="store_true")
    a = ap.parse_args()
    if not a.preview:
        assert PLACEHOLDER not in a.decision, "placeholder decision text: run with --preview or give the owner decision"
        assert re.fullmatch(r"\d{1,2} [A-Z][a-z]+ 20\d\d", a.date), "date must look like '19 October 2026'"
    raw = open(a.draft, "rb").read(); assert hashlib.sha256(raw).hexdigest() == DRAFT_SHA, "draft hash mismatch"
    t = raw.decode("utf-8")
    for i, o, n in edits(a.date, a.decision):
        assert t.count(o) == 1, f"{i}: {t.count(o)} matches"; t = t.replace(o, n)
    rel_sha = hashlib.sha256(t.encode()).hexdigest()
    if a.preview: t = BANNER + t
    open(a.out, "w", encoding="utf-8", newline="").write(t)
    print(f"release bytes sha256={rel_sha}" + ("  (written as PREVIEW with banner)" if a.preview else ""))
