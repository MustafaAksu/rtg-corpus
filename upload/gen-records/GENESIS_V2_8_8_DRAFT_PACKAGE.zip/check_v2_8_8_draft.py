#!/usr/bin/env python
"""check_v2_8_8_draft.py — independent gate checker for RTG_GENESIS_GEOMETRY_DSN_v2_8_8_DRAFT (maintenance).
Gates: manifest v0.1 §3 (M1-M5, S1-S4, optional S5) with the owner review of 19 Oct 2026:
  * M3 recognises historical v6.4.11 uses by textual anchor and scope, never by line number;
  * S3 authorises every edit by an independent RULE (not by copying the build), so a change is accepted
    only if it matches one authorised P/H/APPA/FOOT operation exactly.
Usage:
  python check_v2_8_8_draft.py --base v2_8_7.md --draft v2_8_8_DRAFT.md --build build_v2_8_8_draft.py
         [--dyad RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md] [--replay genesis_nu5_p5_replay.py] [--final]
--final: owner-review mode; any SKIP (missing --dyad) counts as FAIL. S5 (--replay) is optional in both modes."""
import sys, re, os, hashlib, argparse, subprocess, tempfile, collections
ap = argparse.ArgumentParser()
for k in ("base", "draft", "build"): ap.add_argument("--" + k, required=True)
ap.add_argument("--dyad"); ap.add_argument("--replay"); ap.add_argument("--final", action="store_true")
a = ap.parse_args()
BASE_SHA = "d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361"
DYAD_SHA = "5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542"
REPLAY_SHA = "34bab14033a1f6bdf51f47e5c9694de43b68c2e05e6f410a7d6fa91e27f661cb"
CONV = "`[conv: one-step NF, declared K_5 family, frame W_p, resonant h=0]`"
FROZEN_RIDS = ["GEN-THM-K3-PLANAR-FACTOR-NOGO", "GEN-THM-K3-SIXSTEP-FACTOR-NOGO", "GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO",
               "GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA", "GEN-DEF-MEANFEEDBACK-FAMILY"]
FORBIDDEN_DYAD = ["DYAD-THM-FORMAL-Z6-GENERATOR", "DYAD-CAND-FLAT-CENTRALIZER", "DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES",
                  "DYAD-THM-FORMAL-CENTRALIZER", "DYAD-THM-FORMAL-INVOLUTION-UNIQUE", "DYAD-ALG-CENT-KERNEL",
                  "DYAD-THM-ANALYTIC-CLOCK-BRIDGE", "DYAD-OPEN-INVOLUTION-REALIZATION"]
R, SK = [], []
def gate(g, name, ok, note=""): R.append((g, bool(ok))); print(f"{'PASS' if ok else 'FAIL'}  {g:4s} {name}" + (f"  [{note}]" if note else ""))
def skip(g, name, why): SK.append(g); print(f"SKIP  {g:4s} {name}  [{why}]")
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
base = open(a.base, encoding="utf-8").read(); draft = open(a.draft, encoding="utf-8").read()
src = open(a.build, encoding="utf-8").read()
ns = {}; exec(src[src.index("E = []"):src.index("for i, old, new in E:")], ns); E = ns["E"]
live = lambda s: s.split("## Appendix A")[0]

# ---------- M1: identity, determinism, reverse edit ----------
gate("M1a", "baseline v2.8.7 SHA-256", sha(a.base) == BASE_SHA)
with tempfile.TemporaryDirectory() as td:
    out = os.path.join(td, "d.md"); r = subprocess.run([sys.executable, "-I", a.build, a.base, out], capture_output=True, text=True)
    gate("M1b", "draft == fresh deterministic build", r.returncode == 0 and open(out, encoding="utf-8").read() == draft, f"{len(E)} edits")
rev = draft
for i, o, n in reversed(E): rev = rev.replace(n, o, 1)
gate("M1c", "each anchor occurs once in v2.8.7; reverse edit list recovers v2.8.7 byte-exactly",
     all(base.count(o) == 1 for _, o, _ in E) and rev == base)

# ---------- M2: upstream bytes ----------
drids = lambda s: set(re.findall(r"DYAD-[A-Z0-9-]*[A-Z0-9]", s))
if a.dyad:
    dy = open(a.dyad, encoding="utf-8").read()
    VALUES = ["559\\sqrt{15}/4860", "86775991", "1/(1-i\\tau)", "119\\sqrt{3}/648", "2\\sqrt{3}/3", "e^{iF_f/2}", "G_{04}(10)", "13+15\\sqrt{3}/2",
              "[RID: DYAD-ALG-NU5-P5]", "\\tfrac{355-159\\sqrt5}{48}", "(1106\\sqrt5-2473)\\sqrt{10+2\\sqrt5}"]
    miss = [r_ for r_ in sorted(drids(draft)) if not re.search(re.escape(r_) + r"(?![A-Z0-9-])", dy)]
    gate("M2", f"v6.4.13 SHA; all {len(drids(draft))} DYAD RIDs of the draft exist upstream; cited values + nu5 numerals verbatim",
         sha(a.dyad) == DYAD_SHA and not miss and all(v in dy for v in VALUES), ",".join(miss) or sha(a.dyad)[:12] + "…")
else:
    skip("M2", "upstream v6.4.13 byte gate", "--dyad not given")

# ---------- M3: historical v6.4.11 by textual anchor ----------
HIST = ["synchronized to adopted Dyadic v6.4.11 and OFN v0.9.",                       # v2.8.6 status sentence (D1)
        "*(v2.8.6: recognized as import/alias of `DYAD-DEF-PRIMITIVE-MAP`, Dyadic v6.4.11 §1,",   # v2.8.6 alias note (D1)
        "(the v2.8.6 statements above that name v6.4.11 are historical)",            # P11b disclaimer
        "previous pins: v6.4.11 from v2.8.6"]                                          # P2, P9 history
L = live(draft)
for h in HIST: L = L.replace(h, "")
gate("M3", "no live v6.4.11 / v6.4.12 pointer outside the historical anchors; live pins name v6.4.13",
     "v6.4.11" not in L and "v6.4.12" not in L and live(draft).count("v6.4.13") >= 9,
     f"v6.4.13 live mentions: {live(draft).count('v6.4.13')}")

# ---------- M4: frozen science ----------
blk = lambda s: s[s.index("### §6.3a Projected-$K_3$"):s.index("### §6.4 Tetrahedral")]
sg = lambda s, n: re.search(r"\*\*\[SG-%d\]\*\*.*\nViolation:.*\n" % n, s).group(0)
rid_lines = [l for l in base.splitlines() if any(x in l for x in FROZEN_RIDS)]
gate("M4", "§6.3a/§6.3a.1/§6.3b, SG-15, SG-16 and every line carrying the five K3/6S RIDs byte-identical",
     blk(base) == blk(draft) and sg(base, 15) == sg(draft, 15) and sg(base, 16) == sg(draft, 16)
     and all(l in draft.splitlines() for l in rid_lines), f"{len(blk(base))} chars; {len(rid_lines)} RID lines")

# ---------- M5: nu5 line ----------
NU5 = "- $p=5$: $\\nu_5^{(5)} = \\frac{355-159\\sqrt{5}}{48} + i\\frac{(1106\\sqrt{5}-2473)\\sqrt{10+2\\sqrt{5}}}{48}$"
nl = [l for l in draft.splitlines() if l.startswith("- $p=5$: $\\nu_5^{(5)}")]
gate("M5", "nu5 formula byte-identical; same bullet carries DYAD-ALG-NU5-P5 and the exact convention tag",
     len(nl) == 1 and nl[0] == NU5 + " `[RID: DYAD-ALG-NU5-P5]` " + CONV)

# ---------- S1 / S2: no new science ----------
TAG = re.compile(r"`\[(THM|ALG|RESULT|CERT|HYP|CAND|FAIL|RETRACTED|COR|OPEN|DEF|NUM|INTERP|HEUR|DER)\b")
tags = lambda s: collections.Counter(TAG.findall(s))
grids = lambda s: set(re.findall(r"GEN-[A-Z]+-[A-Z0-9-]*[A-Z0-9]", s))
gate("S1", "claim-tag counts and GEN RID set identical to v2.8.7", tags(base) == tags(draft) and grids(base) == grids(draft),
     str({k: tags(draft)[k] - tags(base)[k] for k in set(tags(base)) | set(tags(draft)) if tags(draft)[k] != tags(base)[k]}))
gate("S2", "DYAD RID set = v2.8.7 set + {DYAD-ALG-NU5-P5}; no formal-Z6 / Lemma F / F1-F3 / OPEN 19-20 RID",
     drids(draft) == drids(base) | {"DYAD-ALG-NU5-P5"} and not any(x in draft for x in FORBIDDEN_DYAD), f"{len(drids(draft))} DYAD RIDs")

# ---------- S3: every edit authorised by an independent rule ----------
def appended(o, n): return n[len(o):] if n.startswith(o) else None
def rule(i, o, n):
    if i in {"P1", "P3", "P4", "P5", "P6", "P7", "P8"}:                   # pure repins
        return o.count("v6.4.11") == 1 and n == o.replace("v6.4.11", "v6.4.13")
    if i in {"P2", "P9"}:                                                  # repin + explicit history
        return n == o.replace("v6.4.11", "v6.4.13").replace("[v2.8.6; previously v6.4.10]", "[v2.8.8; previous pins: v6.4.11 from v2.8.6, v6.4.10 before that]") if i == "P2" \
            else n == o.replace("v6.4.11", "v6.4.13").replace("previously pinned v6.4.10", "previous pins: v6.4.11 from v2.8.6, v6.4.10 before that")
    if i == "P10a":
        return o.rstrip("\n") == NU5 and n == NU5 + " `[RID: DYAD-ALG-NU5-P5]` " + CONV + "\n"
    if i == "P10b":
        x = appended(o, n); return x is not None and x.count("\n") == 1 and x.startswith("- [RID: DYAD-ALG-NU5-P5] :: ") and CONV in x \
            and x.rstrip("\n").endswith(":: §6.2 OPEN 9 imports") and "GEN-" not in x
    if i == "P11a":
        return o.startswith("*(v2.8.7 adopted release") and n.startswith("*(v2.8.8 draft on the adopted v2.8.7 base;") and "v2.8.5 correction/reconciliation base." in n
    if i == "P11b":
        x = n[len(o) - 1:] if n.startswith(o[:-1]) else ""
        return x.startswith(" **v2.8.8 draft maintenance:**") and "DYAD-ALG-NU5-P5" in x and "v6.4.13" in x \
            and "No scientific claim is added, changed or regraded." in x and not TAG.search(x) and "GEN-" not in x
    if i == "H1": return n == "# RTG_GENESIS_GEOMETRY_DSN_v2.8.8_DRAFT\n"
    if i == "H2": return n.startswith("**Date:** 19 October 2026 (draft)  \n**Document status:** DRAFT owner successor — maintenance") and "**Not adopted**" in n and not TAG.search(n)
    if i == "H3": return n == o.replace("**Supersedes:** ", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.7` · ")
    if i == "APPA":
        x = appended(o, n); return x is not None and x.startswith("### v2.8.8 — 19 October 2026 — DRAFT record (not adopted)\n") \
            and "No v2.8.7 claim corrected, regraded or retracted." in x and "[NUM]" in x and not TAG.search(x) and "GEN-" not in x
    if i == "FOOT": return n.startswith("*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.8_DRAFT*  \n*Draft maintenance successor") and n.endswith(o.split("\n")[1])
    return False
AUTH = {"H1", "H2", "H3", "P11a", "P11b", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10a", "P10b", "APPA", "FOOT"}
bad = [i for i, o, n in E if i not in AUTH or not rule(i, o, n)]
ids = [i for i, _, _ in E]
gate("S3", "every edit is one authorised P/H/APPA/FOOT operation, matched by an independent rule; each used once",
     not bad and sorted(ids) == sorted(AUTH), ",".join(bad) or f"{len(E)} edits")

# ---------- S5 (optional) ----------
if a.replay:
    ok = sha(a.replay) == REPLAY_SHA
    if ok:
        r = subprocess.run([sys.executable, "-I", a.replay], capture_output=True, text=True)
        ok = r.returncode == 0 and "ALL PASS (4/4)" in r.stdout
    gate("S5", "optional: genesis_nu5_p5_replay.py hash + 4/4 PASS ([NUM] evidence, not an acceptance condition)", ok)

nf = [g for g, ok in R if not ok]; fail_final = a.final and SK
print(f"{'ALL EXECUTED GATES PASS' if not nf else 'FAILURES: ' + ','.join(nf)} ({len(R)-len(nf)}/{len(R)})"
      + (f"; SKIPPED: {','.join(SK)}" if SK else "") + ("  -> FINAL MODE: skips count as FAIL" if fail_final else ""))
sys.exit(1 if (nf or fail_final) else 0)
