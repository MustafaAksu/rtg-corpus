#!/usr/bin/env python
"""build_v2_8_8_draft.py — deterministic build of RTG_GENESIS_GEOMETRY_DSN_v2_8_8_DRAFT (maintenance)
from the exact adopted v2.8.7 bytes. Every edit is an exact-match replacement that must occur exactly once.
Control: GENESIS_V2_8_8_OWNER_PASS_MANIFEST_v0_1 (81939e5f...f542) + owner decisions D1-D4 of 19 Oct 2026.
Usage: python build_v2_8_8_draft.py <v2_8_7.md> <out.md>"""
import sys, hashlib
BASE_SHA = "d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361"
src, out = sys.argv[1], sys.argv[2]
raw = open(src, "rb").read()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA, "baseline hash mismatch"
t = raw.decode("utf-8")

E = []  # (id, old, new)
def ed(i, old, new): E.append((i, old, new))
CONV = "`[conv: one-step NF, declared K_5 family, frame W_p, resonant h=0]`"

# ---------------- header / metadata (H1-H3, P11a) ----------------
ed("H1", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.7\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.8_DRAFT\n")
ed("H2", "**Date:** 18 October 2026  \n**Document status:** ADOPTED owner ledger — six-step K3 factor theorem, chiral cubic factor lemma, mean-feedback family.  \n",
   "**Date:** 19 October 2026 (draft)  \n**Document status:** DRAFT owner successor — maintenance (Dyadic v6.4.13 source synchronization; ν₅⁽⁵⁾ point-of-use attribution). **Not adopted**; adopted owner remains v2.8.7 (`d5d1e57c…e361`).  \n")
ed("H3", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.6` ·",
   "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.7` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.6` ·")
ed("P11a", "*(v2.8.7 adopted release on the v2.8.6 base; v2.8.6 is itself built on the v2.8.5 correction/reconciliation base.",
   "*(v2.8.8 draft on the adopted v2.8.7 base; v2.8.7 is built on the v2.8.6 base, and v2.8.6 on the v2.8.5 correction/reconciliation base.")
ed("P11b", "closure condition, carrier or node exchange (SG-16).\n",
   "closure condition, carrier or node exchange (SG-16). **v2.8.8 draft maintenance:** the live Dyadic source pins move to adopted `RTG_DYADIC_OSCILLATOR_DSN_v6.4.13` (the v2.8.6 statements above that name v6.4.11 are historical); the \\(\\nu_5^{(5)}\\) closed form of §6.2 is attributed to `DYAD-ALG-NU5-P5` with its normalization convention (M2c point-of-use attribution). No scientific claim is added, changed or regraded.\n")

# ---------------- G8-01 live Dyadic pointers (P1-P9) ----------------
ed("P1", "`RTG_DYADIC_OSCILLATOR_DSN_v6.4.11` · `RTG_TRIADIC", "`RTG_DYADIC_OSCILLATOR_DSN_v6.4.13` · `RTG_TRIADIC")
ed("P2", "(repinned to Dyadic DSN v6.4.11 [v2.8.6; previously v6.4.10];",
   "(repinned to Dyadic DSN v6.4.13 [v2.8.8; previous pins: v6.4.11 from v2.8.6, v6.4.10 before that];")
ed("P3", "see `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11` for the primary ledger", "see `RTG_DYADIC_OSCILLATOR_DSN_v6.4.13` for the primary ledger")
ed("P4", "| Dyadic DSN v6.4.11 |", "| Dyadic DSN v6.4.13 |")
ed("P5", "primary ledger in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`", "primary ledger in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.13`")
ed("P6", "### From `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`", "### From `RTG_DYADIC_OSCILLATOR_DSN_v6.4.13`")
ed("P7", "closed in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`", "closed in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.13`")
ed("P8", "closed under its declared convention in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`", "closed under its declared convention in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.13`")
ed("P9", "imported from Dyadic DSN v6.4.11 (`DYAD-CAND-P0-DYADIC`, conditional only; previously pinned v6.4.10)",
   "imported from Dyadic DSN v6.4.13 (`DYAD-CAND-P0-DYADIC`, conditional only; previous pins: v6.4.11 from v2.8.6, v6.4.10 before that)")

# ---------------- G8-02 nu_5^(5) attribution + convention (P10a, P10b) ----------------
NU5 = "- $p=5$: $\\nu_5^{(5)} = \\frac{355-159\\sqrt{5}}{48} + i\\frac{(1106\\sqrt{5}-2473)\\sqrt{10+2\\sqrt{5}}}{48}$\n"
ed("P10a", NU5, NU5[:-1] + " `[RID: DYAD-ALG-NU5-P5]` " + CONV + "\n")
P567 = "- [RID: DYAD-ALG-P567-LEDGER] :: $p=5,6,7$ finite one-step ledger exact coefficients :: §6.2 OPEN 9 imports\n"
ed("P10b", P567, P567 + "- [RID: DYAD-ALG-NU5-P5] :: $\\nu_5^{(5)}$ closed form, exact over $\\mathbb{Q}(\\sqrt5,\\sqrt{10+2\\sqrt5})$ " + CONV
   + " (exact certificate `dyad_m2c_nu5_p5_exact.py`, Dyadic owner; v2.8.8) :: §6.2 OPEN 9 imports\n")

# ---------------- G8-03 Appendix A record ----------------
ed("APPA", "## Appendix A — Version History {#appendix-a}\n\n",
   "## Appendix A — Version History {#appendix-a}\n\n"
   + "### v2.8.8 — 19 October 2026 — DRAFT record (not adopted)\n\n"
   + "Maintenance successor built deterministically from the exact adopted v2.8.7 bytes (`d5d1e57c…e361`) by `build_v2_8_8_draft.py`. Control: owner-pass manifest v0.1 (`81939e5f…f542`) and owner decisions D1–D4 of 19 Oct 2026. Upstream: adopted Dyadic v6.4.13 (`5958f7fe…8542`), consumer audit `check_genesis_dyad_v6_4_13_consumer.py` 8/8 PASS on the adopted bytes.\n\n"
   + "- **G8-01 (deferred D5 executed in this draft):** live Dyadic pointers v6.4.11 → v6.4.13 (companion header, P0-DYADIC status, OPEN 9, §4 routing, §6.2 OPEN 9 imports, §7 header, OPEN 16/17 continuity, §8 P0-DYADIC import). Dated v2.8.6 statements naming v6.4.11 are kept as history (D1).\n"
   + "- **G8-02:** §6.2 \\(\\nu_5^{(5)}\\) closed form unchanged; the same line now names its source `DYAD-ALG-NU5-P5` and convention (D2); new §7 import line.\n"
   + "- **G8-03 — M2c:** source and numerical check RESOLVED; point-of-use metadata applied in this draft, effective on adoption. Exact certificate: Dyadic owner (`dyad_m2c_nu5_p5_exact.py`). Genesis-side independent replay, numerical grade [NUM] only (D3): `genesis_nu5_p5_replay.py` (`34bab140…61cb`), 4/4 PASS — p=6 calibration against DYAD-ALG-NF6, p=5 value to 1e-50, negative control, and convention sensitivity (a resonant normalizer coefficient h21 = i/10 shifts Im n32 by 0.01127).\n"
   + "- **G8-04:** status-summary maintenance sentence (D4); header and footer.\n"
   + "- **Not in this draft:** any import of the formal ℤ₆ generator, Lemma F or F1–F3; any change to §6.3a, §6.3a.1, §6.3b, SG-15 or SG-16; physical G2, OPEN-B/E1 or γ selection; new GEN RIDs or claim tags.\n"
   + "- **No v2.8.7 claim corrected, regraded or retracted.**\n\n")

# ---------------- footer ----------------
ed("FOOT", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.7*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.6.",
   "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.8_DRAFT*  \n*Draft maintenance successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.7 (not adopted). v2.8.8 moves the live Dyadic pins to v6.4.13 and attributes the ν₅⁽⁵⁾ closed form to DYAD-ALG-NU5-P5 with its convention; no scientific claim changes. Inherited v2.8.7 footer follows:*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.6.")

for i, old, new in E:
    n = t.count(old)
    assert n == 1, f"{i}: expected 1 match, found {n}"
    t = t.replace(old, new)
open(out, "w", encoding="utf-8", newline="").write(t)
print(f"applied {len(E)} edits -> {out}  sha256={hashlib.sha256(t.encode()).hexdigest()}")
