#!/usr/bin/env python
"""kappa_pq_symbolic.py — p(kappa), q(kappa) as exact identities in Q(kappa)(i*sqrt3).
Same construction as kappa_pq_independent.py, but kappa is an indeterminate: coefficients live in the
rational-function field Q(kappa), so the closed forms are verified identically in kappa (no interpolation).
Own construction: 6-real-dim kappa-map w_e' = T(w_e) - kappa*mean(T(w)); centre manifold
s = psi(u) solved by its own homological equation through degree 3 (psi2 AND psi3);
reduced map on C, six-fold composition, chiral form of BOTH components. Exact Q(i*sqrt3)."""
import sys
from sympy import QQ, symbols
from sympy.polys.fields import field
FQ, KAP = field("kappa", QQ)
def Fr(a, b=1):
    if hasattr(a, "field"): return a / b
    return FQ(QQ(a)) / FQ(QQ(b))
from math import factorial
D = 3
class K:
    __slots__=("p","q")
    def __init__(s,p=0,q=0): s.p,s.q=Fr(p),Fr(q)
    def __add__(a,b): b=k(b); return K(a.p+b.p,a.q+b.q)
    __radd__=__add__
    def __neg__(a): return K(-a.p,-a.q)
    def __sub__(a,b): return a+(-k(b))
    def __mul__(a,b): b=k(b); return K(a.p*b.p-3*a.q*b.q,a.p*b.q+a.q*b.p)
    __rmul__=__mul__
    def conj(a): return K(a.p,-a.q)
    def inv(a): n=a.p*a.p+3*a.q*a.q; return K(a.p/n,-a.q/n)
    def __truediv__(a,b): return a*k(b).inv()
    def iszero(a): return a.p==0 and a.q==0
    def __eq__(a,b): b=k(b); return a.p==b.p and a.q==b.q
    def __repr__(a): return f"{a.p}" if a.q==0 else f"{a.p}{'+' if a.q>=0 else '-'}{abs(a.q)}*i*sqrt3"
def k(x): return x if isinstance(x,K) else K(x)
S3=K(0,1); LAM=K(Fr(1,2),Fr(1,2)); LAMB=LAM.conj()
# polys in (u1,U1,u2,U2) as dict
def clean(P): return {m:c for m,c in P.items() if not c.iszero() and sum(m)<=D}
def add(*Ps):
    R={}
    for P in Ps:
        for m,c in P.items(): R[m]=R.get(m,K())+c
    return clean(R)
def sc(c,P): return clean({m:k(c)*v for m,v in P.items()})
def mul(P,Q):
    R={}
    for m,c in P.items():
        for n,d in Q.items():
            if sum(m)+sum(n)<=D:
                t=tuple(x+y for x,y in zip(m,n)); R[t]=R.get(t,K())+c*d
    return clean(R)
def cj(P): return {(b1,a1,b2,a2):c.conj() for (a1,b1,a2,b2),c in P.items()}
def deg(P,d): return {m:c for m,c in P.items() if sum(m)==d}
def eq(P,Q): return not add(P,sc(-1,Q))
one={(0,0,0,0):K(1)}
u1,U1,u2,U2={(1,0,0,0):K(1)},{(0,1,0,0):K(1)},{(0,0,1,0):K(1)},{(0,0,0,1):K(1)}
# primitive T in W chart, 1-var poly {(a,b)}
def p1a(*Ps):
    R={}
    for P in Ps:
        for m,c in P.items(): R[m]=R.get(m,K())+c
    return {m:c for m,c in R.items() if not c.iszero() and sum(m)<=D}
def p1m(P,Q):
    R={}
    for (a,b),c in P.items():
        for (e,f),d in Q.items():
            if a+b+e+f<=D: R[(a+e,b+f)]=R.get((a+e,b+f),K())+c*d
    return {m:c for m,c in R.items() if not c.iszero()}
p1s=lambda c,P:{m:k(c)*v for m,v in P.items() if not (k(c)*v).iszero()}
Z,ZB={(1,0):K(1)},{(0,1):K(1)}
rho=p1a(p1s(Fr(1,2),p1a(Z,ZB)),p1s(K(0,Fr(-1,6)),p1a(Z,p1s(-1,ZB))))
eta=p1s(K(0,Fr(-1,3)),p1a(Z,p1s(-1,ZB)))
def ser(x,cf):
    R,p={}, {(0,0):K(1)}
    for n in range(D+1):
        if cf(n): R=p1a(R,p1s(cf(n),p))
        p=p1m(p,x)
    return R
sn=ser(eta,lambda n:Fr((-1)**((n-1)//2),factorial(n)) if n%2 else 0)
em=ser(rho,lambda n:Fr(1,factorial(n)) if n else 0)
r1,e1=p1a(rho,p1s(-1,sn)),p1a(eta,em,p1s(-1,sn))
TW=p1a(r1,p1s(Fr(-1,2),e1),p1s(S3*Fr(1,2),e1))
def applyT(g):
    gb=cj(g); pw,pwb=[one],[one]
    for _ in range(D): pw.append(mul(pw[-1],g)); pwb.append(mul(pwb[-1],gb))
    R={}
    for (a,b),c in TW.items(): R=add(R,sc(c,mul(pw[a],pwb[b])))
    return R
def substitute(P,G1,G2):  # P(G1,conjG1,G2,conjG2)
    vals=[G1,cj(G1),G2,cj(G2)]; pw=[[one] for _ in range(4)]
    for i in range(4):
        for _ in range(D): pw[i].append(mul(pw[i][-1],vals[i]))
    R={}
    for (a,b,c_,d),cf in P.items(): R=add(R,sc(cf,mul(mul(pw[0][a],pw[1][b]),mul(pw[2][c_],pw[3][d]))))
    return R
def lampow(n):
    r=K(1)
    for _ in range(n%6): r=r*LAM
    return r
def run(kap):
    ue=[u1,u2,add(sc(-1,u1),sc(-1,u2))]
    def step(psi):
        w=[add(x,sc(Fr(1,3),psi)) for x in ue]
        t=[applyT(x) for x in w]; tot=add(*t); m=sc(Fr(1,3),tot)
        return sc(1-kap,tot),[add(t[0],sc(-1,m)),add(t[1],sc(-1,m))]   # s', (u1',u2')
    psi={}
    for d in (2,3):
        sp_,(a1,a2)=step(psi)
        R=deg(add(sp_,sc(-1,substitute(psi,a1,a2))),d)
        for (a,b,c_,dd),cf in R.items():
            den=lampow((a+c_)-(b+dd))-LAM*(1-kap)
            psi=add(psi,{(a,b,c_,dd):cf/den})
    sp_,(a1,a2)=step(psi)
    inv_ok=eq(add(sp_,sc(-1,substitute(psi,a1,a2))),{})        # invariance through degree 3
    G1,G2=u1,u2
    for _ in range(6): G1,G2=substitute(a1,G1,G2),substitute(a2,G1,G2)
    f1,f2=deg(G1,3),deg(G2,3)
    assert not deg(G1,2) and not deg(G2,2) and G1.get((1,0,0,0))==K(1)
    u=add(u1,sc(LAM,u2)); v=add(u1,sc(LAMB,u2)); Uc,Vc=cj(u),cj(v)
    uf=add(f1,sc(LAM,f2)); vf=add(f1,sc(LAMB,f2))
    Um=mul(mul(u,u),Uc); Vm=mul(mul(v,Vc),u)          # u|u|^2, |v|^2 u
    c1=uf.get((2,1,0,0),K()); c2=uf.get((2,0,0,1),K())  # coeffs of u1^2 U1, u1^2 U2
    # p + q = c1 ; p*lamb + q*lam = c2
    q=(c2-c1*LAMB)/(LAM-LAMB); p=c1-q
    ok_u=eq(uf,add(sc(p,Um),sc(q,Vm)))
    ok_v=eq(vf,add(sc(p,mul(mul(v,v),Vc)),sc(q,mul(mul(u,Uc),v))))
    return p,q,inv_ok,ok_u,ok_v,psi
def pform(x):
    n=x*x-x+1
    return K(-(x*x-3*x+1)/(6*n), -(2*x*x-3*x+2)/(9*n))
def qform(x):
    n=x*x-x+1; Dd=(x-2)*n
    return K(-2*(x-1)**3/(3*Dd), -2*(2*x*x-3*x+2)/(9*n))
p,q,inv,ou,ov,psi=run(KAP)
okp, okq = (p==pform(KAP)), (q==qform(KAP))
print("p(kappa) =", p.p, " + i*sqrt3*(", p.q, ")")
print("q(kappa) =", q.p, " + i*sqrt3*(", q.q, ")")
print(f"invariance_through_deg3={inv} u-form={ou} v-form={ov} p_matches={okp} q_matches={okq}")
dens=sorted({str(c.p.denom)+" | "+str(c.q.denom) for c in psi.values()})
print("psi coefficient denominators (Re | Im/sqrt3):"); [print("   ",d) for d in dens]
ok=inv and ou and ov and okp and okq
print("ALL PASS (identity in Q(kappa))" if ok else "FAILURES"); sys.exit(0 if ok else 1)
