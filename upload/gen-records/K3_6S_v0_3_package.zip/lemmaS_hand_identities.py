#!/usr/bin/env python
"""lemmaS_hand_identities.py — checks every matrix identity used in the hand proof of Lemma S (p != 0),
symbolically in p = a+ib, q = c+id (sympy, exact). Not a proof by itself; it audits the proof's computations.
 I1  Df(e^{ia},0) = diag( p(I+2P_a), q )  for a in {0, pi/2, pi/6}      (P_a = projection on R e^{ia})
 I2  A(a) := P_a - P_0 is invertible for a = pi/2, pi/6 and A(pi/2)^{-1} A(pi/6) = (1/2) Rot(pi/3)
 I3  Rot(pi/3) has no real eigenline (char. poly discriminant < 0)
 I4  v-block of Df(1,1) applied to (h,0), h=1, equals 2q   (so C_u+0 is invariant only if q=0)
 I5  u-block of Df(1,1) applied to (0,h), h=1, equals 2q   (so 0+C_v is invariant only if q=0)"""
import sys
import sympy as sp
a,b,c,d=sp.symbols("a b c d", real=True)
x1,y1,x2,y2=sp.symbols("x1 y1 x2 y2", real=True)
p=a+sp.I*b; q=c+sp.I*d; u=x1+sp.I*y1; v=x2+sp.I*y2
N=lambda z: sp.expand(z*sp.conjugate(z))
fu=sp.expand(u*(p*N(u)+q*N(v))); fv=sp.expand(v*(p*N(v)+q*N(u)))
F=sp.Matrix([sp.re(fu),sp.im(fu),sp.re(fv),sp.im(fv)]).applyfunc(sp.expand)
X=[x1,y1,x2,y2]; J=F.jacobian(X)
def Df(uu,vv): return J.subs({x1:sp.re(uu),y1:sp.im(uu),x2:sp.re(vv),y2:sp.im(vv)}).applyfunc(sp.simplify)
Mp=sp.Matrix([[a,-b],[b,a]]); Mq=sp.Matrix([[c,-d],[d,c]])
P=lambda t: sp.Matrix([[sp.cos(t)**2,sp.cos(t)*sp.sin(t)],[sp.cos(t)*sp.sin(t),sp.sin(t)**2]])
res=[]
ok1=True
for t in (0,sp.pi/2,sp.pi/6):
    want=sp.diag(Mp*(sp.eye(2)+2*P(t)),Mq)
    ok1&= (Df(sp.exp(sp.I*t),0)-want).applyfunc(sp.simplify)==sp.zeros(4,4)
res.append(("I1",ok1))
A=lambda t: P(t)-P(0)
Rot=lambda t: sp.Matrix([[sp.cos(t),-sp.sin(t)],[sp.sin(t),sp.cos(t)]])
ok2= A(sp.pi/2).det()!=0 and A(sp.pi/6).det()!=0 and (A(sp.pi/2).inv()*A(sp.pi/6)-Rot(sp.pi/3)/2).applyfunc(sp.simplify)==sp.zeros(2,2)
res.append(("I2",ok2))
R=Rot(sp.pi/3); disc=sp.simplify(R.trace()**2-4*R.det()); res.append(("I3",disc<0))
J11=Df(1,1)
res.append(("I4",sp.simplify(J11[2,0]+sp.I*J11[3,0]-2*q)==0))
res.append(("I5",sp.simplify(J11[0,2]+sp.I*J11[1,2]-2*q)==0))
for g,ok in res: print(("PASS" if ok else "FAIL"),g)
allok=all(ok for _,ok in res); print("ALL PASS (5/5)" if allok else "FAILURES"); sys.exit(0 if allok else 1)
