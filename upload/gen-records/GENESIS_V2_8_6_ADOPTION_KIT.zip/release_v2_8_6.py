#!/usr/bin/env python
"""release_v2_8_6.py — metadata-only adoption transform: reviewed v2.8.6 DRAFT -> adopted v2.8.6.
Usage: python release_v2_8_6.py <draft.md> <out.md> --date "16 October 2026" --decision "<owner decision ref>" [--preview]
--preview prepends a one-line non-adoption banner; without it the output is the adopted release."""
import sys, hashlib, argparse
DRAFT_SHA = "434ea62a85b620dd95aa9b2798690cb09e535f1f02141d4a9cbcf829aba47104"
BANNER = "> **ADOPTION PREVIEW — NOT ADOPTED.** This file shows the exact release bytes below this line; adoption requires the owner decision. Adopted owner remains v2.8.5.\n\n"
def edits(date, decision):
    E = []
    def ed(i, o, n): E.append((i, o, n))
    ed("R-title", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.6_DRAFT\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.6\n")
    ed("R-date", "**Date:** 16 October 2026 (draft)  \n**Document status:** DRAFT owner successor — Stage B (K3 planar-factor theorem + Dyadic v6.4.11 / OFN v0.9 source synchronization). **Not adopted**; adopted owner remains v2.8.5 (`41ed7660…475cf`).  \n",
       f"**Date:** {date}  \n**Document status:** ADOPTED owner ledger — K3 planar-factor theorem + Dyadic v6.4.11 / OFN v0.9 source synchronization.  \n")
    ed("R-supersedes", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.5` ·", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.5` ·")
    ed("R-summary", "**Status summary.** *(v2.8.5 adopted correction/reconciliation release. Version history remains in Appendix A.)*",
       "**Status summary.** *(v2.8.6 adopted release on the v2.8.5 correction/reconciliation base. Version history remains in Appendix A.)*")
    ed("R-h5", "**v2.8.6 draft addition:**", "**v2.8.6 addition:**")
    ed("R-k1", "obstruction (v2.8.6 draft).** The projected", "obstruction (v2.8.6).** The projected")
    ed("R-sg15", "**Planar-factor scope guard (v2.8.6 draft).**", "**Planar-factor scope guard (v2.8.6).**")
    ed("R-63a", "*(v2.8.6 draft; source:", "*(v2.8.6; source:")
    ed("R-exp", "`[DEF]` **(v2.8.6 draft) RRF G2-CLOCK export.**", "`[DEF]` **(v2.8.6) RRF G2-CLOCK export.**")
    ed("R-art", "planar-factor obstruction (v2.8.6 draft) :: `[THM]`", "planar-factor obstruction (v2.8.6) :: `[THM]`")
    ed("R-appA", "### v2.8.6 — DRAFT, 16 October 2026 — Stage B (not adopted)\n",
       f"### v2.8.6 — {date} — Adopted owner release\n\n**Adoption:** {decision}. Scientific payload is the reviewed DRAFT bytes `{DRAFT_SHA}` (receiving review: 19/19 gates PASS, including M6c). The adoption transform `release_v2_8_6.py` changes metadata, status, history and footer only; `check_release_v2_8_6.py` proves it. Open provenance item M2c (ν₅⁽⁵⁾ closed form not printed in the Dyadic source) is non-blocking and is **not** marked source-verified. Outbound notices (RRF G2-CLOCK, Dyadic N1/N2, OFN CUST-O09-01) are issued after adoption.\n\n#### v2.8.6 — DRAFT record, 16 October 2026 — Stage B\n")
    ed("R-foot", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.6_DRAFT*  \n*Draft successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.5 (not adopted).",
       "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.6*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.5.")
    return E
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("draft"); ap.add_argument("out")
    ap.add_argument("--date", required=True); ap.add_argument("--decision", required=True); ap.add_argument("--preview", action="store_true")
    a = ap.parse_args()
    raw = open(a.draft, "rb").read(); assert hashlib.sha256(raw).hexdigest() == DRAFT_SHA, "draft hash mismatch"
    t = raw.decode("utf-8")
    for i, o, n in edits(a.date, a.decision):
        assert t.count(o) == 1, f"{i}: {t.count(o)} matches"; t = t.replace(o, n)
    rel_sha = hashlib.sha256(t.encode()).hexdigest()
    if a.preview: t = BANNER + t
    open(a.out, "w", encoding="utf-8", newline="").write(t)
    print(f"release bytes sha256={rel_sha}" + ("  (written as PREVIEW with banner)" if a.preview else ""))
