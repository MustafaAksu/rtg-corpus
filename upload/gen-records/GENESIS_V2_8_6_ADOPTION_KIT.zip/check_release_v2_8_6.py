#!/usr/bin/env python
"""check_release_v2_8_6.py — proves the adoption transform is metadata-only.
Usage: python check_release_v2_8_6.py <draft.md> <release_or_preview.md> --date ... --decision ..."""
import sys, re, hashlib, argparse, collections, importlib.util, os
ap = argparse.ArgumentParser(); ap.add_argument("draft"); ap.add_argument("release")
ap.add_argument("--date", required=True); ap.add_argument("--decision", required=True); a = ap.parse_args()
spec = importlib.util.spec_from_file_location("rel", os.path.join(os.path.dirname(os.path.abspath(__file__)), "release_v2_8_6.py"))
rel = importlib.util.module_from_spec(spec); spec.loader.exec_module(rel)
R = []
def gate(g, name, ok, note=""): R.append(ok); print(f"{'PASS' if ok else 'FAIL'}  {g:3s} {name}" + (f"  [{note}]" if note else ""))
draft = open(a.draft, encoding="utf-8").read(); out = open(a.release, encoding="utf-8").read()
preview = out.startswith(rel.BANNER); body = out[len(rel.BANNER):] if preview else out
E = rel.edits(a.date, a.decision)
gate("R1", "reviewed draft SHA-256", hashlib.sha256(draft.encode()).hexdigest() == rel.DRAFT_SHA)
t = draft
for i, o, n in E: t = t.replace(o, n, 1)
gate("R2", "release body == metadata transform of the reviewed draft", t == body, "preview" if preview else "release")
r = body
for i, o, n in reversed(E): r = r.replace(n, o, 1)
gate("R3", "reverse transform recovers the reviewed draft byte-exactly", r == draft)
TAG = re.compile(r"`\[(THM|ALG|RESULT|CERT|HYP|CAND|FAIL|RETRACTED|COR|OPEN|DEF|NUM|INTERP|HEUR|DER)\b")
c = lambda s: collections.Counter(TAG.findall(s))
gate("R4", "claim-tag counts identical draft vs release (no scientific change)", c(draft) == c(body))
sci = lambda s: s.split("## Appendix A")[0]
diff_lines = [l for l in set(sci(body).splitlines()) ^ set(sci(draft).splitlines())]
ok5 = all(re.search(r"v2\.8\.6|Date:|Document status|Supersedes|Status summary|^# RTG", l) for l in diff_lines)
gate("R5", "every changed live line is a version/status/metadata line", ok5, f"{len(diff_lines)} lines")
gate("R6", "no 'draft'/'not adopted' marker left in live text", not re.search(r"(?i)v2\.8\.6 draft|not adopted|\(on adoption\)", sci(body)))
gate("R7", "M2c not marked source-verified", "SOURCE VERIFIED" not in body.upper() or "not** marked source-verified" in body)
nf = R.count(False); print(f"{'ALL PASS' if not nf else 'FAILURES'} ({len(R)-nf}/{len(R)})"); sys.exit(1 if nf else 0)
