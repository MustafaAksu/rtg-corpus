#!/usr/bin/env python
"""check_release_v2_8_8.py — proves the v2.8.8 adoption transform is metadata-only.
Usage: python check_release_v2_8_8.py <draft.md> <release_or_preview.md> --date ... --decision ...
A preview (banner present) is checked on the bytes below the banner; R8 then reports the placeholder as expected."""
import sys, re, hashlib, argparse, collections, importlib.util, os
ap = argparse.ArgumentParser(); ap.add_argument("draft"); ap.add_argument("release")
ap.add_argument("--date", required=True); ap.add_argument("--decision", required=True); a = ap.parse_args()
spec = importlib.util.spec_from_file_location("rel", os.path.join(os.path.dirname(os.path.abspath(__file__)), "release_v2_8_8.py"))
rel = importlib.util.module_from_spec(spec); spec.loader.exec_module(rel)
R = []
def gate(g, name, ok, note=""): R.append(bool(ok)); print(f"{'PASS' if ok else 'FAIL'}  {g:3s} {name}" + (f"  [{note}]" if note else ""))
draft = open(a.draft, encoding="utf-8").read(); out = open(a.release, encoding="utf-8").read()
preview = out.startswith(rel.BANNER); body = out[len(rel.BANNER):] if preview else out
E = rel.edits(a.date, a.decision)
gate("R1", "reviewed draft SHA-256", hashlib.sha256(draft.encode()).hexdigest() == rel.DRAFT_SHA)
t = draft
for i, o, n in E: t = t.replace(o, n, 1) if draft.count(o) == 1 else None
gate("R2", f"release body == metadata transform of the reviewed draft ({len(E)} edits, each anchor unique)", t == body, "preview" if preview else "release")
r = body
for i, o, n in reversed(E): r = r.replace(n, o, 1)
gate("R3", "reverse transform recovers the reviewed draft byte-exactly", r == draft)
TAG = re.compile(r"`\[(THM|ALG|RESULT|CERT|HYP|CAND|FAIL|RETRACTED|COR|OPEN|DEF|NUM|INTERP|HEUR|DER)\b")
c = lambda s: collections.Counter(TAG.findall(s))
gate("R4", "claim-tag counts identical draft vs release (no scientific change)", c(draft) == c(body))
sci = lambda s: s.split("## Appendix A")[0]
dl = set(sci(body).splitlines()) ^ set(sci(draft).splitlines())
gate("R5", "every changed live line is a version/status/metadata line", all(re.search(r"v2\.8\.8|Date:|Document status|Supersedes|^# RTG", l) for l in dl), f"{len(dl)} lines")
gate("R6", "no draft/not-adopted/on-adoption marker left in live text", not re.search(r"(?i)v2\.8\.8 draft|v2\.8\.8_DRAFT|not adopted|\(on adoption\)|On adoption,|\(draft\)", sci(body)))
rids = lambda s: sorted(set(re.findall(r"(?:GEN|DYAD|TRIAD)-[A-Z0-9-]*[A-Z0-9]", s)))
NU5 = "- $p=5$: $\\nu_5^{(5)} = \\frac{355-159\\sqrt{5}}{48} + i\\frac{(1106\\sqrt{5}-2473)\\sqrt{10+2\\sqrt{5}}}{48}$ `[RID: DYAD-ALG-NU5-P5]` `[conv: one-step NF, declared K_5 family, frame W_p, resonant h=0]`"
gate("R7", "RID set unchanged; nu5 attribution line intact; Gröbner script still only HISTORICAL / CONFIRMATORY / NOT REPLAYED", rids(draft) == rids(body) and NU5 in body.splitlines()
     and all("NOT REPLAYED" in l and "not a proof input" in l for l in body.splitlines() if "k3_six_step_factor_check" in l))
real = rel.PLACEHOLDER not in a.decision and re.fullmatch(r"\d{1,2} [A-Z][a-z]+ 20\d\d", a.date)
gate("R8", "adoption metadata: real owner decision text and date (release); placeholder only inside a preview",
     (not preview and real and f"**Adoption:** {a.decision}." in body) or (preview and rel.PLACEHOLDER in body), "preview" if preview else "release")
nf = R.count(False); print(f"{'ALL PASS' if not nf else 'FAILURES'} ({len(R)-nf}/{len(R)})"); sys.exit(1 if nf else 0)
