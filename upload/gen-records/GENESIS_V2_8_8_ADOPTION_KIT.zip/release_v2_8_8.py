#!/usr/bin/env python
"""release_v2_8_8.py — metadata-only adoption transform: reviewed v2.8.8 DRAFT -> adopted v2.8.8.
Usage: python release_v2_8_8.py <draft.md> <out.md> --date "<D Month YYYY>" --decision "<owner decision ref>" [--preview]
--preview prepends a one-line non-adoption banner; without it the output is the adopted release.
A non-preview run refuses placeholder decision text."""
import sys, re, hashlib, argparse
DRAFT_SHA = "4dcf0185ab14815e34e06eb35dd52616d74cbf91726ff96e62f616c84923f884"
PACKAGE_SHA = "bea4cd5034be39055266f9da2a7a2cfeaf71e67c57014b0b150f2df7c0cd9ba0"
DYAD_SHA = "5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542"
PLACEHOLDER = "[PENDING OWNER DECISION]"
BANNER = "> **ADOPTION PREVIEW — NOT ADOPTED.** This file shows the exact release bytes below this line; adoption requires the owner decision. Adopted owner remains v2.8.7.\n\n"
def edits(date, decision):
    E = []
    def ed(i, o, n): E.append((i, o, n))
    ed("R-title", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.8_DRAFT\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.8\n")
    ed("R-date", "**Date:** 19 October 2026 (draft)  \n**Document status:** DRAFT owner successor — maintenance (Dyadic v6.4.13 source synchronization; ν₅⁽⁵⁾ point-of-use attribution). **Not adopted**; adopted owner remains v2.8.7 (`d5d1e57c…e361`).  \n",
       f"**Date:** {date}  \n**Document status:** ADOPTED owner ledger — maintenance release (Dyadic v6.4.13 source synchronization; ν₅⁽⁵⁾ point-of-use attribution).  \n")
    ed("R-supersedes", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.7` ·", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.7` ·")
    ed("R-summary", "*(v2.8.8 draft on the adopted v2.8.7 base;", "*(v2.8.8 adopted maintenance release on the v2.8.7 base;")
    ed("R-p11b", "**v2.8.8 draft maintenance:**", "**v2.8.8 maintenance:**")
    ed("R-appA", "### v2.8.8 — 19 October 2026 — DRAFT record (not adopted)\n",
       f"### v2.8.8 — {date} — Adopted maintenance release\n\n**Adoption:** {decision}. Scientific payload is the reviewed DRAFT bytes `{DRAFT_SHA}` (independent receiving review, 19 October 2026: `check_v2_8_8_draft.py --final --dyad --replay` 11/11 PASS, 0 SKIP, against adopted Dyadic v6.4.13 `{DYAD_SHA}`; package `{PACKAGE_SHA}`). The adoption transform `release_v2_8_8.py` changes metadata, status, history and footer only; `check_release_v2_8_8.py` proves it. In force from this release: the live Dyadic pins name v6.4.13 (deferred D5 executed), and M2c is CLOSED at the point of use (`DYAD-ALG-NU5-P5` with its normalization convention; exact certificate Dyadic-owned; Genesis replay [NUM] only). No scientific claim, claim tag or GEN RID changed. Outbound notices (Dyadic N8 RECEIVED with repin executed; RRF/FMS/OFN informational) are issued after adoption.\n\n#### v2.8.8 — DRAFT record, 19 October 2026 — maintenance\n")
    ed("R-foot", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.8_DRAFT*  \n*Draft maintenance successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.7 (not adopted).",
       "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.8*  \n*Adopted maintenance successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.7.")
    return E
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("draft"); ap.add_argument("out")
    ap.add_argument("--date", required=True); ap.add_argument("--decision", required=True); ap.add_argument("--preview", action="store_true")
    a = ap.parse_args()
    if not a.preview:
        assert PLACEHOLDER not in a.decision, "placeholder decision text: run with --preview or give the owner decision"
        assert re.fullmatch(r"\d{1,2} [A-Z][a-z]+ 20\d\d", a.date), "date must look like '19 October 2026'"
    raw = open(a.draft, "rb").read(); assert hashlib.sha256(raw).hexdigest() == DRAFT_SHA, "draft hash mismatch"
    t = raw.decode("utf-8")
    for i, o, n in edits(a.date, a.decision):
        assert t.count(o) == 1, f"{i}: {t.count(o)} matches"; t = t.replace(o, n)
    rel_sha = hashlib.sha256(t.encode()).hexdigest()
    if a.preview: t = BANNER + t
    open(a.out, "w", encoding="utf-8", newline="").write(t)
    print(f"release bytes sha256={rel_sha}" + ("  (written as PREVIEW with banner)" if a.preview else ""))
