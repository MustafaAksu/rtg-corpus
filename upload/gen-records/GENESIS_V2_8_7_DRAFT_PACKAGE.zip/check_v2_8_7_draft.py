#!/usr/bin/env python
"""check_v2_8_7_draft.py — independent gate checker for RTG_GENESIS_GEOMETRY_DSN_v2_8_7_DRAFT.
Gates follow GENESIS_V2_8_7_OWNER_PASS_MANIFEST_v0_1 §4 with the owner decisions of 18 Oct 2026.
Usage:
  python check_v2_8_7_draft.py --base v2_8_6.md --draft v2_8_7_DRAFT.md --build build_v2_8_7_draft.py
         [--scripts DIR] [--final]
--scripts DIR : directory holding kappa_pq_symbolic.py, lemmaS_hand_identities.py, kappa_pq_independent.py
--final       : owner-adoption mode — every SKIP becomes FAIL (kappa_pq_symbolic.py is load-bearing).
Exit 0 iff every executed gate passes (and, with --final, nothing is skipped)."""
import sys, re, os, hashlib, argparse, subprocess, collections, tempfile
ap = argparse.ArgumentParser()
for k in ("base", "draft", "build"): ap.add_argument("--" + k, required=True)
ap.add_argument("--scripts"); ap.add_argument("--final", action="store_true")
a = ap.parse_args()
BASE_SHA = "294c6fc26482d7deae42900cb50b3029ac81e96d66e239bfe8b797e95fdaa269"
SCRIPTS = {"kappa_pq_symbolic.py": ("091a42105cff7965127c55a4a5adffa281021cd71957ed789409de320c5d42b2", "ALL PASS (identity in Q(kappa))"),
           "lemmaS_hand_identities.py": ("af8e79c36f2312c78150c808e5a7a57fc6aeccba9de5355263f5b9c012989674", "ALL PASS (5/5)"),
           "kappa_pq_independent.py": ("7056b077e30ff498b17cf96737a32366305995283de3e332d38654bbfe4aef97", "ALL PASS")}
NEW_RIDS = {"GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA", "GEN-THM-K3-SIXSTEP-FACTOR-NOGO",
            "GEN-DEF-MEANFEEDBACK-FAMILY", "GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO"}
R, SK = [], []
def gate(g, name, ok, note=""):
    R.append((g, bool(ok))); print(f"{'PASS' if ok else 'FAIL'}  {g:4s} {name}" + (f"  [{note}]" if note else ""))
def skip(g, name, why):
    SK.append(g); print(f"SKIP  {g:4s} {name}  [{why}]")
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
base = open(a.base, encoding="utf-8").read(); draft = open(a.draft, encoding="utf-8").read()

# edit list, read from the build script without running its I/O
src = open(a.build, encoding="utf-8").read()
seg = src[src.index("E = []"):src.index("for i, old, new in E:")]
ns = {}; exec(seg, ns); E = ns["E"]
added = {i: (n.replace(o, "", 1) if o in n else n) for i, o, n in E}
new_text = "\n".join(added.values())

# ---- M1: identity and exact reproducibility ----
gate("M1a", "baseline v2.8.6 SHA-256", sha(a.base) == BASE_SHA)
with tempfile.TemporaryDirectory() as td:
    out = os.path.join(td, "d.md")
    r = subprocess.run([sys.executable, "-I", a.build, a.base, out], capture_output=True, text=True)
    gate("M1b", "draft == fresh deterministic build from baseline", r.returncode == 0 and open(out, encoding="utf-8").read() == draft, f"{len(E)} edits")
ok_once = all(base.count(o) == 1 for _, o, _ in E)
rev = draft
for i, o, n in reversed(E): rev = rev.replace(n, o, 1)
gate("M1c", "every anchor occurs once in v2.8.6; reverse edit list recovers v2.8.6 byte-exactly", ok_once and rev == base)

# ---- M2: Dyadic source contract unchanged (D5 deferred) ----
drids = lambda s: set(re.findall(r"DYAD-[A-Z0-9-]*[A-Z0-9]", s))
gate("M2", "DYAD RID set unchanged; pins stay on v6.4.11; no v6.4.12 pointer added",
     drids(base) == drids(draft) and all("D5 deferred" in l for l in new_text.splitlines() if "v6.4.12" in l) and "`RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`" in draft, f"{len(drids(draft))} DYAD RIDs")

# ---- M7: adopted §6.3a, SG-15 and existing K3 entries byte-identical ----
def blk(s):
    i = s.index("### §6.3a Projected-$K_3$ Planar-Factor Obstruction")
    j = s.index("`[INTERP]` Companion contrast", i); j = s.index("\n", j) + 1
    return s[i:j]
sg15 = lambda s: re.search(r"\*\*\[SG-15\]\*\*.*\nViolation:.*\n", s).group(0)
old_lines = [l for l in base.splitlines() if "GEN-THM-K3-PLANAR-FACTOR-NOGO" in l and not l.startswith("- **G-B01")]
gate("M7", "adopted §6.3a block, SG-15 and every existing K3-PLANAR line byte-identical",
     blk(base) == blk(draft) and sg15(base) == sg15(draft) and all(l in draft.splitlines() for l in old_lines),
     f"§6.3a {len(blk(base))} chars; {len(old_lines)} RID lines")

# ---- M8: exactly four new RIDs ----
grids = lambda s: set(re.findall(r"GEN-[A-Z]+-[A-Z0-9-]*[A-Z0-9]", s))
newr = grids(draft) - grids(base)
defs_ok = all(draft.count(f"- [RID: {x}] ::") == 1 for x in NEW_RIDS) and \
          draft.count("`[RID: GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA]`") == 1 and draft.count("`[RID: GEN-DEF-MEANFEEDBACK-FAMILY]`") == 1 and \
          draft.count("`[RID: GEN-THM-K3-SIXSTEP-FACTOR-NOGO]`") == 2 and draft.count("`[RID: GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO]`") == 2
gate("M8", "new GEN RIDs are exactly the four authorized; one §8 entry each; one definition (+§1 line for theorems)",
     newr == NEW_RIDS and defs_ok and "GEN-ALG-MEANFEEDBACK" not in draft and "GEN-OPEN-MEANMODE" not in draft, ",".join(sorted(newr)))

# ---- S1: content, executions, concordance ----
MUST = [r"c_\gamma=\frac{3\gamma^3-7\gamma^2+5\gamma-2}{6(\gamma-2)n}+i\frac{\sqrt3(2\gamma^2-3\gamma+2)}{9n}",
        r"\beta_\gamma=\frac{2\sqrt3(2\gamma^2-3\gamma+2)}{9n}-i\frac{2(\gamma-1)^3}{3(\gamma-2)n}",
        r"n=\gamma^2-\gamma+1", r"\(c_1=c_0\) and \(\beta_1=\beta_*\)",
        r"(H_{\rm spec})\qquad (1-\gamma)^6\notin\operatorname{spec}DT'(E(0))",
        r"(H_{\rm prim})\qquad (1-\gamma)\lambda\notin\operatorname{spec}DT'(E(0))",
        r"A(\pi/2)^{-1}A(\pi/6)=\tfrac12R_{\pi/3}", "**[SG-16]**",
        "049e313e4f07ffe5e576018426a5776aab9b602b0c5c55ef286c71d750babc9e"] + [h for h, _ in SCRIPTS.values()]
miss = [m for m in MUST if m not in draft]
gate("S1a", "formulas, (H_spec)/(H_prim), Lemma S key identity, SG-16 and all pinned hashes present", not miss, "; ".join(m[:30] for m in miss))
if a.scripts:
    for g, nm in (("S1b", "kappa_pq_symbolic.py"), ("S1b'", "lemmaS_hand_identities.py"), ("S1b\"", "kappa_pq_independent.py")):
        p = os.path.join(a.scripts, nm); h, token = SCRIPTS[nm]
        if not os.path.exists(p): skip(g, nm, "file missing"); continue
        if sha(p) != h: gate(g, nm + " hash", False); continue
        r = subprocess.run([sys.executable, "-I", p], capture_output=True, text=True)
        if r.returncode != 0 and "No module named 'sympy'" in r.stderr: skip(g, nm, "sympy not installed"); continue
        gate(g, f"{nm}: hash ok, exit 0, '{token}'", r.returncode == 0 and token in r.stdout)
else:
    skip("S1b", "rerun pinned scripts", "--scripts not given")
try:
    import sympy as sp
    g = sp.symbols("gamma", real=True); s3 = sp.sqrt(3); n = g**2 - g + 1
    p = -(g**2 - 3*g + 1)/(6*n) - sp.I*s3*(2*g**2 - 3*g + 2)/(9*n)                 # v0.3 closed forms
    q = -sp.Rational(2, 3)*(g - 1)**3/((g - 2)*n) - sp.I*2*s3*(2*g**2 - 3*g + 2)/(9*n)
    c = (3*g**3 - 7*g**2 + 5*g - 2)/(6*(g - 2)*n) + sp.I*s3*(2*g**2 - 3*g + 2)/(9*n)  # draft forms
    b = 2*s3*(2*g**2 - 3*g + 2)/(9*n) - sp.I*2*(g - 1)**3/(3*(g - 2)*n)
    z = lambda e: sp.simplify(sp.expand_complex(e)) == 0
    ok = z(c - (p - q)) and z(b - sp.I*q) and z(c.subs(g, 1) - (sp.Rational(1, 6) + sp.I*s3/9)) and z(b.subs(g, 1) - 2*s3/9) \
         and z(sp.im(c - sp.I*b) + s3*(2*g**2 - 3*g + 2)/(9*n))
    gate("S1c", "c_gamma = p-q, beta_gamma = i q identically; gamma=1 gives (c0, beta*); Im(c-i beta) formula", ok)
except ImportError:
    skip("S1c", "sympy concordance", "sympy not installed")

# ---- S2: forbidden overclaims in added text ----
FORBID = [r"\\kappa", "κ",
          r"(six-step|F_1\^6|F_\\gamma\^6)[^.\n]{0,160}\bC\^1\b[^.\n]{0,80}(d=1,3|d=1, 3)",
          r"(six-step|F_1\^6|F_\\gamma\^6)[^.\n]{0,160}(d=1,3|d=1, 3)[^.\n]{0,80}\bC\^1\b",
          r"select(s|ed)? (a |the )?physical (\\\(\\gamma|γ|closure|carrier|node)",
          r"\\gamma\\in\\\{0,2\\\}\\\) (is|are) (covered|excluded)",
          r"tangent to (\\\(\\mathcal D|the mean mode)",
          r"(EF=TE|E\\circ F_1=T'\\circ E)[^.\n]{0,40}(equivalent to|\\iff)"]
NEG = re.compile(r"\b(not|no|neither|nor|without)\b[^.]{0,80}$")
def guarded(text, pos):
    """True if the match is a guard: negated in its sentence, inside a 'Violation:' line,
    or in the 'Forbidden overclaim' column (3rd) of a §5 table row."""
    ls = text.rfind("\n", 0, pos) + 1; line_pre = text[ls:pos]
    if text[ls:].startswith("Violation:"): return True
    if text[ls:].startswith("|") and line_pre.count("|") == 3: return True
    return bool(NEG.search(text[max(ls, pos - 160):pos]))
def valid_only(text):
    """§5 rows: only the 'Valid form' column is a claim; the 'Forbidden overclaim' column is a guard."""
    out = []
    for l in text.splitlines():
        c = l.split("|")
        out.append(c[2] if l.startswith("|") and len(c) >= 6 else l)
    return "\n".join(out)
def hits_in(text):
    text = valid_only(text)
    return [pat for pat in FORBID for m in re.finditer(pat, text) if not guarded(text, m.start())]
hits = hits_in(new_text)
cond = [l for l in new_text.splitlines() if "MEANFEEDBACK-SIXSTEP" in l and "H_spec" not in l and r"H_{\rm spec}" not in l and not l.startswith("*Draft successor")]
ctl = all(hits_in(x) for x in ("This selects a physical closure.",
                                 r"The six-step contract \(E\circ F_1^6=T'\circ E\) gives a \(C^1\) exclusion of d=1,3 factors.",
                                 r"The centre manifold is tangent to \(\mathcal D\).", r"Here \(\kappa\) is the family parameter."))
gate("S2", "no forbidden overclaim; no κ in added text; family theorem always carries (H_spec); negative controls fire",
     not hits and not cond and ctl, ";".join(hits + [c[:40] for c in cond]) or ("" if ctl else "NEGCTL-FAILED"))

# ---- S3: claim-tag audit ----
TAG = re.compile(r"`\[(THM|ALG|RESULT|CERT|HYP|CAND|FAIL|RETRACTED|COR|OPEN|DEF|NUM|INTERP|HEUR|DER)\b")
tags = lambda s: collections.Counter(TAG.findall(s))
CLAIM = {"K1", "HR", "K63", "EXP", "ART"}
loss = [i for i, o, n in E if any(tags(n)[k] < tags(o)[k] for k in tags(o))]
badd = [i for i, o, n in E if (i not in CLAIM and tags(n) != tags(o)) or tags(n)["COR"] > tags(o)["COR"] or tags(n)["RETRACTED"] > tags(o)["RETRACTED"]]
tb, td = tags(base), tags(draft)
gate("S3a", "no edit removes a claim tag", not loss, ",".join(loss))
gate("S3b", "tags added only in authorized G7 edits; no new [COR]/[RETRACTED]", not badd, ",".join(badd))
gate("S3c", "whole-document tag counts non-decreasing", all(td[k] >= tb[k] for k in tb), str({k: td[k] - tb[k] for k in td if td[k] != tb[k]}))

# ---- S4: SESSION boundary ----
S4BAD = ["R4′", "R4'", "Cent_formal", "A1/A2", "lock manifold", "c^6=1", "c⁶ = 1"]
fms_ok = all(("not Genesis-verified" in l or "FMS-reported" in l or "verdicts" in l) for l in new_text.splitlines() if "FMS" in l)
o20_ok = all("Not in this draft" in l for l in new_text.splitlines() if "OPEN 20" in l)
gate("S4", "no FMS SESSION content or OPEN 20 import; FMS only as hash-reporter / excluded verdicts",
     not any(x in new_text for x in S4BAD) and fms_ok and o20_ok)

# ---- S5: Gröbner provenance status ----
gl = [l for l in draft.splitlines() if "k3_six_step_factor_check" in l]
gate("S5", "k3_six_step_factor_check.py only as HISTORICAL / CONFIRMATORY / NOT REPLAYED, never a proof input",
     gl and all("HISTORICAL / CONFIRMATORY / NOT REPLAYED" in l and "not a proof input" in l for l in gl), f"{len(gl)} lines")

ex = [g for g, _ in R]; nf = [g for g, ok in R if not ok]
fail_final = a.final and SK
print(f"{'ALL EXECUTED GATES PASS' if not nf else 'FAILURES: ' + ','.join(nf)} ({len(ex) - len(nf)}/{len(ex)})"
      + (f"; SKIPPED: {','.join(SK)}" if SK else "") + ("  -> FINAL MODE: skips count as FAIL" if fail_final else ""))
sys.exit(1 if (nf or fail_final) else 0)
