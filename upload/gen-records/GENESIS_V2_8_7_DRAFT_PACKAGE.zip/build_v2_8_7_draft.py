#!/usr/bin/env python
"""build_v2_8_7_draft.py — deterministic build of RTG_GENESIS_GEOMETRY_DSN_v2_8_7_DRAFT
from the exact adopted v2.8.6 bytes. Every edit is an exact-match replacement that must occur
exactly once. Control: GENESIS_V2_8_7_OWNER_PASS_MANIFEST_v0_1 (7519e14f...135a) + owner
decisions D1-D7 of 18 Oct 2026 (four new RIDs only; direct primitive spectral condition).
Usage: python build_v2_8_7_draft.py <v2_8_6.md> <out.md>"""
import sys, hashlib
BASE_SHA = "294c6fc26482d7deae42900cb50b3029ac81e96d66e239bfe8b797e95fdaa269"
src, out = sys.argv[1], sys.argv[2]
raw = open(src, "rb").read()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA, "baseline hash mismatch"
t = raw.decode("utf-8")

E = []  # (id, old, new)
def ed(i, old, new): E.append((i, old, new))

V03 = "049e313e4f07ffe5e576018426a5776aab9b602b0c5c55ef286c71d750babc9e"
HS = r"\((H_{\rm spec})\)"
HP = r"\((H_{\rm prim})\)"

# ---------------- header / metadata ----------------
ed("H1", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.6\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.7_DRAFT\n")
ed("H2", "**Date:** 16 October 2026  \n**Document status:** ADOPTED owner ledger — K3 planar-factor theorem + Dyadic v6.4.11 / OFN v0.9 source synchronization.  \n",
   "**Date:** 18 October 2026 (draft)  \n**Document status:** DRAFT owner successor — Stage B (six-step K3 factor theorem, chiral cubic factor lemma, mean-feedback family). **Not adopted**; adopted owner remains v2.8.6 (`294c6fc2…a269`).  \n")
ed("H3", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.5` ·",
   "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.6` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.5` ·")
ed("H4", "*(v2.8.6 adopted release on the v2.8.5 correction/reconciliation base.",
   "*(v2.8.7 draft on the adopted v2.8.6 base; v2.8.6 is itself built on the v2.8.5 correction/reconciliation base.")
ed("H5", "synchronized to adopted Dyadic v6.4.11 and OFN v0.9.\n",
   "synchronized to adopted Dyadic v6.4.11 and OFN v0.9. " + r"**v2.8.7 draft addition:** the projected-\(K_3\) map also has no local \(C^3\) submersive factor of lower real dimension under the six-step contract \(E\circ F_1^6=T'\circ E\), for any \(C^3\) target (§6.3a.1); for the mean-feedback family \(F_\gamma\) (§6.3b) the same holds for \(\gamma\notin\{0,2\}\) under the spectral condition " + HS + r". These are mathematical semiconjugacy exclusions, not a selection of a physical \(\gamma\), closure condition, carrier or node exchange (SG-16)." + "\n")

# ---------------- §1 summary lines ----------------
ed("K1", "Mathematical exclusion only; see §6.3a and SG-15.\n",
   "Mathematical exclusion only; see §6.3a and SG-15.\n\n"
   + r"`[THM]` `[RID: GEN-THM-K3-SIXSTEP-FACTOR-NOGO]` **Projected-\(K_3\) six-step factor obstruction (v2.8.7 draft).** The projected triad map \(F_1=P_{\mathcal C}T^{\times3}\) admits no local \(C^3\) submersive semiconjugacy \(E\circ F_1^6=T'\circ E\) onto any \(C^3\) dynamics \(T'\) of real dimension \(d\in\{1,2,3\}\); no hypothesis is placed on \(T'\). Mathematical exclusion only; see §6.3a.1, SG-15 and SG-16." + "\n\n"
   + r"`[THM]` `[RID: GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO]` **Mean-feedback six-step obstruction (v2.8.7 draft; conditional).** For the mean-feedback family \(F_\gamma\) on \(\mathbb R^6\) (§6.3b), \(\gamma\in\mathbb R\setminus\{0,2\}\), no local \(C^3\) submersive semiconjugacy \(E\circ F_\gamma^6=T'\circ E\) with \(d\in\{1,2,3\}\) exists under " + HS + r": \((1-\gamma)^6\notin\operatorname{spec}DT'(E(0))\). \(\gamma\) is a model parameter, not identified with any physical parameter of this ledger; see SG-16." + "\n")

# ---------------- §3 SG-16 ----------------
ed("SG16", "\n\n---\n\n## §4. Layer Routing {#sec-4-layer-routing}\n",
   "\n\n" + r"**[SG-16]** **Six-step and mean-feedback scope guard (v2.8.7 draft).** `GEN-THM-K3-SIXSTEP-FACTOR-NOGO` and `GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO` concern local \(C^3\) semiconjugacy under the six-step contract \(E\circ F^6=T'\circ E\). The family theorem is cited only together with " + HS + r"; the primitive-clock family statement of §6.3b only with " + HP + r", and " + HS + r" is not transferred to the primitive clock. \(\gamma\) is a model parameter: no physical \(\gamma\), closure condition, carrier, network–dyad bridge or node exchange is selected. \(\gamma\in\{0,2\}\), \(C^1/C^2\) planar factors, primitive-clock \(C^1\) family statements and targets whose spectrum meets the \(\mathcal D\)-spectrum are not covered. The centre manifold \(M^c_\gamma\) is tangent to \(\mathcal C\), not to the mean mode \(\mathcal D\). The cubic-order decoupling of \(|u|^2,|v|^2\) (\(\Im\beta_\gamma=0\)) holds only at \(\gamma=1\), so ER-2B shape-sphere results are not transported to \(\gamma\neq1\). `GEN-THM-K3-PLANAR-FACTOR-NOGO` keeps its adopted scope (SG-15); it is neither widened nor regraded.  " + "\n"
   + r"Violation: Citing the family theorem without " + HS + r"; claiming a six-step exclusion of \(d=1,3\) at \(C^1\); reading \(\gamma\) as a physical parameter or as a selected closure; claiming \(\gamma\in\{0,2\}\) is covered; presenting the centre manifold as tangent to \(\mathcal D\); treating the primitive and six-step contracts as equivalent." + "\n\n---\n\n## §4. Layer Routing {#sec-4-layer-routing}\n")

# ---------------- §5 high-risk rows ----------------
ed("HR", "| Genesis II HYP-B mechanism |",
   r"| Projected-$K_3$ six-step factor | `[THM]`: no local $C^3$ submersive factor under $E\circ F_1^6=T'\circ E$, $d=1,2,3$, any $C^3$ target | $C^1$ six-step exclusion for $d=1,3$; equivalence of primitive and six-step contracts; physical node-exchange or carrier verdict | §6.3a.1, SG-15, SG-16 |" + "\n"
   + r"| Mean-feedback six-step factor | `[THM]` conditional: $F_\gamma$, $\gamma\in\mathbb R\setminus\{0,2\}$, $C^3$, $d=1,2,3$, under $(H_{\rm spec})$ | Statement without $(H_{\rm spec})$; $\gamma\in\{0,2\}$ covered; physical $\gamma$ or closure selected; centre manifold tangent to the mean mode | §6.3b, SG-16 |" + "\n"
   + "| Genesis II HYP-B mechanism |")

# ---------------- §6.3a.1 and §6.3b ----------------
BLOCK = r"""#### §6.3a.1 Six-Step Clock `[THM]` (v2.8.7 draft) {#sec-6-3a-1-six-step}

> **[SG-15 applies]** **[SG-16 applies]** *(v2.8.7 draft; source: `K3_KAPPA_SIX_STEP_CLOCK_NOTE_v0_3.md`, accepted for owner review 18 Oct 2026. The adopted statement and proof of §6.3a above are unchanged; this block treats a second contract, \(E\circ F_1^6=T'\circ E\).)*

`[THM]` `[RID: GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA]` `[scope: real-linear factors of a homogeneous chiral cubic; branch c-i beta != 0, beta != 0]` **Chiral cubic factor lemma (Lemma S).** On \(\mathbb C^2\cong\mathbb R^4\) let
\[
f(u,v)=\bigl(c\,u|u|^2-i\beta Nu,\;c\,v|v|^2-i\beta Nv\bigr),\qquad N=|u|^2+|v|^2,
\]
with \(c,\beta\in\mathbb C\), \(c-i\beta\neq0\) and \(\beta\neq0\). Then no real-linear surjection \(\ell:\mathbb R^4\to\mathbb R^d\), \(d\in\{1,2,3\}\), satisfies \(\ell\circ f=t\circ\ell\) for a \(C^1\) map \(t\).

*Proof.* Write \(\mathbb C_u=\mathbb C\oplus0\), \(\mathbb C_v=0\oplus\mathbb C\), \(P_\alpha\) for the orthogonal projection of \(\mathbb C\cong\mathbb R^2\) onto \(\mathbb Re^{i\alpha}\), and \(A(\alpha)=P_\alpha-P_0\).
- **(i) Invariant kernel.** Differentiating gives \(\ell\,Df(x)=Dt(\ell x)\,\ell\), so \(K=\ker\ell\) is a proper nonzero real subspace with \(Df(x)K\subseteq K\) for every \(x\).
- **(ii) Axis Jacobians.** \(Df(e^{i\alpha},0)=\operatorname{diag}\bigl((c-i\beta)(I+2P_\alpha),\,-i\beta\bigr)\), so \(Df(e^{i\alpha},0)-Df(1,0)=\operatorname{diag}\bigl(2(c-i\beta)A(\alpha),\,0\bigr)\). For \(\alpha\notin\pi\mathbb Z\), \(A(\alpha)\) is invertible (\(\det A(\alpha)=-\sin^2\alpha\)). These operators map \(K\) into \(K\cap\mathbb C_u\); hence \(K\cap\mathbb C_u=0\) forces \(K\subseteq\mathbb C_v\). By the \(u\leftrightarrow v\) symmetry, \(K\cap\mathbb C_v=0\) forces \(K\subseteq\mathbb C_u\).
- **(iii) No invariant line.** If \(L=K\cap\mathbb C_u\) is a real line, every \(2(c-i\beta)A(\alpha)\) with \(\alpha\notin\pi\mathbb Z\) fixes \(L\), hence so does \(A(\pi/2)^{-1}A(\pi/6)=\tfrac12R_{\pi/3}\) (the complex scalar cancels). A rotation by \(\pi/3\) has no real eigenline. So \(K\cap\mathbb C_u\in\{0,\mathbb C_u\}\), and likewise \(K\cap\mathbb C_v\in\{0,\mathbb C_v\}\).
- **(iv) Cases.** By (ii)–(iii), \(K=0\), \(K=\mathbb R^4\), \(K=\mathbb C_u\oplus0\) or \(K=0\oplus\mathbb C_v\). The first two are excluded because \(K\) is proper and nonzero. The \(v\)-block of \(Df(1,1)(h,0)\) and the \(u\)-block of \(Df(1,1)(0,h)\) both equal \(-2i\beta\,\Re h\), so \(\beta\neq0\) excludes the last two. \(\square\)

The lemma is sharp: for \(\beta=0\), \(\ell=\) projection to \(u\) is a factor with \(t(u)=c\,u|u|^2\).

`[THM]` `[RID: GEN-THM-K3-SIXSTEP-FACTOR-NOGO]` `[scope: named projected-K3 model on C; six-step contract E F_1^6 = T' E; local germs at 0; C^3, d=1,2,3]` Let \(E\) be a \(C^3\) submersion from a neighbourhood of \(0\in\mathcal C\) onto a manifold of real dimension \(d\in\{1,2,3\}\), and let \(T'\) be \(C^3\) with \(E\circ F_1^6=T'\circ E\) near \(0\). Then no such pair exists. No hypothesis is placed on the fixed point, linearization or cubic coefficients of \(T'\).

*Proof.*
- **(a) Linear part.** \(\ell=DE(0)\) is surjective and \(\ell\,DF_1^6(0)=DT'(E(0))\,\ell\). Since \(DF_1^6(0)=\lambda^6=I\), \(DT'(E(0))=I\).
- **(b) No quadratic terms.** By §6.3a(b), \(F_1^6=\mathrm{id}+f_3+O(4)\). The degree-2 part of \(E\circ F_1^6=T'\circ E\) gives \(t_2\circ\ell=0\), so \(t_2=0\).
- **(c) Cubic identity.** At degree 3 the \(E_2\) and \(E_3\) terms cancel (\(E_2(x+f_3)-E_2(x)=O(|x|^4)\)), leaving \(\ell\circ f_3=t_3\circ\ell\).
- **(d) Elimination.** By §6.3a(d), in the chiral coordinates \(u,v\) the cubic \(f_3\) has the form of Lemma S with \((c,\beta)=(c_0,\beta_*)\), where \(c_0-i\beta_*=\tfrac16-i\tfrac{\sqrt3}{9}\neq0\) and \(\beta_*\neq0\). Lemma S excludes every \(d\). \(\square\)

`[ALG]` **Relation to the primitive clock.** A primitive factor \(E\circ F_1=T'\circ E\) induces \(E\circ F_1^6=T'^6\circ E\), so this theorem re-excludes primitive factors at \(C^3\). The adopted \(C^1\) statement for \(d=1,3\) (§6.3a) is stronger and remains the primitive-clock reference. The two contracts are not made equivalent (SG-15).

`[DEF]` **Evidence.** Proof: K3-6S v0.3 §2.2 and §3.1 (`""" + V03 + r"""`). Audit of the identities in Lemma S (ii)–(iv), written there as \(p=c-i\beta\), \(q=-i\beta\): `lemmaS_hand_identities.py` (`af8e79c36f2312c78150c808e5a7a57fc6aeccba9de5355263f5b9c012989674`), 5/5 PASS, independently rerun. Corroboration at sample points: `lemmaS_burnside_check.py` (`2429212d0c8d38c240a03bac66b8157c687697348c9187f596a0dbc71cb6ea9d`; generated algebra \(M_4(\mathbb R)\); \(\beta=0\) control of dimension 8). The branch \(c-i\beta=0\) is not stated here; `k3_six_step_factor_check.py` (`7d761090378781c5c74ec64abc1f215cc951cec21f139a231ee1bd8ed18ad4ff`, hash as reported by FMS v0.5.1, not Genesis-verified) is HISTORICAL / CONFIRMATORY / NOT REPLAYED and is not a proof input.

### §6.3b Mean-Feedback Triad Family `[DEF / ALG / THM]` (v2.8.7 draft) {#sec-6-3b-mean-feedback}

> **[SG-15 applies]** **[SG-16 applies]** *(v2.8.7 draft; source: K3-6S v0.3 §1 and §3.2–§3.4. The source writes the family parameter with a different letter; the concordance is in the v2.8.7 occurrence disposition.)*

`[DEF]` `[RID: GEN-DEF-MEANFEEDBACK-FAMILY]` **Model.** For \(\gamma\in\mathbb R\), \(F_\gamma\) acts on \(\mathbb R^6\cong\mathbb C^3\) (edges \(w_e\) in the eigenframe of §6.3a) by
\[
(F_\gamma w)_e=T(w_e)-\tfrac{\gamma}{3}\textstyle\sum_{j}T(w_j),\qquad e=1,2,3.
\]
\(\mathcal C=\{\sum_ew_e=0\}\) is the carrier of §6.3a and \(\mathcal D=\{w_1=w_2=w_3\}\) is the mean mode. \(DF_\gamma(0)\) is multiplication by \(\lambda\) on \(\mathcal C\) and by \((1-\gamma)\lambda\) on \(\mathcal D\). For \(\gamma=1\), \(F_1\) maps \(\mathbb R^6\) into \(\mathcal C\), and its restriction to \(\mathcal C\) is the §6.3a model. \(\gamma\) is a model parameter, not identified with any physical parameter of this ledger (SG-16).

`[ALG]` **Centre manifold and exact six-step cubic.** For \(\gamma\in\mathbb R\setminus\{0,2\}\), \(|1-\gamma|\neq1\), so there is a local \(C^3\) centre manifold \(M^c_\gamma\), a graph over \(\mathcal C\) tangent to \(\mathcal C\) (not to \(\mathcal D\)). Its Taylor coefficients are fixed by the homological equation; their denominators \(\lambda^m-(1-\gamma)\lambda\) vanish for real \(\gamma\) only at \(\gamma=2\) (degree 2) and \(\gamma=0\) (degree 3). On \(M^c_\gamma\), \(F_\gamma^6=\mathrm{id}+f_\gamma+O(4)\) has no quadratic part and, in the chiral coordinates of §6.3a,
\[
u(f_\gamma)=c_\gamma u|u|^2-i\beta_\gamma Nu,\qquad v(f_\gamma)=c_\gamma v|v|^2-i\beta_\gamma Nv,
\]
\[
c_\gamma=\frac{3\gamma^3-7\gamma^2+5\gamma-2}{6(\gamma-2)n}+i\frac{\sqrt3(2\gamma^2-3\gamma+2)}{9n},\qquad
\beta_\gamma=\frac{2\sqrt3(2\gamma^2-3\gamma+2)}{9n}-i\frac{2(\gamma-1)^3}{3(\gamma-2)n},\qquad n=\gamma^2-\gamma+1 .
\]
These hold as identities in \(\mathbb Q(\gamma)(i\sqrt3)\), not only at sample points. \(c_1=c_0\) and \(\beta_1=\beta_*\). Since \(2\gamma^2-3\gamma+2>0\) and \(n>0\): \(\Re\beta_\gamma>0\) and \(\Im(c_\gamma-i\beta_\gamma)=-\sqrt3(2\gamma^2-3\gamma+2)/(9n)\neq0\). Hence Lemma S applies for every \(\gamma\in\mathbb R\setminus\{0,2\}\).

`[THM]` `[RID: GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO]` `[scope: F_gamma on R^6, gamma in R minus {0,2}; six-step contract; local germs at 0; C^3, d=1,2,3; conditional on (H_spec)]` Let \(E\) be a \(C^3\) submersion from a neighbourhood of \(0\in\mathbb R^6\) onto a manifold of real dimension \(d\in\{1,2,3\}\), and let \(T'\) be \(C^3\) with \(E\circ F_\gamma^6=T'\circ E\) near \(0\). Assume
\[
(H_{\rm spec})\qquad (1-\gamma)^6\notin\operatorname{spec}DT'(E(0)).
\]
Then no such pair exists.

*Proof.*
- **(a) Mean mode in the kernel.** \(DF_\gamma^6(0)=I\) on \(\mathcal C\) and \((1-\gamma)^6I\) on \(\mathcal D\). For \(x\in\mathcal D\), \(\bigl(DT'(E(0))-(1-\gamma)^6\bigr)\ell x=0\), so \((H_{\rm spec})\) gives \(\mathcal D\subseteq\ker\ell\).
- **(b) Reduction.** \(M^c_\gamma\) is locally \(F_\gamma\)-invariant and \(C^3\) with \(T_0M^c_\gamma=\mathcal C\). Since \(\ell\) is onto and \(\mathcal D\subseteq\ker\ell\), \(\ell|_{\mathcal C}\) is onto. So \(E|_{M^c_\gamma}\) is a \(C^3\) submersion with \(E|_{M^c_\gamma}\circ F_\gamma^6|_{M^c_\gamma}=T'\circ E|_{M^c_\gamma}\).
- **(c) Cubic elimination.** Steps (a)–(c) of §6.3a.1 apply on \(M^c_\gamma\) with cubic \(f_\gamma\); Lemma S with \((c,\beta)=(c_\gamma,\beta_\gamma)\) excludes every \(d\). \(\square\)

`[ALG]` **Sufficient forms of \((H_{\rm spec})\).** The spectrum of \(DT'(E(0))\) lies on the unit circle (then \(|1-\gamma|^6\neq1\) for \(\gamma\notin\{0,2\}\)); in particular \(T'=T^6\), with \(DT^6(0)=I\). At \(\gamma=1\), \((H_{\rm spec})\) says that \(DT'(E(0))\) is invertible.

`[ALG]` **\((H_{\rm spec})\) cannot be dropped.** At \(\gamma=1\), \(E(w)=\sum_ew_e\) is a submersion \(\mathbb R^6\to\mathbb R^2\) with \(E\circ F_1=0\); hence \(E\circ F_1^6=T'\circ E\) with \(T'\equiv0\), and \((1-\gamma)^6=0\in\operatorname{spec}(0)\).

`[ALG]` **Primitive clock (\(C^3\) only).** For \(\gamma\in\mathbb R\setminus\{0,2\}\) there is no local \(C^3\) submersive semiconjugacy \(E\circ F_\gamma=T'\circ E\) with \(d\in\{1,2,3\}\) under the direct condition
\[
(H_{\rm prim})\qquad (1-\gamma)\lambda\notin\operatorname{spec}DT'(E(0)).
\]
(i) \(DF_\gamma(0)|_{\mathcal D}\) has spectrum \(\{(1-\gamma)\lambda,(1-\gamma)\bar\lambda\}\); \(B=DT'(E(0))\) is real, so \((H_{\rm prim})\) excludes both, and the intertwining \(\ell|_{\mathcal D}DF_\gamma(0)|_{\mathcal D}=B\,\ell|_{\mathcal D}\) forces \(\ell|_{\mathcal D}=0\). (ii) \(\ell|_{\mathcal C}\) is onto and \(\ell|_{\mathcal C}\lambda=B\,\ell|_{\mathcal C}\), so \(B\) is induced by multiplication by \(\lambda\) on a quotient of \(\mathcal C\) and \(B^6=I\). (iii) On \(M^c_\gamma\), \(E\circ F_\gamma^6=T'^6\circ E\) with \(DT'^6(E(0))=I\); steps (b)–(c) of §6.3a.1 and Lemma S apply. \((H_{\rm spec})\) is not used and is not implied: \((H_{\rm prim})\) does not imply \((1-\gamma)^6\notin\operatorname{spec}(B^6)\) in general. No \(C^1\) statement is made for the family.

`[OPEN]` Factors whose target spectrum meets the \(\mathcal D\)-spectrum for \(\gamma\neq1\); \(\gamma\in\{0,2\}\); planar factors at \(C^1/C^2\) at both clocks; primitive-clock \(C^1\) statements for the family; non-submersive or non-local factor maps; other network dynamics; any physical selection of \(\gamma\) or of a closure condition (OFN/RRF).

`[DEF]` **Evidence.** Proof: K3-6S v0.3 §1.2–§1.3, §3.2–§3.4 (`""" + V03 + r"""`). Exact cubic data (load-bearing): `kappa_pq_symbolic.py` (`091a42105cff7965127c55a4a5adffa281021cd71957ed789409de320c5d42b2`), identities in \(\mathbb Q(\gamma)(i\sqrt3)\), independently rerun 18 Oct 2026, PASS. Cross-checks: `kappa_pq_independent.py` (`7056b077e30ff498b17cf96737a32366305995283de3e332d38654bbfe4aef97`; own second- and third-order centre manifold, both chiral components, five exact sample points) and `exact_q.py` (`44105683b5da2b57fa9dfbd2f9e05488107c560f7b7fae7ab88b6ae24d4a6001`; independent derivation, PI rerun). The source scripts use the coefficients \(p=c_\gamma-i\beta_\gamma\), \(q=-i\beta_\gamma\).

### §6.4 Tetrahedral Jacobi Modes and Chronological Protection `[THM / mixed]` {#sec-6-4-tetrahedral}
"""
ed("K63", "\n### §6.4 Tetrahedral Jacobi Modes and Chronological Protection `[THM / mixed]` {#sec-6-4-tetrahedral}\n", "\n" + BLOCK)

# ---------------- §7 export ----------------
ed("EXP", "a carrier, or a physical node-exchange action (SG-15).\n",
   "a carrier, or a physical node-exchange action (SG-15).\n\n"
   + r"`[DEF]` **(v2.8.7 draft) RRF G2-CLOCK six-step export.** On adoption, Genesis exports `GEN-THM-K3-SIXSTEP-FACTOR-NOGO`: the raw projected-\(K_3\) map has no local \(C^3\) submersive factor under the six-step contract \(E\circ F_1^6=T'\circ E\), for target dimension \(1\)–\(3\) and any \(C^3\) target. `GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO` is exported only together with " + HS + r", for \(\gamma\notin\{0,2\}\). RRF may cite both without repeating the proofs. Genesis does not select RRF's physical admissibility condition, a carrier, a closure condition, a physical \(\gamma\) or a node-exchange action (SG-15, SG-16). The export of `GEN-THM-K3-PLANAR-FACTOR-NOGO` is unchanged." + "\n")

# ---------------- §8 registry ----------------
ed("ART", "historical coefficient source `ER2B_OBSERVABLE_RESPONSE_v1.zip` (`06d5e0c9…82b1`)\n",
   "historical coefficient source `ER2B_OBSERVABLE_RESPONSE_v1.zip` (`06d5e0c9…82b1`)\n"
   + r"- [RID: GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA] :: chiral cubic factor lemma (Lemma S), branch \(c-i\beta\neq0\), \(\beta\neq0\) (v2.8.7 draft) :: `[THM]` `[scope: §6.3a.1]` — proof: §6.3a.1 / K3-6S v0.3 §2.2 (`049e313e…bc9e`); audit `lemmaS_hand_identities.py` (`af8e79c3…9674`, 5/5 PASS); corroboration `lemmaS_burnside_check.py` (`2429212d…a9d`); `k3_six_step_factor_check.py` (`7d761090…d4ff`, FMS-reported hash) HISTORICAL / CONFIRMATORY / NOT REPLAYED, not a proof input" + "\n"
   + r"- [RID: GEN-THM-K3-SIXSTEP-FACTOR-NOGO] :: projected-\(K_3\) six-step factor obstruction (v2.8.7 draft) :: `[THM]` `[scope: §6.3a.1]` — proof: §6.3a.1 / K3-6S v0.3 §3.1 (`049e313e…bc9e`); source cubic: §6.3a(d) and `k3_obstruction_exact_check.py` (`384aaa5f…01ee`)" + "\n"
   + r"- [RID: GEN-DEF-MEANFEEDBACK-FAMILY] :: mean-feedback triad family \(F_\gamma\) on \(\mathbb R^6\) (v2.8.7 draft) :: `[DEF]` `[scope: §6.3b]` — source: K3-6S v0.3 §1.1 (`049e313e…bc9e`)" + "\n"
   + r"- [RID: GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO] :: mean-feedback six-step obstruction (v2.8.7 draft) :: `[THM]` `[scope: §6.3b; conditional on (H_{\rm spec})]` — proof: §6.3b / K3-6S v0.3 §3.2 (`049e313e…bc9e`); exact cubic data `kappa_pq_symbolic.py` (`091a4210…42b2`, load-bearing, PASS); cross-checks `kappa_pq_independent.py` (`7056b077…ef97`), `exact_q.py` (`44105683…6001`)" + "\n")

# ---------------- Appendix A ----------------
ed("APPA", "## Appendix A — Version History {#appendix-a}\n\n",
   "## Appendix A — Version History {#appendix-a}\n\n"
   + r"""### v2.8.7 — 18 October 2026 — DRAFT record (not adopted)

Built deterministically from the exact adopted v2.8.6 bytes (`294c6fc2…a269`) by `build_v2_8_7_draft.py`. Control: owner-pass manifest v0.1 (`7519e14f…135a`) and owner decisions D1–D7 of 18 Oct 2026, with the two owner record corrections (four new RIDs only; direct primitive-clock spectral condition).

- **G7-01:** chiral cubic factor lemma `GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA` (§6.3a.1).
- **G7-02:** `GEN-THM-K3-SIXSTEP-FACTOR-NOGO` (§6.3a.1), with entries in §1, §5, §7 and §8.
- **G7-03:** new §6.3b: `GEN-DEF-MEANFEEDBACK-FAMILY`; exact cubic data \((c_\gamma,\beta_\gamma)\) without a separate RID; `GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO` under \((H_{\rm spec})\); primitive-clock family statement at \(C^3\) under \((H_{\rm prim})\).
- **G7-04:** SG-16. **G7-05:** §7 six-step export line. **G7-06:** provenance in §6.3a.1, §6.3b and §8.
- The adopted §6.3a and SG-15 are byte-identical; `GEN-THM-K3-PLANAR-FACTOR-NOGO` is neither widened nor regraded.
- **Not in this draft:** Dyadic v6.4.12.1 repin (D5 deferred; pins stay on v6.4.11); physical \(\gamma\) selection; OPEN-B/E1; Dyadic OPEN 20; FMS model-selection verdicts; V20-O1–O5; Candidates A–C; `Q-SUCC-UV-01`. M2c is unchanged.
- **No v2.8.6 claim corrected, regraded or retracted.**

""")

# ---------------- footer ----------------
ed("FOOT", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.6*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.5.",
   "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.7_DRAFT*  \n*Draft successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.6 (not adopted). v2.8.7 adds GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA, GEN-THM-K3-SIXSTEP-FACTOR-NOGO, GEN-DEF-MEANFEEDBACK-FAMILY, GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO and SG-16 only. Inherited v2.8.6 footer follows:*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.5.")

for i, old, new in E:
    n = t.count(old)
    assert n == 1, f"{i}: expected 1 match, found {n}"
    t = t.replace(old, new)
open(out, "w", encoding="utf-8", newline="").write(t)
print(f"applied {len(E)} edits -> {out}  sha256={hashlib.sha256(t.encode()).hexdigest()}")
