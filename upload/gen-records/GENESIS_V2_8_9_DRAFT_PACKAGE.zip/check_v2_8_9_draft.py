#!/usr/bin/env python
"""check_v2_8_9_draft.py — independent gate checker for RTG_GENESIS_GEOMETRY_DSN_v2_8_9_DRAFT (D-4 scientific successor).
Gates follow the occurrence disposition plan v0.1 §5 (DM1-DM7, S1, S3) and the owner decisions of 19 Oct 2026:
  M1  (DM1) baseline identity; draft == fresh deterministic build; anchors unique; reverse edit list recovers v2.8.8
  M2  (DM2) §6.3a-§6.3b block, SG-15, SG-16 and the five existing K3/6S RID lines byte-identical
  M3  (DM3) §6.3c cites Lemma S with c=p-q, beta=iq, branch condition; mu != 0 stated as hypothesis; n_T and mu_6 printed
  M4  (DM4) primitive companion is [ALG] without RID, proved by the direct primitive argument; (H_prim) not equated
            with (H_spec); the new RID sits only on six-step [THM] lines; export does not export the primitive companion
  M5  (DM5) guards G-JET, G-20, G-SEL, G-OFN present at point of use; forbidden selection/existence phrases absent
  M6  (DM6) certificate hash + rerun 6/6 PASS (needs --cert; SKIP counts as FAIL in --final)
  M7  (DM7) DYAD RID set unchanged; no Dyadic generator/centralizer/realization RID; no OFN/FMS identifier added
  S1  GEN RID delta == {GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO}; claim-tag delta == declared delta (frozen draft)
  S3  every edit authorised by an independent rule; each authorised ID used exactly once
Usage: python check_v2_8_9_draft.py --base v2_8_8.md --draft v2_8_9_DRAFT.md --build build_v2_8_9_draft.py
                                    [--cert d4_transported_cubic_cert.py] [--final]"""
import sys, re, os, hashlib, argparse, subprocess, tempfile, collections
ap = argparse.ArgumentParser()
for x in ("base", "draft", "build"): ap.add_argument("--" + x, required=True)
ap.add_argument("--cert"); ap.add_argument("--final", action="store_true")
a = ap.parse_args()
BASE_SHA = "9abd36169a4bf6056318605c0399ff1f91c53f157b9181bdbfdb9faed3000f37"
CERT_SHA = "f4c382855b130249ce290d3ca939b283aadd27d6ea9a1af551599f4cd9533f6d"
NEW = "GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO"
LEMMA = "GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA"
FROZEN_RIDS = ["GEN-THM-K3-PLANAR-FACTOR-NOGO", "GEN-THM-K3-SIXSTEP-FACTOR-NOGO", "GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO",
               LEMMA, "GEN-DEF-MEANFEEDBACK-FAMILY"]
FORBIDDEN_DYAD = ["DYAD-THM-FORMAL-Z6-GENERATOR", "DYAD-CAND-FLAT-CENTRALIZER", "DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES",
                  "DYAD-THM-FORMAL-CENTRALIZER", "DYAD-THM-FORMAL-INVOLUTION-UNIQUE", "DYAD-ALG-CENT-KERNEL",
                  "DYAD-THM-ANALYTIC-CLOCK-BRIDGE", "DYAD-OPEN-INVOLUTION-REALIZATION"]
DECLARED_TAG_DELTA = {"THM": 4, "ALG": 3, "DEF": 4, "OPEN": 1}   # fixed on the frozen draft (disposition §3)
R, SK = [], []
def gate(g, name, ok, note=""): R.append((g, bool(ok))); print(f"{'PASS' if ok else 'FAIL'}  {g:4s} {name}" + (f"  [{note}]" if note else ""))
def skip(g, name, why): SK.append(g); print(f"SKIP  {g:4s} {name}  [{why}]")
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
base = open(a.base, encoding="utf-8").read(); draft = open(a.draft, encoding="utf-8").read()
src = open(a.build, encoding="utf-8").read()
ns = {"t": base}; exec(src[src.index("E = []"):src.index("for i, old, new in E:")], ns); E = ns["E"]
TAG = re.compile(r"`\[(THM|ALG|RESULT|CERT|HYP|CAND|FAIL|RETRACTED|COR|OPEN|DEF|NUM|INTERP|HEUR|DER)\b")

# ---------- M1 ----------
gate("M1a", "baseline v2.8.8 SHA-256", sha(a.base) == BASE_SHA)
with tempfile.TemporaryDirectory() as td:
    out = os.path.join(td, "d.md"); r = subprocess.run([sys.executable, "-I", a.build, a.base, out], capture_output=True, text=True)
    gate("M1b", "draft == fresh deterministic build", r.returncode == 0 and open(out, encoding="utf-8").read() == draft, f"{len(E)} edits")
rev = draft
for i, o, n in reversed(E): rev = rev.replace(n, o, 1)
gate("M1c", "each anchor occurs once in v2.8.8; reverse edit list recovers v2.8.8 byte-exactly",
     all(base.count(o) == 1 for _, o, _ in E) and rev == base)

# ---------- M2 ----------
blk_b = base[base.index("### §6.3a Projected-$K_3$"):base.index("### §6.4 Tetrahedral")]
try: blk_d = draft[draft.index("### §6.3a Projected-$K_3$"):draft.index("### §6.3c Transported")]
except ValueError: blk_d = None
sg = lambda s, k: re.search(r"\*\*\[SG-%d\]\*\*.*\n" % k, s).group(0)
rid_lines = [l for l in base.splitlines() if any(x in l for x in FROZEN_RIDS)]
dl = draft.splitlines()
gate("M2", "§6.3a/§6.3a.1/§6.3b, SG-15, SG-16 and every v2.8.8 line carrying the five K3/6S RIDs byte-identical",
     blk_b == blk_d and sg(base, 15) == sg(draft, 15) and sg(base, 16) == sg(draft, 16) and all(l in dl for l in rid_lines),
     f"{len(blk_b)} chars; {len(rid_lines)} RID lines")

# ---------- §6.3c extraction ----------
try: S = draft[draft.index("### §6.3c Transported"):draft.index("### §6.4 Tetrahedral")]
except ValueError: S = ""
paras = S.split("\n\n")
prim = next((p for p in paras if "**Primitive clock" in p), "")
thm = next((p for p in paras if f"[RID: {NEW}]" in p), "")

# ---------- M3 ----------
need3 = [f"`{LEMMA}`", r"c=p-q", r"\beta=iq", r"p=\mu/3", r"q=2\mu/3", r"c-i\beta=p\neq0", r"\beta\neq0",
         r"**(H-\(\mu\))** \(\mu:=6\bar\lambda n\neq0\)", r"\gamma\in\mathbb R\setminus\{0,2\}", r"(H_{\rm spec})",
         r"n=n_T=\tfrac18-\tfrac{7i\sqrt3}{72}", r"6\bar\lambda n_T=\mu_6=-\tfrac12-\tfrac{2i\sqrt3}{3}", "adopted branch, without extension"]
miss3 = [x for x in need3 if x not in S]
gate("M3", "§6.3c: Lemma S dependency with c=p-q, beta=iq, branch; (H-mu) explicit hypothesis; n_T and mu_6 printed",
     S and thm and not miss3, ";".join(miss3))

# ---------- M4 ----------
prim_ok = (prim.startswith("`[ALG]` **Primitive clock") and "[RID:" not in prim and "no RID" in prim and "`[THM]`" not in prim
           and r"(H_{\rm prim})" in prim and "direct primitive-clock argument of §6.3b" in prim
           and "is **not** invoked" in prim and "neither is a corollary of the other" in prim
           and r"\((H_{\rm prim})\) does not imply \((1-\gamma)^6\notin\operatorname{spec}(B^6)\)" in prim
           and r"\((H_{\rm spec})\) is not used." in prim)
bad_equate = [x for x in [r"(H_{\rm prim})\) implies \((H_{\rm spec})", r"(H_{\rm prim})\) implies \((1-\gamma)^6",
                          "follows from the theorem above", "corollary of the six-step theorem", "by the six-step theorem"]
              if x in S]
new_rid_lines = [l for l in dl if f"[RID: {NEW}]" in l]
rid_ok = len(new_rid_lines) == 3 and all("`[THM]`" in l and "Primitive" not in l and "primitive-clock" not in l.split("::")[0] for l in new_rid_lines)
exp = next((l for l in dl if "**(v2.8.9) Transported six-step export.**" in l), "")
exp_ok = "is **not** exported as a theorem" in exp and "(H_{\\rm spec})" in exp
gate("M4", "primitive companion [ALG], no RID, direct primitive argument; (H_prim) not equated with (H_spec); new RID only on six-step [THM]; not exported",
     prim_ok and not bad_equate and rid_ok and exp_ok, ";".join(bad_equate) + f" rid_lines={len(new_rid_lines)}")

# ---------- M5 ----------
GUARDS = ["**G-JET.**", "**G-20.**", "**G-SEL.**", "**G-OFN.**", "existence of such a \\(\\Phi\\) is not asserted here.",
          "no statement is made about a formal power-series map as such", "does not imply uniqueness of any model class",
          "not a choice of physical network representation", "require separate proof"]
FORBID = ["unique physical model", "selects model C", "model C is selected", "J exists", "physical realization is established",
          "only possible model", "the physical model is"]
added = "".join(n for _, o, n in E)
gmiss = [g for g in GUARDS if g not in S]; fbad = [f for f in FORBID if f.lower() in added.lower()]
gate("M5", "guards G-JET/G-20/G-SEL/G-OFN at point of use; forbidden selection/existence phrases absent from added text",
     not gmiss and not fbad, ";".join(gmiss + fbad))

# ---------- M6 ----------
if a.cert:
    ok = sha(a.cert) == CERT_SHA
    if ok:
        r = subprocess.run([sys.executable, "-I", a.cert], capture_output=True, text=True)
        ok = r.returncode == 0 and "6/6 gates PASS" in r.stdout and not r.stderr.strip()
    gate("M6", "d4_transported_cubic_cert.py hash + rerun 6/6 PASS, empty stderr", ok)
else:
    skip("M6", "certificate rerun", "--cert not given")

# ---------- M7 ----------
drids = lambda s: set(re.findall(r"DYAD-[A-Z0-9-]*[A-Z0-9]", s))
ofn = lambda s: collections.Counter(re.findall(r"(?:RTG-OFN|OFN|FMS)-[A-Z0-9][A-Z0-9-]*", s))
gate("M7", "DYAD RID set unchanged; no Dyadic generator/centralizer/realization RID; no OFN/FMS identifier added",
     drids(draft) == drids(base) and not any(x in draft for x in FORBIDDEN_DYAD) and ofn(draft) == ofn(base),
     f"{len(drids(draft))} DYAD RIDs")

# ---------- S1 ----------
tags = lambda s: collections.Counter(TAG.findall(s))
grids = lambda s: set(re.findall(r"GEN-[A-Z]+-[A-Z0-9-]*[A-Z0-9]", s))
delta = {k: tags(draft)[k] - tags(base)[k] for k in set(tags(base)) | set(tags(draft)) if tags(draft)[k] != tags(base)[k]}
gate("S1", "GEN RID delta == {new RID}; claim-tag delta == declared", grids(draft) - grids(base) == {NEW} and grids(base) <= grids(draft)
     and delta == DECLARED_TAG_DELTA, str(delta))

# ---------- S3 ----------
def app(o, n): return n[len(o):] if n.startswith(o) else None
def rule(i, o, n):
    if i == "H1": return o == "# RTG_GENESIS_GEOMETRY_DSN_v2.8.8\n" and n == "# RTG_GENESIS_GEOMETRY_DSN_v2.8.9_DRAFT\n"
    if i == "H2": return n.startswith("**Date:** 19 October 2026 (draft)  \n**Document status:** DRAFT owner successor — scientific") and "**Not adopted**" in n and not TAG.search(n)
    if i == "H3": return n == o.replace("**Supersedes:** ", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.8` · ")
    if i == "P11":
        x = n[len(o) - 1:] if n.startswith(o[:-1]) else ""
        return x.startswith(" **v2.8.9 draft addition:**") and x.count(NEW) == 1 and not TAG.search(x) and grids(x) == {NEW} \
            and "no physical model, carrier, closure condition or" in x and "is not asserted" in x
    if i == "C1":
        x = app(o, n); return x is not None and x.startswith(f"\n`[THM]` `[RID: {NEW}]`") and x.endswith("see §6.3c, SG-15 and SG-16.\n") \
            and len(TAG.findall(x)) == 1 and r"\mu=6\bar\lambda n\neq0" in x and r"(H_{\rm spec})" in x and x.count("\n") == 2
    if i == "R5":
        x = app(o, n); return x is not None and x.startswith("| Transported chiral factor |") and x.count("\n") == 1 and x.rstrip("\n").endswith("| §6.3c, SG-15, SG-16 |")
    if i == "S6":
        return o == "### §6.4 Tetrahedral Jacobi Modes and Chronological Protection" and n.endswith(o) and n.startswith("### §6.3c Transported Chiral Factor Obstruction") \
            and n.count("[RID:") == 1 and grids(n) == {NEW, LEMMA, "GEN-DEF-PRIMITIVE-MAP"}
    if i == "X7":
        x = app(o, n); return x is not None and x.startswith("\n`[DEF]` **(v2.8.9) Transported six-step export.**") and len(TAG.findall(x)) == 1 and grids(x) == {NEW}
    if i == "R8":
        x = app(o, n); return x is not None and x.startswith(f"- [RID: {NEW}] :: ") and x.count("\n") == 1 and "f4c38285" in x and LEMMA in x
    if i == "APPA":
        x = app(o, n); return x is not None and x.startswith("### v2.8.9 — 19 October 2026 — DRAFT record (not adopted)\n") \
            and "No v2.8.8 claim corrected, regraded or retracted." in x and not TAG.search(x) and grids(x) == {NEW}
    if i == "FOOT": return n.startswith("*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.9_DRAFT*  \n*Draft scientific successor") and n.endswith(o.split("\n")[1])
    return False
AUTH = {"H1", "H2", "H3", "P11", "C1", "R5", "S6", "X7", "R8", "APPA", "FOOT"}
bad = [i for i, o, n in E if i not in AUTH or not rule(i, o, n)]
ids = [i for i, _, _ in E]
gate("S3", "every edit is one authorised operation matched by an independent rule; each ID used once",
     not bad and sorted(ids) == sorted(AUTH), ",".join(bad) or f"{len(E)} edits")

nf = [g for g, ok in R if not ok]; fail_final = a.final and SK
print(f"{'ALL EXECUTED GATES PASS' if not nf else 'FAILURES: ' + ','.join(nf)} ({len(R)-len(nf)}/{len(R)})"
      + (f"; SKIPPED: {','.join(SK)}" if SK else "") + ("  -> FINAL MODE: skips count as FAIL" if fail_final else ""))
sys.exit(1 if (nf or fail_final) else 0)
