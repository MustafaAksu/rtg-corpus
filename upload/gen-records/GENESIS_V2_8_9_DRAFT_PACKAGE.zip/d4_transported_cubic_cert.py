#!/usr/bin/env python
"""d4_transported_cubic_cert.py — Genesis D-4 (GENESIS-WORK-TRANSPORTED-FACTOR-TRANSFER), step D4-B.

Independent cubic-transfer certificate for the transported mean-feedback family
    (G w)_e = N(w_e) - (gamma/3) * sum_j N(w_j),   w in C^3 = R^6,
built from the full six-real-dimensional network map, NOT from OFN's coefficient transfer.

Exact arithmetic in the field Q(gamma, a, b)(i*sqrt3); n = a + i*sqrt3*b is a generic complex cubic coefficient.

Gates:
  G1  mu6 from the primitive T itself: j^3(T^6) = z + mu z^2 zbar, no quadratic part, no other cubic monomial;
      mu = -1/2 - (2/3) i sqrt3.
  G2  Birkhoff cubic n of T (quadratic chart removal, own computation) and the identity mu = 6 * conj(lam) * n.
  G3  Transported family with N3(z) = lam z + n z^2 zbar, gamma and n indeterminate:
      centre manifold psi2 == 0; invariance through degree 3; six-step return has no quadratic part;
      both chiral components have the Lemma S form; p = 2 conj(lam) n, q = 4 conj(lam) n, identically in gamma.
  G4  Calibration: the same pipeline with N := T (raw, with quadratic part) reproduces the adopted Genesis
      p(gamma), q(gamma) of v2.8.8 §6.3b (source convention p = c - i beta, q = -i beta).
  G5  Genesis Lemma S data for the transported family at the DYAD value: c = p - q, beta = i q;
      c - i beta = p != 0, beta != 0.
  G6  Negative controls: (i) n = 0 gives p = q = 0 (Lemma S hypothesis fails, sharpness);
      (ii) a deliberately wrong claim p = mu/6 is rejected.
Usage: python d4_transported_cubic_cert.py      (exit 0 iff all gates PASS)"""
import sys
from math import factorial
from sympy import QQ
from sympy.polys.fields import field

FQ, GAM, A_, B_ = field("gamma,a,b", QQ)
def Fr(x, y=1):
    if hasattr(x, "field"): return x / y
    return FQ(QQ(x)) / FQ(QQ(y))
D = 3
class K:  # element p + q*i*sqrt3 of Q(gamma,a,b)(i sqrt3)
    __slots__ = ("p", "q")
    def __init__(s, p=0, q=0): s.p, s.q = Fr(p), Fr(q)
    def __add__(x, y): y = k(y); return K(x.p + y.p, x.q + y.q)
    __radd__ = __add__
    def __neg__(x): return K(-x.p, -x.q)
    def __sub__(x, y): return x + (-k(y))
    def __mul__(x, y): y = k(y); return K(x.p*y.p - 3*x.q*y.q, x.p*y.q + x.q*y.p)
    __rmul__ = __mul__
    def conj(x): return K(x.p, -x.q)
    def inv(x): m = x.p*x.p + 3*x.q*x.q; return K(x.p/m, -x.q/m)
    def __truediv__(x, y): return x * k(y).inv()
    def iszero(x): return x.p == 0 and x.q == 0
    def __eq__(x, y): y = k(y); return x.p == y.p and x.q == y.q
    def __repr__(x): return f"({x.p}) + i*sqrt3*({x.q})"
def k(x): return x if isinstance(x, K) else K(x)
S3 = K(0, 1); LAM = K(Fr(1, 2), Fr(1, 2)); LAMB = LAM.conj()
# beta = i q is never formed in the field; only its nonvanishing (q != 0) is used.

# ---------- one-variable polynomials {(a,b): coeff} for z^a zbar^b ----------
def p1a(*Ps):
    R = {}
    for P in Ps:
        for m, c in P.items(): R[m] = R.get(m, K()) + c
    return {m: c for m, c in R.items() if not c.iszero() and sum(m) <= D}
def p1m(P, Q):
    R = {}
    for (a, b), c in P.items():
        for (e, f), d in Q.items():
            if a+b+e+f <= D: R[(a+e, b+f)] = R.get((a+e, b+f), K()) + c*d
    return {m: c for m, c in R.items() if not c.iszero()}
p1s = lambda c, P: {m: k(c)*v for m, v in P.items() if not (k(c)*v).iszero()}
p1c = lambda P: {(b, a): c.conj() for (a, b), c in P.items()}
Z, ZB = {(1, 0): K(1)}, {(0, 1): K(1)}
def p1comp(P, g):
    gb = p1c(g); pw, pwb = [{(0, 0): K(1)}], [{(0, 0): K(1)}]
    for _ in range(D): pw.append(p1m(pw[-1], g)); pwb.append(p1m(pwb[-1], gb))
    R = {}
    for (a, b), c in P.items(): R = p1a(R, p1s(c, p1m(pw[a], pwb[b])))
    return R

# ---------- primitive T in the W eigenframe (same construction as kappa_pq_symbolic.py) ----------
rho = p1a(p1s(Fr(1, 2), p1a(Z, ZB)), p1s(K(0, Fr(-1, 6)), p1a(Z, p1s(-1, ZB))))
eta = p1s(K(0, Fr(-1, 3)), p1a(Z, p1s(-1, ZB)))
def ser(x, cf):
    R, p = {}, {(0, 0): K(1)}
    for m in range(D+1):
        if cf(m): R = p1a(R, p1s(cf(m), p))
        p = p1m(p, x)
    return R
sn = ser(eta, lambda m: Fr((-1)**((m-1)//2), factorial(m)) if m % 2 else 0)
em = ser(rho, lambda m: Fr(1, factorial(m)) if m else 0)
r1, e1 = p1a(rho, p1s(-1, sn)), p1a(eta, em, p1s(-1, sn))
TW = p1a(r1, p1s(Fr(-1, 2), e1), p1s(S3*Fr(1, 2), e1))

def lampow(m):
    r = K(1)
    for _ in range(m % 6): r = r*LAM
    return r

results = {}
def gate(name, ok, info=""):
    results[name] = bool(ok); print(f"[{'PASS' if ok else 'FAIL'}] {name} {info}")

# ---------- G1: mu6 from T^6 ----------
assert TW.get((1, 0)) == LAM and (0, 1) not in TW, "DT(0) must be multiplication by lambda"
T6 = Z
for _ in range(6): T6 = p1comp(TW, T6)
quad = {m: c for m, c in T6.items() if sum(m) == 2}
cub = {m: c for m, c in T6.items() if sum(m) == 3}
MU = cub.get((2, 1), K())
gate("G1", T6.get((1, 0)) == K(1) and not quad and set(cub) == {(2, 1)} and MU == K(Fr(-1, 2), Fr(-2, 3)),
     f"mu6 = {MU}")

# ---------- G2: Birkhoff cubic n of T; mu = 6 conj(lam) n ----------
h2 = {}
for (a, b), c in TW.items():
    if a+b == 2: h2[(a, b)] = c / (lampow(a-b) - LAM)        # lam h2(z) - h2(lam z) = -T2  => conj chart
# check: T(h(z)) - h(lam z) has no degree-2 part, read resonant cubic
h = p1a(Z, h2)
Th = p1comp(TW, h)
hl = p1comp(h, p1s(LAM, Z))
diff = p1a(Th, p1s(-1, hl))
d2 = {m: c for m, c in diff.items() if sum(m) == 2}
NB = diff.get((2, 1), K())
gate("G2", not d2 and K(6)*LAMB*NB == MU, f"n_Birkhoff = {NB};  6*conj(lam)*n == mu6: {K(6)*LAMB*NB == MU}")

# ---------- network pipeline (generic edge map given as a 1-var poly) ----------
def clean(P): return {m: c for m, c in P.items() if not c.iszero() and sum(m) <= D}
def add(*Ps):
    R = {}
    for P in Ps:
        for m, c in P.items(): R[m] = R.get(m, K()) + c
    return clean(R)
def sc(c, P): return clean({m: k(c)*v for m, v in P.items()})
def mul(P, Q):
    R = {}
    for m, c in P.items():
        for n_, d in Q.items():
            if sum(m)+sum(n_) <= D:
                t = tuple(x+y for x, y in zip(m, n_)); R[t] = R.get(t, K()) + c*d
    return clean(R)
def cj(P): return {(b1, a1, b2, a2): c.conj() for (a1, b1, a2, b2), c in P.items()}
def deg(P, d): return {m: c for m, c in P.items() if sum(m) == d}
def eq(P, Q): return not add(P, sc(-1, Q))
one = {(0, 0, 0, 0): K(1)}
u1, U1, u2, U2 = {(1, 0, 0, 0): K(1)}, {(0, 1, 0, 0): K(1)}, {(0, 0, 1, 0): K(1)}, {(0, 0, 0, 1): K(1)}
def apply1(MAP, g):
    gb = cj(g); pw, pwb = [one], [one]
    for _ in range(D): pw.append(mul(pw[-1], g)); pwb.append(mul(pwb[-1], gb))
    R = {}
    for (a, b), c in MAP.items(): R = add(R, sc(c, mul(pw[a], pwb[b])))
    return R
def substitute(P, G1, G2):
    vals = [G1, cj(G1), G2, cj(G2)]; pw = [[one] for _ in range(4)]
    for i in range(4):
        for _ in range(D): pw[i].append(mul(pw[i][-1], vals[i]))
    R = {}
    for (a, b, c_, d), cf in P.items(): R = add(R, sc(cf, mul(mul(pw[0][a], pw[1][b]), mul(pw[2][c_], pw[3][d]))))
    return R
def run(MAP, gam):
    """Full R^6 map: w_e = x_e + s/3 (x in C, s = sum w); invariant graph s = psi(x) through degree 3."""
    ue = [u1, u2, add(sc(-1, u1), sc(-1, u2))]
    def step(psi):
        w = [add(x, sc(Fr(1, 3), psi)) for x in ue]
        t = [apply1(MAP, x) for x in w]; tot = add(*t); m = sc(Fr(1, 3), tot)
        return sc(1-gam, tot), [add(t[0], sc(-1, m)), add(t[1], sc(-1, m))]
    psi = {}
    for d in (2, 3):
        sp_, (a1, a2) = step(psi)
        R = deg(add(sp_, sc(-1, substitute(psi, a1, a2))), d)
        for (a, b, c_, dd), cf in R.items():
            den = lampow((a+c_)-(b+dd)) - LAM*(1-gam)
            psi = add(psi, {(a, b, c_, dd): cf/den})
    sp_, (a1, a2) = step(psi)
    inv_ok = eq(add(sp_, sc(-1, substitute(psi, a1, a2))), {})
    G1, G2 = u1, u2
    for _ in range(6): G1, G2 = substitute(a1, G1, G2), substitute(a2, G1, G2)
    lin_ok = G1.get((1, 0, 0, 0)) == K(1) and G2.get((0, 0, 1, 0)) == K(1) and len(deg(G1, 1)) == 1 and len(deg(G2, 1)) == 1
    noquad = not deg(G1, 2) and not deg(G2, 2)
    f1, f2 = deg(G1, 3), deg(G2, 3)
    u = add(u1, sc(LAM, u2)); v = add(u1, sc(LAMB, u2)); Uc, Vc = cj(u), cj(v)
    uf = add(f1, sc(LAM, f2)); vf = add(f1, sc(LAMB, f2))
    c1 = uf.get((2, 1, 0, 0), K()); c2 = uf.get((2, 0, 0, 1), K())
    q = (c2 - c1*LAMB) / (LAM - LAMB); p = c1 - q
    ok_u = eq(uf, add(sc(p, mul(mul(u, u), Uc)), sc(q, mul(mul(v, Vc), u))))
    ok_v = eq(vf, add(sc(p, mul(mul(v, v), Vc)), sc(q, mul(mul(u, Uc), v))))
    return dict(p=p, q=q, psi=psi, inv=inv_ok, lin=lin_ok, noquad=noquad, ok_u=ok_u, ok_v=ok_v)

# ---------- G3: transported family, gamma and n indeterminate ----------
NSYM = K(A_, B_)                                  # n = a + i sqrt3 b
N3 = {(1, 0): LAM, (2, 1): NSYM}
r = run(N3, GAM)
psi2_zero = not deg(r["psi"], 2)
p_ok = r["p"] == K(2)*LAMB*NSYM
q_ok = r["q"] == K(4)*LAMB*NSYM
# gamma-independence follows from p_ok/q_ok: the right-hand sides contain no gamma.
gate("G3", psi2_zero and r["inv"] and r["lin"] and r["noquad"] and r["ok_u"] and r["ok_v"] and p_ok and q_ok,
     f"psi2=0:{psi2_zero} inv:{r['inv']} lin=I:{r['lin']} noquad:{r['noquad']} u-form:{r['ok_u']} v-form:{r['ok_v']} "
     f"p=2conj(lam)n:{p_ok} q=4conj(lam)n:{q_ok}")
print("     psi3 monomials (degree 3):", sorted(deg(r["psi"], 3)))

# ---------- G4: calibration against adopted Genesis §6.3b ----------
def pform(x):
    m = x*x - x + 1
    return K(-(x*x - 3*x + 1)/(6*m), -(2*x*x - 3*x + 2)/(9*m))
def qform(x):
    m = x*x - x + 1
    return K(-2*(x-1)**3/(3*(x-2)*m), -2*(2*x*x - 3*x + 2)/(9*m))
rc = run(TW, GAM)
gate("G4", rc["inv"] and rc["ok_u"] and rc["ok_v"] and rc["p"] == pform(GAM) and rc["q"] == qform(GAM),
     "raw T reproduces Genesis p(gamma), q(gamma) identically")

# ---------- G5: Lemma S data at the DYAD value n = n_Birkhoff ----------
nD = NB
pD, qD = K(2)*LAMB*nD, K(4)*LAMB*nD
c_minus_ibeta = pD                    # c - i beta = p   (c = p - q, beta = i q)
beta_nonzero = not qD.iszero()        # beta = i q != 0  <=>  q != 0
gate("G5", pD == MU*K(Fr(1, 3)) and qD == MU*K(Fr(2, 3)) and not c_minus_ibeta.iszero() and beta_nonzero,
     f"p = mu/3 = {pD};  q = 2mu/3 = {qD};  c - i beta = p != 0;  beta = i q != 0")

# ---------- G6: negative controls ----------
r0 = run({(1, 0): LAM}, GAM)
wrong = (K(2)*LAMB*NSYM) == (K(6)*LAMB*NSYM)*K(Fr(1, 6))
gate("G6", r0["p"].iszero() and r0["q"].iszero() and not wrong,
     "n=0 gives p=q=0 (Lemma S branch excluded); wrong claim p=mu/6 rejected")

ok = all(results.values())
print(f"\n{sum(results.values())}/{len(results)} gates PASS")
sys.exit(0 if ok else 1)
