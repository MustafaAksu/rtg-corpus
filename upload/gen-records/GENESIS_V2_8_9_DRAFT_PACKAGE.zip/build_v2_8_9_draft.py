#!/usr/bin/env python
"""build_v2_8_9_draft.py — deterministic build of RTG_GENESIS_GEOMETRY_DSN_v2_8_9_DRAFT (D-4 scientific successor)
from the exact adopted v2.8.8 bytes. Every edit is an exact-match replacement that must occur exactly once.
Control: occurrence disposition plan v0.1 (aee218c0...1ee3), owner-pass manifest v0.1 (53782f85...0570),
owner decisions of 19 Oct 2026 (D1-D5; R-1..R-5; primitive proof dependency clarified).
Usage: python build_v2_8_9_draft.py <v2_8_8.md> <out.md>"""
import sys, hashlib
BASE_SHA = "9abd36169a4bf6056318605c0399ff1f91c53f157b9181bdbfdb9faed3000f37"
src, out = sys.argv[1], sys.argv[2]
raw = open(src, "rb").read()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA, "baseline hash mismatch"
t = raw.decode("utf-8")

E = []  # (id, old, new)
def ed(i, old, new): E.append((i, old, new))
RID = "GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO"
CERT = "d4_transported_cubic_cert.py"
CERT_SHA = "f4c382855b130249ce290d3ca939b283aadd27d6ea9a1af551599f4cd9533f6d"
D4REC = "1a5f7f56690b1496d9972dc294053334e2eeca40a1d1d9e9f41185d84da3cee3"

# ---------------- G9-03 header ----------------
ed("H1", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.8\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.9_DRAFT\n")
ed("H2", "**Date:** 19 October 2026  \n**Document status:** ADOPTED owner ledger — maintenance release (Dyadic v6.4.13 source synchronization; ν₅⁽⁵⁾ point-of-use attribution).  \n",
   "**Date:** 19 October 2026 (draft)  \n**Document status:** DRAFT owner successor — scientific (D-4: transported chiral factor obstruction, §6.3c). **Not adopted**; adopted owner remains v2.8.8 (`9abd3616…0f37`).  \n")
ed("H3", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.7` ·",
   "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.8` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.7` ·")
ed("P11", "No scientific claim is added, changed or regraded.\n",
   "No scientific claim is added, changed or regraded. **v2.8.9 draft addition:** `" + RID + "` (§6.3c) excludes local \\(C^3\\) submersive six-step factors for every real \\(C^3\\) network germ with the stated linear structure, zero quadratic part and chiral cubic invariant \\(\\mu\\neq0\\), under \\((H_{\\rm spec})\\); a primitive-clock companion is recorded at the same grade as the §6.3b primitive statement. This is a mathematical semiconjugacy exclusion for the stated real \\(C^3\\) class; no physical model, carrier, closure condition or \\(\\gamma\\) is selected, and existence of an exactly transported realization is not asserted.\n")

# ---------------- G9-02 §1 summary ----------------
L55 = "`[THM]` `[RID: GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO]` **Mean-feedback six-step obstruction (v2.8.7; conditional).**"
i55 = t.index(L55); e55 = t.index("\n", i55) + 1
OLD_C1 = t[i55:e55]
ed("C1", OLD_C1, OLD_C1 + "\n`[THM]` `[RID: " + RID + "]` **Transported chiral factor obstruction (v2.8.9; conditional).** For every real \\(C^3\\) germ \\(G\\) on \\(\\mathbb R^6\\) whose third jet, in some \\(C^3\\) coordinates fixing \\(0\\), equals that of the mean-feedback form \\((G^{(n)}_\\gamma w)_e=N_3(w_e)-\\tfrac{\\gamma}{3}\\sum_jN_3(w_j)\\), \\(N_3(z)=\\lambda z+nz^2\\bar z\\), with \\(\\gamma\\in\\mathbb R\\setminus\\{0,2\\}\\) and \\(\\mu=6\\bar\\lambda n\\neq0\\), no local \\(C^3\\) submersive semiconjugacy \\(E\\circ G^6=T'\\circ E\\) with \\(d\\in\\{1,2,3\\}\\) exists under \\((H_{\\rm spec})\\). Mathematical exclusion only; see §6.3c, SG-15 and SG-16.\n")

# ---------------- G9-02 §5 row ----------------
R624 = "| Mean-feedback six-step factor | `[THM]` conditional: $F_\\gamma$, $\\gamma\\in\\mathbb R\\setminus\\{0,2\\}$, $C^3$, $d=1,2,3$, under $(H_{\\rm spec})$ | Statement without $(H_{\\rm spec})$; $\\gamma\\in\\{0,2\\}$ covered; physical $\\gamma$ or closure selected; centre manifold tangent to the mean mode | §6.3b, SG-16 |\n"
ed("R5", R624, R624 + "| Transported chiral factor | `[THM]` conditional: real $C^3$ germs with the §6.3c third jet, $\\gamma\\in\\mathbb R\\setminus\\{0,2\\}$, $\\mu\\neq0$, $C^3$, $d=1,2,3$, under $(H_{\\rm spec})$; primitive companion `[ALG]` under $(H_{\\rm prim})$ | Selection of model C or of any physical model; existence of an exactly transported realization; sub-$C^3$ or non-planar decouplings; $\\gamma\\in\\{0,2\\}$ covered; primitive companion cited as a theorem | §6.3c, SG-15, SG-16 |\n")

# ---------------- G9-01 new §6.3c ----------------
S63C = r"""### §6.3c Transported Chiral Factor Obstruction `[DEF / ALG / THM]` (v2.8.9) {#sec-6-3c-transported}

> **[SG-15 applies]** **[SG-16 applies]** *(v2.8.9; source: `GENESIS_TRANSPORTED_FACTOR_TRANSFER_D4_SESSION_v0_1_1.md`, receiving review ACCEPT; owner-pass manifest v0.1 and occurrence disposition plan v0.1, owner decisions of 19 Oct 2026. §6.3a, §6.3a.1 and §6.3b above are unchanged.)*

`[DEF]` **Model class.** Let \(\mathcal N_3\) be the set of real \(C^3\) germs \(N:(\mathbb C,0)\to(\mathbb C,0)\) with \(DN(0)=A\) (multiplication by \(\lambda=e^{i\pi/3}\) in the eigenframe of §6.3a), zero quadratic part, and third jet \(j^3N(0)(z)=\lambda z+n\,z^2\bar z\). Put \(\mu(N):=6\bar\lambda n\); then \(N^6(z)=z+\mu(N)z^2\bar z+o(|z|^3)\). For \(\gamma\in\mathbb R\) let \(G^N_\gamma\) be the family of §6.3b with \(T\) replaced by \(N\), \((G^N_\gamma w)_e=N(w_e)-\tfrac{\gamma}{3}\sum_jN(w_j)\), and let \(G^{(n)}_\gamma:=G^{N_3}_\gamma\), \(N_3(z)=\lambda z+nz^2\bar z\), the real polynomial reference map. \(\gamma\) is a model parameter (SG-16).

`[THM]` `[RID: GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO]` `[scope: real C^3 germs on R^6 with the stated third jet; gamma in R minus {0,2}; mu != 0; six-step contract; local germs at 0; C^3, d=1,2,3; conditional on (H_spec)]` Let \(\gamma\in\mathbb R\setminus\{0,2\}\), \(n\in\mathbb C\), and let \(G\) be a real \(C^3\) germ on \(\mathbb R^6\) with \(G(0)=0\). Assume:
- **(H-JET)** in some \(C^3\) coordinates fixing \(0\), \(j^3G(0)=j^3G^{(n)}_\gamma(0)\); explicitly, (i) \(DG(0)\) is multiplication by \(\lambda\) on \(\mathcal C\) and by \((1-\gamma)\lambda\) on \(\mathcal D\); (ii) \(G\) has no quadratic part; (iii) the cubic part of \(G\) is \(w\mapsto\bigl(n\,w_e^2\bar w_e-\tfrac{\gamma}{3}\sum_jn\,w_j^2\bar w_j\bigr)_e\);
- **(H-\(\mu\))** \(\mu:=6\bar\lambda n\neq0\).

Let \(E\) be a \(C^3\) submersion from a neighbourhood of \(0\in\mathbb R^6\) onto a manifold of real dimension \(d\in\{1,2,3\}\), and \(T'\) a \(C^3\) map with \(E\circ G^6=T'\circ E\) near \(0\). If
\[
(H_{\rm spec})\qquad (1-\gamma)^6\notin\operatorname{spec}DT'(E(0)),
\]
no such pair exists. Hypotheses and conclusion are invariant under \(C^3\) diffeomorphisms fixing \(0\): if \(E\) is a factor of \(\Psi^{-1}G\Psi\), then \(E\circ\Psi^{-1}\) is a factor of \(G\) with the same \(T'\).

*Proof.*
- **(a) Mean mode in the kernel; reduction.** As §6.3b (a)–(b): these use only (i) and the existence of a local \(C^3\) centre manifold \(M^c\) tangent to \(\mathcal C\), which holds because \(|1-\gamma|\neq1\). \(E|_{M^c}\) is a \(C^3\) submersion with \(E|_{M^c}\circ G^6|_{M^c}=T'\circ E|_{M^c}\).
- **(b) Third jet of \(M^c\).** The Taylor coefficients of \(M^c=\{s=\psi(x)\}\) through degree 3 are fixed by the homological equation, whose denominators \(\lambda^m-(1-\gamma)\lambda\) do not vanish in degrees 2 and 3 for \(\gamma\notin\{0,2\}\); by (ii), \(\psi_2=0\).
- **(c) Six-step cubic.** On \(M^c\), \(G^6=\mathrm{id}+f+o(|x|^3)\) with no quadratic part, and in the chiral coordinates of §6.3a
\[
u(f)=\tfrac{\mu}{3}\,u|u|^2+\tfrac{2\mu}{3}\,|v|^2u,\qquad v(f)=\tfrac{\mu}{3}\,v|v|^2+\tfrac{2\mu}{3}\,|u|^2v,
\]
with no other cubic monomial, identically in \(\gamma\) and \(n\) (certificate gate G3).
- **(d) Lemma S.** Steps (a)–(c) of §6.3a.1 give \(\ell\circ f=t_3\circ\ell\). `GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA` applies with \(c=p-q=-\mu/3\), \(\beta=iq=2i\mu/3\), where \(p=\mu/3\), \(q=2\mu/3\): \(c-i\beta=p\neq0\) and \(\beta\neq0\) by (H-\(\mu\)). This is the adopted branch, without extension. Every \(d\) is excluded. \(\square\)

`[ALG]` **Primitive clock (\(C^3\) only; no RID; same grade as the §6.3b primitive statement).** Under (H-JET) and (H-\(\mu\)) there is no local \(C^3\) submersive semiconjugacy \(E\circ G=T'\circ E\) with \(d\in\{1,2,3\}\) under
\[
(H_{\rm prim})\qquad (1-\gamma)\lambda\notin\operatorname{spec}B,\qquad B=DT'(E(0)).
\]
The argument is the direct primitive-clock argument of §6.3b: (i) \(DG(0)|_{\mathcal D}\) has spectrum \(\{(1-\gamma)\lambda,(1-\gamma)\bar\lambda\}\) and \(B\) is real, so \((H_{\rm prim})\) and the intertwining force \(\ell|_{\mathcal D}=0\); (ii) \(\ell|_{\mathcal C}\) is onto and \(\ell|_{\mathcal C}\lambda=B\,\ell|_{\mathcal C}\), so \(B^6=I\); (iii) on \(M^c\), \(E\circ G^6=T'^6\circ E\) with \(DT'^6(E(0))=I\), and steps (b)–(c) of §6.3a.1 with the cubic of (c) above and Lemma S exclude every \(d\). The six-step theorem above is **not** invoked: \((H_{\rm prim})\) does not imply \((1-\gamma)^6\notin\operatorname{spec}(B^6)\) in general, so the two statements share the cubic data but neither is a corollary of the other. \((H_{\rm spec})\) is not used.

`[ALG]` **Instances by existence condition.**
- **(C1, exists.)** \(n=n_T=\tfrac18-\tfrac{7i\sqrt3}{72}\), the Birkhoff cubic of the primitive \(T\) (`GEN-DEF-PRIMITIVE-MAP`), with \(6\bar\lambda n_T=\mu_6=-\tfrac12-\tfrac{2i\sqrt3}{3}\neq0\). \(G^{(n_T)}_\gamma\) is a real polynomial map satisfying the theorem (certificate gates G1, G2).
- **(C2, conditional.)** If \(\Phi\) is a real \(C^3\) diffeomorphism with \(\Phi(0)=0\), \(D\Phi(0)=I\) and \(N_\Phi:=\Phi T\Phi^{-1}\) commuting with \(A\), then \(N_\Phi\in\mathcal N_3\) and \(\mu(N_\Phi)=\mu_6\), since \(\Phi T^6\Phi^{-1}(z)=z+f_3(z)+o(|z|^3)\) with \(f_3=\mu_6z^2\bar z\) unchanged; hence \((\Phi^{-1})^{\times3}\circ G^{N_\Phi}_\gamma\circ\Phi^{\times3}\) satisfies the theorem. The commutation of \(\Phi T\Phi^{-1}\) with \(A\) is a hypothesis; **existence of such a \(\Phi\) is not asserted here.** No Dyadic generator, centralizer or realization result is imported.
- **(C3.)** The theorem itself: every real \(C^3\) germ with the stated third jet, whether or not it is exactly transported.

**Guards at the point of use** (owner-pass manifest v0.1 §4; not a new scope guard).
- **G-JET.** Only real \(C^3\) germs are covered. Formal and polynomial computations enter as exact third-jet data; no statement is made about a formal power-series map as such.
- **G-20.** The theorem neither requires nor supplies existence of an exactly transported realization; (C2) is vacuous if no such \(\Phi\) exists. Preservation under \(C^3\) conjugacy is a mathematical statement about an existing diffeomorphism, not a choice of physical network representation.
- **G-SEL.** No physical model, carrier, closure condition or \(\gamma\) is selected. The obstruction does not imply uniqueness of any model class, and it does not distinguish an exactly transported model from its third-jet equivalents (C3).
- **G-OFN.** Use as a coupling certificate in another stream is subject to that stream's own contract (local \(C^3\) conjugacy, declared clock, planar targets); wider decoupling notions are not covered and require separate proof.

`[OPEN]` \(\gamma\in\{0,2\}\) (including the neutral mean mode at \(\gamma=2\)); planar factors at \(C^1/C^2\); targets whose spectrum meets the \(\mathcal D\)-spectrum; non-planar or \(d\ge4\) decompositions; non-submersive or non-local factor maps; formal power-series maps as such; existence of an exactly transported realization; any physical selection (OFN/FMS). Relative to the item "other network dynamics" in the open list of §6.3b, the third-jet class above is now covered; the remainder of that item stays open.

`[DEF]` **Evidence.** Proof: D-4 SESSION v0.1.1 (`1a5f7f56690b1496d9972dc294053334e2eeca40a1d1d9e9f41185d84da3cee3`) §3–§5, with the Genesis receiving review of 19 Oct 2026. Exact third-jet data (load-bearing): `d4_transported_cubic_cert.py` (`f4c382855b130249ce290d3ca939b283aadd27d6ea9a1af551599f4cd9533f6d`), 6/6 PASS, independently rerun — G1 \(\mu_6\) from \(T\); G2 \(n_T\) and \(6\bar\lambda n_T=\mu_6\); G3 \(\psi_2=0\), both chiral components, \(p=\mu/3\), \(q=2\mu/3\) identically in \(\gamma,n\); G4 calibration against the §6.3b coefficients; G5 Lemma S branch; G6 negative controls. Scope and dependency audit: owner-pass manifest v0.1 (`53782f8509949c2ae989bbf8fe3a9a64207b7157831988a727c7ba4dde910570`).

"""
ed("S6", "### §6.4 Tetrahedral Jacobi Modes and Chronological Protection", S63C + "### §6.4 Tetrahedral Jacobi Modes and Chronological Protection")

# ---------------- G9-02 §7 export ----------------
X1145 = "`[DEF]` **(v2.8.7) RRF G2-CLOCK six-step export.**"
i1 = t.index(X1145); e1 = t.index("\n", i1) + 1
OLD_X = t[i1:e1]
ed("X7", OLD_X, OLD_X + "\n`[DEF]` **(v2.8.9) Transported six-step export.** Genesis exports `" + RID + "` with exactly the hypotheses of §6.3c (real \\(C^3\\) germ, stated third jet, \\(\\gamma\\notin\\{0,2\\}\\), \\(\\mu\\neq0\\), \\((H_{\\rm spec})\\)). The primitive-clock companion of §6.3c is an algebraic statement at the grade of the §6.3b primitive statement and is **not** exported as a theorem. A consumer that uses the result as a coupling certificate states its own contract (regularity, clock, targets); Genesis does not select a physical model, carrier, closure condition, \\(\\gamma\\) or the existence of an exactly transported realization (SG-15, SG-16; guards of §6.3c).\n")

# ---------------- G9-02 §8 RID line ----------------
R1186 = "- [RID: GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO] :: mean-feedback six-step obstruction (v2.8.7)"
i2 = t.index(R1186); e2 = t.index("\n", i2) + 1
OLD_R = t[i2:e2]
ed("R8", OLD_R, OLD_R + "- [RID: " + RID + "] :: transported chiral factor obstruction (v2.8.9) :: `[THM]` `[scope: §6.3c; six-step; conditional on (H_{\\rm spec}) and \\mu\\neq0]` — proof: §6.3c / D-4 SESSION v0.1.1 (`1a5f7f56…cee3`); exact third-jet data `" + CERT + "` (`f4c38285…3f6d`, load-bearing, 6/6 PASS); algebraic dependency `GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA` (adopted branch)\n")

# ---------------- G9-03 Appendix A record ----------------
ed("APPA", "## Appendix A — Version History {#appendix-a}\n\n",
   "## Appendix A — Version History {#appendix-a}\n\n"
   + "### v2.8.9 — 19 October 2026 — DRAFT record (not adopted)\n\n"
   + "Scientific successor built deterministically from the exact adopted v2.8.8 bytes (`9abd3616…0f37`) by `build_v2_8_9_draft.py`. Control: D-4 SESSION v0.1.1 (`1a5f7f56…cee3`), owner-pass manifest v0.1 (`53782f85…0570`), occurrence disposition plan v0.1 (`aee218c0…1ee3`) and owner decisions of 19 Oct 2026 (D1–D5, R-1–R-5, primitive proof dependency clarified).\n\n"
   + "- **G9-01:** new §6.3c with one new theorem RID `" + RID + "` (six-step, real C³ third-jet class, μ ≠ 0, (H_spec)); a primitive-clock companion without RID at the grade of the §6.3b primitive statement, proved by the direct primitive argument (not as a corollary of the six-step theorem); instances C1 (polynomial, exists), C2 (conditional on a C³ chart Φ; existence not asserted) and C3; guards G-JET, G-20, G-SEL, G-OFN at the point of use.\n"
   + "- **G9-02:** entries for the new RID in §1, §5, §7 export and §8.\n"
   + "- **G9-03:** status-summary sentence; header and footer.\n"
   + "- **Not in this draft:** any change to §6.3a, §6.3a.1, §6.3b, SG-15, SG-16 or the five existing K3/6S RID lines; widening or regrading of existing RIDs; a new scope guard; any import of the Dyadic formal generator, centralizer or realization results; OFN/FMS verdicts as premises; Dyadic repin to v6.4.14 (deferred, R-1); physical γ, carrier, closure or model selection.\n"
   + "- **No v2.8.8 claim corrected, regraded or retracted.**\n\n")

# ---------------- footer ----------------
ed("FOOT", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.8*  \n*Adopted maintenance successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.7.",
   "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.9_DRAFT*  \n*Draft scientific successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.8 (not adopted). v2.8.9 adds " + RID + " (§6.3c) only. Inherited v2.8.8 footer follows:*  \n*Adopted maintenance successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.7.")

for i, old, new in E:
    n = t.count(old)
    assert n == 1, f"{i}: expected 1 match, found {n}"
    t = t.replace(old, new)
open(out, "w", encoding="utf-8", newline="").write(t)
print(f"applied {len(E)} edits -> {out}  sha256={hashlib.sha256(t.encode()).hexdigest()}")
