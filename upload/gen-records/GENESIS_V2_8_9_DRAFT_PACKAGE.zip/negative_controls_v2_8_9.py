#!/usr/bin/env python
"""negative_controls_v2_8_9.py — tampering controls for check_v2_8_9_draft.py (owner decision of 19 Oct 2026:
the six planned controls plus an (H_prim)/(H_spec) equation control; one extra certificate control).
Each control tampers a copy of the build (or the draft / certificate), rebuilds, runs the checker in --final mode
and requires exit 1 with the expected gate(s) failing. Usage: python negative_controls_v2_8_9.py (from the package dir)."""
import sys, os, re, subprocess, tempfile, shutil
BASE, BUILD, CHECK, CERT = "RTG_GENESIS_GEOMETRY_DSN_v2_8_8.md", "build_v2_8_9_draft.py", "check_v2_8_9_draft.py", "d4_transported_cubic_cert.py"
src = open(BUILD, encoding="utf-8").read()
def sub(s, old, new):
    assert s.count(old) == 1, old[:60]; return s.replace(old, new)
CONTROLS = [
  ("NC1 widen GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO (§1 line)", "build",
   lambda s: sub(s, 'ed("C1", OLD_C1, OLD_C1 + ', 'ed("C1", OLD_C1, OLD_C1.replace("(v2.8.7; conditional).", "(v2.8.7; conditional; also transported families).") + '),
   {"M2", "S3"}),
  ("NC2 primitive companion tagged [THM]", "build",
   lambda s: sub(s, "`[ALG]` **Primitive clock", "`[THM]` **Primitive clock"), {"M4", "S1"}),
  ("NC3 (H-mu) hypothesis dropped", "build",
   lambda s: sub(s, "- **(H-\\(\\mu\\))** \\(\\mu:=6\\bar\\lambda n\\neq0\\).\n", ""), {"M3"}),
  ("NC4 Dyadic formal Z6 generator imported", "build",
   lambda s: sub(s, "algebraic dependency `GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA` (adopted branch)\\n\")",
                 "algebraic dependency `GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA` (adopted branch) `[import: DYAD v6.4.13 §6.16; RID: DYAD-THM-FORMAL-Z6-GENERATOR]`\\n\")"),
   {"M7"}),
  ("NC5 'unique physical model' wording", "build",
   lambda s: sub(s, "existence of an exactly transported realization is not asserted.\\n\")",
                 "existence of an exactly transported realization is not asserted. Model C is the unique physical model.\\n\")"), {"M5"}),
  ("NC6 one byte changed in §6.3b (draft only)", "draft", None, {"M1b", "M2"}),
  ("NC7 (H_prim) equated with (H_spec)", "build",
   lambda s: sub(s, "The six-step theorem above is **not** invoked:", "The six-step theorem above is invoked, since \\((H_{\\rm prim})\\) implies \\((H_{\\rm spec})\\):"),
   {"M4"}),
  ("NC8 certificate bytes altered", "cert", None, {"M6"}),
]
allok = True
for name, kind, f, expect in CONTROLS:
    with tempfile.TemporaryDirectory() as td:
        b = os.path.join(td, BUILD); d = os.path.join(td, "draft.md"); c = os.path.join(td, CERT)
        open(b, "w", encoding="utf-8").write(f(src) if kind == "build" else src)
        shutil.copy(CERT, c)
        r = subprocess.run([sys.executable, "-I", b, BASE, d], capture_output=True, text=True)
        if r.returncode != 0: print(f"BUILD-ERROR {name}: {r.stderr.strip()[-200:]}"); allok = False; continue
        if kind == "draft":
            t = open(d, encoding="utf-8").read()
            t = t.replace("a graph over \\(\\mathcal C\\) tangent to \\(\\mathcal C\\)", "a graph over \\(\\mathcal C\\)  tangent to \\(\\mathcal C\\)", 1)
            open(d, "w", encoding="utf-8").write(t)
        if kind == "cert":
            open(c, "a", encoding="utf-8").write("\n# tampered\n")
        r = subprocess.run([sys.executable, "-I", CHECK, "--base", BASE, "--draft", d, "--build", b, "--cert", c, "--final"],
                           capture_output=True, text=True)
        failed = set(re.findall(r"^FAIL\s+(\S+)", r.stdout, re.M))
        ok = r.returncode == 1 and expect <= failed
        allok &= ok
        print(f"{'OK  ' if ok else 'BAD '} {name}: exit={r.returncode} failed={sorted(failed)} expected⊇{sorted(expect)}")
print("ALL NEGATIVE CONTROLS CAUGHT" if allok else "NEGATIVE CONTROL FAILURE"); sys.exit(0 if allok else 1)
