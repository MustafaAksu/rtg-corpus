#!/usr/bin/env python
"""genesis_nu5_p5_replay.py — Genesis-side independent replay of DYAD-ALG-NU5-P5 (Dyadic v6.4.13 §6.11).
Own implementation (no Dyadic code): high-precision complex arithmetic (mpmath, 60 digits).
Model: rho' = rho - sin eta, eta' = eta + K_p(e^rho - 1) - K_p sin eta, K_p = 2 - lam - conj(lam), lam = e^{2 pi i/p};
frame W_p = rho + ((lam-1)/K_p) eta; one-step normal form f o h = h o n through degree 5 with the resonant
monomial coefficients of every h_k set to zero (resonance a-b-1 = 0 mod p).
Gates:
  C1 p=6 calibration: n21, n32, n05 equal the DYAD-ALG-NF6 values (exact rationals in Q(sqrt3)) to 1e-50.
  C2 p=5: n32 equals the printed closed form (355-159 sqrt5)/48 + i (1106 sqrt5 - 2473) sqrt(10+2 sqrt5)/48 to 1e-50.
  C3 negative control: the same comparison with the imaginary part's sign flipped must FAIL.
  C4 convention sensitivity: a nonzero resonant normalizer coefficient h21 changes Im n32 (why the convention tag is required).
This is a [NUM high-precision] corroboration, not an exact certificate."""
import sys
from mpmath import mp, mpf, mpc, exp, pi, sqrt, sin, factorial
mp.dps = 60
D = 5
def padd(*ps):
    r = {}
    for p in ps:
        for k, v in p.items(): r[k] = r.get(k, 0) + v
    return {k: v for k, v in r.items() if sum(k) <= D and abs(v) > mpf(10)**-55}
def pscale(c, p): return {k: c*v for k, v in p.items()}
def pmul(p, q):
    r = {}
    for (a, b), u in p.items():
        for (c, d), v in q.items():
            if a+b+c+d <= D: r[(a+c, b+d)] = r.get((a+c, b+d), 0) + u*v
    return r
def pconj(p): return {(b, a): v.conjugate() for (a, b), v in p.items()}
def ppow(p, n):
    r = {(0, 0): mpc(1)}
    for _ in range(n): r = pmul(r, p)
    return r
def series(x, coef):           # sum_n coef(n) x^n, n=1..D
    r, pw = {}, {(0, 0): mpc(1)}
    for n in range(1, D+1):
        pw = pmul(pw, x)
        c = coef(n)
        if c: r = padd(r, pscale(c, pw))
    return r
def compose(F, G):             # F(G, conj G)
    Gc = pconj(G); r = {}
    for (a, b), v in F.items():
        r = padd(r, pscale(v, pmul(ppow(G, a), ppow(Gc, b))))
    return r
def deg(p, k): return {kk: v for kk, v in p.items() if sum(kk) == k}
def normal_form(p, gauge=None):
    lam = exp(2j*pi/p); lb = lam.conjugate(); K = 2 - lam - lb; c = (lam - 1)/K
    z, zb = {(1, 0): mpc(1)}, {(0, 1): mpc(1)}
    eta = pscale(1/(c - c.conjugate()), padd(z, pscale(-1, zb)))          # eta real
    rho = padd(z, pscale(-c, eta))
    sin_eta = series(eta, lambda n: mpf((-1)**((n-1)//2))/factorial(n) if n % 2 else 0)
    expm1 = series(rho, lambda n: 1/factorial(n))
    rho1 = padd(rho, pscale(-1, sin_eta))
    eta1 = padd(eta, pscale(K, expm1), pscale(-K, sin_eta))
    f = padd(rho1, pscale(c, eta1))
    assert abs(f.get((1, 0), 0) - lam) < mpf(10)**-50 and abs(f.get((0, 1), 0)) < mpf(10)**-50
    h, n = dict(z), {(1, 0): lam}
    for k in range(2, D+1):
        R = deg(padd(compose(f, h), pscale(-1, compose(h, n))), k)
        for (a, b), v in R.items():
            mult = lam**a * lb**b
            if abs(mult - lam) < mpf(10)**-40:   # resonant: goes to n, h_ab = 0
                n[(a, b)] = v
                if gauge and (a, b) in gauge: h[(a, b)] = gauge[(a, b)]   # residual gauge freedom
            else:
                h[(a, b)] = -v/(lam - mult)
        chk = deg(padd(compose(f, h), pscale(-1, compose(h, n))), k)
        assert all(abs(v) < mpf(10)**-45 for v in chk.values()), f"degree {k} not solved"
    return n
s3, s5 = sqrt(3), sqrt(5)
res = []
n6 = normal_form(6)
want6 = {(2, 1): mpc(mpf(1)/8, -7*s3/72), (3, 2): mpc(mpf(-5)/432, 23*s3/3888), (0, 5): mpc(mpf(43)/17280, -227*s3/155520)}
ok1 = all(abs(n6.get(k, 0) - v) < mpf(10)**-50 for k, v in want6.items())
res.append(("C1", "p=6 calibration n21,n32,n05 = DYAD-ALG-NF6", ok1))
n5 = normal_form(5)
closed = mpc((355 - 159*s5)/48, (1106*s5 - 2473)*sqrt(10 + 2*s5)/48)
ok2 = abs(n5[(3, 2)] - closed) < mpf(10)**-50
res.append(("C2", "p=5 n32 = printed closed form of nu_5^(5)", ok2))
wrong = mpc(closed.real, -closed.imag)
res.append(("C3", "negative control (conjugated value) is rejected", not abs(n5[(3, 2)] - wrong) < mpf(10)**-50))
n5g = normal_form(5, gauge={(2, 1): mpc(0, mpf(1)/10)})
dIm = (n5g[(3, 2)] - n5[(3, 2)]).imag
res.append(("C4", "convention sensitivity: resonant gauge h21 = i/10 changes Im n32 (SG-10)", abs(dIm) > mpf(10)**-10))
print(f"Im n32 shift under h21 = i/10: {mp.nstr(dIm, 15)}")
for g, name, ok in res: print(f"{'PASS' if ok else 'FAIL'}  {g}  {name}")
print(f"nu_5^(5) (computed) = {mp.nstr(n5[(3,2)], 30)}")
print(f"p=5 resonant normal-form slots through degree 5: {sorted(k for k in n5 if k != (1,0))}")
allok = all(ok for *_, ok in res)
print("ALL PASS (4/4)" if allok else "FAILURES"); sys.exit(0 if allok else 1)
