#!/usr/bin/env python
"""check_genesis_dyad_v6_4_13_consumer.py — byte-level consumer audit of adopted Dyadic v6.4.13 against
adopted Genesis v2.8.7 (repin readiness + M2c source). Read-only; changes no file.
Usage: python check_genesis_dyad_v6_4_13_consumer.py --genesis RTG_GENESIS_GEOMETRY_DSN_v2_8_7.md --dyad RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md
Exit 0 iff every gate passes."""
import sys, re, hashlib, argparse
ap = argparse.ArgumentParser(); ap.add_argument("--genesis", required=True); ap.add_argument("--dyad", required=True); a = ap.parse_args()
GEN_SHA = "d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361"
DYAD_SHA = "5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542"   # as reported by the Genesis-side review, 19 Oct 2026
R = []
def gate(g, name, ok, note=""): R.append(bool(ok)); print(f"{'PASS' if ok else 'FAIL'}  {g:3s} {name}" + (f"  [{note}]" if note else ""))
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
gen = open(a.genesis, encoding="utf-8").read(); dy = open(a.dyad, encoding="utf-8").read()
gate("D1", "Genesis v2.8.7 adopted SHA-256", sha(a.genesis) == GEN_SHA)
gate("D2", "Dyadic v6.4.13 SHA-256 (as reported)", sha(a.dyad) == DYAD_SHA, sha(a.dyad)[:12] + "…")
rids = sorted(set(re.findall(r"DYAD-[A-Z0-9-]*[A-Z0-9]", gen)))
miss = [r for r in rids if not re.search(re.escape(r) + r"(?![A-Z0-9-])", dy)]
gate("D3", f"all {len(rids)} DYAD RIDs cited by Genesis exist in v6.4.13", not miss, ",".join(miss))
VALUES = ["559\\sqrt{15}/4860", "86775991", "1/(1-i\\tau)", "119\\sqrt{3}/648", "2\\sqrt{3}/3", "e^{iF_f/2}", "G_{04}(10)", "13+15\\sqrt{3}/2"]
vm = [v for v in VALUES if v not in dy]
gate("D4", "the 8 Dyadic values cited by Genesis are printed verbatim in v6.4.13", not vm, ",".join(vm))
CONTRACT = ["\\rho' = \\rho - \\sin\\eta, \\qquad \\eta' = \\eta + (e^\\rho - 1) - \\sin\\eta",
            "\\mathcal{P}_{\\rm dyad}(R^2)=\\begin{pmatrix}1-R^2/2&\\tau R^2\\\\-\\tau R^2&1-R^2/2\\end{pmatrix}",
            "n_{21}=\\tfrac18-\\tfrac{7i\\sqrt3}{72}", "[RID: DYAD-DEF-BRIDGE-EXPORT-CONTRACT]",
            "None of these items depends on the Lie strict-kernel gauge"]
cm = [c[:40] for c in CONTRACT if c not in dy]
gate("D5", "primitive map, protection matrix, NF6 n21 and bridge-contract gauge statement unchanged in v6.4.13", not cm, "; ".join(cm))
GEN_NU5 = "\\frac{355-159\\sqrt{5}}{48} + i\\frac{(1106\\sqrt{5}-2473)\\sqrt{10+2\\sqrt{5}}}{48}"
DY_NU5 = ["[RID: DYAD-ALG-NU5-P5]", "\\tfrac{355-159\\sqrt5}{48}", "(1106\\sqrt5-2473)\\sqrt{10+2\\sqrt5}", "dyad_m2c_nu5_p5_exact.py"]
gate("D6", "M2c: Genesis formula present; Dyadic registers DYAD-ALG-NU5-P5 with the same numerals and its certificate",
     GEN_NU5 in gen and all(x in dy for x in DY_NU5))
from math import sqrt
g_val = complex((355 - 159*sqrt(5))/48, (1106*sqrt(5) - 2473)*sqrt(10 + 2*sqrt(5))/48)
gate("D6b", "numerical value of the shared closed form", abs(g_val - complex(-0.0111418421347200, 0.0072266912896357)) < 1e-14, f"{g_val:.15g}")
gate("D7", "Dyadic records Genesis v2.8.7 as inspected consumer and issues notice N8 (M2c)",
     "RTG_GENESIS_GEOMETRY_DSN_v2.8.7" in dy and re.search(r"\| N8 ", dy) is not None)
nf = R.count(False); print(f"{'ALL PASS' if not nf else 'FAILURES'} ({len(R)-nf}/{len(R)})"); sys.exit(1 if nf else 0)
