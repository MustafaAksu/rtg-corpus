#!/usr/bin/env python
"""check_v2_8_6_draft.py — gate checker for RTG_GENESIS_GEOMETRY_DSN_v2_8_6_DRAFT.
Usage:
  python check_v2_8_6_draft.py --base v2_8_5.md --draft v2_8_6_DRAFT.md --build build_v2_8_6_draft.py \
      --dyad RTG_DYADIC_OSCILLATOR_DSN_v6_4_11.md [--ofn RTG_ONTOLOGICAL_FOUNDATIONS_v0_9.md] [--k3 k3_obstruction_exact_check.py]
Exit 0 iff every executed gate passes. Optional inputs that are absent are reported SKIP (not PASS)."""
import sys, re, hashlib, argparse, subprocess, importlib.util, collections
ap = argparse.ArgumentParser()
ap.add_argument("--base", required=True); ap.add_argument("--draft", required=True)
ap.add_argument("--build", required=True); ap.add_argument("--dyad", required=True)
ap.add_argument("--ofn"); ap.add_argument("--k3")
a = ap.parse_args()
BASE_SHA = "41ed76602c1c87c42972ac5b3f0a53f6973ac484427473ac371c57db1ab475cf"
DYAD_SHA = "6fccd429758adb729032a68c2a99e24a7bab6f5226aae5df1453b09b189ccb2e"
K3_SHA = "384aaa5f17ecd0786960b3a97fc08a5d332c9e12809a2c92796616f2615a01ee"
R = []
def gate(gid, name, ok, note=""):
    R.append((gid, ok)); print(f"{'PASS' if ok else 'FAIL'}  {gid:4s} {name}" + (f"  [{note}]" if note else ""))
def skip(gid, name, why): print(f"SKIP  {gid:4s} {name}  [{why}]")
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
base = open(a.base, encoding="utf-8").read(); draft = open(a.draft, encoding="utf-8").read()
dyad = open(a.dyad, encoding="utf-8").read()

# load the edit list from the build script without executing its main body
src = open(a.build, encoding="utf-8").read()
edits_src = src.split("for i, old, new in E:")[0].split("t = raw.decode(\"utf-8\")")[1]
ns = {}; exec("E=[]\ndef ed(i,o,n): E.append((i,o,n))\n" + edits_src.split("E = []")[1], ns); E = ns["E"]

# ---- M1: baseline identity and exact reproducibility ----
gate("M1a", "baseline v2.8.5 SHA-256", sha(a.base) == BASE_SHA)
gate("M1b", "Dyadic v6.4.11 SHA-256", sha(a.dyad) == DYAD_SHA)
t = base
for i, o, n in E: t = t.replace(o, n, 1) if t.count(o) == 1 else None or t
gate("M1c", "draft == deterministic build from baseline", t == draft, f"{len(E)} edits")
rev = draft
for i, o, n in reversed(E): rev = rev.replace(n, o, 1)
gate("M1d", "reverse-applying the edit list recovers v2.8.5 byte-exactly (no undeclared change)", rev == base)

# ---- S3: claim-tag audit per edit ----
TAG = re.compile(r"`\[(THM|ALG|RESULT|CERT|HYP|CAND|FAIL|RETRACTED|COR|OPEN|DEF|NUM|INTERP|HEUR|DER)\b")
tags = lambda s: collections.Counter(TAG.findall(s))
CLAIM_ADD = {"K1", "SG15", "HR", "K63a", "EXP", "ART", "APPA", "H5"}
bad_loss, bad_add = [], []
for i, o, n in E:
    to, tn = tags(o), tags(n)
    if any(tn[k] < to[k] for k in to): bad_loss.append(i)
    if i not in CLAIM_ADD and tn != to: bad_add.append(i)
    if any(k in ("COR", "RETRACTED") and tn[k] > to[k] for k in tn): bad_add.append(i + ":COR/RETRACTED")
gate("S3a", "no edit removes an existing claim tag", not bad_loss, ",".join(bad_loss))
gate("S3b", "claim tags added only in authorized G-B01/G-B04/changelog edits; no new [COR]/[RETRACTED]", not bad_add, ",".join(bad_add))
tb, td = tags(base), tags(draft)
gate("S3c", "whole-document tag counts non-decreasing", all(td[k] >= tb[k] for k in tb), str({k: td[k]-tb[k] for k in td if td[k] != tb[k]}))

# ---- M2: Dyadic RIDs and cited values present in v6.4.11 ----
rids = sorted(set(re.findall(r"DYAD-[A-Z0-9-]+[A-Z0-9]", draft)))
missing = [r for r in rids if not re.search(re.escape(r) + r"(?![A-Z0-9-])", dyad)]
gate("M2a", f"all {len(rids)} DYAD RIDs cited in draft exist in v6.4.11", not missing, ",".join(missing))
VALUES = ["559\\sqrt{15}/4860", "86775991", "1/(1-i\\tau)", "119\\sqrt{3}/648", "2\\sqrt{3}/3", "e^{iF_f/2}", "G_{04}(10)", "13+15\\sqrt{3}/2"]
vm = [v for v in VALUES if v not in dyad]
gate("M2b", "cited Dyadic values present verbatim in v6.4.11", not vm, ",".join(vm))
print("NOTE  M2c  nu_5^(5) closed form printed in Genesis §6.2 is NOT printed in Dyadic v6.4.11 (source states only 'exact over Q(sqrt5, sqrt(10+2sqrt5))'); pre-existing provenance gap, unchanged by this draft — owner item")

# ---- M3/M4/M5 ----
live = draft.split("## Appendix A")[0]
gate("M3", "no live import routes frame/v_perp/protection matrix via DYAD-ALG-LIEGAUGE-NORM",
     not re.search(r"\[RID: DYAD-ALG-LIEGAUGE-NORM\] ::", live))
nf6 = [l for l in draft.splitlines() if "DYAD-ALG-NF6" in l]
ok4 = (len(nf6) == 4
       and sum(("normalizing chart" in l) and not l.startswith("- [RID") for l in nf6) == 2
       and sum(l.startswith("- [RID: DYAD-ALG-NF6]") for l in nf6) == 1
       and sum(l.startswith("- **G-B03") for l in nf6) == 1)
gate("M4", "DYAD-ALG-NF6 only at the two h-chart uses + import line + changelog", ok4, f"{len(nf6)} lines")
FORMULA = r"$$T(\rho,\eta)=\bigl(\rho-\sin\eta,\;\eta+e^\rho-1-\sin\eta\bigr).$$"
f_base = True if (FORMULA in base and FORMULA in draft) else None
gate("M5", "GEN-DEF-PRIMITIVE-MAP retained, identical formula, alias recorded",
     "[RID: GEN-DEF-PRIMITIVE-MAP]" in draft and f_base is not None and "import/alias of `DYAD-DEF-PRIMITIVE-MAP`" in draft)

# ---- M6: OFN pointers ----
ofn_live = [l for l in live.splitlines() if "ONTOLOGICAL_FOUNDATIONS" in l]
gate("M6a", "all live OFN pointers name v0.9; none name v0.8 as current", ofn_live and all("v0.9" in l for l in ofn_live) and not any("v0.8`" in l and "from v0.8" not in l for l in ofn_live))
gate("M6b", "OFN pointer remains context-only (no OFN scientific import introduced)", "not proof of Genesis birth laws or UV embeddings" in draft and "no OFN claim is imported into Genesis" in draft)
if a.ofn:
    o = open(a.ofn, encoding="utf-8").read()
    gate("M6c", "OFN v0.9 file: title, CUST-O09-01, IMP-O08-11/13 Genesis imports present",
         "ONTOLOGICAL_FOUNDATIONS" in o and "v0.9" in o[:400] and "CUST-O09-01" in o and "IMP-O08-11" in o and "GEN-THM-LIN-ORDER6" in o, f"sha256 {sha(a.ofn)[:12]}…")
else: skip("M6c", "OFN v0.9 source-scope check", "--ofn not given")

# ---- S1/S2/S4 ----
must = ["GEN-THM-K3-PLANAR-FACTOR-NOGO", "C\\(C^1\\)" if False else "C^1", "u(f_3)=c_0u|u|^2-i\\beta_*Nu", "\\beta_*=\\tfrac{2\\sqrt3}{9}", "\\nu=\\tfrac16-i\\tfrac{\\sqrt3}{3},\\ \\chi=\\tfrac13", "9f95d48d23a340738146271d4bcf1a483b04252e9210c9f403a7f23172dd083a", K3_SHA]
gate("S1a", "§6.3a carries statement, chiral identity, coefficients and pinned provenance", all(m in draft for m in must))
if a.k3:
    ok = sha(a.k3) == K3_SHA
    if ok:
        r = subprocess.run([sys.executable, "-I", a.k3], capture_output=True, text=True)
        n = subprocess.run([sys.executable, "-I", a.k3, "--negative-control"], capture_output=True, text=True)
        ok = r.returncode == 0 and "ALL PASS (8/8)" in r.stdout and n.returncode == 1
    gate("S1b", "k3_obstruction_exact_check.py hash, 8/8 PASS, negative control exit 1", ok)
else: skip("S1b", "rerun exact certificate", "--k3 not given")
new_text = "\n".join(n for _, _, n in E)
FORBID = [r"exclud\w* (a |the )?physical node[- ]exchange", r"node[- ]exchange (is )?(impossible|excluded|forbidden)", r"EF=TE\\?\)? (and|\\iff|⇔|is equivalent to) \\?\(?EF=T\^6E\\?\)? (are|is) equivalent", r"C\^1/C\^2[^.]*excluded", r"selects? (the )?physical carrier"]
NEG = re.compile(r"\b(not|no|neither|nor)\b[^.]{0,40}$")
hits = [p for p in FORBID for m in re.finditer(p, new_text)
        if not NEG.search(new_text[max(0, m.start() - 60):m.start()])]  # negated statements are guards, not claims
hits += ["NEGCTL-FAILED"] if not any(re.search(p, "This excludes a physical node exchange.") for p in FORBID) else []
gate("S2", "no forbidden overclaim in added text", not hits, ";".join(hits))
gate("S4", "Q-2.8.6-01 UV type split absent (only as renamed/formerly mention); no H_V/M_* objects",
     all("formerly `Q-2.8.6-01`" in l for l in draft.splitlines() if "Q-2.8.6-01" in l) and "H_V" not in draft and "M_*" not in draft)

ex = [g for g, ok in R]; nf = [g for g, ok in R if not ok]
print(f"{'ALL EXECUTED GATES PASS' if not nf else 'FAILURES: ' + ','.join(nf)} ({len(ex)-len(nf)}/{len(ex)})")
sys.exit(1 if nf else 0)
