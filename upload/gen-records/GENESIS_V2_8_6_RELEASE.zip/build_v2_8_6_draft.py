#!/usr/bin/env python
"""build_v2_8_6_draft.py — deterministic build of RTG_GENESIS_GEOMETRY_DSN_v2_8_6_DRAFT
from the exact adopted v2.8.5 bytes. Every edit is an exact-match replacement that must
occur exactly once. Usage: python build_v2_8_6_draft.py <v2_8_5.md> <out.md>"""
import sys, hashlib
BASE_SHA = "41ed76602c1c87c42972ac5b3f0a53f6973ac484427473ac371c57db1ab475cf"
src, out = sys.argv[1], sys.argv[2]
raw = open(src, "rb").read()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA, "baseline hash mismatch"
t = raw.decode("utf-8")

E = []  # (id, old, new)
def ed(i, old, new): E.append((i, old, new))

# ---------------- header ----------------
ed("H1", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.5\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.6_DRAFT\n")
ed("H2", "**Date:** 5 October 2026  \n**Document status:** ADOPTED owner ledger — correction/reconciliation release.  \n",
   "**Date:** 16 October 2026 (draft)  \n**Document status:** DRAFT owner successor — Stage B (K3 planar-factor theorem + Dyadic v6.4.11 / OFN v0.9 source synchronization). **Not adopted**; adopted owner remains v2.8.5 (`41ed7660…475cf`).  \n")
ed("H3", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.4` ·", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.5` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.4` ·")
ed("H4", "**Companion documents:** `RTG_PROGRAMME_OVERVIEW_v1.2` · `RTG_ONTOLOGICAL_FOUNDATIONS_v0.8` · `DSN_METHODOLOGY_v1.3` · `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10` ·",
   "**Companion documents:** `RTG_PROGRAMME_OVERVIEW_v1.2` · `RTG_ONTOLOGICAL_FOUNDATIONS_v0.9` · `DSN_METHODOLOGY_v1.3` · `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11` ·")
ed("H5", "Candidates A–C and V20-O1–O5 are not admitted in this release.\n",
   "Candidates A–C and V20-O1–O5 are not admitted in this release. **v2.8.6 draft addition:** the projected-\\(K_3\\) primitive map has no local submersive factor of lower real dimension (§6.3a; \\(C^3\\) for planar targets, \\(C^1\\) for \\(d=1,3\\)); this is a mathematical semiconjugacy exclusion, not a physical node-exchange, carrier or network–dyad selection. Primitive-map custody, bridge-frame/protection-matrix sources and OFN pointers are synchronized to adopted Dyadic v6.4.11 and OFN v0.9.\n")

# ---------------- G-B02 N1 alias ----------------
ed("N1a", "`[DEF]` `[RID: GEN-DEF-PRIMITIVE-MAP]` **Primitive generator.**\n",
   "`[DEF]` `[RID: GEN-DEF-PRIMITIVE-MAP]` **Primitive generator.** *(v2.8.6: recognized as import/alias of `DYAD-DEF-PRIMITIVE-MAP`, Dyadic v6.4.11 §1, which owns the definition — OFN CUST-O09-01 / Dyadic notice N1. The Genesis RID is retained and resolves to the identical formula; Genesis theorem RIDs are unchanged.)*\n")
ed("N1b", "`[DEF]` **RTG dyad generator.**\n", "`[DEF]` **RTG dyad generator.** *(Same formula as `GEN-DEF-PRIMITIVE-MAP` = alias of `DYAD-DEF-PRIMITIVE-MAP`; no further RID.)*\n")

# ---------------- G-B01 §1 summary ----------------
ed("K1", "`[FAIL]` **No $Q_s^3$ safe surface.**",
   "`[THM]` `[RID: GEN-THM-K3-PLANAR-FACTOR-NOGO]` **Projected-\\(K_3\\) planar-factor obstruction (v2.8.6 draft).** The projected triad primitive map \\(F_1=P_{\\mathcal C}T^{\\times3}\\) admits no local \\(C^3\\) submersive semiconjugacy \\(E\\circ F_1=T'\\circ E\\) onto any \\(C^3\\) planar dynamics \\(T'\\), and no local \\(C^1\\) one for target dimension \\(1\\) or \\(3\\). Mathematical exclusion only; see §6.3a and SG-15.\n\n`[FAIL]` **No $Q_s^3$ safe surface.**")

# ---------------- G-B01 §3 SG-15 ----------------
ed("SG15", "Violation: Using reported $|\\alpha_f|\\ge0.012$, $Q_d^*\\approx1.133\\times10^{-2}$, corrected $J_Q$ form, or corrected phase-drift law as certified claims before provenance attachment.\n",
   "Violation: Using reported $|\\alpha_f|\\ge0.012$, $Q_d^*\\approx1.133\\times10^{-2}$, corrected $J_Q$ form, or corrected phase-drift law as certified claims before provenance attachment.\n\n**[SG-15]** **Planar-factor scope guard (v2.8.6 draft).** `GEN-THM-K3-PLANAR-FACTOR-NOGO` concerns local semiconjugacy of the named projected-\\(K_3\\) primitive map at the stated regularity. It does not select or exclude a physical node exchange, carrier, network–dyad bridge or OPEN-B/E1 realization; it does not exclude \\(C^1/C^2\\) planar factors, higher-dimensional targets or other network dynamics; and it does not make the factor contracts \\(EF=TE\\) and \\(EF=T^6E\\) equivalent. It is independent of, and only analogous to, `DYAD-THM-LOCAL-INVOLUTION-GERM`.  \nViolation: Reading the no-go as a physical node-exchange or carrier verdict, extending it below \\(C^3\\) for \\(d=2\\), or presenting it as derived from Dyadic §6.15.\n")

# ---------------- G-B01 §5 row ----------------
ed("HR", "| Genesis II HYP-B mechanism | `[HYP]`: sole viable cascade route after HYP-A/HYP-C `[FAIL]`; requires OPEN M source |",
   "| Projected-$K_3$ planar factor | `[THM]`: no local $C^3$ rank-2 planar factor (any $C^3$ target); no $C^1$ factor for $d=1,3$ | Physical node-exchange exclusion; carrier/OPEN-B/E1 selection; $C^1/C^2$ $d=2$ exclusion | §6.3a, SG-15 |\n| Genesis II HYP-B mechanism | `[HYP]`: sole viable cascade route after HYP-A/HYP-C `[FAIL]`; requires OPEN M source |")

# ---------------- G-B01 §6.3a ----------------
ed("K63a", "### §6.4 Tetrahedral Jacobi Modes and Chronological Protection `[THM / mixed]` {#sec-6-4-tetrahedral}\n",
r"""### §6.3a Projected-$K_3$ Planar-Factor Obstruction `[THM]` {#sec-6-3a-k3-factor}

> **[SG-11 applies]** **[SG-15 applies]** *(v2.8.6 draft; source: `K3_CUBIC_FACTOR_OBSTRUCTION_SESSION_RECORD_v0_1_2.md`, Stage A accepted.)*

`[DEF]` **Model.** \(T\) is the primitive map (`GEN-DEF-PRIMITIVE-MAP`, alias of `DYAD-DEF-PRIMITIVE-MAP`) written in the eigenframe \(W=\mathcal L(\rho,\eta)\). The projected triad carrier is \(\mathcal C=\{(w_1,w_2,w_3):w_1+w_2+w_3=0\}\cong\mathbb C^2\), and
\[
F_1=P_{\mathcal C}\circ T^{\times3}
\]
applies \(T\) to each edge and subtracts the mean. \(DF_1(0)\) is multiplication by \(\lambda=e^{i\pi/3}\).

`[THM]` `[RID: GEN-THM-K3-PLANAR-FACTOR-NOGO]` `[scope: named projected-K3 primitive model; local germs at 0; C^3 for d=2, C^1 for d=1,3]` Let \(E\) be a submersion from a neighbourhood of \(0\in\mathcal C\) onto a manifold of real dimension \(d\in\{1,2,3\}\), and let \(T'\) satisfy \(E\circ F_1=T'\circ E\) near \(0\). Then:
- for \(d=1,3\) no such \(C^1\) pair exists;
- for \(d=2\) no such \(C^3\) pair exists.

No hypothesis is placed on the fixed point, linearization or cubic coefficient of \(T'\).

*Proof.*
- **(a) Fixed point and linear part.** \(p=E(0)\) is \(T'\)-fixed. \(\ell=DE(0)\) is surjective and satisfies \(\ell\lambda=DT'(p)\ell\). Hence \(\ker\ell\) is a \(\lambda\)-invariant real subspace. Since \(\lambda\notin\mathbb R\) it is complex, so its real dimension is even. This excludes \(d=1,3\) at \(C^1\). For \(d=2\), \(DT'(p)\) is conjugate to \(A\) and \(\ell\) is complex-linear (after conjugating an orientation-reversing target coordinate).
- **(b) Leading-term lemma.** If \(G^6=\mathrm{id}+p_k+o(|x|^k)\) commutes with \(G\), \(DG(0)=R\), \(R^6=I\), then \(p_k\circ R=R\circ p_k\). There is no equivariant quadratic, so both returns lack quadratic terms: \(F_1^6=\mathrm{id}+f_3+O(4)\) and \(T'^6=\mathrm{id}+C\,y|y|^2+o(|y|^3)\), with \(C\) unrestricted. No normalizer is used.
- **(c) Cubic factor identity.** \(\ell\circ f_3=C\,\ell|\ell|^2\); the \(E_2\) and \(E_3\) contributions cancel at degree three.
- **(d) Source cubic.**
\[
f_{3,e}=\nu\Big(w_e|w_e|^2-\tfrac13\sum_jw_j|w_j|^2\Big)+\tfrac{2i\chi}{3}(w_{e+1}-w_{e-1})\,\Im(w_1\bar w_2),\qquad \nu=\tfrac16-i\tfrac{\sqrt3}{3},\ \chi=\tfrac13 .
\]
With \(u=w_1+\lambda w_2\), \(v=w_1+\bar\lambda w_2\) and \(N=\sum_e|w_e|^2=|u|^2+|v|^2\):
\[
u(f_3)=c_0u|u|^2-i\beta_*Nu,\qquad v(f_3)=c_0v|v|^2-i\beta_*Nv,\qquad c_0=\tfrac16+i\tfrac{\sqrt3}{9},\ \beta_*=\tfrac{2\sqrt3}{9}.
\]
- **(e) Elimination.** For \(\ell=\alpha u+\beta v\), the \(u^2\bar v\) and \(v^2\bar u\) coefficients give \(C\alpha^2\bar\beta=C\beta^2\bar\alpha=0\). If \(C\neq0\), take \(\beta=0\), \(\alpha\neq0\); the \(u|v|^2\) coefficient is \(-i\beta_*\alpha\) on the left and \(0\) on the right. If \(C=0\), the \(u|v|^2\) and \(v|u|^2\) coefficients force \(\alpha=\beta=0\). Hence \(\ell=0\), contradicting surjectivity. \(\square\)

`[ALG]` **Structural reading.** The obstruction is the chiral phase coupling \(\beta_*\neq0\) through \(N=|u|^2+|v|^2\). Each \(|u|^2,|v|^2\) is autonomous at cubic order, so the radial data factor and the phases do not. \((\nu,\chi)\) are triad-network coefficients, not the dyad \(\mu_6\).

`[DEF]` **Evidence.**
- Exact source-data certificate: `k3_obstruction_exact_check.py`, SHA-256 `384aaa5f17ecd0786960b3a97fc08a5d332c9e12809a2c92796616f2615a01ee`. It derives \(f_3\) from the primitive with no imported jet. Result: 8/8 PASS, and the \(\chi=1/4\) negative control exits 1.
- Confirmatory checks: `fac.py` (real Gröbner elimination), `exact_chiral.py`, and `k3.py` `[NUM]` (untruncated map; dyad cross-check \(\mu_{\rm num}=\mu_6\)).
- Historical coefficient source: ER-2B Observable Response v1.

`[OPEN]` \(C^1/C^2\) planar factors; non-submersive or non-local factor maps; other network or incidence dynamics; other carriers, including the formal odd carrier; the physical node-exchange action and G2 realization (RRF/OFN).

`[INTERP]` Companion contrast: the isolated dyad contracts (\(\Re\mu_6<0\)), while the projected triad has local radial outflow (ER-2B OBS-1, noncanonical). This theorem shows that no \(C^3\) planar factor connects them.

### §6.4 Tetrahedral Jacobi Modes and Chronological Protection `[THM / mixed]` {#sec-6-4-tetrahedral}
""")

# ---------------- G-B03 N2 / NF6 ----------------
ed("N2a", "| Dyadic module | $\\mu_6$, $\\tau$, $v_\\perp$, antisymmetric channel | Dyadic DSN `[RID: DYAD-THM-C21]` |",
   "| Dyadic module | $\\mu_6$, $\\tau$ (`DYAD-THM-C21`); $W$-frame, $v_\\perp$ (`DYAD-DEF-BRIDGE-EXPORT-CONTRACT`); antisymmetric channel (Genesis-native, §6.2) | Dyadic DSN v6.4.11 |")
ed("N2b", "$$s = \\rho - \\tfrac{1}{2}\\eta, \\quad c = \\tfrac{\\sqrt{3}}{2}\\eta, \\quad v_\\perp = \\bigl(\\tfrac{1}{\\sqrt{3}},\\tfrac{2}{\\sqrt{3}}\\bigr).$$\n",
   "$$s = \\rho - \\tfrac{1}{2}\\eta, \\quad c = \\tfrac{\\sqrt{3}}{2}\\eta, \\quad v_\\perp = \\bigl(\\tfrac{1}{\\sqrt{3}},\\tfrac{2}{\\sqrt{3}}\\bigr).$$\n*(Source of the frame and \\(v_\\perp\\): `DYAD-DEF-BRIDGE-EXPORT-CONTRACT` item 1, no gauge choice.)*\n")
ed("NF6a", "For the adopted isolated-dyad normalizing chart \\(W=h(z,\\bar z)\\) on its declared local domain,",
   "For the adopted isolated-dyad normalizing chart \\(W=h(z,\\bar z)\\) on its declared local domain (`DYAD-ALG-NF6`),")
ed("NF6b", "where \\(h\\) is the adopted isolated-dyad normalizing chart on its declared domain;",
   "where \\(h\\) is the adopted isolated-dyad normalizing chart on its declared domain (`DYAD-ALG-NF6`);")
ed("N2c", "- [RID: DYAD-ALG-LIEGAUGE-NORM] :: Birkhoff frame, $v_\\perp$, antisymmetric channel, protection matrix :: §6.2 canonical $p=6$ eigenframe; `[conv: Lie strict-kernel gauge]`\n",
   "- [RID: DYAD-DEF-PRIMITIVE-MAP] :: primitive map definition (Genesis alias `GEN-DEF-PRIMITIVE-MAP`) :: §1, §6.1, §6.3a\n- [RID: DYAD-DEF-BRIDGE-EXPORT-CONTRACT] :: primitive linear frame \\(W=\\mathcal L(\\rho,\\eta)\\), $v_\\perp$ (contract item 1; no gauge choice) :: §6.2 canonical $p=6$ eigenframe\n- [RID: DYAD-ALG-PROTECTION-MATRIX] :: $p$-step protection matrix (linear eigenframe, cubic order) :: §6.2 dyadic module\n- [RID: DYAD-ALG-NF6] :: adopted isolated-dyad normalizing chart \\(h\\) :: §6.2–§6.3 \\(E_{\\rm NF}\\)\n- *(v2.8.6 repin, Dyadic notice N2: these items were previously routed through `DYAD-ALG-LIEGAUGE-NORM` with `[conv: Lie strict-kernel gauge]`; that RID is now the archival Lie-gauge normalization only and is not imported here. The antisymmetric-channel theorem of §6.2 is Genesis-native and not an import.)*\n")

# ---------------- pointer refresh Dyadic v6.4.10 -> v6.4.11 (live lines only) ----------------
ed("P211", "(repinned to Dyadic DSN v6.4.10; scientific import scope corrected in v2.8.5 release)", "(repinned to Dyadic DSN v6.4.11 [v2.8.6; previously v6.4.10]; scientific import scope corrected in v2.8.5 release)")
ed("P276", "Status: PARTIAL — see `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10` for the primary ledger", "Status: PARTIAL — see `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11` for the primary ledger")
ed("P662", "primary ledger in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10`):", "primary ledger in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`):")
ed("P951", "### From `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10`\n", "### From `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`\n")
ed("P993", "- **OPEN 16 — Dyadic alias phase decomposition:** closed in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10`", "- **OPEN 16 — Dyadic alias phase decomposition:** closed in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`")
ed("P994", "- **OPEN 17 — Dyadic $a_2$ computation:** closed under its declared convention in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.10`", "- **OPEN 17 — Dyadic $a_2$ computation:** closed under its declared convention in `RTG_DYADIC_OSCILLATOR_DSN_v6.4.11`")
ed("P1024", "— imported from Dyadic DSN v6.4.10\n", "— imported from Dyadic DSN v6.4.11 (`DYAD-CAND-P0-DYADIC`, conditional only; previously pinned v6.4.10)\n")
# OFN pointer (live)
ed("P989", "- `RTG_ONTOLOGICAL_FOUNDATIONS_v0.8` — current foundational context; not proof of Genesis birth laws or UV embeddings.",
   "- `RTG_ONTOLOGICAL_FOUNDATIONS_v0.9` — current foundational context; not proof of Genesis birth laws or UV embeddings. *(v2.8.6 mechanical refresh from v0.8; OFN v0.9 imports Genesis identities IMP-O08-11/13 and records CUST-O09-01, answered here by the §1 alias; no OFN claim is imported into Genesis.)*")

# ---------------- G-B04 export ----------------
ed("EXP", "`[DEF]` Any exported claim involving TDR-G must cite a named discrete-continuous bridge theorem. No such bridge is currently registered.\n",
   "`[DEF]` Any exported claim involving TDR-G must cite a named discrete-continuous bridge theorem. No such bridge is currently registered.\n\n`[DEF]` **(v2.8.6 draft) RRF G2-CLOCK export.** Genesis exports `GEN-THM-K3-PLANAR-FACTOR-NOGO` with exactly the scope of §6.3a: the projected-\\(K_3\\) primitive map has no local submersive factor of strictly lower real dimension (\\(d=1,3\\) at \\(C^1\\); \\(d=2\\) at \\(C^3\\); \\(C^1/C^2\\) for \\(d=2\\) OPEN). RRF may cite the result without repeating the proof. Genesis does not select RRF's physical admissibility condition, a carrier, or a physical node-exchange action (SG-15).\n")

# ---------------- §8 artifact ----------------
ed("ART", "- [RID: GEN-ART-REGGE-BRIDGE] :: minimal curvature cluster / RTG-to-Regge map scaffold :: `[OPEN]`\n",
   "- [RID: GEN-ART-REGGE-BRIDGE] :: minimal curvature cluster / RTG-to-Regge map scaffold :: `[OPEN]`\n- [RID: GEN-THM-K3-PLANAR-FACTOR-NOGO] :: projected-\\(K_3\\) planar-factor obstruction (v2.8.6 draft) :: `[THM]` `[scope: §6.3a]` — proof: §6.3a / SESSION record v0.1.2 (`9f95d48d23a340738146271d4bcf1a483b04252e9210c9f403a7f23172dd083a`); exact data certificate `k3_obstruction_exact_check.py` (`384aaa5f…01ee`); confirmatory `fac.py` (`91608cb7…7f2b`), `exact_chiral.py` (`e5e268a6…af7d`), `k3.py` `[NUM]` (`dcb08a27…1038`) in `K3_factor_obstruction.zip` (`046ac458…85cc`; no internal manifest, `fac.py` receipt pending — confirmatory only); historical coefficient source `ER2B_OBSERVABLE_RESPONSE_v1.zip` (`06d5e0c9…82b1`)\n")

# ---------------- Appendix A ----------------
ed("APPA", "### v2.8.5 — 5 October 2026 — Adopted correction/reconciliation owner release\n",
r"""### v2.8.6 — DRAFT, 16 October 2026 — Stage B (not adopted)

Built deterministically from the exact adopted v2.8.5 bytes (`41ed7660…475cf`) by `build_v2_8_6_draft.py`. Owner decisions D1–D4 of 16 Oct 2026 apply.

- **G-B01:** new `[THM]` `GEN-THM-K3-PLANAR-FACTOR-NOGO` (§6.3a), with entries in §1, §5, §7 and §8 and new SG-15. Source: Stage-A SESSION record v0.1.2.
- **G-B02 (Dyadic N1):** `GEN-DEF-PRIMITIVE-MAP` recognized as import/alias of `DYAD-DEF-PRIMITIVE-MAP`; the Genesis RID is retained.
- **G-B03 (Dyadic N2):** frame and \(v_\perp\) → `DYAD-DEF-BRIDGE-EXPORT-CONTRACT`; protection matrix → `DYAD-ALG-PROTECTION-MATRIX`; antisymmetric channel recorded as Genesis-native (D3); `DYAD-ALG-NF6` cited only where the chart \(h\) is used; `DYAD-ALG-LIEGAUGE-NORM` no longer imported.
- **G-B04:** RRF G2-CLOCK export line (§7) without any physical selection.
- **G-B05:** provenance hashes in §8.
- **Mechanical:** live Dyadic pointers v6.4.10 → v6.4.11; OFN v0.8 → v0.9 (D2). Historical version-history text unchanged.
- **Not in this draft:** UV-interface type split (`Q-SUCC-UV-01`, formerly `Q-2.8.6-01`; trigger not met); V20-O1–O5; Candidates A–C; OPEN-B/E1; Problem B; Dyadic OPEN 19.
- **No v2.8.5 claim corrected, regraded or retracted.**

### v2.8.5 — 5 October 2026 — Adopted correction/reconciliation owner release
""")

# ---------------- footer ----------------
ed("FOOT", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.5*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.4.",
   "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.6_DRAFT*  \n*Draft successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.5 (not adopted). v2.8.6 adds GEN-THM-K3-PLANAR-FACTOR-NOGO and Dyadic v6.4.11 / OFN v0.9 source synchronization only. Inherited v2.8.5 footer follows:*  \n*Adopted successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.4.")

for i, old, new in E:
    n = t.count(old)
    assert n == 1, f"{i}: expected 1 match, found {n}"
    t = t.replace(old, new)
open(out, "w", encoding="utf-8", newline="").write(t)
print(f"applied {len(E)} edits -> {out}  sha256={hashlib.sha256(t.encode()).hexdigest()}")
