#!/usr/bin/env python
"""release_v2_8_9.py — metadata-only adoption transform: reviewed v2.8.9 DRAFT -> adopted v2.8.9.
Usage: python release_v2_8_9.py <draft.md> <out.md> --date "<D Month YYYY>" --decision "<owner decision text>" [--preview]
--preview prepends a one-line non-adoption banner; without it the output is the adopted release.
A non-preview run refuses placeholder decision text."""
import sys, re, hashlib, argparse
DRAFT_SHA = "b2cc5c5cb637459b3e2aded30b1c48ad859f2591a93684f463f89fbab503f62a"
PACKAGE_SHA = "a3ceb92e66d7cd2caf4d96d5e65f6d17607b5b7e50f2f88a6f0582335573e973"
CERT_SHA = "f4c382855b130249ce290d3ca939b283aadd27d6ea9a1af551599f4cd9533f6d"
PLACEHOLDER = "[PENDING OWNER DECISION]"
BANNER = "> **ADOPTION PREVIEW — NOT ADOPTED.** This file shows the exact release bytes below this line; adoption requires the owner decision. Adopted owner remains v2.8.8.\n\n"
def edits(date, decision):
    E = []
    def ed(i, o, n): E.append((i, o, n))
    ed("R-title", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.9_DRAFT\n", "# RTG_GENESIS_GEOMETRY_DSN_v2.8.9\n")
    ed("R-date", "**Date:** 19 October 2026 (draft)  \n**Document status:** DRAFT owner successor — scientific (D-4: transported chiral factor obstruction, §6.3c). **Not adopted**; adopted owner remains v2.8.8 (`9abd3616…0f37`).  \n",
       f"**Date:** {date}  \n**Document status:** ADOPTED owner ledger — scientific release (D-4: transported chiral factor obstruction, §6.3c).  \n")
    ed("R-supersedes", "**Supersedes (on adoption):** `RTG_GENESIS_GEOMETRY_DSN_v2.8.8` ·", "**Supersedes:** `RTG_GENESIS_GEOMETRY_DSN_v2.8.8` ·")
    ed("R-summary", "*(v2.8.8 adopted maintenance release on the v2.8.7 base;",
       "*(v2.8.9 adopted scientific release on the v2.8.8 base; v2.8.8 is the adopted maintenance release on the v2.8.7 base;")
    ed("R-p11", "**v2.8.9 draft addition:**", "**v2.8.9 addition:**")
    ed("R-appA", "### v2.8.9 — 19 October 2026 — DRAFT record (not adopted)\n",
       f"### v2.8.9 — {date} — Adopted scientific release\n\n**Adoption:** {decision}. Scientific payload is the reviewed DRAFT bytes `{DRAFT_SHA}` "
       f"(independent receiving review, 19 October 2026: `check_v2_8_9_draft.py --final --cert` 11/11 PASS, 0 SKIP; certificate `d4_transported_cubic_cert.py` (`{CERT_SHA}`) rerun 6/6 PASS; package `{PACKAGE_SHA}`, 12/12 SHA256SUMS entries verified). "
       "Negative controls: the package record shows 8/8 caught; the reviewer's independent full replay did not complete within the execution time limit, which is recorded as an execution-coverage limitation with no observed control failure. "
       "The adoption transform `release_v2_8_9.py` changes metadata, status, history and footer only; `check_release_v2_8_9.py` proves it. "
       "In force from this release: `GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO` (§6.3c; six-step; real C³ germs with the stated third jet; γ ∉ {0,2}; μ ≠ 0; (H_spec)); the primitive-clock companion remains an algebraic statement without RID. "
       "No v2.8.8 claim, claim tag or RID changed; the Dyadic pins remain v6.4.13 (repin deferred). Outbound notices (OFN informational, Q6 regularity remaining an OFN decision; RRF and FMS informational) are issued after adoption.\n\n"
       "#### v2.8.9 — DRAFT record, 19 October 2026 — scientific (D-4)\n")
    ed("R-foot", "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.9_DRAFT*  \n*Draft scientific successor to adopted RTG_GENESIS_GEOMETRY_DSN_v2.8.8 (not adopted).",
       "*END OF DOCUMENT — RTG_GENESIS_GEOMETRY_DSN_v2.8.9*  \n*Adopted scientific successor to RTG_GENESIS_GEOMETRY_DSN_v2.8.8.")
    return E
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("draft"); ap.add_argument("out")
    ap.add_argument("--date", required=True); ap.add_argument("--decision", required=True); ap.add_argument("--preview", action="store_true")
    a = ap.parse_args()
    if not a.preview:
        assert PLACEHOLDER not in a.decision, "placeholder decision text: run with --preview or give the owner decision"
        assert re.fullmatch(r"\d{1,2} [A-Z][a-z]+ 20\d\d", a.date), "date must look like '19 October 2026'"
    raw = open(a.draft, "rb").read(); assert hashlib.sha256(raw).hexdigest() == DRAFT_SHA, "draft hash mismatch"
    t = raw.decode("utf-8")
    for i, o, n in edits(a.date, a.decision):
        assert t.count(o) == 1, f"{i}: {t.count(o)} matches"; t = t.replace(o, n)
    rel_sha = hashlib.sha256(t.encode()).hexdigest()
    if a.preview: t = BANNER + t
    open(a.out, "w", encoding="utf-8", newline="").write(t)
    print(f"release bytes sha256={rel_sha}" + ("  (written as PREVIEW with banner)" if a.preview else ""))
