# Bounded local proxy measurements (SESSION; not source-backed)

The source-backed first-F-block campaign has been owner replayed in PR #305. This F2 exploratory campaign instead uses the V2 test file `approximate_18sig_coefs.txt` converted into exact-dyadic interval endpoints with a deliberately wide ±`1e-15` component pad. These proxy intervals do NOT come from the pinned 80-digit Stage-2 source, and these measurements do NOT constitute a real-source run. The same unchanged `direct6` and F1 necessary contractor are used.

| First tiling | Second subdivision | F1 excluded | F1 retained | F2 subtile excluded | F2 subtile retained | F2 unresolved | Final L1-based hull radius |
|---|---|---:|---:|---:|---:|---:|---:|
| 8×8 (60 active) | 2×2 | 44 | 16 | 0 | 64 | 0 | 1.526195e-3 |
| 8×8 (60 active) | 4×4 | 44 | 16 | 96 | 160 | 0 | 1.296769e-3 |
| 10×10 (96 active) | 4×4 | 80 | 16 | 128 | 128 | 0 | 9.656854e-4 |

The 8×8/2×2 executable completed with exit 0 and its output passed `check_f2_details.py`. The 4×4 action counts/hulls were independently reconstructed from complete per-row TSV outputs; the originating long-running command's terminal exit code was **not captured**, so no full-run PASS is claimed for either 4×4 proxy campaign. Local bounded C++ math/partition tests passed in optimized mode and with ASan/UBSan; the source SHA and transfer are not independently reverified by these proxy calculations. The delivered Ubuntu CLI is the authoritative place to run 8×8/4×4 and 10×10/4×4 on the actual pinned coefficient file.

**Rectangular L1 hull convention:** `enclosing_disk(box)` uses the L1 norm of the half-side widths, not the smaller Euclidean radius. A preliminary comparison incorrectly used Euclidean radii; those values are withdrawn. The numbers above match the delivered kernel's L1 convention.

**Conditional:** every numerical discard uses the one-step/two-step necessary conditions only if the candidate's graph orbit lies in the owner `D0` tube at each step. No curve existence, 334-block result, inverse G, point jump, B-an or B-6 conclusion.
