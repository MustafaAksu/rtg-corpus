#!/usr/bin/env python3
"""[SESSION] Independent, exact-integer structural consistency check on F2 output.
Not a mathematical validation of M bounds, graph existence or the source pads.
"""
import sys
from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal
S = 1 << 256


def hull_radius(rows, use_final):
    cols = (10, 11, 12, 13) if use_final else (6, 7, 8, 9)
    xs = [[int(row[q]) for q in cols] for row in rows]
    if not xs:
        raise ValueError('empty hull')
    xlo, xhi = min(x[0] for x in xs), max(x[1] for x in xs)
    ylo, yhi = min(x[2] for x in xs), max(x[3] for x in xs)
    mx = (xlo + xhi) // 2
    my = (ylo + yhi) // 2
    return max(abs(xlo-mx), abs(xhi-mx)) + max(abs(ylo-my), abs(yhi-my))


def approx_printed(floatstr, integer):
    # C++'s decimal output is six digits after decimal point in scientific
    # notation (7 significant digits); compare at a modest rounding tolerance.
    val = Decimal(integer) / Decimal(S)
    shown = Decimal(floatstr)
    return abs(shown - val) <= max(Decimal('5e-6') * abs(val), Decimal('1e-15'))


def main(out_path, detail_path):
    out = Path(out_path).read_text().splitlines()
    assert 'HORIZON=2' in out[0], 'expected two-block output'
    header = out[1].split(); record = out[2].split()
    values = dict(zip(header, record))
    grid = int(values['grid']); sub = int(values['subdiv'])
    rows = [line.split() for line in Path(detail_path).read_text().splitlines()[1:]]
    assert rows and all(len(r) == 14 for r in rows)
    first = defaultdict(set)
    first_events, second_events = {}, Counter()
    for r in rows:
        idx, sid = int(r[0]), int(r[1]); a, b = r[2:4]
        assert a in {'EXCLUDED', 'RETAINED', 'UNRESOLVED'}
        assert idx not in first or sid not in first[idx]
        first[idx].add(sid)
        if idx in first_events: assert first_events[idx] == a
        first_events[idx] = a
        if a == 'RETAINED': assert 0 <= sid < sub*sub
        else: assert sid == -1 and b in {'NOT_NEEDED','NOT_RUN'}
        second_events[b] += 1
        # The stored final candidate box MUST be inside the corresponding
        # intermediate box in every retained/unresolved row.
        if a != 'EXCLUDED':
            assert int(r[6]) <= int(r[10]) <= int(r[11]) <= int(r[7])
            assert int(r[8]) <= int(r[12]) <= int(r[13]) <= int(r[9])
    assert len(first) == int(values['active'])
    assert sum(a=='EXCLUDED' for a in first_events.values()) == int(values['first_excluded'])
    assert sum(a=='RETAINED' for a in first_events.values()) == int(values['first_retained'])
    assert sum(a=='UNRESOLVED' for a in first_events.values()) == int(values['first_unresolved'])
    assert int(values['first_evaluated'])+int(values['first_unresolved']) == int(values['active'])
    assert int(values['first_evaluated']) == int(values['first_excluded'])+int(values['first_retained'])
    assert int(values['second_subtiles']) == int(values['first_retained']) * sub * sub
    assert int(values['second_evaluated'])+int(values['second_unresolved']) == int(values['second_subtiles'])
    assert int(values['second_evaluated']) == int(values['second_excluded'])+int(values['second_retained'])
    assert second_events['EXCLUDED'] == int(values['second_excluded'])
    assert second_events['RETAINED'] == int(values['second_retained'])
    assert second_events['UNRESOLVED'] == int(values['second_unresolved'])
    first_hull_rows = [r for r in rows if r[2] in {'RETAINED','UNRESOLVED'}]
    final_hull_rows = [r for r in rows if r[3] in {'RETAINED','UNRESOLVED'} or r[2] == 'UNRESOLVED']
    r1=hull_radius(first_hull_rows,False)
    r2=hull_radius(final_hull_rows,True)
    assert r2<=r1, 'final candidate set must lie inside initial candidate hull'
    assert approx_printed(values['first_hull_radius'],r1)
    assert approx_printed(values['final_hull_radius'],r2)
    m1=[int(r[4]) for r in rows if int(r[4])>0]
    m2=[int(r[5]) for r in rows if int(r[5])>0]
    assert m1 and m2
    for key, v in [('M1_min',min(m1)),('M1_max',max(m1)),('M2_min',min(m2)),('M2_max',max(m2))]:
        assert approx_printed(values[key],v), (key,values[key])
    print('F2_DETAILS_STRUCTURE_PASS', 'grid',grid,'subdiv',sub,'rows',len(rows),
          'first_excluded',values['first_excluded'],'second_excluded',values['second_excluded'],
          'final_hull_L1',values['final_hull_radius'])
    print('SESSION_ONLY: no independent numerical/analytic proof of tube bounds')
    return 0

if __name__ == '__main__':
    if len(sys.argv)!=3:
        print('Usage: check_f2_details.py RESULT_STDOUT DETAILS_TSV',file=sys.stderr)
        sys.exit(64)
    try:sys.exit(main(sys.argv[1],sys.argv[2]))
    except (ValueError,AssertionError,IndexError,KeyError) as e:
        print('F2_DETAILS_STRUCTURE_FAIL:',str(e),file=sys.stderr)
        sys.exit(1)
