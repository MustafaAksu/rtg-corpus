// [SESSION] DYAD OPEN 20 -- conditional F-leg TWO-BLOCK necessary-condition contractor.
// Unchanged stage-one source is included under a renamed main, not rewritten.
// All exclusions are conditional on the graph/tube hypotheses in the owner proof record.
#define main f1_original_main
#include "real_f1_tube.cpp"
#undef main

namespace f2 {
using namespace dyad;
using namespace dyad::centered;

struct Counts {
  size_t active=0, first_evaluated=0, first_excluded=0, first_retained=0,
         first_unresolved=0, second_subtiles=0, second_evaluated=0, second_excluded=0,
         second_retained=0, second_unresolved=0;
  Z m1min=0,m1max=0,m2min=0,m2max=0;
  std::optional<C> h1,h2;
};
void update_bounds(Z& lo,Z& hi,const Z& v){if(lo==0 || v<lo)lo=v;if(v>hi)hi=v;}

// A single F block propagates a rigorous flow on an entire disk.
// Return only its lift; never reset the tangent to the midpoint.
State iter(const C& x,const Disk& D,const std::vector<C>& phi,int blocks){
  Flow f=from_lift(x,D,phi);
  for(int k=0;k<blocks;++k)f=direct6(std::move(f));
  return lifted_readout(f,phi);
}

// Outward-rounded partition of a rectangular box, with shared edges possibly
// overlapping by at most one dyadic unit. The union covers the ORIGINAL box.
std::vector<C> split_box(const C&b,size_t n){
  if(n==0||n>16)throw std::invalid_argument("subdivision outside [1,16]");
  std::vector<C> ans;
  Z dx=b.re.h-b.re.l,dy=b.im.h-b.im.l;
  for(size_t i=0;i<n;++i)for(size_t j=0;j<n;++j){
    Z xl=b.re.l+fd(dx*Z(i),Z(n)),xh=b.re.l+cd(dx*Z(i+1),Z(n));
    Z yl=b.im.l+fd(dy*Z(j),Z(n)),yh=b.im.l+cd(dy*Z(j+1),Z(n));
    ans.push_back(C(I(xl,xh),I(yl,yh)));
  }
  return ans;
}

// All candidate sets are kept as interval boxes, never silently replaced by
// their intersected enclosing discs. The enclosing disc is for evaluation ONLY.
Counts execute(const Data& data,size_t grid,size_t subdivision,const std::string& detail_path){
  f1::ForwardTube TB(data.c);
  auto t=tiles(grid);Counts S;S.active=t.size();
  std::ofstream out(detail_path);
  if(!out)throw std::runtime_error("cannot create details file");
  out<<"tile subtile first_action second_action M1_256 M2_256 in_re_lo_256 in_re_hi_256 in_im_lo_256 in_im_hi_256 final_re_lo_256 final_re_hi_256 final_im_lo_256 final_im_hi_256\n";
  for(size_t i=0;i<t.size();++i){
    const Disk& tile=t[i];
    C initial=tile.box();
    C after1=initial, after2=initial;
    std::string st1="UNRESOLVED",st2="NOT_RUN";
    Z m1=0,m2=0;
    try{
      State R=iter(TB.at_start(),tile,data.phi,1);
      auto upper=TB.upper(R.a.v);m1=upper.M;
      State P=iter(TB.at_start(),Disk(tile.c,0),data.phi,1);
      C slope=mid(P.b.d);
      if(abs_lower(slope)<=0)throw std::domain_error("first slope includes zero");
      Disk necessary=necessary_disk(tile,P.b.v,R.b.d,slope,m1);
      ++S.first_evaluated;
      update_bounds(S.m1min,S.m1max,m1);
      auto hit=intersection(initial,necessary.box());
      if(!hit){st1="EXCLUDED";st2="NOT_NEEDED";++S.first_excluded;}
      else {st1="RETAINED";after1=*hit;++S.first_retained;f1::add_hull(S.h1,after1);}
    }catch(const std::domain_error& e){
      ++S.first_unresolved;f1::add_hull(S.h1,after1);
      st1="UNRESOLVED";st2="NOT_RUN";
      if(S.first_unresolved<=8)std::cerr<<"UNRESOLVED first tile="<<i<<" "<<e.what()<<"\n";
    }
    if(st1=="RETAINED"){
      auto parts=split_box(after1,subdivision);
      for(size_t sj=0;sj<parts.size();++sj){
        ++S.second_subtiles;
        const C& part=parts[sj];
        after2=part;st2="UNRESOLVED";m2=0;
        try {
          // The circumscribed disk may contain false candidates; that only
          // enlarges the enclosure, never removes a valid candidate.
          Disk reduced=ball(part);
          State R2=iter(TB.at_start(),reduced,data.phi,2);
          auto upper=TB.upper(R2.a.v);m2=upper.M;
          State P2=iter(TB.at_start(),Disk(reduced.c,0),data.phi,2);
          C slope=mid(P2.b.d);
          if(abs_lower(slope)<=0)throw std::domain_error("second slope includes zero");
          Disk necessary2=necessary_disk(reduced,P2.b.v,R2.b.d,slope,m2);
          ++S.second_evaluated;
          update_bounds(S.m2min,S.m2max,m2);
          auto hit2=intersection(part,necessary2.box());
          if(!hit2){st2="EXCLUDED";++S.second_excluded;}
          else {after2=*hit2;st2="RETAINED";++S.second_retained;f1::add_hull(S.h2,after2);}
        }catch(const std::domain_error& e){
          ++S.second_unresolved;st2="UNRESOLVED";f1::add_hull(S.h2,after2);
          if(S.second_unresolved<=8)std::cerr<<"UNRESOLVED second tile="<<i<<" sub="<<sj<<" "<<e.what()<<"\n";
        }
        out<<i<<' '<<sj<<' '<<st1<<' '<<st2<<' '<<m1<<' '<<m2<<' '
           <<part.re.l<<' '<<part.re.h<<' '<<part.im.l<<' '<<part.im.h<<' '
           <<after2.re.l<<' '<<after2.re.h<<' '<<after2.im.l<<' '<<after2.im.h<<'\n';
      }
    } else {
      // First-stage unresolved: original tile remains possible. First-stage
      // excluded: no candidate remains in this tile under the hypothesis.
      if(st1=="UNRESOLVED"){
        after2=initial;f1::add_hull(S.h2,after2);
      }
      out<<i<<" -1 "<<st1<<' '<<st2<<' '<<m1<<' '<<m2<<' '
         <<initial.re.l<<' '<<initial.re.h<<' '<<initial.im.l<<' '<<initial.im.h<<' '
         <<after2.re.l<<' '<<after2.re.h<<' '<<after2.im.l<<' '<<after2.im.h<<'\n';
    }
  }
  if(!S.h2)throw std::domain_error("empty final candidate cover (not a jump or nonexistence proof)");
  return S;
}
} // namespace f2


#ifndef DYAD_F2_NO_MAIN
int main(int argc,char**argv){
  if(argc!=5){std::cerr<<"Usage: real_f2_tube TRANSFER GRID(8|10|16) SUBDIV(1|2|4) DETAILS_PATH\n";return 64;}
  try{
    size_t grid=std::stoul(argv[2]);if(grid!=8&&grid!=10&&grid!=16)throw std::invalid_argument("allowed grids 8,10,16");
    size_t subdivision=std::stoul(argv[3]);if(subdivision!=1&&subdivision!=2&&subdivision!=4)throw std::invalid_argument("subdiv=1,2,4 only");
    Data dat=read_data(argv[1]);
    auto pi=f1::pi_interval();if(!(pi.l> Z(3)*SCALE && pi.h< Z(4)*SCALE))throw std::runtime_error("pi gate");
    f2::Counts s=f2::execute(dat,grid,subdivision,argv[4]);
    std::cout<<"METHOD=primitive_per_T; HORIZON=2; status=SESSION_CONDITIONAL\n";
    std::cout<<"grid subdiv active first_evaluated first_excluded first_retained first_unresolved second_subtiles second_evaluated second_excluded second_retained second_unresolved M1_min M1_max M2_min M2_max first_hull_radius final_hull_radius\n";
    std::cout<<grid<<' '<<subdivision<<' '<<s.active<<' '<<s.first_evaluated<<' '<<s.first_excluded<<' '<<s.first_retained<<' '<<s.first_unresolved<<' '<<s.second_subtiles<<' '<<s.second_evaluated<<' '<<s.second_excluded<<' '<<s.second_retained<<' '<<s.second_unresolved<<' '
             <<f1::outdec(s.m1min)<<' '<<f1::outdec(s.m1max)<<' '<<f1::outdec(s.m2min)<<' '<<f1::outdec(s.m2max)<<' '
             <<(s.h1?f1::outdec(enclosing_disk(*s.h1).r):"EMPTY")<<' '<<f1::outdec(enclosing_disk(*s.h2).r)<<'\n';
    std::cout<<"NO_CERTIFICATE; conditional D0 graph, two tube bounds, source-transfer assumptions.\n";
    return s.first_unresolved||s.second_unresolved?2:0;
  }catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<"\n";return 2;}
   catch(const std::exception&e){std::cerr<<"INPUT_FAIL: "<<e.what()<<"\n";return 3;}
}

#endif // DYAD_F2_NO_MAIN
