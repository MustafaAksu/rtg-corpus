// [SESSION] Exhaustive grid-edge and basic enclosure checks for the F2 subdivision.
#define DYAD_F2_NO_MAIN
#include "real_f2_tube.cpp"
#include <iostream>
#include <cassert>
int main(){
  for(const int n : {1,2,4}) {
    C B(I::rat(-1,500), I::rat(3,2000));
    auto grid=f2::split_box(B,n);
    assert(grid.size()==size_t(n*n));
    // Every original dyadic test point is in at least one returned closed box.
    for(int i=0;i<=16;++i)for(int j=0;j<=16;++j){
      Z x=B.re.l+fd((B.re.h-B.re.l)*Z(i),Z(16));
      Z y=B.im.l+fd((B.im.h-B.im.l)*Z(j),Z(16));
      bool found=false;
      for(const auto&box:grid)if(box.re.l<=x&&x<=box.re.h&&box.im.l<=y&&y<=box.im.h)found=true;
      assert(found);
    }
    assert(grid.front().re.l<=B.re.l && grid.front().im.l<=B.im.l);
    assert(grid.back().re.h>=B.re.h && grid.back().im.h>=B.im.h);
  }
  bool refused=false;try{(void)f2::split_box(C(0),0);}catch(const std::invalid_argument&){refused=true;}
  assert(refused);
  // Intersections may overlap the right-hand side; they never lose the left.
  C parent(I::rat(-1,100),I::rat(1,100));
  for(auto& b:f2::split_box(parent,4)){
    Disk d=dyad::centered::ball(b);
    C over=d.box();
    assert(over.re.l<=b.re.l && over.re.h>=b.re.h);
    assert(over.im.l<=b.im.l && over.im.h>=b.im.h);
  }
  std::cout<<"F2_SUBDIVISION_UNIT_PASS (sampled coverage, exact endpoint checks)\n";
}
