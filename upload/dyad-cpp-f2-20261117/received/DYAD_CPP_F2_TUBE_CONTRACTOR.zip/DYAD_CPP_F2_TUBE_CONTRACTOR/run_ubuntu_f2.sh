#!/usr/bin/env bash
# [SESSION] Conditional two-block evaluation only. No 3c-b, certification or release.
set -euo pipefail
if [[ $# -ne 5 ]]; then
  echo 'Usage: run_ubuntu_f2.sh REPO V2_DIR BENCH_DIR F1_DIR NEW_OR_EMPTY_OUTPUT_DIR' >&2
  exit 64
fi
repo=$(cd -- "$1" && pwd)
v2=$(cd -- "$2" && pwd)
bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd)
out=$5
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -e "$out" ]]; then
  if [[ ! -d "$out" || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output directory must be new or empty' >&2; exit 64
  fi
else mkdir -p -- "$out"; fi
out=$(cd -- "$out" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/f2_package_checks.txt"
(cd "$f1" && sha256sum -c SHA256SUMS.txt) > "$out/f1_package_checks.txt"
(cd "$bench" && sha256sum -c SHA256SUMS.txt) > "$out/benchmark_package_checks.txt"
(cd "$v2" && sha256sum -c SHA256SUMS.txt) > "$out/v2_package_checks.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
if ! printf '%s  %s\n' "$expected" "$source_json" | sha256sum -c -; then
  echo 'STOP: pinned Stage-2 JSON mismatch' >&2; exit 4
fi
{
 printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
 printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
 g++ --version | head -1
 python3 --version
 printf 'SOURCE_SHA256=%s\n' "$expected"
 printf 'MODE=SESSION_ONLY; F2 conditioned on sectorial tube/seed; NOT 3c-b\n'
} > "$out/environment.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" \
  --out "$out/phi40_outer_256.txt" > "$out/import.log"
common=(-std=c++17 -Wall -Wextra -pedantic -I "$v2/source" -I "$bench" -I "$f1/source")
g++ "${common[@]}" -O2 "$src/source/real_f2_tube.cpp" -o "$out/real_f2_tube"
g++ "${common[@]}" -O2 "$src/source/test_f2_partition.cpp" -o "$out/test_f2_partition"
"$out/test_f2_partition" > "$out/unit.txt"
# Restrict ASan/UBSan to bounded math/partition units (not the costly grid runs).
g++ "${common[@]}" -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined \
  "$src/source/test_f2_partition.cpp" -o "$out/test_f2_partition_san"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 40s \
  "$out/test_f2_partition_san" > "$out/sanitizer_unit.txt" 2> "$out/sanitizer_stderr.txt"
set +e
"$out/real_f2_tube" > "$out/negative_noargs.txt" 2>&1; neg_arg=$?
"$out/real_f2_tube" "$source_json" 8 2 "$out/negative_wrong.tsv" > "$out/negative_input.txt" 2>&1; neg_input=$?
"$out/real_f2_tube" "$out/phi40_outer_256.txt" 8 7 "$out/negative_grid.tsv" > "$out/negative_subdiv.txt" 2>&1; neg_sub=$?
set -e
if [[ "$neg_arg" -ne 64 || "$neg_input" -ne 3 || "$neg_sub" -ne 3 ]]; then
  echo "STOP: expected (64,3,3) negative exits, got ($neg_arg,$neg_input,$neg_sub)" >&2; exit 1
fi
failed=0
# Two source-backed experiments. Omit expensive finer grids unless separately scoped.
for spec in '8 4' '10 4'; do
  read -r grid sub <<< "$spec"
  set +e
  timeout -k 5s 210s "$out/real_f2_tube" "$out/phi40_outer_256.txt" "$grid" "$sub" \
    "$out/details_${grid}_${sub}.tsv" > "$out/run_${grid}_${sub}.stdout.txt" 2> "$out/run_${grid}_${sub}.stderr.txt"
  status=$?
  set -e
  if [[ "$status" -ne 0 ]]; then
    printf 'INCONCLUSIVE grid=%s subdivision=%s exit=%s\n' "$grid" "$sub" "$status" | tee -a "$out/summary.txt"
    failed=1; continue
  fi
  sed -n '3p' "$out/run_${grid}_${sub}.stdout.txt" | tee -a "$out/summary.txt"
  python3 "$src/source/check_f2_details.py" \
    "$out/run_${grid}_${sub}.stdout.txt" "$out/details_${grid}_${sub}.tsv" \
    > "$out/detail_check_${grid}_${sub}.txt" || { failed=1; }
done
(cd "$out" && find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name real_f2_tube ! -name test_f2_partition ! -name test_f2_partition_san -printf '%f\0' | sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt)
if [[ "$failed" -ne 0 ]]; then
  echo 'INCONCLUSIVE: at least one grid failed or timed out; unresolved retained.'; exit 2
fi
echo 'PASS: SESSION conditional two-block contractor; NOT a certificate or point jump.'
