# Owner review requested — DYAD C++ F2 conditional contractor (SESSION)

**Basis:** F1 owner review in PR #305 (head `fb95ff2bfbfbdd4ecc526de59354b2a9bcac3916`); governing Dyadic `dyad-v6.4.24`; proof record §§1, 4–5, 9–10, 12–13. Prior dependencies and their tests remain untouched. This is not a 3c-b production or replay run.

**Request to owner (Claude):**

1. **F2-R1 (critical):** prove the two-step retained-box induction for a candidate under the **conditional** graph/tube assumptions. In particular, after F1 necessary-disc/box intersection, the subdivided rectangle cover and each circumscribed disk must enclose the true candidate even when the disk includes extraneous points. Check that `iter(...,2)` preserves **full** tangent dependence and evaluates `d_2` only at the end.
2. **F2-R2:** check that `ForwardTube::upper` is valid independently at **both** base images over `X_j∩D0`. No condition `X_j⊂D0`, no use of a sampled or Python-midpoint M as a bound. Check exceptions preserve the correct **prior** candidate box. Confirm the C++ `cwall.l` floor is compatible with both the current D0 definition and the PI-approved, not-yet-implemented owner O-1 correction.
3. **F2-R3:** verify exact 256-bit endpoint tiling, `split_box` union coverage for arbitrary signed boxes, no false discard, last-hull L1 convention, and negative controls. Read the full integer-endpoint TSVs and compare with replayed results.
4. **F2-R4:** verify source identity and all dependency manifest checks; C++ code inclusion must use unchanged original `real_f1_tube.cpp`, `bench.cpp`, `centered_evaluator.hpp`, and `independent_core.cpp`. The coefficient transfer itself remains **owner-verified against the Python Arb recursion**, not an independent C++ regeneration.
5. **F2-R5 (interpretation):** distinguish the local **18-digit proxy** numbers from the first source-backed PI Ubuntu run to be executed. Record an honest `INCONCLUSIVE` if run budget/exception/hull test fails; no implication for a certified point jump or B-an/B-6.

**O-1 remains an owner-source maintenance item:** the PI's acceptance of the upper-endpoint-wall proposal needs fixed exact-dyadic values, provenance, and checks across working precision profiles; it is not silently implemented by this package.
