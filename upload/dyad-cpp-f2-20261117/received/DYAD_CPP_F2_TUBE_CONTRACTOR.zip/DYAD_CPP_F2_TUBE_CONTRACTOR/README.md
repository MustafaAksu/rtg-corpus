# DYAD OPEN 20 — conditional two-block F-leg contractor (C++ development checkpoint)

**Status:** `[SESSION]` research prototype; **NOT** a stage-3c-b run, certificate, physical validation, adopted DSN result, inverse branch, or point-jump proof. No merges, tags, canonical edits, or production/replay authorization are part of this package.

## 1. Verified inputs, provenance, and fixed scope

- Governing science: `dyad-v6.4.24` plus release record; stage-3c-a proof record §§1, 4–5, 9–10, 12–13; the F1 owner review at PR #305, head `fb95ff2bfbfbdd4ecc526de59354b2a9bcac3916` (owner's SESSION acceptance); numeric scale note PR #301, head `3de7ab633e3f9fad3c11cefa38656aaf9818df2c`.
- Stage-2 coefficient JSON: `evidence/dyad/open20-an/stage2/scout_N216_dps840.json`, exact SHA-256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`. Imported by the unchanged `DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2/source/import_phi40.py`, enclosing 39 complex `a_k` and `c`. The owner's independent Arb-recursion check at PR #305 supports the existing ±`1e-65` (coefficients) / ±`1e-32` (`c`) pads; not independent C++ coefficient generation.
- **Unchanged dependencies:** `DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2`, `DYAD_CPP_FORWARD_METHOD_BENCHMARK` and `DYAD_CPP_F1_TUBE_CONTRACTOR`, each with its checked `SHA256SUMS.txt`. The F2 program includes the exact original F1 source (renaming only its C++ entry point) and uses the existing `direct6` and `necessary_disk` implementations without modification.
- Target: \(\xi_*=0.40 e^{i\pi/6}\), \(\phi_{40}\), \(\lvert d_0\rvert\le0.002\); the **first two forward blocks** \(F=T^6\), fixed owner decimal \(\tau\) and chart \(D_0\). No other horizon or inverse direction is executed.
- O-1 owner finding: PI approved preparation of a fixed-dyadic upper-wall convention, **not yet implemented** in the owner proof record; this C++ F2 code uses the **more conservative** `cwall.l` as its second-functional floor and does not depend on the eventual upper-wall correction.

## 2. Mathematical construction and no-loss invariant

Let \(B_*=\{d:\lvert d\rvert\le0.002\}\). The input tiling covers \(B_*\) by 60 (grid 8) or 96 (grid 10) enclosing circular tiles \(T_i\). All derived subsets are kept as **axis-aligned boxes**. The working hypothesis is: the actual sectorial candidate \(d^*\in B_*\) has a graph orbit in the owner tube over \(D_0\) at both first and second blocks. That is *not* established in this package.

1. **F1:** Evaluate a full interval/tangent enclosure of \(d_1(d)\) on each tile \(T_i\), using a mean-value step at every *primitive* \(T\). Independently bound
   \(M_{1,i}\ge\sup_{x\in X_{1,i}\cap D_0} R_0(x)\),
   as in owner-reviewed `ForwardTube::upper`. With the full-tile derivative, original C1–C2 necessary contractor returns a disc \(N_{1,i}\) guaranteed to contain each feasible \(d^*\in T_i\). Store the **box intersection** \(H_{1,i}=\mathrm{box}(T_i)\cap\mathrm{box}(N_{1,i})\). If empty, exclude. A domain/range/slope failure retains the original tile.
2. **Refine:** Split each nonempty \(H_{1,i}\) into a 2×2 or 4×4 grid of exact-dyadic outward-rounded **closed rectangles**. Their union contains \(H_{1,i}\); tiny edge overlaps are allowed. The full post-F1 rectangle is not lost. Each small rectangle \(P\) is **circumscribed** by a disk \(\mathcal B(P)\) solely for evaluation.
3. **F2:** On \(\mathcal B(P)\), perform **two full six-primitive-step blocks** without reset, enclosing \(d_2(d)\) and \(\partial d_2/\partial d_0\) on the **entire** circumscribed disk. Independently derive
   \(M_{2,P}\ge\sup_{x\in X_{2,P}\cap D_0}R_0(x)\).
   The original C1–C2 contractor produces \(N_{2,P}\). Keep \(P\cap\mathrm{box}(N_{2,P})\) or discard only on **proved empty intersection**. If any F2 enclosure fails, keep **P** unmodified. If F1 is unresolved, keep its entire original tile without attempting F2.
4. **Final hull:** Take the outward L1 disk containing the union of all nonexcluded final boxes, using the original `enclosing_disk` convention. In particular, the radius printed by C++ is an **L1-based overbound**, not the smaller Euclidean circumscribed radius. An empty final set raises `INCONCLUSIVE` rather than asserting absence of an invariant curve.

The implications use the tube/graph hypothesis: \(d^*\in B_*\) and \(x_j(d^*)\in D_0,\lvert d_j(d^*)\rvert\le R_0(x_j(d^*))\) for j=1,2. They do not assert existence or uniqueness of \(d^*\). The M bounds are valid **only** as upper bounds on \(X_j\cap D_0\); no condition that all of \(X_j\) lies in \(D_0\) is needed.

## 3. Reproduction on PI Ubuntu server

Unzip this new archive as `/root/DYAD_CPP_F2_TUBE_CONTRACTOR`; retain the previous three extracted and **unchanged** directories. Run:

```bash
bash /root/DYAD_CPP_F2_TUBE_CONTRACTOR/run_ubuntu_f2.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/dyad-f2-tube-run
```

The output directory must be new/empty. The script checks all package manifests and the exact Stage-2 JSON SHA, imports intervals afresh, compiles optimized and bounded ASan/UBSan partition controls, runs negative CLI/transfer/grid tests and the 8×8 and 10×10 grids with 4×4 **second-stage subdivision**, and structurally verifies action counts, hull radii and output endpoints from exact integers. `exit 0` is a **SESSION** execution success; `exit 2` indicates an inconclusive/time-limited tile campaign; other nonzero exits are errors. Nothing invokes or authorizes 3c-b.

Inspect `summary.txt`, `run_8_4.stdout.txt`, `run_10_4.stdout.txt`, `detail_check_*.txt`, and the per-tile `details_*.tsv` under the output directory. The exact integer endpoints in TSV are the review evidence; printed scientific notation is rounded for display and **not** a bound.

## 4. Local development evidence — **approximate transfer only**

The local benchmark used a deliberately **18-significant-digit** proxy transfer for the coefficients and `c`, padded by ±`1e-15` per component. It does **not** have the pinned Stage-2 source SHA/Arb semantics and is **not** a source-backed run. Bounds are conditional on those proxy inputs.

| Initial grid | Post-F1 refinement | First disc radius | F2 subtile excluded/retained/unresolved | Final L1 disc radius |
|---|---|---:|---|---:|
| 8×8 (60 initial) | 2×2 (64 subtile evals) | 1.526195e-3 | 0 / 64 / 0 | 1.526195e-3 |
| 8×8 (60 initial) | 4×4 (256 evals) | 1.526195e-3 | 96 / 160 / 0 | **1.296769e-3** |
| 10×10 (96 initial) | 4×4 (256 evals) | 1.198130e-3 | 128 / 128 / 0 | **9.656854e-4** |

The displayed L1 radii were independently reconstructed using exact integer `enclosing_disk` arithmetic from the local TSVs. No *real* Stage-2-run result or independently checked F2 mpmath oracle is claimed here. The first-stage owner-accepted F1 results remain distinct. A 16×16 source-backed run is intentionally not part of this package.

**Limitations:** the R2/F2 second-block derivative bound may become too wide for some rectangles; unresolved pieces are retained. The validity of the sectorial graph and normalizing literature inputs remains conditional. The inverse leg, 334 blocks, full C++ independent point-jump proof and B-an/B-6 are open.
