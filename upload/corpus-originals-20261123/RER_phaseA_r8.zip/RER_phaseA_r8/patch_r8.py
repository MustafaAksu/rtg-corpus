"""Phase A r7 -> r8 patch (Dyadic currency only; receiver decision on B-05, 20 Oct 2026).
Dyadic owner_current -> v6.4.17, OWNER_REPORTED with the release-record hash; v6.4.16 recorded as superseded (receiver-hashed).
RER Dyadic pins stay on v6.4.13 (no repin). New gate A23 with negative controls against promoting the reported hash without bytes.
Exact-once text replacements; catalog JSON edits by key. Run once on a fresh copy of r7."""
import sys, os, json
D = sys.argv[1]
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:80]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'

D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
D16 = '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'
D13 = '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542'

# ---- frozen catalog
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
assert KV['Dyadic'] == '6.4.16'
KV['Dyadic'] = '6.4.17'
KV['_catalog_checked'] = '2026-10-20 (Phase A r8, preparer)'
KV['_source_authority']['Dyadic'] = ('owner release record claude/RTG_DYADIC_v6_4_17_RELEASE_RECORD.md (owner-reported; v6.4.17 bytes not hashed in this package; '
                                     'release verification by the reviewer pending). Superseded v6.4.16 was hashed by the receiving co-owner (Phase A r3 review).')
open(p, 'w').write(dump(KV))

# ---- catalog_sources.json
p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
d = CS['owner_current']['Dyadic']; assert d['version'] == '6.4.16' and d['sha256'] == D16 and d['evidence'] == 'HASH_VERIFIED_BY_RECEIVER'
CS['owner_current']['Dyadic'] = {
    'version': '6.4.17', 'sha256': D17, 'evidence': 'OWNER_REPORTED',
    'note': 'adopted 19 Oct 2026 per its release record (claude/RTG_DYADIC_v6_4_17_RELEASE_RECORD.md); the hash is the one stated there and was not computed in this package; release verification by the reviewer is pending. Per the release record: new DYAD-THM-OPEN21-PRIMITIVE-PHASE-REMAINDER [THM — conditional on RECOG-THM-R9-MEMORY], OPEN 21 CLOSED, notice N13; OPEN 20 unchanged; no RID renamed or regraded.',
    'superseded': {'version': '6.4.16', 'sha256': D16, 'evidence': 'HASH_VERIFIED_BY_RECEIVER (Phase A r3 review)'}}
k = CS['keys']['DYAD6413']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED' and k['cited_version'] == '6.4.13'
k['reason'] += (' Phase A r8: current Dyadic is v6.4.17 (owner-reported, not byte-verified). Its release record lists OPEN 21 changes only. '
                'Byte equality of the cited §§6.15–6.17 between v6.4.16 and v6.4.17 is not checked here; it is to be checked once the v6.4.17 file is available. RER pins stay on v6.4.13.')
CS['_about'] += ' Phase A r8 (20 Oct): Dyadic current moved to v6.4.17 (OWNER_REPORTED); DYAD6413 pins retained.'
open(p, 'w').write(dump(CS))

# ---- build_phaseA.py
rp('build_phaseA.py', [
 ('"""RER Phase A r7 builder', '"""RER Phase A r8 builder'),
 ("'RER-REGISTRY-PHASEA/7'", "'RER-REGISTRY-PHASEA/8'"),
 ("'RER-SOURCE-CURRENCY/7'", "'RER-SOURCE-CURRENCY/8'"),
 ("'RER-BLOCKED-SOURCES/7'", "'RER-BLOCKED-SOURCES/8'"),
 ("§§6.15–6.17 byte-identical to v6.4.15 (receiver-reported). RER Dyadic pins stay on v6.4.13.']}",
  "§§6.15–6.17 byte-identical to v6.4.15 (receiver-reported). RER Dyadic pins stay on v6.4.13.',\n"
  "                          'Dyadic v6.4.17 ADOPTED 19 Oct 2026 (e07cf2b9…4bfc, owner-reported; bytes not hashed here; release verification pending). Supersedes v6.4.16 (33c14c5c…59e0, receiver-hashed). Per its release record: OPEN 21 closed by DYAD-THM-OPEN21-PRIMITIVE-PHASE-REMAINDER; OPEN 20 and all earlier RIDs/grades unchanged. RER Dyadic pins stay on v6.4.13; byte equality of the cited §§6.15–6.17 in v6.4.17 is checked only when the file is available.']}"),
 ("'# RER r4.6 — source-currency matrix (Phase A r7, noncanonical)'", "'# RER r4.6 — source-currency matrix (Phase A r8, noncanonical)'"),
 ("'# RER r4.6 — blocked-source register (Phase A r7, noncanonical)'", "'# RER r4.6 — blocked-source register (Phase A r8, noncanonical)'"),
])

# ---- check_phaseA.py
rp('check_phaseA.py', [
 ('"""Phase A r7 gates on RER v0.2 DRAFT r4.6.', '"""Phase A r8 gates on RER v0.2 DRAFT r4.6.'),
 ("the ER01 gap reference (G8/0) is HISTORICAL with verified bytes and a pending per-reference audit (r7, A6-G8-01).\"\"\"",
  "the ER01 gap reference (G8/0) is HISTORICAL with verified bytes and a pending per-reference audit (r7, A6-G8-01).\n"
  "A23 Dyadic currency (r8): v6.4.17 is current, OWNER_REPORTED with the release-record hash; no file with that hash is in sources_available,\n"
  "so no BYTE_VERIFIED / HASH_VERIFIED_BY_RECEIVER promotion; v6.4.16 recorded as superseded (receiver-hashed); every Dyadic row has no verified\n"
  "current hash, owner evidence OWNER_REPORTED and a non-CURRENT currency; the DYAD6413 pin stays v6.4.13 with its cited hash and receiver authentication.\"\"\""),
 ("and oc['Dyadic']['version'] != '6.4.15' and oc['OFN']['version'] == '0.10'",
  "and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16') and oc['OFN']['version'] == '0.10'"),
 ("g('A19 owner currency equals the frozen catalog; Dyadic v6.4.15 and OFN v0.9 not current;", "g('A19 owner currency equals the frozen catalog; Dyadic v6.4.15/v6.4.16 and OFN v0.9 not current;"),
 ("in particular Dyadic v6.4.15 and OFN v0.9 are rejected as current;", "in particular Dyadic v6.4.15, Dyadic v6.4.16 and OFN v0.9 are rejected as current;"),
 ("    g('A22 r6 source custody (container chain preparer-declared); ER01 record rows blocked, G8/0 historical', cu_ok and er_ok, f'{len(CU)} custody entries')\n",
  "    g('A22 r6 source custody (container chain preparer-declared); ER01 record rows blocked, G8/0 historical', cu_ok and er_ok, f'{len(CU)} custody entries')\n"
  "    dy = oc['Dyadic']; D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'\n"
  "    dyrows = [x for x in cm['rows'] if x['owner'] == 'Dyadic']\n"
  "    dy_ok = (dy['version'] == '6.4.17' and dy['sha256'] == D17 and dy['evidence'] == 'OWNER_REPORTED' and D17 not in avail\n"
  "             and dy.get('superseded', {}).get('version') == '6.4.16' and dy['superseded'].get('sha256') == '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'\n"
  "             and len(dyrows) >= 1 and all(x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT' for x in dyrows)\n"
  "             and all(x['cited_version'] == '6.4.13' and x['cited_sha256'] == '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED' for x in dyrows if x['key'] == 'DYAD6413'))\n"
  "    g('A23 Dyadic v6.4.17 owner-reported only; v6.4.16 superseded; RER pins stay v6.4.13', dy_ok, f'{len(dyrows)} Dyadic row(s)')\n"),
 ("         ('A21 OFN row given a verified current hash', 20, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(verified_current_hash='acb70a8cfc7962abcc047dedffb59e9ceca8f2e9843d6203df6eba54f5ed5dfa')))]",
  "         ('A21 OFN row given a verified current hash', 20, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(verified_current_hash='acb70a8cfc7962abcc047dedffb59e9ceca8f2e9843d6203df6eba54f5ed5dfa'))),\n"
  "         ('A19 Dyadic v6.4.16 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.16'))),\n"
  "         ('A23 Dyadic v6.4.17 promoted to BYTE_VERIFIED without bytes', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED'))),\n"
  "         ('A23 Dyadic v6.4.17 promoted to BYTE_VERIFIED_HERE', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED_HERE'))),\n"
  "         ('A23 Dyadic v6.4.17 promoted to HASH_VERIFIED_BY_RECEIVER', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='HASH_VERIFIED_BY_RECEIVER'))),\n"
  "         ('A23 Dyadic row given a verified current hash', 22, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'Dyadic').update(verified_current_hash='e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'))),\n"
  "         ('A23 DYAD6413 pin silently moved to v6.4.17', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(cited_version='6.4.17', cited_sha256='e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'))),\n"
  "         ('A23 superseded v6.4.16 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))]"),
])
print('patched')
