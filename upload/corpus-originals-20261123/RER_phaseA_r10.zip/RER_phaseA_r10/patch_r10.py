"""Phase A r9 -> r10: a fresh Phase A pass on the exact RER v0.2 DRAFT r4.7 bytes (receiver authorization, 20 Oct 2026).
- The source Markdown is replaced by r4.7 (110729e5...cd1d). All outputs are rebuilt from r4.7 by the same builder; nothing from the
  r9 outputs is reused as output. The r9 matrix and registry are pinned as inputs only, for the A24 regression comparison.
- New catalog key RRF083 (the import line r4.7 adds to RER-DYAD-FORMAL-INVOLUTION). The r4.7 package manifest is added; rows carry
  path_in_r4_7_package. The registry output file is renamed to r4_7.
- New gate A24 (r4.7 source pass); its negative controls include re-using the r9 matrix and dropping or promoting the RRF083 row.
Exact-once text replacements; catalog JSON edits by key. Args: TARGET_DIR R47_MD R47_PACKAGE_SHA256SUMS. Run once on a fresh copy of r9."""
import sys, os, json, shutil, hashlib
D, R47, R47SUMS = sys.argv[1], sys.argv[2], sys.argv[3]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:90]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
R47_SHA = '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d'
R47_ZIP = '9ab6393e94001d5c513f68af64e32d63afb0548b31879afcfc3912911ecfc14f'
R46_SHA = '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'
RRF083 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
assert sha(R47) == R47_SHA
os.remove(os.path.join(D, 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md'))
shutil.copyfile(R47, os.path.join(D, 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_7.md'))
shutil.copyfile(R47SUMS, os.path.join(D, 'inputs/r4_7_package_SHA256SUMS.txt'))
os.makedirs(os.path.join(D, 'inputs/phaseA_r9_outputs'))
for f in ('SOURCE_CURRENCY_MATRIX.json', 'RER_REGISTRY_v0_2_r4_6_PHASEA.json'):
    shutil.move(os.path.join(D, 'out', f), os.path.join(D, 'inputs/phaseA_r9_outputs', f))
for f in ('SOURCE_CURRENCY_MATRIX.md', 'BLOCKED_SOURCE_REGISTER.json', 'BLOCKED_SOURCE_REGISTER.md'):
    os.remove(os.path.join(D, 'out', f))

p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
assert 'RRF083' not in CS['keys'] and CS['owner_current']['RRF']['sha256'] == RRF083 and CS['owner_current']['RRF']['version'] == '0.8.3'
CS['keys']['RRF083'] = {'cited_version': '0.8.3', 'family': 'OWNER_DSN', 'owner': 'RRF', 'rule': 'CURRENT', 'receiver_byte_verified': True,
    'reason': 'r4.7 (O6): pin for the RRF v0.8.3 sections (§2.3, §2.4b RRF-DYAD-NF row) cited by the r4.6 carrier cell of RER-DYAD-FORMAL-INVOLUTION. Cited version is the current adopted working standard.',
    'receiver_note': 'RECEIVER-REPORTED: adopted RRF v0.8.3 bytes held and hash-verified on the receiving side (Phase A reviews; r4.7 decision of 20 Oct 2026). Not in the r4.7 package; not byte-held by the preparer.'}
CS['_about'] += ' Phase A r10 (20 Oct): source moved to RER r4.7; RRF083 key added (r4.7 O6 import line).'
open(p, 'w').write(dump(CS))
p = os.path.join(D, 'catalog_records.json'); CR = json.load(open(p))
CR['_about'] += ' Phase A r10: unchanged record classification; r4.7 changes only the text of RER-DYAD-FORMAL-INVOLUTION.'
open(p, 'w').write(dump(CR))
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
KV['_catalog_checked'] = '2026-10-20 (Phase A r10, preparer)'; open(p, 'w').write(dump(KV))

rp('build_phaseA.py', [
 ('"""RER Phase A r9 builder (deterministic). Inputs: exact r4.6 Markdown (r4.5 + RRF editor Q1-Q8 implementation),',
  '"""RER Phase A r10 builder (deterministic). Inputs: exact r4.7 Markdown (r4.6 + the six Phase B-05 record-text items in RER-DYAD-FORMAL-INVOLUTION; r4.6 = r4.5 + RRF editor Q1-Q8 implementation),'),
 ("MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md'\nMD_SHA = '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'\n",
  f"MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_7.md'\nMD_SHA = '{R47_SHA}'\nR47_ZIP_SHA = '{R47_ZIP}'\nBASE_R46_SHA = '{R46_SHA}'\n"),
 ("assert sha(mdb) == MD_SHA, 'r4.6 hash mismatch'", "assert sha(mdb) == MD_SHA, 'r4.7 hash mismatch'"),
 ("pkg46 = man('inputs/r4_6_package_SHA256SUMS.txt')", "pkg46 = man('inputs/r4_6_package_SHA256SUMS.txt'); pkg47 = man('inputs/r4_7_package_SHA256SUMS.txt')"),
 ("'path_in_r4_6_package': path in pkg46,", "'path_in_r4_6_package': path in pkg46, 'path_in_r4_7_package': path in pkg47,"),
 ("'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R46_ZIP_SHA, 'base_r4_5_package_zip_sha256': R45_ZIP_SHA,",
  "'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R47_ZIP_SHA, 'base_r4_6_sha256': BASE_R46_SHA, 'base_r4_6_package_zip_sha256': R46_ZIP_SHA, 'base_r4_5_package_zip_sha256': R45_ZIP_SHA,"),
 ("'RER-REGISTRY-PHASEA/9'", "'RER-REGISTRY-PHASEA/10'"), ("'RER-SOURCE-CURRENCY/9'", "'RER-SOURCE-CURRENCY/10'"), ("'RER-BLOCKED-SOURCES/9'", "'RER-BLOCKED-SOURCES/10'"),
 ("'out/RER_REGISTRY_v0_2_r4_6_PHASEA.json': dump(reg)", "'out/RER_REGISTRY_v0_2_r4_7_PHASEA.json': dump(reg)"),
 ("'# RER r4.6 — source-currency matrix (Phase A r9, noncanonical)'", "'# RER r4.7 — source-currency matrix (Phase A r10, noncanonical)'"),
 ("'# RER r4.6 — blocked-source register (Phase A r9, noncanonical)'", "'# RER r4.7 — blocked-source register (Phase A r10, noncanonical)'"),
 ("| In r4 / r4.4 / r4.5 / r4.6 pkg |", "| In r4 / r4.4 / r4.5 / r4.6 / r4.7 pkg |"),
 ("{yn(x['path_in_r4_6_package'])}", "{yn(x['path_in_r4_6_package'])} / {yn(x['path_in_r4_7_package'])}"),
 ("The r8 OWNER_REPORTED line above is kept as history.']}",
  "The r8 OWNER_REPORTED line above is kept as history.',\n"
  "                          'Phase A r10 (20 Oct 2026): source is RER r4.7 (110729e5…cd1d; package 9ab6393e…c14f), accepted ACCEPT SCOPED as a DRAFT by the receiver. r4.7 changes only RER-DYAD-FORMAL-INVOLUTION and adds one import row (RRF083, RRF v0.8.3 §2.3/§2.4b). All outputs are rebuilt from r4.7; the r9 outputs (on r4.6) are inputs for regression only.']}"),
])
t = open(os.path.join(D, 'build_phaseA.py'), encoding='utf-8').read(); assert '|---|---|---|---|---|---|---|---|---|---|---|---|---|' in t

rp('check_phaseA.py', [
 ('"""Phase A r9 gates on RER v0.2 DRAFT r4.6.', '"""Phase A r10 gates on RER v0.2 DRAFT r4.7.'),
 ("--tamper also runs a file-level control: the checker is re-run with the v6.4.17 file withheld from sources_available, and A23 must fail.\"\"\"",
  "--tamper also runs a file-level control: the checker is re-run with the v6.4.17 file withheld from sources_available, and A23 must fail.\n"
  "A24 r4.7 source pass (r10): the outputs record the r4.7 source and package hashes and the r4.6 base; the matrix equals the pinned r9 matrix\n"
  "row for row (identity, cited hash, bytes, authentication, currency, status) except exactly one added RECORD_IMPORT row RRF083 in\n"
  "RER-DYAD-FORMAL-INVOLUTION (n=2; cited v0.8.3 with the adopted hash; CURRENT; RECEIVER_BYTE_VERIFIED; OWNER_REPORTED); every row carries\n"
  "path_in_r4_7_package; the registry equals the pinned r9 registry for the other 19 records, and for RER-DYAD-FORMAL-INVOLUTION differs only in\n"
  "text fields (exactness, task, adoption and OPEN items unchanged; primary_grade starts with the r9 value '[THM] (owner grade)' and, because the\n"
  "parser reads up to '. **Exactness', now also holds the O3 per-RID labels, so grade_tags is ['ALG', 'THM'] - finding R10-F1, recorded, not repaired).\"\"\""),
 ("reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_6_PHASEA.json'])", "reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_7_PHASEA.json'])"),
 ("pkg46 = B.rd('inputs/r4_6_package_SHA256SUMS.txt').decode()", "pkg46 = B.rd('inputs/r4_6_package_SHA256SUMS.txt').decode(); pkg47 = B.rd('inputs/r4_7_package_SHA256SUMS.txt').decode()"),
 ("        if x['path_in_r4_6_package'] and ('  ' + x['cited_path'] + '\\n') not in pkg46: bb.append(x['key'] + ':pkg46')\n",
  "        if x['path_in_r4_6_package'] and ('  ' + x['cited_path'] + '\\n') not in pkg46: bb.append(x['key'] + ':pkg46')\n"
  "        if x.get('path_in_r4_7_package') and ('  ' + x['cited_path'] + '\\n') not in pkg47: bb.append(x['key'] + ':pkg47')\n"),
 ("    return all(res), res\n\nouts =",
  "    m9 = json.loads(B.rd('inputs/phaseA_r9_outputs/SOURCE_CURRENCY_MATRIX.json')); r9 = json.loads(B.rd('inputs/phaseA_r9_outputs/RER_REGISTRY_v0_2_r4_6_PHASEA.json'))\n"
  "    ident = lambda x: tuple(x.get(k) for k in ('record', 'row_kind', 'n', 'key', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash'))\n"
  "    new = [x for x in cm['rows'] if ident(x) not in set(ident(y) for y in m9['rows'])]; gone = [y for y in m9['rows'] if ident(y) not in set(ident(x) for x in cm['rows'])]\n"
  "    add = new[0] if len(new) == 1 else {}\n"
  "    rows_ok = (not gone and len(cm['rows']) == len(m9['rows']) + 1 and len(new) == 1 and add.get('record') == 'RER-DYAD-FORMAL-INVOLUTION' and add.get('row_kind') == 'RECORD_IMPORT'\n"
  "               and add.get('n') == 2 and add.get('key') == 'RRF083' and add.get('cited_version') == '0.8.3' and add.get('cited_sha256') == 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'\n"
  "               and add.get('currency') == 'CURRENT' and add.get('authentication') == 'RECEIVER_BYTE_VERIFIED' and add.get('status') == 'OWNER_REPORTED' and all('path_in_r4_7_package' in x for x in cm['rows']))\n"
  "    sm = reg['source_markdown']\n"
  "    src_ok = (sm['file'].endswith('_r4_7.md') and sm['sha256'] == B.MD_SHA == '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d' and sm['package_zip_sha256'] == '9ab6393e94001d5c513f68af64e32d63afb0548b31879afcfc3912911ecfc14f'\n"
  "              and sm.get('base_r4_6_sha256') == '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772' and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA)\n"
  "    R9 = {x['id']: x for x in r9['records']}; R10 = {x['id']: x for x in reg['records']}\n"
  "    oth = [k for k in R9 if k != 'RER-DYAD-FORMAL-INVOLUTION']\n"
  "    dy9, dy10 = R9.get('RER-DYAD-FORMAL-INVOLUTION', {}), R10.get('RER-DYAD-FORMAL-INVOLUTION', {})\n"
  "    rec_ok = (set(R9) == set(R10) and len(oth) == 19 and all(R9[k] == R10[k] for k in oth) and dy9 != dy10\n"
  "              and all(dy9.get(f) == dy10.get(f) for f in ('exactness_codes', 'exactness_text', 'task', 'open_items', 'registry_owner_adoption')) and len(dy10.get('imports', [])) == len(dy9.get('imports', [])) + 1\n"
  "              and dy9.get('primary_grade') == '[THM] (owner grade)' and (dy10.get('primary_grade') or '').startswith('[THM] (owner grade). Owner grades per imported RID (r4.7):')\n"
  "              and dy9.get('grade_tags') == ['THM'] and dy10.get('grade_tags') == ['ALG', 'THM'])  # finding R10-F1: the parser reads the O3 per-RID labels into primary_grade\n"
  "    g('A24 r4.7 source pass: sources pinned; matrix = r9 + one RRF083 row; registry differs only in RER-DYAD-FORMAL-INVOLUTION text', src_ok and rows_ok and rec_ok, f'{len(cm[\"rows\"])} rows, {len(new)} new, {len(gone)} gone')\n"
  "    return all(res), res\n\nouts ="),
 ("    R, C, K = 'out/RER_REGISTRY_v0_2_r4_6_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'",
  "    R, C, K = 'out/RER_REGISTRY_v0_2_r4_7_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'"),
 ("         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('history'))),\n",
  "         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('history'))),\n"
  "         ('A24 r9 matrix rows re-used (RRF083 row absent)', 23, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r9_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows']))),\n"
  "         ('A24 RRF083 row dropped', 23, mut(C, lambda d: d['rows'].remove(next(x for x in d['rows'] if x['key'] == 'RRF083')))),\n"
  "         ('A24 RRF083 row promoted to BYTE_VERIFIED_HERE', 23, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(authentication='BYTE_VERIFIED_HERE'))),\n"
  "         ('A24 source recorded as r4.6', 23, mut(R, lambda d: d['source_markdown'].update(sha256='2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'))),\n"
  "         ('A24 another record silently changed', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED'))),\n"
  "         ('A24 DYAD grade changed', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(primary_grade='[ALG]'))),\n"
  "         ('A24 parsed grade tags silently reset to [THM] (R10-F1 hidden)', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(grade_tags=['THM']))),\n"),
])
print('patched')
