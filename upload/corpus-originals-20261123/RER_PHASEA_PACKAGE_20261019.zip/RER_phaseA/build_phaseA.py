"""RER Phase A builder (deterministic). Inputs: exact r4.4 Markdown, two preparer catalogs, the r4.4 package manifest and
sources_available/. Outputs in out/: registry JSON, source-currency matrix (JSON+MD), blocked-source register (JSON+MD).
No Markdown is edited; no grade, status or owner is changed."""
import sys, os, re, json, hashlib, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, 'tools')); import rer_parse as P
MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_4.md'
MD_SHA = '5df4738685ecebf979da4f48d432ef2f9af01b6964dfefb62d7ac31887caa9d8'
R44_ZIP_SHA = '0c08ae639f0104eb373d48e92d7a84051ba2b8f9f99841fb17edb7069534f91f'
sha = lambda b: hashlib.sha256(b).hexdigest()
def rd(p): return open(os.path.join(HERE, p), 'rb').read()
def dump(o): return (json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n').encode('utf-8')

def status_of(x):
    """Receiver vocabulary (decision record III.2): VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED."""
    c, b = x['currency'], x['bytes_status']
    if c == 'BLOCKED': return 'BLOCKED'
    if b == 'BYTE_VERIFIED_MATCH' and c in ('UNCHANGED_VERIFIED', 'CURRENT', 'ARTIFACT_PINNED'): return 'VERIFIED'
    if c in ('CURRENT', 'UNCHANGED_OWNER_REPORTED'): return 'OWNER_REPORTED'
    return 'HISTORICAL'

def build():
    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.4 hash mismatch'
    md = mdb.decode('utf-8')
    CS = json.loads(rd('catalog_sources.json')); CR = json.loads(rd('catalog_records.json'))
    man = lambda f: set(l.split('  ', 1)[1].strip() for l in rd(f).decode().splitlines() if '  ' in l)
    pkg = man('inputs/r4_4_package_SHA256SUMS.txt'); pkg4 = man('inputs/r4_package_SHA256SUMS.txt')
    avail = {}
    for f in sorted(os.listdir(os.path.join(HERE, 'sources_available'))):
        k, base = f.split('__', 1); avail[k] = (f, sha(rd('sources_available/' + f)))
    st = P.source_table(md)
    blocks = P.blocks(md)
    recs, gaps = [], []
    for rid, title, body in blocks:
        if rid in P.GAPS:
            gaps.append({'id': rid, 'title': title, 'text_sha256': sha(body.strip().encode())}); continue
        r = P.parse_record(rid, title, body); c = CR['records'][rid]
        r.update({'cohort': c['cohort'], 'owner_family': c['owner_family'], 'claim_provenance': c['provenance'],
                  'phaseB_route': c['phaseB_route'], 'adoption_status': 'PENDING',
                  'phaseA_status': 'BLOCKED_SOURCE_UNVERIFIED' if c.get('blocked') else 'ACTIVE',
                  'accepted_cohort_eligible': not c.get('blocked', False),
                  'grade_status': 'SOURCE_CLAIMED_NOT_RER_ADOPTED' if c.get('blocked') else 'AS_REGISTERED_PENDING_PHASE_B',
                  'prior_review_receipt': r['fields']['Review receipt'] or 'NO_IN_RECORD_RECEIPT'})
        for extra in ('provenance_note', 'author_conflict'):
            if extra in c: r[extra] = c[extra]
        for i in r['imports']: i.pop('raw', None)
        recs.append(r)
    # ---- currency matrix
    rows = []
    v16 = rd('sources_available/' + avail['TRIAD'][0]).decode('utf-8').split('\n') if 'TRIAD' in avail else None
    v161 = rd('sources_available/' + avail['TRIAD161'][0]).decode('utf-8') if 'TRIAD161' in avail else None
    for r in recs:
        for n, i in enumerate(r['imports']):
            k = i['key']; row_st = st.get(k) or {}
            cited = i['cited_sha256'] or row_st.get('sha256')
            hash_origin = 'IMPORT_LINE' if i['cited_sha256'] else ('SOURCE_TABLE' if row_st.get('sha256') else 'NONE')
            if k in CS['keys']: cat = dict(CS['keys'][k])
            elif k in CS['snapshot_keys']: cat = dict(CS['snapshot_rule'], owner='(study snapshot)', cited_version=row_st.get('description', '').split(';')[0])
            else: cat = dict(CS['artifact_rule'], owner='(artifact)', cited_version=row_st.get('description', '').split(';')[0] or 'artifact')
            own = CS['owner_current'].get(cat.get('owner'), {})
            path = urllib.parse.unquote(i['path'])
            if k in avail:
                bytes_status = 'BYTE_VERIFIED_MATCH' if cited and avail[k][1] == cited else 'BYTE_MISMATCH'
            else:
                bytes_status = 'PRINTED_ONLY' if cited else 'NO_HASH_PRINTED'
            currency, reason = cat['rule'], cat.get('reason', '')
            if cat['rule'] == 'LINE_RANGE_VERBATIM':
                ok = bool(v16 and v161 and i['lines'] and '\n'.join(v16[i['lines'][0]-1:i['lines'][1]]) in v161)
                currency = 'UNCHANGED_VERIFIED' if ok else 'RECHECK_IN_PHASE_B'
                reason = f"lines {i['lines']} of v1.6 {'appear verbatim' if ok else 'do not appear verbatim'} in v1.6.1 bytes"
            if cat['rule'] == 'CURRENT' and own and own.get('sha256') and cited and cited != own['sha256']:
                currency, reason = 'RECHECK_IN_PHASE_B', 'cited hash differs from current owner hash'
            rows.append({'record': r['id'], 'n': n, 'key': k, 'source_doc': os.path.basename(path) if path else None,
                'source_family': cat['family'], 'owner': cat.get('owner'), 'section_or_RID': (i['section'] + (f" | RID: {i['rid']}" if i['rid'] and i['rid'] != 'unavailable' else '')),
                'lines': i['lines'], 'cited_version': cat.get('cited_version'), 'cited_sha256': cited, 'cited_hash_origin': hash_origin,
                'current_owner_version': own.get('version'), 'current_owner_sha256': own.get('sha256'), 'current_owner_evidence': own.get('evidence'),
                'bytes_status': bytes_status, 'available_file': ('sources_available/' + avail[k][0]) if k in avail else None,
                'path_in_r4_4_package': path in pkg, 'path_in_r4_package': path in pkg4, 'cited_path': path,
                'inspection_extent': 'FULL_FILE_HASH' if k in avail else ('SECTION_RANGE' if i['lines'] else 'REFERENCE_ONLY'),
                'currency': currency, 'currency_reason': reason, 'reviewer_disposition': 'PENDING'})
            x = rows[-1]
            x['verified_current_hash'] = own.get('sha256') if own.get('evidence') in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER') else None
            x['status'] = status_of(x)
    # ---- blocked register
    blocked = []
    bysrc = {}
    for r in recs:
        for m in r['missing_primary_inputs']:
            b = bysrc.setdefault(m, {'source': m, 'records': [], 'kind': 'MISSING_PRIMARY_INPUT', 'blocked_records': []})
            b['records'].append(r['id'])
            if r['phaseA_status'] == 'BLOCKED_SOURCE_UNVERIFIED': b['blocked_records'].append(r['id'])
    for k, v in sorted(st.items()):
        if 'Direct source not available' in v['description']:
            src = re.findall(r'`([^`]+)`', v['row'])[1]
            b = bysrc.setdefault(src, {'source': src, 'records': [], 'kind': 'SOURCE_TABLE_NOT_AVAILABLE', 'blocked_records': []})
            b['source_table_key'] = k
    er = bysrc['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']
    er['records'] += ['RER-ER2B-T6D', 'RER-ER2B-CARRIER']; er['blocked_records'] += ['RER-ER2B-T6D', 'RER-ER2B-CARRIER']
    er['note'] = 'Primary v0.2 package not available to preparer or receiver. ER-2B consolidated v0.3 (80669c69…, NONCANONICAL) reports the package identity RTG_ER2B_CONSOLIDATED_v0_2.zip 8c635290…48ee and v0.2 study ea26d3d1…5e (source-reported, not verified here); v0.3 is background only and does not unblock (receiver D-2). Unblocking needs the package bytes and, if required, an ER-2B custodian decision.'
    for src in ('RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md', 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip'):
        bysrc[src]['note'] = 'For RER-RRF-CND01 this blocks only the secondary-report coincidence item (not imported as a theorem); the record\'s [THM] is the RER-native fixed-set implication.'
    blocked = list(bysrc.values())
    for b in blocked:
        b['records'] = sorted(set(b['records'])); b['blocked_records'] = sorted(set(b['blocked_records'])); b['blocks_acceptance'] = bool(b['blocked_records'])
    blocked.sort(key=lambda b: b['source'])
    printed = sorted(set(x['key'] for x in rows if x['bytes_status'] in ('PRINTED_ONLY', 'NO_HASH_PRINTED')))
    reg = {'schema': 'RER-REGISTRY-PHASEA/1', 'status': 'NONCANONICAL PHASE A CANDIDATE — not adopted, not frozen',
           'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R44_ZIP_SHA},
           'counts': {'records': len(recs), 'gap_entries': len(gaps), 'legacy_v0_1_entries': len(P.legacy_entries(md))},
           'records': recs, 'gap_entries': gaps,
           'legacy_v0_1_snapshot': {'label': 'HISTORICAL_SNAPSHOT_NOT_AN_ADOPTION_COHORT', 'entries': P.legacy_entries(md)},
           'source_table': {k: {kk: vv for kk, vv in v.items() if kk != 'row'} for k, v in st.items()}}
    cm = {'schema': 'RER-SOURCE-CURRENCY/1', 'source_markdown_sha256': MD_SHA, 'owner_current': CS['owner_current'], 'rows': rows,
          'bytes_not_available_to_preparer': printed,
          'watch_items': ['Genesis v2.8.9 DRAFT (b2cc5c5c…, not adopted) adds GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO; relevance to RER-GEN-K3-MODAL / G6 to be assessed after adoption.',
                          'Dyadic v6.4.15 (be270dde…, owner-adopted; reviewer release verification pending). Owner text read 19 Oct: adds OPEN 3b results only; no RID cited by RER is renamed or regraded; OPEN 20 unchanged.']}
    lost = sorted(set(x['key'] for x in rows if x['path_in_r4_package'] and not x['path_in_r4_4_package']))
    br = {'schema': 'RER-BLOCKED-SOURCES/1', 'source_markdown_sha256': MD_SHA, 'blocked': blocked,
          'packaging_finding': 'Cited evidence files present in the r4 package but not carried into the r4.1–r4.4 packages: ' + ', '.join(lost) + '. Their bytes are included in this Phase A package under sources_available/ and match the cited hashes; the next RER draft package must carry them at the cited paths.',
          'lost_in_packaging': lost,
          'byte_availability_gap': {'keys': printed, 'note': 'Hashes printed in RER; bytes held in the r3.1 source package, not in the preparer workspace. Not blocking by itself; the receiving side holding the r3.1 package can byte-verify.'}}
    return {'out/RER_REGISTRY_v0_2_r4_4_PHASEA.json': dump(reg), 'out/SOURCE_CURRENCY_MATRIX.json': dump(cm),
            'out/BLOCKED_SOURCE_REGISTER.json': dump(br), 'out/SOURCE_CURRENCY_MATRIX.md': render_matrix(cm, recs),
            'out/BLOCKED_SOURCE_REGISTER.md': render_blocked(br)}

def render_matrix(cm, recs):
    L = ['# RER r4.4 — source-currency matrix (Phase A, noncanonical)', '', f"Source: `{MD}` `{MD_SHA}`. Generated by `build_phaseA.py`; the JSON is authoritative.", '',
         '## Current owner versions', '', '| Owner | Current | SHA-256 | Evidence | Note |', '|---|---|---|---|---|']
    for o, v in sorted(cm['owner_current'].items()): L.append(f"| {o} | {v['version']} | `{v['sha256'][:12]}…` | {v['evidence']} | {v['note']} |")
    L += ['', '## Import rows', '', '| Record | Key | Family | Cited | Cited hash | Bytes | In r4 / r4.4 pkg | Current owner | Verified current hash | Currency | Status |', '|---|---|---|---|---|---|---|---|---|---|---|']
    for x in cm['rows']:
        L.append(f"| {x['record']} | `{x['key']}` | {x['source_family']} | {x['cited_version']} | {(x['cited_sha256'] or '—')[:12]} ({x['cited_hash_origin']}) | {x['bytes_status']} | {'yes' if x['path_in_r4_package'] else 'no'} / {'yes' if x['path_in_r4_4_package'] else 'no'} | {x['current_owner_version'] or '—'} | {(x['verified_current_hash'] or '—')[:12]} | {x['currency']} | **{x['status']}** |")
    from collections import Counter
    L += ['', '## Summary', '', f"- Import rows: {len(cm['rows'])}; records: {len(recs)}.",
          '- Currency: ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['currency'] for x in cm['rows']).items())),
          '- Bytes: ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['bytes_status'] for x in cm['rows']).items())),
          '- Status (receiver vocabulary): ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['status'] for x in cm['rows']).items())),
          '- Field mapping to the receiver list (decision record III.2): cited_hash = `cited_sha256`; verified_current_hash is set only where the current owner file was byte-hashed (preparer or receiver); status maps currency and bytes_status as in `status_of()`.',
          '', '## Watch items', ''] + [f'- {w}' for w in cm['watch_items']]
    return ('\n'.join(L) + '\n').encode('utf-8')

def render_blocked(br):
    L = ['# RER r4.4 — blocked-source register (Phase A, noncanonical)', '', '| Source | Kind | Cited by | Blocks acceptance of | Note |', '|---|---|---|---|---|']
    for b in br['blocked']: L.append(f"| `{b['source']}` | {b['kind']}{' (' + b['source_table_key'] + ')' if b.get('source_table_key') else ''} | {', '.join(b['records']) or '—'} | {', '.join(b['blocked_records']) or '—'} | {b.get('note', '')} |")
    L += ['', '## Packaging finding', '', br['packaging_finding']]
    L += ['', '## Byte-availability gap (not blocking)', '', br['byte_availability_gap']['note'], '', ', '.join(f'`{k}`' for k in br['byte_availability_gap']['keys'])]
    return ('\n'.join(L) + '\n').encode('utf-8')

if __name__ == '__main__':
    os.makedirs(os.path.join(HERE, 'out'), exist_ok=True)
    for p, b in build().items():
        open(os.path.join(HERE, p), 'wb').write(b); print(p, sha(b)[:16])
