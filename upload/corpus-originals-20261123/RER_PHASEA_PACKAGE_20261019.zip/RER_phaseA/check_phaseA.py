"""Phase A gates (independent of tools/rer_parse.py: Markdown is re-read by plain line scanning). Exit 0 iff all pass.
A1 r4.4 source SHA and catalog pins; A2 deterministic rebuild (fresh build == stored outputs, byte-exact); A3 record set
(MD headings vs JSON ids: same order, no missing/duplicate, gaps separate); A4 field mirror (grade line, task, six contract cells,
import count, OPEN count per record); A5 currency rows (one per import occurrence; required fields present); A6 byte claims
(every BYTE_VERIFIED_MATCH file exists and re-hashes to the cited value; no package-path claim without manifest entry);
A7 stale pins (owner-DSN rows with cited != current version carry a non-CURRENT status and a reason); A8 ER-2B firewall;
A9 no promotion (adoption PENDING everywhere; JSON grade text == MD); A10 RRF-CND01 provenance split; A11 legacy snapshot
separate (16, labelled historical, none among records); A12 blocked register covers every missing primary input and every
'Direct source not available' row; A13 packaging finding lists every cited file lost between r4 and r4.4; A14 receiver status vocabulary (VERIFIED requires a byte match; verified_current_hash only where the owner file was hashed).
--tamper: mutated outputs must fail the named gate."""
import sys, os, re, json, hashlib, copy
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); import build_phaseA as B
sha = lambda b: hashlib.sha256(b).hexdigest()
CAT_PINS = {'catalog_sources.json': None, 'catalog_records.json': None}  # filled from PINS file
PINS = json.load(open(os.path.join(HERE, 'PINS.json')))
md = open(os.path.join(HERE, B.MD), encoding='utf-8').read()
L = md.split('\n')

def md_records():
    out, cur = [], None
    for ln in L:
        m = re.match(r'^### (RER-[A-Z0-9-]+) — ', ln)
        if m or ln.startswith('## ') or ln.startswith('<a id='):
            if cur: out.append(cur); cur = None
        if m: cur = {'id': m.group(1), 'lines': []}
        elif cur is not None: cur['lines'].append(ln)
    if cur: out.append(cur)
    return out

def gates(outs, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_4_PHASEA.json']); cm = json.loads(outs['out/SOURCE_CURRENCY_MATRIX.json']); br = json.loads(outs['out/BLOCKED_SOURCE_REGISTER.json'])
    g('A1 source and catalog pins', sha(md.encode()) == B.MD_SHA and all(sha(open(os.path.join(HERE, f), 'rb').read()) == h for f, h in PINS['inputs'].items()))
    fresh = B.build()
    g('A2 deterministic rebuild equals stored outputs', all(fresh[p] == outs[p] for p in fresh) and set(fresh) == set(outs))
    mr = md_records(); gaps = {'RER-G7', 'RER-G8', 'RER-G9', 'RER-G10'}
    mids = [r['id'] for r in mr if r['id'] not in gaps]; jids = [r['id'] for r in reg['records']]
    g('A3 record set mirrors Markdown', mids == jids and len(set(jids)) == len(jids) == 20 and sorted(x['id'] for x in reg['gap_entries']) == sorted(gaps), f'{len(jids)} records')
    bad = []
    for r in mr:
        if r['id'] in gaps: continue
        j = next((x for x in reg['records'] if x['id'] == r['id']), None)
        if j is None: bad.append((r['id'], 'missing')); continue
        gl = next((l for l in r['lines'] if l.startswith('**Primary grade:**')), '')
        if j['primary_grade'] is None or j['primary_grade'] not in gl or ('`' + j['task'] + '`') not in gl: bad.append((r['id'], 'grade/task'))
        for row in ['Carrier', 'Observables', 'Constraints', 'Transformation law', 'Closure status', 'Memory']:
            cell = next((l for l in r['lines'] if l.startswith('| ' + row + ' | ')), None)
            if cell is None or cell != f"| {row} | {j['contract'][row]} |": bad.append((r['id'], row))
        if sum(l.startswith('Import/reference:') for l in r['lines']) != len(j['imports']): bad.append((r['id'], 'imports'))
        if sum(l.startswith('[OPEN] ') for l in r['lines']) != len(j['open_items']): bad.append((r['id'], 'open'))
    g('A4 field mirror (grade, task, six cells, imports, OPENs)', not bad, f'{len(bad)} mismatches {bad[:2]}')
    need = ['record', 'key', 'source_doc', 'cited_version', 'cited_sha256', 'current_owner_version', 'current_owner_sha256', 'section_or_RID', 'inspection_extent', 'currency', 'reviewer_disposition', 'bytes_status']
    occ = sum(len(x['imports']) for x in reg['records'])
    keys_ok = all(all(k in x for k in need) for x in cm['rows'])
    g('A5 one currency row per import occurrence, required fields present', len(cm['rows']) == occ and keys_ok and all(x['reviewer_disposition'] == 'PENDING' for x in cm['rows']), f'{len(cm["rows"])} rows')
    bb = []
    pkg = B.rd('inputs/r4_4_package_SHA256SUMS.txt').decode()
    for x in cm['rows']:
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH':
            f = os.path.join(HERE, x['available_file'] or '')
            if not os.path.isfile(f) or sha(open(f, 'rb').read()) != x['cited_sha256']: bb.append(x['key'])
        elif x['available_file']: bb.append(x['key'])
        if x['path_in_r4_4_package'] and ('  ' + x['cited_path']) not in pkg: bb.append(x['key'] + ':pkg')
    g('A6 byte and package-path claims are true', not bb, f'{bb[:3]}')
    st = [x for x in cm['rows'] if x['source_family'] == 'OWNER_DSN' and x['current_owner_version'] and x['cited_version'] != x['current_owner_version']
          and (x['currency'] in ('CURRENT',) or not x['currency_reason'])]
    g('A7 stale owner pins carry a non-CURRENT status and a reason', not st, f'{len(st)} stale')
    er = [x for x in reg['records'] if x['id'] in ('RER-ER2B-T6D', 'RER-ER2B-CARRIER')]
    g('A8 ER-2B firewall', len(er) == 2 and all(x['phaseA_status'] == 'BLOCKED_SOURCE_UNVERIFIED' and x['accepted_cohort_eligible'] is False and x['grade_status'] == 'SOURCE_CLAIMED_NOT_RER_ADOPTED' for x in er)
      and all(x['accepted_cohort_eligible'] for x in reg['records'] if x not in er))
    g('A9 no promotion: adoption PENDING everywhere', all(x['adoption_status'] == 'PENDING' and x['registry_owner_adoption'].startswith('pending') for x in reg['records']))
    c = next(x for x in reg['records'] if x['id'] == 'RER-RRF-CND01')
    g('A10 RRF-CND01 provenance split', c['claim_provenance'] == 'RER_NATIVE_STANDARD_MATH' and '[DEF] proposed interface' in c.get('provenance_note', '') and 'NOT the source of the [THM]' in c.get('provenance_note', ''))
    lg = reg['legacy_v0_1_snapshot']
    g('A11 legacy v0.1 snapshot separate', lg['label'] == 'HISTORICAL_SNAPSHOT_NOT_AN_ADOPTION_COHORT' and len(lg['entries']) == 16 and not set(e['key'] for e in lg['entries']) & set(jids))
    srcs = {b['source'] for b in br['blocked']}
    mpi = {m for x in reg['records'] for m in x['missing_primary_inputs']}
    dna = {re.findall(r'`([^`]+)`', l)[1] for l in L if l.startswith('| `') and 'Direct source not available' in l}
    erb = next((b for b in br['blocked'] if b['source'] == 'RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'), {})
    g('A12 blocked register complete', mpi <= srcs and dna <= srcs and set(erb.get('blocked_records', [])) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'}, f'{len(srcs)} sources')
    lost = sorted(set(x['key'] for x in cm['rows'] if x['path_in_r4_package'] and not x['path_in_r4_4_package']))
    g('A13 packaging finding lists every lost cited file', lost == br['lost_in_packaging'] and all(k in br['packaging_finding'] for k in lost), f'{len(lost)} files')
    st_ok = all(x['status'] in ('VERIFIED', 'OWNER_REPORTED', 'HISTORICAL', 'BLOCKED') and x['status'] == B.status_of(x) for x in cm['rows'])
    vh_ok = all((x['verified_current_hash'] is None) or (x['current_owner_evidence'] in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER') and x['verified_current_hash'] == x['current_owner_sha256']) for x in cm['rows'])
    ver_ok = all(x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in cm['rows'] if x['status'] == 'VERIFIED')
    g('A14 receiver status vocabulary and verified-hash discipline', st_ok and vh_ok and ver_ok)
    return all(res), res

outs = {p: open(os.path.join(HERE, p), 'rb').read() for p in B.build()}
ok, res = gates(outs); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    def mut(path, f):
        o = dict(outs); d = json.loads(o[path]); f(d); o[path] = B.dump(d); return o
    R, C, K = 'out/RER_REGISTRY_v0_2_r4_4_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'
    T = [('A3 drop a record', 2, mut(R, lambda d: d['records'].pop(5))),
         ('A4 change a contract cell', 3, mut(R, lambda d: d['records'][0]['contract'].__setitem__('Closure status', 'CLOSED'))),
         ('A6 false byte claim', 5, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY').update(bytes_status='BYTE_VERIFIED_MATCH', available_file='sources_available/none'))),
         ('A7 stale pin marked CURRENT', 6, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'GEN287').update(currency='CURRENT'))),
         ('A8 ER-2B unblocked', 7, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-ER2B-T6D').update(phaseA_status='ACTIVE', accepted_cohort_eligible=True))),
         ('A9 promote adoption', 8, mut(R, lambda d: d['records'][3].update(adoption_status='ADOPTED'))),
         ('A12 drop a blocked source', 11, mut(K, lambda d: d['blocked'].pop(0))),
         ('A14 printed-only row labelled VERIFIED', 13, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY' and x['currency'] != 'BLOCKED').update(status='VERIFIED')))]
    allf = True
    for n, i, o in T:
        _, rr = gates(o, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    ok = ok and allf
sys.exit(0 if ok else 1)
