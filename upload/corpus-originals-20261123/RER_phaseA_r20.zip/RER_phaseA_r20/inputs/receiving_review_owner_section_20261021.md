# Owner section comparison — independent receiving review

**Date:** 21 October 2026.  
**Status:** NONCANONICAL receiver evidence and scoped decisions. No owner adoption, freeze, publication, source repin or Phase A output modification.  
**Object reviewed:** `OWNER_SECTION_CHECK_r1.zip`, SHA-256 `231201a558ef47732979ff6de6a658f192ac95984c22c49a501283637b9d7753`.  
**Decision:** **ACCEPT SCOPED — source identity, executable comparison and claim-scoped consumer impact.** A small summary-count correction is recorded below; no source result is rejected.

## 1. Sources, authority and actual reading

[SESSION: inspected here] Governing sources actually found: DSN Methodology **v1.3**, Programme **v1.2**, OFN **v0.10**. Relevant scientific sources: Dyadic **v6.4.18/v6.4.19**, RECOG **v0.3.21/v0.3.22**, RRF **v0.8.3/v0.8.4**; supplemental historical originals Dyadic **v6.4.13**, RECOG **v0.3.20**, RRF **v0.8.2**. RER consumer: **v0.2 DRAFT r4.13**, SHA-256 `e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c`; machine baseline **Phase A r18**. Genesis **v2.8.9 §6.3c** and OFN **§5.5.4** were consulted only for the new RRF class-C scope boundary. These are the verified available editions for this review, not a global latest-release claim.

The preparer note and checker were read completely. The 31 declared old/new comparison blocks were checked as byte spans; changed-block diffs and relevant RER G7–G10, CND01 and DYAD record passages were inspected. Whole owner documents were hashed but were **not** read as full scientific ledgers or re-proved. `source_manifest.json` records exact file hashes and reading scopes.

[OWNER: Methodology v1.3 §§3.3, 12.1–12.4] Identity, execution, scientific adequacy and adoption are separate. An old pin is not invalid merely because a newer edition exists; its actual claim and changes must be checked. Programme v1.2 §7.3/SG-PROG-4 and OFN v0.10 preserve the physical-transfer boundary.

## 2. Replay and independent extraction

[SESSION: executed here] Two clean directories were extracted from the uploaded ZIP. All **15/15 manifest entries** passed before and after execution. In each directory:

```text
python -I -B owner_section_check.py
python -I -B owner_section_check.py --check
python -I -B owner_section_check.py --negcontrol
```

All six subprocesses returned 0 with empty stderr. The JSON, diff and comparison report remained byte-identical to their packaged versions. The negative-control stdout matched the packaged negative-control log exactly in both runs. All **3/3** preparer bit-flip controls detected a section mismatch. No bytecode cache appeared in the replay directories.

[SESSION: independently computed here] A separate receiver implementation (`independent_owner_audit.py`) does **not import the preparer checker**. It verifies the same declared source identities and section specification using byte offsets, unique active-section anchors and original line endings. All **31/31** reported section statuses, retained-content hashes and ranges reproduced. All **6/6** file hashes matched. Three additional receiver controls recomputed both mutated whole-file identity and raw-block inequality. The copied r18 matrix was compared with the original mounted `RER_phaseA_r18.zip` and is byte-identical.

**Extraction convention:** the preparer strips terminal empty lines before joining the section content, so its section digests describe those retained content slices, not the untrimmed heading-to-heading span. The receiver also compared the **raw** heading-to-heading spans, including terminal separators. The equality/change classifications are the same. Both digest forms are stored in `independent_audit_results.json`. Do not mix their hashes or line-end conventions.

**Checker boundary:** normal mode is documented to accept six pinned file identities and report section differences; it is not a mathematical proof gate. `--check` adds equality to stored outputs. In `--negcontrol`, the preparer's printed whole-file `MATCH` flag is computed before mutation; it should not be read as a valid hash for the mutated digest. The receiver's additional controls recompute the mutated file hash explicitly. This diagnostic limitation does not change the successful mismatch controls or positive-run identities.

## 3. Results and summary correction

[SESSION: independently computed here]

| Owner pair | Compared objects | Result |
|---|---|---|
| Dyadic 6.4.18→6.4.19 | Five cited blocks; OPEN21 and §6.14 as context | Five cited blocks IDENTICAL; OPEN21 also IDENTICAL; §6.14 CHANGED |
| RECOG 0.3.21→0.3.22 | §6.6a and §6.16g | 2/2 IDENTICAL |
| RRF 0.8.3→0.8.4 | 22 declared blocks | **9 IDENTICAL, 11 CHANGED, 2 NEW** |

**OSC-N1 — corrected count (nonblocking):** the submission message says RRF 10 identical / 10 changed / 2 new. The package JSON and its detailed table actually yield **9 / 11 / 2**. The detailed block results are correct; only the prose count needs correction in the receiving/change record. No scientific rerun or rewritten owner file is required.

The Dyadic “only §6.14 changed” reading applies to the selected scientific comparison blocks, not the entire document: the whole file contains 13 change hunks, including metadata and result pointers. The packet itself records that distinction. Likewise, the 22 RRF blocks are not a disjoint coverage certificate for the entire RRF document.

## 4. Additional historical evidence recovered here

[SESSION: recovered and hash-verified here] Two missing originals were found inside the existing mounted `TRIAD_RER_RECEIVING_REVIEW_20261019.zip`, whose hash is `9bfeca625d43cffcce027e6d8bbb808daa4570e60e60cbe06d97ef156a337c12`:

| File | SHA-256 |
|---|---|
| Dyadic v6.4.13 | `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` |
| RRF v0.8.2 | `f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461` |

They were extracted without modification and compared with the printed pin hashes. Container/member extraction was replayed here; external custody before that archived package was not reconstructed. Both originals and a precise custody receipt are included in this handoff. This is **additional receiver evidence**, not a retroactive change to the preparer's honest `SOURCE_MISSING` state.

RECOG v0.3.20 was also recovered from the earlier W3 quote archive and checked against `fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df`. Its §6.6a and §6.16g were compared **directly** with v0.3.21 and v0.3.22; all four raw comparisons are identical. Thus the pin-to-current conclusion no longer depends solely on an old comparison log.

[SESSION: independently computed here] Direct Dyadic v6.4.13→v6.4.19:
- OPEN19, §6.15 and §6.16: raw-byte-identical.
- Whole OPEN20 and §6.17: **changed**, not byte-identical.
- Lemma F, its proof sketch, the F1–F3 premise paragraph and each of F1/F2/F3: exact retained paragraphs. The existence update is a separate result.

**OSC-N2 — historical RRF currency reason needs correction:** direct RRF v0.8.2→v0.8.3 comparison shows **both §2.4b and §4.2 changed**. §2.4b adds/updates the smooth clock bridge, flat uniqueness and class-wise existence equivalence. §4.2 gains the N9 receipt. §4.2 is identical only for the **v0.8.3→v0.8.4** leg. Therefore r18's earlier reason that only §2.4c changed is not a safe basis for current-use equality. Preserve that statement as an earlier report if needed, but append this independent correction; do not label the old-to-current pair `UNCHANGED_VERIFIED`.

RRF v0.8 was not found in the targeted local/source-name/top-level archive search. Its 12 pinned reference rows remain without independently replayed original-file authentication here. RRF v0.8.2 recovery does not supply v0.8.

## 5. RRF semantic source review

### 5.1 Smooth existence versus the older formal receipt

[OWNER: Dyadic v6.4.19 §6.17; RRF v0.8.4 §§2.4, 2.4b–c, 6.2, §8 item 12] The update distinguishes existing-object F1–F3 from the E1–E4 existence theorem. The imported result remains local C∞ germ mathematics; E2 uniqueness is restricted to generators with zero linear part. B-an/B-6 remain OPEN, the finite `S_h` is not promoted to an exact dynamical symmetry, and `EF=TE` is not identified with `EF=T^6E`.

[SESSION: consumer comparison] RER r4.13's separate DYAD6418 import and non-transfer clauses already express these distinctions. The changed RRF §2.4b content is **compatible at the RER use point**, but not byte-identical. RRF082 remains a historical import; RRF083's §2.3 is identical while its §2.4b is changed. Whole-row identity must not be inferred from one unchanged subsection. No new RER theorem correction follows from this comparison.

### 5.2 W3 and G9

[OWNER: RECOG v0.3.20/v0.3.21/v0.3.22 §6.16g; RRF v0.8.4 §6.3] The same-space W3 wording is present exactly once in each of those three RECOG sources, RRF v0.8.4 and RER r4.13, and is absent from RRF v0.8.3. The new RRF paragraph labels different-space maps into a common space as a separate OPEN extension with no registered map.

[SESSION: receiving scope decision] The **current-source wording discrepancy is resolved** at the inspected use point. This is source fidelity, not a cohomology transport theorem, a network realization or closure of CELL-F4. This owner-section package does **not** change G9/1 or G9/3 `PENDING_PER_REFERENCE_AUDIT`; those require an explicit per-reference disposition. G9/3 still lacks the original RRF v0.8 bytes. The editor's old-leg statement remains `EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED`.

### 5.3 New class-C contract

[OWNER: RRF v0.8.4 §6.2a; OFN v0.10 §5.5.4; Genesis v2.8.9 §6.3c] RRF describes reimposed mean feedback in a transported carrier as a different conditional model, not passive recharting and not a new native network profile. Its smooth isolated-dyad chart consequence is kept separate from adoption/selection of the class-C network family. The Q6 statement retains real C³, the stated third jet, `(H_spec)`, `mu != 0` and `gamma not in {0,2}`; no physical or all-carrier exclusion follows.

[SESSION: receiving scope decision] This new RRF entry is context for a future G2 comparison, not a replacement for the absent original G2 v0.4 §5b. No G2 carrier identification, Triadic G6 closure, or physical branch choice is supplied. No new mathematical derivation or owner-certificate rerun was performed.

### 5.4 Historical/current presentation

[SESSION: inspected here] RRF v0.8.4 contains explicit current-state overrides while retaining old receipts. Their dated historical limitations are not read as current blanket denials of smooth existence. RER G10 line 152 still carries the dated r4.4 wording “v0.8.3 ... governs”, while G9 contains the later v0.8.4 adoption note. A later authorized consumer-source maintenance should make G10's current working-standard pointer explicit and retain the dated text as history. This is **not** a new contradiction in the scoped mathematical records and does not block this package.

## 6. Authorized next step: one narrow Phase A r19

[SESSION: receiving decision] A single separate r19 may record the evidence obtained here. Do not change r18 or RER r4.13. Exact instructions for all 18 owner rows are in `row_dispositions_18.json` and `.md`.

1. Current owner identities Dyadic 6.4.19, RECOG 0.3.22, RRF 0.8.4 may be `BYTE_VERIFIED` **when their real files and custody receipts are included and checked**. Matching identities are not theorem-proof certifications.
2. DYAD6418 and the two RECOG rows may use `UNCHANGED_VERIFIED` / `VERIFIED`. Preserve v6.4.18 and v0.3.20 pins. Their cited block equalities are complete.
3. Include recovered Dyadic v6.4.13 and RRF v0.8.2 originals with this receipt. Once locally rehashed, their row authentication may be `BYTE_VERIFIED_HERE`. Keep both rows `HISTORICAL`: relevant whole sections changed, even though retained claims are compatible. Preserve the exact old pins.
4. Keep RRF083 `HISTORICAL`/`RECHECK_IN_PHASE_B`; add a separate source-section review field/receipt recording §2.3 IDENTICAL and §2.4b CHANGED but consumer-compatible. Do not encode this as whole-row equality. RRF082 similarly receives its corrected multi-leg comparison, not an unchanged label.
5. RRF08_ADOPTED's 12 rows retain their original-source evidence limits. The current owner's hash can be verified without upgrading those historical pin hashes. No old v0.8 equality is manufactured from the new file.
6. All scientific records, grades, OPEN states, pins, the closed synchronization receipt, gap audit statuses and the ER-2B/G2 blocks remain unchanged. Preserve all r18 outputs as dated history. Pin the exact source files, this receipt and the comparison artefacts; test missing/altered files, silent repinning, incorrect whole-row equality and premature gap closure.

[SESSION: prospective counts, not an executed Phase A revision] With only these three overall-status upgrades, the expected distribution is **31 VERIFIED / 2 OWNER_REPORTED / 52 HISTORICAL / 6 BLOCKED** (91 rows). Including and rehashing the two recovered old originals changes authentication from **60/6/24/1** to **62 BYTE_VERIFIED_HERE / 4 RECEIVER_BYTE_VERIFIED / 24 HASH_PRINTED_UNVERIFIED / 1 UNAUTHENTICATED_NO_HASH**. These are acceptance expectations, not a created or accepted r19.

## 7. Work not performed; final disposition

[SESSION: execution boundary] No Dyadic smooth embedding, centralizer, RECOG or Genesis scientific certificate was executed or independently re-proved in this review. No Stage-2 or Triadic scientific calculation was started. No owner adoption authorization was authenticated beyond the recorded source lifecycle. No old RRF v0.8 original was recovered. No G9 per-reference audit was closed.

[SESSION: receiving decision] **OWNER_SECTION_CHECK r1: ACCEPT SCOPED.** The 9/11/2 count correction and the supplemental historical RRF delta are receiving-record corrections, not grounds for rewriting owner sources or silently repairing the submitted package. RER **r4.13 DRAFT** and Phase A **r18 ACCEPT SCOPED** remain the current working objects in this review; r19 preparation is authorized only as above. G2 §5b, ER-2B source blocks, G9/1–G9/3 and Stage-2 regional/global certification remain open.

## Reproduction and evidence files

`replay_summary.json`, `independent_audit_results.json`, `source_manifest.json`, `recovered_source_custody.json`, `row_dispositions_18.json`, `recovered_RRF082_to083.diff` and `logs/` distinguish supplied-code replay from the receiver's separate extraction. `README.md` gives portable commands. A final handoff manifest hashes all files except itself.
