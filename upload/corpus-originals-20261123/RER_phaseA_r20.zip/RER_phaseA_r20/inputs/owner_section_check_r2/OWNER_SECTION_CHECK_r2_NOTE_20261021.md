# Owner section check r2 — old-edition legs (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE (Claude, RER co-owner). NONCANONICAL. Identity, section equality, exact differences, paragraph retention, citing RER rows and a labelled preparer reading are separate axes. **No acceptance, grade, catalog change, adoption, freeze or publication is proposed here.** This package is the local replay the receiver's r19 review (§5) and the owner-section review (§6 table, row "recovered DYAD6413 and RRF082") require before any later catalog step may use `BYTE_VERIFIED_HERE` for those two pins; that step (a Phase A r20) is **not** built here and needs its own authorization.

## 1. Source transfer verified here

`RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip`, SHA-256 `efb824cc790052c5d2a7299ef8bf8fe0581e141f7cdc648c19d340d10a1e30af` (receiver delivery, uploaded by the PI). Manifest 4/4 OK. The two originals were hashed here:

| File | Bytes | SHA-256 here | RER pin | Result |
|---|---:|---|---|---|
| `RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md` | 187,458 | `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` | DYAD6413 | **MATCH** |
| `RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md` | 88,773 | `f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461` | RRF082 | **MATCH** |

Custody (receiver `CUSTODY.json`, pinned in `inputs/`): extracted anew from `TRIAD_RER_RECEIVING_REVIEW_20261019.zip` (`9bfeca62…37c12`), compared byte-for-byte with the previous owner-section handoff copies; external custody before that archive NOT_REAUTHENTICATED (receiver statement, kept as is). Preparer chain: upload → hashed here (BYTE_VERIFIED_HERE for file identity; the upstream chain stays receiver-declared).

Other sources: v6.4.18, v6.4.19, v0.8.3, v0.8.4 copied from the accepted Phase A r19 package `sources_available/` (hashes equal the catalog identities; see `compare_output.txt`).

## 2. Results (`out/compare_output.txt`; exact diffs in `out/changed_blocks.diff`)

| Leg | IDENTICAL | CHANGED |
|---|---|---|
| Dyadic v6.4.13 → v6.4.18 | §2 OPEN 19, §6.15, §6.16 | §2 OPEN 20 (1/2 paragraphs retained), §6.17 (7/8 retained: Lemma F and F1–F3 paragraphs verbatim) |
| Dyadic v6.4.13 → v6.4.19 | same (v6.4.18 → v6.4.19 IDENTICAL on these blocks, r1) | same |
| RRF v0.8.2 → v0.8.3 | §2.3, §2.4a, §4.2a, §4.3, §6.3, §6.4 | §2.4 (1/2), **§2.4b (5/8)**, **§4.2 (6/6 retained; additive N9 overlay)**, §6.2 (7/8) |
| RRF v0.8.2 → v0.8.4 | §2.3, §2.4a, §4.3, §6.4 | §2.4, §2.4b, §4.2, §4.2a, §6.2, §6.3 |

These agree with the receiver's RECEIVER-REPORTED results (r19 review §5; owner-section review §3): v6.4.13 → v6.4.19 OPEN 19 / §6.15 / §6.16 identical, OPEN 20 / §6.17 changed with the Lemma F / F1–F3 paragraphs retained; v0.8.2 → v0.8.3 **both §2.4b and §4.2 changed** (OSC-N2 confirmed here), §4.2 identical only on v0.8.3 → v0.8.4; §6.2 not byte-identical v0.8.2 → v0.8.3 (receiver's earlier finding).

**What the RER pins see.** DYAD6413 cites §2 OPEN 19/20 and §§6.15–6.17 at v6.4.13: three blocks unchanged through v6.4.19, two changed (owner closing B-∞ existence, additive with one marked line and one rewritten status line). RRF082 cites §2.4b and §4.2 at v0.8.2: §4.2 additive overlay, §2.4b three paragraphs rewritten (reworded in the direction of the DYAD v6.4.13 results the RER record imports). RRF083 cites §2.3 (identical from v0.8.2 through v0.8.4) and §2.4b. **Whole-row old-to-current equality is not supported for DYAD6413 or RRF082 and is not asserted.** The preparer readings are labelled PREPARER_READING in the JSON and are not receiver findings.

Not covered: RRF v0.8 (`c4ec1f10…b44a`) is still SOURCE_MISSING; the 12 RRF08_ADOPTED pins are not verified by this check. G9/1–G9/3, G2 §5b, ER-2B, Stage-2 unchanged.

## 3. Replay

```
sha256sum -c SHA256SUMS.txt
python -I -B owner_section_check_r2.py --check        # out/* byte-identical, exit 0
python -I -B owner_section_check_r2.py --negcontrol   # 4/4 caught, exit 0
```

Negative control: one byte flipped in memory inside an honestly IDENTICAL block of the new file of each leg (§2 OPEN 19 for Dyadic, §2.3 for RRF); each is reported CHANGED. The block cutter trims trailing blank lines of a block (as in r1); the receiver's raw-slice replay in r1 gave the same verdicts.

## 4. Proposed (not built) r20 scope, for the receiver's decision

If authorized: Phase A r20 on the unchanged RER r4.13 and r19 catalog, adding the two files to `sources_available/` (`DYAD6413__…v6_4_13.md`, `RRF082__…v0_8_2.md`) with a custody r20 record and this package pinned; DYAD6413 and RRF082 rows `BYTE_VERIFIED_HERE` / `BYTE_VERIFIED_MATCH`, currency unchanged (RECHECK_IN_PHASE_B / HISTORICAL), reasons citing this check (no whole-row equality); expected statuses 31/2/52/6 unchanged, authentication 62/4/24/1; and the r19 change-record locator correction (§5 → §6) recorded in the r20 change record, r19 bytes untouched.
