"""Owner section check r2 — the old-edition legs that r1 left SOURCE_MISSING / NOT_REPLAYED (receiver source transfer RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip,
efb824cc…30af; r19 receiving review §5; owner-section review §6 table, row "recovered DYAD6413 and RRF082"):
  Dyadic v6.4.13 -> v6.4.18 and v6.4.13 -> v6.4.19 : §2 OPEN 19, §2 OPEN 20, §6.15, §6.16, §6.17 (cited by the DYAD6413 row, pin v6.4.13)
  RRF    v0.8.2  -> v0.8.3  and v0.8.2  -> v0.8.4  : §2.3, §2.4, §2.4a, §2.4b, §4.2, §4.2a, §4.3, §6.2, §6.3, §6.4 (RRF082 cites §2.4b, §4.2; RRF083 cites §2.3, §2.4b)
Axes kept separate (receiver instruction): file identity (the two recovered files are hashed here against the RER pins); section byte equality; what changed (exact diff);
paragraph retention inside a CHANGED block (which old paragraphs survive verbatim); the RER rows that cite the section; a PREPARER_READING of each change.
Whole-row old-to-current equality is NOT asserted for any changed block. v0.8 (c4ec1f10…b44a) stays SOURCE_MISSING. No acceptance, grade or catalog change is proposed by this script.
Usage: python -I -B owner_section_check_r2.py              -> compare the four legs, write out/*; exit 0 iff all six file hashes match
       python -I -B owner_section_check_r2.py --check      -> compare and verify out/* byte-identical (no write)
       python -I -B owner_section_check_r2.py --negcontrol -> flip one byte inside one honestly IDENTICAL block of the new file of each leg; each must be
                                                             reported CHANGED (exit 0 iff all four are caught)"""
import sys, hashlib, difflib, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; SRC = HERE / 'sources'; OUT = HERE / 'out'
sha = lambda b: hashlib.sha256(b).hexdigest()
D13 = ('RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md', '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542', 'v6.4.13')
D18 = ('RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md', 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d', 'v6.4.18')
D19 = ('RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md', '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9', 'v6.4.19')
R82 = ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md', 'f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461', 'v0.8.2')
R83 = ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md', 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187', 'v0.8.3')
R84 = ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md', '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce', 'v0.8.4')
DSPEC = [('§2 OPEN 19', '**OPEN 19 —', '---'), ('§2 OPEN 20', '**OPEN 20 —', '---'), ('§6.15', '### §6.15', '### §6.16'), ('§6.16', '### §6.16', '### §6.17'), ('§6.17', '### §6.17', '## §7.')]
RSPEC = [('§2.3', '## 2.3 ', '## 2.4 '), ('§2.4', '## 2.4 ', '## 2.4a'), ('§2.4a', '## 2.4a', '### 2.4b'), ('§2.4b', '### 2.4b', ('### 2.4c', '## 2.5 ')),
         ('§4.2', '## 4.2 ', '### 4.2a'), ('§4.2a', '### 4.2a', '## 4.3 '), ('§4.3', '## 4.3 ', '# 5. '),
         ('§6.2', '### 6.2 ', ('### 6.2a', '### 6.3 ')), ('§6.3', '### 6.3 ', '### 6.4 '), ('§6.4', '### 6.4 ', '# 7. ')]
PAIRS = {'Dyadic 13->18': D13 + D18 + (DSPEC,), 'Dyadic 13->19': D13 + D19 + (DSPEC,), 'RRF 82->83': R82 + R83 + (RSPEC,), 'RRF 82->84': R82 + R84 + (RSPEC,)}
# RER rows (Phase A r19 matrix) citing each section
CITED = {
 ('Dyadic', '§2 OPEN 19'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413 (pin v6.4.13)'], ('Dyadic', '§2 OPEN 20'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413 (pin v6.4.13)', 'RER-DYAD-FORMAL-INVOLUTION/3 DYAD6418 (pin v6.4.18; leg v6.4.18 -> v6.4.19 checked in r1)'],
 ('Dyadic', '§6.15'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413'], ('Dyadic', '§6.16'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413'], ('Dyadic', '§6.17'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413', 'RER-DYAD-FORMAL-INVOLUTION/3 DYAD6418 (pin v6.4.18)'],
 ('RRF', '§2.3'): ['RER-DYAD-FORMAL-INVOLUTION/2 RRF083 (pin v0.8.3; leg v0.8.3 -> v0.8.4 checked in r1: IDENTICAL)'],
 ('RRF', '§2.4b'): ['RER-DYAD-FORMAL-INVOLUTION/1 RRF082 (pin v0.8.2)', 'RER-DYAD-FORMAL-INVOLUTION/2 RRF083 (pin v0.8.3; leg v0.8.3 -> v0.8.4 checked in r1: CHANGED)'],
 ('RRF', '§4.2'): ['RER-DYAD-FORMAL-INVOLUTION/1 RRF082 (pin v0.8.2)'],
 ('RRF', '§2.4'): ['not cited at this pin (context; RRF-DYAD-NF row)'], ('RRF', '§2.4a'): ['not cited at this pin (context)'], ('RRF', '§4.2a'): ['RER-G9/2 RRF08_ADOPTED (pin v0.8; SOURCE_MISSING leg) — context here'],
 ('RRF', '§4.3'): ['not cited at this pin (context)'], ('RRF', '§6.2'): ['RER-RRF-CND01/2, RER-G7/0, RER-G8/2 RRF08_ADOPTED (pin v0.8; SOURCE_MISSING leg) — context here; receiver earlier reported v0.8.2 -> v0.8.3 §6.2 NOT byte-identical'],
 ('RRF', '§6.3'): ['RER-G9/3 RRF08_ADOPTED (pin v0.8; SOURCE_MISSING leg) — context here'], ('RRF', '§6.4'): ['RER-G10/1 RRF08_ADOPTED (pin v0.8; SOURCE_MISSING leg) — context here'],
}
OLD_LEGS = {'Dyadic': 'v6.4.13 bytes now held (receiver source transfer, hashed here = RER pin 5958f7fe…8542); v6.4.13 -> v6.4.18 and v6.4.13 -> v6.4.19 compared directly here. The v6.4.18 -> v6.4.19 leg is in r1 (cited blocks IDENTICAL).',
            'RRF': 'v0.8.2 bytes now held (receiver source transfer, hashed here = RER pin f09dbb12…5461); v0.8.2 -> v0.8.3 and v0.8.2 -> v0.8.4 compared directly here. v0.8 (c4ec1f10…b44a) is still SOURCE_MISSING: the 12 RRF08_ADOPTED pins are NOT verified by this check.'}
READING = {
 ('Dyadic 13->18', '§2 OPEN 20'): 'changed — status line rewritten (B-∞ existence CLOSED (v6.4.18) by DYAD-THM-SMOOTH-EMBEDDING; flat uniqueness CLOSED (v6.4.13) kept; B-an/B-6 ACTIVE) with the v6.4.17 status retained verbatim as history inside the line; one new "(B-∞ existence — v6.4.18) [THM] CLOSED" line inserted before the retained v6.4.13 "(B-∞ existence) [OPEN]" line; the B-an line and the (B-∞) sub-question line are unchanged. The RER DYAD6413 import (formal involution, F1–F3 classification) is not the changed statement; the change is the owner closing B-∞ existence, which RER r4.13 imports separately via DYAD6418',
 ('Dyadic 13->18', '§6.17'): 'changed — additive with one reworded line: the v6.4.13 "[OPEN] Not established" line is kept with a "[v6.4.17] … (v6.4.17 state; existence … addressed by the v6.4.18 entries below)" marker; the v6.4.18 smooth-flow-embedding block (sources paragraph, [THM] DYAD-THM-SMOOTH-EMBEDDING E1–E4, proof outline, [DEF] recorded distinctions) is appended; the Lemma F and F1–F3 paragraphs of v6.4.13 are retained verbatim (7 of 8 old paragraphs). F1–F3 grades stated unchanged ([THM — conditional]) with their existence condition discharged by E1',
 ('Dyadic 13->19', '§2 OPEN 20'): 'same change as the v6.4.13 -> v6.4.18 leg (the v6.4.18 -> v6.4.19 leg is IDENTICAL for this block, r1)',
 ('Dyadic 13->19', '§6.17'): 'same change as the v6.4.13 -> v6.4.18 leg (the v6.4.18 -> v6.4.19 leg is IDENTICAL for this block, r1)',
 ('RRF 82->83', '§2.4'): 'changed — one sentence of the formal-involution row reworded: "Existence/convergence of the formal involution is OPEN 20, not closed by formal uniqueness (§2.4b)" becomes "… remains OPEN 20 (B-an/B-∞ existence); the new v6.4.13 F1–F3 results classify existing C∞ involutions and roots (§2.4c), not their existence"; the formal-uniqueness statement, the S_h jet-six limit and the other rows are unchanged. Not cited by RER at the v0.8.2 pin',
 ('RRF 82->83', '§2.4b'): 'changed — three paragraphs rewritten (5 of 8 retained verbatim): (a) the analytic clock-bridge paragraph now says the C∞ six-step involution is upgraded to exact primitive commutation by adopted DYAD v6.4.13 §6.17 F1 (was: "exact primitive commutation is not established: the difference is flat"); (b) the OPEN 20 paragraph now lists B-an / B-6 / B-∞ existence separately and records B-∞ flat uniqueness CLOSED for existing germs (Lemma F, F1–F3) as distinct from existence; (c) the G2-PRE existence-equivalence paragraph is generalized from analytic to class-wise (C∞ and analytic) with F3 as the reverse direction. The RRF082 citation (§2.4b) therefore does not read the same text in v0.8.3: cited statement reworded, in the direction of the DYAD v6.4.13 results the RER record itself imports; not an equality',
 ('RRF 82->83', '§4.2'): 'changed — additive: an "N9 update (current owner receipt)" paragraph inserted (formal J = T∘F^{-1/6}, R_0 = J³; F1/F2 exact primitive commutation and uniqueness for existing C∞ involutions, not existence; not OPEN-A closure); all 6 old paragraphs retained verbatim. The RRF082 citation (§4.2) sees an additive overlay',
 ('RRF 82->83', '§6.2'): 'changed — the regularity/clock decision paragraph reworded: "For C∞, formal jet equality yields only a flat primitive commutator, and its exact vanishing remains DYAD OPEN 20 (B-∞)" becomes "For an existing C∞ involution … F1 upgrades flat primitive commutation to exact RT=TR; F2 uniqueness, F3 roots. This does not supply such an involution/root. For finite C^r the exact clock bridge is not imported"; import pin added; 7 of 8 paragraphs retained. Matches the receiver\'s earlier RECEIVER-REPORTED finding (§6.2 not byte-identical v0.8.2 -> v0.8.3). Cited by RER only at the v0.8 pin (SOURCE_MISSING leg)',
 ('RRF 82->84', '§2.4'): 'composition: the v0.8.2 -> v0.8.3 rewording above, then the v0.8.3 -> v0.8.4 rewording of r1 (C∞ existence CLOSED by DYAD v6.4.18 E1–E4, override pointer)',
 ('RRF 82->84', '§2.4b'): 'composition: the three v0.8.2 -> v0.8.3 rewritten paragraphs above, then the v0.8.3 -> v0.8.4 additive override paragraph of r1 (B-∞ existence CLOSED); 5 of 8 v0.8.2 paragraphs still verbatim in v0.8.4',
 ('RRF 82->84', '§4.2'): 'the v0.8.2 -> v0.8.3 N9 overlay only; v0.8.3 -> v0.8.4 IDENTICAL (r1); all 6 v0.8.2 paragraphs retained verbatim',
 ('RRF 82->84', '§4.2a'): 'changed only on the v0.8.3 -> v0.8.4 leg (r1: additive current owner-source pin paragraph); v0.8.2 -> v0.8.3 IDENTICAL; all 4 v0.8.2 paragraphs retained',
 ('RRF 82->84', '§6.2'): 'composition: the v0.8.2 -> v0.8.3 rewording above, then the two v0.8.3 -> v0.8.4 edits of r1 (notice paragraph prepended; "This does not supply such an involution/root" replaced by the DYAD v6.4.18 E1–E4 statement)',
 ('RRF 82->84', '§6.3'): 'changed only on the v0.8.3 -> v0.8.4 leg (r1: W3 same-cohomology-space wording and the different-space transport [OPEN] paragraph); v0.8.2 -> v0.8.3 IDENTICAL; 4 of 5 v0.8.2 paragraphs retained',
}
def owner_of(pair): return pair.split()[0]
def cut_blocks(b, spec):
    L = b.split(b'\n'); out = {}
    for name, start, end in spec:
        s = start.encode(); idx = [n for n, l in enumerate(L) if l.startswith(s)]
        if len(idx) == 0: out[name] = None; continue
        i = idx[0]
        if end is None: j = len(L)
        else:
            ends = (end,) if isinstance(end, str) else end
            j = next((n for n in range(i + 1, len(L)) if any(L[n].startswith(e.encode()) for e in ends)), len(L))
        while j > i + 1 and not L[j - 1].strip(): j -= 1
        out[name] = (i + 1, j, b'\n'.join(L[i:j]))
    return out
def compare(mut=None):
    report = {'_about': 'Owner section check r2 — old-edition legs (preparer: Claude, RER co-owner; NONCANONICAL). Identity, section equality, exact differences, citing RER rows and a labelled preparer reading are separate axes; no acceptance, grade or catalog change is proposed.', 'pairs': {}}
    lines = []; all_ok = True; neg_caught = {}
    for pair, (f_old, h_old, v_old, f_new, h_new, v_new, spec) in PAIRS.items():
        owner = owner_of(pair)
        b_old = (SRC / f_old).read_bytes(); b_new = (SRC / f_new).read_bytes()
        ok_old, ok_new = sha(b_old) == h_old, sha(b_new) == h_new
        B_old, B_new = cut_blocks(b_old, spec), cut_blocks(b_new, spec)
        if mut == pair:  # negative control: flip one byte in the middle of the first block that is honestly IDENTICAL
            tgt = next(n for n, _, _ in spec if B_old.get(n) and B_new.get(n) and B_old[n][2] == B_new[n][2])
            T = B_new[tgt][2]; p = b_new.index(T) + len(T) // 2; b_new = b_new[:p] + bytes([b_new[p] ^ 1]) + b_new[p + 1:]; B_new = cut_blocks(b_new, spec)
        lines += [f'== {pair}: {v_old} -> {v_new}', f'  {v_old} {sha(b_old)} {"MATCH" if ok_old else "NO MATCH"} ({len(b_old)} bytes)',
                  f'  {v_new} {sha(b_new)} {"MATCH" if ok_new else ("MUTATED (negative control)" if mut == owner else "NO MATCH")} ({len(b_new)} bytes)']
        all_ok &= ok_old and ok_new; blocks = []
        for name, _, _ in spec:
            o, n = B_old.get(name), B_new.get(name)
            if o is None and n is not None: st = 'NEW_IN_' + v_new
            elif o is not None and n is None: st = 'ABSENT_IN_' + v_new
            elif o is None and n is None: st = 'ANCHOR_NOT_FOUND'
            else: st = 'IDENTICAL' if o[2] == n[2] else 'CHANGED'
            e = {'section': name, 'status': st, 'old_lines': None if o is None else [o[0], o[1]], 'old_bytes': None if o is None else len(o[2]), 'old_sha256': None if o is None else sha(o[2]),
                 'new_lines': None if n is None else [n[0], n[1]], 'new_bytes': None if n is None else len(n[2]), 'new_sha256': None if n is None else sha(n[2]),
                 'cited_by_rer_rows': CITED.get((owner, name), []), 'preparer_reading': READING.get((pair, name), 'unchanged' if st == 'IDENTICAL' else None)}
            if st == 'CHANGED':
                po = [p for p in o[2].split(b'\n\n') if p.strip()]; pn = n[2]
                kept = [p for p in po if p in pn]; e['paragraph_retention'] = {'old_paragraphs': len(po), 'retained_verbatim_in_new': len(kept), 'dropped_or_edited': [p.decode('utf-8', 'replace')[:120] for p in po if p not in pn]}
                e['unified_diff'] = '\n'.join(difflib.unified_diff(o[2].decode('utf-8', 'replace').split('\n'), n[2].decode('utf-8', 'replace').split('\n'), v_old, v_new, lineterm='', n=1))
            elif st.startswith('NEW_IN_'): e['new_text'] = n[2].decode('utf-8', 'replace')
            blocks.append(e)
            if st == 'CHANGED': lines.append(f"  {name:22s} paragraphs: {e['paragraph_retention']['old_paragraphs']} old, {e['paragraph_retention']['retained_verbatim_in_new']} retained verbatim in {v_new}")
            lines.append(f"  {name:22s} {v_old} lines {('%d-%d' % tuple(e['old_lines'])) if o else '—':12s} {v_new} lines {('%d-%d' % tuple(e['new_lines'])) if n else '—':12s} {st:16s} {(e['new_sha256'] or '')[:16]}")
        # whole-file hunks vs cited blocks
        Lo, Ln = b_old.split(b'\n'), b_new.split(b'\n'); hunks = []
        for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, Lo, Ln, autojunk=False).get_opcodes():
            if tag == 'equal': continue
            hit = [nm for nm, _, _ in spec if B_old.get(nm) and i1 < B_old[nm][1] and max(i2, i1 + 1) > B_old[nm][0] - 1]
            hunks.append({'op': tag, 'old': [i1 + 1, i2], 'new': [j1 + 1, j2], 'inside_blocks': hit})
        lines.append(f'  whole-file change hunks: {len(hunks)}; inside listed blocks: {sum(1 for h in hunks if h["inside_blocks"])}')
        if mut == pair:
            neg_caught[pair] = any(e['status'] == 'CHANGED' and e['section'] == tgt for e in blocks)
            lines.append(f'  negative control ({tgt}): {"mismatch detected (good)" if neg_caught[pair] else "NOT detected (BAD)"}')
        report['pairs'][pair] = {'old': {'file': f_old, 'sha256': sha(b_old), 'expected': h_old, 'version': v_old}, 'new': {'file': f_new, 'sha256': sha(b_new), 'expected': h_new, 'version': v_new},
                                  'legs_note': OLD_LEGS[owner], 'blocks': blocks, 'whole_file_hunks': hunks}
    return report, '\n'.join(lines) + '\n', all_ok, neg_caught
if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == '--negcontrol':
        res = {}
        for pair in PAIRS:
            _, txt, _, nc = compare(mut=pair); print(txt, end=''); res[pair] = nc[pair]
        ok = all(res.values()); print('negative controls:', '4/4 caught' if ok else f'{sum(res.values())}/4 caught (BAD)'); sys.exit(0 if ok else 1)
    rep, txt, ok, _ = compare()
    J = (json.dumps(rep, ensure_ascii=False, indent=1) + '\n').encode('utf-8'); T = txt.encode('utf-8')
    D = ''
    for owner, p in rep['pairs'].items():
        for e in p['blocks']:
            if e['status'] == 'CHANGED': D += f"==== {owner} {e['section']} ({p['old']['version']} -> {p['new']['version']})\n{e['unified_diff']}\n\n"
            elif e['status'].startswith('NEW_IN_'): D += f"==== {owner} {e['section']} ({e['status']})\n{e['new_text']}\n\n"
    D = D.encode('utf-8')
    if a and a[0] == '--check':
        same = (OUT / 'owner_section_check.json').read_bytes() == J and (OUT / 'compare_output.txt').read_bytes() == T and (OUT / 'changed_blocks.diff').read_bytes() == D
        print(txt, end=''); print('stored outputs byte-identical:', same); sys.exit(0 if ok and same else 1)
    OUT.mkdir(exist_ok=True); (OUT / 'owner_section_check.json').write_bytes(J); (OUT / 'compare_output.txt').write_bytes(T); (OUT / 'changed_blocks.diff').write_bytes(D)
    print(txt, end=''); print('RESULT:', 'all six file hashes MATCH' if ok else 'a file hash does NOT match'); sys.exit(0 if ok else 1)
