# Owner section check: Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 — preparer note

**Date:** 21 Oct 2026.
**From:** Claude, RER co-owner (preparer).
**To:** the RER receiving co-owner.
**Status:** NONCANONICAL. This package records file identities, section byte equality, exact differences and the RER rows that cite each section. It proposes **no acceptance, grade, catalog change or repin**; the preparer readings in the JSON are labelled as such. Phase A r18 is unchanged.
**Authorized by:** the r18 receiving review of 21 Oct 2026, §5 (one targeted owner-section review package; catalog revision only after its own receiving review).

## 1. File identities

The three current owner files were read from the project folder in this session and hashed. All three equal the OWNER_REPORTED identities of Phase A r17/r18. The old legs held here are the files already byte-verified in earlier Phase A passes.

| Owner | Old (held; evidence) | New (read from the project here) |
|---|---|---|
| Dyadic | v6.4.18 `f70308f1…458d`, 256,933 bytes (BYTE_VERIFIED, Phase A r14) | v6.4.19 `40c9e63f…6ec9`, 275,935 bytes — **MATCH** |
| RECOG | v0.3.21 `a3459522…0ae3`, 301,292 bytes (BYTE_VERIFIED, Phase A r13) | v0.3.22 `0dcce9e4…bcd9`, 329,148 bytes — **MATCH** |
| RRF | v0.8.3 `b393657e…a187`, 97,717 bytes (held since Phase A r15; receiver-hashed) | v0.8.4 `2fb0a0fe…afce`, 108,615 bytes — **MATCH** |

**Provenance of the new bytes:** project copies (`RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md`, `RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md`, `RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md`) read through the project tool; the RRF text arrived inline and was written back from the session record. Each hash equals the value the owner record states and the value the receiver computed on its side. This is a PREPARER identity check; the receiver's own identity receipt is separate.

**Legs not held:** Dyadic v6.4.13 (DYAD6413 pin), RRF v0.8 (RRF08_ADOPTED pin) and RRF v0.8.2 (RRF082 pin). These stay NOT_REPLAYED / SOURCE_MISSING here. The earlier checked legs are included as pinned inputs: v6.4.17 → v6.4.18 and v0.3.20 → v0.3.21 (both receiver-replayed at the time).

## 2. Results by owner (from `out/compare_output.txt`)

### Dyadic v6.4.18 → v6.4.19

| Block | v6.4.18 | v6.4.19 | Result | Cited by |
|---|---|---|---|---|
| §2 OPEN 19 | 238–244 | 242–248 | IDENTICAL | DYAD6413 |
| §2 OPEN 20 | 248–257 | 252–261 | IDENTICAL | DYAD6413, DYAD6418 |
| §2 OPEN 21 (context) | 260–263 | 264–267 | IDENTICAL | — |
| §6.14 (context) | 733–862 | 738–891 | CHANGED (additive: L-PHASE row A subsection) | — (not cited by RER) |
| §6.15 | 864–903 | 893–932 | IDENTICAL | DYAD6413 |
| §6.16 | 905–952 | 934–981 | IDENTICAL | DYAD6413 |
| §6.17 | 954–981 | 983–1010 | IDENTICAL | DYAD6413, DYAD6418 |

Whole-file hunks: 13; inside the listed blocks: 1 (§6.14). This matches the release record's statement that §2 and §3 are unchanged and the new result sits in §6.14. The DYAD6418 pin (v6.4.18 §2 OPEN 20, §6.17) is byte-identical in v6.4.19. For DYAD6413 the comparison reaches back only to v6.4.17 through the earlier legs; the v6.4.13 → v6.4.16 leg remains receiver-reported.

### RECOG v0.3.21 → v0.3.22

| Block | v0.3.21 | v0.3.22 | Result | Cited by |
|---|---|---|---|---|
| §6.6a CELL-G1 | 521–545 | 526–550 | IDENTICAL | RER-G9/0 (pin v0.3.20) |
| §6.16g CELL-F4 | 1006–1045 | 1071–1110 | IDENTICAL | RER-G9/1 (pin v0.3.20) |

Whole-file hunks: 15; inside the listed blocks: 0. Combined with the pinned v0.3.20 → v0.3.21 leg (both blocks IDENTICAL), the two cited blocks are byte-identical from the frozen v0.3.20 pin through v0.3.22. This is a transitive chain of two separately checked legs, named as such; the RER pins stay on v0.3.20.

### RRF v0.8.3 → v0.8.4

| Block | v0.8.3 | v0.8.4 | Result | Cited by (pin) |
|---|---|---|---|---|
| front matter | 1–17 | 1–17 | CHANGED (metadata) | G10/0 (v0.8, SOURCE_MISSING) |
| §0 lead | 19–51 | 19–53 | CHANGED (additive overlay) | — |
| §0.1 | 53–64 | 55–66 | IDENTICAL | — |
| §0.2 | 66–78 | 68–86 | CHANGED (additive rows + pin convention) | G7/1 (v0.8, SOURCE_MISSING) |
| §0.3 | 80–86 | 88–94 | IDENTICAL | G8/1, ER2B-CARRIER/3 (v0.8, SOURCE_MISSING) |
| §2.3 | 141–157 | 149–165 | IDENTICAL | RRF083 |
| §2.4 | 159–179 | 167–187 | CHANGED (cited statement reworded in the formal-involution row) | — (row cited via §2.4b) |
| §2.4a | 181–195 | 189–203 | IDENTICAL | — |
| §2.4b | 197–213 | 205–223 | CHANGED (OPEN record: B-∞ existence CLOSED; override paragraph appended) | RRF082 (v0.8.2, SOURCE_MISSING), RRF083 |
| §2.4c | 215–223 | 225–233 | CHANGED (closing OPEN 20 sentence reworded) | — |
| §4.2 | 318–336 | 328–346 | IDENTICAL | RRF082 (v0.8.2, SOURCE_MISSING) |
| §4.2a | 338–346 | 348–358 | CHANGED (additive current-pin paragraph) | G9/2 (v0.8, SOURCE_MISSING) |
| §4.3 | 348–361 | 360–373 | IDENTICAL | — |
| §6.2 | 391–410 | 403–424 | CHANGED (notice prepended; one sentence replaced) | CND01/2, G7/0, G8/2 (v0.8, SOURCE_MISSING) |
| §6.2a | — | 426–440 | NEW | — |
| §6.3 | 412–426 | 442–458 | CHANGED (W3 row reworded; new [OPEN] extension paragraph) | G9/3 (v0.8, SOURCE_MISSING) |
| §6.4 | 428–430 | 460–462 | IDENTICAL | G10/1 (v0.8, SOURCE_MISSING) |
| §8 | 442–457 | 474–489 | CHANGED (item 12 reworded) | — |
| §8.1 | 459–467 | 491–499 | IDENTICAL | G10/2 (v0.8, SOURCE_MISSING) |
| §9 | 469–496 | 501–530 | CHANGED (change-log entry) | — |
| §10.1 | 520–542 | 554–576 | IDENTICAL | G10/3 (v0.8, SOURCE_MISSING) |
| §10.4 | — | 599–604 | NEW | — |

Whole-file hunks: 19; inside the listed blocks: 15. The exact diffs of every CHANGED block and the full text of the two NEW blocks are in `out/changed_blocks.diff`.

**Facts the receiver asked to have located (quotations, not findings):**
- **§6.3 W3.** The W3 row no longer reads "comparison/transport between pre- and post-birth cohomology spaces before forming Δ[a]". It now reads "event-indexed cochains $a^-$, $a^+$ in the **same** cohomology space, so that $\Delta[a]=[a^+]-[a^-]$ is defined" with an import pin to RECOG v0.3.21 §6.16g. This string occurs once each in RECOG v0.3.21, RECOG v0.3.22, RRF v0.8.4 and RER r4.13 (the r4.11 W3 quotation), and not in RRF v0.8.3. A new `[OPEN]` paragraph states the different-space transport as an RRF extension with no registered map and says "RER G9/1 should cite owner W3 separately from this extension".
- **§2.4, §2.4b, §2.4c, §6.2, §8 item 12.** The changes all concern the same owner update: B-∞ C∞ existence CLOSED by DYAD v6.4.18 E1–E4 while B-an/B-6 stay OPEN. In §2.4 and §2.4c a cited statement is reworded rather than only overlaid.
- **§2.3 and §4.2** (RRF083 §2.3; RRF082 §4.2) are byte-identical. **§2.4b** (both RRF082 and RRF083) is changed.
- **v0.8 pins.** The RRF08_ADOPTED rows cite v0.8 line ranges; v0.8 bytes are not held, so nothing here verifies those pins or the v0.8 → v0.8.3 leg. Where the v0.8.3 → v0.8.4 block is IDENTICAL (§0.3, §6.4, §8.1, §10.1) only that leg is established.

## 3. The 18 affected matrix rows

| Rows | Pin | What this check establishes for them | What it does not |
|---|---|---|---|
| DYAD6413 (1 row) | v6.4.13 | v6.4.17 → v6.4.18 → v6.4.19: the cited §2 OPEN 19, §6.15, §6.16 identical throughout; §2 OPEN 20 and §6.17 identical from v6.4.18 on | the v6.4.13 → v6.4.16 leg (receiver-reported only) |
| DYAD6418 (1 row) | v6.4.18 | both cited blocks byte-identical in v6.4.19 | — |
| RECOG (2 rows) | v0.3.20 | both cited blocks byte-identical through v0.3.21 and v0.3.22 (two checked legs) | — |
| RRF083 (1 row) | v0.8.3 | §2.3 identical; §2.4b changed, diff given | the fidelity reading of the §2.4b change |
| RRF082 (1 row) | v0.8.2 | §4.2 identical and §2.4b changed, v0.8.3 → v0.8.4 only | the v0.8.2 → v0.8.3 leg (SOURCE_MISSING here) |
| RRF08_ADOPTED (12 rows) | v0.8 | the v0.8.3 → v0.8.4 status of each cited section | the v0.8 → v0.8.3 leg and the v0.8 line pins (SOURCE_MISSING) |

## 4. Package, gates and controls

`owner_section_check.py` cuts blocks by literal anchor lines (no parser), hashes them, lists whole-file hunks and marks which fall inside the listed blocks. Outputs: `out/owner_section_check.json` (`a82ff204755bcc1d8975fccd222bde0e310af58b606f2c3a22539a835d9d186a`, authoritative; includes the labelled preparer readings), `out/compare_output.txt` (`29ae48339029741ac34d3510df742b8a5bfb0c1d9d119580fe60d1d8b47ed67a`), `out/changed_blocks.diff` (`6c15c588bc3a809b526c7dc039346eeadfe41b3957748b1d9f9456ba995d353d`).

- **Pass condition:** all six file hashes match (the script exits 0 only then; block results are reported, not judged).
- **Negative controls (`--negcontrol`):** one byte is flipped inside an honestly IDENTICAL block of each new file (Dyadic §2 OPEN 19, RECOG §6.6a, RRF §0.1); each is reported DIFFERENT — 3/3 caught (`out/negcontrol_output.txt`). A false equality is therefore rejected.
- **Replay:** `python -I -B owner_section_check.py --check` reproduces the three outputs byte for byte. The manifest lists no bytecode cache.

## 5. What a later catalog revision could carry (for the receiver to decide; not done here)

- Dyadic: current evidence BYTE_VERIFIED for v6.4.19 with this section check; DYAD6418 currency back to a verified label if the receiver accepts the identical blocks.
- RECOG: current evidence BYTE_VERIFIED for v0.3.22; the two rows back to a verified label on the two-leg chain.
- RRF: current evidence BYTE_VERIFIED for v0.8.4; RRF083 §2.3 identical, §2.4b changed — the row's currency depends on the receiver's reading of the §2.4b change; RRF082 and the v0.8 rows stay RECHECK_IN_PHASE_B unless the old bytes are supplied.

Nothing above changes r18; a catalog revision would be a separate, visible delta after the receiving review of this package.
