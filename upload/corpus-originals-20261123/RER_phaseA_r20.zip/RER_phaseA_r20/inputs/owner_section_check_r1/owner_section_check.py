"""Owner section check for the three owner updates listed in Phase A r17/r18 as OWNER_REPORTED (receiver authorization of 21 Oct 2026, r18 review §5):
  Dyadic v6.4.18 -> v6.4.19 : §2 OPEN 19, §2 OPEN 20, §6.15, §6.16, §6.17 (cited by DYAD6413 and DYAD6418 rows); §6.14 and OPEN 21 as context
  RECOG  v0.3.21 -> v0.3.22 : §6.6a CELL-G1, §6.16g CELL-F4 (cited by the two RECOG rows, pin v0.3.20)
  RRF    v0.8.3  -> v0.8.4  : front matter, §0 lead, §0.1, §0.2, §0.3, §2.3, §2.4, §2.4a, §2.4b, §2.4c, §4.2, §4.2a, §4.3, §6.2, §6.2a (new),
                              §6.3, §6.4, §8, §8.1, §9, §10.1, §10.4 (new) — the cited current-use locations of the 14 RRF rows plus the notices
Axes kept separate (receiver instruction): file identity; section byte equality; what changed (exact diff); the RER rows that cite the section;
a PREPARER_READING of each change (unchanged / changed — additive overlay / changed — cited statement reworded / new section); old legs without
bytes (v6.4.13, v0.8, v0.8.2) stay SOURCE_MISSING / NOT_REPLAYED. No acceptance, grade or catalog change is proposed by this script.
Usage: python -I -B owner_section_check.py            -> compare all three pairs, write out/*; exit 0 iff all six file hashes match
       python -I -B owner_section_check.py --check    -> compare and verify out/* byte-identical (no write)
       python -I -B owner_section_check.py --negcontrol -> flip one byte inside one block of each new file in memory; each must be reported
                                                          DIFFERENT where the honest run says IDENTICAL (exit 0 iff all three are caught)"""
import sys, hashlib, difflib, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; SRC = HERE / 'sources'; OUT = HERE / 'out'
sha = lambda b: hashlib.sha256(b).hexdigest()
PAIRS = {
 'Dyadic': ('RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md', 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d', 'v6.4.18',
            'RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md', '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9', 'v6.4.19',
            [('§2 OPEN 19', '**OPEN 19 —', '---'), ('§2 OPEN 20', '**OPEN 20 —', '---'), ('§2 OPEN 21 (context)', '**OPEN 21 —', '---'),
             ('§6.14 (context)', '### §6.14', '### §6.15'), ('§6.15', '### §6.15', '### §6.16'), ('§6.16', '### §6.16', '### §6.17'), ('§6.17', '### §6.17', '## §7.')]),
 'RECOG': ('RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md', 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3', 'v0.3.21',
           'RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md', '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9', 'v0.3.22',
           [('§6.6a', '### §6.6a', '### §6.7'), ('§6.16g', '#### §6.16g', '## §7.')]),
 'RRF': ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md', 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187', 'v0.8.3',
         'RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md', '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce', 'v0.8.4',
         [('front matter', '---', '# 0. '), ('§0 lead', '# 0. ', '### 0.1'), ('§0.1', '### 0.1', '### 0.2'), ('§0.2', '### 0.2', '### 0.3'), ('§0.3', '### 0.3', '# 1. '),
          ('§2.3', '## 2.3 ', '## 2.4 '), ('§2.4', '## 2.4 ', '## 2.4a'), ('§2.4a', '## 2.4a', '### 2.4b'), ('§2.4b', '### 2.4b', '### 2.4c'), ('§2.4c', '### 2.4c', '## 2.5 '),
          ('§4.2', '## 4.2 ', '### 4.2a'), ('§4.2a', '### 4.2a', '## 4.3 '), ('§4.3', '## 4.3 ', '# 5. '),
          ('§6.2', '### 6.2 ', ('### 6.2a', '### 6.3 ')), ('§6.2a (new)', '### 6.2a', '### 6.3 '), ('§6.3', '### 6.3 ', '### 6.4 '), ('§6.4', '### 6.4 ', '# 7. '),
          ('§8', '# 8. ', '### 8.1'), ('§8.1', '### 8.1', '# 9. '), ('§9', '# 9. ', '# 10. '), ('§10.1', '### 10.1', '### 10.2'), ('§10.4 (new)', '### 10.4', None)]),
}
# RER rows (Phase A r18 matrix) citing each section; old-edition legs
CITED = {
 ('Dyadic', '§2 OPEN 19'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413 (pin v6.4.13)'], ('Dyadic', '§2 OPEN 20'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413 (pin v6.4.13)', 'RER-DYAD-FORMAL-INVOLUTION/3 DYAD6418 (pin v6.4.18)'],
 ('Dyadic', '§6.15'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413'], ('Dyadic', '§6.16'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413'], ('Dyadic', '§6.17'): ['RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413', 'RER-DYAD-FORMAL-INVOLUTION/3 DYAD6418'],
 ('RECOG', '§6.6a'): ['RER-G9/0 RECOG (pin v0.3.20 lines 517–542)'], ('RECOG', '§6.16g'): ['RER-G9/1 RECOG (pin v0.3.20 lines 1002–1042)'],
 ('RRF', 'front matter'): ['RER-G10/0 RRF08_ADOPTED (pin v0.8 lines 1–16)'], ('RRF', '§0.2'): ['RER-G7/1 RRF08_ADOPTED (pin v0.8 lines 59–70)'], ('RRF', '§0.3'): ['RER-G8/1, RER-ER2B-CARRIER/3 RRF08_ADOPTED (pin v0.8 lines 71–78)'],
 ('RRF', '§2.3'): ['RER-DYAD-FORMAL-INVOLUTION/2 RRF083 (pin v0.8.3)'], ('RRF', '§2.4b'): ['RER-DYAD-FORMAL-INVOLUTION/1 RRF082 (pin v0.8.2)', 'RER-DYAD-FORMAL-INVOLUTION/2 RRF083 (pin v0.8.3)'],
 ('RRF', '§4.2'): ['RER-DYAD-FORMAL-INVOLUTION/1 RRF082 (pin v0.8.2)'], ('RRF', '§4.2a'): ['RER-G9/2 RRF08_ADOPTED (pin v0.8 lines 280–289)'],
 ('RRF', '§6.2'): ['RER-RRF-CND01/2, RER-G7/0, RER-G8/2 RRF08_ADOPTED (pin v0.8 lines 333–349)'], ('RRF', '§6.3'): ['RER-G9/3 RRF08_ADOPTED (pin v0.8 lines 350–365)'],
 ('RRF', '§6.4'): ['RER-G10/1 RRF08_ADOPTED (pin v0.8 lines 366–390)'], ('RRF', '§8.1'): ['RER-G10/2 RRF08_ADOPTED (pin v0.8 lines 418–426)'], ('RRF', '§10.1'): ['RER-G10/3 RRF08_ADOPTED (pin v0.8 lines 472–490)'],
}
OLD_LEGS = {'Dyadic': 'v6.4.13 (5958f7fe…8542, receiver-reported identity): bytes not held — the v6.4.13 -> v6.4.18 leg is NOT_REPLAYED here; v6.4.16 -> v6.4.17 (5/5 IDENTICAL) and v6.4.17 -> v6.4.18 (OPEN 19, §6.15, §6.16 IDENTICAL; OPEN 20, §6.17 CHANGED) are the earlier checked legs (sources/dyad_v6_4_17_v6_4_18_compare_output.txt)',
            'RECOG': 'v0.3.20 (fdb8c9a7…b8df, RER pin): v0.3.20 -> v0.3.21 checked earlier, both cited blocks IDENTICAL (sources/recog_v0_3_20_v0_3_21_compare_output.txt, receiver-replayed); a transitive v0.3.20 -> v0.3.22 statement would combine that leg with this one',
            'RRF': 'v0.8 (c4ec1f10…b44a) and v0.8.2 (f09dbb12…5461): bytes not held — the v0.8 -> v0.8.3 and v0.8.2 -> v0.8.3 legs are SOURCE_MISSING here (the receiver reported v0.8.2 bytes recovered on its side in Phase A review, 19 Oct; §6.2 v0.8 -> v0.8.3 was called CHANGED-SCOPE by the RRF editor, Q6); the pins of the RRF08_ADOPTED and RRF082 rows are not verified by this check'}
# preparer reading of each changed block (not a receiver finding)
READING = {
 ('Dyadic', '§6.14 (context)'): 'changed — additive: new L-PHASE row A subsection (DYAD-THM-LPHASE-ROWA-REMAINDER and its artifacts) inserted inside §6.14; §6.14 is not cited by RER',
 ('RRF', 'front matter'): 'changed — version/date/status/supersedes/review-scope metadata; the cited v0.8 header text is a different edition (SOURCE_MISSING leg)',
 ('RRF', '§0 lead'): 'changed — additive: a v0.8.4 review-stage overlay paragraph prepended; earlier boundaries kept',
 ('RRF', '§0.2'): 'changed — additive: new current-source rows (DYAD v6.4.18 N14, RECOG v0.3.21 G3/RF-1, OFN v0.10, Genesis v2.8.9) and a RECOG owner-pin convention paragraph; earlier rows kept',
 ('RRF', '§2.4'): 'changed — cited statement reworded inside the formal-involution row: "Existence of the formal involution remains OPEN 20 … the new v6.4.13 results classify C∞ involutions and roots (§2.4c), not their existence" becomes "Analytic existence/convergence remains OPEN 20 (B-an/B-6). C∞ existence CLOSED by DYAD v6.4.18 E1–E4 (see current-state §2.4b override); adopted v6.4.13 F1–F3 classify existing smooth germs and roots, while v6.4.18 additionally supplies their local existence. Physical G2 and OPEN-A remain OPEN"; the formal-uniqueness statement and the S_h/R_0 jet-six limit are unchanged',
 ('RRF', '§2.4b'): 'changed — additive: a v0.8.4 current-state override paragraph (DYAD N14) appended; the §2.4b receipt text and the OPEN record are kept, B-∞ existence now CLOSED in the OPEN record',
 ('RRF', '§2.4c'): 'changed — cited statement reworded: the closing OPEN 20 sentence of the F1–F3 paragraph now reads "At the date of this v0.8.3 receipt, B-an, B-6 and B-∞ existence were open; current status supersedes this historical receipt: B-∞ existence CLOSED by DYAD v6.4.18 E1–E4, B-an/B-6 OPEN" (was: "OPEN 20 remains B-an, B-6 and B-∞ existence")',
 ('RRF', '§4.2a'): 'changed — additive: a current owner-source pin paragraph (RECOG v0.3.21 primary, OFN v0.10 consumer); the v0.8.1 text is kept as dated',
 ('RRF', '§6.2'): 'changed — two edits: (a) a v0.8.4 regularity/clock notice paragraph prepended, marking the archived v0.8.3 statement as not current status; (b) in the regularity/clock decision paragraph the sentence "This does not supply such an involution/root." is replaced by "DYAD v6.4.18 E1–E4 now separately supplies such smooth roots/involution on its local domain; this is not physical network realization" with an import pin; the four-notion guard and the contract table are unchanged. The cited v0.8 lines 333–349 are an earlier edition (SOURCE_MISSING leg)',
 ('RRF', '§6.2a (new)'): 'new section — OFN class-C model contract (reference-only); not cited by RER',
 ('RRF', '§6.3'): 'changed — W3 row now quotes the same-cohomology-space wording with an import pin to RECOG v0.3.21 §6.16g; a new [OPEN] paragraph states the different-space transport as an RRF extension with no registered map and asks RER G9/1 to cite owner W3 separately from the extension',
 ('RRF', '§8'): 'changed — item 12 now states C∞ existence CLOSED by DYAD v6.4.18 while B-an/B-6 stay OPEN',
 ('RRF', '§9'): 'changed — additive: the v0.8.4 change-log entry prepended',
 ('RRF', '§10.4 (new)'): 'new section — v0.8.4 candidate receipt and adoption boundary',
}
def cut_blocks(b, spec):
    L = b.split(b'\n'); out = {}
    for name, start, end in spec:
        s = start.encode(); idx = [n for n, l in enumerate(L) if l.startswith(s)]
        if name == 'front matter': i = 0
        else:
            if len(idx) == 0: out[name] = None; continue
            i = idx[0] if len(idx) == 1 or name.startswith('§2 OPEN') or name.startswith('§6.1') else idx[0]
        if end is None: j = len(L)
        else:
            ends = (end,) if isinstance(end, str) else end
            j = next((n for n in range(i + 1, len(L)) if any(L[n].startswith(e.encode()) for e in ends)), len(L))
        while j > i + 1 and not L[j - 1].strip(): j -= 1
        out[name] = (i + 1, j, b'\n'.join(L[i:j]))
    return out
def compare(mut=None):
    report = {'_about': 'Owner section check (preparer: Claude, RER co-owner; NONCANONICAL). Identity, section equality, exact differences, citing RER rows and a labelled preparer reading are separate axes; no acceptance, grade or catalog change is proposed.', 'pairs': {}}
    lines = []; all_ok = True; neg_caught = {}
    for owner, (f_old, h_old, v_old, f_new, h_new, v_new, spec) in PAIRS.items():
        b_old = (SRC / f_old).read_bytes(); b_new = (SRC / f_new).read_bytes()
        ok_old, ok_new = sha(b_old) == h_old, sha(b_new) == h_new
        B_old, B_new = cut_blocks(b_old, spec), cut_blocks(b_new, spec)
        if mut == owner:  # negative control: flip one byte in the middle of the first block that is honestly IDENTICAL
            tgt = next(n for n, _, _ in spec if B_old.get(n) and B_new.get(n) and B_old[n][2] == B_new[n][2])
            T = B_new[tgt][2]; p = b_new.index(T) + len(T) // 2; b_new = b_new[:p] + bytes([b_new[p] ^ 1]) + b_new[p + 1:]; B_new = cut_blocks(b_new, spec)
        lines += [f'== {owner}: {v_old} -> {v_new}', f'  {v_old} {sha(b_old)} {"MATCH" if ok_old else "NO MATCH"} ({len(b_old)} bytes)',
                  f'  {v_new} {sha(b_new)} {"MATCH" if ok_new else ("MUTATED (negative control)" if mut == owner else "NO MATCH")} ({len(b_new)} bytes)']
        all_ok &= ok_old and ok_new; blocks = []
        for name, _, _ in spec:
            o, n = B_old.get(name), B_new.get(name)
            if o is None and n is not None: st = 'NEW_IN_' + v_new
            elif o is not None and n is None: st = 'ABSENT_IN_' + v_new
            elif o is None and n is None: st = 'ANCHOR_NOT_FOUND'
            else: st = 'IDENTICAL' if o[2] == n[2] else 'CHANGED'
            e = {'section': name, 'status': st, 'old_lines': None if o is None else [o[0], o[1]], 'old_bytes': None if o is None else len(o[2]), 'old_sha256': None if o is None else sha(o[2]),
                 'new_lines': None if n is None else [n[0], n[1]], 'new_bytes': None if n is None else len(n[2]), 'new_sha256': None if n is None else sha(n[2]),
                 'cited_by_rer_rows': CITED.get((owner, name), []), 'preparer_reading': READING.get((owner, name), 'unchanged' if st == 'IDENTICAL' else None)}
            if st == 'CHANGED':
                e['unified_diff'] = '\n'.join(difflib.unified_diff(o[2].decode('utf-8', 'replace').split('\n'), n[2].decode('utf-8', 'replace').split('\n'), v_old, v_new, lineterm='', n=1))
            elif st.startswith('NEW_IN_'): e['new_text'] = n[2].decode('utf-8', 'replace')
            blocks.append(e)
            lines.append(f"  {name:22s} {v_old} lines {('%d-%d' % tuple(e['old_lines'])) if o else '—':12s} {v_new} lines {('%d-%d' % tuple(e['new_lines'])) if n else '—':12s} {st:16s} {(e['new_sha256'] or '')[:16]}")
        # whole-file hunks vs cited blocks
        Lo, Ln = b_old.split(b'\n'), b_new.split(b'\n'); hunks = []
        for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, Lo, Ln, autojunk=False).get_opcodes():
            if tag == 'equal': continue
            hit = [nm for nm, _, _ in spec if B_old.get(nm) and i1 < B_old[nm][1] and max(i2, i1 + 1) > B_old[nm][0] - 1]
            hunks.append({'op': tag, 'old': [i1 + 1, i2], 'new': [j1 + 1, j2], 'inside_blocks': hit})
        lines.append(f'  whole-file change hunks: {len(hunks)}; inside listed blocks: {sum(1 for h in hunks if h["inside_blocks"])}')
        if mut == owner:
            neg_caught[owner] = any(e['status'] == 'CHANGED' and e['section'] == tgt for e in blocks)
            lines.append(f'  negative control ({tgt}): {"mismatch detected (good)" if neg_caught[owner] else "NOT detected (BAD)"}')
        report['pairs'][owner] = {'old': {'file': f_old, 'sha256': sha(b_old), 'expected': h_old, 'version': v_old}, 'new': {'file': f_new, 'sha256': sha(b_new), 'expected': h_new, 'version': v_new},
                                  'old_legs_not_held': OLD_LEGS[owner], 'blocks': blocks, 'whole_file_hunks': hunks}
    return report, '\n'.join(lines) + '\n', all_ok, neg_caught
if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == '--negcontrol':
        res = {}
        for owner in PAIRS:
            _, txt, _, nc = compare(mut=owner); print(txt, end=''); res[owner] = nc[owner]
        ok = all(res.values()); print('negative controls:', '3/3 caught' if ok else f'{sum(res.values())}/3 caught (BAD)'); sys.exit(0 if ok else 1)
    rep, txt, ok, _ = compare()
    J = (json.dumps(rep, ensure_ascii=False, indent=1) + '\n').encode('utf-8'); T = txt.encode('utf-8')
    D = ''
    for owner, p in rep['pairs'].items():
        for e in p['blocks']:
            if e['status'] == 'CHANGED': D += f"==== {owner} {e['section']} ({p['old']['version']} -> {p['new']['version']})\n{e['unified_diff']}\n\n"
            elif e['status'].startswith('NEW_IN_'): D += f"==== {owner} {e['section']} ({e['status']})\n{e['new_text']}\n\n"
    D = D.encode('utf-8')
    if a and a[0] == '--check':
        same = (OUT / 'owner_section_check.json').read_bytes() == J and (OUT / 'compare_output.txt').read_bytes() == T and (OUT / 'changed_blocks.diff').read_bytes() == D
        print(txt, end=''); print('stored outputs byte-identical:', same); sys.exit(0 if ok and same else 1)
    OUT.mkdir(exist_ok=True); (OUT / 'owner_section_check.json').write_bytes(J); (OUT / 'compare_output.txt').write_bytes(T); (OUT / 'changed_blocks.diff').write_bytes(D)
    print(txt, end=''); print('RESULT:', 'all six file hashes MATCH' if ok else 'a file hash does NOT match'); sys.exit(0 if ok else 1)
