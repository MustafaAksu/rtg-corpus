# RER Phase A r19 — independent receiving review

**Date:** 21 October 2026.  
**Status:** NONCANONICAL receiver evidence; no owner/registry adoption, freeze or publication.  
**Decision:** **ACCEPT SCOPED — authorized source-currency and metadata delta.**  
**Object:** `RER_phaseA_r19.zip`, SHA-256 `683046e70c1d4644e33ae40a3cde85666f6346ecb979874ea9b66430443efe06`.

## 1. Basis, reading and scope

[SESSION: inspected here] The preparer's r19 change record and the prior owner-section receiving review were read in full. The operative authorization is the latter review, SHA-256 `e279fd3c3cc47b0cbe02b85f50c21fc97f45d2e808f5e953b118ad63ff2cd323`, especially §6 and its 18-row disposition table. The change record calls this §5; §5 contains the scientific consumer review and §6 the authorization. The file identity and intended scope are unambiguous; this numbering discrepancy is nonblocking.

[SESSION: inspection boundary] The supplied builder, parser and checker were inspected at the relevant construction/control sections and executed as specified below. This is not formal verification of every code path. Entire current owner files were hashed; thirteen raw section comparisons were independently repeated to test the identity premises of the catalog. No new owner theorem or proof package was independently certified in this turn. `results/source_manifest.json` gives exact input identities and actual inspection scopes.

Consumer source: **RER v0.2 DRAFT r4.13**, SHA-256 `e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c`. Baseline: **Phase A r18**, ZIP SHA-256 `1dafb50fbd1e37a98b6804c84a2285d709d9810384a0a0fa5ce5820fbb4ca249`. Current owner identities in this frozen catalog: Dyadic **6.4.19**, RECOG **0.3.22**, RRF **0.8.4**. This is not global live-release discovery.

## 2. Package and supplied-code replay

[SESSION: executed here] The ZIP was extracted to two distinct clean directories after member/path checks. In each directory:

```sh
python -I -B build_phaseA.py
python -I -B check_phaseA.py --tamper
```

| Check | Result |
|---|---|
| r19 ZIP identity | MATCH |
| Complete non-self-listing manifest | **159/159 PASS**, before and after each replay |
| Positive gates | **34/34 PASS**, each replay |
| Negative controls | **140/140 expected named-gate failures**, each replay |
| Negative breakdown | **113 output tampers + 27 file/input controls** |
| Five regenerated outputs | Byte-identical to packaged outputs and between runs |
| Full checker stdout | Byte-identical to the packaged log in both runs |
| Child process exit status / stderr | 0 / empty for all four commands |
| Bytecode/cache files | None in the archive or either replay directory |

The supplied negative controls are tests of the supplied validation predicates; their success is not an independent mathematical proof or an exhaustive robustness guarantee.

## 3. Separate independent audit

[SESSION: independently computed here] `code/independent_r19_audit.py` uses only the Python standard library and imports neither the preparer's builder nor parser/checker. It performs **68/68 successful identity and delta checks**. This number counts bounded audit assertions, not scientific theorems or independent proof certificates.

Important cross-checks:

- The source Markdown equals both the original **r4.13 ZIP** member and the r18 source, byte-for-byte.
- The five historical r18 outputs and r18 checker log equal the corresponding files in the **original mounted r18 ZIP**, not merely another copy within r19.
- The pinned authorization receipt and six owner-section comparison artefacts equal their previously accepted original packages.
- Registry and blocked-register JSONs differ from r18 **only in schema**. The 20 records, four gap entries, all grades, receipts, OPEN items and source table are unchanged. Adoption remains PENDING for all 20 records.
- The 91 ordered row identities are unchanged. Exactly **18 rows** differ, precisely the set in the receiver's 18-row authorization table.
- Only `currency`, `currency_reason`, `current_owner_evidence`, `verified_current_hash`, `status` and `receiver_section_check` change. No cited version/hash, byte-status, authentication, line range, path or package-presence flag changes.
- Exactly **three overall row statuses** change: DYAD6418 and the two RECOG rows, OWNER_REPORTED → VERIFIED. The other 15 changed rows retain their prior overall status.
- All **13 gap-reference audits** remain PENDING_PER_REFERENCE_AUDIT. The synchronization warning, its machine CHECK state and separate receiving CLOSED — SOURCE_SYNCHRONIZED disposition are unchanged. The two ER-2B records remain blocked.
- Only three current-owner entries change; their version/hash identities are unchanged, their evidence becomes BYTE_VERIFIED, and their former evidence/note state is preserved under `history.phaseA_r17_r18`. Earlier history is retained.

Verified counts:

| Axis | Result |
|---|---|
| VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED | **31 / 2 / 52 / 6** |
| BYTE_VERIFIED_HERE / RECEIVER_BYTE_VERIFIED / HASH_PRINTED_UNVERIFIED / UNAUTHENTICATED_NO_HASH | **60 / 6 / 24 / 1** |

The authentication distribution correctly remains unchanged: current-owner authentication and authentication of a historical cited pin are different fields.

## 4. Owner evidence and section scope

[SESSION: computed here] The three current files inside r19 match both the catalog identities and the accepted owner-section package:

| Owner | Bytes | SHA-256 |
|---|---:|---|
| Dyadic 6.4.19 | 275935 | `40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9` |
| RECOG 0.3.22 | 329148 | `0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9` |
| RRF 0.8.4 | 108615 | `2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce` |

The custody entries match their filenames, sizes and content hashes. The preparer's project-tool/session reconstruction chain remains **PREPARER_DECLARED**; matching file identity does not independently authenticate that upstream chain.

[SESSION: independent raw-byte comparisons] Five cited Dyadic blocks, OPEN19/20 and §§6.15–6.17, were re-compared from 6.4.18 to 6.4.19 and are identical. The two cited RECOG blocks were compared directly from both 0.3.20 and 0.3.21 to 0.3.22 and are identical. For RRF 0.8.3→0.8.4, §2.3 and §4.2 are identical, whereas §2.4b and §6.3 are changed. These thirteen comparisons preserve original separator bytes; hashes and line spans are in the independent audit JSON.

[SESSION: receipt comparison] The accepted owner-section receipt records the complete RRF block census **9 IDENTICAL / 11 CHANGED / 2 NEW**. r19 carries that census correctly. OSC-N2 is also implemented: the old RRF082 reason is explicitly historical, and the correction records that **both §2.4b and §4.2 changed from 0.8.2 to 0.8.3**; §4.2 equality applies only to 0.8.3→0.8.4. Neither RRF082 nor RRF083 has been promoted to whole-row identity. No new semantic or theorem acceptance is implied by the r19 catalog.

## 5. Historical originals not packaged in r19

[SESSION: receiving decision] Leaving DYAD6413 and RRF082 at RECEIVER_BYTE_VERIFIED is correct for the submitted package. The earlier permission to raise them to BYTE_VERIFIED_HERE was conditional on including and locally hashing their real files; r19 explicitly does not exercise it. This is **not an acceptance defect**.

[SESSION: extracted and verified here] To resolve the delivery dependency, the two exact originals were extracted anew from `TRIAD_RER_RECEIVING_REVIEW_20261019.zip` and compared with the previous `OWNER_SECTION_RECEIVER_HANDOFF_20261021.zip` copies:

- Dyadic 6.4.13: `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542`.
- RRF 0.8.2: `f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461`.

They are delivered separately in `RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip` (4/4 payload manifest verified). Archive identity/member paths and the comparison are recorded there. External custody before the source archive is not reauthenticated. This delivery does **not** modify r19 or grant whole-section equality; no Phase A r20 was created.

## 6. Decision and residual work

[SESSION: receiving decision] **Phase A r19: ACCEPT SCOPED. No substantive correction requested.** The source-currency promotions, 18-row scope, preserved old pins and correction of OSC-N1/OSC-N2 conform to the authorization. The change record's §5 authorization locator should read §6 in any later documentation update; the accepted r19 bytes must not be silently rewritten for that minor reference note.

RER remains **r4.13 DRAFT**. Phase A r19 is the accepted machine/source-currency scan. RRF v0.8 original-pin authentication, G9/1–G9/3 per-reference dispositions, G2 §5b identification, two ER-2B source blocks and Stage-2 regional/global certification remain open. The dated G10 working-standard wording remains only a watch item; this review does not authorize or apply consumer text maintenance.

No owner proof, kernel, age-geometry or Stage-2 scientific calculation was executed in this turn. No owner adoption, freeze, publication, source repin or physical transfer is authorized. The prior owner-section semantic findings are carried as scoped receipts, not rebranded as new proofs.
