# RER r4.11 — blocked-source register (Phase A r17, noncanonical)

| Source | Kind | Cited by | Blocks acceptance of | Note |
|---|---|---|---|---|
| `ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip` | MISSING_PRIMARY_INPUT (COINC_CERT) | RER-RRF-CND01 | — | For RER-RRF-CND01 this blocks only the secondary-report coincidence item (not imported as a theorem); the record's [THM] is the RER-native fixed-set implication. |
| `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md` | MISSING_PRIMARY_INPUT (ER02) | RER-ER2B-CARRIER, RER-ER2B-T6D, RER-RRF-CND01 | RER-ER2B-CARRIER, RER-ER2B-T6D | Primary v0.2 package not available to preparer or receiver. ER-2B consolidated v0.3 (80669c69…, NONCANONICAL) reports the package identity RTG_ER2B_CONSOLIDATED_v0_2.zip 8c635290…48ee and v0.2 study ea26d3d1…5e (source-reported, not verified here); v0.3 is background only and does not unblock (receiver D-2). Unblocking needs the package bytes and, if required, an ER-2B custodian decision. |
| `RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md` | MISSING_PRIMARY_INPUT (COINC_RESPONSE) | RER-RRF-CND01 | — | For RER-RRF-CND01 this blocks only the secondary-report coincidence item (not imported as a theorem); the record's [THM] is the RER-native fixed-set implication. |

## Packaging finding

Cited evidence files present in the r4 package but not carried into the r4.1–r4.4 packages: TRIAD_BGJ, TRIAD_BGJ_PY, TRIAD_CK_PY, TRIAD_EC_PY, TRIAD_GC_PY, TRIAD_KR_PY, TRIAD_SB_PY. Repaired in the r4.5 package, which carries them at their cited paths with their cited hashes: TRIAD_BGJ, TRIAD_BGJ_PY, TRIAD_CK_PY, TRIAD_EC_PY, TRIAD_GC_PY, TRIAD_KR_PY, TRIAD_SB_PY.

## Byte-availability gap (not blocking)

Phase A r6 correction: the r1–r5 note said these bytes were not in the preparer workspace. That was incomplete: 14 cited files were present in PI-supplied session uploads and are now byte-verified (inputs/source_custody_r6.json). The keys listed here are the ones still without bytes. Not blocking by itself; the receiving side holding the r3.1 package can byte-verify.

`ANGLE_DATA`, `DYAD6413`, `ERADD`, `ERREPLY`, `G2NOTE04`, `GEN287`, `HARM`, `K36S`, `K3REC`, `OFN9`, `R3_REQUEST`, `RANKDATA`, `RRF082`, `RRF08_ADOPTED`
