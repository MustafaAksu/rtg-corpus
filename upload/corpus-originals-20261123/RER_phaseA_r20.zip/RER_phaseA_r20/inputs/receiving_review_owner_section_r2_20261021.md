# OWNER_SECTION_CHECK r2 — independent receiving review and r20 authorization

**Date:** 21 October 2026.  
**Status:** NONCANONICAL receiving record. No owner/registry adoption, freeze or publication.  
**Decision:** **ACCEPT SCOPED — file identity, old-edition section comparisons and source custody within the inspected archives. Phase A r20 preparation is authorized at the narrow scope in §6.**

## 1. Sources and inspection extent

[SESSION: inspected here] The preparer's `OWNER_SECTION_CHECK_r2_NOTE_20261021.md` and comparison script were read in full. The original r19 receiver record and the transfer README/custody were inspected directly. The operative governance sources found locally are adopted Methodology **v1.3** (status, §0.6, §§12.1–12.4), Programme **v1.2** (status and SG-PROG-1–4) and OFN **v0.10** (status/scope). These were read by section, not in full. Their identities are in `SOURCE_MANIFEST.json`; this is not a global release-currency audit.

[SESSION: inspected/computed here] Scientific source editions actually compared: Dyadic **v6.4.13, v6.4.18 and v6.4.19**; RRF **v0.8.2, v0.8.3 and v0.8.4**. Thirty specified section pairs were compared completely as byte objects. Text inspection was targeted to the changed status/import passages, including Dyadic OPEN 20 and §6.17 and the RRF §2.4b/§4.2/§6.2/§6.3 changes. This review does not read or replay the external mathematical proof/certificate bundles and does not independently re-prove any owner theorem.

[SESSION: computed here] Input ZIP:

```text
OWNER_SECTION_CHECK_r2.zip
e149b349d4420fb3db58e9c357f9c7822fa3074be0fecf1e149e46ee577e4a10
```

The separately uploaded note is byte-identical to its package copy.

## 2. Package replay and independent checks

[SESSION: executed here] Two fresh extractions were used, with no edits to the submitted files. In each:

```sh
python -I -B owner_section_check_r2.py --check
python -I -B owner_section_check_r2.py --negcontrol
python -I -B owner_section_check_r2.py
```

| Check | Receiver result |
|---|---|
| Root manifest | **16/16 listed entries match**, before and after replay |
| Source files | **6/6 hashes match** |
| `--check` | exit 0; three computed comparison artifacts byte-identical |
| Negative controls | **4/4 caught**; exit 0 means successful detection, as documented |
| Normal regeneration | exit 0; stored comparison artifacts unchanged |
| Two clean runs | stdout logs byte-identical; no Python cache created |
| Separate receiver audit | **125/125 identity, custody and comparison assertions passed** |
| Independent comparison implementation | **30/30 section outcomes, ranges and trimmed hashes reproduced** |
| Independent mutation tests | **4/4 block differences and 4/4 changed full-file hashes detected** |

[SESSION: implementation independence] `independent_audit.py` does not import or execute the preparer's comparison module. It locates numbered headings and OPEN-entry boundaries independently, preserves raw bytes and also reproduces the preparer's declared trailing-blank-line trimming. Section labels and the claimed outputs are shared test inputs, not independent source discoveries. All raw-slice equality/change verdicts agree with the trimmed verdicts. `INDEPENDENT_AUDIT.json` records both sets of sizes/hashes. Its output is identical when run against either clean extraction.

## 3. Source custody and comparison results

[SESSION: computed here] The original transfer ZIP is present and matches:

```text
efb824cc790052c5d2a7299ef8bf8fe0581e141f7cdc648c19d340d10a1e30af
```

Its four payload manifest entries pass. The two old editions match the original transfer members, the specific members in `TRIAD_RER_RECEIVING_REVIEW_20261019.zip`, and the prior owner-section receiver handoff. Both named archive hashes also match the custody record. The upstream history before the archived originals remains **NOT_REAUTHENTICATED**; archive/member comparison is not identity verification of the human supplier or owner adoption authority.

| Key | Bytes | SHA-256 |
|---|---:|---|
| DYAD6413 | 187,458 | `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` |
| RRF082 | 88,773 | `f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461` |

[SESSION: independently compared here] All four successor source files in r2 equal the corresponding files in the original accepted r19 ZIP. The matrix in r2 also equals the original r19 matrix; it is not a newly edited catalog.

| Direct leg | Identical | Changed |
|---|---:|---:|
| Dyadic v6.4.13 → v6.4.18 | 3 | 2 |
| Dyadic v6.4.13 → v6.4.19 | 3 | 2 |
| RRF v0.8.2 → v0.8.3 | 6 | 4 |
| RRF v0.8.2 → v0.8.4 | 4 | 6 |
| **Total** | **16** | **14** |

[SESSION: independently compared here] For both Dyadic legs, OPEN 19, §6.15 and §6.16 are byte-identical; OPEN 20 and §6.17 change. The full Lemma F statement paragraph and the combined F1–F3 paragraph are byte-identical. Under the script's blank-line segmentation, 7/8 old §6.17 segments survive; this count includes structural text and is not a count of seven independently reviewed theorems.

[SESSION: independently compared here] For RRF v0.8.2→v0.8.3, §2.3, §2.4a, §4.2a, §4.3, §6.3 and §6.4 are identical. §2.4, §2.4b, §4.2 and §6.2 change. In §2.4b, 5/8 old segments survive; three are rewritten. In §4.2, all 6/6 old segments survive plus the N9 overlay. Thus **OSC-N2 is locally reproduced**: §4.2 is not byte-identical on the v0.8.2→v0.8.3 leg.

[SESSION: independently compared here] On the direct v0.8.2→v0.8.4 leg, §2.3, §2.4a, §4.3 and §6.4 are identical. §2.4, §2.4b, §4.2, §4.2a, §6.2 and §6.3 change. No whole-row old-to-current equality is granted to DYAD6413 or RRF082. RRF v0.8 is not supplied by this package; none of the twelve RRF08_ADOPTED pin identities is authenticated by these legs.

## 4. Two nonblocking tooling observations

### OSC2-T1 — mutation log labels

[SESSION: code inspection and executed reproduction] In `compare(mut=...)`, `ok_new` is calculated before the in-memory mutation, but the printed SHA-256 is calculated after it. The four altered full-file hashes are therefore printed with **MATCH**, despite differing from their expected source hashes. The alternative display branch also compares `mut == owner` while the mutation selector is a pair label, not an owner label.

The section mismatch detector itself works: each targeted block becomes CHANGED. Unmodified-run source hash checks are correct. This is a **negative-log provenance/display defect**, not a failure of the submitted four mutation detections or of the normal section comparisons. A subsequent tooling update should distinguish baseline identity from mutated identity, e.g. `BASELINE_MATCH` and `MUTATED_HASH_MISMATCH`, or recompute the post-mutation hash status. Do not read these four MATCH labels as evidence of mutated-file identity.

### OSC2-T2 — copied historical manifest not listed by root manifest

[SESSION: computed here] The root manifest lists sixteen payloads and excludes itself correctly. There is one additional unlisted payload: `inputs/SHA256SUMS.txt`, a copy of the historical transfer manifest. It is not a second runnable manifest for the r2 inputs layout. I compared its bytes directly with the authenticated transfer ZIP: they are identical.

This therefore leaves no unresolved source-byte discrepancy in this receiving review, but the sixteen root entries are not a complete manifest of every non-root-manifest file. For r20, pin this historical input like any other input, or pin the intact original r2 ZIP as an archive. Do not use a recursive basename exclusion that drops every file called SHA256SUMS.txt; exclude only the new root manifest's own path.

[SESSION: receiving disposition] **Neither observation blocks this scoped acceptance or r20 preparation.** The original r2 package/logs stay unchanged. No separate r3 or repeat owner scientific review is required before the narrow r20. Carry these caveats in its change record and reference this receipt.

## 5. Meaning of this acceptance

[SESSION: receiving decision] **OWNER_SECTION_CHECK r2: ACCEPT SCOPED.** Historical source identities, declared section differences and full-paragraph preservation are independently supported. The preparer's current local file-identity verification can be recorded as such, without rewriting the earlier r19 availability statements.

[SESSION: boundary] Source identity, selected section equality, scientific source fidelity, proof certification and adoption remain separate. This review supplies no new theorem, no physical exchange/carrier result, no G9 per-reference closure and no Stage-2 certificate. The fixed historical pins do not need repinning merely because their bytes have been recovered.

## 6. Phase A r20 — explicitly authorized preparation scope

[SESSION: receiving decision] **Phase A r20 preparation is authorized.** This is not acceptance of an as-yet-unbuilt r20 and not adoption of RER. Use unchanged RER r4.13 (`e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c`) and accepted Phase A r19 (`683046e70c1d4644e33ae40a3cde85666f6346ecb979874ea9b66430443efe06`).

1. Add the exact DYAD6413 and RRF082 source bytes to `sources_available/`, hash them locally, add `source_custody_r20.json`, and pin the original r2 package/comparison artifacts plus this receiving record. Keep the external custody boundary NOT_REAUTHENTICATED. Preserve preparer-local and receiver-local execution attributions separately.
2. For **exactly the two rows** `RER-DYAD-FORMAL-INVOLUTION / RECORD_IMPORT / 0 / DYAD6413` and `/ 1 / RRF082`, set `bytes_status=BYTE_VERIFIED_MATCH` and `authentication=BYTE_VERIFIED_HERE`. Update `available_file`, inspection extent and narrowly scoped comparison/availability explanations as needed. Preserve earlier receiver reports as dated history rather than silently converting their authorship.
3. Keep both rows **HISTORICAL / RECHECK_IN_PHASE_B**. Do not mark them CURRENT, VERIFIED or UNCHANGED_VERIFIED; the old-to-current sections are not all equal. Keep all cited paths, editions, hashes and line ranges unchanged. The unchanged RER source and its historical package-presence flags must remain truthful; presence in a new Phase A source inventory does not make an old RER package contain the file.
4. All other 89 matrix rows, scientific records, grades, OPENs, owner-current version/identity/evidence entries, SYNC status/receiving-disposition and all 13 gap-reference audit fields are preserved. Derived missing-byte lists may remove just the two newly available keys. Add only the necessary r20 schema/provenance/history metadata; preserve r19 outputs and logs as immutable comparison inputs.
5. Expected counts (arithmetic expectation, not an r20 execution result): **31/2/52/6** for VERIFIED/OWNER_REPORTED/HISTORICAL/BLOCKED; **62/4/24/1** for BYTE_VERIFIED_HERE/RECEIVER_BYTE_VERIFIED/HASH_PRINTED_UNVERIFIED/UNAUTHENTICATED_NO_HASH. Total **91 rows**. Schema-only changes to registry/blocked records are allowed, together with derived byte-availability metadata; the two ER-2B scientific blocks do not change.
6. Required negative controls should reject either missing/altered source file, mismatched source/custody hash, silent pin migration, whole-row equality or status promotion, loss of the custody boundary, alteration of other rows/records, or premature G9/SYNC/ER-2B changes. Preserve the source check's proper distinction between baseline and mutation hashes. Include nested historical manifests in the new input coverage, or pin their intact containing archive.
7. Record the previous r19 change-record locator correction **§5 → §6** in the r20 change record only. Do not rewrite r19. G10 consumer wording is outside this authorization.

## 7. Final state and continuation capsule

[SESSION: receiving disposition] RER **r4.13 DRAFT** and Phase A **r19 ACCEPT SCOPED** remain the active reviewed objects. r2 source/section review is **ACCEPT SCOPED**; r20 is **AUTHORIZED_TO_PREPARE, NOT_REVIEWED**. No r20 output was created in this session. G9/1–G9/3, G2 §5b, the two ER-2B blocks, and Stage-2 regional/global certification and multi-step error control remain open. No owner mathematical proof or Stage-2 scientific computation was replayed.

Evidence files: `REPLAY_RESULTS.json`, `INDEPENDENT_AUDIT.json`, `SOURCE_MANIFEST.json`, `replay_received.py`, `independent_audit.py` and `logs/`. The independent audit JSON is reproducible from the delivered package plus the named previously supplied archives. The full source editions are inputs, not new releases.
