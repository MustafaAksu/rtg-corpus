"""Phase A r19 -> r20: two-row source-availability step (receiving decision of 21 Oct 2026 on OWNER_SECTION_CHECK_r2: ACCEPT SCOPED; r20 AUTHORIZED TO PREPARE, §6).
Source unchanged (RER r4.13); r19 outputs kept as history. Exactly the two rows RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413 and /1 RRF082 change: their original
bytes are held in sources_available and hashed here (custody r20), so bytes_status BYTE_VERIFIED_MATCH and authentication BYTE_VERIFIED_HERE; currency and
status stay RECHECK_IN_PHASE_B / HISTORICAL; no pin moves; whole-row equality not asserted. Other 89 rows, owner_current, pins, grades, OPENs, G9 audits and
the SYNC receipt unchanged; derived missing-bytes lists lose exactly these two keys. Expected statuses 31/2/52/6; authentication 62/4/24/1.
Args: TARGET_DIR TRANSFER_DIR (extracted receiver transfer kit) TRANSFER_ZIP OSC2_DIR OSC2_ZIP RECEIVER_REVIEW_R2_MD RECEIVER_REVIEW_R19_MD"""
import sys, os, json, shutil, hashlib
D, XF, XZ, SC2, SZ, RV2, RV19 = sys.argv[1:8]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
H13 = '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542'; H82 = 'f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461'
XZH = 'efb824cc790052c5d2a7299ef8bf8fe0581e141f7cdc648c19d340d10a1e30af'; SZH = 'e149b349d4420fb3db58e9c357f9c7822fa3074be0fecf1e149e46ee577e4a10'
assert sha(open(XZ, 'rb').read()) == XZH and sha(open(SZ, 'rb').read()) == SZH
assert not any(x == '__pycache__' for _, ds, _ in os.walk(D) for x in ds)
os.remove(os.path.join(D, 'SHA256SUMS.txt'))
H = os.path.join(D, 'inputs/phaseA_r19_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r19.txt'))
for f in ('RER_PHASE_A_R19_CHANGE_RECORD_20261021.md', 'patch_r19.py'): os.remove(os.path.join(D, f))
# the two recovered originals
NEW = {'DYAD6413__RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md': ('RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md', H13, '6.4.13'), 'RRF082__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md': ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md', H82, '0.8.2')}
RC = json.load(open(os.path.join(XF, 'CUSTODY.json'))); rcf = {e['file']: e for e in RC['files']}
cust = {}
for fn, (src, h, v) in NEW.items():
    b = open(os.path.join(XF, src), 'rb').read(); assert sha(b) == h, fn; e = rcf[src]; assert e['sha256'] == h and e['bytes'] == len(b)
    open(os.path.join(D, 'sources_available', fn), 'wb').write(b)
    cust[fn] = {'key': fn.split('__')[0], 'sha256': h, 'version': v, 'bytes': len(b),
                'container': 'receiver source transfer RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip (' + XZH + '; pinned as inputs/RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip), member RER_HISTORICAL_SOURCE_TRANSFER_20261021/' + src + ', uploaded by the PI to the preparer session on 21 Oct 2026; hashed here on receipt and again when copied into this package; hash equals the RER pin and the receiver custody record',
                'receiver_declared_chain': {k: e[k] for k in ('source_archive', 'source_archive_sha256', 'source_member', 'previous_handoff', 'previous_handoff_sha256', 'previous_handoff_member', 'extraction_and_comparison', 'external_custody_before_original_archive')}}
open(os.path.join(D, 'inputs/source_custody_r20.json'), 'w').write(dump({'_about': 'Phase A r20 custody for the two recovered historical owner editions (DYAD6413, RRF082).',
    'container_chain_status': 'PREPARER_DECLARED: the transfer-zip -> upload -> local hash steps are the preparer\'s; the archive/member chain inside receiver_declared_chain is the receiver\'s record (RECEIVER-REPORTED, replayed by the receiver on 21 Oct 2026, not here); external custody before TRIAD_RER_RECEIVING_REVIEW_20261019.zip NOT_REAUTHENTICATED (receiver statement, kept).', 'files': cust}))
shutil.copyfile(XZ, os.path.join(D, 'inputs/RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip'))
shutil.copyfile(SZ, os.path.join(D, 'inputs/OWNER_SECTION_CHECK_r2.zip'))
scd = os.path.join(D, 'inputs/owner_section_check_r2'); os.makedirs(scd)
for f in ('owner_section_check_r2.py', 'OWNER_SECTION_CHECK_r2_NOTE_20261021.md', 'out/compare_output.txt', 'out/owner_section_check.json', 'out/changed_blocks.diff', 'out/negcontrol_output.txt'):
    shutil.copyfile(os.path.join(SC2, f), os.path.join(scd, os.path.basename(f)))
shutil.copyfile(RV2, os.path.join(D, 'inputs/receiving_review_owner_section_r2_20261021.md')); shutil.copyfile(RV19, os.path.join(D, 'inputs/receiving_review_phaseA_r19_20261021.md'))
RV2H = sha(open(RV2, 'rb').read()); RV19H = sha(open(RV19, 'rb').read())

# ---- ledger
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
KV['_catalog_checked'] = '2026-10-21 (Phase A r20, preparer)'
KV['_source_authority']['Dyadic'] += ' Historical v6.4.13 (RER pin of DYAD6413): bytes held and hashed here since Phase A r20 (custody r20; receiver source transfer); section check r2 inputs/owner_section_check_r2/.'
KV['_source_authority']['RRF'] += ' Historical v0.8.2 (RER pin of RRF082): bytes held and hashed here since Phase A r20 (custody r20; receiver source transfer); section check r2 inputs/owner_section_check_r2/. v0.8 original still not recovered.'
open(p, 'w').write(dump(KV))

# ---- catalog (two keys only)
p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p)); K = CS['keys']
SC2N = 'inputs/owner_section_check_r2/ (OWNER_SECTION_CHECK_r2.zip ' + SZH[:8] + '…' + SZH[-4:] + '; receiver review ' + RV2H[:8] + '…' + RV2H[-4:] + ', ACCEPT SCOPED, 21 Oct 2026)'
k = K['DYAD6413']; assert k['rule'] == 'RECHECK_IN_PHASE_B' and k.get('receiver_byte_verified') is True
k['reason'] += (' Phase A r20: the v6.4.13 file is now held in sources_available and hashed here (inputs/source_custody_r20.json; receiver source transfer ' + XZH[:8] + '…' + XZH[-4:] + '); hash equals the RER pin. '
                'Section check r2 ' + SC2N + ', replayed here: v6.4.13 -> v6.4.18 and v6.4.13 -> v6.4.19 — §2 OPEN 19, §6.15, §6.16 IDENTICAL; §2 OPEN 20 and §6.17 CHANGED (owner closing B-∞ existence in v6.4.18; the Lemma F and F1–F3 '
                'paragraphs retained verbatim). Authentication BYTE_VERIFIED_HERE for the file identity; the earlier receiver recovery (19 Oct) stays as dated history. Rule and pin unchanged; whole-row old-to-current equality is not asserted.')
k['receiver_note'] += ' Phase A r20: file held and hashed here (BYTE_VERIFIED_HERE); the receiver\'s 19 Oct recovery is kept as the earlier report.'
k = K['RRF082']; assert k['rule'] == 'RECHECK_IN_PHASE_B' and k.get('receiver_byte_verified') is True
k['reason'] += (' Phase A r20: the v0.8.2 file is now held in sources_available and hashed here (inputs/source_custody_r20.json; receiver source transfer ' + XZH[:8] + '…' + XZH[-4:] + '); hash equals the RER pin. '
                'Section check r2 ' + SC2N + ', replayed here: v0.8.2 -> v0.8.3 — §2.3 IDENTICAL; §2.4b CHANGED (3 of 8 paragraphs rewritten) and §4.2 CHANGED (additive N9 overlay; 6/6 paragraphs retained) — OSC-N2 reproduced here; '
                'v0.8.2 -> v0.8.4 — §2.3 IDENTICAL, §2.4b and §4.2 CHANGED. Authentication BYTE_VERIFIED_HERE for the file identity; the earlier receiver recovery (19 Oct) stays as dated history. Rule and pin unchanged; whole-row old-to-current equality is not asserted.')
k['receiver_note'] += ' Phase A r20: file held and hashed here (BYTE_VERIFIED_HERE); the receiver\'s 19 Oct recovery is kept as the earlier report.'
CS['_about'] += ' Phase A r20 (21 Oct): DYAD6413 and RRF082 original bytes held and hashed here (custody r20; receiver source transfer; section check r2 receiver-accepted) — authentication BYTE_VERIFIED_HERE, currency/status unchanged (RECHECK_IN_PHASE_B / HISTORICAL); nothing else changed.'
open(p, 'w').write(dump(CS))

# ---- builder
rp('build_phaseA.py', [
 ('"""RER Phase A r19 builder (deterministic; r19 is a catalog step', '"""RER Phase A r20 builder (deterministic; r20 holds the DYAD6413 / RRF082 originals, two rows BYTE_VERIFIED_HERE, currency unchanged; r19 is a catalog step'),
 ("'RER-REGISTRY-PHASEA/19'", "'RER-REGISTRY-PHASEA/20'"), ("'RER-SOURCE-CURRENCY/19'", "'RER-SOURCE-CURRENCY/20'"), ("'RER-BLOCKED-SOURCES/19'", "'RER-BLOCKED-SOURCES/20'"),
 ("'# RER r4.13 — source-currency matrix (Phase A r19, noncanonical)'", "'# RER r4.13 — source-currency matrix (Phase A r20, noncanonical)'"),
 ("'# RER r4.13 — blocked-source register (Phase A r19, noncanonical)'", "'# RER r4.13 — blocked-source register (Phase A r20, noncanonical)'"),
 ("not a contradiction in the scoped records.']}",
  "not a contradiction in the scoped records.',\n"
  "                          'Phase A r20 (21 Oct 2026): source-availability step on the unchanged RER r4.13 and the r19 catalog (r19 ACCEPT SCOPED). The recovered originals Dyadic v6.4.13 (5958f7fe…8542) and RRF v0.8.2 (f09dbb12…5461) arrived in the receiver source transfer RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip (" + XZH[:8] + "…" + XZH[-4:] + "), were hashed here and are held in sources_available (custody r20; external custody before the 19 Oct receiver archive NOT_REAUTHENTICATED). Exactly two rows change: RER-DYAD-FORMAL-INVOLUTION/0 DYAD6413 and /1 RRF082 — bytes_status BYTE_VERIFIED_MATCH, authentication BYTE_VERIFIED_HERE; currency RECHECK_IN_PHASE_B and status HISTORICAL unchanged, because the section check r2 (OWNER_SECTION_CHECK_r2.zip " + SZH[:8] + "…" + SZH[-4:] + "; receiver ACCEPT SCOPED, review " + RV2H[:8] + "…" + RV2H[-4:] + ") shows the cited OPEN 20 / §6.17 (Dyadic) and §2.4b / §4.2 (RRF) changed between the pinned and the current editions while OPEN 19 / §6.15 / §6.16 and §2.3 are identical; the pins do not move. The derived missing-bytes lists lose these two keys. Receiver tooling notes on r2 carried here (OSC2-T1: the r2 negative-control log prints the post-mutation hash with the pre-mutation MATCH label — display only, detection correct; OSC2-T2: the r2 root manifest did not list the copied historical inputs/SHA256SUMS.txt, which the receiver compared byte-identical to the transfer kit; r20 pins the intact r2 and transfer archives). Locator correction to the r19 change record: the r19 authorization is §6 of the owner-section receiving review (not §5); r19 bytes untouched. Nothing else changed: 89 rows, owner_current, pins, grades, OPEN items, G9 audits, SYNC receipt, ER-2B blocks. v0.8 (12 RRF08_ADOPTED pins) still not recovered.']}"),
])

# ---- checker
C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    assert t.count(a) == 1, a[:60]; i = t.index(a); j = t.index(b, i); return t[:i] + new + t[j:]
def one(t, a, b):
    assert t.count(a) == 1, a[:80]; return t.replace(a, b)
# A23: DYAD6413 row now byte-verified here, file held, custody r20, r2 section check
A23_OLD = "and x['authentication'] == 'RECEIVER_BYTE_VERIFIED'\n                     and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' and x['verified_current_hash'] == D19\n                     and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['current_owner_version'] == '6.4.19' and 'RECEIVER-REPORTED, not replayed here' in x['currency_reason'] for x in r13)"
A23_NEW = ("and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['available_file'] == 'sources_available/' + FN13 and x['inspection_extent'] == 'FULL_FILE_HASH'\n"
           "                     and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' and x['verified_current_hash'] == D19\n"
           "                     and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['current_owner_version'] == '6.4.19' and 'RECEIVER-REPORTED, not replayed here' in x['currency_reason'] and 'Phase A r20' in x['currency_reason']\n"
           "                     and 'whole-row old-to-current equality is not asserted' in x['currency_reason'] and 'OPEN 20 and §6.17 CHANGED' in x['currency_reason'] and 'RECEIVER-REPORTED (Phase A review, 19 Oct 2026)' in x.get('receiver_note', '') for x in r13)")
t = one(t, A23_OLD, A23_NEW)
t = one(t, "    FN19 = 'DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md'; P19 = os.path.join(HERE, 'sources_available', FN19)",
        "    FN13 = 'DYAD6413__RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md'; P13 = os.path.join(HERE, 'sources_available', FN13); H13 = '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542'\n"
        "    f13_ok = FN13 not in withhold and os.path.isfile(P13) and sha(open(P13, 'rb').read()) == H13\n"
        "    C20 = json.loads(ri('inputs/source_custody_r20.json')); c13 = C20.get('files', {}).get(FN13, {})\n"
        "    sc2 = ri('inputs/owner_section_check_r2/compare_output.txt').decode('utf-8')\n"
        "    def leg(txt, a, b):\n"
        "        i = txt.find('== ' + a); j = txt.find('== ', i + 3) if i >= 0 else -1; return txt[i:(j if j > 0 else len(txt))] if i >= 0 else ''\n"
        "    d13_19 = leg(sc2, 'Dyadic 13->19', ''); d13_18 = leg(sc2, 'Dyadic 13->18', '')\n"
        "    d13_ok = all(f'v6.4.13 {H13} MATCH' in L and all(re.search(r'^  ' + re.escape(s) + r' +v6\\.4\\.13 lines \\S+ +v6\\.4\\.1[89] lines \\S+ +IDENTICAL', L, re.M) for s in ('§2 OPEN 19', '§6.15', '§6.16'))\n"
        "                 and all(re.search(r'^  ' + re.escape(s) + r' +v6\\.4\\.13 lines \\S+ +v6\\.4\\.1[89] lines \\S+ +CHANGED', L, re.M) for s in ('§2 OPEN 20', '§6.17')) and re.search(r'^  §6\\.17 +paragraphs: 8 old, 7 retained', L, re.M) for L in (d13_18, d13_19))\n"
        "    FN19 = 'DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md'; P19 = os.path.join(HERE, 'sources_available', FN19)")
t = one(t, "    dy_ok = (dy['version'] == '6.4.19' and dy['sha256'] == D19 and dy['evidence'] == 'BYTE_VERIFIED' and D19 in avail and D18 in avail and D17 in avail and f18_ok and f19_ok",
        "    dy_ok = (dy['version'] == '6.4.19' and dy['sha256'] == D19 and dy['evidence'] == 'BYTE_VERIFIED' and D19 in avail and D18 in avail and D17 in avail and f18_ok and f19_ok and f13_ok and H13 in avail\n"
        "             and c13.get('key') == 'DYAD6413' and c13.get('sha256') == H13 and bool(c13.get('container')) and C20.get('container_chain_status', '').startswith('PREPARER_DECLARED') and 'NOT_REAUTHENTICATED' in C20.get('container_chain_status', '')\n"
        "             and c13.get('receiver_declared_chain', {}).get('external_custody_before_original_archive') == 'NOT_REAUTHENTICATED' and c13['receiver_declared_chain'].get('source_archive_sha256') == '9bfeca625d43cffcce027e6d8bbb808daa4570e60e60cbe06d97ef156a337c12' and d13_ok")
t = one(t, "    g('A23 Dyadic v6.4.19 byte-verified (file, custody r19, section check: cited blocks identical, §6.14 changed); v6.4.18/v6.4.17 identities and r8-r18 history kept; DYAD6413 pin v6.4.13 RECHECK (receiver direct comparison recorded); DYAD6418 pin v6.4.18 UNCHANGED_VERIFIED'",
        "    g('A23 Dyadic v6.4.19 byte-verified (file, custody r19, section check r1); v6.4.18/v6.4.17 identities and r8-r18 history kept; DYAD6413: v6.4.13 file held and hashed here (custody r20, receiver chain kept as declared, NOT_REAUTHENTICATED boundary), BYTE_VERIFIED_HERE, section check r2 (OPEN 19/§6.15/§6.16 identical, OPEN 20/§6.17 changed) replayed, currency RECHECK/HISTORICAL unchanged; DYAD6418 pin v6.4.18 UNCHANGED_VERIFIED'")
# A24: add r19 record
t = one(t, "    H18 = 'inputs/phaseA_r18_outputs/'; o18 = ri(H18 + 'check_phaseA_output_r18.txt').decode('utf-8')",
        "    H18 = 'inputs/phaseA_r18_outputs/'; o18 = ri(H18 + 'check_phaseA_output_r18.txt').decode('utf-8'); H19 = 'inputs/phaseA_r19_outputs/'; o19 = ri(H19 + 'check_phaseA_output_r19.txt').decode('utf-8')")
t = one(t, "and '34/34 gates PASS' in o18 and 'BAD' not in o13 + o15 + o16 + o17 + o18", "and '34/34 gates PASS' in o18 and '34/34 gates PASS' in o19 and 'negative controls (each must FAIL the named gate)' in o19 and 'BAD' not in o13 + o15 + o16 + o17 + o18 + o19")
t = one(t, "r13, r15, r16, r17 and r18 checker records kept', src_ok)", "r13, r15, r16, r17, r18 and r19 checker records kept', src_ok)")
# A25: registry identical to r19 except schema
t = one(t, "    g18 = json.loads(B.rd(H18 + 'RER_REGISTRY_v0_2_r4_13_PHASEA.json'))", "    g19 = json.loads(B.rd(H19 + 'RER_REGISTRY_v0_2_r4_13_PHASEA.json'))")
t = one(t, "    g('A25 r18 registry equality: source unchanged, registry identical to r18 apart from the schema label (records, gap entries, source table, legacy snapshot)', strip(reg) == strip(g18) and g18['schema'] == 'RER-REGISTRY-PHASEA/18' and reg['schema'] == 'RER-REGISTRY-PHASEA/19' and len(reg['records']) == 20)",
        "    g('A25 r19 registry equality: source unchanged, registry identical to r19 apart from the schema label (records, gap entries, source table, legacy snapshot)', strip(reg) == strip(g19) and g19['schema'] == 'RER-REGISTRY-PHASEA/19' and reg['schema'] == 'RER-REGISTRY-PHASEA/20' and len(reg['records']) == 20)")
# A28: matrix vs r19
NEW_A28 = r'''    m19 = json.loads(B.rd(H19 + 'SOURCE_CURRENCY_MATRIX.json')); b19 = json.loads(B.rd(H19 + 'BLOCKED_SOURCE_REGISTER.json'))
    TWO = {('RER-DYAD-FORMAL-INVOLUTION', 'RECORD_IMPORT', 0, 'DYAD6413'), ('RER-DYAD-FORMAL-INVOLUTION', 'RECORD_IMPORT', 1, 'RRF082')}
    AVF = {'bytes_status', 'authentication', 'available_file', 'inspection_extent', 'currency_reason', 'receiver_note'}
    dk = [((x['record'], x['row_kind'], x['n'], x['key']), sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k))) for x, y in zip(cm['rows'], m19['rows'])]
    rows19_ok = (len(cm['rows']) == len(m19['rows']) == 91 and all((x['key'], x['record'], x['n'], x['row_kind'], x['cited_sha256'], x['cited_version'], x['lines'], x['cited_path'], x['currency'], x['status'], x['verified_current_hash'], x['current_owner_evidence'],
                                                                     x['path_in_r4_package'], x['path_in_r4_13_package']) == (y['key'], y['record'], y['n'], y['row_kind'], y['cited_sha256'], y['cited_version'], y['lines'], y['cited_path'], y['currency'], y['status'], y['verified_current_hash'], y['current_owner_evidence'], y['path_in_r4_package'], y['path_in_r4_13_package']) for x, y in zip(cm['rows'], m19['rows']))
                 and all(d == [] for idf, d in dk if idf not in TWO) and all(set(d) == AVF for idf, d in dk if idf in TWO) and sum(1 for idf, d in dk if d) == 2
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256', 'byte_availability_gap')}
    bag, bag19 = br.get('byte_availability_gap', {}), b19.get('byte_availability_gap', {})
    rest19_ok = (stripb(br) == stripb(b19) and bag.get('note') == bag19.get('note') and sorted(set(bag19.get('keys', [])) - set(bag.get('keys', []))) == ['DYAD6413', 'RRF082'] and set(bag.get('keys', [])) <= set(bag19.get('keys', []))
                 and oc == m19['owner_current'] and cm.get('scientific_sync_warnings') == m19.get('scientific_sync_warnings') and cm['watch_items'][:-1] == m19['watch_items'] and cm['watch_items'][-1].startswith('Phase A r20 (21 Oct 2026): source-availability step')
                 and meta.get('scope') == m19['owner_catalog']['scope'] and meta.get('checked') == '2026-10-21 (Phase A r20, preparer)' and sorted(o for o in meta.get('source_authority', {}) if meta['source_authority'][o] != m19['owner_catalog']['source_authority'].get(o)) == ['Dyadic', 'RRF']
                 and sorted(set(m19['bytes_not_available_to_preparer']) - set(cm['bytes_not_available_to_preparer'])) == ['DYAD6413', 'RRF082'] and set(cm['bytes_not_available_to_preparer']) <= set(m19['bytes_not_available_to_preparer'])
                 and m19['schema'] == 'RER-SOURCE-CURRENCY/19' and cm['schema'] == 'RER-SOURCE-CURRENCY/20' and len(br['blocked']) == len(b19['blocked']))
    g('A28 r19 matrix equality: 91 rows; exactly the two rows DYAD6413 and RRF082 differ, only in byte-availability fields; pins, lines, paths, currency, status, verified hashes unchanged everywhere; owner_current, warning, blocked list and G9 audits unchanged; missing-bytes lists lose exactly the two keys', rows19_ok and rest19_ok, f'{sum(1 for idf, d in dk if d)} row(s) differ')
'''
t = cut(t, "    m18 = json.loads(B.rd(H18 + 'SOURCE_CURRENCY_MATRIX.json'))", "    H83 = ", NEW_A28)
# A29: RRF082 row
t = one(t, "    FN84 = 'RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md'; P84 = os.path.join(HERE, 'sources_available', FN84)",
        "    FN82 = 'RRF082__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md'; P82 = os.path.join(HERE, 'sources_available', FN82); H82 = 'f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461'\n"
        "    f82_ok = FN82 not in withhold and os.path.isfile(P82) and sha(open(P82, 'rb').read()) == H82; c82 = C20.get('files', {}).get(FN82, {})\n"
        "    r82_83 = leg(sc2, 'RRF 82->83', ''); r82_84 = leg(sc2, 'RRF 82->84', '')\n"
        "    r82_ok = (f'v0.8.2 {H82} MATCH' in r82_83 and f'v0.8.2 {H82} MATCH' in r82_84 and f'v0.8.3 {H83} MATCH' in r82_83 and f'v0.8.4 {F84} MATCH' in r82_84\n"
        "              and all(re.search(r'^  §2\\.3 +v0\\.8\\.2 lines \\S+ +v0\\.8\\.[34] lines \\S+ +IDENTICAL', L, re.M) and re.search(r'^  §2\\.4b +v0\\.8\\.2 lines \\S+ +v0\\.8\\.[34] lines \\S+ +CHANGED', L, re.M) and re.search(r'^  §4\\.2 +v0\\.8\\.2 lines \\S+ +v0\\.8\\.[34] lines \\S+ +CHANGED', L, re.M) for L in (r82_83, r82_84))\n"
        "              and re.search(r'^  §4\\.2 +paragraphs: 6 old, 6 retained', r82_83, re.M) and re.search(r'^  §2\\.4b +paragraphs: 8 old, 5 retained', r82_83, re.M) and 'negative controls: 4/4 caught' in ri('inputs/owner_section_check_r2/negcontrol_output.txt').decode('utf-8'))\n"
        "    FN84 = 'RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md'; P84 = os.path.join(HERE, 'sources_available', FN84)")
t = one(t, "           and len(rr82) == 1 and all(x['cited_version'] == '0.8.2' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED' and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and 'OSC-N2 correction' in x['currency_reason']",
        "           and f82_ok and H82 in avail and c82.get('key') == 'RRF082' and c82.get('sha256') == H82 and bool(c82.get('container')) and c82.get('receiver_declared_chain', {}).get('external_custody_before_original_archive') == 'NOT_REAUTHENTICATED' and r82_ok\n"
        "           and len(rr82) == 1 and all(x['cited_version'] == '0.8.2' and x['cited_sha256'] == H82 and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['available_file'] == 'sources_available/' + FN82 and x['inspection_extent'] == 'FULL_FILE_HASH'\n"
        "                                      and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and 'OSC-N2 correction' in x['currency_reason'] and 'OSC-N2 reproduced here' in x['currency_reason'] and 'whole-row old-to-current equality is not asserted' in x['currency_reason']\n"
        "                                      and 'RECEIVER-REPORTED (Phase A review, 19 Oct 2026)' in x.get('receiver_note', '')")
t = one(t, "    g('A29 RRF v0.8.4 byte-verified (file, custody r19, section check 9/11/2 with §2.3 identical and §2.4b changed); v0.8.3 superseded; RRF083 and RRF082 stay RECHECK_IN_PHASE_B/HISTORICAL with section receipts (RRF082 reason corrected); 12 v0.8 rows keep their source limit; no RRF row CURRENT'",
        "    g('A29 RRF v0.8.4 byte-verified (file, custody r19, section check r1 9/11/2); v0.8.3 superseded; RRF082: v0.8.2 file held and hashed here (custody r20), BYTE_VERIFIED_HERE, section check r2 (§2.3 identical; §2.4b and §4.2 changed v0.8.2 -> v0.8.3 and -> v0.8.4, OSC-N2 reproduced) replayed, currency RECHECK/HISTORICAL unchanged; RRF083 RECHECK/HISTORICAL with receipt; 12 v0.8 rows keep their source limit; no RRF row CURRENT'")
# A32: counts and receiver reviews
t = one(t, "               and h[:8] in cm['watch_items'][-1] for o, v, h, rec, fn in NV)", "               and h[:8] in next((w for w in cm['watch_items'] if w.startswith('Phase A r19 (21 Oct 2026)')), '') for o, v, h, rec, fn in NV)")
t = one(t, "    rv = ri('inputs/receiving_review_owner_section_20261021.md').decode('utf-8', 'replace')",
        "    rv = ri('inputs/receiving_review_owner_section_20261021.md').decode('utf-8', 'replace'); rv2 = ri('inputs/receiving_review_owner_section_r2_20261021.md').decode('utf-8', 'replace'); rv19 = ri('inputs/receiving_review_phaseA_r19_20261021.md').decode('utf-8', 'replace')\n"
        "    xz = ri('inputs/RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip'); sz = ri('inputs/OWNER_SECTION_CHECK_r2.zip')")
t = one(t, "           and sum(1 for x in cm['rows'] if x['authentication'] == 'BYTE_VERIFIED_HERE') == 60 and sum(1 for x in cm['rows'] if x['authentication'] == 'RECEIVER_BYTE_VERIFIED') == 6)",
        "           and sum(1 for x in cm['rows'] if x['authentication'] == 'BYTE_VERIFIED_HERE') == 62 and sum(1 for x in cm['rows'] if x['authentication'] == 'RECEIVER_BYTE_VERIFIED') == 4\n"
        "           and sum(1 for x in cm['rows'] if x['authentication'] == 'HASH_PRINTED_UNVERIFIED') == 24 and sum(1 for x in cm['rows'] if x['authentication'] == 'UNAUTHENTICATED_NO_HASH') == 1\n"
        "           and sha(xz) == 'efb824cc790052c5d2a7299ef8bf8fe0581e141f7cdc648c19d340d10a1e30af' and sha(sz) == 'e149b349d4420fb3db58e9c357f9c7822fa3074be0fecf1e149e46ee577e4a10'\n"
        "           and 'ACCEPT SCOPED' in rv2 and 'Phase A r20 preparation is authorized' in rv2 and 'e149b349d4420fb3db58e9c357f9c7822fa3074be0fecf1e149e46ee577e4a10' in rv2 and 'OSC2-T1' in rv2 and 'OSC2-T2' in rv2 and '62/4/24/1' in rv2\n"
        "           and 'ACCEPT SCOPED' in rv19 and '683046e70c1d4644e33ae40a3cde85666f6346ecb979874ea9b66430443efe06' in rv19 and 'OSC2-T1' in cm['watch_items'][-1] and 'OSC2-T2' in cm['watch_items'][-1] and '§6 of the owner-section receiving review (not §5)' in cm['watch_items'][-1]\n"
        "           and all(x['authentication'] != 'RECEIVER_BYTE_VERIFIED' for x in cm['rows'] if x['key'] in ('DYAD6413', 'RRF082')))")
t = one(t, "    g('A32 three current owner versions BYTE_VERIFIED with held files, custody r19 and the receiver-accepted section check; no pin moved, no row CURRENT; receiver review pinned (ACCEPT SCOPED, 9/11/2, OSC-N2); statuses 31/2/52/6, authentication 60/6 as expected by the receiver', a32)",
        "    g('A32 three current owner versions BYTE_VERIFIED (r19 evidence kept); no pin moved, no row CURRENT; receiver reviews pinned (owner-section r1, r19, r2 with the r20 authorization) and the transfer / r2 archives pinned intact; r2 tooling notes and the §5 -> §6 locator correction in the r20 watch item; statuses 31/2/52/6, authentication 62/4/24/1 as expected by the receiver', a32)")
# ---- controls
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]; ents[-1] = ents[-1][:-1]
ents = [e.rstrip(',') for e in ents]
RET = ("('A23 DYAD6413 authentication upgraded without the file'", "('A29 RRF082 authentication upgraded without the file'", "('A28 r18 matrix rows re-used'", "('A28 a Dyadic row authentication changed'", "('A28 catalog checked date left at r17'", "('A28 r19 watch item dropped'")
keep = [e for e in ents if not any(e.startswith(r) for r in RET)]
M19 = "json.loads(B.rd('inputs/phaseA_r19_outputs/SOURCE_CURRENCY_MATRIX.json'))"
NEWC = f'''('A23 DYAD6413 row left in the r19 state (RECEIVER_BYTE_VERIFIED, PRINTED_ONLY)', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(authentication='RECEIVER_BYTE_VERIFIED', bytes_status='PRINTED_ONLY', available_file=None, inspection_extent='REFERENCE_ONLY')))
('A23 DYAD6413 promoted to UNCHANGED_VERIFIED/VERIFIED on the held file', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='UNCHANGED_VERIFIED', status='VERIFIED')))
('A23 DYAD6413 promoted to CURRENT', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='CURRENT')))
('A23 DYAD6413 pin silently moved to v6.4.19', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(cited_version='6.4.19', cited_sha256='40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9')))
('A23 DYAD6413 reason without the non-equality limit', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency_reason=next(x for x in d['rows'] if x['key'] == 'DYAD6413')['currency_reason'].replace('whole-row old-to-current equality is not asserted', 'whole-row equality holds', 1))))
('A23 DYAD6413 reason reports OPEN 20 / §6.17 identical', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency_reason=next(x for x in d['rows'] if x['key'] == 'DYAD6413')['currency_reason'].replace('OPEN 20 and §6.17 CHANGED', 'OPEN 20 and §6.17 IDENTICAL', 1))))
('A23 DYAD6413 receiver 19 Oct report relabelled as preparer run', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(receiver_note='Phase A r20: file held and hashed here (BYTE_VERIFIED_HERE).')))
('A23 DYAD6413 sync warning link dropped', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').pop('sync_warning')))
('A28 r19 matrix rows re-used', 27, mut(C, lambda d: d.update(rows={M19}['rows'])))
('A28 a third row given the two-row byte-availability change', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(bytes_status='BYTE_VERIFIED_MATCH', authentication='BYTE_VERIFIED_HERE')))
('A28 a non-owner row changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(currency_reason='edited')))
('A28 DYAD6413 line range changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(lines=[1, 2])))
('A28 DYAD6413 package-presence flag flipped (old RER package said to contain the file)', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(path_in_r4_13_package=True)))
('A28 catalog checked date left at r19', 27, mut(C, lambda d: d['owner_catalog'].update(checked='2026-10-21 (Phase A r19, preparer)')))
('A28 r20 watch item dropped', 27, mut(C, lambda d: d['watch_items'].pop()))
('A28 missing-bytes list still names DYAD6413', 27, mut(C, lambda d: d['bytes_not_available_to_preparer'].append('DYAD6413')))
('A28 missing-bytes list drops a still-missing key (premature gap closure)', 27, mut(C, lambda d: d['bytes_not_available_to_preparer'].remove('RRF08_ADOPTED')))
('A28 blocked register byte-availability gap keeps RRF082', 27, mut(K, lambda d: d['byte_availability_gap']['keys'].append('RRF082')))
('A28 blocked register byte-availability note rewritten', 27, mut(K, lambda d: d['byte_availability_gap'].update(note='all bytes available')))
('A28 an ER-2B blocked record changed', 27, mut(K, lambda d: d['blocked'].pop()))
('A28 owner_current Dyadic evidence changed', 27, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='OWNER_REPORTED')))
('A28 G9/1 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 1).update(gap_reference_review='CLOSED')))
('A28 SYNC disposition dropped', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition')))
('A29 RRF082 row left in the r19 state (RECEIVER_BYTE_VERIFIED, PRINTED_ONLY)', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(authentication='RECEIVER_BYTE_VERIFIED', bytes_status='PRINTED_ONLY', available_file=None, inspection_extent='REFERENCE_ONLY')))
('A29 RRF082 promoted to UNCHANGED_VERIFIED/VERIFIED on the held file', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency='UNCHANGED_VERIFIED', status='VERIFIED')))
('A29 RRF082 pin silently moved to v0.8.4', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(cited_version='0.8.4', cited_sha256='2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce')))
('A29 RRF082 reason without the OSC-N2 replay', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency_reason=next(x for x in d['rows'] if x['key'] == 'RRF082')['currency_reason'].replace('OSC-N2 reproduced here', 'OSC-N2 not replayed', 1))))
('A29 RRF082 reason without the non-equality limit', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency_reason=next(x for x in d['rows'] if x['key'] == 'RRF082')['currency_reason'].replace('whole-row old-to-current equality is not asserted', 'whole-row equality holds', 1))))
('A29 RRF082 receiver 19 Oct report relabelled as preparer run', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(receiver_note='Phase A r20: file held and hashed here (BYTE_VERIFIED_HERE).')))
('A29 a v0.8 row given the v0.8.2 file as its verification', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(authentication='BYTE_VERIFIED_HERE', bytes_status='BYTE_VERIFIED_MATCH', available_file='sources_available/RRF082__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md')))
('A32 DYAD6413 left RECEIVER_BYTE_VERIFIED (count 61/5)', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(authentication='RECEIVER_BYTE_VERIFIED')))
('A32 a printed-only row counted as byte-verified (count 63)', 31, mut(C, lambda d: next(x for x in d['rows'] if x['authentication'] == 'HASH_PRINTED_UNVERIFIED').update(authentication='BYTE_VERIFIED_HERE')))
('A32 r2 tooling notes dropped from the watch item', 31, mut(C, lambda d: d['watch_items'].__setitem__(-1, d['watch_items'][-1].replace('OSC2-T1', 'T1', 1))))
('A32 locator correction dropped from the watch item', 31, mut(C, lambda d: d['watch_items'].__setitem__(-1, d['watch_items'][-1].replace('§6 of the owner-section receiving review (not §5)', '§5 of the owner-section receiving review', 1))))'''.split('\n')
t = t[:i] + '    T = [' + (',\n         ').join(keep + NEWC) + ']' + t[j:]
# file / input controls
t = one(t, "    for fn, gi, lab in (('DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md', 22, 'A23 v6.4.19'), ('RECOG0322__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md', 25, 'A26 v0.3.22'), ('RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md', 28, 'A29 v0.8.4')):",
        "    for fn, gi, lab in (('DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md', 22, 'A23 v6.4.19'), ('RECOG0322__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md', 25, 'A26 v0.3.22'), ('RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md', 28, 'A29 v0.8.4'),\n"
        "                        ('DYAD6413__RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md', 22, 'A23 v6.4.13'), ('RRF082__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md', 28, 'A29 v0.8.2')):")
t = one(t, "    sc19b = B.rd('inputs/owner_section_check_r1/compare_output.txt'); c19b = B.rd('inputs/source_custody_r19.json');",
        "    sc2b = B.rd('inputs/owner_section_check_r2/compare_output.txt'); c20b = B.rd('inputs/source_custody_r20.json'); rv2b = B.rd('inputs/receiving_review_owner_section_r2_20261021.md'); o19b = B.rd('inputs/phaseA_r19_outputs/check_phaseA_output_r19.txt'); ng2b = B.rd('inputs/owner_section_check_r2/negcontrol_output.txt')\n"
        "    xzb = B.rd('inputs/RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip'); szb = B.rd('inputs/OWNER_SECTION_CHECK_r2.zip')\n"
        "    for n, p, bb, gi in [('A23 section check r2 reports §6.17 IDENTICAL on the v6.4.13 -> v6.4.19 leg', 'inputs/owner_section_check_r2/compare_output.txt', sc2b.replace(b'v6.4.19 lines 983-1010     CHANGED  ', b'v6.4.19 lines 983-1010     IDENTICAL', 1), 22),\n"
        "                         ('A23 section check r2 reports OPEN 19 CHANGED on the v6.4.13 -> v6.4.18 leg', 'inputs/owner_section_check_r2/compare_output.txt', sc2b.replace(b'v6.4.18 lines 238-244      IDENTICAL', b'v6.4.18 lines 238-244      CHANGED  ', 1), 22),\n"
        "                         ('A29 section check r2 reports §4.2 IDENTICAL on the v0.8.2 -> v0.8.3 leg', 'inputs/owner_section_check_r2/compare_output.txt', sc2b.replace(b'v0.8.3 lines 318-336      CHANGED', b'v0.8.3 lines 318-336      IDENTICAL', 1), 28),\n"
        "                         ('A29 section check r2 reports §2.3 CHANGED on the v0.8.2 -> v0.8.4 leg', 'inputs/owner_section_check_r2/compare_output.txt', sc2b.replace(b'v0.8.4 lines 149-165      IDENTICAL', b'v0.8.4 lines 149-165      CHANGED  ', 1), 28),\n"
        "                         ('A29 r2 negative-control log altered', 'inputs/owner_section_check_r2/negcontrol_output.txt', ng2b.replace(b'4/4 caught', b'3/4 caught (BAD)', 1), 28),\n"
        "                         ('A23 custody r20 hash altered', 'inputs/source_custody_r20.json', c20b.replace(b'5958f7fe8a3e0ec9', b'0000000000000000', 1), 22),\n"
        "                         ('A23 custody r20 boundary relabelled REAUTHENTICATED', 'inputs/source_custody_r20.json', c20b.replace(b'NOT_REAUTHENTICATED', b'REAUTHENTICATED'), 22),\n"
        "                         ('A23 custody r20 receiver archive hash altered', 'inputs/source_custody_r20.json', c20b.replace(b'9bfeca625d43cffc', b'0000000000000000'), 22),\n"
        "                         ('A32 r2 receiver review altered (authorization sentence removed)', 'inputs/receiving_review_owner_section_r2_20261021.md', rv2b.replace(b'Phase A r20 preparation is authorized', b'Phase A r20 preparation is pending'), 31),\n"
        "                         ('A32 transfer archive altered', 'inputs/RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip', xzb[:-1] + bytes([xzb[-1] ^ 1]), 31),\n"
        "                         ('A32 r2 archive altered', 'inputs/OWNER_SECTION_CHECK_r2.zip', szb[:-1] + bytes([szb[-1] ^ 1]), 31),\n"
        "                         ('A24 r19 checker record altered', 'inputs/phaseA_r19_outputs/check_phaseA_output_r19.txt', o19b.replace(b'34/34 gates PASS', b'33/34 gates PASS', 1), 23)]:\n"
        "        assert bb != B.rd(p), n\n"
        "        _, rr = gates(outs, verbose=False, inp={p: bb}); good = not rr[gi]; allf &= good\n"
        "        print(f'  input control {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    sc19b = B.rd('inputs/owner_section_check_r1/compare_output.txt'); c19b = B.rd('inputs/source_custody_r19.json');")
a = '"""Phase A r19 gates on RER v0.2 DRAFT r4.13 (r19: catalog step; source unchanged).'; assert t.count(a) == 1
t = t.replace(a, '"""Phase A r20 gates on RER v0.2 DRAFT r4.13 (r20: two-row source-availability step; source and catalog pins unchanged).\n'
  'r20: A23/A29 (extended): the DYAD6413 and RRF082 rows are BYTE_VERIFIED_HERE / BYTE_VERIFIED_MATCH only with the real file in sources_available, the\n'
  'custody r20 entry (receiver chain kept as declared, NOT_REAUTHENTICATED boundary) and the section check r2 output (OPEN 19/§6.15/§6.16 and §2.3 identical;\n'
  'OPEN 20/§6.17 and §2.4b/§4.2 changed; 4/4 negative controls); currency RECHECK_IN_PHASE_B and status HISTORICAL unchanged; the 19 Oct receiver recovery\n'
  'stays as dated history. A24 adds the r19 checker record; A25 requires registry identity with r19 apart from the schema; A28 compares with the r19 matrix:\n'
  'exactly two rows differ, only in byte-availability fields, and the derived missing-bytes lists lose exactly those two keys; A32 pins the transfer and r2\n'
  'archives intact and the receiver reviews, and checks 31/2/52/6 and 62/4/24/1. The r19 A23/A29 "upgraded without the file" controls and A28 r18-based\n'
  'controls are retired (results in the pinned r19 record). Nested historical manifests are pinned inside their intact archives (receiver note OSC2-T2).\n'
  'Earlier wording, kept as history: Phase A r19 gates on RER v0.2 DRAFT r4.13 (r19: catalog step; source unchanged).', 1)
open(C, 'w', encoding='utf-8').write(t)
p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/source_custody_r20.json', 'inputs/receiving_review_owner_section_r2_20261021.md', 'inputs/receiving_review_phaseA_r19_20261021.md', 'inputs/RER_HISTORICAL_SOURCE_TRANSFER_20261021.zip', 'inputs/OWNER_SECTION_CHECK_r2.zip'] + ['inputs/owner_section_check_r2/' + x for x in sorted(os.listdir(scd))] + ['inputs/phaseA_r19_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs'], f; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched r20')
