#!/usr/bin/env python3
"""Independent SymPy checks: ER2B chirality identification, cyclic slot constraint.

Not a rerun of the 6-step jet or q->chi derivation. Checks symbolic bridge and
basis facts conditional on the previously reported coefficients and incidence.
"""
import json
from pathlib import Path
import sympy as s
I=s.I; R=s.Rational; rt=s.sqrt(3)
checks=[]
def assert_eq(name, expr, target=0):
    rem=s.simplify(s.expand(expr-target))
    ok=rem==0
    checks.append({'name':name,'pass':bool(ok),'residual':str(rem)})
    if not ok: raise AssertionError(name+': '+str(rem))
def W(r,e):return r-e/2+I*rt*e/2
sr,se,cr,ce=s.symbols('sr se cr ce',real=True)
w_s=W(sr,se); w_c=W(cr,ce)
w1=w_s; w2=-w_s/2+w_c; w3=-w1-w2
S=s.simplify(s.im(s.expand_complex(w1*s.conjugate(w2))))
omegaG=rt/2*(se*cr-sr*ce)
omegaRaw=(se*cr-sr*ce)
omegaT=-rt*omegaRaw
assert_eq('S equals RER Omega_G',S,omegaG)
assert_eq('Triadic Omega_T = -2 Omega_G',omegaT,-2*omegaG)
S23=s.im(s.expand_complex(w2*s.conjugate(w3)))
S31=s.im(s.expand_complex(w3*s.conjugate(w1)))
assert_eq('S invariant under 1->2->3',S23,S)
assert_eq('S invariant under 1->3->1',S31,S)
ccwarea=s.im(s.expand_complex(s.conjugate(w1)*w2))/2
assert_eq('usual CCW triangle area equals -S/2',ccwarea,-S/2)

x,y,X,Y=s.symbols('x y X Y') # formal complex edges and conjugates
z=-x-y; Z=-X-Y
B1=lambda a,b,A,B:a*a*A-b*b*B
B2=lambda a,b,A,B:a*a*B-b*b*A
B3=lambda a,b,A,B:a*b*(A-B)
C=lambda a,b,A,B:(a+b)*(a*B-b*A)
assert_eq('chi basis C=B2-B3', C(x,y,X,Y),B2(x,y,X,Y)-B3(x,y,X,Y))
triplets=[(x,y,X,Y),(y,z,Y,Z),(z,x,Z,X)]
for name, fn in [('B1',B1),('B2',B2),('B3',B3),('C',C)]:
 cyc=s.expand(sum(fn(*v) for v in triplets))
 checks.append({'name':f'cyclic sum {name}','result':str(s.factor(cyc)),'zero':cyc==0})
assert_eq('B2 and B3 cyclic defects coincide',sum(B2(*v)-B3(*v) for v in triplets))
assert_eq('B1 cyclic consistency',sum(B1(*v) for v in triplets))
assert_eq('C cyclic consistency',sum(C(*v) for v in triplets))
assert_eq('B2 cyclic defect nonzero at formal witness',s.expand(sum(B2(*v) for v in triplets)).subs({x:1,y:0,X:1,Y:0}),2)

# reconstruct 8 mixed partials of complex C and compare with U,V table.
a1,a2,b1,b2,U,V=s.symbols('a1 a2 b1 b2 U V',real=True)
wa=W(a1,a2); wb=W(b1,b2); waw=s.conjugate(wa); wbw=s.conjugate(wb)
chi=V/2+I/rt*(V/2-U)
Ccomplex=chi*C(wa,wb,waw,wbw)
# inverse W(r,e)=r-e/2+i sqrt3 e/2
def w_to_components(expr):
    rr=s.re(s.expand_complex(expr))
    ii=s.im(s.expand_complex(expr))
    return (s.simplify(rr+ii/rt),s.simplify(2*ii/rt))
out_r,out_e=w_to_components(Ccomplex)
expected={
 (a1,b1):(U*(a2-b2),V*(a2-b2)),
 (a1,b2):(-U*(2*a1+b1)+V*(a2+2*b2),-U*(a2+2*b2)+V*(-2*a1+a2-b1+2*b2)),
 (a2,b1):(U*(a1+2*b1)-V*(2*a2+b2),U*(2*a2+b2)+V*(a1-2*a2+2*b1-b2)),
 (a2,b2):(V*(a1-b1),(V-U)*(a1-b1))
}
for (aa,bb),(targetr,targete) in expected.items():
    assert_eq(f'8-table derivative ({aa},{bb}) rho',s.diff(out_r,aa,bb),targetr)
    assert_eq(f'8-table derivative ({aa},{bb}) eta',s.diff(out_e,aa,bb),targete)
# old q->chi algebra
ur,ui,vr,vi,tr,ti=s.symbols('ur ui vr vi tr ti',real=True)
u=ur+I*ui;v=vr+I*vi;t=tr+I*ti
Zuv=u*v
Uv=-12*s.re(s.expand_complex(Zuv))+4*rt*s.im(s.expand_complex(Zuv))-2*(vr**2+vi**2)-4*(tr**2+ti**2)
Vv=-12*s.re(s.expand_complex(Zuv))-4*rt*s.im(s.expand_complex(Zuv))+2*(vr**2+vi**2)-8*(tr**2+ti**2)
chi_formula=(-6+2*I*rt)*u*v+(1+I*rt)*(vr**2+vi**2)-4*(tr**2+ti**2)
assert_eq('chi from U,V matches closed quadratic form',Vv/2+I/rt*(Vv/2-Uv),chi_formula)
assert_eq('U=V=0 implies chi=0 and conversely linear invertibility',s.expand(chi.subs({U:s.re(chi_formula),V:2*s.re(chi_formula)})) if False else V-2*s.re(s.expand_complex(chi)),0)
# generic no double-count of coefficients
assert_eq('chi Genesis U=1/3 V=2/3',chi.subs({U:R(1,3),V:R(2,3)}),R(1,3))

# Supplemental exact one-step non-invariance witness for S=0 in Genesis model.
vv=s.symbols('vv',real=True)
f1,f2,f3=s.exp(vv)-1,s.exp(vv/2)-1,s.exp(-3*vv/2)-1
os=rt*vv/2*((2*f1-f2-f3)/3-(f2-f3)/2)
assert_eq('collinear Genesis one-step orientation exact',os,rt*vv/12*(4*s.exp(vv)-5*s.exp(vv/2)+s.exp(-3*vv/2)))
assert_eq('collinear orientation leading cubic',s.series(os,vv,0,5).removeO(),5*rt*vv**3/24)

out=Path('/mnt/data/ER2B_CHIRALITY_BRIDGE_v1/check_results.json')
out.write_text(json.dumps({'scope':'Orientation bridge, cyclic slot basis, table agreement. Does not rerun sixfold primitive jet.', 'passed':sum(c.get('pass',True) for c in checks),'checks':checks},indent=2))
print(f'{len(checks)} checks OK; S=Omega_G, Omega_T=-2S')
print('cyclic B2 sum:',s.factor(sum(B2(*v) for v in triplets)))
print('cyclic B3 sum:',s.factor(sum(B3(*v) for v in triplets)))

