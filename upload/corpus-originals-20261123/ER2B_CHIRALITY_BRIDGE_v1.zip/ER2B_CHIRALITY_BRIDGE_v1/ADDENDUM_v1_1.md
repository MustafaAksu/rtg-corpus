## 7. [ALG] Working addendum v1.1 — chirality, cyclic consistency and the coefficient zero set

**Status:** noncanonical supplement to the reviewed ER-2B finite-algebra note. No owner/adoption status changes. The original sixfold return jet and its U,V formulas are imported, not re-extracted by this addendum. This section uses the signed-Gram normalization of RER v0.1 and the Genesis conditional model.

### 7.1. Area/chirality identification and its units

Let W(rho,eta)=rho−eta/2+i sqrt(3) eta/2. Genesis incidence gives w1=W(s), w2=−w1/2+W(c), w3=−w1−w2. Hence

\[
\boxed{S:=\Im(w_1\bar w_2)
=\frac{\sqrt3}{2}(s_\eta c_\rho-s_\rho c_\eta)=\Omega_G.}
\]

The cyclic identities Im(w1 conjugate(w2))=Im(w2 conjugate(w3))=Im(w3 conjugate(w1)) follow from closure. With the usual positive-CCW polygon orientation on vertices (0,w1,w1+w2), S is **minus twice** signed area, not plus twice. Same input planar component values in the Triadic v1.6 lifted-producer convention give B_T=2B_G and **Omega_T=−2Omega_G=−2S**. That last equality is a normalization bridge, not transport of physical dynamical or birth laws.

### 7.2. Why exactly two complex resonant cubic coefficients survive

Write x=w1, y=w2, z=−x−y. At homogeneous degree three and phase weight +1, an edge-slot-exchange antisymmetric output difference has complex basis

\[
\begin{aligned}
B_1(x,y)&=x^2\bar x-y^2\bar y,\\
B_2(x,y)&=x^2\bar y-y^2\bar x,\\
B_3(x,y)&=xy(\bar x-\bar y).
\end{aligned}
\]

But any *single coherent three-edge output* requires D12+D23+D31=0. Under x+y+z=0,

\[
\sum_{\rm cyc}B_1=0,\qquad
\sum_{\rm cyc}B_2=\sum_{\rm cyc}B_3\not\equiv0.
\]

Therefore D=nu B1+beta B2+gamma B3 must have beta+gamma=0. Only **two** complex coefficients survive:

\[
\boxed{D=\nu B_1+\chi(B_2-B_3),\quad
B_2-B_3=(x+y)(x\bar y-y\bar x).}
\]

This is the missing proof in the previous interpretive reply. It uses **edge-slot swap antisymmetry and cyclic consistency**, NOT physical oriented-node S3 equivariance; the primitive DYAD even part explicitly breaks the latter.

### 7.3. Nonseparable cubic part is third edge times signed-Gram chirality

Since x+y=−w3 and x bar(y)−y bar(x)=2iS,

\[
\boxed{(G_{3,1}-G_{3,2})_{\rm nonsep}
=-2i\chi\,w_3\,\Omega_G.}
\]

One compatible zero-sum edge representative is

\[
G^{\rm nonsep}_{3,e}=(2i\chi/3)(w_{e+1}-w_{e-1})\Omega_G.
\]

**Pointwise vanishing:** for Omega_G=0 the nonseparable *cubic term* vanishes even if chi is nonzero. This is not invariance of the collinear locus under the full map and not an all-order exact-separability theorem. The signed area is a function of the existing three edges, not an additional independent physical degree of freedom.

### 7.4. Coefficient, scaling, and zero-locus dimension

The prior U,V formulas combine in the fixed eigenframe as

\[
\boxed{\chi={V\over2}+{i\over\sqrt3}({V\over2}-U)
=(-6+2i\sqrt3)uv+(1+i\sqrt3)|v|^2-4|t|^2.}
\]

Conversely V=2 Re chi, U=Re chi−sqrt(3) Im chi. The complete eight-entry U,V mixed-derivative table is exactly recovered from chi(B2−B3) with the output transformed back to (rho,eta).

The zero locus has defining quadrics f1=2 Re(uv)+|t|², f2=2sqrt(3) Im(uv)−|v|²+|t|². If v != 0,

\[
\det\partial(f_1,f_2)/\partial(\Re u,\Im u)=4\sqrt3|v|^2>0.
\]

If v=0 and f1=f2=0, then t=0; for u != 0 the corresponding v-Jacobian has rank two. Thus the zero locus is a smooth **real four-dimensional** subset of real coefficient space away from the origin; the origin is singular. This is not a physical-moduli dimension claim before quotienting by admitted transformations.

### 7.5. Scope and next move

The current check independently verifies the RER/Triadic normalization, cyclic-slot reduction, eight mixed derivatives of chi(B2−B3), and the chi expression, but does **not** regenerate the Genesis sixfold return from T or audit physical primitive resonance. The next useful question is whether this chi Omega_G term has an admissible dynamical interpretation for another **source-defined coupled map** on the same clock/carrier, not merely its formal existence.

### 7.6. [ALG] The collinear locus is not invariant in the named Genesis primitive map

Choose s=(t,0), c=(t,0). The three edge inputs (t,0), (t/2,0), (−3t/2,0) have S=Omega_G=0. Apply the exact Genesis one-step model N=P_C T_e^{×3} with T_e(rho,0)=(rho,e^rho−1). Reconstruct the updated modal pair from the projected edges. Its signed Gram orientation is

\[
\boxed{\Omega_G^+=\frac{\sqrt3\,t}{12}
\left(4e^t-5e^{t/2}+e^{-3t/2}\right)
=\frac{5\sqrt3}{24}t^3+O(t^5).}
\]

Thus for sufficiently small nonzero t the originally collinear triple becomes noncollinear after **one primitive coupled step**. The algebraic factor Omega_G in the six-step cubic *nonseparable difference* vanishes on the initial collinear state; it is not an invariant-manifold statement about the whole analytic dynamics. This is conditional on the specified Genesis primitive edge projection, not a physical triadic evolution theorem.
