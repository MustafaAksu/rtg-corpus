#!/usr/bin/env python3
"""High precision sanity check with untruncated T; NOT an analytic certificate."""
import json
from pathlib import Path
import mpmath as mp
mp.mp.dps=95
m=mp.mpf
root=Path(__file__).resolve().parents[1]
def add(x,y):return (x[0]+y[0],x[1]+y[1])
def mul(x,t):return (t*x[0],t*x[1])
def T(x):
 r,e=x
 return (r-mp.sin(e),e+mp.expm1(r)-mp.sin(e))
def step(s,c):
 ed=[s,add(mul(s,-m(1)/2),c),add(mul(s,-m(1)/2),mul(c,-1))]
 out=list(map(T,ed))
 avg=mul(add(add(out[0],out[1]),out[2]),m(1)/3)
 out=[add(z,mul(avg,-1)) for z in out]
 return (out[0],mul(add(out[1],mul(out[2],-1)),m(1)/2))
def W(x):return x[0]-x[1]/2+1j*mp.sqrt(3)*x[1]/2
def N_and_S(s,c):
 z,v=W(s),W(c);ed=[z,-z/2+v,-z/2-v]
 return sum(abs(ww)**2 for ww in ed),mp.im(z*mp.conj(v))
rows=[]
for kind in ('child-free','noncollinear'):
 for td in (20,40,80):
  t=m(1)/td;s=(t,m(0));c=(m(0),m(0)) if kind=='child-free' else (m(0),t)
  n0,o0=N_and_S(s,c)
  for _ in range(6):s,c=step(s,c)
  n1,o1=N_and_S(s,c)
  pred=n0*n0/6+2*o0*o0
  rec={'model':kind,'t':'1/'+str(td),'scaled_N_change':mp.nstr((n1-n0)/t**4,24),
       'predicted_scaled_N_change':mp.nstr(pred/t**4,24),
       'scaled_S_change':mp.nstr((o1-o0)/(n0*o0),24) if o0 else 'not applicable',
       'predicted_scaled_S_change':'1/3' if o0 else 'not applicable'}
  rows.append(rec)
(root/'outputs/numeric_exact_map.json').write_text(json.dumps({'precision_decimal_places':95,'not_a_certificate':True,'rows':rows},indent=2)+'\n')
for row in rows:print(row)
