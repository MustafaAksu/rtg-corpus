#!/usr/bin/env python3
"""Exact check of genus-3 edge cubic response in fixed Genesis modal chart.
Loads the *previously generated* audited cubic polynomial JSON, not a fresh
independent six-step producer. Derives each source contribution symbolically.
"""
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import sympy as s
R=s.Rational
x,y,u,v=s.symbols('x y u v',real=True)
nr,ni,cr,ci=s.symbols('nr ni cr ci',real=True)
nu=nr+s.I*ni;chi=cr+s.I*ci
z=x+s.I*y;c=u+s.I*v
w=[z,-z/2+c,-z/2-c]; wc=[s.conjugate(zz) for zz in w]
q=[s.expand(ww*wwc) for ww,wwc in zip(w,wc)]
N=s.expand(sum(q)); S=s.expand(s.im(z*s.conjugate(c)))
Qs=s.expand(z*s.conjugate(z)); Qc=s.expand(c*s.conjugate(c)); I=s.expand(s.re(z*s.conjugate(c)))
check={}
def eq(name,lhs,rhs):
 delta=s.simplify(s.expand(lhs-rhs)); check[name]=(delta==0)
 if delta!=0:
  print('FAIL',name,'residual',delta);sys.exit(1)
 print('PASS',name)
mean=s.expand(sum(w[j]*q[j] for j in range(3))/3)
sep=[s.expand(nu*(w[i]*q[i]-mean)) for i in range(3)]
non=[s.expand(2*s.I*chi*S*(w[(i+1)%3]-w[(i-1)%3])/3) for i in range(3)]
def dreal(P,dw):
 if P=='N': return s.expand(2*s.re(sum(wc[i]*dw[i] for i in range(3))))
 if P=='S': return s.expand(s.im(dw[0]*s.conjugate(w[1])+w[0]*s.conjugate(dw[1])))
 dz=dw[0];dc=(dw[1]-dw[2])/2
 if P=='Qs':return s.expand(2*s.re(s.conjugate(z)*dz))
 if P=='Qc':return s.expand(2*s.re(s.conjugate(c)*dc))
 if P=='I':return s.expand(s.re(dz*s.conjugate(c)+z*s.conjugate(dc)))
eq('incidence N = 3/2 Qs + 2 Qc',N,R(3,2)*Qs+2*Qc)
eq('chirality Gram', Qs*Qc,I**2+S**2)
eq('edge quartic norm identity',sum(qi**2 for qi in q),N**2/2-2*S**2)
eq('triad upper area bound algebra',N**2-12*S**2,(R(3,2)*Qs-2*Qc)**2+12*I**2) # verify algebraic expression
# Expectations for nonseparable source
for key,expected in {
 'Qs':R(8,3)*(cr*S**2-ci*I*S),
 'Qc':2*cr*S**2+2*ci*I*S,
 'I':ci*(Qs-R(4,3)*Qc)*S,
 'S':R(2,3)*cr*N*S,
 'N':8*cr*S**2
}.items():eq('nonsep delta '+key,dreal(key,non),expected)
# Expectations for separable source
for key,expected in {
 'Qs':nr*(R(3,2)*Qs**2+R(4,3)*Qs*Qc+R(2,3)*(I**2-S**2))+R(4,3)*ni*I*S,
 'Qc':nr*(Qs*Qc+2*Qc**2+(I**2-S**2)/2)-ni*I*S,
 'I':nr*N*I+ni*(-Qs/2+R(2,3)*Qc)*S,
 'S':R(2,3)*nr*N*S,
 'N':2*nr*sum(qi**2 for qi in q)
}.items():eq('sep delta '+key,dreal(key,sep),expected)
# extract source values with a nondegenerate coefficient fit
source=ROOT/'sources/genesis_sixjet_obstruction_audit.json'
j=json.loads(source.read_text())
a1,a2,b1,b2=s.symbols('a1 a2 b1 b2',real=True)
p=[s.sympify(t.replace('^','**'),locals={'a1':a1,'a2':a2,'b1':b1,'b2':b2}) for t in j['full']['G3']]
W=lambda aa,ee:s.expand(aa-ee/2+s.I*s.sqrt(3)*ee/2)
za=W(a1,a2); zb=W(b1,b2)
D=W(p[0]-p[2],p[1]-p[3]); B1=s.expand(za**2*s.conjugate(za)-zb**2*s.conjugate(zb)); area=s.expand(s.im(za*s.conjugate(zb)))
Bchi=-2*s.I*(-za-zb)*area
nu0=s.simplify(D.subs({a1:1,a2:0,b1:0,b2:0}));chi0=R(1,3)
eq('nu from selected ray',nu0,R(1,6)-s.I*s.sqrt(3)/3)
eq('complete full source G3 difference',D,nu0*B1+chi0*Bchi)
# source cubic tensor exactly equals the edge representative, not only differences
params={nr:s.re(nu0),ni:s.im(nu0),cr:s.re(chi0),ci:s.im(chi0)}
full=[s.expand(sep[k]+non[k]).subs(params) for k in range(3)]
for k in (0,1):
 original=W(p[2*k],p[2*k+1])
 predicted=full[k].subs({x:a1-a2/2,u:b1-b2/2+(a1-a2/2)/2,y:s.sqrt(3)*a2/2,v:s.sqrt(3)*b2/2+s.sqrt(3)*a2/4})
 eq(f'edge {k+1} complete cubic source equality',original,predicted)
# total response in Gram variables for actual Genesis coefficients
for key,expected in {
 'Qs':Qs**2/4+Qs*Qc/3+R(2,3)*S**2-R(4,9)*s.sqrt(3)*I*S,
 'Qc':Qs*Qc/4+Qc**2/3+S**2/2+s.sqrt(3)*I*S/3,
 'I':N*I/6+(s.sqrt(3)*Qs/6-2*s.sqrt(3)*Qc/9)*S,
 'S':N*S/3,
 'N':N**2/6+2*S**2
}.items():eq('Genesis total delta '+key,s.expand(dreal(key,[sep[k]+non[k] for k in range(3)])).subs(params),expected)
# Compatibility of the four observable increments with the Gram constraint.
coef=lambda key: s.expand(dreal(key,[sep[k]+non[k] for k in range(3)])).subs(params)
cons=s.expand(Qc*coef('Qs')+Qs*coef('Qc')-2*I*coef('I')-2*S*coef('S'))
eq('quartic Gram-constraint consistency',cons,0)
info={'checks':len(check),'all_pass':all(check.values()),'nu':[str(s.re(nu0)),str(s.im(nu0))],'chi':[str(s.re(chi0)),str(s.im(chi0))],'scope':'cubic jet of Genesis conditional six-step map, through quartic observable increments; no physical mechanism selected; imported prior audited G3 source not independently reproduced'}
print('TOTAL',len(check),'PASS');print(json.dumps(info,indent=2))
(ROOT/'outputs/exact_checks.json').write_text(json.dumps(info,indent=2)+'\n')
