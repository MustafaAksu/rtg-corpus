# ER-2B cubic triad observable response v1

Read `notes/ER2B_GENESIS_OBSERVABLE_RESPONSE.md`.

Run from anywhere (Python 3, SymPy, mpmath):

```
python scripts/check_observable_response.py
python scripts/numeric_check_exact_map.py
```

The exact checks use the included `sources/genesis_sixjet_obstruction_audit.json`, an imported earlier audited coefficient record, not a newly recomputed six-step producer. The numerical check independently executes the untruncated primitive map and reprojection.

No adopted owner scientific files were changed. This is a noncanonical conditional-model derivation.
