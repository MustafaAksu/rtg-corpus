"""Receiver's read-only identity/delta audit; imports no preparer modules.
Requires the extracted batch and nested packages at work/ and original r20/r4.13 ZIPs in /mnt/data.
This is not a mathematical certificate or adoption action.
"""
from pathlib import Path
import hashlib,json,re,zipfile,collections
W=Path(__file__).parent; D=Path('/mnt/data');B=W/'work/RER_PHASE_B_BATCH';R=W/'work/rer_r4_14/RER_r4_14';P=W/'work/phaseA_r21/RER_phaseA_r21'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
result={};checks={}
def test(k,c):
 checks[k]=bool(c)
 if not c:raise AssertionError(k)
def member(z,rel):
 a=[n for n in z.namelist() if n.endswith('/'+rel) or n==rel];test('unique_zip_member:'+rel,len(a)==1);return z.read(a[0])
def manifest(root):
 rows=[]
 for line in (root/'SHA256SUMS.txt').read_text().splitlines():
  h,n=re.match(r'^([0-9a-f]{64})\s+\*?(.*)$',line).groups();rows.append(n);test('manifest:'+str(root.name)+':'+n,sha((root/n).read_bytes())==h)
 files={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 test('manifest_complete:'+root.name,files-set(rows)=={'SHA256SUMS.txt'})
 test('no_pycache:'+root.name,all('__pycache__' not in n and not n.endswith('.pyc') for n in files))
 return len(rows)
result['manifest_counts']={x.name:manifest(x) for x in [B,R,P]}
test('batch_identity',sha((D/'RER_PHASE_B_BATCH_20261021.zip').read_bytes())=='08c132773bd2ec73bd8fac2445741bc20d11e7f81aee50d1f680c0eb8b4c5786')
base=load(P/'baseline_r20.json') if (P/'baseline_r20.json').exists() else load(P/'inputs/baseline_r20.json')
z=zipfile.ZipFile(D/'RER_phaseA_r20.zip')
test('r20_baseline_zip_identity',sha((D/'RER_phaseA_r20.zip').read_bytes())==base['package_zip_sha256'])
for n,h in base['members_at_patch_time'].items():test('baseline_member:'+n,sha(member(z,n))==h)
for f in (P/'inputs/phaseA_r20_outputs').iterdir():
 rel='check_phaseA_output.txt' if f.name=='check_phaseA_output_r20.txt' else 'out/'+f.name
 test('history_identical:'+f.name,f.read_bytes()==member(z,rel))
old=member(z,'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_13.md');new=(R/'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_14.md').read_bytes()
with zipfile.ZipFile(D/'RER_r4_13.zip') as z13:test('original_r4_13_same_as_baseline',member(z13,'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_13.md')==old)
test('new_copies_equal',new==(B/'rer_r4_14/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_14.md').read_bytes()==(P/'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_14.md').read_bytes())
test('new_source_identity',sha(new)=='92f983e64bd54e208898954c45c4ac6482928b794d08b3d1660f0db9d00ff044')
edits=load(R/'r4_13_to_r4_14_edits.json');s=old.decode()
for e in edits:test('edit_exact_once:'+e['id'],s.count(e['old'])==1);s=s.replace(e['old'],e['new'],1)
test('independent_rebuild',s.encode()==new)
for e in reversed(edits):test('reverse_exact_once:'+e['id'],s.count(e['new'])==1);s=s.replace(e['new'],e['old'],1)
test('independent_reverse',s.encode()==old)
# Plain heading segmentation, independent of the delivered parser.
def spans(b):
 t=b.decode();ms=list(re.finditer(r'^### (RER-[A-Z0-9-]+)\b[^\n]*$',t,re.M));out={}
 for i,m in enumerate(ms):
  end=ms[i+1].start() if i+1<len(ms) else t.index('\n## 7.',m.start())
  out[m.group(1)]=t[m.start():end]
 return out
olds,news=spans(old),spans(new)
changed=[k for k in olds if olds[k]!=news[k]]
result['changed_heading_blocks']=changed
expected={'RER-G7','RER-G8','RER-G9','RER-G10','RER-ER2B-CARRIER','RER-RRF-CND01','RER-GEN-K3-MODAL'}
test('changed_blocks_scoped',set(changed)==expected)
for rid in [k for k in olds if k not in {'RER-G7','RER-G8','RER-G9','RER-G10'}]:
 for kind,pat in [('graded',r'^\[(?:THM|ALG|NUM)\].*$'),('open',r'^\[OPEN\].*$'),('contract',r'^\|.*$'),('grade',r'^\*\*Primary grade:.*$')]:
  test(kind+'_unchanged:'+rid,re.findall(pat,olds[rid],re.M)==re.findall(pat,news[rid],re.M))
# Matrix delta, using original baseline archive rather than the copied history.
om=json.loads(member(z,'out/SOURCE_CURRENCY_MATRIX.json'));nm=load(P/'out/SOURCE_CURRENCY_MATRIX.json')
key=lambda r:(r['record'],r['row_kind'],r['n'],r['key'])
o={key(r):r for r in om['rows']};n={key(r):r for r in nm['rows']}
test('matrix_91_to103',len(o)==91 and len(n)==103 and set(o)<=set(n))
added=[n[k] for k in sorted(set(n)-set(o))]
test('12_RRF084_rows',len(added)==12 and all(r['key']=='RRF084' for r in added))
rowd={}
for k,r in o.items():
 f={x for x in set(r)|set(n[k]) if r.get(x)!=n[k].get(x)};rowd['/'.join(map(str,k))]=sorted(f)
 test('old_row_only_allowed_additions:'+str(k),f<={'path_in_r4_14_package','preparer_audit'})
 test('old_row_fields_not_removed:'+str(k),set(r)<=set(n[k]))
 test('old_audit_state_preserved:'+str(k),r.get('gap_reference_review')==n[k].get('gap_reference_review'))
for r in added:
 test('new_source_fields:'+str(key(r)),r['cited_sha256']=='2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce' and r['status']=='VERIFIED' and r['authentication']=='BYTE_VERIFIED_HERE' and r['currency']=='CURRENT')
 a,b=r['lines'];bb=(P/r['available_file']).read_bytes();lines=bb.splitlines(keepends=True);slice_=b''.join(lines[a-1:b])
 test('new_ref_heading:'+str(key(r)),slice_.startswith(b'#') or a==1)
 test('new_ref_hash:'+str(key(r)),sha(bb)==r['cited_sha256'])
result['new_references']=[{x:r[x] for x in ['record','row_kind','n','key','lines']} for r in added]
result['old_matrix_differences']=rowd
for k in ['owner_current','scientific_sync_warnings']:
 test('matrix_global_preserved:'+k,om[k]==nm[k])
result['status_counts']=dict(collections.Counter(r['status'] for r in nm['rows']))
result['authentication_counts']=dict(collections.Counter(r['authentication'] for r in nm['rows']))
# Records + gap reference lists.
oreg=json.loads(member(z,'out/RER_REGISTRY_v0_2_r4_13_PHASEA.json'));nreg=load(P/'out/RER_REGISTRY_v0_2_r4_14_PHASEA.json')
orx={r['id']:r for r in oreg['records']};nrx={r['id']:r for r in nreg['records']};rd={}
for k,r in orx.items():
 f=[x for x in set(r)|set(nrx[k]) if r.get(x)!=nrx[k].get(x)]
 if f:rd[k]=sorted(f)
 test('adoption_pending:'+k,nrx[k]['adoption_status']=='PENDING')
 if k not in expected:test('untouched_record:'+k,r==nrx[k])
result['record_differences']=rd
for k in ['RER-ER2B-CARRIER','RER-RRF-CND01']:
 test('record_new_import_only:'+k,rd[k]==['imports'])
 test('record_old_imports_preserved:'+k,nrx[k]['imports'][:-1]==orx[k]['imports'])
k='RER-GEN-K3-MODAL';test('k3_only_receipt_fields',set(rd[k])=={'fields','prior_review_receipt'})
f0=orx[k]['fields'];f1=nrx[k]['fields'];test('k3_field_only_review_receipt',{x for x in f0|f1 if f0.get(x)!=f1.get(x)}=={'Review receipt'})
for og in oreg['gap_entries']:
 ng=next(g for g in nreg['gap_entries'] if g['id']==og['id']);test('gap_old_refs_preserved:'+og['id'],ng['references'][:len(og['references'])]==og['references'])
# Independent extraction of all held reference audit blocks using published line slices.
aud=load(B/'audit/out/gap_reference_audit.json');sources={}
for k,h in aud['source_identities'].items():
 matches=[p for p in (B/'audit/sources').iterdir() if p.is_file() and sha(p.read_bytes())==h]
 test('audit_source_identity:'+k,len(matches)==1);sources[k]=matches[0].read_bytes()
blocks=0;raw_slices=[]
for rr in aud['rows']:
 ch=rr['checks'];rid=rr['row'];prefix=str((rid['record'],rid['n'],rid['key']))
 parts=ch.get('current_blocks')
 if parts:
  extracted={}
  for sk,v in parts.items():
   aa,bb=v['lines'];raw=b''.join(sources[sk].splitlines(keepends=True)[aa-1:bb]);sli=b'\n'.join(sources[sk].split(b'\n')[aa-1:bb]);extracted[sk]=raw;raw_slices.append({'row':prefix,'source':sk,'raw_sha256':sha(raw),'raw_bytes':len(raw),'line_join_sha256':sha(sli),'line_join_bytes':len(sli)})
   test('audit_block_line_join:'+prefix+sk,sha(sli)==v['sha256'] and len(sli)==v['bytes']);blocks+=1
  for leg,status in ch['legs_computed_here'].items():
   keys={'v0.8.2':'RRF082','v0.8.3':'RRF083','v0.8.4':'RRF084'};l,h=leg.split('->')
   test('audit_leg:'+prefix+leg,('IDENTICAL' if extracted[keys[l]]==extracted[keys[h]] else 'CHANGED')==status)
 else:
  v=ch['pinned_block'];aa,bb=v['lines'];raw=b''.join(sources[rid['key']].splitlines(keepends=True)[aa-1:bb]);sli=b'\n'.join(sources[rid['key']].split(b'\n')[aa-1:bb]);raw_slices.append({'row':prefix,'source':rid['key'],'raw_sha256':sha(raw),'raw_bytes':len(raw),'line_join_sha256':sha(sli),'line_join_bytes':len(sli)});test('audit_pin_line_join:'+prefix,sha(sli)==v['sha256'] and len(sli)==v['bytes']);blocks+=1
result['line_slice_hashes_independently_checked']=blocks;result['raw_slices']=raw_slices
# Authored receipts are identified and read, not their execution claims newly re-executed.
result['receipt_identities']={p.name:sha(p.read_bytes()) for p in (B/'receipts').iterdir() if p.is_file()}
# Visible editorial findings, not gate failures in the supplied validator.
result['editorial_findings']={
 'header_line':new.decode().splitlines()[0],
 'date_line':new.decode().splitlines()[3],
 'added_RRF084_ref_count':new.decode().count('Reference: [RRF084:')+new.decode().count('Import/reference: [RRF084:'),
 'old_title_in_new_source':new.decode().splitlines()[0].endswith('r4.13')}
result['all_scope_checks_passed']=all(checks.values());result['checks']=checks
(W/'logs/independent_scope.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','old_matrix_differences','receipt_identities']},ensure_ascii=False,indent=2))
