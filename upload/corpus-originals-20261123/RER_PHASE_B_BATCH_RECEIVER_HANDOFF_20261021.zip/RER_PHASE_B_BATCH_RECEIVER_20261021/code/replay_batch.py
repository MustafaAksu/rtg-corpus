from pathlib import Path
import subprocess,sys,json,time,hashlib
W=Path(__file__).parent; B=W/'work/RER_PHASE_B_BATCH'; R=W/'work/rer_r4_14/RER_r4_14'; P=W/'work/phaseA_r21/RER_phaseA_r21';L=W/'logs'
jobs=[
 ('audit_check', B/'audit', ['gap_reference_audit.py','--check'], 0, 'out/audit_output.txt'),
 ('audit_controls', B/'audit',['gap_reference_audit.py','--controls'],0,None),
 ('disposition_check',B/'dispositions',['make_disposition_table.py','--check'],0,None),
 ('rer_build',R,['build_r4_14_draft.py'],0,None),
 ('rer_check',R,['check_r4_14_draft.py','--controls'],0,'check_r4_14_output.txt'),
 ('phase_build',P,['build_phaseA.py'],0,None),
 ('phase_check',P,['check_phaseA.py','--tamper'],0,'check_phaseA_output.txt'),
 ('k3_ec',B/'k3_econjugacy',['triad_k3_econjugacy_check.py'],0,'ec_output.txt'),
 ('k3_sb',B/'k3_econjugacy',['triad_six_step_factor_burnside_check.py'],0,'sb_output.txt'),
 ('k3_control',B/'k3_econjugacy',['triad_six_step_factor_burnside_check.py','--control'],1,'sb_control_output.txt'),
]
results=[]
for n,cwd,args,expected,stored in jobs:
 print('START',n,flush=True); t=time.monotonic()
 with (L/(n+'.log')).open('wb') as f:
  try:r=subprocess.run([sys.executable,'-I','-B']+args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=180);rc=r.returncode
  except subprocess.TimeoutExpired:rc='TIMEOUT'
 b=(L/(n+'.log')).read_bytes()
 entry={'job':n,'cwd':str(cwd),'command':[sys.executable,'-I','-B']+args,'returncode':rc,'expected_exit':expected,'seconds':round(time.monotonic()-t,3),'log_sha256':hashlib.sha256(b).hexdigest(),'stored_log_equal': b==(cwd/stored).read_bytes() if stored else None}
 results.append(entry);(L/'replay_results.json').write_text(json.dumps(results,indent=2))
 print('END',n,entry,'TAIL',b.decode(errors='replace')[-500:],flush=True)
