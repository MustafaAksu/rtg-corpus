"""Receiver derivation. No preparer code, jets or matrices are imported.
Exact carrier identities and independent degree-three recurrence for N^6.
The full-map conjugacy proof is written separately; the jet rank is corroboration.
"""
from pathlib import Path
import json, sympy as S
OUT=Path(__file__).parent/'logs'
OUT.mkdir(parents=True, exist_ok=True)
q=S.Rational
E=S.Matrix([[1,0],[-q(1,2),1],[-q(1,2),-1]])
P=(E.T*E).inv()*E.T
I2=S.eye(2); Eb=S.kronecker_product(E,I2); Pb=S.kronecker_product(P,I2)
C=S.kronecker_product(S.eye(3)-S.ones(3)/3,I2)
L=S.Matrix([[1,-q(1,2)],[0,S.sqrt(3)/2]])
L3=S.kronecker_product(S.eye(3),L); EW=L3*Eb
checks={
 'PE_identity':P*E==I2,
 'EP_mean_projector':E*P==S.eye(3)-S.ones(3)/3,
 'full_PE_identity':Pb*Eb==S.eye(4),
 'full_EP_projector':Eb*Pb==C,
 'rank4':Eb.rank()==4,
 'sumzero_image':S.kronecker_product(S.ones(1,3),I2)*Eb==S.zeros(2,4),
 'common_frame_commutes_projector':L3*C==C*L3,
 'eigenframe_encoding_left_inverse':S.simplify(Pb*L3.inv()*EW)==S.eye(4)
}
x=S.Matrix(S.symbols('s_r s_e c_r c_e')); variables=tuple(x)
def sub(v,y): return v.subs(dict(zip(variables,y)),simultaneous=True).applyfunc(S.expand)
edge=Eb*x
T1=[];T2=[];T3=[]
for i in range(3):
 r,e=edge[2*i],edge[2*i+1]
 T1.extend([r-e,r]);T2.extend([0,r**2/2]);T3.extend([e**3/6,(r**3+e**3)/6])
N1=Pb*S.Matrix(T1);N2=(Pb*S.Matrix(T2)).applyfunc(S.expand);N3=(Pb*S.Matrix(T3)).applyfunc(S.expand)
A=N1.jacobian(x);D2=N2.jacobian(x)
y1=x;y2=S.zeros(4,1);y3=S.zeros(4,1)
for k in range(6):
 z1=A*y1
 z2=(A*y2+sub(N2,y1)).applyfunc(S.expand)
 z3=(A*y3+D2.subs(dict(zip(variables,y1)),simultaneous=True)*y2+sub(N3,y1)).applyfunc(S.expand)
 y1,y2,y3=z1,z2,z3
checks['return_linear_identity']=y1==x
checks['return_quadratic_zero']=y2==S.zeros(4,1)
J=y3.jacobian(x)
points=[(1,0,0,0),(0,0,1,0),(1,2,-1,1),(2,-1,1,3),(0,1,1,-2)]
gens=[J.subs(dict(zip(variables,p))) for p in points]
def span_algebra(gs):
 vectors=[];mats=[];words=[];queue=[]
 def add(M,w):
  v=S.Matrix(1,16,list(M))
  if not vectors or S.Matrix.vstack(*vectors,v).rank()>len(vectors):
   vectors.append(v);mats.append(M);words.append(w);queue.append((M,w));return True
  return False
 add(S.eye(4),[])
 for i,G in enumerate(gs):add(G,[i])
 n=0
 while n<len(queue) and len(vectors)<16:
  M,w=queue[n];n+=1
  for i,G in enumerate(gs):
   add(M*G,w+[i])
   if len(vectors)==16:break
 return vectors,mats,words
vs,ms,words=span_algebra(gens)
det=S.Matrix.vstack(*vs).det() if len(vs)==16 else 0
checks['cubic_algebra_full_dimension']=len(vs)==16 and det!=0
Q=lambda r,e:r*r-r*e+e*e
control=S.Matrix([x[0]*Q(x[0],x[1]),x[1]*Q(x[0],x[1]),x[2]*Q(x[2],x[3]),x[3]*Q(x[2],x[3])])
cgs=[control.jacobian(x).subs(dict(zip(variables,p))) for p in points]
cvs,_,_=span_algebra(cgs)
checks['block_diagonal_control_dimension8']=len(cvs)==8
# A concrete rational perturbation breaks the left-inverse identity.
wrong=E.copy();wrong[1,1]=-1
checks['wrong_encoding_control_rejected']=P*wrong!=S.eye(2)
res={'role':'SESSION receiver-independent exact computation; no scientific adoption',
 'source_definition':'RER r4.14 §3, N=(P tensor I2) T_e^x3 (E tensor I2)',
 'checks':checks,'E':str(E),'P':str(P),'eigenframe_L':str(L),
 'cubic':[str(t) for t in y3], 'points':points,'jacobians':[[str(t) for t in G] for G in gens],
 'word_basis':words,'basis_determinant':str(det),'dimension':len(vs),'control_dimension':len(cvs)}
(OUT/'independent_k3.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2));assert all(checks.values())
