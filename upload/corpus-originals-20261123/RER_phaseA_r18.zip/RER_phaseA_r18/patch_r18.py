"""Phase A r17 -> r18: Phase A pass on the exact RER r4.13 bytes (receiving decision of 21 Oct 2026: RER r4.13 ACCEPT SCOPED; Phase A r18 authorized;
r17 outputs kept unchanged as history; catalog unchanged — the owner files now available on the receiving side are NOT entered here; a byte-evidence
update is a separate, visible catalog delta).
- Source Markdown: RER r4.13 (e92991bd…368c; package 3cf88b73…ab00) replaces r4.11; the r4.12 and r4.13 package manifests are added (identity chain
  r4.11 -> r4.12 -> r4.13); rows carry path_in_r4_13_package (package-presence metadata, labelled as such).
- Expected and gated against the pinned r17 outputs (built on r4.11): exactly four records differ — RER-TRIAD-FORMAL-INVOLUTION and
  RER-TRIAD-BIRTH-GRAPH-INVOLUTION (B-07 receipts appended in r4.12), RER-TRIAD-AGE-CURVATURE (B-08 receipt appended in r4.13) and RER-F3-N7N8
  (B-08 evidence separation: claim lines 3 -> 2 with the [NUM] line identical, Evidence/receipt appended, unclassified lines 4 added / 1 removed,
  the untagged evidence-status field preserved). The other 16 records, the four gap entries, the source table, all 91 matrix rows (apart from the
  new package-presence column), owners, warning and blocked register are unchanged.
- A24, A25, A28 re-based; A31/A32 read the r17 watch item by prefix; new A33 (F3-N7N8 parse change exactly as expected) and A34 (the four receipts
  carry the pinned B-07/B-08 decision hashes; the 16 others identical to r17).
Args: TARGET_DIR R413_PACKAGE_DIR R412_PACKAGE_DIR."""
import sys, os, json, shutil, hashlib
D, P413, P412 = sys.argv[1:4]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
R413 = 'e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c'; R413Z = '3cf88b73f143f4f05e6965488090dfa999a397dd2e1d0a781f46d8f00604ab00'
R412 = '7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9'; R412Z = 'accdf0d7d81b84b30a255410625a660ed33f3ccba2dd9d5b22c721ff9fb4cd57'
R411 = '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8'; R411Z = 'f55652773396fe5ed56b22659aa603dfa267f09f420e7c7089ae6d5c92d43073'
B07 = '845c47562df5afea8e09270b63deaefbedc85f4e53f51c3b2d925d0b0ba07141'; B08 = '6c33a39ab15c80ac35bfe02dfec36f94c50c7bf9ca726e157ad554d59c5cb9b5'
MD13 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_13.md'; MD11 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_11.md'
m13 = open(os.path.join(P413, MD13), 'rb').read(); assert sha(m13) == R413
assert not any(x == '__pycache__' for _, ds, _ in os.walk(D) for x in ds)
os.remove(os.path.join(D, 'SHA256SUMS.txt'))
H = os.path.join(D, 'inputs/phaseA_r17_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r17.txt'))
os.remove(os.path.join(D, MD11)); open(os.path.join(D, MD13), 'wb').write(m13)
for f in ('RER_PHASE_A_R17_CHANGE_RECORD_20261021.md', 'patch_r17a.py', 'patch_r17b.py'): os.remove(os.path.join(D, f))
shutil.copyfile(os.path.join(P413, 'SHA256SUMS.txt'), os.path.join(D, 'inputs/r4_13_package_SHA256SUMS.txt'))
shutil.copyfile(os.path.join(P412, 'SHA256SUMS.txt'), os.path.join(D, 'inputs/r4_12_package_SHA256SUMS.txt'))
for src, dst in ((os.path.join(P413, 'inputs/B07_RECEIVING_REVIEW_20261021.md'), 'inputs/B07_RECEIVING_REVIEW_20261021.md'), (os.path.join(P413, 'inputs/B08_RECEIVING_REVIEW_20261021.md'), 'inputs/B08_RECEIVING_REVIEW_20261021.md')):
    shutil.copyfile(src, os.path.join(D, dst))
assert sha(open(os.path.join(D, 'inputs/B07_RECEIVING_REVIEW_20261021.md'), 'rb').read()) == B07 and sha(open(os.path.join(D, 'inputs/B08_RECEIVING_REVIEW_20261021.md'), 'rb').read()) == B08

rp('build_phaseA.py', [
 ('"""RER Phase A r17 builder (deterministic; r17 runs on RER r4.11', '"""RER Phase A r18 builder (deterministic; r18 runs on RER r4.13 (B-07/B-08 receipts; F3-N7N8 evidence separation) with the r17 catalog unchanged; r17 runs on RER r4.11'),
 (f"MD = '{MD11}'\nMD_SHA = '{R411}'\nR411_ZIP_SHA = '{R411Z}'\n", f"MD = '{MD13}'\nMD_SHA = '{R413}'\nR413_ZIP_SHA = '{R413Z}'\nBASE_R412_SHA = '{R412}'\nR412_ZIP_SHA = '{R412Z}'\nBASE_R411_SHA = '{R411}'\nR411_ZIP_SHA = '{R411Z}'\n"),
 ("    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.11 hash mismatch'", "    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.13 hash mismatch'"),
 ("pkg411 = man('inputs/r4_11_package_SHA256SUMS.txt')", "pkg411 = man('inputs/r4_11_package_SHA256SUMS.txt'); pkg413 = man('inputs/r4_13_package_SHA256SUMS.txt')"),
 ("'path_in_r4_11_package': path in pkg411, 'cited_path': path,", "'path_in_r4_11_package': path in pkg411, 'path_in_r4_13_package': path in pkg413, 'cited_path': path,"),
 ("'RER-REGISTRY-PHASEA/17'", "'RER-REGISTRY-PHASEA/18'"), ("'RER-SOURCE-CURRENCY/17'", "'RER-SOURCE-CURRENCY/18'"), ("'RER-BLOCKED-SOURCES/17'", "'RER-BLOCKED-SOURCES/18'"),
 ("'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R411_ZIP_SHA, 'base_r4_10_sha256': BASE_R410_SHA,",
  "'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R413_ZIP_SHA, 'base_r4_12_sha256': BASE_R412_SHA, 'base_r4_12_package_zip_sha256': R412_ZIP_SHA, 'base_r4_11_sha256': BASE_R411_SHA, 'base_r4_11_package_zip_sha256': R411_ZIP_SHA, 'base_r4_10_sha256': BASE_R410_SHA,"),
 ("    return {'out/RER_REGISTRY_v0_2_r4_11_PHASEA.json': dump(reg),", "    return {'out/RER_REGISTRY_v0_2_r4_13_PHASEA.json': dump(reg),"),
 ("'# RER r4.11 — source-currency matrix (Phase A r17, noncanonical)'", "'# RER r4.13 — source-currency matrix (Phase A r18, noncanonical)'"),
 ("'# RER r4.11 — blocked-source register (Phase A r17, noncanonical)'", "'# RER r4.13 — blocked-source register (Phase A r18, noncanonical)'"),
 ("| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 / r4.10 / r4.11 pkg |", "| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 / r4.10 / r4.11 / r4.13 pkg (package-presence metadata) |"),
 ("{yn(x['path_in_r4_11_package'])} |", "{yn(x['path_in_r4_11_package'])} / {yn(x['path_in_r4_13_package'])} |"),
 ("Adoption of a newer owner version does not show section equality or change an older attribution. G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.']}",
  "Adoption of a newer owner version does not show section equality or change an older attribution. G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.',\n"
  "                          'Phase A r18 (21 Oct 2026): source is RER r4.13 (e92991bd…368c; package 3cf88b73…ab00), accepted ACCEPT SCOPED as a DRAFT, built on r4.12 (7313647a…f4b9, ACCEPT SCOPED, B-07 receipt integration). Against the r17 outputs (built on r4.11) exactly four records change: RER-TRIAD-FORMAL-INVOLUTION and RER-TRIAD-BIRTH-GRAPH-INVOLUTION carry the B-07 receiving decisions (ACCEPT SCOPED; decision file 845c4756…7141); RER-TRIAD-AGE-CURVATURE carries its B-08 decision (ACCEPT SCOPED; 6c33a39a…c9b5); RER-F3-N7N8 carries its B-08 correction (CORRECTION REQUIRED, applied: the formal E7/E8 content is the only [ALG] claim of its first line, the infrastructure/pilot/review-status text is an untagged evidence-status field, a historical/current boundary line precedes the formal claim, the [NUM] line and the Q_s bound are unchanged) and its B-08 receipt; grade [ALG], FINITE_ORDER and GLOBAL_CERTIFICATE_PENDING unchanged. The other 16 records, the gap entries, the source table, all pins and OPEN items are unchanged. Owner catalog unchanged since r17 (Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 OWNER_REPORTED); the receiver reports holding files with these identities — a byte-evidence update is a separate catalog delta and is not inferred here. G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.']}"),
])

C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    assert t.count(a) == 1, a[:60]; i = t.index(a); j = t.index(b, i); return t[:i] + new + t[j:]
def one(t, a, b):
    assert t.count(a) == 1, a[:80]; return t.replace(a, b)
assert t.count("'out/RER_REGISTRY_v0_2_r4_11_PHASEA.json'") == 2
t = t.replace("'out/RER_REGISTRY_v0_2_r4_11_PHASEA.json'", "'out/RER_REGISTRY_v0_2_r4_13_PHASEA.json'")
t = one(t, "pkg411 = B.rd('inputs/r4_11_package_SHA256SUMS.txt').decode()", "pkg411 = B.rd('inputs/r4_11_package_SHA256SUMS.txt').decode(); pkg413 = B.rd('inputs/r4_13_package_SHA256SUMS.txt').decode()")
t = one(t, "        if x.get('path_in_r4_11_package') and ('  ' + x['cited_path'] + '\\n') not in pkg411: bb.append(x['key'] + ':pkg411')\n",
        "        if x.get('path_in_r4_11_package') and ('  ' + x['cited_path'] + '\\n') not in pkg411: bb.append(x['key'] + ':pkg411')\n        if x.get('path_in_r4_13_package') and ('  ' + x['cited_path'] + '\\n') not in pkg413: bb.append(x['key'] + ':pkg413')\n")

NEW_A24_25 = r'''    sm = reg['source_markdown']
    H13 = 'inputs/phaseA_r13_outputs/'; o13 = ri(H13 + 'check_phaseA_output_r13.txt').decode('utf-8'); H15 = 'inputs/phaseA_r15_outputs/'; o15 = ri(H15 + 'check_phaseA_output_r15.txt').decode('utf-8')
    H16 = 'inputs/phaseA_r16_outputs/'; o16 = ri(H16 + 'check_phaseA_output_r16.txt').decode('utf-8'); H17 = 'inputs/phaseA_r17_outputs/'; o17 = ri(H17 + 'check_phaseA_output_r17.txt').decode('utf-8')
    man413 = B.rd('inputs/r4_13_package_SHA256SUMS.txt').decode(); man412 = B.rd('inputs/r4_12_package_SHA256SUMS.txt').decode()
    src_ok = (sm['file'].endswith('_r4_13.md') and sm['sha256'] == B.MD_SHA == 'e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c' and sm['package_zip_sha256'] == '3cf88b73f143f4f05e6965488090dfa999a397dd2e1d0a781f46d8f00604ab00'
              and sm.get('base_r4_12_sha256') == '7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9' and sm.get('base_r4_12_package_zip_sha256') == 'accdf0d7d81b84b30a255410625a660ed33f3ccba2dd9d5b22c721ff9fb4cd57'
              and sm.get('base_r4_11_sha256') == '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8' and sm.get('base_r4_11_package_zip_sha256') == 'f55652773396fe5ed56b22659aa603dfa267f09f420e7c7089ae6d5c92d43073'
              and sm.get('base_r4_10_sha256') == '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c' and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA
              and all('path_in_r4_13_package' in x for x in cm['rows']) and '28/28 gates PASS' in o13 and '29/29 gates PASS' in o15 and '30/30 gates PASS' in o16 and '32/32 gates PASS' in o17 and 'BAD' not in o13 + o15 + o16 + o17
              and '7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9  RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_12.md\n' in man413
              and '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8  RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_11.md\n' in man412)
    g('A24 r4.13 source pass: r4.13, package and r4.12/r4.11/r4.10 bases pinned; identity chain r4.11 -> r4.12 -> r4.13 in the manifests; every row carries path_in_r4_13_package; r13, r15, r16 and r17 checker records kept', src_ok)
    g17 = json.loads(B.rd(H17 + 'RER_REGISTRY_v0_2_r4_11_PHASEA.json'))
    G17 = {x['id']: x for x in g17['gap_entries']}; G18 = {x['id']: x for x in reg['gap_entries']}
    R17 = {x['id']: x for x in g17['records']}; R18 = {x['id']: x for x in reg['records']}
    dr = sorted(k for k in R17 if R17[k] != R18.get(k))
    FOUR = ['RER-F3-N7N8', 'RER-TRIAD-AGE-CURVATURE', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'RER-TRIAD-FORMAL-INVOLUTION']
    def receipt_only(a, b, tag):
        dk = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k)); fa, fb = a.get('fields', {}), b.get('fields', {})
        return (dk == ['fields', 'prior_review_receipt'] and sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k)) == ['Review receipt']
                and fb.get('Review receipt', '').startswith(fa.get('Review receipt', '') + ' ' + tag) and b.get('prior_review_receipt') == fb.get('Review receipt'))
    rec_ok = (receipt_only(R17['RER-TRIAD-FORMAL-INVOLUTION'], R18.get('RER-TRIAD-FORMAL-INVOLUTION', {}), 'r4.12: B-07') and receipt_only(R17['RER-TRIAD-BIRTH-GRAPH-INVOLUTION'], R18.get('RER-TRIAD-BIRTH-GRAPH-INVOLUTION', {}), 'r4.12: B-07')
              and receipt_only(R17['RER-TRIAD-AGE-CURVATURE'], R18.get('RER-TRIAD-AGE-CURVATURE', {}), 'r4.13: B-08'))
    f7, f8 = R17['RER-F3-N7N8'], R18.get('RER-F3-N7N8', {})
    dkf = sorted(k for k in set(f7) | set(f8) if f7.get(k) != f8.get(k)); ff7, ff8 = f7.get('fields', {}), f8.get('fields', {})
    f3_ok = (dkf == ['claim_lines', 'fields', 'prior_review_receipt', 'unclassified_lines'] and sorted(k for k in set(ff7) | set(ff8) if ff7.get(k) != ff8.get(k)) == ['Evidence', 'Review receipt']
             and ff8['Evidence'].startswith(ff7['Evidence'] + ' r4.13 (B-08 F3-03)') and ff8['Review receipt'].startswith(ff7['Review receipt'] + ' r4.13: B-08') and f8.get('prior_review_receipt') == ff8['Review receipt']
             and f8.get('grade_tags') == f7['grade_tags'] == ['ALG'] and f8.get('task') == f7['task'] == 'GLOBAL_CERTIFICATE_PENDING' and f8.get('contract') == f7['contract'] and f8.get('imports') == f7['imports'] and f8.get('open_items') == f7['open_items'])
    strip = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown', 'gap_entries', 'records')}
    r_ok = (strip(reg) == strip(g17) and list(R17) == list(R18) and dr == FOUR and rec_ok and f3_ok and G17 == G18 and reg['source_table'] == g17['source_table'] and len(reg['records']) == 20
            and g17['schema'] == 'RER-REGISTRY-PHASEA/17' and reg['schema'] == 'RER-REGISTRY-PHASEA/18')
    g('A25 r17 registry equality: exactly four records differ — three by an appended Review receipt only (B-07 x2, B-08 x1), RER-F3-N7N8 by claim lines, Evidence/receipt and unclassified lines with grade, task, contract, imports and OPEN unchanged; gap entries and source table identical', r_ok, f'records differing: {dr}')
'''
t = cut(t, "    sm = reg['source_markdown']\n    H13 = ", "    rc = oc['RECOG'];", NEW_A24_25)

NEW_A28 = r'''    m17 = json.loads(B.rd(H17 + 'SOURCE_CURRENCY_MATRIX.json')); b17 = json.loads(B.rd(H17 + 'BLOCKED_SOURCE_REGISTER.json'))
    dk = [sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k)) for x, y in zip(cm['rows'], m17['rows'])]
    rows17_ok = (len(cm['rows']) == len(m17['rows']) == 91 and all(d == ['path_in_r4_13_package'] for d in dk)
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256')}
    rest17_ok = (stripb(br) == stripb(b17) and oc == m17['owner_current'] and cm.get('scientific_sync_warnings') == m17.get('scientific_sync_warnings')
                 and cm['watch_items'][:-1] == m17['watch_items'] and cm['watch_items'][-1].startswith('Phase A r18 (21 Oct 2026): source is RER r4.13')
                 and meta == m17['owner_catalog'] and cm['bytes_not_available_to_preparer'] == m17['bytes_not_available_to_preparer'] and m17['schema'] == 'RER-SOURCE-CURRENCY/17' and cm['schema'] == 'RER-SOURCE-CURRENCY/18')
    g('A28 r17 matrix equality: 91 rows differ only by the package-presence column path_in_r4_13_package; owners, catalog (incl. checked date), warning, blocked register and G9 audits unchanged', rows17_ok and rest17_ok, f'{sum(1 for d in dk if d != ["path_in_r4_13_package"])} row(s) with other differences')
'''
t = cut(t, "    m16 = json.loads(B.rd(H16 + 'SOURCE_CURRENCY_MATRIX.json'))", "    H83 = ", NEW_A28)
# A31/A32: read the r17 watch item by prefix (the last item is now r18's)
t = one(t, "    FNF = 'FORMAL__FORMAL_AGE_FAMILY_REVIEW.md'; PF = os.path.join(HERE, 'sources_available', FNF);",
        "    W17 = next((w for w in cm['watch_items'] if w.startswith('Phase A r17 (21 Oct 2026)')), '')\n    FNF = 'FORMAL__FORMAL_AGE_FAMILY_REVIEW.md'; PF = os.path.join(HERE, 'sources_available', FNF);")
t = one(t, "           and 'RER-TRIAD-FORMAL-AGE primary grade [ALG]' in cm['watch_items'][-1] and 'b170dbff…3899' in cm['watch_items'][-1])", "           and 'RER-TRIAD-FORMAL-AGE primary grade [ALG]' in W17 and 'b170dbff…3899' in W17)")
t = one(t, "              and h[:8] in cm['watch_items'][-1] for o, v, h, rec in NV)", "              and h[:8] in W17 for o, v, h, rec in NV)")
NEW_A33_34 = r'''    f8 = next((x for x in reg['records'] if x['id'] == 'RER-F3-N7N8'), {}); f7 = next((x for x in json.loads(B.rd('inputs/phaseA_r17_outputs/RER_REGISTRY_v0_2_r4_11_PHASEA.json'))['records'] if x['id'] == 'RER-F3-N7N8'), {})
    c7, c8 = f7.get('claim_lines', []), f8.get('claim_lines', []); u7, u8 = f7.get('unclassified_lines', []), f8.get('unclassified_lines', [])
    FIELD = '**Infrastructure and evidence status (not a graded claim; r4.13, B-08 F3-01):**'; BOUND = '**Historical/current boundary (r4.13, B-08 F3-02):**'
    UPD = 'Infrastructure evidence update (r3.1/r4.2; untagged since r4.13'; TBL_OLD = '**Reported Stage1 v2 local constants, not a region certificate:**'; TBL_NEW = '**Reported Stage1 v2 local constants, not a region certificate (source-reported evidence; not a graded claim of this record; r4.13):**'
    added = [l for l in u8 if l not in u7]; removed = [l for l in u7 if l not in u8]
    a33 = (len(c7) == 3 and len(c8) == 2 and c8[1] == c7[1] and c7[1].startswith('[NUM] **SAMPLED_ONLY.**') and c7[0].startswith('[ALG] **FINITE_ORDER.** Formal E7/E8 expansions') and c7[2].startswith('[ALG] Infrastructure evidence update only')
           and c8[0].startswith('[ALG] **FINITE_ORDER.** Formal leading-order compatibility defects') and 'E7 = Delta_tau C8 + Delta_tau C9 + O(R^10) and E8 = Delta_tau C9 + O(R^10)' in c8[0] and 'gives no numerical upper bound on the proposed region' in c8[0]
           and not any(s in c8[0] for s in ('41-expectation', 'K=6 pilot', 'K=8', 'lemma review')) and len(u8) == len(u7) + 3 and len(added) == 4 and len(removed) == 1
           and removed[0] == TBL_OLD and sorted(l[:40] for l in added) == sorted(l[:40] for l in (FIELD, BOUND, UPD, TBL_NEW)) and any(l.startswith(FIELD) for l in added) and any(l.startswith(BOUND) for l in added) and any(l.startswith(UPD) for l in added) and any(l.startswith(TBL_NEW) for l in added)
           and all(s in next(l for l in added if l.startswith(FIELD)) for s in ('41-expectation suite passes', 'All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N)', 'INSUFFICIENT EVIDENCE for regional coverage', 'engineering evidence'))
           and f8.get('adoption_status') == 'PENDING' and f8.get('contract', {}).get('Constraints') == f7.get('contract', {}).get('Constraints') and 'R^2/2<=Qs<=3R^2/2' in (f8.get('contract', {}).get('Constraints') or ''))
    g('A33 RER-F3-N7N8 parse change exactly as accepted: claim lines 3 -> 2 ([NUM] identical; first [ALG] formal only, no infrastructure text); unclassified lines +4/-1 (status field, boundary, untagged update, relabelled Stage1 heading); Constraints incl. the Q_s bound unchanged; adoption PENDING', a33, f'claims {len(c7)}->{len(c8)}, unclassified {len(u7)}->{len(u8)}')
    B07H = '845c47562df5afea8e09270b63deaefbedc85f4e53f51c3b2d925d0b0ba07141'; B08H = '6c33a39ab15c80ac35bfe02dfec36f94c50c7bf9ca726e157ad554d59c5cb9b5'
    d07 = B.rd('inputs/B07_RECEIVING_REVIEW_20261021.md'); d08 = B.rd('inputs/B08_RECEIVING_REVIEW_20261021.md')
    RR = {x['id']: x.get('prior_review_receipt', '') for x in reg['records']}
    R17all = {x['id']: x for x in json.loads(B.rd('inputs/phaseA_r17_outputs/RER_REGISTRY_v0_2_r4_11_PHASEA.json'))['records']}
    a34 = (sha(d07) == B07H and sha(d08) == B08H
           and all(B07H in RR.get(r, '') and 'r4.12: B-07 independent receiving review' in RR[r] and 'Record decision: ACCEPT SCOPED' in RR[r] for r in ('RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION'))
           and B08H in RR.get('RER-TRIAD-AGE-CURVATURE', '') and 'ACCEPT SCOPED [ALG], FINITE_ORDER' in RR['RER-TRIAD-AGE-CURVATURE']
           and B08H in RR.get('RER-F3-N7N8', '') and 'Record decision: CORRECTION REQUIRED' in RR['RER-F3-N7N8'] and 'applied here' in RR['RER-F3-N7N8'] and 'INSUFFICIENT EVIDENCE' in RR['RER-F3-N7N8']
           and all(x['prior_review_receipt'] == x['fields'].get('Review receipt') for x in reg['records'] if x['fields'].get('Review receipt'))
           and all(R17all[r] == next((x for x in reg['records'] if x['id'] == r), None) for r in R17all if r not in ('RER-F3-N7N8', 'RER-TRIAD-AGE-CURVATURE', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'RER-TRIAD-FORMAL-INVOLUTION'))
           and all(x['adoption_status'] == 'PENDING' for x in reg['records']))
    g('A34 receipts: the four changed records carry the pinned B-07 / B-08 decision hashes with their stated outcomes (incl. INSUFFICIENT EVIDENCE items and CORRECTION REQUIRED applied); the other 16 records identical to r17; adoption PENDING everywhere', a34)
    return all(res), res

outs ='''
t = one(t, "    return all(res), res\n\nouts =", NEW_A33_34)

# ---- controls
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
assert block[0].startswith("    T = [('") and all(l.startswith("         ('") for l in block[1:])
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]; ents[-1] = ents[-1][:-1]
keep = [e.rstrip(',') for e in ents if not any(e.startswith("('" + g + ' ') for g in ('A24', 'A25', 'A28'))]
keep = [e.replace("d['watch_items'].__setitem__(-1, d['watch_items'][-1].replace('primary grade [ALG]', 'grade unchanged', 1))", "d['watch_items'].__setitem__(-2, d['watch_items'][-2].replace('primary grade [ALG]', 'grade unchanged', 1))") for e in keep]
assert any("__setitem__(-2, d['watch_items'][-2]" in e for e in keep)
G17R = "json.loads(B.rd('inputs/phaseA_r17_outputs/RER_REGISTRY_v0_2_r4_11_PHASEA.json'))"; M17 = "json.loads(B.rd('inputs/phaseA_r17_outputs/SOURCE_CURRENCY_MATRIX.json'))"
F3 = "next(x for x in d['records'] if x['id'] == 'RER-F3-N7N8')"
NEWC = f'''('A24 source recorded as r4.11', 23, mut(R, lambda d: d['source_markdown'].update(sha256='2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8')))
('A24 source recorded as r4.12', 23, mut(R, lambda d: d['source_markdown'].update(sha256='7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9')))
('A24 r4.13 package hash replaced', 23, mut(R, lambda d: d['source_markdown'].update(package_zip_sha256='0' * 64)))
('A24 r4.12 base dropped', 23, mut(R, lambda d: d['source_markdown'].pop('base_r4_12_sha256')))
('A24 a row without path_in_r4_13_package', 23, mut(C, lambda d: d['rows'][0].pop('path_in_r4_13_package')))
('A25 r17 F3-N7N8 record re-used (three claim lines)', 24, mut(R, lambda d: d['records'].__setitem__([x['id'] for x in d['records']].index('RER-F3-N7N8'), next(x for x in {G17R}['records'] if x['id'] == 'RER-F3-N7N8'))))
('A25 r17 FORMAL-INVOLUTION record re-used (no B-07 receipt)', 24, mut(R, lambda d: d['records'].__setitem__([x['id'] for x in d['records']].index('RER-TRIAD-FORMAL-INVOLUTION'), next(x for x in {G17R}['records'] if x['id'] == 'RER-TRIAD-FORMAL-INVOLUTION'))))
('A25 F3-N7N8 grade tag changed', 24, mut(R, lambda d: {F3}.update(grade_tags=['THM'])))
('A25 F3-N7N8 task changed', 24, mut(R, lambda d: {F3}.update(task='CLOSED')))
('A25 F3-N7N8 contract cell changed', 24, mut(R, lambda d: {F3}['contract'].update(Memory='edited')))
('A25 F3-N7N8 import dropped', 24, mut(R, lambda d: {F3}['imports'].pop()))
('A25 F3-N7N8 OPEN item dropped', 24, mut(R, lambda d: {F3}['open_items'].pop()))
('A25 AGE-CURVATURE receipt rewritten instead of appended', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-AGE-CURVATURE')['fields'].update({{'Review receipt': 'r4.13: B-08 only'}})))
('A25 a fifth record changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED')))
('A25 a gap entry changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G9').update(text_sha256='0' * 64)))
('A25 source table changed', 24, mut(R, lambda d: d['source_table']['FORMAL'].update(description='edited')))
('A28 r17 matrix rows re-used', 27, mut(C, lambda d: d.update(rows={M17}['rows'])))
('A28 a row status changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(status='VERIFIED')))
('A28 a row pin hash changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'CURVSCRIPT').update(cited_sha256='0' * 64)))
('A28 owner entry changed (silent byte-evidence upgrade)', 27, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED')))
('A28 catalog checked date changed without a catalog delta', 27, mut(C, lambda d: d['owner_catalog'].update(checked='2026-10-21 (Phase A r18, preparer)')))
('A28 G9/1 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 1).update(gap_reference_review='CLOSED')))
('A28 warning disposition dropped', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition')))
('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited')))
('A28 r18 watch item dropped', 27, mut(C, lambda d: d['watch_items'].pop()))
('A33 [NUM] line altered', 32, mut(R, lambda d: {F3}['claim_lines'].__setitem__(1, {F3}['claim_lines'][1].replace('no continuous-domain supremum', 'a supremum', 1))))
('A33 infrastructure sentence put back into the [ALG] claim', 32, mut(R, lambda d: {F3}['claim_lines'].__setitem__(0, {F3}['claim_lines'][0] + ' All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N).')))
('A33 status field dropped from the machine artifact', 32, mut(R, lambda d: {F3}['unclassified_lines'].remove(next(l for l in {F3}['unclassified_lines'] if l.startswith('**Infrastructure and evidence status')))))
('A33 boundary line dropped', 32, mut(R, lambda d: {F3}['unclassified_lines'].remove(next(l for l in {F3}['unclassified_lines'] if l.startswith('**Historical/current boundary')))))
('A33 K=6 pilot presented as regional coverage', 32, mut(R, lambda d: {F3}['unclassified_lines'].__setitem__([i for i, l in enumerate({F3}['unclassified_lines']) if l.startswith('**Infrastructure and evidence status')][0], next(l for l in {F3}['unclassified_lines'] if l.startswith('**Infrastructure and evidence status')).replace('INSUFFICIENT EVIDENCE for regional coverage', 'sufficient for regional coverage', 1))))
('A33 Q_s bound edited', 32, mut(R, lambda d: {F3}['contract'].update(Constraints={F3}['contract']['Constraints'].replace('R^2/2<=Qs<=3R^2/2', 'Qs<=R^2', 1))))
('A34 B-07 hash dropped from a receipt', 33, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-INVOLUTION').update(prior_review_receipt='r4.12: B-07 independent receiving review; Record decision: ACCEPT SCOPED')))
('A34 F3-N7N8 CORRECTION REQUIRED relabelled as ACCEPT SCOPED', 33, mut(R, lambda d: {F3}.update(prior_review_receipt={F3}['prior_review_receipt'].replace('Record decision: CORRECTION REQUIRED', 'Record decision: ACCEPT SCOPED', 1))))
('A34 INSUFFICIENT EVIDENCE items dropped from the F3 receipt', 33, mut(R, lambda d: {F3}.update(prior_review_receipt={F3}['prior_review_receipt'].replace('INSUFFICIENT EVIDENCE', 'ACCEPT SCOPED'))))
('A34 a record adoption promoted', 33, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-AGE-CURVATURE').update(adoption_status='ADOPTED')))'''.split('\n')
t = t[:i] + '    T = [' + (',\n         ').join(keep + NEWC) + ']' + t[j:]
t = one(t, "    print(f'  input control A24 r16 checker record altered: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n",
        "    print(f'  input control A24 r16 checker record altered: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    o17 = B.rd('inputs/phaseA_r17_outputs/check_phaseA_output_r17.txt')\n"
        "    _, rr = gates(outs, verbose=False, inp={'inputs/phaseA_r17_outputs/check_phaseA_output_r17.txt': o17.replace(b'32/32 gates PASS', b'31/32 gates PASS', 1)}); good = not rr[23]; allf &= good\n"
        "    print(f'  input control A24 r17 checker record altered: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    d08 = B.rd('inputs/B08_RECEIVING_REVIEW_20261021.md'); keep08 = d08\n"
        "    P08 = os.path.join(HERE, 'inputs/B08_RECEIVING_REVIEW_20261021.md')\n"
        "    try:\n"
        "        open(P08, 'wb').write(d08 + b'x'); _, rr = gates(outs, verbose=False); good = not rr[33]; allf &= good\n"
        "        print(f'  input control A34 B-08 decision file altered: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    finally:\n"
        "        open(P08, 'wb').write(keep08)\n")
a = '"""Phase A r17 gates on RER v0.2 DRAFT r4.11 (r17: source r4.11; Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 owner-reported).'; assert t.count(a) == 1
t = t.replace(a, '"""Phase A r18 gates on RER v0.2 DRAFT r4.13 (r18: source r4.13; catalog unchanged since r17).\n'
  'r18: A24 pins r4.13, its package, the r4.12/r4.11/r4.10 bases and the manifest identity chain, and keeps the r13, r15, r16 and r17 checker records. A25\n'
  'compares with the pinned r17 registry (built on r4.11): exactly four records differ — three by an appended Review receipt only (B-07 receipts of the two\n'
  'Triadic involution records, B-08 receipt of AGE-CURVATURE), RER-F3-N7N8 by claim lines, Evidence/receipt and unclassified lines with grade, task, contract,\n'
  'imports and OPEN unchanged; gap entries and source table identical. A28 compares with the pinned r17 matrix: rows differ only by the package-presence\n'
  'column path_in_r4_13_package; owners, catalog (incl. checked date), warning and blocked register unchanged — no catalog delta in r18. A31/A32 read the r17\n'
  'watch item by prefix. New A33: the F3-N7N8 parse change exactly as accepted (claim lines 3 -> 2, [NUM] identical, unclassified +4/-1 incl. the untagged\n'
  'status field, Q_s bound unchanged). New A34: the four changed records carry the pinned B-07/B-08 decision hashes with their outcomes; the 16 others are\n'
  'identical to r17; adoption PENDING everywhere. The r17 A24/A25/A28 controls are retired; their results stay in the pinned r17 record.\n'
  'Earlier wording, kept as history: Phase A r17 gates on RER v0.2 DRAFT r4.11 (r17: source r4.11; Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 owner-reported).', 1)
open(C, 'w', encoding='utf-8').write(t)

p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['inputs/r4_12_package_SHA256SUMS.txt', 'inputs/r4_13_package_SHA256SUMS.txt', 'inputs/B07_RECEIVING_REVIEW_20261021.md', 'inputs/B08_RECEIVING_REVIEW_20261021.md'] + ['inputs/phaseA_r17_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched r18')
