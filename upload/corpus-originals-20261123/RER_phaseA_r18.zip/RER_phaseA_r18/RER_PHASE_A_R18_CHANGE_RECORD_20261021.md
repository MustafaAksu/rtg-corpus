# RER Phase A r18: change record

**Date:** 21 Oct 2026.
**From:** Claude, RER co-owner (preparer). The receiver decides on acceptance.
**Status:** NONCANONICAL Phase A pass. Nothing is adopted, frozen or published. No Markdown edited; no grade, status, owner or pin changed by the builder. **No catalog delta in this pass.**
**Authorized by:** the r4.13 receiving review of 21 Oct 2026 (RER r4.13 ACCEPT SCOPED; Phase A r18 may be prepared from the exact r4.13 hash, r17 outputs kept as history; not authorized to infer adoption or close unrelated OPEN items).

## 1. Inputs

| Object | SHA-256 |
|---|---|
| Source: RER r4.13 | `e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c` |
| r4.13 package | `3cf88b73…ab00` (manifest in `inputs/r4_13_package_SHA256SUMS.txt`) |
| Base r4.12 / its package | `7313647a…f4b9` / `accdf0d7…cd57` (manifest in `inputs/r4_12_package_SHA256SUMS.txt`) |
| Base r4.11 | `2cd3f0e9…4dd8` (listed in the r4.12 manifest; the r4.12 identity is listed in the r4.13 manifest) |
| B-07 decision file | `845c4756…7141` (`inputs/`) |
| B-08 decision file | `6c33a39a…c9b5` (`inputs/`) |
| Phase A r17 outputs and checker output | kept unchanged under `inputs/phaseA_r17_outputs/` (pinned) |

- **Built by:** `patch_r18.py` on a fresh copy of the r17 package. The r17 patch scripts and change record leave the package; the r17 outputs stay as pinned history.

## 2. Comparison baseline

r17 was built on r4.11. r18 therefore compares against r17 across two accepted RER revisions, r4.12 and r4.13, and exactly **four** records are expected to differ. This is the receiver's stated expectation and it is what A25 checks.

| Record | Difference against r17 |
|---|---|
| RER-TRIAD-FORMAL-INVOLUTION | Review receipt appended (B-07, r4.12); `prior_review_receipt` follows |
| RER-TRIAD-BIRTH-GRAPH-INVOLUTION | Review receipt appended (B-07, r4.12) |
| RER-TRIAD-AGE-CURVATURE | Review receipt appended (B-08, r4.13) |
| RER-F3-N7N8 | claim lines 3 → 2 (the `[NUM]` line identical; the first `[ALG]` line now formal only); Evidence and Review receipt appended; unclassified lines 14 → 17 (added: the untagged status field, the boundary line, the untagged infrastructure-update line, the relabelled Stage-1 heading; removed: the old Stage-1 heading). Grade `['ALG']`, FINITE_ORDER, task GLOBAL_CERTIFICATE_PENDING, contract, imports and OPEN unchanged |

Everything else is identical to r17: the other 16 records, the four gap entries, the source table, the 91 matrix rows apart from the new package-presence column, the owner catalog including its checked date, the sync warning with its disposition, and the blocked register. Status counts stay 28 / 5 / 52 / 6.

**Package-presence metadata.** The new column `path_in_r4_13_package` records whether a cited path is listed in the r4.13 manifest. It is metadata about packaging, not row data about bytes or evidence, and is labelled so in the matrix header.

## 3. Receiver notes from the r4.13 review, carried here

| Note | How r18 reflects it |
|---|---|
| R413-N1: the moved paragraph is not literally verbatim (`bundle now supplies` → `bundle supplies`) | Recorded here as a wording correction to the r4.13 change record. The accepted r4.13 bytes are not touched. |
| R413-N2: unclassified lines 14 → 17 (+4 / −1), not "two new" | A33 gates the exact +4 / −1 transformation and names the four added lines and the one removed. |
| R413-N3: the §9 entry says the boundary "precedes the r3.1 table"; it follows the table and the overlay, immediately before the formal claim | Recorded here; A33 and the r4.13 F3 gate describe the actual placement. |

## 4. Owner files on the receiving side

The receiver reports that Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 are now mounted in its environment with hashes equal to the r17 OWNER_REPORTED identities, and that no section comparison was made. r18 does **not** enter this: the catalog is unchanged, and A28 includes a control that rejects a silent evidence upgrade or a changed checked date. A byte-evidence update would be a separate, visible catalog delta (as r13/r14 were for v0.3.21 and v6.4.18), with section checks against the pinned editions.

## 5. Gates: 34/34 PASS; negative controls 146/146 fail as required

**Re-based:**
- **A24:** r4.13 source, package and the r4.12/r4.11/r4.10 bases; the manifest identity chain r4.11 → r4.12 → r4.13; the r13, r15, r16 and r17 checker records.
- **A25:** equality with the r17 registry as in §2. For the three receipt-only records the gate requires that only `fields['Review receipt']` and `prior_review_receipt` change and that the new receipt starts with the old one plus the revision tag. For F3-N7N8 it requires the field set in §2 and nothing else.
- **A28:** equality with the r17 matrix; rows differ only by `path_in_r4_13_package`; owner catalog equal including its checked date.
- **A31 / A32:** unchanged in substance; they now locate the r17 watch item by prefix instead of taking the last item.

**New:**
- **A33:** the F3-N7N8 parse change exactly as accepted: claim lines 3 → 2, the `[NUM]` line byte-identical, the first `[ALG]` line formal with no infrastructure text, unclassified +4 / −1 with the named lines, the status field containing the moved sentences and the B-08 classification, the Constraints cell including the Q_s bound unchanged, adoption PENDING.
- **A34:** the four changed records carry the pinned B-07 / B-08 decision hashes with their stated outcomes (ACCEPT SCOPED ×3; CORRECTION REQUIRED applied, INSUFFICIENT EVIDENCE items present); `prior_review_receipt` equals the Review receipt everywhere; the 16 other records equal r17; adoption PENDING everywhere.

**Controls:** 128 tampers plus 18 file and input controls. The r17 A24/A25/A28 controls are retired and replaced. New ones include:
- the source recorded as r4.11 or r4.12; the r4.12 base dropped;
- the r17 F3-N7N8 or FORMAL-INVOLUTION record re-used; the F3 grade, task, contract, import or OPEN item changed; a receipt rewritten instead of appended; a fifth record, a gap entry or the source table changed;
- the r17 matrix rows re-used; a silent owner byte-evidence upgrade; the catalog checked date changed without a catalog delta;
- the `[NUM]` line altered; infrastructure text put back into the `[ALG]` claim; the status field or the boundary dropped from the machine artifact; the K=6 pilot presented as regional coverage; the Q_s bound edited;
- a B-07 hash dropped; CORRECTION REQUIRED relabelled; INSUFFICIENT EVIDENCE items dropped; an adoption promoted;
- the r17 checker record altered; the B-08 decision file altered.

**Correction made while building:** under the existing control "A3 drop a record", A34 raised an exception instead of failing, because it looked the dropped record up with a bare `next()`. It now tolerates a missing record and fails.

**Clean extraction:** run twice with `python -I -B`; output byte-identical to the stored `check_phaseA_output.txt`; the manifest lists no bytecode cache.

## 6. Open (unchanged)

G9/1 and G9/3 per-reference audits; G2 §5b; the two ER-2B blocks; the regional/global Stage-2 certificate and multi-step error control for F3-N7N8. Optional next catalog step: byte verification and section checks of Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 against their pinned predecessors, if the files are supplied to the preparer.
