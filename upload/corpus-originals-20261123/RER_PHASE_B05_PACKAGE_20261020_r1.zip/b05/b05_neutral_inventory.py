"""Phase B-05 neutral source inventory for the seven author-conflict review items (preparer; mechanical; no assessment).
Inputs: RER r4.6 Markdown (pinned), Phase A r7 SOURCE_CURRENCY_MATRIX.json (pinned), and a read-only hash scan of the preparer's
workspace (loose files and ZIP members) for cited hashes that the matrix does not mark BYTE_VERIFIED_MATCH.
Output: JSON + Markdown tables listing, per record: every Import/reference line (key, cited path, section/lines, cited SHA-256,
Phase A r7 bytes/authentication/status), Review-receipt and Missing-primary-input lines verbatim, OPEN lines verbatim, and
'present in preparer workspace' locations for unverified hashes. It writes no scientific judgement, grade or disposition."""
import sys, os, re, json, hashlib, zipfile, glob
MD = sys.argv[1]; MATRIX = sys.argv[2]; OUT = sys.argv[3]
MD_SHA = '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'
sha = lambda b: hashlib.sha256(b).hexdigest()
mdb = open(MD, 'rb').read(); assert sha(mdb) == MD_SHA
md = mdb.decode(); cm = json.load(open(MATRIX)); assert cm['source_markdown_sha256'] == MD_SHA
ITEMS = [('RER-TRIAD-FORMAL-INVOLUTION', 'whole record'), ('RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'whole record'),
         ('RER-TRIAD-AGE-CURVATURE', 'whole record'), ('RER-TRIAD-FORMAL-AGE', 'whole record'), ('RER-F3-N7N8', 'whole record'),
         ('RER-GEN-K3-MODAL', 'E-conjugacy [ALG] transport step only (owner-import part assessed in Phase B-01)'), ('RER-RRF-CND01', 'whole record')]
lines = md.split('\n')
def span(rid):
    i = next(k for k, l in enumerate(lines) if l.startswith(f'### {rid} — '))
    j = next(k for k in range(i + 1, len(lines)) if lines[k].startswith('### ') or lines[k].startswith('## ') or lines[k].startswith('<a id='))
    return i + 1, j, lines[i:j]
# workspace hash scan
roots = ['/mnt/user-data/outputs', '/mnt/user-data/uploads', '/root/.claude/uploads']
idx = {}
for root in roots:
    for dp, dn, fn in os.walk(root):
        if '/RER_phaseB' in dp: continue
        for f in fn:
            p = os.path.join(dp, f)
            try: b = open(p, 'rb').read()
            except Exception: continue
            idx.setdefault(sha(b), []).append(p)
            if f.endswith('.zip'):
                try:
                    Z = zipfile.ZipFile(p)
                    for n in Z.namelist():
                        if not n.endswith('/'): idx.setdefault(sha(Z.read(n)), []).append(p + '::' + n)
                except Exception: pass
out = {'source_markdown_sha256': MD_SHA, 'matrix_schema': cm['schema'], 'items': []}
for rid, scope in ITEMS:
    a, b, sl = span(rid)
    rows = [x for x in cm['rows'] if x['record'] == rid]
    imps = []
    for x in rows:
        h = x['cited_sha256']; loc = []
        if h and x['bytes_status'] != 'BYTE_VERIFIED_MATCH': loc = sorted(set(idx.get(h, [])))[:3]
        imps.append({'n': x['n'], 'key': x['key'], 'cited_path': x['cited_path'], 'section_or_RID': x['section_or_RID'], 'lines': x['lines'],
                     'cited_version': x['cited_version'], 'cited_sha256': h, 'bytes_status': x['bytes_status'], 'authentication': x['authentication'],
                     'phaseA_status': x['status'], 'currency': x['currency'], 'present_in_preparer_workspace': loc})
    verb = lambda pfx: [l for l in sl if l.startswith(pfx)]
    out['items'].append({'record': rid, 'inventory_scope': scope, 'md_lines': [a, b], 'record_sha256_of_span': sha('\n'.join(sl).encode()),
                         'primary_grade_line': next((l for l in sl if l.startswith('**Primary grade:**')), None),
                         'imports': imps, 'review_receipt_lines': verb('**Review receipt:**'), 'missing_primary_input_lines': verb('**Missing primary input:**'),
                         'open_lines': verb('[OPEN]'), 'evidence_line': verb('**Evidence:**')})
json.dump(out, open(OUT + '.json', 'w'), ensure_ascii=False, indent=1)
L = ['# RER Phase B-05 — neutral source inventory for author-conflict review items', '',
     f'Generated mechanically by `b05_neutral_inventory.py` from RER r4.6 (`{MD_SHA}`) and the Phase A r7 matrix (`{cm["schema"]}`).',
     'It lists identities, byte status and cited ranges only. **No scientific judgement, grade or disposition is expressed.**', '']
for it in out['items']:
    L += [f"## {it['record']}", '', f"- Inventory scope: {it['inventory_scope']}", f"- RER r4.6 lines {it['md_lines'][0]}–{it['md_lines'][1]}; SHA-256 of the record span `{it['record_sha256_of_span']}`",
          f"- Primary grade line (verbatim): {it['primary_grade_line']}", '',
          '| # | Key | Cited path | Section / lines | Cited SHA-256 | Bytes (Phase A r7) | Authentication | Status | Present in preparer workspace (unverified rows only) |', '|---|---|---|---|---|---|---|---|---|']
    for i in it['imports']:
        L.append(f"| {i['n']} | `{i['key']}` | `{i['cited_path']}` | {i['section_or_RID']} {i['lines'] or ''} | `{(i['cited_sha256'] or '—')[:16]}…` | {i['bytes_status']} | {i['authentication']} | {i['phaseA_status']} | {'; '.join('`'+p.replace('/root/.claude/uploads/08b30b17-322e-5f2b-9314-756a53a6b667/','uploads/').replace('/mnt/user-data/','')+'`' for p in i['present_in_preparer_workspace']) or '—'} |")
    for k, t in (('review_receipt_lines', 'Review receipt'), ('missing_primary_input_lines', 'Missing primary input'), ('open_lines', 'OPEN lines'), ('evidence_line', 'Evidence line')):
        if it[k]: L += ['', f'**{t} (verbatim):**', ''] + [f'> {l}' for l in it[k]]
    L.append('')
open(OUT + '.md', 'w').write('\n'.join(L) + '\n')
print('items', len(out['items']), 'rows', sum(len(i['imports']) for i in out['items']))
