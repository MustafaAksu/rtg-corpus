"""Phase B-05: editorial history of the RER-DYAD-FORMAL-INVOLUTION record across RER v0.2 DRAFT r4..r4.6.
Mechanical: for each revision, extract the record span (from its heading to the next '<a id=' anchor), hash it,
print the Carrier cell verbatim and a unified diff of the record against the previous revision. Args: pairs label=path."""
import sys, hashlib, difflib, json, re
revs = [a.split('=', 1) for a in sys.argv[1:]]
out = {}; prev = None
for lab, p in revs:
    b = open(p, 'rb').read(); L = b.decode('utf-8').split('\n')
    i0 = next(i for i, l in enumerate(L) if l.startswith('### RER-DYAD-FORMAL-INVOLUTION'))
    i1 = next(i for i in range(i0 + 1, len(L)) if L[i].startswith('<a id='))
    span = L[i0:i1]; txt = '\n'.join(span)
    car = next(l for l in span if l.startswith('| Carrier |'))
    rec = {'file_sha256': hashlib.sha256(b).hexdigest(), 'lines': [i0 + 1, i1], 'record_sha256': hashlib.sha256(txt.encode()).hexdigest(),
           'carrier_sha256': hashlib.sha256(car.encode()).hexdigest(), 'carrier': car}
    if prev is not None:
        rec['diff_vs_prev'] = [d for d in difflib.unified_diff(prev[1], span, prev[0], lab, n=0, lineterm='') if not d.startswith('@@')]
    out[lab] = rec; prev = (lab, span)
    print('==', lab, rec['file_sha256'][:16], 'lines', rec['lines'], 'record', rec['record_sha256'][:16], 'carrier', rec['carrier_sha256'][:16])
    print(car)
    for d in rec.get('diff_vs_prev', []): print('   ', d[:400])
json.dump(out, open('b05_carrier_history.json', 'w'), indent=1, ensure_ascii=False)
