# RER v0.2 DRAFT r4.4 — Phase A receiving review

**Date:** 19 October 2026  
**Role:** independent receiving co-owner; review/verification, NOT owner adoption or registry freeze.  
**Object:** `RER_PHASEA_PACKAGE_20261019.zip` — SHA-256 `cdb5368253cbb3585717549c7ab54a243b7731e4d95a357f192754ea58b4c61c`.  
**Source Markdown:** `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_4.md` — SHA-256 `5df4738685ecebf979da4f48d432ef2f9af01b6964dfefb62d7ac31887caa9d8`.

## Decision

**Phase A mechanical delivery: ACCEPT SCOPED. Full source-coverage/currency closure: REQUEST TWO REPAIRS (A-P1 and A-P2).** Phase B may begin on records whose primary evidence is available and separately authenticated; Phase A must not be described as full pin-closure, RER adoption or RRF interface acceptance. The last two ER-2B records remain blocked. All 20 scientific records remain `PENDING`.

## Verification executed

- Unzipped to a clean local directory, checked all **39/39** `SHA256SUMS.txt` payload hashes; no mismatches.
- Ran `python -I check_phaseA.py --tamper`: **14/14 PASS**, **8/8** named negative controls rejected as intended.
- Copied source into a new isolated directory, removed `out/`, ran `python -I build_phaseA.py` then the checker: exit 0; **5/5 generated outputs byte-identical** with supplied outputs.
- Independently compared Phase A Markdown to the r4.4 ZIP's Markdown: byte-identical. Re-hashed r4.4 ZIP: `0c08ae639f0104eb373d48e92d7a84051ba2b8f9f99841fb17edb7069534f91f`.
- Registry machine inventory: 20 active-contract records, 4 separately tagged gap entries G7–G10, 16 historical legacy v0.1 entries, **76 record import occurrences**, with status counts `VERIFIED 23 / OWNER_REPORTED 6 / HISTORICAL 41 / BLOCKED 6` *as emitted by the preparer*. All 20 records remain `adoption_status=PENDING`; two ER-2B records have `BLOCKED_SOURCE_UNVERIFIED` and `accepted_cohort_eligible=false`.
- Seven missing Triadic source files in the previous r4.1–r4.4 ZIPs are included in Phase A and independently byte-matched with corresponding r4 ZIP archive entries (7/7). This repairs their evidence availability in the Phase A delivery, **not** the original cited-path packaging defect of the r4.4 draft.
- Source files directly hash-verified at the receiving side: Triadic v1.6.1 `95340abe...d451f`, Genesis v2.8.8 `9abd3616...0f37`, Dyadic v6.4.15 `be270dde...947c4`, RRF v0.8.3 `b393657e...a187`, OFN v0.9 `5ae8fdab...9795`, ER-2B consolidated v0.3 `80669c69...a134` (NONCANONICAL). Prior pinned owner files Genesis v2.8.7 (`d5d1e57c...e361`), Dyadic v6.4.13 (`5958f7fe...8542`), RRF v0.8.2 (`f09dbb12...5461`) were byte-recovered and verified from an earlier receiving-evidence ZIP.
- Exact section comparisons: Genesis v2.8.7 to v2.8.8 **§§6.3a–6.3b byte-identical** (including §6.3a.1 six-step); Dyadic v6.4.13 to v6.4.15 **§§6.15–6.17 byte-identical**. No all-document byte equivalence is claimed. RRF v0.8.3 §6.2 is **not** byte-identical with v0.8.2: it incorporates the exact smooth clock bridge for existing objects; owner-side scope remains nonphysical.

## Receiving findings

### A-P1 — Live provenance sentence is stale (minor content correction; must close before RER release)

`RER-TRIAD-BIRTH-GRAPH-INVOLUTION`, current (d) paragraph, **r4.4 Markdown line 951**, still ends: `Triadic v1.6.1 DRAFT r1 (D3) records the same conditionality on the Triadic side; it is a draft, not an adopted owner source.` Yet line 971 and r4.4 header correctly cite **ADOPTED Triadic v1.6.1**, source SHA `95340abe...d451f`. This is a current-use statement, not a clearly delimited historical quote. Correction should cite the adopted version and distinguish its conditional D3 scope from the independently pending RER (d) graph contract. Suggested wording:

> Adopted Triadic v1.6.1 (§6.1, §6.15, §6.17.2, §7.2, CN-02) states the complete-child remainder and full-child phase/ratio estimates conditionally on Genesis GCL-06 and the selected child functional. It does not adopt the RER formal-involution graph or select the physical p=4 / p≥5 branch. The prior DRAFT r1 reference is historical.

Do not rewrite the original r4.4 Markdown in Phase A; fix by an exact-once, reviewed subsequent draft edit and add a point-of-use stale-status negative gate.

### A-P2 — Source-currency inventory omits gap references (Phase C interface coverage)

`SOURCE_CURRENCY_MATRIX` has **76 import occurrences in 20 record bodies**. The four `RER-G7`–`RER-G10` gap blocks contain **13 further `Reference:` lines** not represented as matrix rows (2, 3, 4, 4 respectively). `gap_entries` in REGISTRY JSON contain only IDs, titles and hashes of bodies. The separate machine-readable receiver extraction is `RER_PHASEA_GAP_REFERENCE_CROSSWALK_20261019.json` (13 references; all Phase C dispositions pending).

In RRF v0.8.3 §6.4, the old dynamical-closure taxonomy is a **separate, noncanonical, nonnormative proposal** and §6.4 is a pointer; the live G10 v0.8 §6.4 content citation is not a straightforward same-section repin. The RRF editor's Q3 is necessary. Incorporate a gap-reference source matrix (or explicit annex with checker) in the next Phase A/registry revision and require a written RRF editor disposition.

### A-P3 — Scope of the reverse gate (nonblocking checker clarification)

Checker A4 independently verifies six contract cells, primary grade/task, import **counts** and OPEN **counts**. It does **not** independently compare import text, individual OPEN-item text, all evidence / exactness / non-transfer fields or every record line. A2 deterministically proves that the supplied JSON matches the **same parser** applied to source Markdown; that is meaningful but is not a full second independent parser or literal JSON→Markdown round trip. The builder may remain usable, but document this narrower guarantee, and add fuller field-level validation before adoption.

## Source-access boundary

The candidate matrix has 27 distinct unavailable-to-preparer keys occurring in 53 rows. Of these, `DYAD6413`, `GEN287`, `RRF082`, `OFN9` were separately recovered and byte-matched at the receiving side; **the remainder are not marked newly verified here**. The original ER-2B v0.2 primary package and the two coincidence witness sources were not supplied. ER-2B consolidated v0.3 is noncanonical background; it does not unblock either ER-2B record. The noncanonical `G2NOTE04` has no recorded SHA-256; it must be labelled as unauthenticated reference unless its identity is supplied.

The recorded RRF v0.8.3 is a working representation standard, not a RER-science owner and not a physical realization. The conditional fixed-set implication belongs to standard equivariance algebra: `Fσ=σF` and `σx=x` imply `σ(Fx)=F(σx)=Fx`. This does not authenticate the coincidence witness or choose a physical node action.

## Phase B routing

| Route | Count | Records |
|---|---:|---|
| Deep claim/source review | 13 | RER-GEN-C01–C09; RER-TRIAD-FORMAL-AGE; RER-TRIAD-AGE-CURVATURE; RER-TRIAD-REGULAR-3FOLD; RER-RRF-CND01 |
| Claim-level verification with prior receipt | 5 | RER-F3-N7N8; RER-GEN-K3-MODAL; RER-DYAD-FORMAL-INVOLUTION; RER-TRIAD-FORMAL-INVOLUTION; RER-TRIAD-BIRTH-GRAPH-INVOLUTION |
| Blocked pending primary owner source | 2 | RER-ER2B-T6D; RER-ER2B-CARRIER |

The two Triadic formal/involution records written by the preparer require receiving/non-author scientific disposition; prior `ACCEPT SCOPED` entries are neither RER owner adoption nor a substitute for that conflict rule. The Stage-2 pilot and scoped lemma review are NOT regional/global certificates; live A1 contract installation remains separately pending.

## RRF editor handoff (not sent)

The supplied `RRF_EDITOR_QUESTION_PACKET_RER_PHASEA_20261019.md` contains Q1–Q8. Forward that unchanged text through the PI, accompanied by A-P2 and the 13-reference gap crosswalk. The receiving inspection supports treating v0.8.3 §6.4 as a pointer and preserving nonnormative status, but cannot preempt the RRF editor's written Q1–Q8 decisions. No RRF edit or authorization is inferred.

**Bottom line:** mechanical candidate **PASS**; complete source-currency/RRF interface **OPEN** with A-P1 and A-P2 repairs. Phase B may proceed in parallel at its source-access boundaries. No RER adoption, freeze, owner regrade, new G6 result, degree-7 graph result or Stage-2 regional sweep was performed.
