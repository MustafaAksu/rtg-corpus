# RRF editor: question packet from RER Phase A

**Date:** 19 Oct 2026.
**From:** Claude, RER co-owner (preparer).
**Status:** NONCANONICAL. A request for written dispositions. It changes no RRF text and asks for no RRF adoption.
**Object:** RER v0.2 DRAFT r4.4 (`5df47386…a9d8`): the gap entries G7–G10 and the record RER-RRF-CND01.
**Current RRF:** v0.8.3, adopted working standard (`b393657e…a187`). RER still cites v0.8 (`c4ec1f10…2b44a`) as its section pin.

Each question can be answered with one word plus at most one sentence. The answers become the written RRF interface resolution that the receiving co-owner requires before release (decision record §IV).

## A. Section pins (v0.8 → v0.8.3)

**Q1.** G7, G8 and CND01 cite v0.8 §6.2 (`RRF-CND-01`, lines 333–349), and G8 cites §0.3. Is the v0.8.3 text of §6.2 and §0.3 an **acceptable successor pin** for these RER statements?
The v0.8.3 §6.2 adds the regularity/clock declaration and the DYAD F1 reference. The four-predicate distinction RER relies on is unchanged.
Answer: SAME-SCOPE / CHANGED-SCOPE (name the change).

**Q2.** G9 cites v0.8 §4.2a and §6.3. Same question for v0.8.3.

**Q3.** G10 cites v0.8 §6.4 (lines 366–390), the "OPTIONAL / PROPOSED dynamical-closure evaluation contract". In v0.8.1 and later, that content was moved to the separate noncanonical file `RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md`. §6.4 is now only a pointer.
Should RER:
- (a) keep the v0.8 pin as history and cite the proposal file for the closure taxonomy; or
- (b) cite only v0.8.3 §6.4 (pointer, non-normative)?

The RER line "the §6.4 FORMAL_ONLY wording needs interface clarification" would then refer to the proposal file, not to the working standard. Please confirm.

## B. Status of RER relative to RRF

**Q4.** Please confirm that RER's closure proposal remains **NON-NORMATIVE** under v0.8.3. That is:
- RER adoption does not make K_closure, the closure taxonomy or a FORMAL_ONLY tag a compulsory RRF profile field;
- RER adoption does not make them a physical test.

**Q5.** RER uses `RRF-DYAD-W` (and §2.4b) as the carrier label for RER-DYAD-FORMAL-INVOLUTION and for the Triadic involution records. RER uses `RRF-NET-W-RAW` only as the provisional network lock. Is this use correct under v0.8.3, given that the `RRF-DYAD-W → RRF-NET-W-RAW` bridge is OPEN?

## C. RER-RRF-CND01 ownership split

The record carries `[THM] EXACT_CONDITIONAL` for `Fσ = σF ⇒ F(Fix σ) ⊆ Fix σ`.

**Q6.** RER will attribute this `[THM]` to **RER-native standard mathematics** (deterministic equivariance). RER will attribute the contract structure (Identity–Action, Carrier–Encoding, Clock–Model, separate Merge) to RRF v0.8.3 §6.2 as a **[DEF] proposed interface**. RRF is not the source of the theorem grade. Does RRF agree with this split?

**Q7.** The coincidence noninvariance witness is the secondary-report boundary in CND01. It is cited from the RRF coincidence response v0.2, the ER-2B coincidence audit and ER-2B v0.2. Does RRF hold the primary bytes of any of these? If it does, a hash would let RER authenticate the item. If it does not, RER keeps the witness as an unauthenticated secondary report.

## D. Items RER will not change without RRF

**Q8.** Physical OPEN-A/B/E1/E2 and OPEN 20 (B-an, B-6, B-∞ existence) stay open in RER. Is there any RRF v0.8.3 statement that RER currently understates or overstates? A list of line numbers is enough.

## What RER does with the answers

- **SAME-SCOPE answers:** a pointer-only repin in the next draft. No grade change.
- **CHANGED-SCOPE answers, or a disagreement on Q4–Q6:** a scoped revision, reviewed by the receiving co-owner before any release.

Nothing in this packet adopts, freezes or publishes RER or RRF.
