# RER Phase B-06 — neutral review packet

RER Phase B-06 neutral review packet (NONCANONICAL; preparer Claude, RER co-owner). Verbatim quotations of byte-pinned sources, provenance-labelled proof material and questions; no PASS/FAIL, grade or acceptance recommendation is given for any claim.

**Review (receiver decides per record or claim: ACCEPT SCOPED, CORRECTION REQUIRED, INSUFFICIENT EVIDENCE):** `RER-RRF-CND01`, `RER-DYAD-FORMAL-INVOLUTION`, `RER-TRIAD-FORMAL-AGE`
**CONTEXT_ONLY — NOT REVIEWED IN B-06:** `RER-TRIAD-FORMAL-INVOLUTION`, `RER-TRIAD-BIRTH-GRAPH-INVOLUTION`

**Currency note:** Dyadic v6.4.19 owner-reported adopted 20 Oct 2026 (40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9, release record claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md); bytes not held; Phase A r16 lists v6.4.18 as current. Not part of B-06.

## RER-RRF-CND01

RER r4.10 lines 772–812; span SHA-256 `0269bb3479f67f331fe47b2fdfa3502d961ee0798c5536fef528602813245c15`.

### Record text (verbatim)

```
### RER-RRF-CND01 — Complete-state exchange-fixed admissibility, not coordinate coincidence
**Primary grade:** [THM]. **Exactness:** `EXACT_CONDITIONAL`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none.

| Field | Contract |
|---|---|
| Carrier | complete state X with a fixed-model involution sigma; conditional encoded carrier C; ABSTRACT_FULL_STATE_ADMISSIBILITY; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | exchange-fixed status; declared carrier coincidence predicate; merge only if separately defined |
| Constraints | Invariant complete-state domain; deterministic F_phys and F_phys sigma=sigma F_phys; Coordinate equality, zero edge, exchange-fixed full state and physical node merge are different predicates.; Physical exclusion additionally needs an actual admissible fixed-state witness and both action/map intertwining relations. |
| Transformation law | Encode E sigma=R E and E F_phys=K E at the same clock. Transport K, coincidence set and action jointly under passive charts. |
| Closure status | GENERAL_FIXED_SET_THEOREM_PHYSICAL_APPLICATION_OPEN: Fixed-set preservation follows from deterministic fixed-model equivariance. The physical applicability of a projected counterexample requires the complete identity/encoding/clock bridge and cannot be supplied by a carrier coincidence alone. |
| Memory | Complete state must contain all transition-relevant variables, including admitted history if required by the source. The fixed-set theorem does not force or exclude a memory carrier. Use the stated observation task and source contract; no memory/age carrier added. |

[THM] **EXACT_CONDITIONAL.** Fixed-set preservation follows from deterministic fixed-model equivariance. The physical applicability of a projected counterexample requires the complete identity/encoding/clock bridge and cannot be supplied by a carrier coincidence alone.
Formula/witness: `F sigma=sigma F => F(Fix sigma) subset Fix sigma`.

**Domain / admissibility:** Complete-state invariant domain for the abstract lemma; physical realization/domain/clock not selected.

**Map / clock:** `F_phys:X->X conditional deterministic fixed-model equivariant update; encoded K and shared clock not constructed here`; physical/test clock must match through E F_phys=K E; none selected.

**Factor or parametrization tested:** E: physical complete state to carrier, NOT a constructed map here.

**Order / error:** exact fixed-set implication; conditional carrier diagnostics are separate source-reported claims. No numerical radius or authenticated direct coincidence-certificate replay here.

**Contract type:** `CONDITIONAL_ADMISSIBILITY_DIAGRAM_NOT_FACTOR`.

**Evidence:** original scientific source pins and earlier verification scopes are retained from r2. R3 checks the changed source/wording interfaces and separate Stage-2 metadata behavior; no historical mathematical certificate is rerun.

Import/reference: [OFN9: 8. Dyad-vs-Triad Primacy (O1 Unresolved)](sources/current/RTG_ONTOLOGICAL_FOUNDATIONS_v0_9.md); lines 541–557; RID unavailable; exact section pinned; SHA-256 `5ae8fdabad35a370f5709afa4d5dca6491e154c75f8a6f15fbb32d251fe59795`.
Import/reference: [OFN9: 12.4 FMS Handoff Disposition and Outstanding Requests](sources/current/RTG_ONTOLOGICAL_FOUNDATIONS_v0_9.md); lines 1186–1205; RID unavailable; exact section pinned; SHA-256 `5ae8fdabad35a370f5709afa4d5dca6491e154c75f8a6f15fbb32d251fe59795`.
Import/reference: [RRF08_ADOPTED: 6.2 `RRF-CND-01` — coincidence realization admissibility (PROPOSED INTERFACE ONLY)](sources/current/RTG_RRF_REPRESENTATION_REGISTRY_v0_8.md); lines 333–349; local RRF-CND-01; SHA-256 `c4ec1f10da0cdf3b95a84b3013909e04db49212e0119b858c170e5fd8f42b44a`.
**Missing primary input:** `RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md`; r4.6: SHA-256 `897bfad065aa20c995b471c09cab564d4c1b6ac610769ae5b3f0fa1eb401126d` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED; Q7); bytes not inspected by the RER preparer or receiver. Secondary references do not authenticate it.
**Missing primary input:** `ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip`; hash unknown in this session; r4.6: no hash recorded by RRF either (Q7); provenance and execution unverified. Secondary references do not authenticate it.
**Missing primary input:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`; r4.6: SHA-256 `ea26d3d1a4853ac88d1938dcb66c76eda4d55980ebf6f4d61091b97d67b2bb5e` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED; Q7; the same identity is source-reported by ER-2B consolidated v0.3 Part A.6); bytes not inspected by the RER preparer or receiver; the v0.2 evidence package remains absent. Secondary references do not authenticate it.
**Secondary-report boundary:** Specific projected K3 coincidence embedding is reported noninvariant at primitive and six-step clocks; not imported as a physically excluding theorem. Direct original source/certificate verification remains pending.
[OPEN] physical fixed-state encoding, shared clock and merge law; RRF OPEN-A/B/E1/E2 unchanged
[OPEN] direct authentication of RRF draft referenced conditional coincidence counterexample

[DEF] **r4.6 current-use overlay (RRF editor Q1, Q6, Q7).** The frozen r3.1 contract above is read as follows. Provenance split (Q6 confirmed): the theorem-grade implication `F sigma=sigma F => F(Fix sigma) subset Fix sigma` is RER-native standard mathematics (deterministic equivariance), stated generally; the Identity–Action / Carrier–Encoding / Clock–Model / separate-Merge structure is the RRF v0.8.3 §6.2 proposed interface (definition grade) (CHANGED-SCOPE from v0.8, `b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187`), which is not the source of the theorem grade. For the physical specialization, a physical coincidence exclusion requires a realization contract that declares: (i) the complete physical state, including all transition-relevant data; (ii) σ as the node exchange acting on that complete state — an edge-slot permutation, a zero edge or equal coordinates do not qualify; (iii) F as the same selected full update, with Fσ = σF for that update; (iv) the encoding/action intertwining Eσ = RE and EF = KE at one shared clock; (v) an actually admissible fixed-state witness; and (vi) explicit `regularity:`, `clock:` and `domain:` declarations. The specialization does not replace the general statement and asserts no realization. Q7 source custody: see the missing-input lines below; bytes byte-hashed by the RRF editor are `RRF_EDITOR_VERIFIED`, which is distinct from inspection by the RER preparer or receiver, from certificate replay and from physical admissibility.
**Next test:** Supply complete state/action/encoding/physical clock and genuine admissible witness. Obtain missing source-specific coincidence response/certificate if numerical/polynomial witness is imported.

**Non-transfer:** No new independent state datum, physical emergence, compulsory historical memory, or physical age variable is established. No automatic RRF registration, universal model exclusion or scientific-owner adoption.
```

### Imports (Phase A r16)

| n | Key | Cited | Section / lines | Bytes | Authentication | Status |
|---|---|---|---|---|---|---|
| 0 | `OFN9` | 0.9 `5ae8fdabad35` | 8. Dyad-vs-Triad Primacy (O1 Unresolved) [541, 557] | PRINTED_ONLY | RECEIVER_BYTE_VERIFIED | HISTORICAL |
| 1 | `OFN9` | 0.9 `5ae8fdabad35` | 12.4 FMS Handoff Disposition and Outstanding Requests [1186, 1205] | PRINTED_ONLY | RECEIVER_BYTE_VERIFIED | HISTORICAL |
| 2 | `RRF08_ADOPTED` | 0.8 `c4ec1f10da0c` | 6.2 `RRF-CND-01` — coincidence realization admissibility (PROPOSED INTERFACE ONLY) [333, 349] | PRINTED_ONLY | HASH_PRINTED_UNVERIFIED | HISTORICAL |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| the implication F sigma = sigma F => F(Fix sigma) ⊂ Fix sigma | RER record text (r4.10) | PREPARER_AUTHORED (RER record); the record states the formula; it contains no written proof |
| RRF v0.8.3 §6.2 interface (Identity–Action / Carrier–Encoding / Clock–Model / Merge) | X-CND-1 | OWNER (RRF), HELD (b393657e…a187) |
| RRF editor response v0.2 Q6 (provenance split) | X-CND-2 | RRF EDITOR, HELD (413a869b…3084) |
| OFN v0.9 §8 and §12.4 (lines 541–557, 1186–1205) | import rows n=0,1 | NOT_HELD — identity as stated by its owner; bytes not in this packet; Phase A r16: RECEIVER_BYTE_VERIFIED, HISTORICAL |
| RRF v0.8 §6.2 (lines 333–349) | import row n=2 | NOT_HELD — identity as stated by its owner; bytes not in this packet; Phase A r16: HASH_PRINTED_UNVERIFIED, HISTORICAL |
| RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md | Missing primary input | NOT_HELD — identity as stated by its owner; bytes not in this packet (897bfad0…126d, RRF_EDITOR_VERIFIED) |
| ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip | Missing primary input | NOT_HELD — identity as stated by its owner; bytes not in this packet (no hash recorded) |
| RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md | Missing primary input | NOT_HELD — identity as stated by its owner; bytes not in this packet (ea26d3d1…5e, RRF_EDITOR_VERIFIED) |

### Questions for the receiver (no answer is implied)

- **Q-CND-1** (General theorem): The [THM] line states the implication `F sigma=sigma F => F(Fix sigma) subset Fix sigma` and attributes it to "deterministic fixed-model equivariance"; the record gives no written proof. Which hypotheses does the implication use — F single-valued on X, sigma a map of X, F(X) ⊂ X, F sigma = sigma F on all of X or only on Fix sigma — and which of them are stated in the Constraints cell ("Invariant complete-state domain; deterministic F_phys and F_phys sigma=sigma F_phys") and the Domain field?
- **Q-CND-2** (General theorem): Is "invariant" in "Complete-state invariant domain" meant as F(X) ⊂ X, sigma(X) = X, or both, and does the implication need sigma to be an involution (the record says "fixed-model involution sigma")?
- **Q-CND-3** (Grade attachment): The overlay (RRF editor Q6, X-CND-2) attaches the theorem grade to the implication only and the interface structure (RRF v0.8.3 §6.2, X-CND-1) to definition grade. Do the record-level grade [THM] and Exactness `EXACT_CONDITIONAL` read consistently with that split, and what is the "condition" in EXACT_CONDITIONAL?
- **Q-CND-4** (G2 / physical application (separate from the theorem)): The Closure cell says `GENERAL_FIXED_SET_THEOREM_PHYSICAL_APPLICATION_OPEN`, and the overlay lists six realization-contract items (i)–(vi). Does any line of the record assert one of (i)–(vi) for a specific model, clock or carrier? The Map/clock and Factor fields say E, K and the shared clock are "not constructed here".
- **Q-CND-5** (Missing inputs): Three primary inputs are missing (coincidence response v0.2, six-step audit zip, ER-2B v0.2) and the "Secondary-report boundary" line keeps the K3 coincidence report unimported. Does any claim line of the record depend on them?

### Source extracts (verbatim)

#### X-CND-1 — RRF v0.8.3 §6.2 RRF-CND-01 proposed interface (definition grade per RRF editor Q6); the r4.6 overlay cites v0.8.3 §6.2

`sources/owner/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md` lines 391–410; extract SHA-256 `f8d1e9566e8a478e0ad9d80c7a89099b557c67912aa0ed8e706b54e3429454c3`

```
### 6.2 `RRF-CND-01` — coincidence realization admissibility (PROPOSED INTERFACE ONLY)

**Status:** `[DEF] [scope: noncanonical interface proposal; RRF/OFN ACCEPT SCOPED; not an adopted physics choice]`. This registry records **representation and admissibility contracts, not proofs or polynomial-jet tables**. The general exchange-fixed lemma remains mathematical source background and the primitive/six-step coincidence counterexample belongs to ER-2B and the two RRF/OFN coincidence reviews; their proofs, exact coefficients and execution provenance are **not reproduced or owned here**.

Four notions must remain distinct: **equal node coordinates**, **zero edge relation**, **exchange-fixed complete configuration**, and **node merge / lower-cardinality reduction**. Only a specified complete-state exchange-fixed set is governed by the usual equivariant fixed-set reasoning; merge needs a separate reduction.

| Owner contract | Required object | RRF admissibility gate |
|---|---|---|
| **Identity / Action** | Full physical state `\mathscr X` including transition-relevant incidence, roles, parameters and necessary history; fixed-model exchange action `\sigma_{BC}` and its physically realizable fixed states | State-completeness and **node-exchange** equivariance at the **selected** physical update; an exchange of edge slots need not be the node permutation. Identify the correct complete-state action and its fixed set; do not infer node-fixed semantics from slot symmetry or `r_{BC}=0` |
| **Carrier / Encoding** | Defined encoding `E:\mathscr X\to\mathcal C`, carrier exchange action `R`, candidate coincidence subset `\mathcal D` | `E\sigma=RE`; a **witnessed** mathematical counterexample initial point must lie in `E(Fix\sigma)` (not only in `\mathcal D`) |
| **Clock / Model** | Full physical update `F_{phys}`, conditional projected model `K`, physical strobe and projection cadence | `EF_{phys}=KE` on the applicable domain and relevant states, with compatible exchange/role action; primitive and six-step cadence are not interchangeable |
| **Merge** *(separate)* | If claimed, a specified lower-cardinality carrier, merge map and post-merge evolution | Independently justified commuting reduction; no merge conclusion from coincidence or symmetry alone |

**Source pointers and conditional outcome:** `[import/source: OFN v0.9, complete-state covariance / OPEN-PRIMACY-3B/3C; RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md; RTG_RRF_COINCIDENCE_ADMISSIBILITY_REVIEW_v0_1.md; RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md]`. For the named *raw projected* three-edge map with reprojection **after each primitive step**, the standard additive coincidence embedding has an exact noninvariance witness at primitive (degree 2) and six-step (degree 4) clocks. This is **conditional mathematics**, not automatic physical node-mediated exclusion. The full-state realization/encoding/clock bridge remains `[OPEN]` (OFN 3B/3C and RRF OPEN-B/E1).

**Slot-versus-node guard (cross-stream report; numerical evidence not replayed):** The projected triad may be edge-slot permutation-equivariant and preserve a child-free *slot-fixed* stratum while failing to preserve a *node-coincidence* stratum. Reported odd-twin comparison is diagnostic, not an owner-adopted physical selection; the detailed calculation remains with the external OFN/ER-2B study. A fixed-set or quotient inference requires the action to intertwine the **actual full update** and the proposed coincidence embedding.

**Regularity/clock decision — OPEN-B/E1 and OFN:** The elementary fixed-set implication needs only a defined equivariant map, not analyticity. A $C^\infty$ carrier may be studied as a **candidate**; this does not choose it over an analytic carrier, supply a convergent odd normalizer or make it a physical realization. Explicitly declare `regularity: analytic / C^\infty / formal / other`, valid domain and `clock: primitive T / six-step T^6 / other physical update` in each submitted realization contract. Adopted DYAD v6.4.12 §6.16 now proves **formal** uniqueness for the `F=T^6`-commuting involution, and §6.15(b) constrains even six-step `C³` involution linear parts to `±I`; §6.15 Corollary A promotes a nonidentity **analytic** six-step involution to exact primitive commutation under its local domain hypotheses. For an **existing `C^∞`** involution on DYAD §6.15/§6.17 local domains, adopted F1 upgrades flat primitive commutation to **exact** `RT=TR`; F2 gives uniqueness, and F3 upgrades existing smooth roots. This does **not** supply such an involution/root. For finite `C^r` the exact clock bridge is not imported. **No clock implication identifies** `EF=TE` with `EF=T^6E`; these remain different network-factor hypotheses and physical clock must still be declared. `[import: DYAD v6.4.12 §6.15; RID: DYAD-THM-LOCAL-INVOLUTION-GERM] [import: DYAD v6.4.12 §6.16; RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE] [import: DYAD v6.4.12 §6.15; RID: DYAD-THM-ANALYTIC-CLOCK-BRIDGE] [import: DYAD v6.4.13 §6.17; RID: DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES]

**Passive transport guard:** A true passive recharting transports the *same* model, action and test subset; it cannot change invariance/noninvariance. Reimposing linear closure, replacing the carrier, changing update or selecting another physical clock is a **different model contract** requiring its own admissibility audit. Do not identify `(P_\mathcal C T^{\times3})^6` with `P_\mathcal C (T^6)^{\times3}` without proof of equivalence.
```

#### X-CND-2 — RRF editor response v0.2, Q6 (provenance split)

`sources/rer/RRF_EDITOR_RESPONSE_TO_RER_PHASEA_v0_2_20261019.md` lines 20–20; extract SHA-256 `1d40243258226552e83516e8d11995565d6066543aab5c5b4eace18432a718c3`

```
**Q6 — CONFIRM WITH Q1 QUALIFIER.** The mathematical implication `Fσ=σF ⇒ F(Fix σ)⊆Fix σ` is elementary background, not a newly owned RRF theorem. The `RRF-CND-01` Identity/Carrier/Clock/Merge interface is a proposed contract, not physics adoption. Here σ must be the *node exchange of the complete state* and F the *same full selected update*; a slot permutation or `r_BC=0` is not a substitute.
```

## RER-DYAD-FORMAL-INVOLUTION

RER r4.10 lines 861–902; span SHA-256 `b6da1f0584e6b63eaf08445d360b7a8847d0f0bcd50426f2f25d38409dd432c6`.

### Record text (verbatim)

```
### RER-DYAD-FORMAL-INVOLUTION — Unique formal −I involution of the isolated dyad (owner import)
**Primary grade:** [THM] (owner grade). **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12 (released as v6.4.12.1; retained unchanged in adopted v6.4.13).
**Owner grades per imported RID** (source note; r4.7 content, own line since r4.8; the record-level primary grade above summarizes the principal formal result): `DYAD-THM-FORMAL-INVOLUTION-UNIQUE` [THM], `DYAD-THM-FORMAL-CENTRALIZER` [THM], `DYAD-ALG-CENT-KERNEL` [ALG], `DYAD-THM-ANALYTIC-CLOCK-BRIDGE` `[THM — analytic]`, all formal-category except the analytic bridge. r4.9: `DYAD-THM-SMOOTH-EMBEDDING` [THM] (Dyadic v6.4.18; C^∞ germ scope — neither formal-category nor analytic). The record-level grade, the Exactness `FORMAL_ONLY` and the contract type describe the formal classification only; they do not say that every imported result of this record is formal (the analytic bridge and the C^∞ embedding are not).

| Field | Contract |
|---|---|
| Carrier | Formal germs of the isolated dyad at P1, written in the raw linear frame W=L(rho,eta) (frame of RRF-DYAD-W, RRF v0.8.3 §2.3); R_0 is defined there without a normalizer (DYAD v6.4.13 §6.16). RRF registers the formal involution at RRF-DYAD-NF + §2.4b (formal only); the RRF-DYAD-W relabeling candidate is the finite S_h, equal to R_0 only through jet degree 6. The isolated-dyad W is not the network raw W (RRF-NET-W-RAW provisional; bridge OPEN). r4.6 carrier per RRF editor Q5; r4–r4.5 label was profile RRF-DYAD-W (RRF v0.8.2 §2.3, §2.4b). Not the triad carrier. |
| Observables | Formal state; no comparator privileged. |
| Constraints | F=T^6=id+mu|W|^2 W+O(4) with Re mu != 0 and Im mu != 0; real formal category. |
| Transformation law | R_0=T^3 o F^{-1/2}=h^(-I)h^{-1} for any formal Poincaré–Dulac normalizer h^ with λ-equivariant normal form (owner condition, DYAD v6.4.13 §6.16 Identification; r4.7). R_0 itself is defined without a normalizer. The finite chart S_h=h_6(-I)h_6^{-1} equals R_0 only through jet degree 6. |
| Closure status | FORMAL_UNIQUE: R_0 is the unique formal involution with DR(0)=-I commuting with F; it also commutes with T. The tangent-to-identity formal centralizer of F is {exp(s log F)}. |
| Memory | Formal symmetry; no physical pole exchange and no memory carrier. |

[THM] **FORMAL_ONLY.** `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.16 | RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE, DYAD-THM-FORMAL-CENTRALIZER, DYAD-ALG-CENT-KERNEL]`. Conditional analytic consequence `[§6.15 | RID: DYAD-THM-ANALYTIC-CLOCK-BRIDGE]`: a real-analytic local involution R with R(0)=0 that commutes with T^6 in the sense of the owner's §6.15 domain convention (0 ∈ int D_Φ) and has DR(0)=-I commutes exactly with T on a neighbourhood of 0 (owner hypotheses, r4.7; under the §6.15(b) hypotheses R(0)=0 is automatic).
Formula/witness: `R_0 = T^3 o F^(-1/2)`; `Cent_formal,DG=I(F) = {exp(s X)}`, `X = log F`.

**Domain / admissibility:** Formal; the analytic bridge is local: its hypotheses are R real-analytic, R(0)=0, the owner's §6.15 domain convention and DR(0)=-I (r4.7). The §6.15(b) hypotheses (C^3, R commuting with T^6 on V ⊂ U_T ∪ {0}) are sufficient for R(0)=0 but are not the bridge's own hypotheses. History (r4–r4.6): Formal; the analytic bridge is local under the owner's §6.15(b) hypotheses.

**Map / clock:** T and T^6; the same formal involution is selected for both. The factor contracts E F = T E and E F = T^6 E remain distinct.

**Factor or parametrization tested:** Not a factor; a symmetry classification.

**Order / error:** All formal orders. Convergence: OPEN 20 (`DYAD-OPEN-INVOLUTION-REALIZATION`). r4.9: analytic convergence remains OPEN 20 B-an/B-6; C^∞ existence (not convergence) is CLOSED since Dyadic v6.4.18 (DYAD-THM-SMOOTH-EMBEDDING, qualitative radius).

**Contract type:** `FORMAL_SYMMETRY_CLASSIFICATION`.

**Evidence:** owner theorem SOURCE-READ (project copy); owner-reported certificates `dyad_open19_kernel_check.py` (`1cb40446…291e`) and `dyad_open19_R0_identity_cert.py` (`c8c14442…cf8`), not rerun here; independent polar-coordinate proof of the kernel lemma in the G2 consolidated note v0.4 §2a, SOURCE-READ. r4.7 source-access boundary: that SOURCE-READ receipt is historical (r4 build). The note's bytes are not held by the RER preparer or receiver (G2NOTE04: no hash printed, UNAUTHENTICATED_NO_HASH; G2 §5b carrier identification pending), so it is not a current byte-access claim. The Dyadic owner records this proof as a citation candidate, not an import (DYAD v6.4.12 adoption interface note); the record does not rest on it. RRF v0.8.2 §2.4b records the same import at RRF working-standard scope. r4.9: the DYAD-THM-SMOOTH-EMBEDDING statement, its scope labels and recorded distinctions are SOURCE-READ from the byte-verified v6.4.18 (DYAD6418) and imported at owner grade (receiving decision D-C); the owner's seven SESSION proof records (DYAD-ART-OPEN20-BINF-RECORDS) and checks (DYAD-ART-OPEN20-BINF-CHECKS) are owner-reported, not read or rerun here, and the import is not an independent proof certification.

**Review receipt:** RER editor ACCEPT SCOPED (17 Oct).
Import/reference: [DYAD6413: §6.15, §6.16, §6.17, §2 OPEN 19/20] (project copy `RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md`; not in this package); SHA-256 `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` (owner-verified, as recorded in the Genesis v2.8.8 owner-pass manifest). r4 pinned [DYAD6412_1] v6.4.12.1 `36e7ef58c952f19cd48683c601957f6a01d90c2e2c6f548b28c1707764c5f107`; the four imported RIDs are unchanged in v6.4.13.
Import/reference: [RRF082: §2.4b, §4.2] (sources/current/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md); file hash not printed in the source; header-authenticated only.
Import/reference: [RRF083: §2.3, §2.4b (`RRF-DYAD-NF` row, formal involution)] (project copy `RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md`; not in this package); SHA-256 `b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187` (OWNER-REPORTED via its adoption record, as in the source table). r4.7: the pin for the RRF v0.8.3 sections cited by the r4.6 carrier cell; the RRF082 line above is kept as the r4–r4.5 history pin.
Import/reference: [DYAD6418: §2 OPEN 20, §6.17] (sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md); SHA-256 `f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d` (BYTE-VERIFIED by the RER preparer against the release record, hash receiver-confirmed 20 Oct 2026; section comparison v6.4.17 → v6.4.18: §2 OPEN 19, §6.15, §6.16 identical, §2 OPEN 20 and §6.17 changed, receiver-accepted). r4.9: pin for the v6.4.18 results only (DYAD-THM-SMOOTH-EMBEDDING and the OPEN 20 status); the DYAD6413 line above stays the pin for §6.15, §6.16, Lemma F and F1–F3.
[OPEN] OPEN 20 B-an: convergence of R_0, equivalently of F^{1/2}.
[OPEN] OPEN 20 B-6 (v6.4.13): convergence of F^{1/6}, equivalently of the formal Z_6 generator J = T∘F^{-1/6} or of an exactly λ-equivariant analytic chart; B-6 ⇒ B-an.
[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18 §6.17, §2 OPEN 20 | RID: DYAD-THM-SMOOTH-EMBEDDING]` (r4.9; owner grade [THM] at C^∞ germ scope: C^∞ local germs at P1, raw frame W, lifted chart) OPEN 20 B-∞ existence is CLOSED at the owner (Dyadic v6.4.18). (E1) On a ball U* = B(0, r'') there is a C^∞ vector field X with j^∞X = log F and F = φ^1_X. (E2) X is unique only among C^∞ generators X' with DX'(0) = 0 (uniqueness among all C^∞ generators of F is not claimed). (E3) For every m ≥ 1, K_m = φ_X^{1/m} is the unique C^∞ tangent-to-identity root with K_m^m = F, and it commutes with T. (E4) J = T∘K_6^{-1} satisfies J^6 = id, DJ(0) = A, JT = TJ; R = T^3∘K_2^{-1} is a C^∞ local involution with DR(0) = −I and RT = TR, unique by F2, satisfying the §6.15 domain convention with V = B ∩ R^{-1}(B). The radius r'' is qualitative; no numerical radius and no finite-C^k constant is imported. The owner's proof route is Φ_∞ = lim G_∞^{-n} F^n (G_∞ the Borel time-one map, unrelated to G = J^2); the earlier route F^{-n} R_∞ F^n stays unproved. C^∞ existence is not analytic convergence: B-an and B-6 stay OPEN (lines above). Imported at owner grade from the byte-verified owner statement; the owner's proof records are not independently reviewed here. r4.8's line "[OPEN] OPEN 20 B-∞ existence: a C^∞ local involution with DR(0) = −I commuting with T (equivalently a C^∞ tangent-to-identity square root of F)." is superseded.
[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 | RID: DYAD-CAND-FLAT-CENTRALIZER, DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES]` (r4.1, erratum E1) OPEN 20 B-∞ flat uniqueness is CLOSED at the C^∞ scope for existing objects: Lemma F [THM]; F1–F3 [THM — conditional] on Lemma F and on existence. An existing C^∞ local involution R with R(0) = 0, RF = FR in the sense of the owner's §6.15 domain convention, and DR(0) = −I commutes with T near 0 and is unique (F1, F2; r4.7 carries these owner hypotheses). Lemma F itself is stated on a forward-invariant ball B_r ⊂ {Q ≤ 1/400} under a flat-contact hypothesis. F1–F3 themselves assert no existence (owner grades unchanged in v6.4.18); since Dyadic v6.4.18 the existence of the objects they concern — the roots K_m, J and R — is supplied at owner level by DYAD-THM-SMOOTH-EMBEDDING E1–E4 (owner §6.17 recorded distinction (iv); line above), so F1–F3 apply to them (r4.9; r4.1–r4.8: "No existence is asserted"). The RID word CAND is an identifier, not a status. r4's line "[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness" is superseded. Not transferred to the triad: Lemma F uses the isolated-dyad contraction DYAD-THM-PRIM-CTR; G6 is OPEN and no triad contraction theorem exists.
[OPEN] Physical exchange (RRF OPEN-A).

**Next test:** None in RER; owner import.

**Non-transfer:** No triad statement follows (see RER-TRIAD-FORMAL-INVOLUTION). No physical pole exchange. S_h is not upgraded beyond degree 6. r4.9: the C^∞ embedding (E1–E4) is not transferred either: its proof uses the isolated-dyad contraction DYAD-THM-PRIM-CTR, and nothing follows for Triadic G6, for analytic convergence (B-an, B-6), for physical pole exchange or for the G2 carrier map.
```

### Imports (Phase A r16)

| n | Key | Cited | Section / lines | Bytes | Authentication | Status |
|---|---|---|---|---|---|---|
| 0 | `DYAD6413` | 6.4.13 `5958f7fe8a3e` | §6.15, §6.16, §6.17, §2 OPEN 19/20  | PRINTED_ONLY | RECEIVER_BYTE_VERIFIED | HISTORICAL |
| 1 | `RRF082` | 0.8.2 `f09dbb12f4b6` | §2.4b, §4.2  | PRINTED_ONLY | RECEIVER_BYTE_VERIFIED | OWNER_REPORTED |
| 2 | `RRF083` | 0.8.3 `b393657e75e7` | §2.3, §2.4b (`RRF-DYAD-NF` row, formal involution)  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 3 | `DYAD6418` | 6.4.18 `f70308f19f59` | §2 OPEN 20, §6.17  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| Dyadic §2 OPEN 19/20, §6.15–§6.17 text at v6.4.18 | X-DYAD-1…5 | OWNER (Dyadic), HELD (f70308f1…458d). The RER pin DYAD6413 (v6.4.13, 5958f7fe…8542) is NOT_HELD — identity as stated by its owner; bytes not in this packet; byte identity of these blocks is preparer- and receiver-checked only for v6.4.16 → v6.4.17 (5/5) and v6.4.17 → v6.4.18 (OPEN 19, §6.15, §6.16 identical; OPEN 20, §6.17 changed by additions); v6.4.13 → v6.4.16 is not byte-checked by the preparer |
| §6.16 proof record DYAD_OPEN19_FORMAL_CENTRALIZER_PROOF_SESSION.md v1.2 | X-DYAD-6 | NOT_HELD — identity as stated by its owner; bytes not in this packet |
| kernel and boundary check scripts (DYAD-ART-OPEN19-KERNEL) | X-DYAD-7 | NOT_HELD — identity as stated by its owner; bytes not in this packet; Phase A key OPEN19CERTS: owner-reported, not rerun |
| R_0 identity certificate and engine (DYAD-ART-OPEN19-R0CERT) | X-DYAD-8 | NOT_HELD — identity as stated by its owner; bytes not in this packet |
| Lemma F proof record v0.3 | X-DYAD-9 | NOT_HELD — identity as stated by its owner; bytes not in this packet |
| smooth-embedding proof records (seven SESSION files) | X-DYAD-10 | NOT_HELD — identity as stated by its owner; bytes not in this packet; project copies with these names exist in the attached project (name match only, bytes not hashed here); written by the Dyadic owner (Claude) and reviewed externally per the owner release record |
| smooth-embedding check scripts and outputs | X-DYAD-11 | NOT_HELD — identity as stated by its owner; bytes not in this packet; project copies of the three scripts exist (name match only) |
| RRF v0.8.3 §2.3, §2.4, §2.4b, §2.4c (carrier frame, NF profile, receipts) | X-DYAD-12…15 | OWNER (RRF), HELD (b393657e…a187) |
| RRF v0.8.2 §2.4b, §4.2 | import row n=1 | NOT_HELD — identity as stated by its owner; bytes not in this packet; Phase A r16: RECEIVER_BYTE_VERIFIED |
| G2 consolidated note v0.4 §2a (independent polar-coordinate proof of the kernel lemma) | Evidence field | NOT_HELD — identity as stated by its owner; bytes not in this packet (no hash printed; UNAUTHENTICATED_NO_HASH); the owner records it as a citation candidate, not an import |
| B-05 reading note and neutral inventory (20 Oct 2026) | sources/history/ | PREPARER_AUTHORED — not receiver evidence; the receiver's earlier disposition covered the inventory as an inventory only, and its corrections to the note became r4.7 O1–O6 |

### Questions for the receiver (no answer is implied)

- **Q-DYAD-1** (Claim A — formal theorems (§6.16)): Compare the Closure cell (FORMAL_UNIQUE: R_0 unique formal involution with DR(0) = −I commuting with F; commutes with T; tangent-to-identity formal centralizer {exp(s log F)}) and the Transformation-law cell with X-DYAD-4. Which owner hypotheses (Constraints: Re mu ≠ 0 and Im mu ≠ 0; real formal category) are used for uniqueness and for the centralizer statement, and are they carried at the point of use?
- **Q-DYAD-2** (Claim A — normalizer identification (r4.7 O1)): The record identifies R_0 = h^(−I)h^(−1) "for any formal Poincaré–Dulac normalizer h^ with λ-equivariant normal form". Where does X-DYAD-4 state this condition, and is R_0 itself defined without a normalizer as the record says?
- **Q-DYAD-3** (Claim A — kernel lemma): `DYAD-ALG-CENT-KERNEL` is graded [ALG] by its owner (source note). Its certificates (X-DYAD-7, X-DYAD-8) are not held; the G2 note proof is unauthenticated. What evidence would the receiver require for the [ALG] kernel statement at import level?
- **Q-DYAD-4** (Claim B — analytic clock bridge (§6.15)): The record states the bridge hypotheses as: R real-analytic, R(0) = 0, the owner's §6.15 domain convention (0 ∈ int D_Φ), DR(0) = −I; it says the §6.15(b) hypotheses are sufficient for R(0) = 0 but are not the bridge's own hypotheses (r4.7 O2). Do these match X-DYAD-3?
- **Q-DYAD-5** (Claim C — C^∞ realization (v6.4.18)): The DYAD6418 [THM] line imports E1–E4 at owner grade (D-C), with E2 restricted to DX'(0) = 0, a qualitative radius and the route G_∞^{−n}F^n. Compare with X-DYAD-5. The proof records (X-DYAD-10) and checks (X-DYAD-11) are not held here: does the receiver review the import as owner-grade fidelity only, or require the proof records?
- **Q-DYAD-6** (Claim C — F1–F3 and Lemma F): The flat-uniqueness line keeps Lemma F [THM] and F1–F3 [THM — conditional] and states that F1–F3 assert no existence themselves while E1–E4 supply the objects. Is the Lemma F scope (forward-invariant ball B_r ⊂ {Q ≤ 1/400}, flat-contact hypothesis) carried as in X-DYAD-5?
- **Q-DYAD-7** (Claim D — G2 carrier map and physical exchange (separate)): The Carrier cell places R_0 in the raw frame W of RRF-DYAD-W and states that the finite S_h equals R_0 only through jet degree 6 and that the isolated-dyad W is not the network raw W. Compare with X-DYAD-12…15. Does any line of the record assert a G2 carrier map or physical pole exchange (the [OPEN] line "Physical exchange (RRF OPEN-A)" and Non-transfer say no)?
- **Q-DYAD-8** (Exactness framing (D-A)): The record keeps [THM] (owner grade) and FORMAL_ONLY at record level while it now also imports an analytic bridge and a C^∞ result; the source note says the record-level labels describe the formal classification only. Is this framing sufficient for the receiver, claim by claim?
- **Q-DYAD-9** (Trail and currency): The record changed in r4.7 (B-05 O1–O6), r4.8 (R10-F1 layout) and r4.9 (v6.4.18 synchronization); r4.10 did not touch it (spans and hashes in the trail table). Dyadic v6.4.19 is owner-reported as adopted on 20 Oct 2026 (40c9e63f…6ec9; release record: §2 and §3 byte-identical to v6.4.18, new §6.14 result only); its bytes are not in this packet. Does the receiver want a currency check against v6.4.19 before deciding?

### Source extracts (verbatim)

#### X-DYAD-1 — Dyadic v6.4.18 §2 OPEN 19

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 238–244; extract SHA-256 `48db555dbb0e8be3e9a5dce2679e8c773037cea01812f6cec34e53945809fc15`

```
**OPEN 19 — Formal centralizer of the normal-form return** [RID: DYAD-OPEN-FORMAL-CENTRALIZER] `[v6.4.11 r2; closed v6.4.12 r1]`

Status: CLOSED — formal scope (v6.4.12, adopted 16 Oct 2026)  
Question (as registered in v6.4.11): Is the formal tangent-to-identity centralizer of the formal one-step normal form $\widehat f_{\rm form}$ (equivalently, of its six-step return) equal to the one-parameter family $\{\exp(s\widehat X)\}$ of its formal infinitesimal generator, with all members $\lambda$-equivariant?  
Answer: **yes**, `[THM]` `[scope: formal category, real coefficients]` (§6.16). The proof is posed in the raw frame for $F=T^6$ and uses only the cubic term $X_3$ of $X=\log F$; conjugation by any formal normalizer $\widehat h$ transports it to the normal-form return. RIDs: `DYAD-ALG-CENT-KERNEL`, `DYAD-THM-FORMAL-CENTRALIZER`, `DYAD-THM-FORMAL-INVOLUTION-UNIQUE`; consequence `DYAD-THM-ANALYTIC-CLOCK-BRIDGE` (§6.15).  
Registered hypotheses, now fixed: formal real-coefficient category; only $\Re\mu\ne0$ and $\Im\mu\ne0$ enter; the lattice term $a_{05}\bar z^5$ plays no role (the kernel argument stops at cubic order).  
Not closed by this item: convergence or realization of the formal involution — moved to OPEN 20.
```

#### X-DYAD-2 — Dyadic v6.4.18 §2 OPEN 20

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 248–257; extract SHA-256 `8c85f3a64e11a261e73ad1cff12e4df474184c08e259723fb8fcea18b3cccf87`

```
**OPEN 20 — Realization of the formal involution (Problem B)** [RID: DYAD-OPEN-INVOLUTION-REALIZATION] `[v6.4.12 r1; restructured v6.4.13]`

Status: PARTIAL — B-∞ existence **CLOSED (v6.4.18)** by `DYAD-THM-SMOOTH-EMBEDDING` (§6.17; `[THM]`, $C^\infty$ germ scope); B-∞ flat uniqueness CLOSED (v6.4.13, $C^\infty$ scope); B-an and B-6 ACTIVE. *v6.4.17 status, retained as history:* PARTIAL (v6.4.13) — B-∞ flat uniqueness CLOSED at the $C^\infty$ scope; B-an, B-6 and B-∞ existence ACTIVE  
(B-an) `[OPEN]` Does $R_0=T^3\circ F^{-1/2}$ converge? `[ALG]` (§6.16) Equivalently: does the tangent-to-identity formal square root $F^{1/2}=\exp(\tfrac12\log F)$ of the six-step return converge? A positive answer gives an analytic non-identity involution commuting with $T$. A negative answer excludes analytic non-identity involutions commuting with $T$ (by §6.15(a)) and, under the §6.15(b) hypotheses, with $T^6$ (Corollary A).  
(B-6) `[OPEN]` `[v6.4.13]` Does the tangent-to-identity formal sixth root $F^{1/6}=\exp(\tfrac16\log F)$ converge? `[ALG]` (§6.16) Equivalent: the canonical generator $J=T\circ F^{-1/6}$ converges; equivalent: an analytic local chart exists in which $T$ commutes exactly with $A$ (Bochner averaging). B-6 ⟺ (B-an and B-3), B-3: $F^{1/3}$ (equivalently $G=J^2$) converges. Hence B-6 ⇒ B-an, and a negative B-an answers B-6 negatively; B-an alone does not give B-6.  
(B-∞) Two sub-questions, separated in v6.4.13:  
(B-∞ existence — v6.4.18) `[THM]` `[v6.4.18]` **CLOSED (v6.4.18).** Yes: by `DYAD-THM-SMOOTH-EMBEDDING` (§6.17), $R=T^3\circ K_2^{-1}$ is a $C^\infty$ local involution with $DR(0)=-I$ commuting with $T$, and $K_6=F^{1/6}$, $J=T\circ K_6^{-1}$ exist in $C^\infty$. The route used is $\Phi_\infty=\lim G_\infty^{-n}F^n$, not the §6.17 sequence $F^{-n}R_\infty F^n$ (which stays unproved). The next line is the v6.4.17 text, retained as history.  
(B-∞ existence) `[OPEN]` Does a $C^\infty$ local involution with $DR(0)=-I$ commuting with $T$ exist (equivalently, by F3, a $C^\infty$ tangent-to-identity square root of $F$)? Same question for $F^{1/6}$ / $J$. A proposed construction route is recorded in §6.17; neither convergence nor the limit's properties are claimed.  
(B-∞ flat uniqueness) `[THM]` **CLOSED (v6.4.13, $C^\infty$ scope).** For an *existing* $C^\infty$ local involution $R$ with $R(0)=0$, $RF=FR$ (§6.15 domain convention) and $DR(0)=-I$: $RT=TR$ exactly near $0$ (F1, §6.17); such an involution is unique (F2); an existing $C^\infty$ tangent-to-identity root of $F$ commutes with $T$ and is unique (F3). Closed only in this sense: nothing is asserted about existence, finite $C^k$, or analytic convergence. RRF L-SHADOW-POLY is not imported and is not used.  
No conjecture on the analytic or existence outcomes is recorded. Not claimed: any physical exchange or G2 realization (SG-14/15).
```

#### X-DYAD-3 — Dyadic v6.4.18 §6.15 (analytic clock bridge; domain convention)

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 864–903; extract SHA-256 `4205012bd158de314ea8f83699c3428536cba4f2b5f0841a50aaabfea751e33f`

```
### §6.15 Local Involutions Commuting with the Return `[THM conditional / OPEN]` {#sec-6-15-involution}

> **[SG-14 applies]** **[SG-15 applies]** Pure mathematics about the selected $T$. Nothing here establishes a physical pole or node exchange, the meaning of an edge exchange $\sigma$, or any factor contract $EF=TE$ / $EF=T^6E$ (RRF G2: CONTRACT READY / PHYSICAL REALIZATION OPEN; RRF OPEN-A; OFN OPEN-OPA).

**Provenance.** Part (a): G2-FIX argument from the RRF/OFN review stream, audited here. Part (b): Dyadic-owner strengthening (16 Oct 2026), accepted by the external mathematical review of the same date (`ACCEPT SCOPED`). No numerical work.

`[DEF]` **Domain convention (G2-DOM form).** Let $V$ be an open neighbourhood of $0$ in the **lifted** $(\rho,\eta)$-plane and $R:V\to V$ a $C^k$ map with $R\circ R=\mathrm{id}_V$. Let $\Phi\in\{T,\,F=T^6\}$ and $V_\Phi:=V\cap\Phi^{-1}(V)$ (an open neighbourhood of $0$, since $\Phi(0)=0$). "$R$ commutes with $\Phi$" means $R\circ\Phi=\Phi\circ R$ on $D_\Phi:=V_\Phi\cap R^{-1}(V_\Phi)$, and it is **required** that
$$0\in\operatorname{int}D_\Phi .$$
This does not presuppose $R(0)=0$; it only guarantees that both compositions are defined, and equal, on a neighbourhood of $0$, so that the identity may be evaluated and differentiated at $0$. `[COR r3, R2-01]` r2 omitted this requirement. All statements are about germs at $0$.

`[THM]` [RID: DYAD-THM-LOCAL-INVOLUTION-GERM] `[proof: elementary; conditional on the stated domain/regularity hypotheses; scope: selected $T$]`

**(a) Primitive clock.** If $k\ge1$, $R$ commutes with $T$, and $V\subset\{|\eta|<\pi\}$, then $R(0)=0$ and $DR(0)\in\{I,-I\}$.

**(b) Six-step clock.** If $k\ge3$, $R$ commutes with $F=T^6$, and $V\subset U_T\cup\{0\}$ with $U_T$ the six-phase tube of DYAD-THM-PRIM-CTR, then $R(0)=0$ and $DR(0)\in\{I,-I\}$.

**(c) Dichotomy.** In either case, $DR(0)=I$ implies $R=\mathrm{id}$ on a neighbourhood of $0$. Hence $R$ is not the identity germ $\iff DR(0)=-I$; and then $\Psi:=\tfrac12(\mathrm{id}-R)$ is a local $C^k$ diffeomorphism with $\Psi\circ R=-\Psi$, i.e. $R$ is locally $C^k$-conjugate to $-I$ (Bochner).

*Proof.* Fixed point: since $0\in D_\Phi$, $\Phi(R(0))=R(\Phi(0))=R(0)$. (a) Fixed points of the lifted $T$ are $\sin\eta=0$, $e^\rho=1$, i.e. $(0,k\pi)$; only $0$ lies in $\{|\eta|<\pi\}$. (On the wrapped cylinder there are further fixed points $(\log(1+2\pi k),0)$, $(\log(1+2\pi k),\pi)$; the lifted-chart hypothesis excludes them.) (b) Fixed points of $F$ are $T$-periodic points of period dividing 6; by DYAD-THM-PRIM-CTR there is no nonzero periodic orbit in $U_T$. In both cases $R(0)=0$. Let $L=DR(0)$, so $L^2=I$.
(a) Differentiating $RT=TR$ at $0$: $LA=AL$, $A=DT(0)$. The eigenvalues $e^{\pm i\pi/3}$ are non-real, so the real commutant of $A$ is $\mathrm{span}\{I,A\}\cong\mathbb C$; its only square roots of $1$ are $\pm I$.
(b) In the raw linear frame $W=\mathcal L(\rho,\eta)$, $F(W)=W+G_3(W)+O(|W|^4)$ with $G_3(W)=\mu|W|^2W$ and no quadratic term (§6.7, DYAD-THM-C21). Write $R(W)=LW+R_2(W)+R_3(W)+o(|W|^3)$, the third-order Taylor expansion of a $C^3$ map (`[COR r3, R2-02]`: r2 wrote $O(4)$, which a general $C^3$ map does not guarantee). Since $F=\mathrm{id}+G_3+O(|W|^4)$ with $F$ analytic, $R\circ F=LW+R_2(W)+R_3(W)+LG_3(W)+o(|W|^3)$ and $F\circ R=LW+R_2(W)+R_3(W)+G_3(LW)+o(|W|^3)$ ($R_2$ evaluated at $W+G_3+\dots$ differs from $R_2(W)$ by $O(|W|^4)$, and $G_3(R(W))-G_3(LW)=O(|W|^4)$). Comparing the homogeneous cubic parts, which are determined uniquely modulo $o(|W|^3)$, gives $L\,G_3(W)=G_3(LW)$. If $L\ne\pm I$, $L$ is a (possibly oblique) reflection, so $LW_0=W_0$ for some $W_0\ne0$; then $L(\mu W_0)=\mu W_0$, so $\mu W_0$ lies in the $+1$ eigenline $\mathbb RW_0$. But $\Im\mu=-\tfrac{2\sqrt3}{3}\ne0$, so multiplication by $\mu$ has no real invariant line — contradiction. Thus $L=\pm I$. (The $O(|W|^4)$ remainder comes from the analyticity of $F$ and needs no fourth derivative of $R$.)
(c) For $L=I$: $\Theta:=\tfrac12(\mathrm{id}+R)$ has $D\Theta(0)=I$ and $\Theta\circ R=\Theta$; $\Theta$ is injective near $0$ (inverse function theorem) and $R(x)\to0$ as $x\to0$, so $R(x)=x$ near $0$. For $L=-I$: $D\Psi(0)=I$ and $\Psi\circ R=-\Psi$ directly. $\square$

`[DEF]` **Reading.** The selectivity lost by the six-step linearization ($DT^6(0)=I$) is restored at cubic order by the chiral (phase-shear) part $\Im\mu$ of the return. If the return were radially symmetric to cubic order with real $\mu$, reflections would survive the cubic test. Both clocks give the same germ dichotomy, but $EF=TE$ and $EF=T^6E$ remain different factor contracts; this lemma does not make them equivalent.

`[DEF]` **Relation to $S_h$.** RECOG/RRF's $S_h=h_6\circ(-I)\circ h_6^{-1}$ has $DS_h(0)=-I$ but commutes with $f$ only through degree 6; it is **not** an exact commuting involution and the lemma does not apply to it as such. The formal $\widehat S=\widehat h(-I)\widehat h^{-1}$ commutes formally. `[v6.4.12]` The identity $\widehat S=R_0$ (§6.16) holds in the formal category only; $S_h$ remains a finite chart object (equal to $R_0$ through degree 6) and is not upgraded by the closure of OPEN 19.

`[v6.4.12]` **Formal uniqueness (now proved, separate RID).** DYAD-THM-LOCAL-INVOLUTION-GERM is unchanged. The jet identification is proved in §6.16 (DYAD-THM-FORMAL-INVOLUTION-UNIQUE): for $C^\infty$ or analytic $R$ in the nontrivial branch of (a) or (b), $j^\infty R=R_0=\widehat S$. Both clocks select the same formal involution. (v6.4.11 recorded this as a conditional reduction under OPEN 19.) Any $C^r$ ($4\le r<\infty$) transfer conditional on RRF/G1 lemmas (L-SHADOW-POLY) is not registered here.

`[THM — analytic]` [RID: DYAD-THM-ANALYTIC-CLOCK-BRIDGE] `[v6.4.12 r1]` `[depends: DYAD-THM-FORMAL-INVOLUTION-UNIQUE]` `[scope: selected $T$, local germs]` **Analytic versus smooth commutation (Corollary A).** Let $R$ be a real-analytic local involution with $R(0)=0$ that commutes with $F=T^6$ in the sense of the domain convention above, and let $DR(0)=-I$. (Under the hypotheses of (b), $R(0)=0$ is automatic and every non-identity germ has $DR(0)=-I$.) Then $RT=TR$ exactly on a neighbourhood of $0$.

*Proof.* $j^\infty R$ is a formal involution commuting with $F$ with linear part $-I$, so $j^\infty R=R_0$ (§6.16). $R_0$ commutes with $T$ formally, so the Taylor series of $RT-TR$ is $R_0T-TR_0=0$. Since $T(0)=R(0)=0$, both compositions are defined and real-analytic on a connected neighbourhood of $0$; an analytic map with vanishing Taylor series vanishes there. $\square$

- If $R_0$ diverges (negative answer to OPEN 20 (B-an)), no analytic non-identity involution commutes with $T^6$ under the hypotheses of (b).
- For $C^\infty$ $R$, only $j^\infty(RT-TR)=0$ follows. Exact primitive-clock commutation then needs a flat-uniqueness argument, currently OPEN (OPEN 20 (B-∞); RRF L-SHADOW-POLY, not imported). `[v6.4.13]` Superseded for existing $C^\infty$ involutions by §6.17 F1 (`[THM — conditional]`): exact primitive-clock commutation holds. The sentence is kept as the v6.4.12 record; existence remains OPEN 20.
- This does not identify the distinct factor contracts $EF=TE$ and $EF=T^6E$, and it does not establish the existence of an analytic or $C^\infty$ involution.

*Provenance.* Proposed by the RRF sync review v0.2 ("analytic clock bridge"); endorsed by the external reviewer (16 Oct 2026); proof written and checked by the Dyadic owner.

`[DEF]` **Failure-mode bookkeeping (for RRF/OFN, not a Dyadic claim).** Failure of $EF=TE$, of fibre compatibility, local triviality $R=\mathrm{id}$, or regularity/jet compatibility each diagnoses a different contract defect; none alone proves physical node exchange impossible.
```

#### X-DYAD-4 — Dyadic v6.4.18 §6.16 (formal involution, formal centralizer, kernel lemma)

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 905–952; extract SHA-256 `fe057e24c263c9c2a00067482e7da4cdd5f3588be462da335cc2c92a0756704b`

```
### §6.16 Formal Centralizer of the Six-Step Return `[ALG / THM — formal]` {#sec-6-16-centralizer}

> **[SG-14 applies]** **[SG-15 applies]** Formal mathematics about the selected $T$. Nothing here establishes convergence, an analytic or smooth involution, a physical exchange, or any factor contract.

**Provenance.** Dyadic-owner proof (16 Oct 2026), recorded in `DYAD_OPEN19_FORMAL_CENTRALIZER_PROOF_SESSION.md` v1.2. External review of v1.0 and v1.1: ACCEPT. RRF sync review v0.2: `ACCEPT SCOPED`, with the $a=0$ boundary correction applied below (Steps 2–3).

`[DEF]` **Setting.** $F=T^6$ in the raw linear frame $W=\mathcal L(\rho,\eta)$; $F=\mathrm{id}+G_3+O(|W|^4)$ with $G_3=\mu|W|^2W$, $\mu=-\tfrac12-\tfrac{2i\sqrt3}{3}$, no quadratic term (DYAD-THM-C21, §6.7). Real formal vector fields with vanishing 1-jet are written by their complex component $V(z,\bar z)$; $\mathfrak X_k$ denotes the homogeneous fields of degree $k$. $X:=\log F=X_3+X_4+\cdots$ (formal), with $X_3$ of component $V_3=\mu z^2\bar z$.

`[ALG]` [RID: DYAD-ALG-CENT-KERNEL] `[v6.4.12 r1]` **Lemma K (homogeneous kernel).** For every $k\ge2$,
$$\ker(\operatorname{ad}_{X_3})\cap\mathfrak X_k=\mathbb R\,X_3\ (k=3),\qquad =0\ (k\ne3).$$
Only $\Re\mu\ne0$ and $\Im\mu\ne0$ are used.

*Proof.*
1. *Bracket on a monomial.* For $B=c\,z^a\bar z^b$, $a+b=k$: $[X_3,B]=c\,\alpha_{a,b}\,z^{a+1}\bar z^{b+1}-\mu\,\bar c\,z^{b+2}\bar z^{a}$, with $\alpha_{a,b}=(a-2)\mu+b\bar\mu$.
2. *Coefficient equations.* The output $z^{a+1}\bar z^{b+1}$ receives the first term from $(a,b)$ and the second from $\phi(a,b)=(b+1,a-1)$ when $a\ge1$. For $a=0$ the partner $(b+1,-1)$ does not exist. The second term of the input $(0,b)$ lands on the $\bar z$-free monomial $(b+2,0)$, which receives nothing else. Hence $[X_3,Y]=0$ for $Y=\sum c_{a,b}z^a\bar z^b$ iff
$$c_{a,b}\alpha_{a,b}=\mu\,\bar c_{\phi(a,b)}\ (a\ge1),\qquad c_{0,b}\alpha_{0,b}=0,\qquad \mu\,\bar c_{0,b}=0 .$$
Outputs $(0,q)$ receive nothing. $\phi$ is an involution on $\{a\ge1\}$ with fixed points $a=b+1$.
3. *Boundary $a=0$.* $\mu\ne0$ gives $c_{0,b}=0$; this removes $(0,2)$ at $k=2$. `[COR r1]` The proof record v1.1 stated that $(p,0)$ outputs give no further condition and used the factor $b\bar\mu-2\mu$ instead. The conclusion was right; the bookkeeping is corrected here (RRF sync review v0.2).
4. *Two-element orbits* ($a\ge1$, $\phi(a,b)\ne(a,b)$). With $c_1=c_{a,b}$, $c_2=c_{\phi(a,b)}$, $\alpha_2=(b-1)\mu+(a-1)\bar\mu$: $c_1\alpha_1=\mu\bar c_2$, $c_2\alpha_2=\mu\bar c_1$. If $\alpha_2=0$ then $c_1=c_2=0$. Otherwise $c_1(\alpha_1\bar\alpha_2-|\mu|^2)=0$. The imaginary part of the factor is $\Im(\mu^2)[(a-2)(a-1)-b(b-1)]$ with $\Im(\mu^2)=2\Re\mu\Im\mu\ne0$. It vanishes only for $b=a-1$ (a fixed point, excluded) or $b=2-a$ ($k=2$); the only two-element orbit left at $k=2$ is $(1,1)\leftrightarrow(2,0)$, where the real part equals $-|\mu|^2\ne0$. So $c_1=c_2=0$.
5. *Fixed points* $(a,a-1)$, $k=2a-1$. The equation is $c\alpha=\mu\bar c$ with $\alpha=(a-2)\mu+(a-1)\bar\mu$, and $|\alpha|^2-|\mu|^2=(a-1)(a-2)\cdot4(\Re\mu)^2$. A nonzero $c$ forces $a\in\{1,2\}$. $a=1$ is linear (excluded); $a=2$ gives $k=3$, $\alpha=\bar\mu$, and $c\bar\mu=\mu\bar c$ means $c\in\mathbb R\mu$, i.e. $Y\in\mathbb RX_3$. $\square$

`[THM]` [RID: DYAD-THM-FORMAL-CENTRALIZER] `[v6.4.12 r1]` `[scope: formal category, real coefficients]` **Theorem C.** $\operatorname{Cent}_{{\rm formal},\,DG(0)=I}(F)=\{\exp(sX):s\in\mathbb R\}$.

*Proof.* Tangent-to-identity formal maps form a pro-unipotent group, so $G=\exp Y$. If $G$ commutes with $F=\exp X$ then $e^{\operatorname{ad}X}Y=Y$; since $(e^{\operatorname{ad}X}-1)=\operatorname{ad}X\cdot\psi(\operatorname{ad}X)$ with $\psi$ invertible, $[X,Y]=0$. The lowest term $Y_k$ satisfies $[X_3,Y_k]=0$, so by Lemma K $k=3$ and $Y_3=sX_3$. Then $Y-sX$ commutes with $X$ and starts above degree 3, so it vanishes by Lemma K. $\square$

`[THM]` [RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE] `[v6.4.12 r1]` `[scope: formal category]` **Corollary U.** Let $R_0:=T^3\circ F^{-1/2}=T^3\circ\exp(-\tfrac12X)$.
- (i) $R_0$ is a formal involution with $DR_0(0)=-I$ that commutes with $T$, hence with $F$.
- (ii) Every formal involution $\widehat R$ commuting with $F$ with $D\widehat R(0)=-I$ equals $R_0$.

*Proof.* (i) $T$ commutes with $F$, so $\mathrm{Ad}_TX=X$ and $T^3$ commutes with every $\exp(sX)$. Then $R_0^2=T^6\exp(-X)=\mathrm{id}$ and $DR_0(0)=A^3=-I$. (ii) $C=\widehat RR_0$ is tangent to the identity and commutes with $F$, so $C=\exp(sX)$ by Theorem C. Since $R_0$ commutes with $X$, $\widehat R^2=C^2R_0^2=\exp(2sX)=\mathrm{id}$, so $s=0$. $\square$

No normalizer is used. `[ALG]` **Identification.** For any formal Poincaré–Dulac normalizer $\widehat h$ with $\lambda$-equivariant normal form, $\widehat S=\widehat h(-I)\widehat h^{-1}$ satisfies (ii) because $-I=\lambda^3$; hence $\widehat S=R_0$. In normal-form coordinates the centralizer $\{\exp(s\widehat X)\}$ consists of $\lambda$-equivariant maps, which answers OPEN 19 as registered. $\widehat S=R_0$ is a formal identity only; see §6.15 on $S_h$.

`[ALG]` **Problem B reduction** (OPEN 20). $T^3$ is analytic and invertible near $0$ and $F^{1/2}=R_0T^3$. So $R_0$ converges iff the tangent-to-identity formal square root $F^{1/2}$ of the six-step return converges. ($T^3=R_0\circ F^{1/2}$ factors the analytic square root of $F$ with linear part $-I$.) Existence of a formal root does not imply convergence; the question is not answered here.

`[THM]` [RID: DYAD-THM-FORMAL-Z6-GENERATOR] `[v6.4.13]` `[scope: formal category]` **Canonical ℤ₆ generator.** Let $J:=T\circ\exp(-\tfrac16X)=T\circ F^{-1/6}$. Then $J^6=\mathrm{id}$, $JT=TJ$, $DJ(0)=A$, $R_0=J^3$ and $G:=J^2=T^2F^{-1/3}$. $J$ is the unique formal map commuting with $F$ with linear part $A$ and $J^6=\mathrm{id}$; likewise $G$ (order 3, linear part $A^2$).

*Proof.* $T$ commutes with $X$, so $J^6=T^6\exp(-X)=\mathrm{id}$ and $J$ commutes with $T$. If $J'$ has the stated properties, $J'J^{-1}$ is tangent to the identity and commutes with $F$, so $J'=\exp(sX)J$ (Theorem C); $J$ commutes with $X$, so $\mathrm{id}=J'^6=\exp(6sX)$ and $s=0$. The same argument applies to $G$. $\square$ (No use of the full centralizer of $T$ is needed; cf. FMS v0.5.1 R3, SESSION.)

`[ALG]` `[v6.4.13]` **Analytic realization hierarchy** (OPEN 20). Let $K:=F^{1/6}=\exp(\tfrac16X)$. (a) $K$ converges ⟺ $J=TK^{-1}$ converges ⟺ an analytic chart exists in which $T$ commutes exactly with $A$: given analytic $J$, $\Phi=\tfrac16\sum_{k=0}^5A^{-k}J^k$ satisfies $D\Phi(0)=I$, $\Phi J=A\Phi$, so $\Phi T\Phi^{-1}$ commutes with $A$; conversely, in such a chart $A^{-1}T'$ is an analytic tangent-to-identity sixth root. (b) $K$ converges ⟺ $F^{1/2}$ and $F^{1/3}$ converge: $F^{1/2}=K^3$, $F^{1/3}=K^2$, and $K=F^{1/2}\circ F^{-1/3}$, with exact commutation by the identity theorem. Hence B-6 ⇒ B-an. The admissible exactly-equivariant charts are $\{\psi\circ\Phi:\psi A=A\psi\}$.

**Finite reproductions** `[ALG]` `[scope: finite checks; not certificates of the all-order statements]`:
- `dyad_open19_kernel_check.py` (DYAD-ART-OPEN19-KERNEL): real Jacobian brackets, exact sympy, $k=2,\dots,13$; kernel dimensions $0,1,0,\dots,0$, the $k=3$ field parallel to $X_3$; exit-gated.
- `dyad_open19_a0_boundary_check.py` (DYAD-ART-OPEN19-KERNEL): the Step 2–3 boundary structure for $b=0,\dots,7$; exit-gated, negative control exits 1.
- `dyad_open19_R0_identity_cert.py` (DYAD-ART-OPEN19-R0CERT): 3 truncations ($N=6,8,12$) × 7 assertions — $R_0^2=\mathrm{id}$, $R_0f=fR_0$, $R_0F=FR_0$, $DR_0(0)=-I$, $f\circ h=h\circ n$, $\mathcal J_{\le N}(h(-I)h^{-1})=\mathcal J_{\le N}R_0$, $[R_0]_2=2h_2$; all PASS; negative control (root factor $\tfrac13$) exits 1. At $N=6$ it reproduces RECOG/RRF's $S_6$. It shares the engine of DYAD-ART-RE-REFEREE and is not an independent third implementation.
- Cross-check reference `[reviewer-reported; not owner-inspected]`: `cent.py` (SHA-256 prefix `c6189068`, suffix `4624`; complex-component method) reports kernel dimensions $0,1,0,\dots,0$ for $k=2,\dots,13$. Computational support only.

`[OPEN]` **Not established by this section:** convergence of $R_0$ and analytic or $C^\infty$ existence of a non-identity commuting involution (OPEN 20); exact commutation of a $C^\infty$ six-step involution with $T$; physical exchange or G2 realization (SG-14/15, RRF OPEN-A, OFN OPEN-OPA); equivalence of $EF=TE$ and $EF=T^6E$.
```

#### X-DYAD-5 — Dyadic v6.4.18 §6.17 (Lemma F, F1–F3, DYAD-THM-SMOOTH-EMBEDDING)

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 954–981; extract SHA-256 `8ccea62eac500143ce0e18a971145887c67c8fb72a4358a4502e3358f0d6e44a`

```
### §6.17 Flat Centralizer Triviality `[THM / THM — conditional]` {#sec-6-17-flat}

> **[SG-14 applies]** **[SG-15 applies]** Local mathematics about the selected $T$ near $P_1$. Status: **adopted 18 Oct 2026** after two external review rounds (r1: ACCEPT with R1–R2; r2: ACCEPT — ADOPTION READY). Proof record: `DYAD_LEMMA_F_FLAT_CENTRALIZER_PROOF_RECORD_v0_3.md` (SHA-256 `2e6c5c59a1fdfe6baa1702df8873b0d89664796d4f317313f239969b406a8ece`; reviewed predecessor v0.2 `0a2ae5e2…4dfb`; v0.3 changes only the construction-route sentence, review R1). The RIDs below retain the word `CAND` from the draft stage; per DSN v1.3 a RID is a fixed identifier and carries no status.

`[THM]` [RID: DYAD-CAND-FLAT-CENTRALIZER] `[v6.4.13]` `[proof: elementary; uses DYAD-THM-PRIM-CTR only; scope: stated ball and flat-contact hypothesis]` **Lemma F.** Raw frame $W$, $Q=|W|^2$, $B_s=\{Q\le s\}$. Fix $s_0\in(0,\tfrac1{400}]$ and $K$ with $\|DF(W)-I\|\le KQ(W)$ on $B_{s_0}$; choose $r$ with $4r\le s_0$, $4rK\le\tfrac12$, $B:=B_{4r}$. If $C:B_r\to B$ is any map with $C\circ F=F\circ C$ on $B_r$ and $|C(W)-W|\le c_N|W|^N$ for every $N$, then $C=\mathrm{id}$ on $B_r$.

*Proof sketch* (full text in the proof record). By DYAD-THM-PRIM-CTR, $B_r$ and $B$ are forward-invariant and orbits obey $Q(F^kz)\le\min(4r,2/k)$. For $a=C(x)$, $b=x$, convexity of $Q$ and the mean-value inequality give $|F^na-F^nb|\ge c_0n^{-4K}|a-b|$, while commutation and flatness give $|F^na-F^nb|=|C(F^nx)-F^nx|\le c_N(2/n)^{N/2}$. Take $N>8K$, $n\to\infty$. $\square$ Only the radial contraction ($\Re\mu<0$) is used; no regularity of $C$ is assumed.

`[THM — conditional]` [RID: DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES] `[v6.4.13]` `[conditional on: Lemma F; and on the existence of the $C^\infty$ involution or root concerned — no existence is asserted]` For $C^\infty$ maps, flatness follows from jets (Taylor's theorem and the chain rule); this is the only use of $C^\infty$.
- **F1 ($C^\infty$ clock bridge).** A $C^\infty$ local involution $R$ with $R(0)=0$, $RF=FR$ (§6.15 domain convention), $DR(0)=-I$ satisfies $RT=TR$ near $0$. ($C=TRT^{-1}R$ has jet $TR_0T^{-1}R_0=\mathrm{id}$.)
- **F2 ($C^\infty$ uniqueness).** Two such involutions coincide near $0$.
- **F3 (smooth roots).** A $C^\infty$ tangent-to-identity $K$ with $K^m=F$ commutes with $T$ and is unique. Hence in $C^\infty$: $F^{1/6}$ exists ⟺ $J$ exists ⟺ an exactly $\lambda$-equivariant $C^\infty$ chart exists, without a separate commutation hypothesis; likewise $F^{1/2}$ ⟺ $R_0$.

`[OPEN]` `[v6.4.17]` **Not established** *(v6.4.17 state; existence of $C^\infty$ roots, $J$ and $R$ is addressed by the v6.4.18 entries below)*: existence of any $C^\infty$ root, involution or $J$ (OPEN 20 B-∞ existence; proposed construction route: the conjugation sequence $F^{-n}R_\infty F^n$ with $R_\infty$ a Borel realization of $R_0$. `[COR r2, review R1]` Its $C^0$ convergence, higher-derivative convergence, and the commutation properties of a limit are **not proved**; Lemma F gives uniqueness of an existing flat-close commuting map, not convergence of approximately commuting conjugates. r1's statement that $C^0$ convergence follows from Lemma-F-type estimates is withdrawn); finite-$C^k$ analogues; analytic B-an/B-6; physical exchange or G2 realization; identification of $EF=TE$ with $EF=T^6E$.

**OPEN 20 B-∞ existence — smooth flow embedding (v6.4.18).** Sources: the O20-∞ SESSION records (§8 DYAD-ART-OPEN20-BINF-RECORDS), reviewed 19–20 Oct 2026 (P2-b v0.2.1, P3-a v0.1 and P3-b/c v0.1 accepted; integration audit v0.1 accepted with the E2 scope correction applied in v0.1.1). Requested by FMS (OPEN 20 priority, `DYAD_REPLY_TO_FMS_OPEN20_PRIORITY_v0_1.md`).

`[THM]` [RID: DYAD-THM-SMOOTH-EMBEDDING] `[v6.4.18]` `[proof: Borel realization + flat conjugacy by inverse iteration + polynomial derivative bounds + Lemma F/F2/F3; scope: $C^\infty$ local germs at $P_1$, raw frame $W$, lifted chart]` **Smooth flow embedding of the six-step return.** Let $\widehat X=\log F$ be the formal generator of §6.16. (E1) There are a ball $U^*=B(0,r'')$ and a $C^\infty$ vector field $X$ near $0$ with $j^\infty_0X=\widehat X$ and $F=\varphi^1_X$ on $U^*$. (E2) If $X'$ is a $C^\infty$ field with $\varphi^1_{X'}=F$ near $0$ and $DX'(0)=0$, then $X'=X$ as germs; in particular $X$ does not depend on the Borel realization used. (E3) For every $m\ge1$, $K_m:=\varphi_X^{1/m}$ is a $C^\infty$ tangent-to-identity germ with $K_m^m=F$; it commutes with $T$ and is the unique such root (F3). (E4) $J:=T\circ K_6^{-1}$ satisfies $J^6=\mathrm{id}$, $DJ(0)=A$, $JT=TJ$; $R:=T^3\circ K_2^{-1}$ is a $C^\infty$ local involution with $DR(0)=-I$, $RT=TR$, unique by F2, and satisfies the §6.15 domain convention with $V=B\cap R^{-1}(B)$.

*Proof outline* (full text in the records). (i) $X_\infty$: a $C^\infty$ Borel realization of $\widehat X$; $G_\infty:=\varphi^1_{X_\infty}$ has $j^\infty G_\infty=j^\infty F$ (jet ODE on finite-dimensional jet spaces). (ii) On $\bar B(0,3\rho)$, $F$ and $G_\infty$ are local diffeomorphisms with $\|DH-I\|\le c_1|w|^2$ and $Q(Hw)\le Q-\tfrac12Q^2$ (common cubic term $\mu|W|^2W$, $\operatorname{Re}\mu=-\tfrac12$; DYAD-THM-PRIM-CTR for $F$), and $F-G_\infty$ is flat. (iii) P2-b: for $N_0>2\gamma+4$, $\gamma=2c_1/a$, the inverse-branch iterates $p_n=\Gamma_n\circ F^n$, $\Gamma_n=(G_\infty^n|_{B(0,3\rho)})^{-1}$, are defined on a fixed ball $B(0,\rho_1)$ and converge uniformly to $\Phi_\infty$ with $\Phi_\infty F=G_\infty\Phi_\infty$; by the symmetric construction and Lemma F (re-proved for $G_\infty$ from its own hypotheses) $\Phi_\infty$ is a local homeomorphism. (iv) P3-a: $\|D^\ell H^n\|\le C_\ell(1+n)^{A_\ell}$, $\|D^\ell\Gamma_m\|\le\bar C_\ell(1+m)^{B_\ell}$, $\|D^\ell p_n\|\le\hat C_\ell(1+n)^{P_\ell}$, uniform in the base point, with $A_\ell=(2\alpha+1)(\ell-1)+\alpha$, $B_\ell=(7\alpha+1)(\ell-1)+2\alpha$, $P_\ell=(7\alpha+1)(\ell-1)+(\ell+2)\alpha$, $\alpha=c_1/a$. A uniform form $(1+nQ)^{A}$ is impossible for $\ell=3$: $j^3F^n=\mathrm{id}+nP_3$. (v) P3-b/c: $\|D^j(F-G_\infty)(w)\|\le C_{N,j}|w|^N$ for all $N,j$; $d_n=p_{n+1}-p_n=\int_0^1D\Gamma_{n+1}(z_t)[(F-G_\infty)(F^nx)]\,dt$ with one flat factor per Leibniz term gives $\|D^\ell d_n\|\le M_{N,\ell}(1+n)^{E_\ell}|F^nx|^N$, $E_\ell=(8\alpha+1)\ell+2\alpha$; with the integer $N_k=\lceil2E_k+3\rceil$, $\sum_n\|d_n\|_{C^k(B(0,\rho_1))}<\infty$ for every $k$ on the same ball. So $\Phi_\infty\in C^\infty$, $\Phi_\infty-\mathrm{id}$ flat. (vi) Inverse function theorem, a Grönwall flow ball for $X_\infty$ and a forward-invariant common ball $U^*$ give $F=\varphi^1_X$, $X=\Phi_\infty^*X_\infty$. (vii) E2: the jet of $X'$ equals $\widehat X$ (needs $DX'(0)=0$); $C_t=\varphi_X^{-t}\varphi_{X'}^t$ commutes with $F$, is flat-close to the identity and maps $B_r\to B_{4r}$ for all $t\in[0,1]$, so Lemma F gives $C_t=\mathrm{id}$. (viii) E3–E4: F3, with its existence condition discharged by E1; F2; §6.15 convention checked in the audit. *Checks* (DYAD-ART-OPEN20-BINF-CHECKS): exact 3-jet of $T^6$ ($j^3F^n=\mathrm{id}+nP_3$, $DQ\cdot P_3=-Q^2$, cubic part $=\mu|W|^2W$), $A^6=I$, $A^3=-I$, exponent recursions, input pins; negative controls fail as required. The checks do not replace the all-orders arguments.

`[DEF]` `[v6.4.18]` **Recorded distinctions.** (i) **Notation:** $G_\infty$ denotes the Borel time-one map; it is unrelated to $G=J^2$ of §6.16. (ii) **Route:** the proof uses $G_\infty^{-n}F^n$; the §6.17 route $F^{-n}R_\infty F^n$ is a different sequence and remains unproved. (iii) **E2 scope:** uniqueness is claimed only among generators with $DX'(0)=0$; $\exp(DX'(0))=I$ does not force $DX'(0)=0$ in general. (iv) **F1–F3:** grades unchanged (`[THM — conditional]`); their existence condition is discharged for the roots $K_m$, $J$ and $R$ by E1. (v) **Radius:** $r''$ is qualitative; no numerical radius and no finite-$C^k$ constant is claimed. (vi) $C^\infty$ existence says nothing about analyticity: B-an and B-6 are untouched. (vii) SG-14/15: no physical exchange, G2 realization or $EF=TE$/$EF=T^6E$ identification follows.

`[OPEN]` `[v6.4.18]` **Not established:** convergence of $\log F$, $F^{1/2}$, $F^{1/6}$ (B-an, B-6); uniqueness among all $C^\infty$ generators of $F$; quantitative radii and finite-$C^k$ versions; convergence of $F^{-n}R_\infty F^n$; physical exchange or G2 realization.

`[NUM]` `[scope: illustration only]` Sampled $\max\|DF-I\|/Q\approx3.80$–$4.07$ for $|W|\in[0.005,0.05]$, consistent with $3|\mu|\approx3.77$; not a proof input.

---
```

#### X-DYAD-6 — Dyadic v6.4.18 §8 artifact line: §6.16 proof record

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 1059–1059; extract SHA-256 `b6ea515415406908b2f77b168c1f010d344864a6aac8ad335fe27c3b34de5bc7`

```
- [RID: DYAD-ART-OPEN19-SESSION] `[v6.4.12 r1]` :: `DYAD_OPEN19_FORMAL_CENTRALIZER_PROOF_SESSION.md` v1.2 (SHA-256 `6749df1126b36453f1f860dd797a872f291fcc7926412225f839acfb2e60e1c6`) :: proof record for §6.16 and Corollary A; reviewer records: SESSION v1.1 review (ACCEPT), RRF sync review `RTG_RRF_OPEN19_G2_POSTADOPTION_SYNC_REVIEW_v0_2.md` (`ACCEPT SCOPED`) :: `[SESSION]` record; role: provenance, not a truth grade
```

#### X-DYAD-7 — Dyadic v6.4.18 §8 artifact line: kernel check scripts

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 1060–1060; extract SHA-256 `8df7ad3f4f92d6776ca3bb01e6b9ccc35910555b3c21338b95551256497a7f2f`

```
- [RID: DYAD-ART-OPEN19-KERNEL] `[v6.4.12 r1]` :: `dyad_open19_kernel_check.py` v1.1 (SHA-256 `1cb40446c0289424fcb8539c77aec6d43f4e6a0873434645b8cc3dc4397a291e`) + `dyad_open19_a0_boundary_check.py` (`a2aedc51acef70738e5b6006c601c036d5ee182a5d2eb899beb92c5dc4303a45`) :: exit-gated sympy reproductions of Lemma K for $k\le13$ and of the $a=0$ boundary structure for $b\le7$ :: `[ALG]` `[scope: finite]`
```

#### X-DYAD-8 — Dyadic v6.4.18 §8 artifact line: R_0 identity certificate

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 1061–1061; extract SHA-256 `ad8618ac68ba5d39efcb223b6439b4abb2a5daf5d048c2a0323a3b690b07dd5c`

```
- [RID: DYAD-ART-OPEN19-R0CERT] `[v6.4.12 r1]` :: `dyad_open19_R0_identity_cert.py` (SHA-256 `c8c144426b2c9e795df19a997b181209fce6ab7edeaa1b9c04e731ad0d059cf8`) + engine `dyad_return_qchi_exact.py` (`e45286fa100b2b31c4d547e8513e23f926b2bda36d31938577fa9f312ca350f6`) :: 3 truncations × 7 exit-gated assertions for $R_0$ (§6.16); owner rerun 16 Oct 2026 PASS at $N=6,8,12$; independent reviewer rerun PASS in the SESSION v1.1 review round (kernel check and $R_0$ certificate). The r1 review reran only `dyad_open19_a0_boundary_check.py` and relies on those earlier records for the other two :: `[ALG]` `[scope: finite jets]`
```

#### X-DYAD-9 — Dyadic v6.4.18 §8 artifact line: Lemma F proof record

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 1063–1063; extract SHA-256 `36af998320d063132c5c40ab2939debaf1495bb0b435caad37c0aee9b42e729a`

```
- [RID: DYAD-ART-LEMMA-F-RECORD] `[v6.4.13]` :: `DYAD_LEMMA_F_FLAT_CENTRALIZER_PROOF_RECORD_v0_3.md` (SHA-256 `2e6c5c59a1fdfe6baa1702df8873b0d89664796d4f317313f239969b406a8ece`; current) — predecessor v0.2 (`0a2ae5e266a9d9dd175503df4ea9629c10978637bdaadadc38e75a94fb104dfb`, the text reviewed in the r1 round; superseded on the §3.4 construction-route sentence only) :: proof record for §6.17; reviewed r1 and r2 rounds (18 Oct 2026) :: `[SESSION]` record, provenance for the adopted `[THM]`
```

#### X-DYAD-10 — Dyadic v6.4.18 §8 artifact line: smooth-embedding proof records

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 1072–1072; extract SHA-256 `dc7109ee7003f5af87744699b5a4012bffe1b64118508c5ace735e98a84dcf34`

```
- [RID: DYAD-ART-OPEN20-BINF-RECORDS] `[v6.4.18]` :: `DYAD_REPLY_TO_FMS_OPEN20_PRIORITY_v0_1.md` (`208ec09a4c57eee69463e0ea6e8867b8868aa019643f075e8b9bfb73db91dda3`), `DYAD_OPEN20_SMOOTH_EMBEDDING_LITERATURE_SCOPE_SESSION_v0_1.md` (`3a06222a67d7b895cbcd911db7928a94fc8dc1599d1aa69da1e83e0a2a78c0be`), `DYAD_OPEN20_P1B_P2_DOMAIN_SESSION_v0_1.md` (`0ab4fab0e30c02a8874e6d08d91dff00abe389e528b492435dc0e3409a55820c`; §1–§2 current, §3 superseded), `DYAD_OPEN20_P2B_DOMAIN_PROOF_SESSION_v0_2_1.md` (`6f275e735897a3f29308de132a416d184b01c2e420fafb83cc012d360033fcf4`; supersedes v0.2 `b8a1434f…19f9`), `DYAD_OPEN20_P3A_ITERATE_DERIVATIVE_BOUNDS_SESSION_v0_1.md` (`b044a41d88c57bfc258469e741d01bd458e9256e2fe4e4ebda92e32b07e9a846`), `DYAD_OPEN20_P3BC_FLAT_DERIVATIVES_AND_CK_CONVERGENCE_SESSION_v0_1_1.md` (`3ceca25ee64d0b0263da10972ab8e64231545e74e8ad8fc977cd25caeb9e487f`; supersedes v0.1 `f299f50f…a136`), `DYAD_OPEN20_BINF_EXISTENCE_INTEGRATION_AUDIT_SESSION_v0_1_1.md` (`57327922a56aabc409023a780618d9ff46070daa785e4c6355a086cabbe66f4e`; supersedes v0.1 `4e598848…7b57`) :: reply, scope and proof records for OPEN 20 B-∞ existence :: `[SESSION]` records
```

#### X-DYAD-11 — Dyadic v6.4.18 §8 artifact line: smooth-embedding check scripts

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 1073–1073; extract SHA-256 `0b283841e9e108bb662a3f302cfe18e2564600565de9b2faef5c2299485046ae`

```
- [RID: DYAD-ART-OPEN20-BINF-CHECKS] `[v6.4.18]` :: `dyad_open20_p3a_check.py` (`56d8178109b34a8858dca6d3d5470524916ae850390bf2a81b86d9ddf2e67140`) + `p3a_check.json` (`1665994e5460a377192a29d3ef7b6efd55491856b7aa5bcd291be7d8fa12ebd1`); `dyad_open20_p3bc_check_v0_1_1.py` (`6cde7ca66cb86101a4ae7b8a41877d49a31ec449563c41bb0d6fc136b6c76d48`) + `p3bc_check_v0_1_1.json` (`4204cd4f05d889df153744b161709d38db261a9ed14ff112c5bf026f7dfe14e9`); `dyad_open20_binf_integration_check.py` (`0d5a1dfdc13a7bfe7d3ebbe63d5dc1d8f88baff44f663fddaff4b765c2fb0264`) + `binf_integration_check.json` (`26ef2748045cb0ceac138beb2f211f4dc5ff2aa17d7d47c81e2e387bca078f5f`) :: exact jet, linear-algebra, exponent and pin checks (8+3+6 gates; 4+3+3 negative controls; reviewer re-executed) :: `[ALG]` checks supporting the proof (not a substitute for it)
```

#### X-DYAD-12 — RRF v0.8.3 §2.3 RRF-DYAD-W (carrier frame)

`sources/owner/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md` lines 141–157; extract SHA-256 `eaeccea2f8b7486f6791f43d1da76742ebc51cbe7a37a56c8d8484e1111dbe52`

```
## 2.3 `RRF-DYAD-W` (lifted $\mathcal L$-frame)

| Field | Entry |
|---|---|
| Native state | $W=\mathcal L(\rho,\eta)=\rho-\tfrac{\eta}{2}+i\tfrac{\sqrt3}{2}\eta=\rho+\omega\eta$, $\omega=\tfrac{-1+i\sqrt3}{2}$; **lifted local phase, no wrapping seam** `[import: DYAD v6.4.10 §6.14, definition 𝓛; RID unavailable]` |
| Distinguish from | $W_{\rm DSN}=\mathcal L(\rho,\eta_{\rm wrap})$ of DYAD §1 — the same linear frame applied to the principal angle; registered on the wrapped side (`RRF-DYAD-WRAPPED`, projected observables), not here. $W_{\rm DSN}=W_{\rm lift}$ **iff** the chosen lift equals $\eta_{\rm wrap}$; on other deck sheets they differ even far from the seam. The anti-correlation frame $(U,V)$ is likewise a wrapped-side object. |
| Domain | lifted local |
| Native dynamics | $f=\mathcal LT\mathcal L^{-1}$ (one-step); linear part $\lambda=e^{i\pi/3}$, $\lambda^6=1$ `[import: DYAD v6.4.10 §1; OFN v0.8]`; six-step return $F_W=f^{\circ6}$ with cubic coefficient $c_{21}=\mu=-\tfrac12-i\tfrac{2\sqrt3}{3}$ `[import: DYAD v6.4.10; RID: DYAD-THM-C21]` |
| Native observables | $Q_{\rm prim}=\lvert W\rvert^2=\rho^2-\rho\eta+\eta^2$; Hermitian comparator $C_W(a,b)=\bar W_aW_b$; normalised $\widehat C=e^{i(\Theta_b-\Theta_a)}$ |
| Observable status | $Q_{\rm prim}$, $C_W$ **native** (raw bilinear forms) |
| Relabeling candidate (two symbols) | **Registered object:** the exact local map $S_h=h_6\circ(-I)\circ h_6^{-1}$ on $h_6(D)$, $D$ a sign-symmetric disk inside the certified inverse domain. **Involution exact by construction:** $S_h^2=I$ on $h_6(D)$. **Commutation finite-order only:** $\mathcal J_{\le6}(f\circ S_h-S_h\circ f)=0$ `[ALG] [scope: degree ≤ 6] [conv: DYAD-ALG-NF6 additive normalizer] [import: RECOG v0.3.14 §6.14, cert check 9; evidence RID: RECOG-ART-R11-LEDGER] [provenance: Claude-checked as recorded by RECOG; owner-source inspection, no rerun here]`. The truncation $S_6:=\mathcal J_{\le6}S_h$ satisfies both identities only to jet order. Leading terms: $S_h(W)=-W+s_2(W,\bar W)+O(3)$, $s_2=2h_2=-\tfrac{1+i\sqrt3}{6}W^2-\tfrac23W\bar W+\tfrac{1-i\sqrt3}{12}\bar W^2$. |
| Covariance of native observables under $S_h$ | General two-input identities are algebraic consequences of the displayed $s_2$: $C_W(S_hW_a,S_hW_b)-C_W(W_a,W_b)=O(3)$, and $C_W(S_hW_a,W_b)=-C_W(W_a,W_b)+O(3)$ (joint total degree in the two states). The nonzero real-ray witness $C_W(S_ht,S_ht)-C_W(t,t)=\tfrac32t^3+O(t^4)$ is independently reconstructed in RECOG §6.14 check 9 `[ALG] [scope: fixed adopted h_6; finite-jet consequence, not exact invariance] [import: RECOG v0.3.14 §6.14; evidence RID: RECOG-ART-R11-LEDGER] [provenance: Claude-checked as recorded by RECOG for the stated check; no rerun here]`. A comparator with exact $S_h$-covariance is $C^W_{\rm cov}(a,b)=\overline{h_6^{-1}(W_a)}h_6^{-1}(W_b)$: the transported NF-native $C_z$, separately **re-defined** relative to $C_W$ (§4.1). |
| Six-step parity `[import: DYAD v6.4.10 §6.12, definition E_odd; RID unavailable]` | $F_W$ is **not** odd under $w\mapsto-w$: $\tfrac12(F_W(w)+F_W(-w))=F_4(w)+O(6)$, $F_4\ne0$; $E_{\rm odd}(w)=\tfrac12(F_W(w)-F_W(-w))-w=\mu\lvert w\rvert^2w+O(5)$. $F_4$ is the six-step counterpart of the one-step $T_b$ obstruction. Physical bridge of $E_{\rm odd}$ `[OPEN]` (owner-recorded). |
| Exactness | $\mathcal L$ exact linear bijection; $S_h$ exact involution, dynamical commutation degree-6 certified |
| Information loss | none relative to LIFT |
| Guard | $\Re W,\Im W$ are structure-adapted components, not spatial axes `[import: OFN v0.9 §4.4 #ofn-rank-typing; RID: RTG-OFN-DEF-RANK-TYPING]` |
| Status | `[DEF]`; $Q_{\rm prim}=\lvert W\rvert^2$ exact |
```

#### X-DYAD-13 — RRF v0.8.3 §2.4 RRF-DYAD-NF

`sources/owner/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md` lines 159–179; extract SHA-256 `ea60095b39d3f44befbd2f82cc1eea9972e343c034d7d44b397c6dafe81de7a0`

```
## 2.4 `RRF-DYAD-NF`

| Field | Entry |
|---|---|
| Normalisation object | **Polynomial conjugacy only** — DYAD SG-19 operation (iii): $W=h(z,\bar z)$, $h=\mathrm{id}+h_2+\dots+h_6$, exact additive polynomial over $\mathbb Q(i\sqrt3)$, **resonant monomial coefficients of each $h_n$ set to zero** (resonance $a-b-1\equiv0\bmod 6$); table in `DYAD_RETURN_ENCLOSURE_P2B_v2/outputs/certificate.json` (`jets.h_degree6`, `jets.J_through6`) `[import: DYAD v6.4.10 §6.14; RID: DYAD-ALG-NF6] [provenance: owner-adopted]`. Operations (i) archival $\Phi_{\rm archive}$ and (ii) log-channel projection $G_{\rm proj}$ are **not** this profile. |
| Non-transferable quantities | **Standing refusal after R11 closure:** raw $\tfrac{47}{54}$ ($\mathcal A_{\rm raw}$), archival $c_\theta^{(6)},a_1,a_2$ in the Lie strict-kernel convention, fitted long-orbit backbones, projected-model coefficients, and raw $c_{05}$ are not inputs to the current NF chart merely by sharing names. RECOG R11 is CLOSED and explicitly retains this refusal; it does not authorize these transfers `[import: RECOG v0.3.14 §6.14, refusal line; evidence RID: RECOG-ART-R11-LEDGER]`. Standing lattice obstruction: $c^{({\rm raw},6)}_{05}-a_{05}=\tfrac{-13+3i\sqrt3}{576}\ne0$ `[import: DYAD v6.4.10 §6.14; RID: DYAD-ALG-NF6-OBS]`. |
| Domain | inverse-coordinate domain of DYAD-THM-NF-INV: $h_6$ injective on $\lvert z\rvert\le\tfrac1{10}$ with $\lvert h_6(z)\rvert\le\tfrac{17}{16}\lvert z\rvert$, $h_6^{-1}$ exists on $\lvert W\rvert\le\tfrac9{100}$ (majorant $M(s)$, $H(s)=s+M(s)$); remainder domain of DYAD-THM-NF-REM with radius-indexed profiles $(r,C_7)=(\tfrac1{20},100)$ or $(\tfrac1{40},30)$, never mixed; **local only** |
| One-step objects (two symbols) | **Delivered:** $\widehat f_6=h_6^{-1}fh_6$, exact analytic map on its proved domain, finite jet $n$ with $\mathcal J_{\le6}(f\circ h_6-h_6\circ n)=0$. **Formal:** $\widehat f_{\rm form}=h_{\rm form}^{-1}fh_{\rm form}$, the formal Poincaré–Dulac normal form; contains only resonant monomials $z^p\bar z^q$, $p-q\equiv1\ (\mathrm{mod}\ 6)$ — hence all of odd degree. $h_6=\mathcal J_{\le6}h_{\rm form}$ under the shared convention. |
| One-step symmetry | Formal: $\widehat f_{\rm form}(\lambda z)=\lambda\widehat f_{\rm form}(z)$, hence $\widehat f_{\rm form}(-z)=-\widehat f_{\rm form}(z)$, $-1=\lambda^3$ `[ALG] [scope: formal all-order] [provenance: Claude-checked (resonance argument)]`. Delivered: only $\mathcal J_{\le6}\big(\widehat f_6(\lambda z)-\lambda\widehat f_6(z)\big)=0$ `[ALG] [scope: degree ≤ 6]`; all-order equivariance of the exact analytic $\widehat f_6$ is **not** established by the certificate. |
| Six-step object | $\widehat F=h^{-1}F_Wh$, finite jet $J(z)=z+\mu z^2\bar z+a_{32}z^3\bar z^2+a_{05}\bar z^5$; linear part identity; certified remainder $\lvert\widehat F-J\rvert\le C_7\lvert z\rvert^7$ `[import: DYAD v6.4.10 §6.14; RID: DYAD-THM-NF-REM]`. $E_{\rm NF}(z)=\widehat F(z)-z=\mu\lvert z\rvert^2z+O(5)$; its jet $J$ is odd (finite order), the formal six-step normal form is odd; this exact map (fixed finite $h_6$) has **no all-order oddness under the naive $-I$ action**: the verified fixed-chart degree-ten parity obstruction is recorded separately as finding VF-1 (§2.4a); the jet and remainder certificates are unaffected and the profile remains valid. **$\widehat f$ and $\widehat F$ are different maps; $n$ and $J$ are different jets; neither is an all-orders identity (SG-19).** |
| Native observables | $q=\lvert z\rvert^2$; self-return multiplier $\chi_m(z)=\widehat F^{\circ m}(z)/z$, defined for $z\ne0$ and admissible iterates (extension at $0$ stated separately); NF comparator $C_z(a,b)=\bar z_az_b$ |
| Source-derived history/limit observable | $\Psi=\Theta-\tau\log q$, $\tau=2\sqrt3/3$, with the continuous along-orbit lift of $\arg z$; $\mathcal M(z_0):=\Psi_\infty-\Psi(z_0)$ denotes RECOG's $M$ (renamed typographically here to avoid collision with the coordinate majorant $M(s)$). Defined for the exact return $\widehat F$, not a lattice-free comparison model `[import: RECOG v0.3.14 §6.13a; RID: RECOG-THM-R9-MEMORY]`. This is an imported derived observable with its own source theorem, not a newly appended independent state coordinate; track/domain and token limitations are in §4.1a. |
| Observable status | $q$, $\chi_m$, $C_z$ **native / re-defined**; $Q_{\rm prim}=\lvert h(z,\bar z)\rvert^2$ and $C_W\!\mid_{\rm NF}=\overline{h(z_a)}\,h(z_b)$ **transported** |
| Relabeling candidate | $z\mapsto-z$: exact symmetry of $\widehat f_{\rm form}$; degree-6 certified for $\widehat f_6$. $h_6$ is the unique solution of the specified homological recursion through degree 6 under the zero-resonant-coefficient convention, so the exact map $S_h=h_6(-I)h_6^{-1}$ and its truncation $S_6=\mathcal J_{\le6}S_h$ carry no residual-gauge ambiguity at degree $\le6$ `[ALG] [scope: degree ≤ 6] [conv: DYAD-ALG-NF6]`. Canonicity under other normalizer conventions and at all formal orders is not supplied by this fixed-chart registry and remains `[OPEN] [scope: other normalization classes]`. This is not an unclosed R11 task: the completed R11 ledger pins the adopted chart and routes physical pole identification to RRF OPEN-A `[import: RECOG v0.3.14 §6.14; evidence RID: RECOG-ART-R11-LEDGER]`. |
| Formal involution — **owner-adopted, formal only** | `R_0=T^3F^{-1/2}=\widehat h(-I)\widehat h^{-1}` is the **unique formal** `−I`-linear involution commuting with `F=T^6` and it also commutes formally with primitive `T` `[THM] [scope: formal only] [import: DYAD v6.4.12 §6.16; RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE]`. The delivered **finite** $S_h=h_6(-I)h_6^{-1}$ is exactly involutive and equals `R_0` only through jet degree six under the shared normalizer convention; exact dynamical commutation is **not** established for $S_h$. Existence/convergence of the formal involution remains **OPEN 20** (B-an/B-∞ existence); the new v6.4.13 F1–F3 results classify *existing* C∞ involutions and roots (§2.4c), not their existence. |
| Covariance under $-I$ | **Exact algebraic identities:** $q(-z)=q(z)$; $C_z(-z_a,-z_b)=C_z(z_a,z_b)$; $C_z(-z_a,z_b)=-C_z(z_a,z_b)$. **Self-return multiplier:** for the formal odd normal form the formal multiplier is sign-invariant; for the polynomial model $\chi^J_m=J^{\circ m}/z$ sign-invariance is exact but that model is a separate re-definition, not a transport of $\chi_m$; for the delivered exact $\widehat F$, $\chi_1$ is **not exactly sign-invariant** — a consequence of the verified fixed-$h_6$ degree-ten finding VF-1 (§2.4a); $\chi_m$ for $m\ge2$ is not classified in this registry. Bounded statement for one return: with $R:=\widehat F-J$, $\lvert R(z)\rvert\le C_7\lvert z\rvert^7$ and $J(-z)=-J(z)$, $\chi_1(-z)-\chi_1(z)=-\tfrac{R(-z)+R(z)}{z}$, hence $\lvert\chi_1(-z)-\chi_1(z)\rvert\le2C_7\lvert z\rvert^6$ on $0<\lvert z\rvert\le r$ `[ALG] [scope: direct consequence of DYAD-THM-NF-REM, one six-step return, either (r,C_7) profile unmixed] [provenance: review v1 deduction; Claude-checked]`. No $m$-uniform iteration bound is claimed. |
| Common-realisation condition `[DEF] [scope: RRF working convention]` | two $z$-states may be compared by $C_z$ only if $z_a=h_6^{-1}(W_a)$, $z_b=h_6^{-1}(W_b)$ — **preimages under the same registered $h_6$** (images under $h_6^{-1}$) of states in the **same registered $W$-frame**, both inside the registered inverse domain — or an explicit certified frame transport between their charts is registered. Direction/typing only; decides nothing about physical co-realisation, birth inheritance or the network bridge. A registered frame/context transport is necessary for comparing differently represented data, but does not itself supply an admissible shared physical history; NUMGEN M2-1 makes this separation explicit (§6.1). |
| Exactness | formal all-order / degree-6 certified / certified remainder |
| Information loss | none inside domain; no global content |
| Guards | $q\ne Q_{\rm prim}$ beyond leading order — they are different native observables, not two coordinate expressions of one; primitive iterates $Q_m$ and normalized iterates $q_m$ are **not identified** (DYAD §6.14); $\bar z_az_b\ne\overline{h(z_a)}h(z_b)$ in general |
| Status | `[DEF]`; chart and certificates owner-adopted (DYAD v6.4.10) |
```

#### X-DYAD-14 — RRF v0.8.3 §2.4b formal involution receipt

`sources/owner/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md` lines 197–213; extract SHA-256 `9017b430298c789877f00effbfe1f6280ed91ce9225cc8b4fc78402d358aed1c`

```
### 2.4b Adopted DYAD formal involution receipt (new v0.8.2 candidate; not a new profile)

`[THM] [scope: formal germs for F=T^6; owner-adopted] [import: DYAD v6.4.12 §6.16 #sec-6-16-centralizer; RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE]` The formal object

\[
R_0=T^3\circ F^{-1/2}=\widehat h(-I)\widehat h^{-1},\qquad F=T^6,
\]

is the **unique formal involution** with derivative `−I` commuting with `F`; it commutes formally with primitive `T`. The tangent-to-identity formal centralizer is the one-parameter family `exp(s log F)` `[import: DYAD v6.4.12 §6.16; RID: DYAD-THM-FORMAL-CENTRALIZER]`. The kernel lemma over **all homogeneous degrees** is `[import: DYAD v6.4.12 §6.16; RID: DYAD-ALG-CENT-KERNEL]`. The lifecycle `DYAD-OPEN-FORMAL-CENTRALIZER` is **CLOSED (formal)** by this owner release; this is not RRF OPEN-A closure.

`[DEF] [scope: finite-versus-formal refusal]` The delivered `S_h=h_6(-I)h_6^{-1}` is an **exact involution of the finite polynomial chart** with only degree-six **dynamical commutation** established. In the shared normalization convention `J_{≤6}R_0=J_{≤6}S_h=S_6`; no exact equality `R_0=S_h`, analytic convergence or physical pole exchange follows. VF-1 (`DYAD-ALG-NF6-DEG10`) concerns the fixed finite `h_6` chart only; it does not obstruct a different analytic or smooth odd chart. The owner §6.15 specifies `DYAD-THM-LOCAL-INVOLUTION-GERM` for primitive `C¹` and six-step `C³` involutions, with appropriate invariant/tube domains.

`[THM] [scope: conditional real-analytic local germs] [import: DYAD v6.4.12 §6.15 #sec-6-15-involution; RID: DYAD-THM-ANALYTIC-CLOCK-BRIDGE]` A nonidentity **analytic** local involution commuting with `F=T^6` under the §6.15(b) hypotheses has derivative `−I` and commutes **exactly** with primitive `T`. A `C^∞` six-step involution has the same formal jet as `R_0`; **adopted DYAD v6.4.13 §6.17 F1 now upgrades this to exact primitive commutation** on its stated domain. The §6.15 analytical result remains a distinct earlier owner theorem. Network factor hypotheses `EF=TE` and `EF=T^6E` are still **different contracts**. `[import: DYAD v6.4.13 §6.17; RID: DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES]`

`[OPEN] [import: DYAD v6.4.13 §§2, 6.16–6.17; RID: DYAD-OPEN-INVOLUTION-REALIZATION]` **OPEN 20 (B-an):** analytic convergence of `R_0`/`F^{1/2}`; **(B-6):** analytic convergence of `F^{1/6}` / `J`; **(B-∞ existence):** existence of a C∞ root/involution and of the corresponding sixth-root realization. `[THM] [scope: DYAD v6.4.13 §6.17 existing C∞ germs; RID: DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES]` **B-∞ flat uniqueness CLOSED** for existing germs by Lemma F and F1–F3. These are distinct from the unknown existence outcomes. Owner RIDs `DYAD-CAND-FLAT-CENTRALIZER` and `DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES` retain their historical spelling despite [THM] grade.

`[ALG] [scope: class-wise local existence equivalence, conditional on the owner clock/root results; not a physical realization] [import: DYAD v6.4.13 §6.17; RID: DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES] [import: DYAD v6.4.13 §§2, 6.16; RID: DYAD-OPEN-INVOLUTION-REALIZATION]` In each of C∞ and analytic categories, a nonidentity primitive-commuting involution (equivalently an odd chart for primitive `T`) exists **iff** a tangent-to-identity square root `Q²=F` exists in that category. The easy direction is `Q=T³R`; the reverse uses F3 for C∞, and the analytic special case of F3 (or formal-root uniqueness plus analytic identity) for Cω, with `R=T³Q^{-1}`. The existence equivalence is an algebraic *consequence* of owner theorems plus the explicitly defined averaging chart (G2 v0.3 §4); it does **not** make the open root/involution exist. No G2 physical factor/encoding is claimed.
```

#### X-DYAD-15 — RRF v0.8.3 §2.4c formal Z6 and smooth centralizer receipt

`sources/owner/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md` lines 215–223; extract SHA-256 `b12f3eef95498c18d381df9e53ff7478515918e1af958995b3533ecbedc5b5ac`

```
### 2.4c DYAD N9 receipt: formal ℤ₆ and smooth centralizer (v0.8.3 source sync)

`[THM] [scope: formal only] [import: DYAD v6.4.13 §6.16; RID: DYAD-THM-FORMAL-Z6-GENERATOR]` The canonical formal generator `J=T∘F^{-1/6}` has order six and linear part `A`; `R_0=J³`, `G=J²`. **OPEN 20 B-6** concerns its analytic realization. **B-6 ⇒ B-an** and **B-6 ⇔ B-an ∧ B-3** `[ALG] [import: DYAD v6.4.13 §6.16; RID: DYAD-OPEN-INVOLUTION-REALIZATION]`; whether B-an alone entails B-3 is not established. A finite or formal generator is not a chosen physical pole/triad action.

`[THM] [scope: DYAD §6.17 forward-invariant ball and flat contact; existence not asserted] [import: DYAD v6.4.13 §6.17; RID: DYAD-CAND-FLAT-CENTRALIZER]` Owner Lemma F states that an `F`-commuting map flat-close to identity is identity on its stated local ball; the RID spelling `CAND` does not indicate its adopted `[THM]` grade.

`[THM] [scope: conditional on an *existing* C∞ germ/root, owner §6.15 domain and §6.17 hypotheses] [import: DYAD v6.4.13 §6.17; RID: DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES]` F1: existing nonidentity six-step involution commutes exactly with primitive `T`; F2: it is unique; F3: existing tangent-identity roots of `F` commute with `T` and are unique. Analytic results are included as a regularity subclass; no convergence or realization is inferred. These theorems do **not** identify physical `σ`, edge encoding `E`, or `EF=TE` with `EF=T⁶E`. **OPEN 20** remains B-an, B-6 and B-∞ existence. The finite-C^r analogue remains unresolved.

`[DEF] [scope: representation and owner boundary]` The physical-clock field remains required even when a C∞ involution commutes with both local clocks: a dynamical factor from network update to `T` is different from a factor to `T⁶`. The separate noncanonical G2 v0.4 review will maintain the full gate contract.
```

### Record trail r4.6 → r4.10

| Version | File SHA-256 | Record lines | Record span SHA-256 | Change |
|---|---|---|---|---|
| r4.6 | `2fa878ffa32c…` | 860–898 | `51602a2341858fcf…` | base of B-05 |
| r4.7 | `110729e54a2c…` | 860–899 | `79cc88c7a7f2567d…` | B-05 follow-up O1–O6 (CR47, D47) |
| r4.8 | `2dfebebfd788…` | 860–900 | `61fd249ea68b2850…` | R10-F1 layout edit (CR48, D48) |
| r4.9 | `9c0f43fce597…` | 860–901 | `b6da1f0584e6b63e…` | Dyadic v6.4.18 synchronization (CR49, D49) |
| r4.10 | `5b1d06544952…` | 861–902 | `b6da1f0584e6b63e…` | G9 W3 only; this record unchanged (CR410, D410) |

## RER-TRIAD-FORMAL-AGE

RER r4.10 lines 503–543; span SHA-256 `7b1548b93e014bca0e348842d5e799562f898614e70af71ed31fce7ce87e2b89`.

### Record text (verbatim)

```
### RER-TRIAD-FORMAL-AGE — Formal age suspension; uniqueness only in polynomial-age coefficient class
**Primary grade:** [THM]. **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none.

| Field | Contract |
|---|---|
| Carrier | formal germ R[[s1,s2,c1,c2]]; C(s,tau) formal graph; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | formal state and transported observables |
| Constraints | F=Id+O(3); F_c(s,0)=0; C_kappa=O(\|s\|^3); At every homogeneous s-degree the age coefficient is polynomial in tau.; Fixed kappa, no physical age clock and no selected continuous-time mechanism. |
| Transformation law | Formal pullback powers (F*)^tau=sum binom(tau,k)(F*-Id)^k; full state and readout transported jointly. |
| Closure status | FORMAL_ONLY: There is a unique polynomial-in-tau coefficient family interpolating all integer-age graphs, with formal F(s,C(s,tau))=(s_plus,C(s_plus,tau+1)). |
| Memory | Formal tau interpolates integer-age sheets; it is not a measured physical clock, independently supplied history, or a convergent memory coordinate. Use the stated observation task and source contract; no memory/age carrier added. |

[THM] **FORMAL_ONLY.** There is a unique polynomial-in-tau coefficient family interpolating all integer-age graphs, with formal F(s,C(s,tau))=(s_plus,C(s_plus,tau+1)).
Formula/witness: `U^tau=sum_{k>=0}binom(tau,k)(U-I)^k; C(s,tau)=Z_tau(S_tau^(-1)(s))`.

**Domain / admissibility:** Formal germ at zero; coefficient identities in tau, not evaluations of a convergent family.

**Map / clock:** `formal germ of the source F=N^6 on ambient X`; F=N^6, each primitive step reprojects.

**Factor or parametrization tested:** NOT_PROPOSED_REDUCTION; parameterization i(s,tau) is specified separately.

**Order / error:** all formal orders; deg_tau C_d<=floor((d-3)/2), d>=3. No convergence radius, numerical remainder constant or uniform-age validity follows.

**Contract type:** `FORMAL_PARAMETERIZATION_SEMICONJUGACY_NOT_REDUCTION`.

**Typed parameterization:** `i(s,tau)=(s,C(s,tau))`; `F_param(s,tau)=(F_s(s,C(s,tau)),tau+1)`.
Compatibility: `F o i = i o F_param, as formal series only`. formal; no analytic evaluation or rank-three manifold asserted.

**Evidence:** original scientific source pins and earlier verification scopes are retained from r2. R3 checks the changed source/wording interfaces and separate Stage-2 metadata behavior; no historical mathematical certificate is rerun.

**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending. [TRIAD_R2_REVIEW: Triadic contributor review of RER v0.2 DRAFT r2 — record-by-record scope check](sources/current/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md); lines 1–30; RID unavailable; exact section pinned; SHA-256 `d388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab`.
Import/reference: [FORMAL: Complete source/record (bounded note or machine artifact)](sources/upstream/TRIAD_FORMAL_AGE_FAMILY_REVIEW_20261009/FORMAL_AGE_FAMILY_REVIEW.md); lines 1–62; RID unavailable; exact section pinned; SHA-256 `b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899`.
Import/reference: [FORMALSCRIPT: Complete source/record (bounded note or machine artifact)](sources/current/triad_formal_age_family_check.py); lines 1–70; RID unavailable; exact section pinned; SHA-256 `5bc3494dae0d4cb390dbe4946382d8d3bbe1167d0613dafc0a34dde48d4f98e1`.
Import/reference: [SERIES2: Complete source/record (bounded note or machine artifact)](sources/current/c09_independent_series_check%20%281%29.py); lines 1–213; RID unavailable; exact section pinned; SHA-256 `67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b`.
[OPEN] real analytic convergence / punctured-domain realization
[OPEN] uniform-in-age quantitative control
[OPEN] physical age/memory interpretation

**Next test:** Controlled N7/N8 defects are a separate task; do not redo formal existence.

**Non-transfer:** No new independent state datum, physical emergence, compulsory historical memory, or physical age variable is established. No automatic RRF registration, universal model exclusion or scientific-owner adoption.
```

### Imports (Phase A r16)

| n | Key | Cited | Section / lines | Bytes | Authentication | Status |
|---|---|---|---|---|---|---|
| 0 | `FORMAL` | 2026-10-09 `b170dbff5ebd` | Complete source/record (bounded note or machine artifact) [1, 62] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | HISTORICAL |
| 1 | `FORMALSCRIPT` | source upload `5bc3494dae0d` | Complete source/record (bounded note or machine artifact) [1, 70] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 2 | `SERIES2` | revision 2 `67b2e0e785dd` | Complete source/record (bounded note or machine artifact) [1, 213] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| receiving review of the formal age-family result, incl. "Independent structural proof" | X-AGE-1 | HELD (b170dbff…3899); the file names no author |
| checker triad_formal_age_family_check.py | X-AGE-2 | HELD (5bc3494d…98e1); it asserts the SHA-256 of ../source/c09_independent_series_check_rev2.py = 67b2e0e7…799b |
| series engine c09_independent_series_check (1).py | X-AGE-3 | HELD (67b2e0e7…799b) — the same bytes the checker expects as source/c09_independent_series_check_rev2.py |
| contributor note RER_C09_INDEPENDENT_VERIFICATION_20261009 (3).md (94b48b73…137) | cited in X-AGE-1 | NOT_HELD — identity as stated by its owner; bytes not in this packet; the RER packages hold a different version "(6)" (d3553fb4…3321, Phase A key CURVNOTE) cited by other records |
| archive TRIAD_C09_TAU_RECEIVING_20261009.zip; positive.log / negative.log | cited in X-AGE-1 | NOT_HELD — identity as stated by its owner; bytes not in this packet |
| review receipt TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md (d388d7eb…e1ab) | Review receipt field | NOT_HELD — identity as stated by its owner; bytes not in this packet |

### Questions for the receiver (no answer is implied)

- **Q-AGE-1** (Construction to all orders): X-AGE-1 defines U^τ := Σ_k binom(τ,k) N^k with N = U − I, U = F^*, and states that N raises total filtration degree by at least two because F − Id = O(3). Which steps make U^τ an algebra automorphism and give U^τ U^σ = U^{τ+σ} (the polynomial-identity argument on nonnegative integers)? Are the three model properties listed there (F(0) = 0 and F = Id + O(3); F_c(s,0) = 0; C_κ = O(‖s‖^3)) the ones in the RER Constraints cell?
- **Q-AGE-2** (Recursion / interpolation identity): The record's formula C(s,τ) = Z_τ(S_τ^{-1}(s)) and the identity F(s,C(s,τ)) = (s_plus, C(s_plus, τ+1)) "as formal series only": does X-AGE-1 derive the identity from U^τ U^1 = U^{τ+1} together with the formal inverse of S_τ (D_{s_0}S_τ(0) = I)?
- **Q-AGE-3** (Degree bound): Three forms occur: the RER Order/error field "deg_tau C_d<=floor((d-3)/2), d>=3"; X-AGE-1 the same bound and "This corrects the contributor's unqualified <=d-4 … a valid weaker bound for d>=5"; X-AGE-2 the checker docstring "degree <= d-4" and NAGES = 9. Which bound does each check test, and which bound does the RER record rely on?
- **Q-AGE-4** (Uniqueness scope): The record claims uniqueness "only in polynomial-age coefficient class" (title, Closure cell); X-AGE-1 says it is not unique in larger smooth/nonpolynomial interpolation classes. Is the claim line itself scoped that way?
- **Q-AGE-5** (No convergence claim): Order/error says no convergence radius, numerical remainder constant or uniform-age validity follows; the [OPEN] lines keep real-analytic convergence, uniform-in-age control and physical age/memory open; X-AGE-1 "What the result does not show". Does any line assert convergence or a manifold?
- **Q-AGE-6** (Finite checks vs all-orders proof): X-AGE-1 calls the checker runs "finite-order sampled tests" (three ray/κ combinations, τ = 1/2, −1/3, 5/2, up to t^12) and assigns the all-orders statement to the structural proof. The RER Evidence field says no historical certificate is rerun in r3. What role do X-AGE-2/X-AGE-3 have for the [THM]?
- **Q-AGE-7** (Provenance): X-AGE-1 writes the hash 67b2e0e7…799b after the name of the archive TRIAD_C09_TAU_RECEIVING_20261009.zip; the checker (X-AGE-2) asserts the same hash for the extracted source/c09_independent_series_check_rev2.py, and the held file "c09_independent_series_check (1).py" has it. The contributor note "(3)" cited there is not held. Does this provenance satisfy the receiver?

### Source extracts (verbatim)

#### X-AGE-1 — FORMAL_AGE_FAMILY_REVIEW.md, whole file (includes the "Independent structural proof")

`sources/triad/FORMAL_AGE_FAMILY_REVIEW.md` lines 1–62; extract SHA-256 `bb385c980c430964236020168df0e39fcfc5b6b9ab66a503c8d59622c953068a`

```
# Triadic / RER C09 — receiving review of formal age-family result

**Date:** 2026-10-09  
**Status:** NONCANONICAL; conditional Genesis analytic modal map, one-time birth contract A. No adopted DSN/RRF or physical-model state modified.

## Received artifacts and provenance

- Contributor note: `RER_C09_INDEPENDENT_VERIFICATION_20261009 (3).md` (SHA-256 `94b48b732e99af8ed980187d21acaa2b68f416626b9cb41bb60c965698480137`). §8 is the new proposed result; §6's earlier tau-update statement is explicitly withdrawn in §7.
- Checker: `triad_formal_age_family_check.py` (SHA-256 `5bc3494dae0d4cb390dbe4946382d8d3bbe1167d0613dafc0a34dde48d4f98e1`).
- Source implementation: `c09_independent_series_check_rev2.py` extracted *without editing* from archived `TRIAD_C09_TAU_RECEIVING_20261009.zip` (SHA-256 `67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b`).

## Receiving disposition

**[ALG, formal — accepted with scope corrections].** Let `F` be the **named** six-step, reproject-after-each-step Genesis analytic modal map, in its formal germ about zero, and let `C_κ(s)=κ Q(s) J_Q s` be the trial birth graph. The only model properties used by the general construction are

1. `F(0)=0` and `F(X)=X+O(||X||^3)`;
2. `F_c(s,0)=0` (the child-free graph is invariant);
3. `C_κ(s)=O(||s||^3)`.

The age-`n` graph `c_n(s)` is the graph of `F^n(graph C_κ)` over current parent `s`, defined as a formal germ. At every homogeneous `s`-degree `d`, its coefficient is polynomial in `n`. A sharper admissible bound is

`deg_n [c_n]_d <= floor((d-3)/2)` for `d>=3`, with `[c_n]_3=C_κ`, independent of age.

This corrects the contributor's unqualified `<=d-4`, which is not meaningful at `d=3`; the latter is a valid weaker bound for `d>=5`.

**Independent structural proof (no coefficient interpolation assumption).** In the completed local algebra `A=R[[s_1,s_2,c_1,c_2]]`, write `U=F^*` for substitution and `N=U-I`. Because `F-Id=O(3)`, `N` raises total filtration degree by at least two. Therefore

`U^τ := sum_{k>=0} binom(τ,k) N^k`

is a valid formal operation, with coefficients polynomial in `τ` at every fixed state degree. On nonnegative integers it is exactly `(F^*)^n`. Each coefficient of `U^τ(fg)-U^τ(f)U^τ(g)` is polynomial in `τ` and vanishes at every nonnegative integer, so it vanishes identically. Thus `U^τ` is a formal algebra automorphism. By the binomial identity `U^τ U^σ=U^{τ+σ}`. These operations define formal fractional iterates `F^τ` without claiming a convergent flow.

Define `(S_τ(s_0),Z_τ(s_0)):=F^τ(s_0,C_κ(s_0))`. Since `D_{s_0}S_τ(0)=I`, it has a formal inverse `s_0=S_τ^{-1}(s)`. Set

`C(s,τ):=Z_τ(S_τ^{-1}(s))`.

Then `C(s,n)=c_n(s)` for every nonnegative integer `n` and

`F(s,C(s,τ))=(s^+,C(s^+,τ+1))`, `s^+=F_s(s,C(s,τ))`,

**as a formal power-series identity**. `C(s,τ)` is unique among series whose coefficients in `s` are polynomials in `τ` and which agree on all integer ages. This does **not** make it unique in larger smooth/nonpolynomial interpolation classes.

The filtration bound follows because `F_c(s,0)=0` keeps the child-coordinate ideal invariant. Each application of `N` raises degree by at least two, and substituting the cubic birth graph raises the order of terms carrying a child factor. Formal inversion of `S_τ` preserves the bound. Consequently the age-degree at `s`-degree `d` is at most `floor((d-3)/2)`.

## What the result does *not* show

- It is not a proven convergent, analytic, or actual smooth three-dimensional invariant manifold for the full six-step map.
- It does not contradict the earlier no-regular-`C^1`-three-fold-through-the-origin theorem: `∂_τ C(0,τ)=0`, so the parametrization is singular there.
- `τ+=τ+1` is a **formal interpolation coordinate**, not a measured event clock, physical memory, or autonomous age recovery from physical observables.
- It is a formal invariant *parameterization/semiconjugacy* of the reachable age sheets, not an observable-preserving two-dimensional factor.
- The `w_13` curvature obstruction persists against **affine-in-τ child fibres at fixed parent**; it is compatible with a curved formal `C(s,τ)`.
- “Every other τ is a reparameterization” is too broad absent the requirement that both charts parameterize the same family with invertible changes. Nonpolynomial interpolants can agree at all integers yet differ between them.
- The exact source remains the conditional analytic modal map, **not** a physically selected standalone-K3 law. Uniform-in-age control, radius of convergence, domain away from zero, and physical birth/event acceptance remain OPEN.

## Receiving execution

The attached checker uses the actual full sin/exp map as exact rational **truncated series**, not the G3/G4 jet alone. It tests polynomial age interpolation on three ray/κ combinations, and noninteger τ=1/2, -1/3, 5/2 up to t^12. These are *finite-order sampled tests*, not a general all-orders theorem; the structural proof above supplies the latter at formal-series scope.

See `positive.log` and `negative.log` for the exact rerun receipts. Hash and provenance above apply to the untouched original script/source bytes; no source scientific owner document was edited.

## Suggested RER handling

Preserve C09. Add §8 as a **noncanonical, model-specific formal-series supplement** rather than silently promoting it to an exact analytic factor theorem. Keep any new scientific RID and physical interpretation unselected. The next meaningful problem is convergence/admissible-domain control of the formal suspension, or an explicitly defined observable-preserving factor on the actual reachable union, not another arbitrary clock parametrization.
```

#### X-AGE-2 — triad_formal_age_family_check.py, docstring (claim, degree bound, scope, negative control)

`sources/triad/triad_formal_age_family_check.py` lines 1–22; extract SHA-256 `52b8d75234143104b0bb2167f79a602305f95649bad32a95c46d685796737182`

```
#!/usr/bin/env python3
"""
Formal F-invariant age family with trivial clock  (Genesis->RER conditional analytic modal model, birth contract A).

Claim [ALG, formal]: at matched current parent s, the s-degree-d coefficient of the age-n child graph c_n(s)
is a polynomial in n of degree <= d-4.  Hence the sheets admit a unique interpolation C(s,tau) that is
polynomial in tau at each s-degree, and because F(s,c_n(s)) = (s+, c_{n+1}(s+)) for every integer n >= 0,
the identity theorem for polynomials gives, order by order in s,

        F( s, C(s,tau) ) = ( s+, C(s+, tau+1) )        for every real tau.

This script tests both statements on the untruncated full map (standard-library exact series, rev2 code):
  * degree bound: age-8 coefficients through t^11 are predicted by Lagrange interpolation of ages 0..7;
  * invariance at non-integer tau (1/2, -1/3, 5/2): zero child residual through t^NT on sampled rays.
Negative control (--negative): uses tau+ = tau + 1 + 1/10 ; must fail and exit 1.

Scope: formal only. Polynomial degree in tau grows with s-degree, so this is a formal family, not a convergent
or smooth 3-fold; all sheets still meet at the origin (C^1 obstruction theorem unchanged); no uniform-in-age
control, physical clock, memory variable or observable-preserving 2D factor is claimed.

Place the contributor's rev2 series file in ../source/ (SHA-256 67b2e0e7...799b).
"""
```

#### X-AGE-3 — c09_independent_series_check (1).py, docstring (model, independence, modes)

`sources/triad/c09_independent_series_check (1).py` lines 1–28; extract SHA-256 `c79acc3913dfe0c6cc56a200096178398d2ad2305639bbf8a655f353a815a909`

```
#!/usr/bin/env python3
"""
Independent reproduction of RER-GEN-C09 (and the C07 / C08 inputs it uses).

Model (Genesis->RER conditional analytic modal contract, 8-9 Oct 2026):
  E = [[1,0],[-1/2,1],[-1/2,-1]],  P = (E^T E)^{-1} E^T = [[2/3,-1/3,-1/3],[0,1/2,-1/2]]
  T_e(r,e) = (r - sin e, e + exp(r) - 1 - sin e)
  N = (P (x) I2) o T_e^{x3} o (E (x) I2),   F = N^6   (reprojection after every primitive step)
  Birth graph (contract A): B_k(s) = (s, k Q(s) J_Q s),  Q(r,e) = r^2 - r e + e^2,
                            J_Q = (1/sqrt3) [[1,-2],[2,-1]].

Independence: this script imports nothing from the RER/C08/C09 packages and does not
read jet_coefficients.json.  It never truncates the map to a G3/G4 jet: it composes the
full analytic sin/exp map as exact power series in a scale parameter t along a ray
s = t*u, truncated only in t (order NT).  Coefficients are exact Fractions.

sqrt(3) bookkeeping: write kappa = sqrt(3)*kt (kt rational).  Then
   C_k(s)      = kt Q(s) M s,          M = [[1,-2],[2,-1]]
   R_k(s)      = -(sqrt3 k/6) Q^2 s    = -(kt/2) Q^2 s
   2k^2/9      = 2 kt^2/3,  k^2/18 = kt^2/6
   Omega_G     = (sqrt3/2) w,  w = s_e c_r - s_r c_e;  claim Omega_G,n = -k Q^2  <=>  w_n = -2 kt Q^2
   age fingerprint 2 sqrt3 I/(Omega_G Q_s) = 4 I/(w Q_s)
so every asserted identity is checked over Q.

Usage:  python c09_independent_series_check.py            (exit 0 iff all checks pass)
        python c09_independent_series_check.py --negative (perturbs the claimed C09 coefficient; must exit 1)
        python c09_independent_series_check.py --quick    (1 kappa, 2 rays, ages 0-2, t^11; for slow environments)
"""
```

## Preparer runs (timing only — not receiver evidence)

| Script | Wall time | Normal mode | Negative mode |
|---|---|---|---|
| triad_formal_age_family_check.py (layout: checker/ and source/c09_independent_series_check_rev2.py) | ≈75 s | exit 0, "12 PASS, 0 FAIL" | --negative: exit 1, "3 PASS, 9 FAIL" |
| c09_independent_series_check (1).py | ≈20 s | exit 0, "511 PASS, 0 FAIL" | --negative: exit 1, "331 PASS, 180 FAIL"; --quick mode exists (≈2 s per its docstring) |

## Context records — CONTEXT_ONLY — NOT REVIEWED IN B-06

### RER-TRIAD-FORMAL-INVOLUTION

RER r4.10 lines 905–946; span SHA-256 `b74deb4bd7b6e83db4381c03ef7204905668807bf026c404c6e36be814774264`; unchanged since r4.6 (B-05 base): yes. Context for a later review round only; not part of the B-06 receiving decision.

| n | Key | Cited | Bytes | Authentication | Status |
|---|---|---|---|---|---|
| 0 | `TRIAD_BGJ` | artifact `494b34f2915e` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 1 | `TRIAD_BGJ_PY` | artifact `5c020986bc0e` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 2 | `TRIAD_CK_PY` | artifact `fac5ffe7ccfe` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 3 | `TRIAD_KR_PY` | artifact `5447338c3fd3` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 4 | `G2NOTE04` | DYAD–RRF–OFN G2 consolidated note v0.4 (noncanonical) `—` | NO_HASH_PRINTED | UNAUTHENTICATED_NO_HASH | HISTORICAL |

```
### RER-TRIAD-FORMAL-INVOLUTION — Formal involution of the conditional modal map; uniqueness only at the primitive clock with linear part −I_4
**Primary grade:** [THM] for (i); [ALG] for (ii). **Exactness:** `FORMAL_ONLY` for (i); `FINITE_ORDER` for (ii). **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none (Triadic co-owner result; not owner-adopted; the preparer is not its reviewer).

| Field | Contract |
|---|---|
| Carrier | Formal germ R[[s1,s2,c1,c2]]; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | Formal state; slot actions rho_Pi = P Pi E (x) I_2. |
| Constraints | DN(0)=A(+)A, A^3=-I; F=N^6=id+G_3+O(4). Fixed conditional model; no physical selection. |
| Transformation law | S^_triad := N^3 o F^{-1/2}. Every slot permutation rho_Pi commutes exactly with N, hence with S^_triad. |
| Closure status | (i) FORMAL_UNIQUE_PRIMITIVE_CLOCK. (ii) LEMMA_K_DOES_NOT_TRANSFER: the cubic kernel is two-dimensional. |
| Memory | Formal symmetry only; no physical node exchange and no memory carrier. |

[THM] **(i) FORMAL_ONLY.** S^_triad is a formal involution with DS^(0)=-I_4 that commutes with N and with every rho_Pi, and it is the unique formal involution that both commutes with N and has linear part -I_4. Proof (dimension-free): R commutes with F hence with the unique tangent-to-identity root F^{-1/2}, so with S^; R S^ is a tangent-to-identity involution, hence the identity. The exact jet check `TRIAD_BGJ_PY` (degree ≤ 5) confirms S^S^=id, S^N=NS^, DS^=-I_4, slot commutation for all four actions, S^ != -I.

[ALG] **(ii) FINITE_ORDER.** Two dyad facts do not transfer. (a) The real commutant of A(+)A is all complex-linear maps of C^2, so involutions commuting with N need not have DR(0)=±I (the exact slot reflections are examples). (b) dim ker(ad_{X_3}) on degree-k real fields of R^4 is 0, **2**, 0, 0, 0, 0 for k=2,…,7 (dyad: 1 at k=3). [NUM] identification in chiral modes u=w1+λw2, v=w1+λ̄w2: the kernel is spanned by A=(a u|u|^2, -iβ*|u|^2 v) and B=(-iβ*|v|^2 u, a v|v|^2), a=1/6-i√3/9, β*=2√3/9, X_3=A+B (fit residual 1e-14). Hence the formal tangent-to-identity centralizer of the triad's F is not known to be {exp(sX)}, uniqueness for involutions commuting with F only is OPEN, and there is no triadic analogue of DYAD-THM-ANALYTIC-CLOCK-BRIDGE.
Formula/witness: `S = N^3 o F^(-1/2)`; `F^(-1/2) = x - g/2 + (3/8)(g o F - g) + O(7)`, g=F-id; `dim ker ad_X3 |_k = (0,2,0,0,0,0)`.

**Domain / admissibility:** Formal germ at 0; kernel dimensions exact for k ≤ 7 only.

**Map / clock:** Uniqueness at the **primitive** clock N. The six-step-only class is OPEN (G6).

**Factor or parametrization tested:** Not a factor; a symmetry classification.

**Order / error:** (i) all formal orders by proof, jet check through degree 5; (ii) exact for k=2,…,7. No convergence.

**Contract type:** `FORMAL_SYMMETRY_CLASSIFICATION`.

**Evidence:** `TRIAD_BGJ_PY` EXECUTED (Triadic contributor; RER editor replay exit 0). Kernel: exact-rational `TRIAD_CK_PY` source-executed (≈90 s); on the receiving side its run timed out after degrees 2–5, so no identical-script replay exists; the receiving co-owner built an independent alternative exact certificate (exact rank lower bounds in two prime fields matched by exact rational null vectors at k = 3), PASS (0,2,0,0,0,0) for k = 2–7, with its zero-cubic negative control failing as expected (19 Oct 2026; RECEIVER-REPORTED, files not in this package); independent float64 SVD replay `TRIAD_KR_PY` EXECUTED by the RER editor (PASS; negative control `--control-real` exits 1) — [NUM] grade; the [ALG] grade of the kernel dimensions rests on the source exact script and the independent receiving-side exact certificate. Note: β*=0 alone also yields dimension 2 (two decoupled dyads), so the dimension is not attributed to the chiral coupling.

**Review receipt:** Triadic reviewer ACCEPT (formal, 15 Oct); RER editor ACCEPT SCOPED with the primitive-clock / -I_4 scope (17 Oct). Independent scientific receiving review of the proof of (i) by a reviewer other than its author is still required before any owner adoption.
Import/reference: [TRIAD_BGJ: TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md §1] (sources/current/TRIAD_R4/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md); SHA-256 `494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413`.
Import/reference: [TRIAD_BGJ_PY: triad_formal_involution_birth_jet.py] (sources/current/TRIAD_R4/triad_formal_involution_birth_jet.py); SHA-256 `5c020986bc0ee54b4c9f0795e954e625088802253b78546a479d17fb193a9feb`.
Import/reference: [TRIAD_CK_PY: triad_cubic_centralizer_kernel_check.py] (sources/current/TRIAD_R4/triad_cubic_centralizer_kernel_check.py); SHA-256 `fac5ffe7ccfefc9ded108b413e04d2bddb1e6d3fbb1b835edea5ba88af082e91`.
Import/reference: [TRIAD_KR_PY: triad_cubic_kernel_chiral_replay.py] (sources/current/TRIAD_R4/triad_cubic_kernel_chiral_replay.py); SHA-256 `5447338c3fd30064b51e0360c0724aa9350ed8a34b3d78a5570ffaf2185f5584`.
Import/reference: [G2NOTE04: DYAD–RRF–OFN G2 consolidated note v0.4 §2] (sources/current/DYAD_RRF_OFN_G2_CONSOLIDATED_NOTE_v0_4.md); no hash printed in the source.
[OPEN] G6: six-step-only uniqueness — whether span{A,B} extends to a two-parameter formal centralizer of F.
[OPEN] Convergence of S^_triad.
[OPEN] Physical node exchange (OFN OPEN-OPA, RRF OPEN-A).

**Next test:** Solve [X,Y]=0 order by order with Y_3=B; the zero kernels at k ≥ 4 make the completion unique if unobstructed, so only the cokernel obstruction has to be computed.

**Non-transfer:** No physical node exchange; slot symmetry is not node-coincidence invariance (RRF §6.2); no identification with the dyad's R_0 or with the h-transported carrier (G2 note §5b). No automatic RRF registration or owner adoption.
```

### RER-TRIAD-BIRTH-GRAPH-INVOLUTION

RER r4.10 lines 949–990; span SHA-256 `4f69e4ad224ccbe71802e02e741c427e6f9452605c03eba2f3cca4ce62918645`; unchanged since r4.6 (B-05 base): yes. Context for a later review round only; not part of the B-06 receiving decision.

| n | Key | Cited | Bytes | Authentication | Status |
|---|---|---|---|---|---|
| 0 | `TRIAD_BGJ` | artifact `494b34f2915e` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 1 | `TRIAD_GC_PY` | artifact `024c9ad1ee5d` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 2 | `POLY` | kappa_tilde=1 / through degree 9 `03042f84016a` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |
| 3 | `GEN287` | 2.8.7 `d5d1e57c6eea` | PRINTED_ONLY | RECEIVER_BYTE_VERIFIED | OWNER_REPORTED |
| 4 | `TRIAD161` | 1.6.1 `95340abe57e9` | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | VERIFIED |

```
### RER-TRIAD-BIRTH-GRAPH-INVOLUTION — Birth graph under S^_triad: degree-4 graph defect, unique even completion, no permutation of age sheets
**Primary grade:** [ALG]. **Exactness:** `FORMAL_ONLY` with exact jets through degree 5. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none (Triadic co-owner result; not owner-adopted; the preparer is not its reviewer).

| Field | Contract |
|---|---|
| Carrier | Trial birth graph B_kappa(s)=(s, kappa~ Q(s) M s), M=[[1,-2],[2,-1]], kappa=sqrt3 kappa~ (= Genesis c_0^{[3]}=kappa Qs J_Q s); formal age family C(s,tau) (RER-TRIAD-FORMAL-AGE). kappa is the Triadic birth coefficient; it is not the Genesis mean-feedback parameter gamma. |
| Observables | Covariance defect D(s)=S^(B(s))-B(-s); graph defect G(s)=S^_c(B)-C(S^_s(B)). |
| Constraints | Fixed real kappa~; formal; the age-sheet statement uses the pinned kappa~=1 table POLY. |
| Transformation law | Covariance (D) and graph invariance (G) are separate contracts; D's degree-2/3 parent terms are effects of S^'s nonlinear chart, not graph data. |
| Closure status | (a) The cubic graph is not S^-invariant: G vanishes at degrees 2–3, is first nonzero at degree 4, and is exactly kappa~-linear. (b) Unique even completion C_4=G_4/2; with it the defect vanishes through degree 5. (c) S^ maps no age sheet onto any age sheet (kappa~=1). |
| Memory | Formal graph geometry; selects no birth initialization, post-birth law or memory carrier. |

[ALG] **(a)** G_4 = kappa~·[3/4 r^4 - 4 r^3 e + 6 r^2 e^2 - 6 r e^3 + 11/4 e^4, 11/4 r^4 - 7 r^3 e + 9 r^2 e^2 - 7 r e^3 + 2 e^4] != 0; D_parent nonzero from degree 2 and kappa-free through degree 5; D_child zero at degrees 2–3, first nonzero at degree 4, proportional to kappa~. [COR] (contributor, 15 Oct) the earlier claim S^(B_kappa(s)) = B_kappa(-s) + O(|s|^5) is withdrawn.
[ALG] **(b)** For c=C_3+C_4+O(5) the degree-4 graph defect is G_4[C_3]-2C_4 (checked for a generic quartic), so C_4=G_4/2 is the unique degree-4 completion; with it the defect vanishes through degree 5 (kappa~=1,2); odd terms C_5 drop out of G_5. Scope: a formal completion through degree 5; all-order existence not claimed.
[ALG] **(c)** POLY has C_4 ≡ 0 for every tau (deg_tau C_4 ≤ 0), so the S^-image of every sheet has quartic Phi_4=G_4 != 0 and is not a sheet tau' for any real tau'.
[ALG] **(d) Remainder-order bookkeeping under a stated child contract.** Child contract used here: the child functional is the graph value itself — a birth places the state on c=C(s) over the current parent inside the conditional modal model; its remainder order p is the leading degree of C(s)-kappa Qs J_Q s. Under this contract the S^-invariant completion has p=4 (C_4 != 0 for kappa~ != 0) and every formal age sheet has p ≥ 5 (C_4 ≡ 0). So, under this contract, S^-compatibility of the birth graph and the Genesis fifth-order branch (OPEN 5/2B, GCL-06) are mutually exclusive. [OPEN] Which child functional, if any, is physical; whether birth is a graph initialization at all; whether either graph is the post-birth law; selection of the p=4 or p=5 branch. An S^-compatible graph existing does not select p=4, and the age family does not select p=5. Adopted Triadic v1.6.1 (§6.1, §6.15, §6.17.2, §7.2, CN-02) states the complete-child remainder and the full-child phase/ratio estimates conditionally on Genesis GCL-06 and the selected child functional. It does not adopt the RER formal-involution graph contract of this record or select the physical p=4 / p≥5 branch. The r4–r4.4 reference to Triadic v1.6.1 DRAFT r1 at this point is historical.
Formula/witness: `G = S_c(B) - C(S_s(B))` first nonzero at degree 4; `G4[C3+C4] = G4[C3] - 2 C4`; `Phi4 = G4 - C4`.

**Domain / admissibility:** Formal; jets through degree 5; (c) on the kappa~=1 table; kappa~-linearity of G_4 extends (a),(b) to every kappa~.

**Map / clock:** S^_triad of RER-TRIAD-FORMAL-INVOLUTION (primitive-clock involution). Contrast: RER-GEN-C07 measures the F-invariance defect of the same graph at degree 5; different object.

**Factor or parametrization tested:** Graph invariance and covariance under the formal involution; not a factor.

**Order / error:** Exact jets through degree 5; no convergence, no remainder constant.

**Contract type:** `GRAPH_INVARIANCE_TEST_UNDER_FORMAL_SYMMETRY_NOT_FACTOR`.

**Evidence:** `TRIAD_BGJ_PY` and `TRIAD_GC_PY` EXECUTED (Triadic contributor; RER editor replays exit 0); POLY re-hashed unchanged.

**Review receipt:** RER editor ACCEPT SCOPED (17 Oct) with the explicit child contract in (d). Independent scientific receiving review by a reviewer other than the author is still required before any owner adoption.
Import/reference: [TRIAD_BGJ: §§2–4] (sources/current/TRIAD_R4/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md); SHA-256 `494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413`.
Import/reference: [TRIAD_GC_PY: triad_involution_graph_completion.py] (sources/current/TRIAD_R4/triad_involution_graph_completion.py); SHA-256 `024c9ad1ee5d36ecc088de1e8301109c75fd236d524987ce4a2e681cf89a0574`.
Import/reference: [POLY: age_family_polynomials_kt1.json] (sources/current/age_family_polynomials_kt1.json); SHA-256 `03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c`.
Import/reference: [GEN287: §2 OPEN 5/2B remainder-order guard; §6.3 GCL-06] (sources/current/RTG_GENESIS_GEOMETRY_DSN_v2_8_7.md); SHA-256 `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361`.
Import/reference: [TRIAD161: Triadic v1.6.1 (adopted 19 Oct 2026), §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md); SHA-256 `95340abe57e999ed48681502152113d8fdb3102f74f45a25aa66c2d0092d451f`; the cited sections are byte-identical to DRAFT r2. History (r4.1–r4.3 citation): [TRIAD161_DRAFT_R2: Triadic v1.6.1 DRAFT r2, §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r2.md); DRAFT, not adopted; SHA-256 `dd67907fc21e457e413c3d6ee924617bc7818c1c200a9bde04fb67649d79b3e7`. r4 cited DRAFT r1 (`31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea`) at sources/current/TRIAD_R4/, while the r4 package held that file at sources/current/ (path erratum); r4.1 places both drafts under sources/current/TRIAD_R4/. Record (d) is independent of the Triadic D3 decision (receiving review, 19 Oct).
[OPEN] All-order existence of the even completion; analytic realization.
[OPEN] Which graph, if any, is the physical birth initialization; physical p-branch selection.

**Next test:** Extend (b) to degree 7: is the degree-6 even completion forced and the degree-7 defect automatic?

**Non-transfer:** No physical birth law, reset or healing inference, compulsory memory, or selection of the p=4 branch. No automatic RRF registration or owner adoption.
```

