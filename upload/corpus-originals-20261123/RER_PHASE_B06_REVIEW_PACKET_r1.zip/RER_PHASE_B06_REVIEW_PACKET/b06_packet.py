"""RER Phase B-06 neutral review packet (preparer: Claude, RER co-owner; NONCANONICAL).
Scope (receiving decision of 20 Oct 2026): three records for independent receiving review -- RER-RRF-CND01, RER-DYAD-FORMAL-INVOLUTION,
RER-TRIAD-FORMAL-AGE -- plus two Triadic records as CONTEXT_ONLY — NOT REVIEWED IN B-06.
The packet quotes byte-pinned sources, lists proof material with its provenance and states questions. It gives no PASS/FAIL, grade or
acceptance recommendation for any claim; the receiver decides ACCEPT SCOPED / CORRECTION REQUIRED / INSUFFICIENT EVIDENCE per record or claim.
Usage: python -I -B b06_packet.py            -> verify inputs, build, write B06_REVIEW_PACKET.json/.md; exit 0 iff all gates pass
       python -I -B b06_packet.py --check    -> verify and compare with the stored outputs byte for byte (no write)
       python -I -B b06_packet.py --negcontrol -> negative controls (each must make its gate fail); exit 0 iff all do"""
import sys, re, json, hashlib, copy
from pathlib import Path
HERE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
FILES = {
 'RER10': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_10.md', '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c'),
 'RER9': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_9.md', '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84'),
 'RER8': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md', '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'),
 'RER7': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_7.md', '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d'),
 'RER6': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md', '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'),
 'MATRIX16': ('sources/rer/PHASEA_r16_SOURCE_CURRENCY_MATRIX.json', 'bee6ca76eeb92a5992e2632755bc71bcc637cbfdcac3ec64f6e998628a4c1fe2'),
 'RRFQ': ('sources/rer/RRF_EDITOR_RESPONSE_TO_RER_PHASEA_v0_2_20261019.md', '413a869b49a295652af1379510fbece2d10619daffd5874c1320e1d686113084'),
 'RRF083': ('sources/owner/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md', 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'),
 'DYAD6418': ('sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md', 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'),
 'FORMAL': ('sources/triad/FORMAL_AGE_FAMILY_REVIEW.md', 'b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899'),
 'FORMALSCRIPT': ('sources/triad/triad_formal_age_family_check.py', '5bc3494dae0d4cb390dbe4946382d8d3bbe1167d0613dafc0a34dde48d4f98e1'),
 'SERIES2': ('sources/triad/c09_independent_series_check (1).py', '67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b'),
 'D47': ('sources/history/r4_6_to_r4_7_DRAFT.diff', 'c3c9025920a56437263bf45b14732d99ccf4f76e3e051ffe55aa4974f0257b2c'),
 'D48': ('sources/history/r4_7_to_r4_8_DRAFT.diff', '76c85da705c05019d34d911090e7243aaf18a6eceaa20cecd80b8b2b4c7776dc'),
 'D49': ('sources/history/r4_8_to_r4_9_DRAFT.diff', 'f3616cdeb81309b4dda9e83dd2c5b5827251a89a2c710e679a0c274291d9dc1a'),
 'D410': ('sources/history/r4_9_to_r4_10_DRAFT.diff', 'ccdb0632f13f1e125793cac1eaa6c14511da59b1fac4a69f8490b5175a2a236f'),
 'CR47': ('sources/history/RER_R4_7_CHANGE_RECORD_20261020.md', 'e92921906ab9ec44ba94809eb33765fb51f54d5faab0d19a1255bb72e0e9d03d'),
 'CR48': ('sources/history/RER_R4_8_CHANGE_RECORD_20261020.md', '8afb1137985187ecafac06a2020194e0bb4a0b9b8288a511734fbca298ab9f17'),
 'CR49': ('sources/history/RER_R4_9_CHANGE_RECORD_20261020.md', '87b259cdccb1c43c1e2ef286e85179bf156c8191807c19bc5c282db86fc94e80'),
 'CR410': ('sources/history/RER_R4_10_CHANGE_RECORD_20261020.md', '23a70495487df16dc67bac815be81cebbc2577883a764c25fc711225f61f82b2'),
 'B05INV': ('sources/history/RER_PHASE_B05_NEUTRAL_SOURCE_INVENTORY_20261020.json', 'b9a978dad834f7a0c21344ac4088e89ae6a779312b43dd417facbdd7fb0aa5e7'),
 'B05INVMD': ('sources/history/RER_PHASE_B05_NEUTRAL_SOURCE_INVENTORY_20261020.md', 'fcf7a081658f22a221f3cadf17e708476a494f81aa40a3911673beee5f04ebf4'),
 'B05NOTE': ('sources/history/RER_PHASE_B05_DYAD_FORMAL_INVOLUTION_READING_NOTE_20261020.md', '26b8f6ce46fd0fa63adb882b72bcd92feb952335b670198da0e98af782221cce'),
 'C_TRIAD161': ('sources/context/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md', '95340abe57e999ed48681502152113d8fdb3102f74f45a25aa66c2d0092d451f'),
 'C_BGJ': ('sources/context/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md', '494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413'),
 'C_POLY': ('sources/context/age_family_polynomials_kt1.json', '03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c'),
 'C_CK': ('sources/context/triad_cubic_centralizer_kernel_check.py', 'fac5ffe7ccfefc9ded108b413e04d2bddb1e6d3fbb1b835edea5ba88af082e91'),
 'C_KR': ('sources/context/triad_cubic_kernel_chiral_replay.py', '5447338c3fd30064b51e0360c0724aa9350ed8a34b3d78a5570ffaf2185f5584'),
 'C_BGJPY': ('sources/context/triad_formal_involution_birth_jet.py', '5c020986bc0ee54b4c9f0795e954e625088802253b78546a479d17fb193a9feb'),
 'C_GC': ('sources/context/triad_involution_graph_completion.py', '024c9ad1ee5d36ecc088de1e8301109c75fd236d524987ce4a2e681cf89a0574'),
}
REVIEW = ['RER-RRF-CND01', 'RER-DYAD-FORMAL-INVOLUTION', 'RER-TRIAD-FORMAL-AGE']
CONTEXT = ['RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION']
CONTEXT_LABEL = 'CONTEXT_ONLY — NOT REVIEWED IN B-06'
# verbatim extracts: (id, record, file key, start-line prefix, end rule) ; end rule = ('prefix', p) | ('rule',) for next '---' | ('line',)
EXTRACTS = [
 ('X-CND-1', 'RER-RRF-CND01', 'RRF083', '### 6.2 ', ('prefix', '### 6.3 '), 'RRF v0.8.3 §6.2 RRF-CND-01 proposed interface (definition grade per RRF editor Q6); the r4.6 overlay cites v0.8.3 §6.2'),
 ('X-CND-2', 'RER-RRF-CND01', 'RRFQ', '**Q6 —', ('line',), 'RRF editor response v0.2, Q6 (provenance split)'),
 ('X-DYAD-1', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '**OPEN 19 —', ('rule',), 'Dyadic v6.4.18 §2 OPEN 19'),
 ('X-DYAD-2', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '**OPEN 20 —', ('rule',), 'Dyadic v6.4.18 §2 OPEN 20'),
 ('X-DYAD-3', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '### §6.15', ('prefix', '### §6.16'), 'Dyadic v6.4.18 §6.15 (analytic clock bridge; domain convention)'),
 ('X-DYAD-4', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '### §6.16', ('prefix', '### §6.17'), 'Dyadic v6.4.18 §6.16 (formal involution, formal centralizer, kernel lemma)'),
 ('X-DYAD-5', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '### §6.17', ('prefix', '## §7.'), 'Dyadic v6.4.18 §6.17 (Lemma F, F1–F3, DYAD-THM-SMOOTH-EMBEDDING)'),
 ('X-DYAD-6', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '- [RID: DYAD-ART-OPEN19-SESSION]', ('line',), 'Dyadic v6.4.18 §8 artifact line: §6.16 proof record'),
 ('X-DYAD-7', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '- [RID: DYAD-ART-OPEN19-KERNEL]', ('line',), 'Dyadic v6.4.18 §8 artifact line: kernel check scripts'),
 ('X-DYAD-8', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '- [RID: DYAD-ART-OPEN19-R0CERT]', ('line',), 'Dyadic v6.4.18 §8 artifact line: R_0 identity certificate'),
 ('X-DYAD-9', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '- [RID: DYAD-ART-LEMMA-F-RECORD]', ('line',), 'Dyadic v6.4.18 §8 artifact line: Lemma F proof record'),
 ('X-DYAD-10', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '- [RID: DYAD-ART-OPEN20-BINF-RECORDS]', ('line',), 'Dyadic v6.4.18 §8 artifact line: smooth-embedding proof records'),
 ('X-DYAD-11', 'RER-DYAD-FORMAL-INVOLUTION', 'DYAD6418', '- [RID: DYAD-ART-OPEN20-BINF-CHECKS]', ('line',), 'Dyadic v6.4.18 §8 artifact line: smooth-embedding check scripts'),
 ('X-DYAD-12', 'RER-DYAD-FORMAL-INVOLUTION', 'RRF083', '## 2.3 ', ('prefix', '## 2.4 '), 'RRF v0.8.3 §2.3 RRF-DYAD-W (carrier frame)'),
 ('X-DYAD-13', 'RER-DYAD-FORMAL-INVOLUTION', 'RRF083', '## 2.4 ', ('prefix', '## 2.4a'), 'RRF v0.8.3 §2.4 RRF-DYAD-NF'),
 ('X-DYAD-14', 'RER-DYAD-FORMAL-INVOLUTION', 'RRF083', '### 2.4b', ('prefix', '### 2.4c'), 'RRF v0.8.3 §2.4b formal involution receipt'),
 ('X-DYAD-15', 'RER-DYAD-FORMAL-INVOLUTION', 'RRF083', '### 2.4c', ('prefix', '## 2.5'), 'RRF v0.8.3 §2.4c formal Z6 and smooth centralizer receipt'),
 ('X-AGE-1', 'RER-TRIAD-FORMAL-AGE', 'FORMAL', '# Triadic / RER C09', ('end',), 'FORMAL_AGE_FAMILY_REVIEW.md, whole file (includes the "Independent structural proof")'),
 ('X-AGE-2', 'RER-TRIAD-FORMAL-AGE', 'FORMALSCRIPT', '#!/usr/bin/env python3', ('prefix', 'import sys, hashlib'), 'triad_formal_age_family_check.py, docstring (claim, degree bound, scope, negative control)'),
 ('X-AGE-3', 'RER-TRIAD-FORMAL-AGE', 'SERIES2', '#!/usr/bin/env python3', ('prefix', 'import '), 'c09_independent_series_check (1).py, docstring (model, independence, modes)'),
]
# proof material not reproduced in the packet; identities as stated by their owners (NOT hashed here unless HELD)
NOT_HELD = 'NOT_HELD — identity as stated by its owner; bytes not in this packet'
PROOF = {
 'RER-RRF-CND01': [
  ('the implication F sigma = sigma F => F(Fix sigma) ⊂ Fix sigma', 'RER record text (r4.10)', 'PREPARER_AUTHORED (RER record); the record states the formula; it contains no written proof'),
  ('RRF v0.8.3 §6.2 interface (Identity–Action / Carrier–Encoding / Clock–Model / Merge)', 'X-CND-1', 'OWNER (RRF), HELD (b393657e…a187)'),
  ('RRF editor response v0.2 Q6 (provenance split)', 'X-CND-2', 'RRF EDITOR, HELD (413a869b…3084)'),
  ('OFN v0.9 §8 and §12.4 (lines 541–557, 1186–1205)', 'import rows n=0,1', NOT_HELD + '; Phase A r16: RECEIVER_BYTE_VERIFIED, HISTORICAL'),
  ('RRF v0.8 §6.2 (lines 333–349)', 'import row n=2', NOT_HELD + '; Phase A r16: HASH_PRINTED_UNVERIFIED, HISTORICAL'),
  ('RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md', 'Missing primary input', NOT_HELD + ' (897bfad0…126d, RRF_EDITOR_VERIFIED)'),
  ('ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip', 'Missing primary input', NOT_HELD + ' (no hash recorded)'),
  ('RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md', 'Missing primary input', NOT_HELD + ' (ea26d3d1…5e, RRF_EDITOR_VERIFIED)'),
 ],
 'RER-DYAD-FORMAL-INVOLUTION': [
  ('Dyadic §2 OPEN 19/20, §6.15–§6.17 text at v6.4.18', 'X-DYAD-1…5', 'OWNER (Dyadic), HELD (f70308f1…458d). The RER pin DYAD6413 (v6.4.13, 5958f7fe…8542) is ' + NOT_HELD + '; byte identity of these blocks is preparer- and receiver-checked only for v6.4.16 → v6.4.17 (5/5) and v6.4.17 → v6.4.18 (OPEN 19, §6.15, §6.16 identical; OPEN 20, §6.17 changed by additions); v6.4.13 → v6.4.16 is not byte-checked by the preparer'),
  ('§6.16 proof record DYAD_OPEN19_FORMAL_CENTRALIZER_PROOF_SESSION.md v1.2', 'X-DYAD-6', NOT_HELD),
  ('kernel and boundary check scripts (DYAD-ART-OPEN19-KERNEL)', 'X-DYAD-7', NOT_HELD + '; Phase A key OPEN19CERTS: owner-reported, not rerun'),
  ('R_0 identity certificate and engine (DYAD-ART-OPEN19-R0CERT)', 'X-DYAD-8', NOT_HELD),
  ('Lemma F proof record v0.3', 'X-DYAD-9', NOT_HELD),
  ('smooth-embedding proof records (seven SESSION files)', 'X-DYAD-10', NOT_HELD + '; project copies with these names exist in the attached project (name match only, bytes not hashed here); written by the Dyadic owner (Claude) and reviewed externally per the owner release record'),
  ('smooth-embedding check scripts and outputs', 'X-DYAD-11', NOT_HELD + '; project copies of the three scripts exist (name match only)'),
  ('RRF v0.8.3 §2.3, §2.4, §2.4b, §2.4c (carrier frame, NF profile, receipts)', 'X-DYAD-12…15', 'OWNER (RRF), HELD (b393657e…a187)'),
  ('RRF v0.8.2 §2.4b, §4.2', 'import row n=1', NOT_HELD + '; Phase A r16: RECEIVER_BYTE_VERIFIED'),
  ('G2 consolidated note v0.4 §2a (independent polar-coordinate proof of the kernel lemma)', 'Evidence field', NOT_HELD + ' (no hash printed; UNAUTHENTICATED_NO_HASH); the owner records it as a citation candidate, not an import'),
  ('B-05 reading note and neutral inventory (20 Oct 2026)', 'sources/history/', 'PREPARER_AUTHORED — not receiver evidence; the receiver\'s earlier disposition covered the inventory as an inventory only, and its corrections to the note became r4.7 O1–O6'),
 ],
 'RER-TRIAD-FORMAL-AGE': [
  ('receiving review of the formal age-family result, incl. "Independent structural proof"', 'X-AGE-1', 'HELD (b170dbff…3899); the file names no author'),
  ('checker triad_formal_age_family_check.py', 'X-AGE-2', 'HELD (5bc3494d…98e1); it asserts the SHA-256 of ../source/c09_independent_series_check_rev2.py = 67b2e0e7…799b'),
  ('series engine c09_independent_series_check (1).py', 'X-AGE-3', 'HELD (67b2e0e7…799b) — the same bytes the checker expects as source/c09_independent_series_check_rev2.py'),
  ('contributor note RER_C09_INDEPENDENT_VERIFICATION_20261009 (3).md (94b48b73…137)', 'cited in X-AGE-1', NOT_HELD + '; the RER packages hold a different version "(6)" (d3553fb4…3321, Phase A key CURVNOTE) cited by other records'),
  ('archive TRIAD_C09_TAU_RECEIVING_20261009.zip; positive.log / negative.log', 'cited in X-AGE-1', NOT_HELD),
  ('review receipt TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md (d388d7eb…e1ab)', 'Review receipt field', NOT_HELD),
 ],
}
TIMING = [  # preparer runs on the session machine, 20 Oct 2026; recorded only to help scheduling; NOT receiver evidence
 ('triad_formal_age_family_check.py (layout: checker/ and source/c09_independent_series_check_rev2.py)', '≈75 s', 'exit 0, "12 PASS, 0 FAIL"', '--negative: exit 1, "3 PASS, 9 FAIL"'),
 ('c09_independent_series_check (1).py', '≈20 s', 'exit 0, "511 PASS, 0 FAIL"', '--negative: exit 1, "331 PASS, 180 FAIL"; --quick mode exists (≈2 s per its docstring)'),
]
QUESTIONS = {
 'RER-RRF-CND01': [
  ('Q-CND-1', 'General theorem', 'The [THM] line states the implication `F sigma=sigma F => F(Fix sigma) subset Fix sigma` and attributes it to "deterministic fixed-model equivariance"; the record gives no written proof. Which hypotheses does the implication use — F single-valued on X, sigma a map of X, F(X) ⊂ X, F sigma = sigma F on all of X or only on Fix sigma — and which of them are stated in the Constraints cell ("Invariant complete-state domain; deterministic F_phys and F_phys sigma=sigma F_phys") and the Domain field?'),
  ('Q-CND-2', 'General theorem', 'Is "invariant" in "Complete-state invariant domain" meant as F(X) ⊂ X, sigma(X) = X, or both, and does the implication need sigma to be an involution (the record says "fixed-model involution sigma")?'),
  ('Q-CND-3', 'Grade attachment', 'The overlay (RRF editor Q6, X-CND-2) attaches the theorem grade to the implication only and the interface structure (RRF v0.8.3 §6.2, X-CND-1) to definition grade. Do the record-level grade [THM] and Exactness `EXACT_CONDITIONAL` read consistently with that split, and what is the "condition" in EXACT_CONDITIONAL?'),
  ('Q-CND-4', 'G2 / physical application (separate from the theorem)', 'The Closure cell says `GENERAL_FIXED_SET_THEOREM_PHYSICAL_APPLICATION_OPEN`, and the overlay lists six realization-contract items (i)–(vi). Does any line of the record assert one of (i)–(vi) for a specific model, clock or carrier? The Map/clock and Factor fields say E, K and the shared clock are "not constructed here".'),
  ('Q-CND-5', 'Missing inputs', 'Three primary inputs are missing (coincidence response v0.2, six-step audit zip, ER-2B v0.2) and the "Secondary-report boundary" line keeps the K3 coincidence report unimported. Does any claim line of the record depend on them?'),
 ],
 'RER-DYAD-FORMAL-INVOLUTION': [
  ('Q-DYAD-1', 'Claim A — formal theorems (§6.16)', 'Compare the Closure cell (FORMAL_UNIQUE: R_0 unique formal involution with DR(0) = −I commuting with F; commutes with T; tangent-to-identity formal centralizer {exp(s log F)}) and the Transformation-law cell with X-DYAD-4. Which owner hypotheses (Constraints: Re mu ≠ 0 and Im mu ≠ 0; real formal category) are used for uniqueness and for the centralizer statement, and are they carried at the point of use?'),
  ('Q-DYAD-2', 'Claim A — normalizer identification (r4.7 O1)', 'The record identifies R_0 = h^(−I)h^(−1) "for any formal Poincaré–Dulac normalizer h^ with λ-equivariant normal form". Where does X-DYAD-4 state this condition, and is R_0 itself defined without a normalizer as the record says?'),
  ('Q-DYAD-3', 'Claim A — kernel lemma', '`DYAD-ALG-CENT-KERNEL` is graded [ALG] by its owner (source note). Its certificates (X-DYAD-7, X-DYAD-8) are not held; the G2 note proof is unauthenticated. What evidence would the receiver require for the [ALG] kernel statement at import level?'),
  ('Q-DYAD-4', 'Claim B — analytic clock bridge (§6.15)', 'The record states the bridge hypotheses as: R real-analytic, R(0) = 0, the owner\'s §6.15 domain convention (0 ∈ int D_Φ), DR(0) = −I; it says the §6.15(b) hypotheses are sufficient for R(0) = 0 but are not the bridge\'s own hypotheses (r4.7 O2). Do these match X-DYAD-3?'),
  ('Q-DYAD-5', 'Claim C — C^∞ realization (v6.4.18)', 'The DYAD6418 [THM] line imports E1–E4 at owner grade (D-C), with E2 restricted to DX\'(0) = 0, a qualitative radius and the route G_∞^{−n}F^n. Compare with X-DYAD-5. The proof records (X-DYAD-10) and checks (X-DYAD-11) are not held here: does the receiver review the import as owner-grade fidelity only, or require the proof records?'),
  ('Q-DYAD-6', 'Claim C — F1–F3 and Lemma F', 'The flat-uniqueness line keeps Lemma F [THM] and F1–F3 [THM — conditional] and states that F1–F3 assert no existence themselves while E1–E4 supply the objects. Is the Lemma F scope (forward-invariant ball B_r ⊂ {Q ≤ 1/400}, flat-contact hypothesis) carried as in X-DYAD-5?'),
  ('Q-DYAD-7', 'Claim D — G2 carrier map and physical exchange (separate)', 'The Carrier cell places R_0 in the raw frame W of RRF-DYAD-W and states that the finite S_h equals R_0 only through jet degree 6 and that the isolated-dyad W is not the network raw W. Compare with X-DYAD-12…15. Does any line of the record assert a G2 carrier map or physical pole exchange (the [OPEN] line "Physical exchange (RRF OPEN-A)" and Non-transfer say no)?'),
  ('Q-DYAD-8', 'Exactness framing (D-A)', 'The record keeps [THM] (owner grade) and FORMAL_ONLY at record level while it now also imports an analytic bridge and a C^∞ result; the source note says the record-level labels describe the formal classification only. Is this framing sufficient for the receiver, claim by claim?'),
  ('Q-DYAD-9', 'Trail and currency', 'The record changed in r4.7 (B-05 O1–O6), r4.8 (R10-F1 layout) and r4.9 (v6.4.18 synchronization); r4.10 did not touch it (spans and hashes in the trail table). Dyadic v6.4.19 is owner-reported as adopted on 20 Oct 2026 (40c9e63f…6ec9; release record: §2 and §3 byte-identical to v6.4.18, new §6.14 result only); its bytes are not in this packet. Does the receiver want a currency check against v6.4.19 before deciding?'),
 ],
 'RER-TRIAD-FORMAL-AGE': [
  ('Q-AGE-1', 'Construction to all orders', 'X-AGE-1 defines U^τ := Σ_k binom(τ,k) N^k with N = U − I, U = F^*, and states that N raises total filtration degree by at least two because F − Id = O(3). Which steps make U^τ an algebra automorphism and give U^τ U^σ = U^{τ+σ} (the polynomial-identity argument on nonnegative integers)? Are the three model properties listed there (F(0) = 0 and F = Id + O(3); F_c(s,0) = 0; C_κ = O(‖s‖^3)) the ones in the RER Constraints cell?'),
  ('Q-AGE-2', 'Recursion / interpolation identity', 'The record\'s formula C(s,τ) = Z_τ(S_τ^{-1}(s)) and the identity F(s,C(s,τ)) = (s_plus, C(s_plus, τ+1)) "as formal series only": does X-AGE-1 derive the identity from U^τ U^1 = U^{τ+1} together with the formal inverse of S_τ (D_{s_0}S_τ(0) = I)?'),
  ('Q-AGE-3', 'Degree bound', 'Three forms occur: the RER Order/error field "deg_tau C_d<=floor((d-3)/2), d>=3"; X-AGE-1 the same bound and "This corrects the contributor\'s unqualified <=d-4 … a valid weaker bound for d>=5"; X-AGE-2 the checker docstring "degree <= d-4" and NAGES = 9. Which bound does each check test, and which bound does the RER record rely on?'),
  ('Q-AGE-4', 'Uniqueness scope', 'The record claims uniqueness "only in polynomial-age coefficient class" (title, Closure cell); X-AGE-1 says it is not unique in larger smooth/nonpolynomial interpolation classes. Is the claim line itself scoped that way?'),
  ('Q-AGE-5', 'No convergence claim', 'Order/error says no convergence radius, numerical remainder constant or uniform-age validity follows; the [OPEN] lines keep real-analytic convergence, uniform-in-age control and physical age/memory open; X-AGE-1 "What the result does not show". Does any line assert convergence or a manifold?'),
  ('Q-AGE-6', 'Finite checks vs all-orders proof', 'X-AGE-1 calls the checker runs "finite-order sampled tests" (three ray/κ combinations, τ = 1/2, −1/3, 5/2, up to t^12) and assigns the all-orders statement to the structural proof. The RER Evidence field says no historical certificate is rerun in r3. What role do X-AGE-2/X-AGE-3 have for the [THM]?'),
  ('Q-AGE-7', 'Provenance', 'X-AGE-1 writes the hash 67b2e0e7…799b after the name of the archive TRIAD_C09_TAU_RECEIVING_20261009.zip; the checker (X-AGE-2) asserts the same hash for the extracted source/c09_independent_series_check_rev2.py, and the held file "c09_independent_series_check (1).py" has it. The contributor note "(3)" cited there is not held. Does this provenance satisfy the receiver?'),
 ],
}
VERDICT = re.compile(r'\b(PASS|FAIL|ACCEPT|ACCEPTED|REJECT|REJECTED|CORRECT|INCORRECT|VALID|INVALID|recommend|recommended|verdict|we conclude|is proved|is wrong)\b', re.I)
TRAIL = [('r4.6', 'RER6', 'base of B-05'), ('r4.7', 'RER7', 'B-05 follow-up O1–O6 (CR47, D47)'), ('r4.8', 'RER8', 'R10-F1 layout edit (CR48, D48)'),
         ('r4.9', 'RER9', 'Dyadic v6.4.18 synchronization (CR49, D49)'), ('r4.10', 'RER10', 'G9 W3 only; this record unchanged (CR410, D410)')]

def load(): return {k: (HERE / p).read_bytes() for k, (p, h) in FILES.items()}
def span(md, rid):
    L = md.split('\n'); i = [n for n, l in enumerate(L) if l.startswith('### ' + rid + ' — ')]
    if len(i) != 1: return None
    i = i[0]; j = next((k for k in range(i + 1, len(L)) if L[k].startswith('### RER-') or L[k].startswith('<a id=') or L[k].startswith('## ')), len(L))
    while j > i and not L[j - 1].strip(): j -= 1
    return i + 1, j, '\n'.join(L[i:j])
def classify(text):
    L = text.split('\n'); out = {'heading': L[0], 'primary_grade_line': None, 'contract_rows': [], 'claim_lines': [], 'open_lines': [], 'import_lines': [], 'fields': [], 'other_lines': []}
    for l in L[1:]:
        if not l.strip() or l in ('| Field | Contract |', '|---|---|'): continue
        if l.startswith('**Primary grade:**'): out['primary_grade_line'] = l
        elif l.startswith('| '): out['contract_rows'].append(l)
        elif re.match(r'^\[(THM|ALG|NUM|DEF)\]', l): out['claim_lines'].append(l)
        elif l.startswith('[OPEN] '): out['open_lines'].append(l)
        elif l.startswith('Import/reference:'): out['import_lines'].append(l)
        elif re.match(r'^\*\*[^*]+:\*\*', l): out['fields'].append(l)
        else: out['other_lines'].append(l)
    return out
def extract(B, fk, start, end):
    t = B[fk].decode('utf-8'); L = t.split('\n'); i = [n for n, l in enumerate(L) if l.startswith(start)]
    if len(i) != 1: return None
    i = i[0]
    if end[0] == 'line': j = i + 1
    elif end[0] == 'end': j = len(L)
    elif end[0] == 'rule': j = next((k for k in range(i + 1, len(L)) if L[k] == '---'), None)
    else: j = next((k for k in range(i + 1, len(L)) if L[k].startswith(end[1])), None)
    if j is None: return None
    while j > i + 1 and not L[j - 1].strip(): j -= 1
    return i + 1, j, '\n'.join(L[i:j])
def build(B):
    md = B['RER10'].decode('utf-8'); M = json.loads(B['MATRIX16'])
    recs = {}
    for rid in REVIEW + CONTEXT:
        s = span(md, rid)
        if s is None: recs[rid] = None; continue
        i, j, t = s
        rows = [{k: x.get(k) for k in ('n', 'key', 'cited_path', 'section_or_RID', 'lines', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash')} for x in M['rows'] if x['record'] == rid]
        r = {'id': rid, 'role': 'REVIEW' if rid in REVIEW else CONTEXT_LABEL, 'rer_r4_10_lines': [i, j], 'span_sha256': sha(t.encode('utf-8')), 'text': t,
             'parts': classify(t), 'phaseA_r16_rows': rows}
        if rid in REVIEW:
            r['extracts'] = []
            for xid, rec, fk, st, en, label in EXTRACTS:
                if rec != rid: continue
                e = extract(B, fk, st, en)
                r['extracts'].append({'id': xid, 'file': FILES[fk][0], 'file_sha256': FILES[fk][1], 'label': label, 'lines': None if e is None else [e[0], e[1]],
                                      'sha256': None if e is None else sha(e[2].encode('utf-8')), 'text': None if e is None else e[2]})
            r['proof_material'] = [{'item': a, 'where': b, 'provenance': c} for a, b, c in PROOF[rid]]
            r['questions'] = [{'id': q, 'topic': tp, 'question': qt} for q, tp, qt in QUESTIONS[rid]]
        else:
            s6 = span(B['RER6'].decode('utf-8'), rid)
            inv = json.loads(B['B05INV']); prior = next((x for x in inv.get('records', []) if x.get('id') == rid), None) if isinstance(inv, dict) else None
            r['b05_r4_6_span_sha256'] = None if s6 is None else sha(s6[2].encode('utf-8'))
            r['unchanged_since_r4_6'] = s6 is not None and s6[2] == t
            r['note'] = 'Context for a later review round only; not part of the B-06 receiving decision.'
        recs[rid] = r
    trail = []
    for v, fk, what in TRAIL:
        s = span(B[fk].decode('utf-8'), 'RER-DYAD-FORMAL-INVOLUTION')
        trail.append({'version': v, 'file': FILES[fk][0], 'file_sha256': FILES[fk][1], 'record_lines': None if s is None else [s[0], s[1]], 'record_span_sha256': None if s is None else sha(s[2].encode('utf-8')), 'change': what})
    return {'_about': 'RER Phase B-06 neutral review packet (NONCANONICAL; preparer Claude, RER co-owner). Verbatim quotations of byte-pinned sources, provenance-labelled proof material and questions; no PASS/FAIL, grade or acceptance recommendation is given for any claim.',
            'scope': {'review': REVIEW, 'context_only': CONTEXT, 'context_label': CONTEXT_LABEL, 'decision_options_of_the_receiver': ['ACCEPT SCOPED', 'CORRECTION REQUIRED', 'INSUFFICIENT EVIDENCE']},
            'files': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()},
            'records': recs, 'dyad_trail': trail,
            'preparer_runs_timing_only': [{'script': a, 'wall_time': b, 'normal_mode': c, 'negative_mode': d, 'label': 'PREPARER_RUN — scheduling information, not receiver evidence'} for a, b, c, d in TIMING],
            'currency_note': 'Dyadic v6.4.19 owner-reported adopted 20 Oct 2026 (40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9, release record claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md); bytes not held; Phase A r16 lists v6.4.18 as current. Not part of B-06.'}
def render(P):
    J = (json.dumps(P, ensure_ascii=False, indent=1) + '\n').encode('utf-8')
    L = ['# RER Phase B-06 — neutral review packet', '', P['_about'], '',
         f"**Review (receiver decides per record or claim: {', '.join(P['scope']['decision_options_of_the_receiver'])}):** " + ', '.join(f'`{r}`' for r in P['scope']['review']),
         f"**{P['scope']['context_label']}:** " + ', '.join(f'`{r}`' for r in P['scope']['context_only']), '', '**Currency note:** ' + P['currency_note'], '']
    for rid in P['scope']['review']:
        r = P['records'][rid]
        L += [f'## {rid}', '', f"RER r4.10 lines {r['rer_r4_10_lines'][0]}–{r['rer_r4_10_lines'][1]}; span SHA-256 `{r['span_sha256']}`.", '', '### Record text (verbatim)', '', '```', r['text'], '```', '',
              '### Imports (Phase A r16)', '', '| n | Key | Cited | Section / lines | Bytes | Authentication | Status |', '|---|---|---|---|---|---|---|']
        L += [f"| {x['n']} | `{x['key']}` | {x['cited_version']} `{(x['cited_sha256'] or '—')[:12]}` | {x['section_or_RID']} {x['lines'] or ''} | {x['bytes_status']} | {x['authentication']} | {x['status']} |" for x in r['phaseA_r16_rows']]
        L += ['', '### Proof material and provenance', '', '| Item | Where | Provenance |', '|---|---|---|'] + [f"| {p['item']} | {p['where']} | {p['provenance']} |" for p in r['proof_material']]
        L += ['', '### Questions for the receiver (no answer is implied)', ''] + [f"- **{q['id']}** ({q['topic']}): {q['question']}" for q in r['questions']]
        L += ['', '### Source extracts (verbatim)', '']
        for x in r['extracts']:
            L += [f"#### {x['id']} — {x['label']}", '', f"`{x['file']}` lines {x['lines'][0]}–{x['lines'][1]}; extract SHA-256 `{x['sha256']}`", '', '```', x['text'], '```', '']
        if rid == 'RER-DYAD-FORMAL-INVOLUTION':
            L += ['### Record trail r4.6 → r4.10', '', '| Version | File SHA-256 | Record lines | Record span SHA-256 | Change |', '|---|---|---|---|---|']
            L += [f"| {t['version']} | `{t['file_sha256'][:12]}…` | {t['record_lines'][0]}–{t['record_lines'][1]} | `{t['record_span_sha256'][:16]}…` | {t['change']} |" for t in P['dyad_trail']] + ['']
    L += ['## Preparer runs (timing only — not receiver evidence)', '', '| Script | Wall time | Normal mode | Negative mode |', '|---|---|---|---|'] + [f"| {t['script']} | {t['wall_time']} | {t['normal_mode']} | {t['negative_mode']} |" for t in P['preparer_runs_timing_only']]
    L += ['', f"## Context records — {P['scope']['context_label']}", '']
    for rid in P['scope']['context_only']:
        r = P['records'][rid]
        L += [f'### {rid}', '', f"RER r4.10 lines {r['rer_r4_10_lines'][0]}–{r['rer_r4_10_lines'][1]}; span SHA-256 `{r['span_sha256']}`; unchanged since r4.6 (B-05 base): {'yes' if r['unchanged_since_r4_6'] else 'no'}. {r['note']}", '',
              '| n | Key | Cited | Bytes | Authentication | Status |', '|---|---|---|---|---|---|'] + [f"| {x['n']} | `{x['key']}` | {x['cited_version']} `{(x['cited_sha256'] or '—')[:12]}` | {x['bytes_status']} | {x['authentication']} | {x['status']} |" for x in r['phaseA_r16_rows']]
        L += ['', '```', r['text'], '```', '']
    return J, ('\n'.join(L) + '\n').encode('utf-8')
def gates(B, P, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    on_disk = sorted(str(f.relative_to(HERE)) for f in (HERE / 'sources').rglob('*') if f.is_file())
    g('B1 input pins: every file under sources/ is pinned, every pin is present with its hash', on_disk == sorted(p for p, h in FILES.values()) and all(sha(B[k]) == h for k, (p, h) in FILES.items()), f'{len(FILES)} files')
    R = P['records']; md = B['RER10'].decode('utf-8')
    ok2 = all(R.get(r) and span(md, r) and R[r]['text'] == span(md, r)[2] and R[r]['span_sha256'] == sha(R[r]['text'].encode('utf-8')) and R[r]['text'] in md for r in REVIEW + CONTEXT)
    g('B2 record spans: each record found once in r4.10, text verbatim, span hash recomputes', ok2)
    M = json.loads(B['MATRIX16'])
    ok3 = all(R[r] and [x['key'] for x in R[r]['phaseA_r16_rows']] == [x['key'] for x in M['rows'] if x['record'] == r]
              and len(R[r]['phaseA_r16_rows']) == len(R[r]['parts']['import_lines']) for r in REVIEW + CONTEXT)
    g('B3 Phase A r16 rows match the pinned matrix and the record\'s Import/reference lines', ok3)
    X = [x for r in REVIEW for x in (R[r] or {}).get('extracts', [])]
    ok4 = len(X) == len(EXTRACTS) and all(x['text'] and x['sha256'] == sha(x['text'].encode('utf-8')) and x['text'] in B[next(k for k, (p, h) in FILES.items() if p == x['file'])].decode('utf-8') for x in X)
    g('B4 source extracts: anchors unique, non-empty, verbatim, hashes recompute', ok4, f'{len(X)} extracts')
    tr = P['dyad_trail']
    ok5 = [t['version'] for t in tr] == ['r4.6', 'r4.7', 'r4.8', 'r4.9', 'r4.10'] and all(t['record_span_sha256'] for t in tr) and tr[3]['record_span_sha256'] == tr[4]['record_span_sha256'] == R['RER-DYAD-FORMAL-INVOLUTION']['span_sha256'] \
          and len({t['record_span_sha256'] for t in tr}) == 4
    g('B5 DYAD trail: r4.6 → r4.10 spans present; r4.7, r4.8, r4.9 each change the record; r4.10 leaves it unchanged', ok5)
    texts = [q['question'] for r in REVIEW for q in R[r]['questions']] + [p['provenance'] for r in REVIEW for p in R[r]['proof_material']] + [p['item'] for r in REVIEW for p in R[r]['proof_material']] + [P['_about'], P['currency_note']]
    unq = lambda t: re.sub(r'`[^`]*`', '', re.sub(r'"[^"]*"', '', t)).replace('no PASS/FAIL', '')  # quoted source text is not preparer judgement
    hits = [t[:50] for t in texts if VERDICT.search(unq(t))]
    g('B6 neutrality: no verdict word in the preparer-written questions, provenance and notes', not hits, f'{len(hits)} hit(s) {hits[:1]}')
    ok7 = P['scope']['review'] == REVIEW and P['scope']['context_only'] == CONTEXT and all(R[r]['role'] == 'REVIEW' and 'questions' in R[r] for r in REVIEW) \
          and all(R[r]['role'] == CONTEXT_LABEL and 'questions' not in R[r] and 'extracts' not in R[r] for r in CONTEXT) and len(REVIEW) == 3
    g('B7 scope: exactly three review records; the two Triadic records CONTEXT_ONLY — NOT REVIEWED IN B-06, with no questions or extracts', ok7)
    pm = [p for r in REVIEW for p in R[r]['proof_material']]
    ok8 = all(('RECEIVER' not in p['provenance'] or 'Phase A r16: RECEIVER_BYTE_VERIFIED' in p['provenance'] or 'not receiver evidence' in p['provenance']) for p in pm) \
          and all('PREPARER_AUTHORED' in p['provenance'] for p in pm if 'B-05' in p['item'] or p['where'].startswith('RER record')) \
          and all(t['label'].startswith('PREPARER_RUN') and 'not receiver evidence' in t['label'] for t in P['preparer_runs_timing_only'])
    g('B8 provenance: preparer-authored items and preparer runs labelled as such; nothing preparer-made is labelled receiver evidence', ok8)
    return all(res), res
if __name__ == '__main__':
    B = load(); a = sys.argv[1:]
    if a and a[0] == '--negcontrol':
        P0 = build(B); allf = True
        def run(n, BB, PP, gi):
            global allf
            _, rr = gates(BB, PP, verbose=False); good = not rr[gi]; allf &= good
            print(f'  negative control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
        fl = lambda b: b[:100] + bytes([b[100] ^ 1]) + b[101:]
        run('B1 one byte flipped in RRF v0.8.3', dict(B, RRF083=fl(B['RRF083'])), P0, 0)
        P1 = copy.deepcopy(P0); P1['records']['RER-RRF-CND01']['text'] = P1['records']['RER-RRF-CND01']['text'].replace('[THM]', '[ALG]', 1); run('B2 record text paraphrased', B, P1, 1)
        P2 = copy.deepcopy(P0); P2['records']['RER-TRIAD-FORMAL-AGE']['phaseA_r16_rows'].pop(); run('B3 an import row dropped', B, P2, 2)
        P3 = copy.deepcopy(P0); P3['records']['RER-DYAD-FORMAL-INVOLUTION']['extracts'][2]['text'] = P3['records']['RER-DYAD-FORMAL-INVOLUTION']['extracts'][2]['text'].replace('real-analytic', 'analytic', 1); run('B4 an extract altered', B, P3, 3)
        P4 = copy.deepcopy(P0); P4['dyad_trail'][4]['record_span_sha256'] = '0' * 64; run('B5 trail hash forged', B, P4, 4)
        P5 = copy.deepcopy(P0); P5['records']['RER-RRF-CND01']['questions'][0]['question'] += ' The implication is proved.'; run('B6 verdict inserted in a question', B, P5, 5)
        P6 = copy.deepcopy(P0); P6['records']['RER-TRIAD-FORMAL-AGE']['proof_material'][0]['provenance'] += ' — ACCEPT'; run('B6 acceptance word in provenance', B, P6, 5)
        P7 = copy.deepcopy(P0); P7['scope']['review'] = REVIEW + ['RER-TRIAD-FORMAL-INVOLUTION']; run('B7 context record moved into the review list', B, P7, 6)
        P8 = copy.deepcopy(P0); P8['records']['RER-TRIAD-BIRTH-GRAPH-INVOLUTION']['role'] = 'REVIEW'; run('B7 context label removed', B, P8, 6)
        P9 = copy.deepcopy(P0); P9['records']['RER-DYAD-FORMAL-INVOLUTION']['proof_material'][-1]['provenance'] = 'RECEIVER-VERIFIED reading note'; run('B8 preparer note labelled receiver evidence', B, P9, 7)
        P10 = copy.deepcopy(P0); P10['preparer_runs_timing_only'][0]['label'] = 'RECEIVER_RUN'; run('B8 preparer run labelled receiver run', B, P10, 7)
        sys.exit(0 if allf else 1)
    P = build(B); ok, res = gates(B, P); J, Md = render(P)
    if a and a[0] == '--check':
        same = (HERE / 'B06_REVIEW_PACKET.json').read_bytes() == J and (HERE / 'B06_REVIEW_PACKET.md').read_bytes() == Md
        print(f'{sum(res)}/{len(res)} gates PASS; stored outputs byte-identical: {same}'); sys.exit(0 if ok and same else 1)
    (HERE / 'B06_REVIEW_PACKET.json').write_bytes(J); (HERE / 'B06_REVIEW_PACKET.md').write_bytes(Md)
    print(f'{sum(res)}/{len(res)} gates PASS; B06_REVIEW_PACKET.json {sha(J)[:16]}, B06_REVIEW_PACKET.md {sha(Md)[:16]}'); sys.exit(0 if ok else 1)
