<a id="rer-gen-k3-modal"></a>
### RER-GEN-K3-MODAL — Genesis projected-K3 factor no-go transported to the conditional modal map (both clocks)
**Primary grade:** [THM] (owner import) with an [ALG] transport step. **Exactness:** `EXACT_LOCAL`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Genesis v2.8.6 (primitive clock) and v2.8.7 (six-step clock).

| Field | Contract |
|---|---|
| Carrier | Ambient modal state X=(s,c) in R4 of §3; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; identified with the Genesis sum-zero carrier C={w1+w2+w3=0} by the linear isomorphism E; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | Any local submersion E' from (R4,0) onto a d-manifold, d in {1,2,3}; no observable is privileged. |
| Constraints | Primitive contract E' o N = T' o E' or six-step contract E' o F = T' o E' near 0, with F=N^6. T' arbitrary (no hypothesis on its fixed point, linear part or cubic coefficient). Regularity: primitive clock C^1 for d=1,3 and C^3 for d=2; six-step clock C^3 for d=1,2,3. |
| Transformation law | PE=I_2 and EP=I_3-J/3 (mean subtraction), hence E o N = F_1 o E with F_1=P_C o T^{x3} (Genesis §6.3a model). Iterating: E o N^6 = F_1^6 o E. Both are linear conjugacies, so factors and regularity transport exactly. |
| Closure status | NO_LOWER_DIMENSIONAL_FACTOR_AT_EITHER_CLOCK: N has no local C^1 factor of dimension 1 or 3 and no local C^3 planar factor (primitive clock); F=N^6 has no local C^3 submersive factor of dimension 1, 2 or 3 (six-step clock). |
| Memory | A factor obstruction is not a proof of new information, physical dimension or compulsory memory. No memory or age carrier is added. |

[THM] **EXACT_LOCAL — primitive clock.** `[import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3a | RID: GEN-THM-K3-PLANAR-FACTOR-NOGO]` (adopted v2.8.6; byte-identical in v2.8.7). The projected-K3 primitive map has no local submersive factor of strictly lower real dimension: d=1,3 excluded at C^1; d=2 excluded at C^3.

[THM] **EXACT_LOCAL — six-step clock.** `[import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3a.1 | RID: GEN-THM-K3-SIXSTEP-FACTOR-NOGO]` (adopted 18 Oct 2026). Under E o F_1^6 = T' o E there is no local C^3 submersive factor for d=1,2,3, with no hypothesis on T' beyond C^3. Supporting owner lemma: `GEN-THM-CHIRAL-CUBIC-FACTOR-LEMMA`.

[ALG] **Transport.** E o N = F_1 o E from the exact identities PE=I and EP=I-J/3; therefore E o N^6 = F_1^6 o E. Every factor of N (resp. F) gives a factor of F_1 (resp. F_1^6) with the same target, regularity and T', and conversely. The six-step identity is the algebraic consequence of the primitive one and needs no separate certificate.
Formula/witness: `E o N = F1 o E`; `PE=I`; `EP=I-J/3`; numerical check max|E N(x) - F1(E x)| = 1.3e-51 at 50 random points (50 digits).

**Domain / admissibility:** Local germs at 0, as in Genesis §6.3a / §6.3a.1. No sector or punctured domain.

**Map / clock:** Both clocks, each with its own owner RID; they are not merged. The factor contracts E F = T' E and E F^6 = T' E remain distinct (Genesis SG-15/SG-16).

**Factor or parametrization tested:** Arbitrary local submersive semiconjugacy onto lower-dimensional dynamics, at each clock.

**Order / error:** Exact local (cubic comparison in the owner proofs); no radius.

**Contract type:** `SEMICONJUGACY_NO_GO_BOTH_CLOCKS`. Distinct from RER-GEN-C05/C06 (six-step, Qs-preserving minimal-rank tests) and from RER-GEN-C08/C10 (reachable and regular-reachable factor tests); none implies another.

**Evidence:** owner theorems SOURCE-READ in the project copies (Genesis v2.8.7 hash as reported by its release record; byte-authenticated by the RER editor on 18 Oct); source data certificate `k3_obstruction_exact_check.py` (`384aaa5f…01ee`) owner-reported, not rerun here; E-conjugacy script `TRIAD_EC_PY` EXECUTED (Triadic contributor and RER editor, both exit 0); six-step linear-algebra step corroborated exactly by `TRIAD_SB_PY` (DX_3 algebra = M_4(Q); block-diagonal control exits 1), EXECUTED by both. The RER has not independently re-proved either owner theorem.

**Review receipt:** RER editor ACCEPT SCOPED (17 Oct) with the primitive-clock boundary; six-step extension recorded 18 Oct after Genesis v2.8.7 adoption.
Import/reference: [GEN287: §6.3a, §6.3a.1, SG-15, SG-16, §7 export] (sources/current/RTG_GENESIS_GEOMETRY_DSN_v2_8_7.md); RID: GEN-THM-K3-PLANAR-FACTOR-NOGO, GEN-THM-K3-SIXSTEP-FACTOR-NOGO; SHA-256 `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361`.
Import/reference: [K3REC: K3 cubic-factor obstruction SESSION record v0.1.2] (sources/current/K3_CUBIC_FACTOR_OBSTRUCTION_SESSION_RECORD_v0_1_2.md); RID unavailable; SHA-256 `9f95d48d23a340738146271d4bcf1a483b04252e9210c9f403a7f23172dd083a`.
Import/reference: [K36S: K3/κ-family six-step proof record v0.3] (sources/current/K3_KAPPA_SIX_STEP_CLOCK_NOTE_v0_3.md); RID unavailable; SHA-256 `049e313e4f07ffe5e576018426a5776aab9b602b0c5c55ef286c71d750babc9e`.
Import/reference: [TRIAD_EC_PY: triad_k3_econjugacy_check.py] (sources/current/TRIAD_R4/triad_k3_econjugacy_check.py); lines 1–40; SHA-256 `c3168ca31144d5ac9a4f08067b1346be4f61a67f91f79b545940c1f67ce5cb62`.
Import/reference: [TRIAD_SB_PY: triad_six_step_factor_burnside_check.py] (sources/current/TRIAD_R4/triad_six_step_factor_burnside_check.py); SHA-256 `1ae0df35bfd437afc935c02d3d4559582ca66bd73a9a9d35253a5952274bf575`.
[OPEN] C^1/C^2 planar factors (d=2) at either clock.
[OPEN] Non-submersive or non-local factor maps; other carriers, including the h-transported carrier.
[OPEN] Physical node exchange / G2 realization (RRF OPEN-A, OFN OPEN-OPA).

**Next test:** None for the submersive C^3 class. Lower regularity and non-submersive classes are separate questions.

**Non-transfer:** No physical node-exchange, carrier or network–dyad selection (Genesis SG-15/SG-16). The mean-feedback family theorem `GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO` (R6, parameter gamma, hypothesis (H_spec)) is context only: the RER model lives on the carrier (gamma=1 equivalent) and this record does not rest on it. No new independent state datum or physical emergence. No automatic RRF registration.

<a id="rer-dyad-formal-involution"></a>
### RER-DYAD-FORMAL-INVOLUTION — Unique formal −I involution of the isolated dyad (owner import)
**Primary grade:** [THM] (owner grade). **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12 (released as v6.4.12.1).

| Field | Contract |
|---|---|
| Carrier | Formal germs of the isolated dyad at P1 in the raw linear frame W=L(rho,eta); profile RRF-DYAD-W (RRF v0.8.2 §2.3, §2.4b). Not the triad carrier. |
| Observables | Formal state; no comparator privileged. |
| Constraints | F=T^6=id+mu|W|^2 W+O(4) with Re mu != 0 and Im mu != 0; real formal category. |
| Transformation law | R_0=T^3 o F^{-1/2}=h^(-I)h^{-1} for any formal Poincaré–Dulac normalizer h^. The finite chart S_h=h_6(-I)h_6^{-1} equals R_0 only through jet degree 6. |
| Closure status | FORMAL_UNIQUE: R_0 is the unique formal involution with DR(0)=-I commuting with F; it also commutes with T. The tangent-to-identity formal centralizer of F is {exp(s log F)}. |
| Memory | Formal symmetry; no physical pole exchange and no memory carrier. |

[THM] **FORMAL_ONLY.** `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.12.1 §6.16 | RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE, DYAD-THM-FORMAL-CENTRALIZER, DYAD-ALG-CENT-KERNEL]`. Conditional analytic consequence `[§6.15 | RID: DYAD-THM-ANALYTIC-CLOCK-BRIDGE]`: an analytic involution with R T^6 = T^6 R and DR(0)=-I commutes exactly with T.
Formula/witness: `R_0 = T^3 o F^(-1/2)`; `Cent_formal,DG=I(F) = {exp(s X)}`, `X = log F`.

**Domain / admissibility:** Formal; the analytic bridge is local under the owner's §6.15(b) hypotheses.

**Map / clock:** T and T^6; the same formal involution is selected for both. The factor contracts E F = T E and E F = T^6 E remain distinct.

**Factor or parametrization tested:** Not a factor; a symmetry classification.

**Order / error:** All formal orders. Convergence: OPEN 20 (`DYAD-OPEN-INVOLUTION-REALIZATION`).

**Contract type:** `FORMAL_SYMMETRY_CLASSIFICATION`.

**Evidence:** owner theorem SOURCE-READ (project copy); owner-reported certificates `dyad_open19_kernel_check.py` (`1cb40446…291e`) and `dyad_open19_R0_identity_cert.py` (`c8c14442…cf8`), not rerun here; independent polar-coordinate proof of the kernel lemma in the G2 consolidated note v0.4 §2a, SOURCE-READ. RRF v0.8.2 §2.4b records the same import at RRF working-standard scope.

**Review receipt:** RER editor ACCEPT SCOPED (17 Oct).
Import/reference: [DYAD6412_1: §6.15, §6.16, §2 OPEN 19/20] (sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_12_1.md); SHA-256 `36e7ef58c952f19cd48683c601957f6a01d90c2e2c6f548b28c1707764c5f107` (owner-reported; v6.4.12 `c2f00eb0…38e8`).
Import/reference: [RRF082: §2.4b, §4.2] (sources/current/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md); file hash not printed in the source; header-authenticated only.
[OPEN] OPEN 20 B-an: convergence of R_0, equivalently of F^{1/2}.
[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness.
[OPEN] Physical exchange (RRF OPEN-A).

**Next test:** None in RER; owner import.

**Non-transfer:** No triad statement follows (see RER-TRIAD-FORMAL-INVOLUTION). No physical pole exchange. S_h is not upgraded beyond degree 6.

<a id="rer-triad-formal-involution"></a>
### RER-TRIAD-FORMAL-INVOLUTION — Formal involution of the conditional modal map; uniqueness only at the primitive clock with linear part −I_4
**Primary grade:** [THM] for (i); [ALG] for (ii). **Exactness:** `FORMAL_ONLY` for (i); `FINITE_ORDER` for (ii). **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none (Triadic co-owner result; not owner-adopted; the preparer is not its reviewer).

| Field | Contract |
|---|---|
| Carrier | Formal germ R[[s1,s2,c1,c2]]; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | Formal state; slot actions rho_Pi = P Pi E (x) I_2. |
| Constraints | DN(0)=A(+)A, A^3=-I; F=N^6=id+G_3+O(4). Fixed conditional model; no physical selection. |
| Transformation law | S^_triad := N^3 o F^{-1/2}. Every slot permutation rho_Pi commutes exactly with N, hence with S^_triad. |
| Closure status | (i) FORMAL_UNIQUE_PRIMITIVE_CLOCK. (ii) LEMMA_K_DOES_NOT_TRANSFER: the cubic kernel is two-dimensional. |
| Memory | Formal symmetry only; no physical node exchange and no memory carrier. |

[THM] **(i) FORMAL_ONLY.** S^_triad is a formal involution with DS^(0)=-I_4 that commutes with N and with every rho_Pi, and it is the unique formal involution that both commutes with N and has linear part -I_4. Proof (dimension-free): R commutes with F hence with the unique tangent-to-identity root F^{-1/2}, so with S^; R S^ is a tangent-to-identity involution, hence the identity. The exact jet check `TRIAD_BGJ_PY` (degree ≤ 5) confirms S^S^=id, S^N=NS^, DS^=-I_4, slot commutation for all four actions, S^ != -I.

[ALG] **(ii) FINITE_ORDER.** Two dyad facts do not transfer. (a) The real commutant of A(+)A is all complex-linear maps of C^2, so involutions commuting with N need not have DR(0)=±I (the exact slot reflections are examples). (b) dim ker(ad_{X_3}) on degree-k real fields of R^4 is 0, **2**, 0, 0, 0, 0 for k=2,…,7 (dyad: 1 at k=3). [NUM] identification in chiral modes u=w1+λw2, v=w1+λ̄w2: the kernel is spanned by A=(a u|u|^2, -iβ*|u|^2 v) and B=(-iβ*|v|^2 u, a v|v|^2), a=1/6-i√3/9, β*=2√3/9, X_3=A+B (fit residual 1e-14). Hence the formal tangent-to-identity centralizer of the triad's F is not known to be {exp(sX)}, uniqueness for involutions commuting with F only is OPEN, and there is no triadic analogue of DYAD-THM-ANALYTIC-CLOCK-BRIDGE.
Formula/witness: `S = N^3 o F^(-1/2)`; `F^(-1/2) = x - g/2 + (3/8)(g o F - g) + O(7)`, g=F-id; `dim ker ad_X3 |_k = (0,2,0,0,0,0)`.

**Domain / admissibility:** Formal germ at 0; kernel dimensions exact for k ≤ 7 only.

**Map / clock:** Uniqueness at the **primitive** clock N. The six-step-only class is OPEN (G6).

**Factor or parametrization tested:** Not a factor; a symmetry classification.

**Order / error:** (i) all formal orders by proof, jet check through degree 5; (ii) exact for k=2,…,7. No convergence.

**Contract type:** `FORMAL_SYMMETRY_CLASSIFICATION`.

**Evidence:** `TRIAD_BGJ_PY` EXECUTED (Triadic contributor; RER editor replay exit 0). Kernel: exact-rational `TRIAD_CK_PY` source-executed (≈90 s), receiving exact replay pending; independent float64 SVD replay `TRIAD_KR_PY` EXECUTED by the RER editor (PASS; negative control `--control-real` exits 1) — [NUM] grade; the [ALG] grade of the kernel dimensions rests on the exact script. Note: β*=0 alone also yields dimension 2 (two decoupled dyads), so the dimension is not attributed to the chiral coupling.

**Review receipt:** Triadic reviewer ACCEPT (formal, 15 Oct); RER editor ACCEPT SCOPED with the primitive-clock / -I_4 scope (17 Oct). Independent scientific receiving review of the proof of (i) by a reviewer other than its author is still required before any owner adoption.
Import/reference: [TRIAD_BGJ: TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md §1] (sources/current/TRIAD_R4/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md); SHA-256 `494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413`.
Import/reference: [TRIAD_BGJ_PY: triad_formal_involution_birth_jet.py] (sources/current/TRIAD_R4/triad_formal_involution_birth_jet.py); SHA-256 `5c020986bc0ee54b4c9f0795e954e625088802253b78546a479d17fb193a9feb`.
Import/reference: [TRIAD_CK_PY: triad_cubic_centralizer_kernel_check.py] (sources/current/TRIAD_R4/triad_cubic_centralizer_kernel_check.py); SHA-256 `fac5ffe7ccfefc9ded108b413e04d2bddb1e6d3fbb1b835edea5ba88af082e91`.
Import/reference: [TRIAD_KR_PY: triad_cubic_kernel_chiral_replay.py] (sources/current/TRIAD_R4/triad_cubic_kernel_chiral_replay.py); SHA-256 `5447338c3fd30064b51e0360c0724aa9350ed8a34b3d78a5570ffaf2185f5584`.
Import/reference: [G2NOTE04: DYAD–RRF–OFN G2 consolidated note v0.4 §2] (sources/current/DYAD_RRF_OFN_G2_CONSOLIDATED_NOTE_v0_4.md); no hash printed in the source.
[OPEN] G6: six-step-only uniqueness — whether span{A,B} extends to a two-parameter formal centralizer of F.
[OPEN] Convergence of S^_triad.
[OPEN] Physical node exchange (OFN OPEN-OPA, RRF OPEN-A).

**Next test:** Solve [X,Y]=0 order by order with Y_3=B; the zero kernels at k ≥ 4 make the completion unique if unobstructed, so only the cokernel obstruction has to be computed.

**Non-transfer:** No physical node exchange; slot symmetry is not node-coincidence invariance (RRF §6.2); no identification with the dyad's R_0 or with the h-transported carrier (G2 note §5b). No automatic RRF registration or owner adoption.

<a id="rer-triad-birth-graph-involution"></a>
### RER-TRIAD-BIRTH-GRAPH-INVOLUTION — Birth graph under S^_triad: degree-4 graph defect, unique even completion, no permutation of age sheets
**Primary grade:** [ALG]. **Exactness:** `FORMAL_ONLY` with exact jets through degree 5. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none (Triadic co-owner result; not owner-adopted; the preparer is not its reviewer).

| Field | Contract |
|---|---|
| Carrier | Trial birth graph B_kappa(s)=(s, kappa~ Q(s) M s), M=[[1,-2],[2,-1]], kappa=sqrt3 kappa~ (= Genesis c_0^{[3]}=kappa Qs J_Q s); formal age family C(s,tau) (RER-TRIAD-FORMAL-AGE). kappa is the Triadic birth coefficient; it is not the Genesis mean-feedback parameter gamma. |
| Observables | Covariance defect D(s)=S^(B(s))-B(-s); graph defect G(s)=S^_c(B)-C(S^_s(B)). |
| Constraints | Fixed real kappa~; formal; the age-sheet statement uses the pinned kappa~=1 table POLY. |
| Transformation law | Covariance (D) and graph invariance (G) are separate contracts; D's degree-2/3 parent terms are effects of S^'s nonlinear chart, not graph data. |
| Closure status | (a) The cubic graph is not S^-invariant: G vanishes at degrees 2–3, is first nonzero at degree 4, and is exactly kappa~-linear. (b) Unique even completion C_4=G_4/2; with it the defect vanishes through degree 5. (c) S^ maps no age sheet onto any age sheet (kappa~=1). |
| Memory | Formal graph geometry; selects no birth initialization, post-birth law or memory carrier. |

[ALG] **(a)** G_4 = kappa~·[3/4 r^4 - 4 r^3 e + 6 r^2 e^2 - 6 r e^3 + 11/4 e^4, 11/4 r^4 - 7 r^3 e + 9 r^2 e^2 - 7 r e^3 + 2 e^4] != 0; D_parent nonzero from degree 2 and kappa-free through degree 5; D_child zero at degrees 2–3, first nonzero at degree 4, proportional to kappa~. [COR] (contributor, 15 Oct) the earlier claim S^(B_kappa(s)) = B_kappa(-s) + O(|s|^5) is withdrawn.
[ALG] **(b)** For c=C_3+C_4+O(5) the degree-4 graph defect is G_4[C_3]-2C_4 (checked for a generic quartic), so C_4=G_4/2 is the unique degree-4 completion; with it the defect vanishes through degree 5 (kappa~=1,2); odd terms C_5 drop out of G_5. Scope: a formal completion through degree 5; all-order existence not claimed.
[ALG] **(c)** POLY has C_4 ≡ 0 for every tau (deg_tau C_4 ≤ 0), so the S^-image of every sheet has quartic Phi_4=G_4 != 0 and is not a sheet tau' for any real tau'.
[ALG] **(d) Remainder-order bookkeeping under a stated child contract.** Child contract used here: the child functional is the graph value itself — a birth places the state on c=C(s) over the current parent inside the conditional modal model; its remainder order p is the leading degree of C(s)-kappa Qs J_Q s. Under this contract the S^-invariant completion has p=4 (C_4 != 0 for kappa~ != 0) and every formal age sheet has p ≥ 5 (C_4 ≡ 0). So, under this contract, S^-compatibility of the birth graph and the Genesis fifth-order branch (OPEN 5/2B, GCL-06) are mutually exclusive. [OPEN] Which child functional, if any, is physical; whether birth is a graph initialization at all; whether either graph is the post-birth law; selection of the p=4 or p=5 branch. An S^-compatible graph existing does not select p=4, and the age family does not select p=5. Triadic v1.6.1 DRAFT r1 (D3) records the same conditionality on the Triadic side; it is a draft, not an adopted owner source.
Formula/witness: `G = S_c(B) - C(S_s(B))` first nonzero at degree 4; `G4[C3+C4] = G4[C3] - 2 C4`; `Phi4 = G4 - C4`.

**Domain / admissibility:** Formal; jets through degree 5; (c) on the kappa~=1 table; kappa~-linearity of G_4 extends (a),(b) to every kappa~.

**Map / clock:** S^_triad of RER-TRIAD-FORMAL-INVOLUTION (primitive-clock involution). Contrast: RER-GEN-C07 measures the F-invariance defect of the same graph at degree 5; different object.

**Factor or parametrization tested:** Graph invariance and covariance under the formal involution; not a factor.

**Order / error:** Exact jets through degree 5; no convergence, no remainder constant.

**Contract type:** `GRAPH_INVARIANCE_TEST_UNDER_FORMAL_SYMMETRY_NOT_FACTOR`.

**Evidence:** `TRIAD_BGJ_PY` and `TRIAD_GC_PY` EXECUTED (Triadic contributor; RER editor replays exit 0); POLY re-hashed unchanged.

**Review receipt:** RER editor ACCEPT SCOPED (17 Oct) with the explicit child contract in (d). Independent scientific receiving review by a reviewer other than the author is still required before any owner adoption.
Import/reference: [TRIAD_BGJ: §§2–4] (sources/current/TRIAD_R4/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md); SHA-256 `494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413`.
Import/reference: [TRIAD_GC_PY: triad_involution_graph_completion.py] (sources/current/TRIAD_R4/triad_involution_graph_completion.py); SHA-256 `024c9ad1ee5d36ecc088de1e8301109c75fd236d524987ce4a2e681cf89a0574`.
Import/reference: [POLY: age_family_polynomials_kt1.json] (sources/current/age_family_polynomials_kt1.json); SHA-256 `03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c`.
Import/reference: [GEN287: §2 OPEN 5/2B remainder-order guard; §6.3 GCL-06] (sources/current/RTG_GENESIS_GEOMETRY_DSN_v2_8_7.md); SHA-256 `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361`.
Import/reference: [TRIAD161_DRAFT: Triadic v1.6.1 DRAFT r1, §6.1/§6.17.2/§7.2 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r1.md); DRAFT, not adopted; SHA-256 `31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea`.
[OPEN] All-order existence of the even completion; analytic realization.
[OPEN] Which graph, if any, is the physical birth initialization; physical p-branch selection.

**Next test:** Extend (b) to degree 7: is the degree-6 even completion forced and the degree-7 defect automatic?

**Non-transfer:** No physical birth law, reset or healing inference, compulsory memory, or selection of the p=4 branch. No automatic RRF registration or owner adoption.

