#!/usr/bin/env python3
"""Gates for RER v0.2 DRAFT r4 (exit 0 iff all PASS).
M1 base r3.1 SHA; M2 records file SHA; M3 deterministic rebuild; M4 reverse edits recover r3.1 byte-exactly;
M5 the sixteen r3.1 record headings (plus the four G7-G10 gap headings) and all sixteen contract tables are byte-identical in r4; M6 no tag-count decrease,
no [RETRACTED]/[FAIL] added; S1 exactly four new record anchors, each with the six-field table and the six contract
fields; S2 notation: no '\\gamma' or 'mean-feedback' inside the four new records except the declared non-transfer /
notation lines, and 'closure plane' never names D; S3 every mention of GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO carries
(H_spec); S4 G5 wording: 'CLOSED_AT_OWNER_GRADE' present and never without a 'C^3' qualifier in the same paragraph;
S5 no new record is marked owner-adopted ('Registry/owner adoption: pending' in all four)."""
import sys, re, hashlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent)); import build_r4_draft as B
base = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_bytes(); draft = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4.md').read_bytes()
res = []
def gate(n, ok, d=''): res.append(ok); print(('PASS ' if ok else 'FAIL ') + n + (f'  [{d}]' if d else ''))
gate('M1 base SHA', hashlib.sha256(base).hexdigest() == B.BASE_SHA)
gate('M2 records SHA', hashlib.sha256(Path('r4_new_records.md').read_bytes()).hexdigest() == B.REC_SHA)
gate('M3 deterministic rebuild', B.apply(base.decode(), B.EDITS).encode() == draft, hashlib.sha256(draft).hexdigest()[:16])
rev = draft.decode(); ok = True
for eid, old, new in reversed(B.EDITS):
    if rev.count(new) != 1: ok = False; print('   reverse not unique:', eid); break
    rev = rev.replace(new, old)
gate('M4 reverse edits recover r3.1 byte-exactly', ok and rev.encode() == base)
b, d = base.decode(), draft.decode()
heads = re.findall(r'^### (RER-[A-Z0-9-]+) — .*$', b, re.M)
gap_heads = [h for h in heads if re.fullmatch(r'RER-G\d+', h)]
rec_heads = [h for h in heads if h not in gap_heads]
tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', b)
full_heads = re.findall(r'^### RER-[A-Z0-9-]+ — .*$', b, re.M)
gate('M5 sixteen r3.1 record headings (+ four G7-G10 gap headings) and sixteen contract tables byte-identical in r4', len(rec_heads) == 16 and len(gap_heads) == 4 and all(h in d for h in full_heads) and len(tables) == 16 and all(t in d for t in tables), f'{len(rec_heads)} record headings, {len(gap_heads)} gap headings, {len(tables)} tables')
tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
c0 = {t: b.count(t) for t in tags}; c1 = {t: d.count(t) for t in tags}
gate('M6 no tag decrease; no RETRACTED/FAIL added', all(c1[t] >= c0[t] for t in tags) and c1['[RETRACTED]'] == c0['[RETRACTED]'] and c1['[FAIL]'] == c0['[FAIL]'], ' '.join(f'{t}{c1[t]-c0[t]:+d}' for t in tags if c1[t] != c0[t]))
new = ['RER-GEN-K3-MODAL', 'RER-DYAD-FORMAL-INVOLUTION', 'RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION']
recs = B.RECORDS
blocks = re.split(r'\n(?=<a id=")', recs); blocks = [x for x in blocks if x.strip()]
fields = ['**Domain / admissibility:**', '**Map / clock:**', '**Factor or parametrization tested:**', '**Order / error:**', '**Contract type:**', '**Evidence:**', '**Review receipt:**', '**Next test:**', '**Non-transfer:**']
ok = len(blocks) == 4 and all(f'### {k} —' in recs for k in new) and all(x.count('| Field | Contract |') == 1 and len(re.findall(r'^\| (Carrier|Observables|Constraints|Transformation law|Closure status|Memory) \|', x, re.M)) == 6 and all(f in x for f in fields) for x in blocks)
gate('S1 four new records, each with six-field table and contract fields', ok, f'{len(blocks)} blocks')
bad = [l for l in recs.splitlines() if ('\\gamma' in l or 'gamma' in l or 'mean-feedback' in l) and not re.search(r'Non-transfer|not the Genesis mean-feedback|parameter gamma', l)]
gate('S2 notation guard in new records (gamma/mean-feedback only in declared lines; D never called closure plane)', not bad and 'closure plane' not in d.split('## 7.')[0].split('## 6.')[1] and all('closure plane' not in l or 'is not used' in l for l in d.splitlines() if 'closure plane' in l), f'{len(bad)} stray')
mf = [l for l in d.splitlines() if 'GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO' in l and 'H_spec' not in l]
gate('S3 mean-feedback theorem always with (H_spec)', not mf, f'{len(mf)} unguarded')
g5 = [l for l in d.splitlines() if 'CLOSED_AT_OWNER_GRADE' in l and 'C^3' not in l]
gate('S4 G5 closure always with C^3 qualifier', 'CLOSED_AT_OWNER_GRADE' in d and not g5, f'{len(g5)} unguarded')
gate('S5 no new record marked owner-adopted', all(re.search(re.escape(k) + r' — [^\n]*\n\*\*Primary grade:\*\*[^\n]*Registry/owner adoption:\*\* pending', recs) for k in new))
print(f'\n{sum(res)}/{len(res)} gates PASS'); sys.exit(0 if all(res) else 1)
