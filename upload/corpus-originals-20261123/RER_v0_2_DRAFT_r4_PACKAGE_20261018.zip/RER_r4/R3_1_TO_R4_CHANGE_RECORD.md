# RER v0.2 DRAFT r4 — change record (r3.1 → r4)

**Date:** 18 Oct 2026.
**Prepared by:** Claude, RER co-owner (and author of the Triadic-side evidence).
**Status:** DRAFT r4, NOT ADOPTED, NOT FROZEN. r3.1 is preserved byte-exactly as the review base. No registry adoption, no RRF-interface review, no owner adoption of any new record.
**Review gate:** receiving review by the other RER co-owner / PI. Because the four new records rest on evidence I produced, I do not accept them; their "Registry/owner adoption" field stays `pending` until a reviewer other than the author disposes of them.

## Identities

| Object | SHA-256 |
|---|---|
| Base: `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md` (909 lines, byte-verified) | `a57aef068ec9eb31f1d7981c239faf855b758652a4e6a37c4295e712d3e42bf9` |
| **Draft: `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4.md`** (1125 lines) | `93a63c49131d665f258dccf16ffcc6ccfb6af9a60035073ebd710dd4d80c8eff` |
| New records source `r4_new_records.md` (inserted verbatim by edit S6) | `03823359f2bb2ac82246a344b15701f75dfc19bb5047e0e38734339325d0a6fc` |
| Builder `build_r4_draft.py` (17 exact-once edits) | `cd53c2eee7f31fb4520d977807dfeb00a9043188385eeb5aff38fc395de46f5c` |
| Checker `check_r4_draft.py` (11 gates) | `c9e3d9cfd4bcac7656c5031982fd4234d65a60a791b09984f4cedb7c0a8d8e3b` |
| Edit list `r3_1_to_r4_edits.json` | `882998a98002d1654981ae36b7f6acf6586df252691eee5fa9b4786ef8ee8204` |
| Unified diff `r3_1_to_r4_DRAFT.diff` (314 lines) | `248a6b5b0067652eb94596397ec54efefea4f456168f7072f4a1aa6c807763f3` |
| Checker output (11/11 PASS) `check_r4_output.txt` | `42b2d05d0c1208c394b826f908d2507186e30ce2024e734a241dfe3be7371700` |

The r3.1 REGISTRY JSON (`b996ba8e…a213`) is **not** modified in r4. Machine-entry changes, if any, are a separate step after the receiving review.

## A. Sources synchronized (pointer layer)

| Source | r3.1 pin | r4 pin | Evidence here | Kind |
|---|---|---|---|---|
| Genesis | v2.8.5 (and v2.8.6 in r3.1 overlays) | **v2.8.7 ADOPTED**, `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361` | BYTE-VERIFIED by the RER editor (18 Oct); project copy SOURCE-READ | pointer + one scientific consequence (G5, §B) |
| Dyadic | v6.4.8.1 / v6.4.11 references | **v6.4.12.1** (`36e7ef58…f107`) | OWNER-REPORTED hash; project copy SOURCE-READ | pointer |
| RRF | adopted v0.8 (line pins) | **v0.8.2** governs; v0.8 / v0.8.1 historical, line pins retained | SOURCE-READ | pointer (G10 overlay) |
| Triadic | adopted v1.6 | adopted **v1.6** unchanged **plus** `RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r1.md` (`31b87c3e…630ea`) as a **separate draft source object** | BYTE-VERIFIED (built here) | pointer; v1.6.1 is cited as draft only |
| K3 records | — | K3 cubic-factor session record v0.1.2; K3 κ six-step note v0.3 (SESSION, noncanonical) | SOURCE-READ | pointer, context |
| Triadic-side evidence | — | `sources/current/TRIAD_R4/` (17 files, pins in SHA256SUMS) | EXECUTED here; receiving replay status per record | evidence |

## B. Scientific changes

| Edit | Location | Change | Tag(s) |
|---|---|---|---|
| S1 | §1 | New paragraph: the named conditional modal map 𝒩 is the Genesis projected-K3 map F₁ up to the linear isomorphism E (E∘𝒩 = F₁∘E, hence E∘𝒩⁶ = F₁⁶∘E); adopted Genesis v2.8.7 six-step theorem therefore transports to ℱ = 𝒩⁶. Mean-feedback theorem named as context only, with (H_spec). RRF v0.8.2 line. | [THM] import, [ALG] transport |
| S2 | §3 | Model contract: E-conjugacy stated as [ALG] with the matrices E, P (PE = I, EP = I − J/3); exact and 50-dps checks pinned (`triad_k3_econjugacy_check.py`). | [ALG] |
| S3 | §5.1 | G10 r4 overlay (RRF v0.8.2 governs; v0.8 pins historical). | [DEF] |
| S4 | §6 intro | "sixteen" → "twenty" complete contracts; four new keys declared local, non-registered. | [DEF] |
| S5 | §6 C07 | Cross-reference from RER-GEN-C07 (leading birth graph) to the new RER-TRIAD-BIRTH-GRAPH-INVOLUTION record (its Ŝ-compatible completion and the p = 4 / p ≥ 5 split under the graph-value child contract). | pointer |
| S6 | §6 end (before §7) | **Four new complete records inserted verbatim** from `r4_new_records.md`: RER-GEN-K3-MODAL (primitive clock: [THM] import of `GEN-THM-K3-PLANAR-FACTOR-NOGO`; six-step clock: [THM] import of `GEN-THM-K3-SIXSTEP-FACTOR-NOGO` via the [ALG] E-conjugacy; exact Burnside corroboration `triad_six_step_factor_burnside_check.py`), RER-DYAD-FORMAL-INVOLUTION ([THM] import, Dyadic v6.4.12.1 OPEN 19 closure, SOURCE-READ), RER-TRIAD-FORMAL-INVOLUTION ([ALG] Ŝ_triad = 𝒩³ℱ^{−1/2}; kernel dim (0,2,0,0,0,0) "[ALG], source-executed exact; independent [NUM] replay PASS"; G6 OPEN), RER-TRIAD-BIRTH-GRAPH-INVOLUTION ([ALG] (a)–(c) defects D, G, unique even completion C₄ = G₄/2; (d) remainder bookkeeping under the explicit graph-value child contract: p = 4 vs p ≥ 5, mutually exclusive; [OPEN] no physical selection; [COR] withdrawal of the earlier O(|s|⁵) claim). All four: `Registry/owner adoption: pending`. | [THM]+[ALG]+[NUM]+[COR]+[OPEN] |
| S7 | §7 | "R4 additional evidence sources" table: three evidence layers (source evidence / receiving disposition / owner adoption) per record; receiving-replay status (`TRIAD_KR_PY` replayed PASS; `TRIAD_CK_PY` exact replay pending; Burnside check replayed PASS); unresolved source requests kept. | status |
| S8 | §8 queue | Rows: G5 CLOSED_AT_OWNER_GRADE (C³ class, both clocks) — no RER task remains, C¹/C² d = 2 stays OPEN at the owners; D3 Triadic scope correction pending owner adoption (draft v1.6.1 r1 exists); G6 OPEN; receiving exact replay of `TRIAD_CK_PY` pending. | queue |
| S9 | §9 | r4 revision entry with the G5 closure statement qualified (C³ class, 6S-core, d = 1, 2, 3), G6 OPEN, D3 pending, notation line (κ Triadic birth coefficient, γ Genesis mean-feedback parameter, 𝒟 mean mode; "closure plane" not used). | [ALG] |

**Gap status after r4** (registry-level, all pending receiving review):

| Gap | r3.1 | r4 |
|---|---|---|
| G5 six-step-clock factors of ℱ | OPEN | **CLOSED_AT_OWNER_GRADE for the C³ class** (adopted Genesis v2.8.7 `GEN-THM-K3-SIXSTEP-FACTOR-NOGO`, transported by E-conjugacy). C¹/C² for d = 2: OPEN at the owners. |
| G6 six-step-only uniqueness / 4D formal centralizer | — | **OPEN** (new; cubic kernel dim 2 bounds the lowest order only). |
| G7–G10 | as r3.1 | unchanged; G10 gets the RRF v0.8.2 overlay. |
| D3 (Triadic birth-remainder import scope) | — | **pending Triadic owner adoption**; v1.6.1 DRAFT r1 carries the [COR] narrowing; RER cites v1.6 adopted and v1.6.1 draft as separate objects. |

Nothing in r3.1 is retracted, regraded or renumbered. No RER-* key is removed. No physical model is selected. No K=8 / Stage-2 result is cited.

## C. Mechanical (M1–M8)

Title, date, document status (with base SHA and build method), supersedes line, companion documents (Genesis v2.8.7; Dyadic v6.4.12.1; RRF v0.8.2; Triadic v1.6 adopted + v1.6.1 draft), status summary ("sixteen + twenty", G5 qualified), identifiers paragraph (four new local keys), release boundary (r4 noncanonical; no adoption, no freeze).

## D. Gates (`check_r4_draft.py`, 11/11 PASS)

| Gate | Result |
|---|---|
| M1 base SHA pinned | PASS |
| M2 new-records file SHA pinned | PASS |
| M3 deterministic rebuild equals the draft | PASS |
| M4 reverse-applying the 17 edits recovers r3.1 byte-exactly | PASS |
| M5 the 16 r3.1 record headings (+ 4 G7–G10 gap headings) and all 16 contract tables byte-identical in r4 | PASS |
| M6 no claim-tag count decreases; no `[RETRACTED]`/`[FAIL]` added | PASS ([THM] +8, [ALG] +13, [NUM] +3, [COR] +2, [OPEN] +12) |
| S1 exactly four new records, each with the six-field table and the nine contract fields | PASS |
| S2 notation: no γ / mean-feedback inside the new records except declared non-transfer lines; 𝒟 never called "closure plane" | PASS |
| S3 every mention of `GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO` carries (H_spec) | PASS |
| S4 `CLOSED_AT_OWNER_GRADE` present and never without the C³ qualifier on the same line | PASS (negative control: removing the qualifier on one line trips S4 and M3) |
| S5 no new record marked owner-adopted | PASS |

Checker fix in this pass: M5 originally compared the heading count to 16; the base has 20 `### RER-` headings because the four gap entries G7–G10 share the heading style. The gate now separates record headings (16, with contract tables) from gap headings (4) and requires every one of them, and every contract table, to appear byte-identically in r4. The two G5 closure lines in the header and §9 lacked the C³ qualifier; the wording was fixed in the builder (the gate was right).

## E. Not in this draft

- No REGISTRY JSON change; no machine-entry change.
- No acceptance of the four Triadic-sourced records by the author.
- No ER-2B v0.2 source (C19–C20 receiving verification still limited).
- No K=8 pilot or Stage-2 sweep result; no TM lemma review; no G6 result.
- No RRF-interface review; no change to any adopted owner DSN.

## F. Requested review (other co-owner / PI)

1. Byte-verify base and draft against the hashes above; rerun `check_r4_draft.py` (needs `build_r4_draft.py`, the base, `r4_new_records.md` and the draft in one directory).
2. Receiving disposition of the four new records (the author cannot do this); in particular, an exact replay of `triad_cubic_centralizer_kernel_check.py` (~90 s, needs `triad_formal_involution_birth_jet.py` alongside) to lift the kernel subclaim from "source-executed exact" to receiving-replayed.
3. Decide whether G5's registry status wording ("CLOSED_AT_OWNER_GRADE for the C³ class") is the accepted form.
4. PI decision on whether r4 proceeds toward an r4 registry JSON step; r4 remains noncanonical until then.
