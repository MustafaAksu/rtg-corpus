# Correction request to the Triadic owner — D3 (birth-remainder import scope)

**From:** Claude (Triadic contributor / auditor), via the RER r4 review.
**To:** Triadic owner / maintaining co-owner.
**Date:** 17 Oct 2026.
**Status:** request only. The owner file is not edited. Any change needs the owner's own review and release gate.

**Target:** `RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6.md`, SHA-256 `c768687cec6d52ffd358dc362cee4348f076160943564adaa461e6c7c4595b36`.

**Priority:** P0 scientific consumer sync. This is a scope narrowing of a live claim, not a pointer update.

## 1. Affected text

| Line | Text (abridged) |
|---|---|
| 806, §7.4 | `[THM] [import: Genesis v2.8.4 §6.3, one-dimensional birth theorem | RID unavailable]` **Leading admissible birth family.** c₀ = κQ_sJ_Qs* + O(‖s*‖⁵) and Q_c = κ²Q_s³ + O(Q_s⁴). Source status: [THM]. |
| 313, §6 | `[THM] [import: Genesis v2.8.4 §6.3]` Leading birth kinematics, followed by Q_c(0) = κ²Q_s³ + O(Q_s⁴), u(0) = κ²Q_s² + O(Q_s³). |
| 649, §6 | `[THM] [import: Genesis v2.8.4 §6.3, one-dimensional birth theorem]` The source admissible pure-transverse birth family is … |

## 2. Why

Genesis v2.8.5 (GCL-06), retained unchanged in the adopted v2.8.6 §1 and §6.3, now reads as follows:
- The leading term c₀^{[3]} = κQ_sJ_Qs* is [THM].
- The O(|s*|⁵) child remainder holds only if the selected complete child functional preserves the cubic leading term and inherits a fifth-order remainder.
- A raw six-step residual carries a nonzero quartic F₄. If the child functional keeps that quartic, an O(|s*|⁴) child remainder and an O(Q_s^{7/2}) amplitude correction are not excluded.
- The physical residual and child functional are OPEN.

The Triadic import of the remainder therefore states more than the source now does.

There is also a concrete formal instance (RER r4 candidate RER-TRIAD-BIRTH-GRAPH-INVOLUTION). The Ŝ_triad-compatible completion of the same leading graph has a nonzero quartic, so its remainder order is p = 4.

## 3. Proposed replacement (for owner review)

> `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.6 §6.3 #sec-6-3-triad, one-dimensional birth theorem | RID unavailable; artifact locator GEN-ART-PHI-2TO3] **Leading admissible birth family.** c₀^{[3]} = κQ_sJ_Qs*, hence Q_c = κ²Q_s³ at leading order.
>
> `[ALG]` `[scope: conditional on the selected child functional]` If that functional preserves the cubic leading term and inherits a fifth-order absolute remainder, then c₀ = c₀^{[3]} + O(‖s*‖⁵) and Q_c = κ²Q_s³ + O(Q_s⁴). If a raw-residual quartic is retained, only O(‖s*‖⁴) and O(Q_s^{7/2}) follow.
>
> `[OPEN]` Physical residual and child-functional selection (Genesis GCL-06).

The same split applies at lines 313 and 649. Downstream Triadic statements that use Q_c = κ²Q_s³ + O(Q_s⁴) or u(0) = κ²Q_s² + O(Q_s³) as a remainder bound, rather than as a leading term, should be checked for whether they depend on the fifth-order branch. I have not audited those uses. That audit is the owner's task.

## 4. Bundled hygiene (separate kind, same pass if the owner wishes)

D1, D2 and D4–D10 of `RER_v0_2_r4_TRIAD_RECORD_CANDIDATES_20261017.md` part D:
- Dyadic N2 repin;
- Genesis RID fills (`GEN-DEF-PRIMITIVE-METRIC`, `GEN-THM-PRIMITIVE-METRIC-INVARIANCE`, `DYAD-DEF-PRIMITIVE-MAP` / `GEN-DEF-PRIMITIVE-MAP`);
- companion pointers;
- the CN-01–CN-05 consumption receipt;
- marking the GEN-OPEN-APEX-SLOT reference as historical, retracted as a [RESULT].

Each of these needs a value-by-value check against the cited source. None of them changes a Triadic result.

## 5. Not requested

- No change to any T-6s/t/u result.
- No change to the leading birth law or the κ reference policies.
- No selection of a physical residual.
