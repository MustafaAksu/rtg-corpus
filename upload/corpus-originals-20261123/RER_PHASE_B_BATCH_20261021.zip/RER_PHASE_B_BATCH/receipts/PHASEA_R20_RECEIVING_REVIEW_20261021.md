# RER Phase A r20 — independent receiving review

**Date:** 21 October 2026.  
**Status:** NONCANONICAL receiving record; not owner/registry adoption, freeze or publication.  
**Decision:** **ACCEPT SCOPED — authorized two-row source-availability/identity update on unchanged RER r4.13.** No new correction is required for this submission.

## 1. Authority, inputs and inspection scope

[SESSION: inspected here] The controlling preparation permission is **§6, items 1–7** of `OWNER_SECTION_R2_RECEIVER_20261021/RECEIVING_REVIEW_20261021.md`. That review and the r20 change record were read completely. The r20 catalogs, output JSON, custody record, relevant builder/checker branches, manifest and historical receipts were inspected. The supplied checker was replayed; a separate receiver audit independently compared actual bytes and JSON without importing the preparer's builder, checker, parser or patch.

[SESSION: inspected here] Available governing editions: adopted **Methodology v1.3** (header, §0.6, §§12.1–12.4 and §13.1), **Programme v1.2** (header, §8 and §8.1), **OFN v0.10** (header/status/scope only). These were read by section, not in full. `SOURCE_MANIFEST.json` records exact identities and read scope. This is not live or global release discovery. No scientific owner proof, Stage-2 engine or mathematical certificate was rerun.

[SESSION: computed here] Principal input identities:

| Object | SHA-256 |
|---|---|
| Submitted r20 ZIP | `adfedefde08cd44294b5b8c2411c353268700739427579f342447d094f813abc` |
| Original r19 ZIP | `683046e70c1d4644e33ae40a3cde85666f6346ecb979874ea9b66430443efe06` |
| Unchanged RER r4.13 Markdown | `e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c` |
| Original RER r4.13 ZIP | `3cf88b73f143f4f05e6965488090dfa999a397dd2e1d0a781f46d8f00604ab00` |

[SESSION: computed here] The separately uploaded r20 change record equals the copy in the package. The source Markdown equals the corresponding file in both the original r19 and original r4.13 ZIPs. The original archives were not changed.

## 2. Two clean replays

[SESSION: executed here] Two separate fresh extractions were used. Manifest and complete-payload checks preceded and followed each run:

```sh
python -I -B build_phaseA.py
python -I -B check_phaseA.py --tamper
```

| Check | Receiver result |
|---|---|
| ZIP SHA-256 and CRC | Match; no CRC error |
| Root manifest | **178/178 PASS**, before and after both replays |
| Manifest completeness | Every payload listed; only the root `SHA256SUMS.txt` itself excluded |
| Main gates | **34/34 PASS**, both replays |
| Negative controls | **182/182 named-gate rejections**, both replays |
| Negative-control breakdown | **141 output tamper + 11 file controls + 30 input controls** |
| Five generated outputs | Byte-identical to packaged outputs and between clean runs |
| Full checker stdout | Byte-identical to packaged log and between clean runs |
| Stderr / exit | Empty stderr; exit 0 for builder and combined checker |
| Python cache | None listed or created |

[SESSION: execution interpretation] Exit 0 for the combined checker means its positive gates and expected negative rejections succeeded. The 182 controls are **not** 182 independently certified scientific claims. The replay uses the preparer's algorithm; it is distinct from the separate identity/delta audit below. `patch_r20.py` itself was not applied: regeneration was performed from the delivered r20 inputs with `build_phaseA.py`.

[SESSION: computed here] Full checker stdout SHA-256:

```text
b370f402b580ce2cd56771b96466726c775dd520ed1e8c680200ecce111270d1
```

## 3. Independent r19 → r20 audit

[SESSION: independently computed here] `independent_audit.py` completed **82/82 assertions** and produced byte-identical JSON against both clean extractions. It does not import or execute the submitted builder/checker/parser/patch. Shared inputs are the source archives, record identifiers and documented authorization; its results concern identity and authorized metadata changes, not independent mathematics.

[SESSION: independently compared here] All six retained r19 historical files—five outputs and the combined checker log—equal their members in the **original external r19 ZIP**, not merely other copies inside r20.

[SESSION: independently compared here] Matrix identities and order are unchanged: **91 rows, exactly two changed**:

| Record / import index | Key | New local evidence | Preserved currency/status |
|---|---|---|---|
| RER-DYAD-FORMAL-INVOLUTION / 0 | DYAD6413 | BYTE_VERIFIED_MATCH; BYTE_VERIFIED_HERE; FULL_FILE_HASH | RECHECK_IN_PHASE_B / HISTORICAL |
| RER-DYAD-FORMAL-INVOLUTION / 1 | RRF082 | BYTE_VERIFIED_MATCH; BYTE_VERIFIED_HERE; FULL_FILE_HASH | RECHECK_IN_PHASE_B / HISTORICAL |

[SESSION: independently compared here] Each of these rows differs in exactly six fields:

```text
bytes_status, authentication, available_file,
inspection_extent, currency_reason, receiver_note
```

The earlier receiver note and currency reason are preserved as prefixes, with dated r20 additions. No old receiver execution is relabelled as a preparer execution. Each appended reason explicitly declines whole-row old-to-current equality.

[SESSION: independently compared here] The **other 89 rows are identical**. All cited versions/hashes/paths, line ranges, package-presence flags and current-owner identities/evidence remain unchanged. All 20 scientific record objects, four gap entries, grades, claims, OPENs, import lists, receipts and the source table are identical; the registry changes only its schema. All 13 gap-reference audits remain `PENDING_PER_REFERENCE_AUDIT`.

[SESSION: independently compared here] The blocked register changes only its schema and the derived unavailable-byte keys. Both unavailable-byte lists lose **exactly DYAD6413 and RRF082**, leaving twelve keys. Their note is unchanged. The two ER-2B scientific blocks and six BLOCKED matrix rows remain intact. The SYNC computed state and its separate receiving disposition are unchanged.

| Axis | Verified r20 counts |
|---|---|
| VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED | **31 / 2 / 52 / 6** |
| BYTE_VERIFIED_HERE / RECEIVER_BYTE_VERIFIED / HASH_PRINTED_UNVERIFIED / UNAUTHENTICATED_NO_HASH | **62 / 4 / 24 / 1** |

[SESSION: independently compared here] Source catalog changes are confined to its explanatory history and the two keys' appended reasons/notes. The known-version inventory changes only its check label and the appended Dyadic/RRF historical-source authority explanations; versions and current-owner records are identical. The record catalog and parser are byte-identical to r19. One watch item is appended; G10 remains a watch item, not an edited consumer statement.

## 4. Source identity, custody and archive coverage

[SESSION: computed here]

| Key | Bytes | SHA-256 |
|---|---:|---|
| DYAD6413 | 187,458 | `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` |
| RRF082 | 88,773 | `f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461` |

[SESSION: independently compared here] Both files equal their original transfer members, their named members in `TRIAD_RER_RECEIVING_REVIEW_20261019.zip`, and their members in the prior owner-section receiver handoff. The two named older archive hashes also match the custody record. These are archive/member checks, not reauthentication of the human source or events before the archived copies. **NOT_REAUTHENTICATED remains the external custody boundary.** The preparer's chain and the receiver-reported chain remain separately attributed.

[SESSION: computed here] The transfer ZIP and section-check r2 ZIP inside r20 are byte-identical to the separately supplied originals and carry the expected full hashes. Transfer inner manifest: **4/4 PASS**. All six copied r2 comparison artifacts equal their members in the original r2 ZIP. The r19 and r2 receiving reports equal the separately supplied receiver files.

[SESSION: receiving assessment] **OSC2-T2 is addressed for this r20 package.** All eleven named historical RER package manifests are directly listed in the root manifest. The copied historical manifest omitted by r2's root manifest is covered by pinning the intact r2 ZIP; its bytes additionally equal the original transfer manifest. The original r2 is not rewritten.

[SESSION: receiving assessment] **OSC2-T1 remains a preserved historical tooling caveat**, not a newly repaired checker: r2's mutation log prints a post-mutation hash with a baseline MATCH label. r20 documents this and does not reinterpret that label as source identity. This review did not rerun the r2 scientific-section comparison; it checked the pinned artifacts and their previous receiving decision. The §5→§6 locator correction is recorded only in the r20 record/watch item. No new corrective revision is requested.

## 5. Decision and continuation state

[SESSION: receiving decision] **Phase A r20 — ACCEPT SCOPED.** The authorization's local file-access prerequisites for DYAD6413 and RRF082 are fulfilled. Their local byte identity can be recorded as `BYTE_VERIFIED_HERE`; their historic/current-use classification remains **HISTORICAL / RECHECK_IN_PHASE_B**. Identity does not establish equality of changed source sections or independent theorem certification.

[SESSION: boundary] No scientific result, physical model/bridge, source pin, grade or owner adoption changes. The twelve RRF v0.8 pins, G9/1–G9/3 audits, G2 §5b, the two ER-2B blocks, Stage-2 regional/global certification and multi-step error control remain open. RER **r4.13 DRAFT** is unchanged; Phase A **r20 ACCEPT SCOPED** is the latest received machine snapshot in this review. No new r21, G10 text maintenance, freeze or release is authorized by this acceptance.

[SESSION: tooling-development note] A preliminary receiver-audit assertion incorrectly required an initial capital `W` in the no-whole-row-equality sentence. It was corrected to a case-insensitive comparison of the actual unchanged sentence. This was a receiver test-literal error, not a defect in the submission; no submitted file was edited.

Evidence: `SOURCE_MANIFEST.json`, `INDEPENDENT_AUDIT.json`, `INDEPENDENT_AUDIT_RUN2.json`, `replay_received.py`, `independent_audit.py`, and `logs/run1`, `logs/run2`. The final report and evidence are separate receiver artifacts; neither the r20 ZIP nor its extracted source inputs were changed.
