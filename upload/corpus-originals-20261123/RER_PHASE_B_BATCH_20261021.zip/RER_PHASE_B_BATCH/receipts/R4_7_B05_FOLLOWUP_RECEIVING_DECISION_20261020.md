# RER Phase A r9 and RER r4.7 — independent receiving decision
Date: 20 October 2026. NONCANONICAL receiving review; no adoption/freeze/release.

## Source manifest
- RER_phaseA_r9.zip: SHA-256 71ccc7e95a6c3758eb5a9e756f2959c807fd958e51492901df657c9bf3b8e9ae; 67/67 SHA256SUMS entries pass.
- RER_r4_7.zip: SHA-256 9ab6393e94001d5c513f68af64e32d63afb0548b31879afcfc3912911ecfc14f; 43/43 SHA256SUMS entries pass.
- Draft r4.7 SHA-256 110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d; base r4.6 unchanged.

## Replays
- Phase A r9: python -I build_phaseA.py and check_phaseA.py: 23/23 gates PASS. check_phaseA.py --tamper: 32/32 expected controls rejected, including held-source-file removal.
- RER r4.7: python -I build_r4_7_draft.py and check_r4_7_draft.py: 14/14 gates PASS. --tamper: 14/14 expected controls rejected (13 explicitly labelled FAILS and one six-gate original-r4.6 regression). Inherited r4.6 checker: 29/29 PASS.
- All cited available evidence under r4.7 supplied paths matches hashes, checker K1 21 pins, 0 bad.

## Decision A: Phase A r9 — ACCEPT SCOPED
Local v6.4.17 source bytes match release hash, current owner's authentication is BYTE_VERIFIED; r8 OWNER_REPORTED state retained as history. DYAD6413 scientific citation remains v6.4.13, and no scientific content or record status changed. The section check reports five identical sections. No adoption implied. Phase A r9 is tied to r4.6, not r4.7.

## Decision B: RER r4.7 — ACCEPT SCOPED, with one metadata reading caution
The r4.6 to r4.7 exact-once patch is limited to RER-DYAD-FORMAL-INVOLUTION plus declared header/history/release boundary. All other records, primary grade, OPEN statements and scientific pins unchanged. O1–O6 satisfy the receiving items: λ-equivariant normal form qualifier; analytic bridge R(0)=0 and domain convention; individual RID grades; smooth flat-uniqueness hypotheses and Lemma F scope; historical G2 §2a evidence qualification; and RRF083 §2.3/§2.4b pin. The carrier cell is byte-identical to r4.6. RRF083 source file is outside the r4.7 package, but adopted v0.8.3 is separately available on the receiver side and has previously been hash-verified.

Caution, nonblocking: the top-level primary grade [THM], exactness FORMAL_ONLY summarizes the principal formal symmetry result; the imported analytic clock bridge carries [THM — analytic] as a separate line and should not be interpreted as FORMAL_ONLY. O3 already makes this distinction legible, so no further edit is required before a new Phase A source-index pass. Historical SOURCE-READ claim for G2 is qualified but is not reauthenticated.

## Next work / blockers
Prepare a fresh Phase A on exact r4.7 bytes, with RRF083 source row and new source-index matrix; do not silently layer the r9 matrix over r4.7. Scientific Phase B cases with author conflicts remain for independent receiving review. G2 §5b identification and two ER-2B blocks remain open. No freeze, adoption or publication.
