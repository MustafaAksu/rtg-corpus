# RER Phase A r21 — change record (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE. r21 is the **single Phase A generation on the integrated RER r4.14 candidate** required by the receiver Fast-Track decision of 21 Oct 2026 (§6). It is not an acceptance of r4.14 or of any record; the new RRF v0.8.4 reference rows are the machine image of an L2 proposal awaiting the receiving review.

**Source.** RER r4.14 `92f983e64bd54e208898954c45c4ac6482928b794d08b3d1660f0db9d00ff044` (package `RER_r4_14.zip` `f86616f8f8aee3bee763825f1adfd4e6c9ba31a896b628fbbd24dc89d622179e`), built on the exact r4.13 bytes (`e92991bd…368c`, kept in the package as the base file). **Baseline.** Phase A r20 `adfedefd…3abc` (ACCEPT SCOPED), pinned unchanged in `inputs/baseline_r20.json` (r20 package hash and member identities; the r20 builder/checker identities equal the receiver's reference pin `5bffe657…` / `3c6b7c4e…`); its outputs and checker record are kept in `inputs/phaseA_r20_outputs/` (gate A36).

## 1. Delta contract (`inputs/delta_contract_r21.json`, `9cefb944…`)

The authorized r20 → r21 differences are written down once and checked by gate **A35**; everything else must be identical (A25, A28):

| Axis | r20 | r21 |
|---|---|---|
| Registry records | 20 | 20; **3 changed** — RER-RRF-CND01 and RER-ER2B-CARRIER: imports +1 (`RRF084`); RER-GEN-K3-MODAL: Review receipt / prior_review_receipt append-only (no independent receipt for the E-conjugacy step; carried into the batch). 17 records identical. Grades, exactness, tasks, contracts, claim lines, OPEN items, adoption PENDING unchanged |
| Gap entries | 13 references | 13 historical references unchanged + **10 current `RRF084` references** (G7 2, G8 2, G9 2, G10 4); gap text hashes changed accordingly |
| Source table | — | +`RRF084`; `DYAD6413` / `RRF082` rows append-only |
| Matrix rows | 91 | **103** = 91 (identical apart from the new `path_in_r4_14_package` flag and, on the 15 gap / RRF-v0.8 rows, a `preparer_audit` field) + 12 new `RRF084` rows (CURRENT, VERIFIED, BYTE_VERIFIED_HERE; cited file held since r19; `path_in_r4_14_package` true, `path_in_r4_13_package` false) |
| Statuses | 31 / 2 / 52 / 6 | **43 / 2 / 52 / 6** |
| Authentication | 62 / 4 / 24 / 1 | **74 / 4 / 24 / 1** |
| `gap_reference_review` (13 historical rows) | PENDING_PER_REFERENCE_AUDIT | unchanged; `preparer_audit` carries the audit proposal with the note "preparer proposal, not a receiver disposition" |
| `gap_reference_review` (10 new rows) | — | `PROPOSED_CURRENT_REFERENCE (r4.14; L2) — RECEIVER_DISPOSITION_PENDING` |
| owner_current, SYNC warning + disposition, blocked register, missing-bytes list (12 keys) | — | identical |
| Catalog | — | +key `RRF084` (owner RRF, v0.8.4, rule CURRENT; reason states "preparer proposal … assert no v0.8 -> v0.8.4 equality"); `_catalog_checked` r21 |

The v0.8 pins are not moved, not verified and not equated to v0.8.4; the 12 `RRF08_ADOPTED` keys remain in `bytes_not_available_to_preparer`.

## 2. Package changes

Added: `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_14.md`; `inputs/r4_14_package_SHA256SUMS.txt`; `inputs/gap_reference_audit.json` (`5cffa026…`, the Phase B audit); `inputs/delta_contract_r21.json`; `inputs/baseline_r20.json`; `inputs/FAST_TRACK_DECISION_20261021.md` and `inputs/FAST_TRACK_EVIDENCE_20261021.json` (receiver authorization and evidence); `inputs/phaseA_r20_outputs/` (5 outputs + checker record); `patch_r21.py`; this record. Output file renamed `out/RER_REGISTRY_v0_2_r4_14_PHASEA.json`. Schemas `…/21`. Builder: reads the audit JSON to attach `preparer_audit`; `gap_reference_review` for `RRF084` rows; r4.14 package flag. The r4.13 file, record catalog and parser are unchanged (A36).

## 3. Checker — baseline + delta

36 gates PASS; **211 negative controls** (163 tampers + 48 file/input), each fails its named gate. Shared invariant gates reused unchanged (A1–A14, A16, A18–A23, A26, A27, A30, A31, A33). Re-based: **A15** (13 historical lines = receiver crosswalk, PENDING with the preparer audit attached; 10 current lines 2/2/2/4, PROPOSED_CURRENT_REFERENCE), **A17** (23/23 paths), **A24** (source r4.14 on the r4.13 base; r4.14 manifest carries r4.13, r4.14 and the v0.8.4 file; r20 record kept), **A25** and **A28** (delta vs r20 per contract), **A29** (26 RRF rows; only the 12 `RRF084` rows CURRENT), **A32** (43/2/52/6; 74/4/24/1), **A34** (13 records untouched since r17). New: **A35** delta contract, **A36** baseline pin. Per the receiver's instruction, the r20 version-specific snapshot controls (r19-based) are retired here and stay in the pinned r20 record; the new controls cover new failure classes only: new rows dropped or given the v0.8 hash / r4.13 presence / no no-equality clause; historical pin silently repinned or promoted; preparer-audit field removed, misattached or relabelled as a disposition; contract counts altered; baseline pin altered; r20 record altered; the v0.8.4 file withheld.

## 4. Replay

```
unzip RER_phaseA_r21.zip && cd RER_phaseA_r21
sha256sum -c SHA256SUMS.txt
python -I -B build_phaseA.py          # out/* byte-identical
python -I -B check_phaseA.py --tamper # 36/36 PASS, 211 controls, exit 0
```

One clean integrated replay is the default (receiver); a second was run here only to confirm determinism of this first r21 build.

## 5. Open (unchanged)

RRF v0.8 original (12 pins); G9/1–G9/3 and all 13 gap dispositions (receiver); G2 §5b; two ER-2B blocks; Stage-2 regional/global certificate; RER-GEN-K3-MODAL E-conjugacy independent review (packet in the batch); adoption scope (PI).
