"""Twenty-record disposition / coverage table for the RER Phase B batch (receiver Fast-Track decision of 21 Oct 2026, §6: "a twenty-record disposition
coverage table … explicitly account for the RER-native E-conjugacy component of GEN-K3-MODAL … do not erase C01–C05's declared historical HARM/ANGLE_DATA/
RANKDATA limits"). PREPARER_ROLE: the table collects the RECEIVER decisions already issued (quoted labels, receipt files hashed here) and the declared
source limits; the preparer adds no acceptance. Items without an independent receipt are listed as batch review items.
Reads: ../receipts/*.md (hashed), the Phase A r21 registry JSON (record list, grades, adoption, blocked status). Writes: out/DISPOSITION_TABLE_20_RECORDS.{json,md}.
Usage: python -I -B make_disposition_table.py [--check]"""
import sys, json, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent; REC = HERE.parent / 'receipts'; OUT = HERE / 'out'
sha = lambda b: hashlib.sha256(b).hexdigest()
REG = json.loads((HERE / 'inputs/RER_REGISTRY_v0_2_r4_14_PHASEA.json').read_text(encoding='utf-8'))
R = {x['id']: x for x in REG['records']}
H = {f.name: sha(f.read_bytes()) for f in sorted(REC.iterdir()) if f.is_file()}
def rc(name): return f'{name} `{H[name][:8]}…{H[name][-4:]}`'
B01, B02, B03, B04, B05, B05F, B06, B07, B08 = ('B01_RECEIVING_REVIEW_20261019.md', 'B02_RECEIVING_REVIEW_20261019.md', 'B02R1_B03_RECEIVING_REVIEW_20261020.md', 'B04_RECEIVING_DECISION_20261020.md', 'B05_RECEIVING_FINDINGS_20261020.md', 'R4_7_B05_FOLLOWUP_RECEIVING_DECISION_20261020.md', 'B06_RECEIVING_REVIEW_20261021.md', 'B07_RECEIVING_REVIEW_20261021.md', 'B08_RECEIVING_REVIEW_20261021.md')
ROWS = [
 ('RER-GEN-C01', 'B-02 (19 Oct): ACCEPT_SCOPED_MATH / HARM_MISSING', [B02, B03], 'HARM not received (declared historical limit, kept)', 'REVIEWED_SCOPED'),
 ('RER-GEN-C02', 'B-02 (19 Oct): ACCEPT_SCOPED_MATH / B02-R1 note correction / HARM_MISSING; B-02 r1 (20 Oct): B02-R1 CLOSED (the r4.6 C02 record never contained the wrong formula)', [B02, B03], 'HARM not received (kept)', 'REVIEWED_SCOPED'),
 ('RER-GEN-C03', 'B-02 (19 Oct): ACCEPT_SCOPED_MATH / HARM_MISSING (receiver independent exact-Fraction implementation reproduced the coefficients)', [B02, B03], 'HARM not received (kept)', 'REVIEWED_SCOPED'),
 ('RER-GEN-C04', 'B-03 (20 Oct): ACCEPT SCOPED — witness/orbit 20/20; source-coverage incomplete (HARM, ANGLE_DATA); general P1,P3 polynomials not checked', [B03], 'HARM, ANGLE_DATA not received (kept)', 'REVIEWED_SCOPED'),
 ('RER-GEN-C05', 'B-03 (20 Oct): ACCEPT SCOPED — degree-17 rank-four witness reproduced in both pathways; RANKDATA bytes not received; [THM] appropriate for the conditional proposition', [B03], 'RANKDATA not received (kept)', 'REVIEWED_SCOPED'),
 ('RER-GEN-C06', 'B-03 (20 Oct): ACCEPT SCOPED — exact invariant child-free stratum, local rank-two lower bound; source coverage complete', [B03], '—', 'REVIEWED_SCOPED'),
 ('RER-GEN-C07', 'B-03 (20 Oct): ACCEPT SCOPED — degree-five graph defect; full twelve-basis identical-script replay not completed by the receiver', [B03], 'replay limit declared', 'REVIEWED_SCOPED'),
 ('RER-GEN-C08', 'B-03 (20 Oct): ACCEPT SCOPED — the two named factor failures only; source coverage complete', [B03], '—', 'REVIEWED_SCOPED'),
 ('RER-GEN-C09', 'B-03 (20 Oct): ACCEPT SCOPED — pairwise fixed-finite-age separation at stated jet/order; not all-order independent rederivation; source coverage complete', [B03], '—', 'REVIEWED_SCOPED'),
 ('RER-TRIAD-FORMAL-AGE', 'B-06 (21 Oct): formal construction and bounded uniqueness ACCEPT SCOPED; grade/provenance CORRECTION REQUIRED → applied in r4.11 ([ALG], formal; source grade); r4.11 ACCEPT SCOPED', [B06], 'result author also wrote the source review (declared; grade provenance line)', 'REVIEWED_SCOPED_AFTER_CORRECTION'),
 ('RER-TRIAD-AGE-CURVATURE', 'B-08 (21 Oct): ACCEPT SCOPED [ALG], FINITE_ORDER (w_13 identity; fixed parent chart and child plane)', [B08], '—', 'REVIEWED_SCOPED'),
 ('RER-TRIAD-REGULAR-3FOLD', 'B-04 (20 Oct): author-conflict disclosure ACCEPT; mathematical scope review ACCEPT SCOPED (ACCEPT_SCOPED_MATH; SOURCE_COVERAGE_COMPLETE)', [B04], '—', 'REVIEWED_SCOPED'),
 ('RER-ER2B-T6D', 'No scientific review possible: BLOCKED_SOURCE_UNVERIFIED (ER-2B v0.2 primary package not inspected; NOT_FOUND_IN_SEARCHED_SNAPSHOT, receiver 21 Oct 2026)', ['FAST_TRACK_DECISION_20261021.md'], 'ER-2B v0.2 study/evidence ZIP missing; D-2 disposition kept', 'BLOCKED_SOURCE_UNVERIFIED'),
 ('RER-ER2B-CARRIER', 'No scientific review possible: BLOCKED_SOURCE_UNVERIFIED (as above); r4.14 adds a current RRF v0.8.4 §0.3 context reference only — does not unblock', ['FAST_TRACK_DECISION_20261021.md'], 'ER-2B v0.2 missing; v0.1 C15 held (G8/0 audited at pin)', 'BLOCKED_SOURCE_UNVERIFIED'),
 ('RER-F3-N7N8', 'B-08 (21 Oct): formal E7/E8 leading orders ACCEPT SCOPED [ALG, formal]; finite-jet polynomials ACCEPT SCOPED; 24-direction sampling ACCEPT SCOPED [NUM, SAMPLED_ONLY]; Stage-1 boxes as source-reported; 41/41 Stage-2 regression as engineering evidence; regional adequacy / whole-region certificates / multi-step error control INSUFFICIENT EVIDENCE; CORRECTION REQUIRED → applied in r4.13 (ACCEPT SCOPED)', [B08], 'regional/global Stage-2 certificate OPEN (GLOBAL_CERTIFICATE_PENDING); not an adoption prerequisite per the receiver', 'REVIEWED_SCOPED_WITH_OPEN_CERTIFICATE'),
 ('RER-RRF-CND01', 'B-06 (21 Oct): general fixed-set theorem ACCEPT SCOPED; G2 physical application unproven', [B06], 'physical realization not shown (declared)', 'REVIEWED_SCOPED'),
 ('RER-GEN-K3-MODAL', 'B-01 (19 Oct): relevance assessment only — CONTEXT_ONLY / PASS; explicitly NOT acceptance of the record. Owner theorems adopted in Genesis v2.8.6/v2.8.7. The RER-native E-conjugacy transport step (E∘N = F_1∘E, E∘N^6 = F_1^6∘E) has NO independent receiver receipt (RER editor = author). → BATCH REVIEW ITEM (packet: k3_econjugacy/)', [B01], 'E-conjugacy step: independent review pending (carried in this batch; r4.14 receipt says so)', 'BATCH_REVIEW_ITEM'),
 ('RER-DYAD-FORMAL-INVOLUTION', 'B-05 (20 Oct): source inventory accepted; six follow-up items → r4.7 (ACCEPT SCOPED, 20 Oct); B-06 (21 Oct): A formal centralizer / R_0 uniqueness, B analytic clock bridge, C C∞ embedding — ACCEPT SCOPED (owner import); proof packages not independently re-audited', [B05, B05F, B06], 'owner proof packages not re-audited (declared); G2 §5b CARRIER_IDENTIFICATION_PENDING', 'REVIEWED_SCOPED_OWNER_IMPORT'),
 ('RER-TRIAD-FORMAL-INVOLUTION', 'B-07 (21 Oct): ACCEPT SCOPED ((ii)(b) rests on the prior receiver certificate, not fully replayed; [NUM] basis line stays [NUM]; (d) conditional); recorded in r4.12 (ACCEPT SCOPED)', [B07], 'full identical-script replay of TRIAD_CK_PY open (alternative exact certificate PASS)', 'REVIEWED_SCOPED'),
 ('RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'B-07 (21 Oct): ACCEPT SCOPED with the explicit child contract in (d); recorded in r4.12', [B07], '—', 'REVIEWED_SCOPED'),
]
def build():
    rows = []
    for rid, dec, files, lim, st in ROWS:
        r = R[rid]
        rows.append({'record': rid, 'primary_grade': r['primary_grade'], 'task': r['task'], 'phaseA_status': r['phaseA_status'], 'adoption_status': r['adoption_status'],
                     'receiver_decision_quoted': dec, 'receipt_files': [{'file': f, 'sha256': H[f]} for f in files], 'declared_limits': lim, 'coverage_status': st,
                     'r4_14_receipt_field': (r['fields'].get('Review receipt') or 'NO_IN_RECORD_RECEIPT')[:160]})
    assert [x['record'] for x in rows] == [x['id'] for x in REG['records']], 'record order/set must equal the registry'
    summary = {'records': len(rows), 'REVIEWED_SCOPED*': sum(1 for x in rows if x['coverage_status'].startswith('REVIEWED_SCOPED')), 'BLOCKED_SOURCE_UNVERIFIED': sum(1 for x in rows if x['coverage_status'] == 'BLOCKED_SOURCE_UNVERIFIED'), 'BATCH_REVIEW_ITEM': sum(1 for x in rows if x['coverage_status'] == 'BATCH_REVIEW_ITEM'), 'adoption_status_all': sorted({x['adoption_status'] for x in rows})}
    rep = {'_about': 'Twenty-record disposition / coverage table (Phase B batch; PREPARER_ROLE compilation of RECEIVER decisions and declared limits; no acceptance added by the preparer). Registry source: Phase A r21 on RER r4.14.', 'registry_sha256': sha((HERE / 'inputs/RER_REGISTRY_v0_2_r4_14_PHASEA.json').read_bytes()), 'receipts': H, 'rows': rows, 'summary': summary}
    md = ['# RER twenty-record disposition / coverage table (Phase B batch, 21 Oct 2026)', '', 'PREPARER_ROLE compilation. Column "Receiver decision" quotes the receiving co-owner\'s issued decisions (receipt files hashed in `receipts/`); "Coverage" is the preparer\'s bookkeeping label, not a new acceptance. Adoption status is PENDING for all 20 records; adoption is a separate PI decision.', '',
          '| # | Record | Grade | Task / Phase A status | Receiver decision (quoted) | Receipts | Declared limits (kept) | Coverage |', '|---|---|---|---|---|---|---|---|']
    for i, x in enumerate(rows, 1):
        md.append(f"| {i} | `{x['record']}` | {x['primary_grade']} | `{x['task']}` / {x['phaseA_status']} | {x['receiver_decision_quoted']} | {'; '.join(rc(f['file']) for f in x['receipt_files'])} | {x['declared_limits']} | **{x['coverage_status']}** |")
    md += ['', f"Summary: {summary['records']} records — {summary['REVIEWED_SCOPED*']} with receiver scoped acceptance (incl. corrections applied and accepted), {summary['BLOCKED_SOURCE_UNVERIFIED']} BLOCKED_SOURCE_UNVERIFIED (ER-2B v0.2 source not inspected), {summary['BATCH_REVIEW_ITEM']} batch review item (RER-GEN-K3-MODAL E-conjugacy transport step). Adoption status: {', '.join(summary['adoption_status_all'])} everywhere.", '',
           'Accepted source limitations (HARM, ANGLE_DATA, RANKDATA; owner proof packages not re-audited; prior receiver certificate not fully replayed) are distinguishable from the accepted scientific payload and are carried unchanged. The Stage-2 regional/global certificate of RER-F3-N7N8 remains OPEN; per the receiver it is not a blanket adoption prerequisite. Load-bearing unresolved contradictions: none known to the preparer in a claim presented as accepted; this statement is for the receiver to confirm or refute in the final review.', '']
    return rep, '\n'.join(md)
if __name__ == '__main__':
    rep, md = build(); J = (json.dumps(rep, ensure_ascii=False, indent=1) + '\n').encode('utf-8'); M = md.encode('utf-8')
    if '--check' in sys.argv:
        same = (OUT / 'DISPOSITION_TABLE_20_RECORDS.json').read_bytes() == J and (OUT / 'DISPOSITION_TABLE_20_RECORDS.md').read_bytes() == M; print('stored outputs byte-identical:', same); sys.exit(0 if same else 1)
    OUT.mkdir(exist_ok=True); (OUT / 'DISPOSITION_TABLE_20_RECORDS.json').write_bytes(J); (OUT / 'DISPOSITION_TABLE_20_RECORDS.md').write_bytes(M); print(rep['summary'])
