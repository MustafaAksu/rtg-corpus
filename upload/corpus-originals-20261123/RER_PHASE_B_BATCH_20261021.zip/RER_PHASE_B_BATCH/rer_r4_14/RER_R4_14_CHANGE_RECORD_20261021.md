# RER v0.2 DRAFT r4.14 — change record (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE. Describes the r4.13 → r4.14 edit and its replay. Not an acceptance of any record; the current-reference additions are an **L2 source-delta proposal** for the receiving review (Fast-Track decision of 21 Oct 2026, §§5–6).

**Base.** r4.13 `e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c` (ACCEPT SCOPED; Phase A r18–r20 on it ACCEPT SCOPED). **Result.** r4.14 `92f983e64bd54e208898954c45c4ac6482928b794d08b3d1660f0db9d00ff044`, built by `build_r4_14_draft.py` from the 17-edit list `r4_13_to_r4_14_edits.json` (`d89c3ebc8c73bd076b4fcedc1afd94533e4e78ee5b8eac495600e119b808fc8c`; every edit exact-once; reverse edits recover r4.13 byte-exactly).

## 1. What changes (17 edits; 85-line unified diff `r4_13_to_r4_14_DRAFT.diff`)

| Edit | Place | Content |
|---|---|---|
| H1 | document status (line 7) | r4.14 status sentence prepended; the r4.13 sentence kept ("r4.13 was: …") |
| G7, G8, G9, G10 | §5, after the last historical `Reference:` line of each guard | one `[DEF]` **r4.14 current-source note** (G10: **current/history clarification**) + current `Reference:` lines with key `RRF084` — G7: §6.2, §0.2; G8: §0.3, §6.2; G9: §4.2a, §6.3; G10: front matter, §6.4 (pointer), §8.1, §10.1. Each note ends with the sentence that the v0.8 pins are historical, the v0.8 bytes were not recovered, **no old-to-current byte equality is claimed and the historical pins are not moved** |
| X1 | §5.1, before the G3 overlay | the current v0.8.4 locations (line ranges) in one sentence; the "Adopted v0.8 locations" column marked historical |
| R1, R2 | RER-ER2B-CARRIER, RER-RRF-CND01 | one `Import/reference:` line each for `RRF084` (§0.3 / §6.2) after the historical v0.8 import line; no other line of either record changes (RER-ER2B-CARRIER stays BLOCKED_SOURCE_UNVERIFIED) |
| K3 | RER-GEN-K3-MODAL Review receipt | append-only: the B-01 review (`15b5c0cb…`) assessed relevance only (CONTEXT_ONLY); the RER-native E-conjugacy transport step has **no independent receiver receipt** and is carried into the Phase B batch; the record is not presented as independently reviewed |
| T1–T5 | §7 | `RRF084` rows in the source table and the owner-version table; `DYAD6413` / `RRF082` status cells append "r4.14: BYTE-VERIFIED (Phase A r20 …)" with the section-check r2 results; superseded-pin chain `RRF08_ADOPTED` → `RRF082` → `RRF083` → `RRF084` (historical line pins kept) |
| O1 | §7 `[OPEN]` ER-2B paragraph | append-only: the receiver's 21 Oct 2026 archive search (113 files, 50 ZIPs, 2,629 members) located none of RRF v0.8, ER-2B v0.2 study/evidence ZIP, Q7 ZIP, RRF coincidence files, G2 note v0.4 original — NOT_FOUND_IN_SEARCHED_SNAPSHOT; ER-2B records stay BLOCKED_SOURCE_UNVERIFIED, G2 §5b stays CARRIER_IDENTIFICATION_PENDING; not repeated without new material |
| Q1 | §8 queue | one P0 (r4.14) row: the Phase B batch items for the receiving co-owner and the PI |
| H2 | §9 | the R4.14 history entry (`[ALG]`) before R4.13 |

**Unchanged:** every grade, exactness code, task, adoption text, contract cell, claim line (`[THM]`/`[ALG]`/`[NUM]`), OPEN item and scientific pin of all 20 records; the 13 historical gap-reference lines and all v0.8 / v0.3.20 / v6.4.13 / v0.8.2 / v0.8.3 pins; the 17 records other than the three touched ones are byte-identical. Line-initial tags: `[DEF]` +4, `[ALG]` +1 (history entry), no `[ENG]`.

## 2. Why these edits

- **Current references (G7–G10, two records).** The gap-reference audit (`inputs/gap_reference_audit.json`; package `audit/` of the batch) read the current RRF v0.8.4 section for each of the 12 live uses of the missing v0.8 pin and located every obligation phrase the RER relies on; the line ranges in the new lines are the audited block ranges (gate S1 recomputes them against the held file). This implements the receiver's route (b)+(c): fresh mappings against adopted v0.8.4 where supported, v0.8 pins preserved as history with their original-byte boundary; no automatic repin; receiver decides row by row.
- **G10 clarification.** The guard's first sentence and the r4 / r4.4 overlays name v0.8, v0.8.2 and v0.8.3 as governing; r4.14 states the current standard (v0.8.4) once and marks those sentences as dated history (the receiver's r18/r19 note). §6.4 is recorded as a pointer, not the taxonomy; the closure-proposal file is not held (evidence limitation retained; receiver search did not locate it).
- **G9 notes.** The r4.11 statement "owner-reported; bytes not held here" for RRF v0.8.4 and RECOG v0.3.22 is superseded by the Phase A r19 byte verification; the W3 owner-scope wording of v0.8.4 §6.3 is quoted verbatim.
- **GEN-K3-MODAL.** Receiver requirement (Fast-Track §6): the RER-native E-conjugacy step must have its own independent receipt or be carried into the batch; no receipt exists, so it is carried and the record is marked accordingly.
- **§7 custody.** Phase A r20 byte verification of the v6.4.13 and v0.8.2 originals and the receiver's search receipt.

## 3. Replay

```
python -I -B make_r4_14_edits.py      # regenerates the edit list (same hash)
python -I -B build_r4_14_draft.py     # r4.14 92f983e6…
python -I -B check_r4_14_draft.py --controls   # 11/11 gates; 12 controls each fail their gate; exit 0
```

Gates M1–M3 (base hash, deterministic rebuild, reversibility), L1 (locality), L2 (untouched records byte-identical; contract tables byte-identical), P1 (parser: records unchanged except the two import lines; 13 historical gap lines unchanged; exactly 10 new `RRF084` lines 2/2/2/4; source table +`RRF084`), S1 (every `RRF084` range equals the audited current block and starts at the section heading; held file hash), S2 (G10 clarification and the no-equality sentences; W3 wording), S3 (K3-MODAL receipt append-only, missing-receipt statement), S4 (tag counts), K1 (22 cited evidence pins carried). Controls: new failure classes only (range shift, hash alteration, historical line dropped, silent repin, contract cell, OPEN item, history marking removed, no-equality sentence removed, receipt presented as reviewed, note given `[THM]`, stray edit, §9 entry dropped).

## 4. Package

`RER_r4_14/` = the r4.13 package plus: `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_14.md`, `make_/build_/check_r4_14_*.py`, `r4_13_to_r4_14_edits.json`, `r4_13_to_r4_14_DRAFT.diff`, `check_r4_14_output.txt`, `inputs/gap_reference_audit.json`, `sources/current/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md` (`2fb0a0fe…afce`), this record. The parser `tools/rer_parse_phaseA_r10.py` (`7b6b98aa…`) is unchanged.
