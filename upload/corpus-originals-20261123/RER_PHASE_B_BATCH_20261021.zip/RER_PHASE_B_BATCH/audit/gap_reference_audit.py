"""RER gap-reference audit (Phase B batch, 21 Oct 2026; receiver Fast-Track decision §5: "prepare the 13-row audit with exact pinned/current source identity,
quoted statement, scope/hypotheses, actual inspection extent and proposed disposition").
Rows: the 13 GAP_REFERENCE rows of the Phase A r20 matrix (G7:2, G8:3, G9:4, G10:4) plus the two RECORD_IMPORT uses of the v0.8 pin outside the gaps
(RER-RRF-CND01/2 §6.2, RER-ER2B-CARRIER/3 §0.3), so that every RRF08_ADOPTED live use is covered (12 rows).
Axes kept separate: (1) pinned identity and whether the pinned bytes are held; (2) for held pins, the pinned line range cut and hashed, and the RER's
verbatim quotes / RIDs located inside it; (3) for the RRF v0.8 pins (original bytes NOT recovered — receiver search 21 Oct 2026), the current adopted
RRF v0.8.4 section located by heading, hashed, with the obligation phrases the RER relies on searched in it, and the known legs recorded
(v0.8 -> v0.8.3 editor-reported; v0.8.2 -> v0.8.3 -> v0.8.4 computed here from held bytes); (4) a PREPARER proposal for the disposition. The proposal
is not a receiver finding; no RER text is changed by this script; no old-to-current byte equality is claimed for any v0.8 pin.
Usage: python -I -B gap_reference_audit.py            -> write out/*; exit 0 iff all held-source hashes match and every located check holds
       python -I -B gap_reference_audit.py --check    -> recompute and compare with out/* (no write)
       python -I -B gap_reference_audit.py --controls -> parameterized negative controls (quote altered in the RER, pinned block altered, source withheld,
                                                        obligation phrase removed); exit 0 iff every control is detected"""
import sys, json, hashlib, re
from pathlib import Path
HERE = Path(__file__).resolve().parent; SRC = HERE / 'sources'; OUT = HERE / 'out'
sha = lambda b: hashlib.sha256(b).hexdigest()
FILES = {'RER': ('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_13.md', 'e92991bd90d24599248410a20845a14588f4ae75e6582681aaa300de370f368c'),
         'RECOG': ('RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md', 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'),
         'ER01': ('RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md', '267c6f37e70220dac02b22b605ef77b8faea009d90db764139887c115cd1fb44'),
         'RRF082': ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_2.md', 'f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461'),
         'RRF083': ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md', 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'),
         'RRF084': ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md', '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'),
         'MATRIX': ('PHASEA_r20_SOURCE_CURRENCY_MATRIX.json', None)}
V08 = 'c4ec1f10da0cdf3b95a84b3013909e04db49212e0119b858c170e5fd8f42b44a'
# RRF section anchors (heading start, end-heading starts) — same cuts as OWNER_SECTION_CHECK r1/r2
RRF_SPEC = {'front matter': ('---', ('# 0. ',)), '§0.2': ('### 0.2', ('### 0.3',)), '§0.3': ('### 0.3', ('# 1. ',)), '§4.2a': ('### 4.2a', ('## 4.3 ',)),
            '§6.2': ('### 6.2 ', ('### 6.2a', '### 6.3 ')), '§6.3': ('### 6.3 ', ('### 6.4 ',)), '§6.4': ('### 6.4 ', ('# 7. ',)), '§8.1': ('### 8.1', ('# 9. ',)), '§10.1': ('### 10.1', ('### 10.2',))}
# the RER's reliance on each source use: what the RER text asserts / quotes, and the phrases the current v0.8.4 block must carry for the same obligation
ROWS = [
 dict(row=('RER-G7', 0, 'RRF08_ADOPTED'), sec='§6.2', rer_reliance='RRF-CND-01 is an interface proposal; fixed-set preservation is a conditional theorem; equal coordinates, zero edge, exchange-fixed state and physical merge not identified; a physical exclusion needs Identity–Action, Carrier–Encoding, Clock–Model witnesses and regularity/clock/domain declarations (G7 [DEF] + r4.6 overlay (i)–(vi)).',
      obligations=['PROPOSED INTERFACE ONLY', 'Four notions must remain distinct', 'equal node coordinates', 'zero edge relation', 'exchange-fixed complete configuration', 'node merge', 'Identity / Action', 'Carrier / Encoding', 'Clock / Model', 'Merge', 'regularity: analytic / C^\\infty / formal / other', 'clock: primitive T / six-step T^6 / other physical update', 'Passive transport guard'],
      legs='v0.8 -> v0.8.3: CHANGED-SCOPE (RRF editor Q6, EDITOR-REPORTED); v0.8.2 -> v0.8.3 and -> v0.8.4: CHANGED (computed here); v0.8.3 -> v0.8.4: CHANGED (r1: notice paragraph prepended; "does not supply such an involution/root" replaced by the DYAD v6.4.18 E1–E4 statement)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §6.2 as a current reference of G7 (the realization-contract obligations (i)–(vi) are all present in the current text; the regularity/clock paragraph now records C∞ existence as owner status, which strengthens, not weakens, the clock-declaration obligation); keep the v0.8 §6.2 pin as historical with the original-byte boundary. No equality claim.'),
 dict(row=('RER-G7', 1, 'RRF08_ADOPTED'), sec='§0.2', rer_reliance='Current source receipts and inheritance/representation boundary of the working standard (G7 second reference; used as the RRF-side source-receipt boundary, not for a theorem).',
      obligations=['Current source receipts and inheritance/representation boundary', 'RRF import boundary', 'RER v0.2', 'no theorem/profile/standard adopted'],
      legs='v0.8 -> v0.8.3: not reported by the editor for §0.2 (SOURCE_MISSING leg); v0.8.2 -> v0.8.3 -> v0.8.4: computed here; v0.8.3 -> v0.8.4: CHANGED (r1: additive current-source rows)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §0.2 as the current source-receipt boundary (it now lists DYAD v6.4.18, RECOG v0.3.21, OFN v0.10, Genesis v2.8.9 and keeps the RER row as "update plan only"); keep the v0.8 pin historical. The RER G10 sentence "RRF v0.8 is the adopted working representation standard" needs the current/history clarification (r4.14).'),
 dict(row=('RER-G8', 0, 'ER01'), sec=None, held_lines=True, rer_reliance='Passive rechart versus genuinely new triad law: the T2×T2 vs T3 split is not invariant under nonlinear recharting; model A (passive transport, same local outward quartic return) vs model B (new normalized-addition, opposite radial sign); the new linearly closed triple has nonzero original closure sum; additive node carrier only after the carrier is specified.',
      quotes=['### ER2B-C15 — [ALG/THM] Passive rechart versus genuinely new triad law', 'A — passive transport of the original Genesis model', 'B — new normalized-addition model', 'opposite local radial signs because they use different additive laws', 'only after that carrier is specified'],
      proposal='AUDITED_AT_PIN (preparer): the pinned v0.1 block carries the statements the RER relies on; ER-2B v0.2 C19–C20 remain a direct-source request (v0.2 package NOT_FOUND_IN_SEARCHED_SNAPSHOT, receiver 21 Oct 2026). Pin unchanged. Receiver per-reference disposition pending.'),
 dict(row=('RER-G8', 1, 'RRF08_ADOPTED'), sec='§0.3', rer_reliance='Passive chart transports state, dynamics, readout, action, closure/incidence, events and domain together; reimposing linear addition/closure in a new nonlinear chart changes the conditional coupled model (G8 [DEF]; editor Q1: SAME-SCOPE in v0.8.3).',
      obligations=['passive', 'transports the state, update, exchange action, incidence/closure operator, event predicate and comparison subset together', 'Reimposing', 'different conditional model', 'RRF-DYAD-W', 'RRF-NET-W-RAW', 'OPEN-B → OPEN-E1 → OPEN-E2'],
      legs='v0.8 -> v0.8.3: SAME-SCOPE (RRF editor Q1, EDITOR-REPORTED; not byte equality); v0.8.2 -> v0.8.3 -> v0.8.4: computed here; v0.8.3 -> v0.8.4: IDENTICAL (r1)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §0.3 as current reference of G8 (same obligation, editor-reported same scope, byte-identical v0.8.3 -> v0.8.4); keep the v0.8 pin historical.'),
 dict(row=('RER-G8', 2, 'RRF08_ADOPTED'), sec='§6.2', rer_reliance='Where the passive/new-model distinction is used for a physical coincidence inference, the G7 realization contract applies (G8 overlay) — the §6.2 Passive transport guard.',
      obligations=['Passive transport guard', 'A true passive recharting transports the *same* model, action and test subset', 'different model contract'],
      legs='as G7/0', proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): as G7/0 (same section).'),
 dict(row=('RER-G9', 0, 'RECOG'), sec=None, held_lines=True, rer_reliance='Cross-model T_k/T_-k conjugacy is distinct from a within-chart involution, edge bookkeeping and physical pole exchange; owner-first: RECOG-ALG-SHEAR-ORIENTATION-CONJUGACY (S∘T_k∘S = T_-k exactly; no conjugacy-invariant observable distinguishes k from -k; orientation is not an internal RECOG selection).',
      quotes=['### §6.6a CELL-G1 — Ratio-Composition Laws for the Phase Shear (R5) `[ALG]` {#sec-6-6a-composition}', '[RID: RECOG-ALG-SHEAR-ORIENTATION-CONJUGACY]', 'S\\circ T_k\\circ S=T_{-k}', 'no conjugacy-invariant observable of the isolated dyad dynamics distinguishes $k$ from $-k$', 'not an internal RECOG selection'],
      proposal='AUDITED_AT_PIN (preparer): RID and the conjugacy statement are inside the pinned lines; the RER reads it as a distinction, not as a physical pole-exchange statement, consistent with the owner scope guard. v0.3.20 -> v0.3.21 -> v0.3.22 block IDENTICAL (r13 check, OWNER_SECTION_CHECK_r1); frozen pin unchanged. Receiver per-reference disposition pending.'),
 dict(row=('RER-G9', 1, 'RECOG'), sec=None, held_lines=True, rer_reliance='CELL-F4 requires W1 (verbatim quote), W2 attachment, W3 (verbatim same-space quote), W4 independence from the reconstructed event log, W5 conditioning/common-driver control; no token-to-cochain map is constructed.',
      quotes=['#### §6.16g CELL-F4 — Identification and Inheritance Ledger (R6 successor)', '[RID: RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS]', 'a fixed directed graph, coefficient module and edge cochain $a$ with a registered realization', 'event-indexed cochains $a^-$, $a^+$ in the **same** cohomology space, so that $\\Delta[a]=[a^+]-[a^-]$ is defined', '**(W2)** a registered dyad', '**(W4)** an independence condition preventing $\\Delta[a]$ from being reconstructible from the token log, event count or Track-A clock', '**(W5)** a declared conditioning/common-driver quotient', 'does not make a token $\\to\\Delta[a]$ test well-posed'],
      proposal='AUDITED_AT_PIN (preparer): both verbatim quotes (W1, W3) and the W2/W4/W5 paraphrases are supported by the pinned lines; the RID is inside the range. The W3 same-space reading is the owner text. Pin unchanged. Receiver per-reference disposition pending.'),
 dict(row=('RER-G9', 2, 'RRF08_ADOPTED'), sec='§4.2a', rer_reliance='RRF §4.2a is the representation-interface pin for "cross-model orientation conjugacy is not physical pole exchange"; RECOG §6.6a is the scientific owner (overlay Q2: SAME-SCOPE, owner-first).',
      obligations=['Cross-model orientation conjugacy is not physical pole exchange', 'RECOG-ALG-SHEAR-ORIENTATION-CONJUGACY', 'S_o\\circ T_k\\circ S_o=T_{-k}', 'conjugacy between two parameter-labelled maps', 'S_h=h_6(-I)h_6^{-1}', '\\mathscr O_e', 'RRF OPEN-A'],
      legs='v0.8 -> v0.8.3: SAME-SCOPE (editor Q2, EDITOR-REPORTED); v0.8.2 -> v0.8.3: IDENTICAL (OWNER_SECTION_CHECK_r2, computed here again); v0.8.3 -> v0.8.4: CHANGED (r1: additive current owner-source pin paragraph naming RECOG v0.3.21 as primary source)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §4.2a as current reference (the conjugacy statement and the three distinctions are unchanged; the new paragraph pins RECOG v0.3.21 §6.6a as primary source, consistent with the RER owner-first reading); keep the v0.8 pin historical.'),
 dict(row=('RER-G9', 3, 'RRF08_ADOPTED'), sec='§6.3', rer_reliance='W3 source note: RRF v0.8.3 §6.3 wording ("comparison/transport between pre- and post-birth cohomology spaces") classified by the RRF editor as an unmarked extension; RER reads W3 only as the owner same-space condition; v0.8.4 §6.3 states W3 at owner scope and keeps different-space transport as an explicitly OPEN extension (r4.11, owner-reported then).',
      obligations=['**W1**', '**W2**', 'in the **same** cohomology space, so that $\\Delta[a]=[a^+]-[a^-]$ is defined', '**W4**', '**W5**', 'RRF extension, **not** RECOG W3', 'RER G9/1 should cite owner W3 separately from this extension', 'not yet well-posed'],
      legs='v0.8 -> v0.8.3: byte-identical block (EDITOR_VERIFIED, block hash 0db65928…8c24 / 588f37a0…05a3 on v0.8.3 reproduced here; v0.8 bytes not held); v0.8.2 -> v0.8.3: IDENTICAL (computed here); v0.8.3 -> v0.8.4: CHANGED (r1: W3 same-space wording with import pin; new [OPEN] extension paragraph)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §6.3 as current reference of G9 — its W3 row now carries the owner same-space wording verbatim and names the different-space transport as an RRF extension "not RECOG W3", which resolves the r4.10 W3 source note for current use; the v0.8/v0.8.3 §6.3 text stays historical (its W3 wording was the unmarked extension). The r4.11 "owner-reported, bytes not held" statement is superseded by Phase A r19 (bytes held, hash verified) and should be updated in r4.14.'),
 dict(row=('RER-G10', 0, 'RRF08_ADOPTED'), sec='front matter', rer_reliance='RRF v0.8 is the adopted working representation standard, authenticated by header/hash; v0.7 and the integration draft are separate historical sources.',
      obligations=['version: "v0.8.4"', 'status: "ADOPTED — RRF v0.8.4 working representation standard', 'supersedes: "RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md', 'predecessor source draft: "RTG_RRF_REPRESENTATION_REGISTRY_v0_7_DRAFT.md'],
      legs='v0.8 -> v0.8.3: metadata (edition change); v0.8.3 -> v0.8.4: CHANGED (r1: version/date/status/supersedes/review-scope)',
      proposal='CURRENT_HISTORY_CLARIFICATION_REQUIRED (L2 text): the G10 [DEF] "RRF v0.8 is the adopted working representation standard" is a dated statement; r4.14 should state that RRF v0.8.4 (adopted 20 Oct 2026; bytes held and verified, Phase A r19) is the current standard and that v0.8 / v0.8.2 / v0.8.3 are historical, with the v0.8 pins kept as historical references and the "v0.8.3 … governs" r4.4 overlay marked history. Add v0.8.4 front matter as current reference; keep the v0.8 header pin historical.'),
 dict(row=('RER-G10', 1, 'RRF08_ADOPTED'), sec='§6.4', rer_reliance='Adopted v0.8 §6.4 was the OPTIONAL / NON-NORMATIVE / RER-PLAN-ONLY dynamical-closure contract; from v0.8.1 on the taxonomy is the separate proposal RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md (65186f39…, editor-recorded) and §6.4 is a non-normative pointer (overlay Q3/Q4).',
      obligations=['RER dynamical-closure proposal — external, source pending', 'NON-NORMATIVE', 'RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md', 'not** a mandatory profile field, owner theorem, numerical certificate or approved physical representation', 'Stage-2 global certificate status is PENDING'],
      legs='v0.8 -> v0.8.1: §6.4 content moved out to the separate proposal (EDITOR-REPORTED); v0.8.2 -> v0.8.3 -> v0.8.4: computed here (pointer text); v0.8.3 -> v0.8.4: IDENTICAL (r1)',
      proposal='EVIDENCE_LIMITATION_RETAINED (L2): v0.8.4 §6.4 is a pointer, not the taxonomy (receiver Fast-Track §5). The taxonomy source RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md (65186f39…) is NOT held by the preparer; the editor-recorded hash is the only identity. Proposed: add v0.8.4 §6.4 as the current pointer reference; record the proposal file as a separate SOURCE_MISSING reference (new catalog key, HASH_PRINTED_UNVERIFIED) rather than repinning the taxonomy to §6.4; keep the v0.8 §6.4 pin historical. The FORMAL_ONLY finite-jet wording [OPEN] stays open.'),
 dict(row=('RER-G10', 2, 'RRF08_ADOPTED'), sec='§8.1', rer_reliance='Integration guard: RER F3, formal age families, w13 and candidate factors are not imported as RRF theorems; CELL-F4 W1–W5 are missing-interface criteria; no new primordial coincidence axiom (G10 / r4 overlay).',
      obligations=['RRF-CND-01` does not establish a new primordial coincidence axiom', 'RECOG CELL-F4 W1–W5 are missing-interface criteria', 'RER F3, formal age families', 'not imported as verified RRF scientific theorems or new native profiles', 'global certificate remains pending'],
      legs='v0.8 -> v0.8.3: not reported by the editor for §8.1 (SOURCE_MISSING leg); v0.8.2 -> v0.8.3 -> v0.8.4: computed here; v0.8.3 -> v0.8.4: IDENTICAL (r1)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §8.1 as current reference (the non-import guard the RER relies on is present verbatim in the current text); keep the v0.8 pin historical.'),
 dict(row=('RER-G10', 3, 'RRF08_ADOPTED'), sec='§10.1', rer_reliance='Source-access statements in RRF §§0.2/10.1 belong to its earlier review snapshot ("RER proposed v0.2 … NOT READ / NOT MOUNTED"); they do not mean the RER files are absent; separate adoption/QA files not supplied.',
      obligations=['Additional v0.8 source inventory and adopted-baseline authentication', 'RER proposed v0.2 / F3 / formal age / N=7/8 Stage 2', 'NOT READ / NOT MOUNTED', 'separate v0.8 adoption record'],
      legs='v0.8 -> v0.8.3: not reported by the editor for §10.1 (SOURCE_MISSING leg); v0.8.2 -> v0.8.3 -> v0.8.4: computed here; v0.8.3 -> v0.8.4: IDENTICAL (r1)',
      proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §10.1 as current reference (the dated "NOT READ / NOT MOUNTED" snapshot is preserved there as history, which is exactly how the RER reads it); keep the v0.8 pin historical.'),
 dict(row=('RER-RRF-CND01', 2, 'RRF08_ADOPTED'), sec='§6.2', rer_reliance='RER-RRF-CND01 imports the RRF-CND-01 interface (general fixed-set theorem accepted B-06; G2 physical application unproven).',
      obligations=['PROPOSED INTERFACE ONLY', 'The general exchange-fixed lemma remains mathematical source background', 'conditional mathematics', 'not automatic physical node-mediated exclusion'],
      legs='as G7/0', proposal='FRESH_CURRENT_REFERENCE_PROPOSED (L2): add RRF v0.8.4 §6.2 as current import reference of RER-RRF-CND01 (B-06 scoped acceptance unchanged: general theorem accepted, physical application unproven); keep the v0.8 pin historical.'),
 dict(row=('RER-ER2B-CARRIER', 3, 'RRF08_ADOPTED'), sec='§0.3', rer_reliance='RER-ER2B-CARRIER (BLOCKED_SOURCE_UNVERIFIED) cites the §0.3 non-transfer lock as representation context.',
      obligations=['passive', 'Reimposing', 'RRF-DYAD-W', 'RRF-NET-W-RAW', 'OPEN-B → OPEN-E1 → OPEN-E2'],
      legs='as G8/1', proposal='CONTEXT_REFERENCE_ONLY (L2): add RRF v0.8.4 §0.3 as current context reference; the record itself stays BLOCKED_SOURCE_UNVERIFIED (ER-2B v0.2 package not inspected; NOT_FOUND_IN_SEARCHED_SNAPSHOT) — the RRF reference does not unblock it.'),
]
def cut_section(b, start, ends):
    L = b.split(b'\n'); s = start.encode()
    idx = [n for n, l in enumerate(L) if l.startswith(s)]
    i = 0 if start == '---' else (idx[0] if idx else None)
    if i is None: return None
    j = next((n for n in range(i + 1, len(L)) if any(L[n].startswith(e.encode()) for e in ends)), len(L))
    while j > i + 1 and not L[j - 1].strip(): j -= 1
    return (i + 1, j, b'\n'.join(L[i:j]))
def run(mut=None, withhold=()):
    B = {}; idok = {}
    for k, (f, h) in FILES.items():
        if k in withhold: B[k] = None; idok[k] = False; continue
        b = (SRC / f).read_bytes(); B[k] = b; idok[k] = (h is None or sha(b) == h)
    if mut and mut[0] == 'block':  # alter one byte inside a pinned held block
        k, s = mut[1]; s = s.encode(); p = B[k].index(s) + len(s) // 2; B[k] = B[k][:p] + bytes([B[k][p] ^ 1]) + B[k][p + 1:]  # flip one byte inside the named substring
    if mut and mut[0] == 'current':  # remove an obligation phrase from the current v0.8.4 text
        B['RRF084'] = B['RRF084'].replace(mut[1].encode(), b'', 1)
    M = json.loads(B['MATRIX']) if B['MATRIX'] else {'rows': []}
    rows_by = {(x['record'], x['n'], x['key']): x for x in M['rows'] if (x['row_kind'] == 'GAP_REFERENCE') or (x['key'] == 'RRF08_ADOPTED')}
    rer = B['RER'].decode('utf-8') if B['RER'] else ''
    out = []; all_ok = all(idok.values()); lines = [f'{k}: {"MATCH" if ok else "NO MATCH / WITHHELD"} {sha(B[k]) if B[k] else "-"}' for k, ok in idok.items() if FILES[k][1]]
    for r in ROWS:
        rec, n, key = r['row']; mrow = rows_by.get((rec, n, key), {})
        e = {'row': {'record': rec, 'n': n, 'key': key, 'row_kind': mrow.get('row_kind'), 'cited_version': mrow.get('cited_version'), 'cited_sha256': mrow.get('cited_sha256'), 'lines': mrow.get('lines'), 'section': mrow.get('section_or_RID'), 'authentication': mrow.get('authentication'), 'status': mrow.get('status'), 'gap_reference_review_r20': mrow.get('gap_reference_review')},
             'rer_reliance': r['rer_reliance'], 'checks': {}, 'proposal_PREPARER': r['proposal']}
        ok = bool(mrow)
        if r.get('held_lines'):  # pinned bytes held: cut the pinned line range and locate the quotes
            src = B[key]; a, z = mrow['lines']
            if src is None: e['checks']['pinned_block'] = 'SOURCE_WITHHELD'; ok = False
            else:
                L = src.split(b'\n'); blk = b'\n'.join(L[a - 1:z]); e['checks']['pinned_block'] = {'lines': [a, z], 'bytes': len(blk), 'sha256': sha(blk), 'heading_at_first_line': L[a - 1].decode('utf-8', 'replace')[:80]}
                q = {s: (s.encode() in blk) for s in r['quotes']}; e['checks']['quotes_in_pinned_block'] = q; e['inspection_extent'] = 'PINNED_LINES_READ_AND_HASHED; quotes located'
                ok &= all(q.values()) and idok[key]
            # the RER text itself must contain each verbatim quote it claims (G9/1 W1, W3)
            if rec == 'RER-G9' and n == 1:
                e['checks']['quotes_in_RER_text'] = {s: (s in rer) for s in r['quotes'][2:4]}; ok &= all(e['checks']['quotes_in_RER_text'].values())
        else:  # v0.8 pin, bytes missing: current v0.8.4 block + legs from held bytes
            e['checks']['pinned_block'] = 'SOURCE_MISSING: RRF v0.8 original bytes not recovered (receiver search 21 Oct 2026: NOT_FOUND_IN_SEARCHED_SNAPSHOT); pin hash ' + V08[:8] + '… kept as printed'
            cur = {}
            for v in ('RRF082', 'RRF083', 'RRF084'):
                c = cut_section(B[v], *RRF_SPEC[r['sec']]) if B[v] else None
                cur[v] = None if c is None else {'lines': [c[0], c[1]], 'bytes': len(c[2]), 'sha256': sha(c[2])}
            e['checks']['current_blocks'] = cur
            c84 = cut_section(B['RRF084'], *RRF_SPEC[r['sec']]) if B['RRF084'] else None
            if c84 is None: ok = False; e['checks']['obligations_in_v0_8_4'] = 'CURRENT_SOURCE_WITHHELD'
            else:
                ob = {s: (s.encode() in c84[2]) for s in r['obligations']}; e['checks']['obligations_in_v0_8_4'] = ob; ok &= all(ob.values()) and idok['RRF084']
            if cur['RRF082'] and cur['RRF083'] and cur['RRF084']:
                e['checks']['legs_computed_here'] = {'v0.8.2->v0.8.3': 'IDENTICAL' if cur['RRF082']['sha256'] == cur['RRF083']['sha256'] else 'CHANGED', 'v0.8.3->v0.8.4': 'IDENTICAL' if cur['RRF083']['sha256'] == cur['RRF084']['sha256'] else 'CHANGED', 'v0.8.2->v0.8.4': 'IDENTICAL' if cur['RRF082']['sha256'] == cur['RRF084']['sha256'] else 'CHANGED'}
            if r['sec'] == '§6.3' and B['RRF083']:  # editor-verified block identity v0.8 == v0.8.3, reproduced on the held v0.8.3 bytes
                L = B['RRF083'].split(b'\n'); i = next(k for k, l in enumerate(L) if l.startswith(b'### 6.3 ')); j = next(k for k in range(i + 1, len(L)) if L[k].startswith(b'### 6.4 '))
                blk = b'\n'.join(L[i:j]) + b'\n'; e['checks']['editor_verified_v0_8_block_on_v0_8_3'] = {'bytes_with_separator': len(blk), 'sha256': sha(blk), 'expected': '0db65928574b3702be16b3cf9fcd6817c8457c8ef9c8766b71117e53392a8c24', 'bytes_without': len(blk) - 1, 'sha256_without': sha(blk[:-1]), 'expected_without': '588f37a0adcacd1a3150846a98e067a12713c63f59c4657712ab34c3191105a3'}
                ok &= sha(blk) == '0db65928574b3702be16b3cf9fcd6817c8457c8ef9c8766b71117e53392a8c24' and sha(blk[:-1]) == '588f37a0adcacd1a3150846a98e067a12713c63f59c4657712ab34c3191105a3'
            e['legs'] = r['legs']; e['inspection_extent'] = 'CURRENT v0.8.4 SECTION READ AND HASHED; obligation phrases located; v0.8.2/v0.8.3 same section hashed; pinned v0.8 bytes NOT inspected (missing)'
        e['ok'] = ok; all_ok &= ok; out.append(e)
        lines.append(f"{rec:16s} {n} {key:14s} {str(mrow.get('lines')):12s} {'HELD ' if r.get('held_lines') else 'MISSING v0.8; current v0.8.4 ' + r['sec']:34s} {'OK' if ok else 'FAIL'}  {r['proposal'].split(' ')[0]}")
    rep = {'_about': 'RER gap-reference audit, Phase B batch (preparer: Claude, RER co-owner; PREPARER_ROLE; NONCANONICAL). 13 GAP_REFERENCE rows + 2 RECORD_IMPORT uses of the v0.8 pin. Proposals are preparer proposals for the receiving review (L2); no RER text is changed here; no old-to-current equality is claimed for v0.8 pins.',
           'source_identities': {k: (sha(B[k]) if B[k] else None) for k in FILES}, 'rows': out, 'summary': {'rows': len(out), 'ok': sum(1 for e in out if e['ok']), 'held_pins': sum(1 for r in ROWS if r.get('held_lines')), 'missing_v0_8_pins': sum(1 for r in ROWS if not r.get('held_lines'))}}
    return rep, '\n'.join(lines) + '\n', all_ok
if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == '--controls':
        C = [('G9/1 W3 quote altered in RER text', ('block', ('RER', 'in the **same** cohomology space, so that'))),
             ('RECOG pinned §6.16g W1 phrase altered', ('block', ('RECOG', 'coefficient module and edge cochain $a$ with a registered realization'))), ('RECOG pinned §6.6a conjugacy identity altered', ('block', ('RECOG', '$$S\\circ T_k\\circ S=T_{-k}\\qquad\\text{exactly'))),
             ('ER01 pinned C15 model-B heading altered', ('block', ('ER01', 'B — new normalized-addition model'))),
             ('v0.8.4 §6.3 W3 same-space phrase removed', ('current', 'in the **same** cohomology space, so that $\\Delta[a]=[a^+]-[a^-]$ is defined')),
             ('v0.8.4 §6.2 clock declaration removed', ('current', 'clock: primitive T / six-step T^6 / other physical update')),
             ('v0.8.4 §8.1 non-import guard removed', ('current', 'not imported as verified RRF scientific theorems or new native profiles')),
             ('v0.8.4 §6.4 proposal filename removed', ('current', 'RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md'))]
        res = []
        for name, m in C:
            _, _, ok = run(mut=m); res.append(not ok); print(f'  control {name}: {"detected (good)" if not ok else "NOT detected (BAD)"}')
        for k in ('RECOG', 'ER01', 'RRF084'):
            _, _, ok = run(withhold=(k,)); res.append(not ok); print(f'  control source {k} withheld: {"detected (good)" if not ok else "NOT detected (BAD)"}')
        print('controls:', f'{sum(res)}/{len(res)} detected'); sys.exit(0 if all(res) else 1)
    rep, txt, ok = run(); J = (json.dumps(rep, ensure_ascii=False, indent=1) + '\n').encode('utf-8'); T = txt.encode('utf-8')
    md = ['# RER gap-reference audit — 13 GAP_REFERENCE rows + 2 RRF v0.8 record uses (Phase B batch, 21 Oct 2026)', '', 'PREPARER_ROLE; NONCANONICAL. Proposals are for the receiving review (L2). No RER text is changed here; no old-to-current byte equality is claimed for the RRF v0.8 pins (original bytes NOT_FOUND_IN_SEARCHED_SNAPSHOT, receiver 21 Oct 2026).', '',
          '| Row | Pin (version; lines) | Pinned bytes | Checked here | Current v0.8.4 block (lines; sha) | Legs | Proposal (PREPARER) |', '|---|---|---|---|---|---|---|']
    for e in rep['rows']:
        r = e['row']; c = e['checks']; held = isinstance(c.get('pinned_block'), dict)
        chk = ('quotes located: %d/%d' % (sum(c['quotes_in_pinned_block'].values()), len(c['quotes_in_pinned_block']))) if held else ('obligations located: %d/%d' % (sum(c['obligations_in_v0_8_4'].values()), len(c['obligations_in_v0_8_4'])))
        cur = '—' if held else ('%s–%s; `%s…`' % (c['current_blocks']['RRF084']['lines'][0], c['current_blocks']['RRF084']['lines'][1], c['current_blocks']['RRF084']['sha256'][:8]))
        legs = '—' if held else ('; '.join(f'{k} {v}' for k, v in c.get('legs_computed_here', {}).items()) + ' (computed here)')
        md.append(f"| {r['record']}/{r['n']} `{r['key']}` | v{r['cited_version']}; {r['lines'][0]}–{r['lines'][1]} | {'HELD, hashed' if held else 'MISSING'} | {chk} | {cur} | {legs} | {e['proposal_PREPARER']} |")
    md += ['', '## Reliance and legs (per row)', '']
    for e in rep['rows']:
        r = e['row']; md += [f"**{r['record']}/{r['n']} `{r['key']}`** — RER relies on: {e['rer_reliance']}" + (f"  \nLegs: {e['legs']}" if 'legs' in e else '') + f"  \nInspection extent: {e.get('inspection_extent', '')}", '']
    md += ['', f"Summary: {rep['summary']['rows']} rows; {rep['summary']['held_pins']} pins held and read; {rep['summary']['missing_v0_8_pins']} v0.8 pins missing (current v0.8.4 section read instead); all located checks hold: {ok}.", '']
    MD = '\n'.join(md).encode('utf-8')
    if a and a[0] == '--check':
        same = (OUT / 'gap_reference_audit.json').read_bytes() == J and (OUT / 'audit_output.txt').read_bytes() == T and (OUT / 'GAP_REFERENCE_AUDIT.md').read_bytes() == MD
        print(txt, end=''); print('stored outputs byte-identical:', same); sys.exit(0 if ok and same else 1)
    OUT.mkdir(exist_ok=True); (OUT / 'gap_reference_audit.json').write_bytes(J); (OUT / 'audit_output.txt').write_bytes(T); (OUT / 'GAP_REFERENCE_AUDIT.md').write_bytes(MD)
    print(txt, end=''); print('RESULT:', 'all identities match and all located checks hold' if ok else 'a check FAILED'); sys.exit(0 if ok else 1)
