# RER Phase B batch — single integrated review package (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE (Claude, RER co-owner / preparer). NONCANONICAL. This package is the one delivery authorized by the receiving co-owner's Fast-Track decision of 21 Oct 2026 (`receipts/FAST_TRACK_DECISION_20261021.md`, §6): 13-row reference audit, source-gap dispositions, the integrated RER r4.14 DRAFT with its readable change record/diff, the twenty-record disposition table, the unchanged baseline pin, the delta contract and its test output, and one Phase A generation. Nothing here is an acceptance, adoption, freeze or release; every disposition the preparer writes is labelled a proposal. **RER stays r4.13 DRAFT and Phase A r20 ACCEPT SCOPED until the receiving review decides on r4.14 / r21.**

## Contents and identities

| Section | What | Replay |
|---|---|---|
| `audit/` | **13-row gap-reference audit** (+2 record uses of the v0.8 pin): `gap_reference_audit.py`, outputs `out/GAP_REFERENCE_AUDIT.md`, `out/gap_reference_audit.json` (`5cffa026…`), `out/audit_output.txt`; held sources in `sources/` (RECOG v0.3.20, ER-2B v0.1, RRF v0.8.2/v0.8.3/v0.8.4, RER r4.13, r20 matrix) | `python -I -B gap_reference_audit.py --check` (exit 0); `--controls` (11/11 detected) |
| `dispositions/` | **Twenty-record disposition / coverage table** (`out/DISPOSITION_TABLE_20_RECORDS.md/.json`; receiver decisions quoted with receipt hashes; 17 REVIEWED_SCOPED*, 2 BLOCKED_SOURCE_UNVERIFIED, 1 BATCH_REVIEW_ITEM); **missing-source dispositions** (`MISSING_SOURCE_DISPOSITIONS_20261021.md`: RRF v0.8, G2 v0.4 §5b, ER-2B v0.2 study/evidence ZIP, Q7 ZIP, RRF coincidence files, closure-proposal file — NOT_FOUND_IN_SEARCHED_SNAPSHOT; blocks kept) | `python -I -B make_disposition_table.py --check` |
| `k3_econjugacy/` | **RER-GEN-K3-MODAL E-conjugacy review packet**: the RER-native transport step stated for independent review; `TRIAD_EC_PY` / `TRIAD_SB_PY` (+ dependency) executed here (PREPARER_ROLE): outputs byte-identical to the logs cited in RER §7 (`607eca6c…8e66`, `74e05255…7e7b`); Burnside negative control exits 1 | `python -I -B triad_k3_econjugacy_check.py`; `python -I -B triad_six_step_factor_burnside_check.py [--control]` |
| `rer_r4_14/` | **RER v0.2 DRAFT r4.14** `92f983e64bd54e208898954c45c4ac6482928b794d08b3d1660f0db9d00ff044` (on the exact r4.13 bytes; 17 exact-once edits; 85-line diff `r4_13_to_r4_14_DRAFT.diff`); package `RER_r4_14.zip` `f86616f8f8aee3bee763825f1adfd4e6c9ba31a896b628fbbd24dc89d622179e` (= r4.13 package + r4.14 files + the held RRF v0.8.4 source); change record | inside the zip: `python -I -B build_r4_14_draft.py`; `python -I -B check_r4_14_draft.py --controls` (11/11 gates; 12 controls) |
| `phaseA_r21/` | **Phase A r21** on r4.14: `RER_phaseA_r21.zip` `3eb4e137e2bff871035da0acae999b0eff9838f30bb79b127b54850f214b62e1` (191 files); change record; `delta_contract_r21.json` (`9cefb944…`), `baseline_r20.json` (`0a2ef86c…`, r20 `adfedefd…3abc` pinned unchanged); the rendered matrix | inside the zip: `python -I -B build_phaseA.py`; `python -I -B check_phaseA.py --tamper` (36/36 gates; 211 controls; exit 0) |
| `receipts/` | the receiver decisions this batch relies on (B-01 … B-08, r4.7/B-05 follow-up, Phase A r20, Fast-Track decision + evidence), hashed in the disposition table | — |

## What the receiver is asked to decide (L2, one review)

1. **13 historical gap references** — per-reference dispositions (`audit/out/GAP_REFERENCE_AUDIT.md`): G8/0, G9/0, G9/1 audited at the held pins (quotes/RIDs located; proposal AUDITED_AT_PIN); the 10 RRF v0.8 uses read against the current v0.8.4 sections (route (b)+(c)).
2. **10 + 2 current RRF v0.8.4 references** added in r4.14 beside the historical pins (`RRF084`) — accept, narrow or reject each; the historical pins are untouched either way; no v0.8 → v0.8.4 equality is claimed. G10/1 (§6.4): pointer only; closure-proposal file not held (evidence limitation).
3. **G10 current/history clarification** and the G9 / §7 source notes (byte verification r19/r20; W3 owner-scope wording).
4. **RER-GEN-K3-MODAL E-conjugacy transport step** — the only one of the 20 records without an independent receipt (`k3_econjugacy/`).
5. **Twenty-record table** — confirm coverage; ER-2B records stay BLOCKED; G2 §5b stays OPEN/BLOCKED; Stage-2 certificate OPEN (not a blanket adoption prerequisite per the receiver).
6. **Phase A r21** — the machine image of the above (103 rows; 43/2/52/6; 74/4/24/1; baseline + delta contract).

After the review: corrections, if any, go into the same r4.14 target (no micro-revision cycle); the PI's adoption-scope decision is separate.

## Determinism / replay notes

All scripts run with `python -I -B`; outputs were regenerated in clean extractions and are byte-identical; no bytecode caches are packaged; each zip's `SHA256SUMS.txt` excludes only its own root path (nested historical manifests are listed). The r2 tooling note OSC2-T1 does not recur: the new negative controls report only whether the named gate fails.
