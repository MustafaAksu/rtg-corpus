# RER r4.14-L1 / Phase A r21-L1 — focused receiving review

**Date:** 21 October 2026.  
**Role:** receiving co-owner; SESSION, NONCANONICAL receiving decision.  
**Decision:** **L1 FINALIZATION ACCEPTED — exact object ready for the separate PI adoption-scope decision.**  
**Boundary:** No adoption, freeze, publication or new mathematical certification is performed by this review.

## 1. Scope and decision

[SESSION: receiving decision] BATCH-L1-01 through BATCH-L1-05 are CLOSED at their authorized mechanical/editorial scope. RER r4.14-L1 and Phase A r21-L1 are ACCEPT SCOPED as the finalized draft and its machine image. No further correction or review cycle is requested. There is no need for r4.15 or r22 solely to finish this set.

[SESSION: review boundary] This review checks the exact allowed delta against the original submitted batch and the original receiver handoff. The preceding scientific/source acceptance, including K3 transport, remains the basis of the scientific disposition. Owner proofs, K3 computations, Stage-2 calculations and previous scientific certificates were not rerun. This is not a new unlimited guarantee for all scientific claims.

## 2. Exact object identities

[SESSION: computed here]

| Object | SHA-256 |
|---|---|
| Submitted L1 outer ZIP | `3ec3dbae6de96dccd19ae17c70d61483f510669e456dd409ec7c1be68c0a5899` |
| **RER r4.14-L1 Markdown** | `032f2211229ab55d6f5f2477f19b75bb29c55a32d7574682be514b18ae0070d3` |
| RER r4.14-L1 nested ZIP | `ca931651e8f8c6500e4ba0f2807a84981310e1246c048af341172248f8385e1d` |
| **Phase A r21-L1 nested ZIP** | `076fd118820996513d4367de001a58b6a2bf7c4e4dace5db0b90cdff984ed274` |
| Registry JSON | `a616d231fc7017c00a7c7e05f5274070b2ffa6e38bef70be19d1a161040c7415` |
| Source-currency matrix JSON | `650975aaa83e62fbde0b4448f14bf6e6193f991b0eb040a0124b5adc5fc885be` |
| Twenty-record disposition JSON | `1b1f8355140c40dca094dc208825fb40316286bfe91697715cd9410a6241bda6` |

[SESSION: verified comparison inputs] The original batch is `08c132773bd2ec73bd8fac2445741bc20d11e7f81aee50d1f680c0eb8b4c5786`; its candidate is `92f983e64bd54e208898954c45c4ac6482928b794d08b3d1660f0db9d00ff044`; its r21 ZIP is `3eb4e137e2bff871035da0acae999b0eff9838f30bb79b127b54850f214b62e1`. The r20 baseline ZIP remains `adfedefde08cd44294b5b8c2411c353268700739427579f342447d094f813abc`. These are distinct historical objects, not overwritten versions of the L1 objects.

## 3. Focused execution and identity checks

[SESSION: executed here] One clean extraction, using `python -I -B`:

| Check | Result |
|---|---|
| Outer manifest | **52/52 PASS**, before and after |
| RER nested manifest | **124/124 PASS**, before and after |
| Phase A nested manifest | **206/206 PASS**, before and after |
| RER deterministic build | Exact expected Markdown hash |
| RER focused checker | **8/8 gates; 7/7 negative controls detected** |
| Phase A deterministic build | All five stored outputs byte-identical |
| Phase A main checker | **37/37 gates PASS**, including A37 |
| Disposition-table checker | JSON and Markdown byte-identical |
| Independent allowed-delta audit | **32/32 grouped identity/scope checks PASS** |
| Independent focused delta negative controls | **10/10 detected** |
| Separately uploaded README, finalization record and table | 3/3 identical to package copies |
| Unlisted payload / Python cache | None |

[SESSION: execution qualification] The supplied Phase A **221-control** negative suite was **not rerun**. Its stored log is authenticated as a preparer execution record. The receiver ran the 37 main gates and ten independent delta-focused sensitivity tests instead. The RER eight-gate/seven-control log matches the stored combined log exactly; the Phase A main-gate output matches the prefix of the stored main-plus-controls log. No claim of receiver 221/221 replay is made.

[SESSION: implementation boundary] `independent_l1_scope.py` imports no preparer parser, builder, checker or patch. It directly compares bytes and JSON against the originally uploaded batch and original receiver archive. Its checks concern identities and permitted changes, not scientific theorem correctness. Its optional-sidecar-field handling was adjusted during implementation; this was a receiver test implementation issue, not a submission finding.

## 4. Five L1 items

[SESSION: independently compared here]

| Item | Disposition and evidence |
|---|---|
| **01 title/date** | CLOSED. Header identifies DRAFT r4.14 and the date list names r4.14. The distinct L1 object identity is explicit. |
| **02 reference count** | CLOSED. Status, queue and history use **12 = 10 gap references + 2 record imports**. No Reference/import line was added, removed or repinned. |
| **03 attribution table** | CLOSED. `(d) conditional` belongs to BIRTH-GRAPH only. The preparer-authored r2 contributor review is distinguished from the separate FORMAL structural note; no new author identity authentication is claimed. Compiled decisions are labelled summaries. |
| **04 K3 typing** | CLOSED. Scalar E0/P0, block E-bar/P-bar and W-frame E_W are distinguished with the authorized domains and dimensions. The scripts and calculation logs remain byte-identical to the original batch. No RER formula changes. |
| **05 receipt/sidecar** | CLOSED. K3 receiving receipt is appended, not substituted. Coverage is 18 scoped + 2 blocked. Exactly 27 reference decisions are attached separately from their preserved pre-review fields. |

[SESSION: independent byte delta] Eight exact-once replacements reproduce the final Markdown; reversing them recovers the submitted candidate byte-for-byte. Exactly six source lines differ (1, 4, 7, 867, 1157, 1162): title, date, status, K3 Review receipt, the r4.14 queue row and its history entry. Scientific claim lines outside the authorized history entry and all Reference/import lines are unchanged. The supplied checker also verifies the r4.13 + 17-edit -> original candidate chain.

[SESSION: independent registry delta] Nineteen of the twenty record objects are identical. Only K3's `fields.Review receipt` and its `prior_review_receipt` copy change, append-only. Grades, exactness, tasks, contracts, claim lines, imports, OPEN items and adoption fields remain unchanged. Four gap entries, source table and legacy material are unchanged. All 20 adoption fields still read PENDING.

## 5. Reference decisions: current use is not old-byte authentication

[SESSION: independently compared here] The original receiver sidecar and review, not only their embedded hashes, were compared with the prior receiver handoff. The reference sidecar SHA-256 is `3536c2079ca905318d1d06fab24a08c7cb3e3ef1e4a2e376531932f7471ab78d`; the prior receiving review is `bd80f89de36cc5f7df744a23dbdbd122bf783df8de53d104f941504dc36b07fd`. They are unchanged.

[SESSION: computed here] All **103** row identities and all prior row fields are preserved. The sole row-level addition is `receiving_disposition_20261021`, on exactly the 27 intended rows. Disposition, scientific-use and boundary text agree with the original receiving sidecar:

| Receiving disposition | Rows |
|---|---:|
| AUDITED_AT_PIN | 3 |
| HISTORICAL_PIN_SOURCE_UNVERIFIED | 12 |
| ACCEPT_SCOPED_CURRENT_REFERENCE | 10 |
| ACCEPT_SCOPED_CONTEXT_ONLY | 1 |
| ACCEPT_SCOPED_POINTER_ONLY | 1 |
| **Total** | **27** |

[SESSION: receiving interpretation] G9/1 owner-W3 fidelity and G9/3 current-use clarification remain accepted as previously decided. Original v0.8 authentication remains unavailable. Old PENDING/PROPOSED and `preparer_audit` fields are retained as dated pre-review history, not as a competing current decision. ER2B-CARRIER's contextual RRF reference does not unblock its scientific payload. G10's pointer-only reference does not authenticate or review the missing closure-proposal text.

[SESSION: computed here] Counts remain **43 VERIFIED / 2 OWNER_REPORTED / 52 HISTORICAL / 6 BLOCKED**, and **74 BYTE_VERIFIED_HERE / 4 RECEIVER_BYTE_VERIFIED / 24 HASH_PRINTED_UNVERIFIED / 1 UNAUTHENTICATED_NO_HASH**. Owner scientific identities, SYNC disposition and blocked-source content are unchanged. Expected source/schema/check-date/watch-item metadata accompanies the L1 object. All six retained r21 output/log files match the original r21 ZIP. The audit directory and K3 scripts/logs remain unchanged.

## 6. Adoption readiness, not adoption

[SESSION: receiving decision] There is **no remaining L1 finalization obstacle** in this submission. The exact r4.14-L1/r21-L1 pair may now be put to the PI for a separate explicit adoption-scope decision. No new scientific review or mechanical micro-revision is requested solely for these five items.

[SESSION: scoped recommendation] The proposed adoption object is a registry containing **18 scoped reviewed scientific payloads**, plus **two ER-2B records explicitly excluded from scientific acceptance and retained as BLOCKED_SOURCE_UNVERIFIED**. Source limits (including missing historic RRF v0.8 bytes, closure proposal, HARM/ANGLE_DATA/RANKDATA, and the prior replay/owner-proof limitations) remain visible and are not waived by this decision.

[SESSION: scope boundary] Stage-2 regional/global certification and multi-step errors, G6, all-order graph completion/realization, G2 carrier identification and physical realization remain at their prior OPEN/BLOCKED scopes. No assertion that all 20 payloads or all historical archives are verified is authorized.

[SESSION: final status] **RER r4.14-L1 DRAFT — L1 FINALIZATION ACCEPTED. Phase A r21-L1 — ACCEPT SCOPED. PI ADOPTION DECISION PENDING.** The original candidate, r21 and r20 remain history. This receiving decision does not authorize a release conversion or publish/adopt any owner result.
