# RER Phase A — v0.2 release pin (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE. This is the Phase A image of the **adopted** `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2.md` (SHA-256 `58feee5ff1f16a37fc4ee029f24499928ea7439731de0a090d8794c1cbe57ad0`; metadata-only release of DRAFT r4.14-L1 `032f2211…70d3`; release package `RER_v0_2_RELEASE.zip` `6b544e7173f51153819ce3e6e9e92c7a5f65613d7749c98d94a893b334b8b080`) after the PI adoption-scope decision recorded in `inputs/RER_v0_2_ADOPTION_RECORD_20261021.md`. It is the machine pin of the adopted object; it adds no review, grade or acceptance of its own.

**What changes vs the r21-L1 image (gate A38 enforces exactly this):** the source identity; the registry `adoption_status` of every record — 18 `ADOPTED_SCOPED` (scoped, reviewed scientific payloads at their stated scopes and declared limits) and 2 `EXCLUDED_BLOCKED` (RER-ER2B-T6D, RER-ER2B-CARRIER: retained as BLOCKED_SOURCE_UNVERIFIED, excluded from scientific acceptance) — with an `adoption_record` reference on each record (the record-level text "Registry/owner adoption: pending" is the preserved pre-adoption wording); schema labels `…/v0.2-RELEASE`; one watch item; the catalog check label. **Everything else is identical**: the 103 matrix rows (43/2/52/6; 74/4/24/1), the receiver reference dispositions, the SYNC receipt, owner_current, the blocked register, gap entries, source table, all claim lines and grades.

**Checker.** 38 gates PASS (A9 re-based to the adoption scope; A24 release source; A25/A28/A35/A37 chains extended; new A38 release identity, including the body check: the adopted file equals r4.14-L1 except header lines 1, 4, 7, 8); 230 negative controls (176 tampers + 54 file/input), each fails its named gate — including: an excluded record marked adopted, an adopted record left PENDING, unscoped "ADOPTED", adoption-record reference dropped, pre-adoption text rewritten, adoption scope JSON or record altered, source recorded as the basis, release package hash altered, row / disposition / claim / gap / blocked changes vs the r21-L1 image.

```
unzip RER_phaseA_v0_2_RELEASE.zip && cd RER_phaseA_v0_2_RELEASE
sha256sum -c SHA256SUMS.txt
python -I -B build_phaseA.py          # out/* byte-identical
python -I -B check_phaseA.py --tamper # 38/38 PASS, 230 controls, exit 0
```

History kept in the package: r20 baseline pin, r21 and r21-L1 outputs and checker records, the submitted r4.14 candidate and r4.14-L1 texts, all receiver receipts.
