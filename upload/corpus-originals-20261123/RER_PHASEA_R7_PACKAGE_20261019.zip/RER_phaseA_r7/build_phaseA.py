"""RER Phase A r7 builder (deterministic). Inputs: exact r4.6 Markdown (r4.5 + RRF editor Q1-Q8 implementation), two preparer catalogs, the r4.4 package manifest and
sources_available/. Outputs in out/: registry JSON, source-currency matrix (JSON+MD), blocked-source register (JSON+MD).
No Markdown is edited; no grade, status or owner is changed."""
import sys, os, re, json, hashlib, urllib.parse
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, 'tools')); import rer_parse as P
MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md'
MD_SHA = '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'
R46_ZIP_SHA = 'b2dfc9e26faf4e3988b69e7bd8c7b49cf66b3961cdea3e950b11d342da954477'
R45_ZIP_SHA = 'da62edd14b4ca1d6a279ac7aefa3fd9b806109b3de8be9fe5b21e349ed563324'
BASE_R44_SHA = '5df4738685ecebf979da4f48d432ef2f9af01b6964dfefb62d7ac31887caa9d8'
sha = lambda b: hashlib.sha256(b).hexdigest()
def rd(p): return open(os.path.join(HERE, p), 'rb').read()
def dump(o): return (json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n').encode('utf-8')

def structured_lines(r):
    """Every record line that a structured JSON field reproduces verbatim."""
    out = set(filter(None, [r.get('primary_grade_line')]))
    out |= {'| Field | Contract |', '|---|---|'} | {f"| {k} | {v} |" for k, v in r['contract'].items() if v is not None}
    out |= set(r['claim_lines']) | {'[OPEN] ' + o for o in r['open_items']} | {i['line'] for i in r['imports']}
    out |= {f"**{k}:** {v}" for k, v in r['fields'].items() if v is not None}
    out |= {f"**Missing primary input:** `{m}`" for m in r['missing_primary_inputs']}
    return out

def status_of(x):
    """Receiver vocabulary (decision record III.2): VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED."""
    c, b = x['currency'], x['bytes_status']
    if c == 'BLOCKED': return 'BLOCKED'
    if b == 'BYTE_VERIFIED_MATCH' and c in ('UNCHANGED_VERIFIED', 'CURRENT', 'ARTIFACT_PINNED'): return 'VERIFIED'
    if c in ('CURRENT', 'UNCHANGED_OWNER_REPORTED'): return 'OWNER_REPORTED'
    return 'HISTORICAL'

def build():
    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.6 hash mismatch'
    md = mdb.decode('utf-8')
    CS = json.loads(rd('catalog_sources.json')); CR = json.loads(rd('catalog_records.json'))
    man = lambda f: set(l.split('  ', 1)[1].strip() for l in rd(f).decode().splitlines() if '  ' in l)
    pkg = man('inputs/r4_4_package_SHA256SUMS.txt'); pkg4 = man('inputs/r4_package_SHA256SUMS.txt'); pkg45 = man('inputs/r4_5_package_SHA256SUMS.txt'); pkg46 = man('inputs/r4_6_package_SHA256SUMS.txt')
    avail = {}
    for f in sorted(os.listdir(os.path.join(HERE, 'sources_available'))):
        k, base = f.split('__', 1); avail[k] = (f, sha(rd('sources_available/' + f)))
    st = P.source_table(md)
    blocks = P.blocks(md)
    recs, gaps = [], []
    for rid, title, body in blocks:
        if rid in P.GAPS:
            refs = [P.parse_import('Import/reference:' + l[len('Reference:'):]) for l in body.splitlines() if l.startswith('Reference:')]
            for q, l in zip(refs, [l for l in body.splitlines() if l.startswith('Reference:')]): q['raw'] = l; q['line'] = l
            gaps.append({'id': rid, 'title': title, 'text_sha256': sha(body.strip().encode()), 'references': refs}); continue
        r = P.parse_record(rid, title, body); c = CR['records'][rid]
        r.update({'cohort': c['cohort'], 'owner_family': c['owner_family'], 'claim_provenance': c['provenance'],
                  'phaseB_route': c['phaseB_route'], 'adoption_status': 'PENDING',
                  'phaseA_status': 'BLOCKED_SOURCE_UNVERIFIED' if c.get('blocked') else 'ACTIVE',
                  'accepted_cohort_eligible': not c.get('blocked', False),
                  'grade_status': 'SOURCE_CLAIMED_NOT_RER_ADOPTED' if c.get('blocked') else 'AS_REGISTERED_PENDING_PHASE_B',
                  'prior_review_receipt': r['fields']['Review receipt'] or 'NO_IN_RECORD_RECEIPT'})
        for extra in ('provenance_note', 'author_conflict'):
            if extra in c: r[extra] = c[extra]
        for i in r['imports']: i['line'] = i.pop('raw', None)
        r['primary_grade_line'] = next((l for l in body.splitlines() if l.startswith('**Primary grade:**')), None)
        struct = structured_lines(r)
        r['unclassified_lines'] = [l for l in body.splitlines() if l.strip() and l not in struct and not l.startswith('<a id=')]  # anchor lines belong to the next record
        recs.append(r)
    # ---- currency matrix
    rows = []
    v16 = rd('sources_available/' + avail['TRIAD'][0]).decode('utf-8').split('\n') if 'TRIAD' in avail else None
    v161 = rd('sources_available/' + avail['TRIAD161'][0]).decode('utf-8') if 'TRIAD161' in avail else None
    units = [(r['id'], 'RECORD_IMPORT', r['imports']) for r in recs] + [(g['id'], 'GAP_REFERENCE', g['references']) for g in gaps]
    for rid_, kind, imps in units:
        for n, i in enumerate(imps):
            k = i['key']; row_st = st.get(k) or {}
            cited = i['cited_sha256'] or row_st.get('sha256')
            hash_origin = 'IMPORT_LINE' if i['cited_sha256'] else ('SOURCE_TABLE' if row_st.get('sha256') else 'NONE')
            if kind == 'GAP_REFERENCE' and k in CS.get('gap_reference_overrides', {}): cat = dict(CS['gap_reference_overrides'][k])
            elif k in CS['keys']: cat = dict(CS['keys'][k])
            elif k in CS['snapshot_keys']: cat = dict(CS['snapshot_rule'], owner='(study snapshot)', cited_version=row_st.get('description', '').split(';')[0])
            else: cat = dict(CS['artifact_rule'], owner='(artifact)', cited_version=row_st.get('description', '').split(';')[0] or 'artifact')
            own = CS['owner_current'].get(cat.get('owner'), {})
            path = urllib.parse.unquote(i['path'])
            if k in avail:
                bytes_status = 'BYTE_VERIFIED_MATCH' if cited and avail[k][1] == cited else 'BYTE_MISMATCH'
            else:
                bytes_status = 'PRINTED_ONLY' if cited else 'NO_HASH_PRINTED'
            currency, reason = cat['rule'], cat.get('reason', '')
            if cat['rule'] == 'LINE_RANGE_VERBATIM':
                ok = bool(v16 and v161 and i['lines'] and '\n'.join(v16[i['lines'][0]-1:i['lines'][1]]) in v161)
                currency = 'UNCHANGED_VERIFIED' if ok else 'RECHECK_IN_PHASE_B'
                reason = f"lines {i['lines']} of v1.6 {'appear verbatim' if ok else 'do not appear verbatim'} in v1.6.1 bytes"
            if cat['rule'] == 'CURRENT' and own and own.get('sha256') and cited and cited != own['sha256']:
                currency, reason = 'RECHECK_IN_PHASE_B', 'cited hash differs from current owner hash'
            rows.append({'record': rid_, 'row_kind': kind, 'n': n, 'key': k, 'source_doc': os.path.basename(path) if path else None,
                'source_family': cat['family'], 'owner': cat.get('owner'), 'section_or_RID': (i['section'] + (f" | RID: {i['rid']}" if i['rid'] and i['rid'] != 'unavailable' else '')),
                'lines': i['lines'], 'cited_version': cat.get('cited_version'), 'cited_sha256': cited, 'cited_hash_origin': hash_origin,
                'current_owner_version': own.get('version'), 'current_owner_sha256': own.get('sha256'), 'current_owner_evidence': own.get('evidence'),
                'bytes_status': bytes_status, 'available_file': ('sources_available/' + avail[k][0]) if k in avail else None,
                'path_in_r4_4_package': path in pkg, 'path_in_r4_package': path in pkg4, 'path_in_r4_5_package': path in pkg45, 'path_in_r4_6_package': path in pkg46, 'cited_path': path,
                'inspection_extent': 'FULL_FILE_HASH' if k in avail else ('SECTION_RANGE' if i['lines'] else 'REFERENCE_ONLY'),
                'currency': currency, 'currency_reason': reason, 'reviewer_disposition': 'PENDING'})
            x = rows[-1]
            x['verified_current_hash'] = own.get('sha256') if own.get('evidence') in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER') else None
            x['status'] = status_of(x)
            x['authentication'] = ('BYTE_VERIFIED_HERE' if bytes_status == 'BYTE_VERIFIED_MATCH' else 'RECEIVER_BYTE_VERIFIED' if cat.get('receiver_byte_verified')
                                   else 'HASH_PRINTED_UNVERIFIED' if cited else 'UNAUTHENTICATED_NO_HASH')
            for f in ('receiver_note', 'receiver_section_check'):
                if cat.get(f): x[f] = cat[f]
            if kind == 'GAP_REFERENCE':
                x['interface_questions'] = 'EDITOR_DISPOSITION_RECEIVED (RRF editor response v0.2, 413a869b…3084; Q1–Q8 implemented in r4.6)'
                x['gap_reference_review'] = 'PENDING_PER_REFERENCE_AUDIT'
                x['gap_reference_review_note'] = 'The editor answered Q1–Q8 on packet excerpts only and did not audit each reference line. Remaining: a per-reference source/currency check of this line against RRF v0.8.3 (receiving co-owner); the editor is consulted again only if a reference turns out CHANGED-SCOPE beyond Q1–Q8.'
                if k == 'RRF08_ADOPTED' and i['section'].startswith('6.4'):
                    x['currency_reason'] += ' Section-specific: from v0.8.1 on, the v0.8 §6.4 content is the separate noncanonical proposal RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md and v0.8.3 §6.4 is a non-normative pointer; not a same-section repin (RRF packet Q3).'
    # ---- blocked register
    blocked = []
    bysrc = {}
    for r in recs:
        for m in r['missing_primary_inputs']:
            b = bysrc.setdefault(m, {'source': m, 'records': [], 'kind': 'MISSING_PRIMARY_INPUT', 'blocked_records': []})
            b['records'].append(r['id'])
            if r['phaseA_status'] == 'BLOCKED_SOURCE_UNVERIFIED': b['blocked_records'].append(r['id'])
    for k, v in sorted(st.items()):
        if 'Direct source not available' in v['description']:
            src = re.findall(r'`([^`]+)`', v['row'])[1]
            b = bysrc.setdefault(src, {'source': src, 'records': [], 'kind': 'SOURCE_TABLE_NOT_AVAILABLE', 'blocked_records': []})
            b['source_table_key'] = k
    er = bysrc['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']
    er['records'] += ['RER-ER2B-T6D', 'RER-ER2B-CARRIER']; er['blocked_records'] += ['RER-ER2B-T6D', 'RER-ER2B-CARRIER']
    er['note'] = 'Primary v0.2 package not available to preparer or receiver. ER-2B consolidated v0.3 (80669c69…, NONCANONICAL) reports the package identity RTG_ER2B_CONSOLIDATED_v0_2.zip 8c635290…48ee and v0.2 study ea26d3d1…5e (source-reported, not verified here); v0.3 is background only and does not unblock (receiver D-2). Unblocking needs the package bytes and, if required, an ER-2B custodian decision.'
    for src in ('RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md', 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip'):
        bysrc[src]['note'] = 'For RER-RRF-CND01 this blocks only the secondary-report coincidence item (not imported as a theorem); the record\'s [THM] is the RER-native fixed-set implication.'
    for b in bysrc.values():
        m = re.search(r'\*\*Missing primary input:\*\* `' + re.escape(b['source']) + r'`;[^\n]*?SHA-256 `([0-9a-f]{64})` byte-hashed by the RRF editor', md)
        if m: b['rrf_editor_sha256'] = m.group(1); b['source_custody'] = 'RRF_EDITOR_VERIFIED (byte-hashed by the RRF editor; bytes not inspected by RER preparer or receiver; not a certificate replay or physical admissibility)'
        else: b['source_custody'] = 'NO_HASH_KNOWN'
    blocked = list(bysrc.values())
    for b in blocked:
        b['records'] = sorted(set(b['records'])); b['blocked_records'] = sorted(set(b['blocked_records'])); b['blocks_acceptance'] = bool(b['blocked_records'])
    blocked.sort(key=lambda b: b['source'])
    printed = sorted(set(x['key'] for x in rows if x['bytes_status'] in ('PRINTED_ONLY', 'NO_HASH_PRINTED')))
    reg = {'schema': 'RER-REGISTRY-PHASEA/7', 'status': 'NONCANONICAL PHASE A CANDIDATE — not adopted, not frozen',
           'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R46_ZIP_SHA, 'base_r4_5_package_zip_sha256': R45_ZIP_SHA, 'base_r4_4_sha256': BASE_R44_SHA},
           'counts': {'records': len(recs), 'gap_entries': len(gaps), 'legacy_v0_1_entries': len(P.legacy_entries(md))},
           'records': recs, 'gap_entries': gaps,
           'legacy_v0_1_snapshot': {'label': 'HISTORICAL_SNAPSHOT_NOT_AN_ADOPTION_COHORT', 'entries': P.legacy_entries(md)},
           'source_table': {k: {kk: vv for kk, vv in v.items() if kk != 'row'} for k, v in st.items()}}
    KV = json.loads(rd('inputs/owner_versions_known.json'))
    cm = {'schema': 'RER-SOURCE-CURRENCY/7', 'source_markdown_sha256': MD_SHA, 'owner_current': CS['owner_current'], 'rows': rows,
          'owner_catalog': {'checked': KV['_catalog_checked'], 'scope': KV['_scope'], 'source_authority': KV['_source_authority']},
          'bytes_not_available_to_preparer': printed,
          'watch_items': ['Genesis v2.8.9 ADOPTED 19 Oct 2026 (d143673e…c6fc, owner-reported): new §6.3c GEN-THM-TRANSPORTED-CHIRAL-FACTOR-NOGO (six-step, real C^3 third-jet class, mu != 0, H_spec); §6.3a–§6.3b unchanged per its draft record. Relevance to RER-GEN-K3-MODAL / G6 is a Phase B item; RER pins stay on v2.8.7.',
                          'OFN v0.10 ADOPTED 19 Oct 2026 (acb70a8c…5dfa, owner-reported; bytes not hashed here). Supersedes v0.9 (5ae8fdab…9795, receiver-hashed). RER OFN pins stay on v0.9 (§8, §12.4) and are marked RECHECK_IN_PHASE_B. OFN v0.10 §11.4 IMP-O10-01/02 consume Genesis v2.8.9 §6.3c: CONSUMER_CHECK_PENDING (Phase B-01; needs a direct reading of OFN v0.10).',
                          'RECOG v0.3.20 is a freeze candidate in its own header; the catalog records it as the latest known version, not as adopted or frozen.',
                          'Dyadic v6.4.16 ADOPTED 19 Oct 2026 (33c14c5c…59e0, receiver-hashed): OPEN 3 closed within its defined scope, OPEN 3c closed as a historical-fit discrepancy, new OPEN 21; OPEN 20 not closed; §§6.15–6.17 byte-identical to v6.4.15 (receiver-reported). RER Dyadic pins stay on v6.4.13.']}
    lost = sorted(set(x['key'] for x in rows if x['path_in_r4_package'] and not x['path_in_r4_4_package']))
    repaired = sorted(set(x['key'] for x in rows if x['key'] in lost and x['path_in_r4_5_package']))
    br = {'schema': 'RER-BLOCKED-SOURCES/7', 'source_markdown_sha256': MD_SHA, 'blocked': blocked,
          'packaging_finding': 'Cited evidence files present in the r4 package but not carried into the r4.1–r4.4 packages: ' + ', '.join(lost) + '. Repaired in the r4.5 package, which carries them at their cited paths with their cited hashes: ' + (', '.join(repaired) or 'none') + '.',
          'lost_in_packaging': lost, 'repaired_in_r4_5': repaired, 'carried_in_r4_6': sorted(set(x['key'] for x in rows if x['key'] in lost and x['path_in_r4_6_package'])),
          'byte_availability_gap': {'keys': printed, 'note': 'Phase A r6 correction: the r1–r5 note said these bytes were not in the preparer workspace. That was incomplete: 14 cited files were present in PI-supplied session uploads and are now byte-verified (inputs/source_custody_r6.json). The keys listed here are the ones still without bytes. Not blocking by itself; the receiving side holding the r3.1 package can byte-verify.'}}
    return {'out/RER_REGISTRY_v0_2_r4_6_PHASEA.json': dump(reg), 'out/SOURCE_CURRENCY_MATRIX.json': dump(cm),
            'out/BLOCKED_SOURCE_REGISTER.json': dump(br), 'out/SOURCE_CURRENCY_MATRIX.md': render_matrix(cm, recs),
            'out/BLOCKED_SOURCE_REGISTER.md': render_blocked(br)}

def render_matrix(cm, recs):
    from collections import Counter
    L = ['# RER r4.6 — source-currency matrix (Phase A r7, noncanonical)', '', f"Source: `{MD}` `{MD_SHA}`. Generated by `build_phaseA.py`; the JSON is authoritative.", '',
         '## Current owner versions', '', f"Frozen catalog, checked {cm['owner_catalog']['checked']}. {cm['owner_catalog']['scope']}", '', '| Owner | Current | SHA-256 | Evidence | Note |', '|---|---|---|---|---|']
    for o, v in sorted(cm['owner_current'].items()): L.append(f"| {o} | {v['version']} | `{v['sha256'][:12]}…` | {v['evidence']} | {v['note']}{' Superseded: v' + v['superseded']['version'] + ' `' + v['superseded']['sha256'][:12] + '…`.' if v.get('superseded') else ''} Authority: {cm['owner_catalog']['source_authority'].get(o, '—')}. |")
    L += ['', '## Import rows', '', '| Record / gap | Kind | Key | Family | Cited | Cited hash | Bytes | Authentication | In r4 / r4.4 / r4.5 / r4.6 pkg | Current owner | Verified current hash | Currency | Status |', '|---|---|---|---|---|---|---|---|---|---|---|---|---|']
    for x in cm['rows']:
        yn = lambda b: 'yes' if b else 'no'
        L.append(f"| {x['record']} | {'gap ref' if x['row_kind'] == 'GAP_REFERENCE' else 'import'} | `{x['key']}` | {x['source_family']} | {x['cited_version']} | {(x['cited_sha256'] or '—')[:12]} ({x['cited_hash_origin']}) | {x['bytes_status']} | {x['authentication']} | {yn(x['path_in_r4_package'])} / {yn(x['path_in_r4_4_package'])} / {yn(x['path_in_r4_5_package'])} / {yn(x['path_in_r4_6_package'])} | {x['current_owner_version'] or '—'} | {(x['verified_current_hash'] or '—')[:12]} | {x['currency']} | **{x['status']}** |")
    L += ['', '## Summary', '', f"- Rows: {len(cm['rows'])} = {sum(x['row_kind'] == 'RECORD_IMPORT' for x in cm['rows'])} record imports + {sum(x['row_kind'] == 'GAP_REFERENCE' for x in cm['rows'])} gap references (G7–G10; RRF Q1–Q8 editor disposition received; per-reference audit pending); records: {len(recs)}.",
          '- Authentication: ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['authentication'] for x in cm['rows']).items())) + '. RECEIVER_BYTE_VERIFIED is receiver-reported (Phase A review, 19 Oct), not executed by the preparer.',
          '- Currency: ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['currency'] for x in cm['rows']).items())),
          '- Bytes: ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['bytes_status'] for x in cm['rows']).items())),
          '- Status (receiver vocabulary): ' + ', '.join(f'{k} {v}' for k, v in sorted(Counter(x['status'] for x in cm['rows']).items())),
          '- Field mapping to the receiver list (decision record III.2): cited_hash = `cited_sha256`; verified_current_hash is set only where the current owner file was byte-hashed (preparer or receiver); status maps currency and bytes_status as in `status_of()`.',
          '', '## Watch items', ''] + [f'- {w}' for w in cm['watch_items']]
    return ('\n'.join(L) + '\n').encode('utf-8')

def render_blocked(br):
    L = ['# RER r4.6 — blocked-source register (Phase A r7, noncanonical)', '', '| Source | Kind | Cited by | Blocks acceptance of | Note |', '|---|---|---|---|---|']
    for b in br['blocked']: L.append(f"| `{b['source']}` | {b['kind']}{' (' + b['source_table_key'] + ')' if b.get('source_table_key') else ''} | {', '.join(b['records']) or '—'} | {', '.join(b['blocked_records']) or '—'} | {b.get('note', '')} |")
    L += ['', '## Packaging finding', '', br['packaging_finding']]
    L += ['', '## Byte-availability gap (not blocking)', '', br['byte_availability_gap']['note'], '', ', '.join(f'`{k}`' for k in br['byte_availability_gap']['keys'])]
    return ('\n'.join(L) + '\n').encode('utf-8')

if __name__ == '__main__':
    os.makedirs(os.path.join(HERE, 'out'), exist_ok=True)
    for p, b in build().items():
        open(os.path.join(HERE, p), 'wb').write(b); print(p, sha(b)[:16])
