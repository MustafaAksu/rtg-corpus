"""Phase A r8 -> r9 patch (Dyadic currency evidence only; receiver decision of 20 Oct 2026 after the independent v6.4.16/v6.4.17 section check).
- The PI-supplied v6.4.17 bytes are added to sources_available as DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md.
- A new custody file inputs/source_custody_r9.json records the file. The section-identity check (script and its PASS output) is copied
  under inputs/dyad_v6_4_17_section_check/.
- Dyadic owner_current evidence moves OWNER_REPORTED -> BYTE_VERIFIED. The r8 state is kept as history in the catalog entry.
- A23 now requires: the real file with the expected hash, a matching custody entry, and the PASS section-check record (5/5 IDENTICAL,
  both file hashes MATCH). The DYAD6413 pin stays v6.4.13. A file-level negative control (file withheld) is added.
Exact-once text replacements; catalog JSON edits by key. Args: TARGET_DIR V17_FILE SECTION_CHECK_DIR. Run once on a fresh copy of r8."""
import sys, os, json, shutil, hashlib
D, V17, SC = sys.argv[1], sys.argv[2], sys.argv[3]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:80]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'

D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
D16 = '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'
FN = 'DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md'
assert sha(V17) == D17
shutil.copyfile(V17, os.path.join(D, 'sources_available', FN))
SCD = os.path.join(D, 'inputs', 'dyad_v6_4_17_section_check'); os.makedirs(SCD)
for f in ('dyad_v6_4_16_v6_4_17_section_identity_check.py', 'compare_output.txt', 'negcontrol_output.txt', 'single_v6_4_17_output.txt'):
    shutil.copyfile(os.path.join(SC, f), os.path.join(SCD, f))
out = open(os.path.join(SCD, 'compare_output.txt'), encoding='utf-8').read()
assert out.count('IDENTICAL') == 5 and 'RESULT: PASS' in out and out.count(' MATCH') == 2

open(os.path.join(D, 'inputs/source_custody_r9.json'), 'w').write(dump({
    '_about': 'Phase A r9 custody for the Dyadic v6.4.17 owner file.',
    'files': {FN: {'key': 'DYAD617', 'sha256': D17, 'version': '6.4.17',
                   'container': 'PI upload to the preparer session, 20 Oct 2026 (RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md, 1502 lines); hash equals the v6.4.17 release record (claude/RTG_DYADIC_v6_4_17_RELEASE_RECORD.md)'}},
    'container_chain_status': 'PREPARER_DECLARED: the file hash was computed here and matches the release record; the receiver independently confirmed the same hash on 20 Oct 2026 (section-check review). The upload path is the preparer\'s declaration.',
    'section_check': {'package_r0': 'DYAD_v6_4_17_SECTION_CHECK.zip 56e772ad28b14dd635a0d0f2c1d0f6fe535a038015dc5927035cc3ec3ecd8ca9 (receiver-run: manifest 3/3, 5/5 IDENTICAL, negative control PASS)',
                      'package_r1': 'DYAD_v6_4_17_SECTION_CHECK_r1.zip 6e512651a422b60ce3a3d2617db8669b4707debe65cbb17de98cc023408729a1 (preparer; not uploaded to the receiver)',
                      'v6_4_16_sha256': D16, 'v6_4_17_sha256': D17,
                      'blocks': ['§2 OPEN 19', '§2 OPEN 20', '§6.15', '§6.16', '§6.17'],
                      'result': 'PASS: both file hashes MATCH; 5/5 blocks byte-IDENTICAL (preparer run and independent receiver run)',
                      'files': 'inputs/dyad_v6_4_17_section_check/'}}))

p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
assert KV['Dyadic'] == '6.4.17'
KV['_catalog_checked'] = '2026-10-20 (Phase A r9, preparer)'
KV['_source_authority']['Dyadic'] = ('owner file v6.4.17, byte-verified here (sources_available, inputs/source_custody_r9.json) and its hash independently confirmed by the receiver; '
                                     'release record claude/RTG_DYADIC_v6_4_17_RELEASE_RECORD.md. Superseded v6.4.16 was hashed by the receiving co-owner (Phase A r3 review) and byte-checked here in the section comparison.')
open(p, 'w').write(dump(KV))

p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
d = CS['owner_current']['Dyadic']; assert d['version'] == '6.4.17' and d['sha256'] == D17 and d['evidence'] == 'OWNER_REPORTED'
r8 = {'evidence': d['evidence'], 'note': d['note']}
d['evidence'] = 'BYTE_VERIFIED'
d['note'] = ('adopted 19 Oct 2026 (release record claude/RTG_DYADIC_v6_4_17_RELEASE_RECORD.md). Phase A r9: bytes held in sources_available and hashed here; hash independently confirmed by the receiver (20 Oct 2026). '
             'Per the release record: new DYAD-THM-OPEN21-PRIMITIVE-PHASE-REMAINDER [THM — conditional on RECOG-THM-R9-MEMORY], OPEN 21 CLOSED, notice N13; OPEN 20 unchanged; no RID renamed or regraded.')
d['history'] = {'phaseA_r8': r8}
k = CS['keys']['DYAD6413']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED' and k['cited_version'] == '6.4.13'
k['reason'] += (' Phase A r9: v6.4.16→v6.4.17 byte equality of §2 OPEN 19, §2 OPEN 20, §6.15, §6.16 and §6.17 checked here and independently by the receiver: 5/5 IDENTICAL '
                '(inputs/dyad_v6_4_17_section_check/). With the receiver-reported v6.4.13→v6.4.16 chain, the cited content is unchanged from v6.4.13 to v6.4.17. The rule label is kept; RER pins stay on v6.4.13.')
CS['_about'] += ' Phase A r9 (20 Oct): Dyadic v6.4.17 bytes added (inputs/source_custody_r9.json); Dyadic evidence BYTE_VERIFIED; r8 state kept as history.'
open(p, 'w').write(dump(CS))

rp('build_phaseA.py', [
 ('"""RER Phase A r8 builder', '"""RER Phase A r9 builder'),
 ("'RER-REGISTRY-PHASEA/8'", "'RER-REGISTRY-PHASEA/9'"),
 ("'RER-SOURCE-CURRENCY/8'", "'RER-SOURCE-CURRENCY/9'"),
 ("'RER-BLOCKED-SOURCES/8'", "'RER-BLOCKED-SOURCES/9'"),
 ("byte equality of the cited §§6.15–6.17 in v6.4.17 is checked only when the file is available.']}",
  "byte equality of the cited §§6.15–6.17 in v6.4.17 is checked only when the file is available.',\n"
  "                          'Phase A r9 (20 Oct 2026): Dyadic v6.4.17 bytes held and hashed here (e07cf2b9…4bfc), hash independently confirmed by the receiver; v6.4.16→v6.4.17 byte equality of the cited §2 OPEN 19/20 and §§6.15–6.17 is 5/5 IDENTICAL (preparer and receiver runs). Dyadic evidence BYTE_VERIFIED. RER Dyadic pins stay on v6.4.13. The r8 OWNER_REPORTED line above is kept as history.']}"),
 ("'# RER r4.6 — source-currency matrix (Phase A r8, noncanonical)'", "'# RER r4.6 — source-currency matrix (Phase A r9, noncanonical)'"),
 ("'# RER r4.6 — blocked-source register (Phase A r8, noncanonical)'", "'# RER r4.6 — blocked-source register (Phase A r9, noncanonical)'"),
])

rp('check_phaseA.py', [
 ('"""Phase A r8 gates on RER v0.2 DRAFT r4.6.', '"""Phase A r9 gates on RER v0.2 DRAFT r4.6.'),
 ("A23 Dyadic currency (r8): v6.4.17 is current, OWNER_REPORTED with the release-record hash; no file with that hash is in sources_available,\n"
  "so no BYTE_VERIFIED / HASH_VERIFIED_BY_RECEIVER promotion; v6.4.16 recorded as superseded (receiver-hashed); every Dyadic row has no verified\n"
  "current hash, owner evidence OWNER_REPORTED and a non-CURRENT currency; the DYAD6413 pin stays v6.4.13 with its cited hash and receiver authentication.\"\"\"",
  "A23 Dyadic currency (r9): v6.4.17 is current with evidence BYTE_VERIFIED, which requires the real file in sources_available with the expected\n"
  "hash and a matching custody entry (inputs/source_custody_r9.json); the r8 OWNER_REPORTED state is kept as history; v6.4.16 recorded as superseded;\n"
  "the section-check record shows both file hashes MATCH and 5/5 blocks IDENTICAL; every Dyadic row carries the v6.4.17 hash as verified current hash,\n"
  "owner evidence BYTE_VERIFIED and a non-CURRENT currency; the DYAD6413 pin stays v6.4.13 with its cited hash and receiver authentication.\n"
  "--tamper also runs a file-level control: the checker is re-run with the v6.4.17 file withheld from sources_available, and A23 must fail.\"\"\""),
 ("def gates(outs, verbose=True):", "def gates(outs, verbose=True, withhold=()):"),
 ("    avail = {sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) for f in os.listdir(os.path.join(HERE, 'sources_available'))}\n",
  "    avail = {sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) for f in os.listdir(os.path.join(HERE, 'sources_available')) if f not in withhold}\n"),
 ("    dy_ok = (dy['version'] == '6.4.17' and dy['sha256'] == D17 and dy['evidence'] == 'OWNER_REPORTED' and D17 not in avail\n"
  "             and dy.get('superseded', {}).get('version') == '6.4.16' and dy['superseded'].get('sha256') == '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'\n"
  "             and len(dyrows) >= 1 and all(x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT' for x in dyrows)\n",
  "    C9 = json.loads(B.rd('inputs/source_custody_r9.json')); f9 = C9['files'].get('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md', {})\n"
  "    sc = B.rd('inputs/dyad_v6_4_17_section_check/compare_output.txt').decode('utf-8')\n"
  "    sc_ok = (sc.count('IDENTICAL') == 5 and 'RESULT: PASS' in sc and 'DIFFERENT' not in sc and 'v6.4.16 33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0 MATCH' in sc\n"
  "             and f'v6.4.17 {D17} MATCH' in sc)\n"
  "    dy_ok = (dy['version'] == '6.4.17' and dy['sha256'] == D17 and dy['evidence'] == 'BYTE_VERIFIED' and D17 in avail\n"
  "             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok\n"
  "             and dy.get('history', {}).get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED'\n"
  "             and dy.get('superseded', {}).get('version') == '6.4.16' and dy['superseded'].get('sha256') == '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'\n"
  "             and len(dyrows) >= 1 and all(x['verified_current_hash'] == D17 and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['currency'] != 'CURRENT' for x in dyrows)\n"),
 ("    g('A23 Dyadic v6.4.17 owner-reported only; v6.4.16 superseded; RER pins stay v6.4.13', dy_ok, f'{len(dyrows)} Dyadic row(s)')",
  "    g('A23 Dyadic v6.4.17 byte-verified with file, custody and section check; r8 state as history; RER pins stay v6.4.13', dy_ok, f'{len(dyrows)} Dyadic row(s)')"),
 ("         ('A23 Dyadic v6.4.17 promoted to BYTE_VERIFIED without bytes', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED'))),\n"
  "         ('A23 Dyadic v6.4.17 promoted to BYTE_VERIFIED_HERE', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED_HERE'))),\n"
  "         ('A23 Dyadic v6.4.17 promoted to HASH_VERIFIED_BY_RECEIVER', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='HASH_VERIFIED_BY_RECEIVER'))),\n"
  "         ('A23 Dyadic row given a verified current hash', 22, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'Dyadic').update(verified_current_hash='e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'))),\n",
  "         ('A23 Dyadic evidence back to OWNER_REPORTED (r8 state)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='OWNER_REPORTED'))),\n"
  "         ('A23 Dyadic evidence relabelled BYTE_VERIFIED_HERE (not catalog vocabulary)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED_HERE'))),\n"
  "         ('A23 BYTE_VERIFIED with a hash that no held file has', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64))),\n"
  "         ('A23 Dyadic row verified hash removed', 22, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'Dyadic').update(verified_current_hash=None))),\n"
  "         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('history'))),\n"),
 ("    for n, i, o in T:\n        _, rr = gates(o, verbose=False); good = not rr[i]; allf &= good\n        print(f'  tamper {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n",
  "    for n, i, o in T:\n        _, rr = gates(o, verbose=False); good = not rr[i]; allf &= good\n        print(f'  tamper {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    _, rr = gates(outs, verbose=False, withhold=('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md',)); good = not rr[22]; allf &= good\n"
  "    print(f'  file control A23 v6.4.17 file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"),
])
print('patched')
