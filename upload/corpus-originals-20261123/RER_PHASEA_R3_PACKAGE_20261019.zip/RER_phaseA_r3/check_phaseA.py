"""Phase A r3 gates on RER v0.2 DRAFT r4.6. Markdown is re-read by plain line scanning, independent of tools/rer_parse.py.
Exit 0 iff all pass; --tamper runs negative controls (each must fail its named gate).
A1 r4.6 source SHA and input pins. A2 determinism: a fresh build equals the stored outputs byte for byte (same parser; not a second
independent parser). A3 record set: Markdown headings vs JSON ids, same order, 20, no duplicates, gaps separate.
A4 literal field mirror: every line reproduced by a structured JSON field (grade line, six contract cells, claim lines, named fields,
each import line and each OPEN line, imports/OPENs/claims in order) is re-found verbatim in the record's Markdown span; every non-blank
span line is either such a line or listed verbatim in unclassified_lines (no line dropped). Line order across different fields is
not reconstructed, and the meaning of a line is not checked.
A5 one matrix row per record import and per gap reference; required fields. A6 byte and package-path claims (r4.4 and r4.5
manifests). A7 stale owner pins carry a non-CURRENT status and a reason. A8 ER-2B firewall. A9 no promotion. A10 RRF-CND01
provenance split. A11 legacy snapshot separate. A12 blocked register complete. A13 packaging finding complete and repaired in r4.5.
A14 receiver status vocabulary. A15 gap-reference coverage (13 G7-G10 Reference lines, equal to the receiver crosswalk, each
PENDING_RRF_EDITOR). A16 authentication vocabulary (BYTE_VERIFIED_HERE iff bytes matched here; RECEIVER_BYTE_VERIFIED only for
receiver-reported keys; no hash => UNAUTHENTICATED_NO_HASH). A17 13/13 gap-reference cited_path non-null and equal to the
link target of the reference line (bracket-aware). A18 blocked register records the RRF-editor hashes exactly where r4.6 states them
(Q7), the coincidence ZIP keeps no hash, and both ER-2B records stay blocked."""
import sys, os, re, json, hashlib, copy
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); import build_phaseA as B
sha = lambda b: hashlib.sha256(b).hexdigest()
CAT_PINS = {'catalog_sources.json': None, 'catalog_records.json': None}  # filled from PINS file
PINS = json.load(open(os.path.join(HERE, 'PINS.json')))
md = open(os.path.join(HERE, B.MD), encoding='utf-8').read()
L = md.split('\n')

def md_records():
    out, cur = [], None
    for ln in L:
        m = re.match(r'^### (RER-[A-Z0-9-]+) — ', ln)
        if m or ln.startswith('## ') or ln.startswith('<a id='):
            if cur: out.append(cur); cur = None
        if m: cur = {'id': m.group(1), 'lines': []}
        elif cur is not None: cur['lines'].append(ln)
    if cur: out.append(cur)
    return out

def gates(outs, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_6_PHASEA.json']); cm = json.loads(outs['out/SOURCE_CURRENCY_MATRIX.json']); br = json.loads(outs['out/BLOCKED_SOURCE_REGISTER.json'])
    g('A1 source and catalog pins', sha(md.encode()) == B.MD_SHA and all(sha(open(os.path.join(HERE, f), 'rb').read()) == h for f, h in PINS['inputs'].items()))
    fresh = B.build()
    g('A2 deterministic rebuild equals stored outputs', all(fresh[p] == outs[p] for p in fresh) and set(fresh) == set(outs))
    mr = md_records(); gaps = {'RER-G7', 'RER-G8', 'RER-G9', 'RER-G10'}
    mids = [r['id'] for r in mr if r['id'] not in gaps]; jids = [r['id'] for r in reg['records']]
    g('A3 record set mirrors Markdown', mids == jids and len(set(jids)) == len(jids) == 20 and sorted(x['id'] for x in reg['gap_entries']) == sorted(gaps), f'{len(jids)} records')
    bad = []; nlines = 0; nuncl = 0
    for r in mr:
        if r['id'] in gaps: continue
        j = next((x for x in reg['records'] if x['id'] == r['id']), None)
        if j is None: bad.append((r['id'], 'missing')); continue
        span = r['lines']; spanset = set(span)
        gl = next((l for l in span if l.startswith('**Primary grade:**')), '')
        if j['primary_grade'] is None or j['primary_grade'] not in gl or ('`' + j['task'] + '`') not in gl or j.get('primary_grade_line') != gl: bad.append((r['id'], 'grade/task'))
        struct = {gl, '| Field | Contract |', '|---|---|'}
        for row in ['Carrier', 'Observables', 'Constraints', 'Transformation law', 'Closure status', 'Memory']:
            cell = next((l for l in span if l.startswith('| ' + row + ' | ')), None)
            if cell is None or cell != f"| {row} | {j['contract'][row]} |": bad.append((r['id'], row))
            struct.add(f"| {row} | {j['contract'][row]} |")
        if [l for l in span if l.startswith('Import/reference:')] != [i['line'] for i in j['imports']]: bad.append((r['id'], 'import lines'))
        if [l for l in span if l.startswith('[OPEN] ')] != ['[OPEN] ' + o for o in j['open_items']]: bad.append((r['id'], 'OPEN lines'))
        if [l for l in span if re.match(r'^\[(THM|ALG|NUM|DEF)\]', l)] != j['claim_lines']: bad.append((r['id'], 'claim lines'))
        for k, v in j['fields'].items():
            if v is not None:
                if f"**{k}:** {v}" not in spanset: bad.append((r['id'], k))
                struct.add(f"**{k}:** {v}")
        struct |= set(j['claim_lines']) | {'[OPEN] ' + o for o in j['open_items']} | {i['line'] for i in j['imports']}
        if any(u not in spanset for u in j['unclassified_lines']): bad.append((r['id'], 'unclassified not in span'))
        left = [l for l in span if l.strip() and l not in struct and l not in set(j['unclassified_lines'])]
        if left: bad.append((r['id'], f'{len(left)} lines unaccounted'))
        nlines += sum(1 for l in span if l.strip()); nuncl += len(j['unclassified_lines'])
    g('A4 literal field mirror; every record line accounted for', not bad, f'{len(bad)} mismatches {bad[:2]}; {nlines} lines, {nuncl} unclassified (verbatim)')
    need = ['record', 'key', 'source_doc', 'cited_version', 'cited_sha256', 'current_owner_version', 'current_owner_sha256', 'section_or_RID', 'inspection_extent', 'currency', 'reviewer_disposition', 'bytes_status']
    gaprefs = [l for r in mr if r['id'] in gaps for l in r['lines'] if l.startswith('Reference:')]
    occ = sum(len(x['imports']) for x in reg['records']) + len(gaprefs)
    keys_ok = all(all(k in x for k in need) for x in cm['rows'])
    g('A5 one currency row per record import and per gap reference, required fields present', len(cm['rows']) == occ and keys_ok and all(x['reviewer_disposition'] == 'PENDING' for x in cm['rows']), f'{len(cm["rows"])} rows')
    bb = []
    pkg = B.rd('inputs/r4_4_package_SHA256SUMS.txt').decode(); pkg45 = B.rd('inputs/r4_5_package_SHA256SUMS.txt').decode(); pkg46 = B.rd('inputs/r4_6_package_SHA256SUMS.txt').decode()
    for x in cm['rows']:
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH':
            f = os.path.join(HERE, x['available_file'] or '')
            if not os.path.isfile(f) or sha(open(f, 'rb').read()) != x['cited_sha256']: bb.append(x['key'])
        elif x['available_file']: bb.append(x['key'])
        if x['path_in_r4_4_package'] and ('  ' + x['cited_path'] + '\n') not in pkg: bb.append(x['key'] + ':pkg')
        if x['path_in_r4_5_package'] and ('  ' + x['cited_path'] + '\n') not in pkg45: bb.append(x['key'] + ':pkg45')
        if x['path_in_r4_6_package'] and ('  ' + x['cited_path'] + '\n') not in pkg46: bb.append(x['key'] + ':pkg46')
    g('A6 byte and package-path claims are true', not bb, f'{bb[:3]}')
    st = [x for x in cm['rows'] if x['source_family'] == 'OWNER_DSN' and x['current_owner_version'] and x['cited_version'] != x['current_owner_version']
          and (x['currency'] in ('CURRENT',) or not x['currency_reason'])]
    g('A7 stale owner pins carry a non-CURRENT status and a reason', not st, f'{len(st)} stale')
    er = [x for x in reg['records'] if x['id'] in ('RER-ER2B-T6D', 'RER-ER2B-CARRIER')]
    g('A8 ER-2B firewall', len(er) == 2 and all(x['phaseA_status'] == 'BLOCKED_SOURCE_UNVERIFIED' and x['accepted_cohort_eligible'] is False and x['grade_status'] == 'SOURCE_CLAIMED_NOT_RER_ADOPTED' for x in er)
      and all(x['accepted_cohort_eligible'] for x in reg['records'] if x not in er))
    g('A9 no promotion: adoption PENDING everywhere', all(x['adoption_status'] == 'PENDING' and x['registry_owner_adoption'].startswith('pending') for x in reg['records']))
    c = next(x for x in reg['records'] if x['id'] == 'RER-RRF-CND01')
    g('A10 RRF-CND01 provenance split', c['claim_provenance'] == 'RER_NATIVE_STANDARD_MATH' and '[DEF] proposed interface' in c.get('provenance_note', '') and 'NOT the source of the [THM]' in c.get('provenance_note', ''))
    lg = reg['legacy_v0_1_snapshot']
    g('A11 legacy v0.1 snapshot separate', lg['label'] == 'HISTORICAL_SNAPSHOT_NOT_AN_ADOPTION_COHORT' and len(lg['entries']) == 16 and not set(e['key'] for e in lg['entries']) & set(jids))
    srcs = {b['source'] for b in br['blocked']}
    mpi = {m for x in reg['records'] for m in x['missing_primary_inputs']}
    dna = {re.findall(r'`([^`]+)`', l)[1] for l in L if l.startswith('| `') and 'Direct source not available' in l}
    erb = next((b for b in br['blocked'] if b['source'] == 'RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'), {})
    g('A12 blocked register complete', mpi <= srcs and dna <= srcs and set(erb.get('blocked_records', [])) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'}, f'{len(srcs)} sources')
    lost = sorted(set(x['key'] for x in cm['rows'] if x['path_in_r4_package'] and not x['path_in_r4_4_package']))
    rep_ok = all(x['path_in_r4_5_package'] and x['path_in_r4_6_package'] for x in cm['rows'] if x['key'] in lost) and br.get('repaired_in_r4_5') == lost
    g('A13 packaging finding complete; every lost file carried by r4.5 at its cited path', lost == br['lost_in_packaging'] and all(k in br['packaging_finding'] for k in lost) and rep_ok, f'{len(lost)} files')
    st_ok = all(x['status'] in ('VERIFIED', 'OWNER_REPORTED', 'HISTORICAL', 'BLOCKED') and x['status'] == B.status_of(x) for x in cm['rows'])
    vh_ok = all((x['verified_current_hash'] is None) or (x['current_owner_evidence'] in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER') and x['verified_current_hash'] == x['current_owner_sha256']) for x in cm['rows'])
    ver_ok = all(x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in cm['rows'] if x['status'] == 'VERIFIED')
    g('A14 receiver status vocabulary and verified-hash discipline', st_ok and vh_ok and ver_ok)
    xw = json.loads(B.rd('inputs/RECEIVER_GAP_REFERENCE_CROSSWALK_20261019.json'))
    jg = [(gp['id'], q['line']) for gp in reg['gap_entries'] for q in gp['references']]
    mg = [(r['id'], l) for r in mr if r['id'] in gaps for l in r['lines'] if l.startswith('Reference:')]
    rows_g = [x for x in cm['rows'] if x['row_kind'] == 'GAP_REFERENCE']
    g('A15 gap-reference coverage (13; equals receiver crosswalk; Phase C pending)', len(mg) == 13 and jg == mg and sorted(l for _, l in mg) == sorted(r['reference_text'] for r in xw['rows'])
      and len(rows_g) == 13 and all(x.get('phaseC_disposition') == 'PENDING_RRF_EDITOR' for x in rows_g), f'{len(rows_g)} rows')
    CSK = json.loads(B.rd('catalog_sources.json'))['keys']
    def auth(x):
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH': return 'BYTE_VERIFIED_HERE'
        if CSK.get(x['key'], {}).get('receiver_byte_verified'): return 'RECEIVER_BYTE_VERIFIED'
        return 'HASH_PRINTED_UNVERIFIED' if x['cited_sha256'] else 'UNAUTHENTICATED_NO_HASH'
    g2 = [x for x in cm['rows'] if x['key'] == 'G2NOTE04']
    g('A16 authentication vocabulary; G2NOTE04 unauthenticated', all(x['authentication'] == auth(x) for x in cm['rows']) and bool(g2) and all(x['authentication'] == 'UNAUTHENTICATED_NO_HASH' for x in g2))
    def target(l):
        i = l.index('['); depth = 0
        for k in range(i, len(l)):
            depth += (l[k] == '[') - (l[k] == ']')
            if depth == 0: break
        assert l[k + 1] == '(' or l[k + 1:k + 3] == ' ('
        j = l.index('(', k + 1); return __import__('urllib.parse').parse.unquote(l[j + 1:l.index(')', j)])
    gp = [(x['cited_path'], target(next(q['line'] for gg in reg['gap_entries'] if gg['id'] == x['record'] for q in [gg['references'][x['n']]]))) for x in rows_g]
    g('A17 gap-reference paths: 13/13 non-null and equal to the link target', len(gp) == 13 and all(p and p == t for p, t in gp), f'{sum(1 for p, t in gp if p and p == t)}/13')
    Q7 = json.loads(B.rd('inputs/rrf_editor_q7_hashes.json'))
    bys = __import__('collections').defaultdict(lambda: {'blocked_records': []}, {b['source']: b for b in br['blocked']})
    g('A18 Q7 custody in the blocked register; ZIP unhashed; ER-2B still blocked',
      bys['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md'].get('rrf_editor_sha256') == Q7['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md']
      and bys['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'].get('rrf_editor_sha256') == Q7['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']
      and 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip' in bys and 'rrf_editor_sha256' not in bys['ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip']
      and set(bys['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']['blocked_records']) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'})
    return all(res), res

outs = {p: open(os.path.join(HERE, p), 'rb').read() for p in B.build()}
ok, res = gates(outs); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    def mut(path, f):
        o = dict(outs); d = json.loads(o[path]); f(d); o[path] = B.dump(d); return o
    R, C, K = 'out/RER_REGISTRY_v0_2_r4_6_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'
    T = [('A3 drop a record', 2, mut(R, lambda d: d['records'].pop(5))),
         ('A4 change a contract cell', 3, mut(R, lambda d: d['records'][0]['contract'].__setitem__('Closure status', 'CLOSED'))),
         ('A6 false byte claim', 5, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY').update(bytes_status='BYTE_VERIFIED_MATCH', available_file='sources_available/none'))),
         ('A7 stale pin marked CURRENT', 6, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'GEN287').update(currency='CURRENT'))),
         ('A8 ER-2B unblocked', 7, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-ER2B-T6D').update(phaseA_status='ACTIVE', accepted_cohort_eligible=True))),
         ('A9 promote adoption', 8, mut(R, lambda d: d['records'][3].update(adoption_status='ADOPTED'))),
         ('A12 drop a blocked source', 11, mut(K, lambda d: d['blocked'].pop(0))),
         ('A14 printed-only row labelled VERIFIED', 13, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY' and x['currency'] != 'BLOCKED').update(status='VERIFIED'))),
         ('A4 alter one import line', 3, mut(R, lambda d: d['records'][3]['imports'][0].__setitem__('line', d['records'][3]['imports'][0]['line'].replace('SHA-256', 'SHA256', 1)))),
         ('A4 drop an unclassified line', 3, mut(R, lambda d: next(x for x in d['records'] if x['unclassified_lines'])['unclassified_lines'].pop())),
         ('A15 drop a gap reference row', 14, mut(C, lambda d: d['rows'].remove(next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE')))),
         ('A16 G2NOTE04 labelled hash-printed', 15, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'G2NOTE04').update(authentication='HASH_PRINTED_UNVERIFIED'))),
         ('A17 null a gap-reference path', 16, mut(C, lambda d: next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE' and x['record'] == 'RER-G9').update(cited_path=None))),
         ('A18 give the ZIP an editor hash', 17, mut(K, lambda d: next(b for b in d['blocked'] if b['source'] == 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip').update(rrf_editor_sha256='0' * 64)))]
    allf = True
    for n, i, o in T:
        _, rr = gates(o, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    ok = ok and allf
sys.exit(0 if ok else 1)
