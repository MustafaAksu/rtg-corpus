"""Phase A r15 -> r16: Phase A pass on the exact RER r4.10 bytes (receiving decision of 20 Oct 2026: RER r4.10 ACCEPT SCOPED; Phase A r16 authorized).
- Source Markdown: RER r4.10 (5b1d0654...b53c; package ac3dd776...7041) replaces r4.9; r4.10 package manifest added; rows carry path_in_r4_10_package.
- Expected and gated: the 91 matrix rows, statuses, pins and the 20 records unchanged; only RER-G9's gap-entry text_sha256 changes; G9/1, G9/3 stay
  PENDING_PER_REFERENCE_AUDIT.
- A24 re-based (r4.10 + r4.9/r4.8 bases; r13 and r15 checker records kept); A25 re-based on the r15 registry; A28 re-based on the r15 matrix;
  new A30: the package manifest lists no Python bytecode cache (receiver packaging note). r15 outputs kept under inputs/phaseA_r15_outputs/.
Args: TARGET_DIR R410_PACKAGE_DIR."""
import sys, os, json, shutil, hashlib
D, P410 = sys.argv[1:3]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
R410 = '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c'; R410Z = 'ac3dd7768a3109645fcec3f7500c14f62804ccb853727e0755237194d1447041'
R49 = '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84'; R49Z = '7fa00ac168b74550bff999f0b0d4c49b12255155d8b64f2ee2344facbf2a100d'
MD10 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_10.md'; MD9 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_9.md'
m10 = open(os.path.join(P410, MD10), 'rb').read(); assert sha(m10) == R410
for root, dirs, files in os.walk(D):  # receiver packaging note: no bytecode caches in the package
    for x in list(dirs):
        if x == '__pycache__': shutil.rmtree(os.path.join(root, x)); dirs.remove(x)
os.remove(os.path.join(D, 'SHA256SUMS.txt'))  # the r15 manifest listed bytecode caches; a fresh manifest is written at packaging
H = os.path.join(D, 'inputs/phaseA_r15_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r15.txt'))
os.remove(os.path.join(D, MD9)); open(os.path.join(D, MD10), 'wb').write(m10)
shutil.copyfile(os.path.join(P410, 'SHA256SUMS.txt'), os.path.join(D, 'inputs/r4_10_package_SHA256SUMS.txt'))
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p)); KV['_catalog_checked'] = '2026-10-20 (Phase A r16, preparer)'; open(p, 'w').write(dump(KV))
p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
CS['_about'] += ' Phase A r16 (20 Oct): source RER r4.10 (G9 W3 source-fidelity text only); no catalog content change.'
open(p, 'w').write(dump(CS))

rp('build_phaseA.py', [
 ('"""RER Phase A r15 builder (deterministic;', '"""RER Phase A r16 builder (deterministic; r16 runs on RER r4.10 (G9 W3 text only);'),
 (f"MD = '{MD9}'\nMD_SHA = '{R49}'\nR49_ZIP_SHA = '{R49Z}'\n", f"MD = '{MD10}'\nMD_SHA = '{R410}'\nR410_ZIP_SHA = '{R410Z}'\nBASE_R49_SHA = '{R49}'\nR49_ZIP_SHA = '{R49Z}'\n"),
 ("    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.9 hash mismatch'", "    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.10 hash mismatch'"),
 ("pkg49 = man('inputs/r4_9_package_SHA256SUMS.txt')\n", "pkg49 = man('inputs/r4_9_package_SHA256SUMS.txt'); pkg410 = man('inputs/r4_10_package_SHA256SUMS.txt')\n"),
 ("'path_in_r4_9_package': path in pkg49, 'cited_path': path,", "'path_in_r4_9_package': path in pkg49, 'path_in_r4_10_package': path in pkg410, 'cited_path': path,"),
 ("'RER-REGISTRY-PHASEA/15'", "'RER-REGISTRY-PHASEA/16'"), ("'RER-SOURCE-CURRENCY/15'", "'RER-SOURCE-CURRENCY/16'"), ("'RER-BLOCKED-SOURCES/15'", "'RER-BLOCKED-SOURCES/16'"),
 ("'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R49_ZIP_SHA, 'base_r4_8_sha256': BASE_R48_SHA,",
  "'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R410_ZIP_SHA, 'base_r4_9_sha256': BASE_R49_SHA, 'base_r4_9_package_zip_sha256': R49_ZIP_SHA, 'base_r4_8_sha256': BASE_R48_SHA,"),
 ("    return {'out/RER_REGISTRY_v0_2_r4_9_PHASEA.json': dump(reg),", "    return {'out/RER_REGISTRY_v0_2_r4_10_PHASEA.json': dump(reg),"),
 ("'# RER r4.9 — source-currency matrix (Phase A r15, noncanonical)'", "'# RER r4.10 — source-currency matrix (Phase A r16, noncanonical)'"),
 ("'# RER r4.9 — blocked-source register (Phase A r15, noncanonical)'", "'# RER r4.10 — blocked-source register (Phase A r16, noncanonical)'"),
 ("| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 pkg |", "| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 / r4.10 pkg |"),
 ("{yn(x['path_in_r4_9_package'])} |", "{yn(x['path_in_r4_9_package'])} / {yn(x['path_in_r4_10_package'])} |"),
 ("the W3 interface question waits for the RRF editor (RF-1).']}",
  "the W3 interface question waits for the RRF editor (RF-1).',\n"
  "                          'Phase A r16 (20 Oct 2026): source is RER r4.10 (5b1d0654…b53c; package ac3dd776…7041), accepted ACCEPT SCOPED as a DRAFT: RER-G9 W3 now states the RECOG §6.16g same-space condition; the RRF v0.8.3 §6.3 wording is recorded as an unmarked extension (RRF editor reply 3092fd5a…6053, RF-1 option (a)); different-space comparison is a separate OPEN RRF proposal; v0.8 / v0.8.3 §6.3 identity EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED. G9 Reference lines, pins and all rows unchanged; G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT. The r15 line above (W3 waiting for RF-1) is kept as history.']}"),
])

C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    assert t.count(a) == 1, a[:60]; i = t.index(a); j = t.index(b, i); return t[:i] + new + t[j:]
t = t.replace("'out/RER_REGISTRY_v0_2_r4_9_PHASEA.json'", "'out/RER_REGISTRY_v0_2_r4_10_PHASEA.json'")
t = t.replace("pkg49 = B.rd('inputs/r4_9_package_SHA256SUMS.txt').decode()\n", "pkg49 = B.rd('inputs/r4_9_package_SHA256SUMS.txt').decode(); pkg410 = B.rd('inputs/r4_10_package_SHA256SUMS.txt').decode()\n", 1)
t = t.replace("        if x.get('path_in_r4_9_package') and ('  ' + x['cited_path'] + '\\n') not in pkg49: bb.append(x['key'] + ':pkg49')\n",
              "        if x.get('path_in_r4_9_package') and ('  ' + x['cited_path'] + '\\n') not in pkg49: bb.append(x['key'] + ':pkg49')\n        if x.get('path_in_r4_10_package') and ('  ' + x['cited_path'] + '\\n') not in pkg410: bb.append(x['key'] + ':pkg410')\n", 1)
assert t.count("pkg410") == 3
NEW_A24_25 = r'''    sm = reg['source_markdown']
    H13 = 'inputs/phaseA_r13_outputs/'; o13 = ri(H13 + 'check_phaseA_output_r13.txt').decode('utf-8'); H15 = 'inputs/phaseA_r15_outputs/'; o15 = ri(H15 + 'check_phaseA_output_r15.txt').decode('utf-8')
    man410 = B.rd('inputs/r4_10_package_SHA256SUMS.txt').decode()
    src_ok = (sm['file'].endswith('_r4_10.md') and sm['sha256'] == B.MD_SHA == '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c' and sm['package_zip_sha256'] == 'ac3dd7768a3109645fcec3f7500c14f62804ccb853727e0755237194d1447041'
              and sm.get('base_r4_9_sha256') == '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84' and sm.get('base_r4_9_package_zip_sha256') == '7fa00ac168b74550bff999f0b0d4c49b12255155d8b64f2ee2344facbf2a100d'
              and sm.get('base_r4_8_sha256') == '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e' and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA
              and all('path_in_r4_10_package' in x for x in cm['rows']) and '28/28 gates PASS' in o13 and '29/29 gates PASS' in o15 and 'BAD' not in o13 + o15
              and '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84  RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_9.md\n' in man410)
    g('A24 r4.10 source pass: r4.10, package and r4.9/r4.8 bases pinned; r4.9 identity in the r4.10 manifest; every row carries path_in_r4_10_package; r13 and r15 checker records kept', src_ok)
    g15 = json.loads(B.rd(H15 + 'RER_REGISTRY_v0_2_r4_9_PHASEA.json'))
    G15 = {x['id']: x for x in g15['gap_entries']}; G16 = {x['id']: x for x in reg['gap_entries']}
    dg = sorted(k for k in G15 if G15[k] != G16.get(k))
    strip = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown', 'gap_entries')}
    r_ok = (reg['records'] == g15['records'] and strip(reg) == strip(g15) and set(G15) == set(G16) and dg == ['RER-G9']
            and {k: v for k, v in G16['RER-G9'].items() if k != 'text_sha256'} == {k: v for k, v in G15['RER-G9'].items() if k != 'text_sha256'}
            and G16['RER-G9']['text_sha256'] != G15['RER-G9']['text_sha256'] and len(reg['records']) == 20)
    g('A25 r15 registry equality: 20 records, source table and all gap entries unchanged except RER-G9 text_sha256 (its references identical)', r_ok, f'gap entries differing: {dg}')
'''
t = cut(t, "    sm = reg['source_markdown']\n    H13 = ", "    rc = oc['RECOG'];", NEW_A24_25)
NEW_A28 = r'''    m15 = json.loads(B.rd(H15 + 'SOURCE_CURRENCY_MATRIX.json')); b15 = json.loads(B.rd(H15 + 'BLOCKED_SOURCE_REGISTER.json'))
    dk = [sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k)) for x, y in zip(cm['rows'], m15['rows'])]
    rows15_ok = (len(cm['rows']) == len(m15['rows']) == 91 and all(d == ['path_in_r4_10_package'] for d in dk)
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256')}
    rest15_ok = (stripb(br) == stripb(b15) and oc == m15['owner_current'] and cm.get('scientific_sync_warnings') == m15.get('scientific_sync_warnings')
                 and cm['watch_items'][:-1] == m15['watch_items'] and cm['watch_items'][-1].startswith('Phase A r16 (20 Oct 2026): source is RER r4.10')
                 and {k: v for k, v in meta.items() if k != 'checked'} == {k: v for k, v in m15['owner_catalog'].items() if k != 'checked'}
                 and cm['bytes_not_available_to_preparer'] == m15['bytes_not_available_to_preparer'] and m15['schema'] == 'RER-SOURCE-CURRENCY/15' and cm['schema'] == 'RER-SOURCE-CURRENCY/16')
    g('A28 r15 matrix equality: 91 rows unchanged except path_in_r4_10_package; owners, warning (incl. disposition), blocked register and G9 audits unchanged', rows15_ok and rest15_ok, f'{sum(1 for d in dk if d != ["path_in_r4_10_package"])} row(s) with other differences')
'''
t = cut(t, "    H14 = 'inputs/phaseA_r14_outputs/'\n", "    H83 = ", NEW_A28)
t = t.replace("    return all(res), res\n\nouts =",
  "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt')\n"
  "    sums = open(SUMS, encoding='utf-8').read() if os.path.isfile(SUMS) else ''\n"
  "    g('A30 package manifest lists no Python bytecode cache (__pycache__, .pyc)', '__pycache__' not in sums and '.pyc' not in sums)\n"
  "    return all(res), res\n\nouts =", 1)
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
assert block[0].startswith("    T = [('") and all(l.startswith("         ('") for l in block[1:])
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]; ents[-1] = ents[-1][:-1]
keep = [e.rstrip(',') for e in ents if not any(e.startswith("('" + g + ' ') for g in ('A24', 'A25', 'A28'))]
NEWC = r'''('A24 source recorded as r4.9', 23, mut(R, lambda d: d['source_markdown'].update(sha256='9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84')))
('A24 r4.10 package hash replaced', 23, mut(R, lambda d: d['source_markdown'].update(package_zip_sha256='0' * 64)))
('A24 r4.9 base dropped', 23, mut(R, lambda d: d['source_markdown'].pop('base_r4_9_sha256')))
('A24 a row without path_in_r4_10_package', 23, mut(C, lambda d: d['rows'][0].pop('path_in_r4_10_package')))
('A25 r15 registry re-used (G9 text hash of r4.9)', 24, mut(R, lambda d: d.update(gap_entries=json.loads(B.rd('inputs/phaseA_r15_outputs/RER_REGISTRY_v0_2_r4_9_PHASEA.json'))['gap_entries'])))
('A25 a G9 reference line changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G9')['references'][-1].update(section='6.3 (edited)')))
('A25 another gap entry changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G10').update(text_sha256='0' * 64)))
('A25 a record changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED')))
('A28 r15 matrix rows re-used', 27, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r15_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows'])))
('A28 a row status changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(status='OWNER_REPORTED')))
('A28 G9/1 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 1).update(gap_reference_review='CLOSED')))
('A28 G9/3 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 3).update(gap_reference_review='CLOSED')))
('A28 warning disposition dropped', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition')))
('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited')))
('A28 owner entry changed', 27, mut(C, lambda d: d['owner_current']['OFN'].update(note='edited')))'''.split('\n')
t = t[:i] + '    T = [' + (',\n         ').join(keep + NEWC) + ']' + t[j:]
t = t.replace("    c15 = B.rd('inputs/source_custody_r15.json'); rv = B.rd('inputs/receiving_review_phaseA_r14_20261020.md')\n",
  "    o15 = B.rd('inputs/phaseA_r15_outputs/check_phaseA_output_r15.txt')\n"
  "    _, rr = gates(outs, verbose=False, inp={'inputs/phaseA_r15_outputs/check_phaseA_output_r15.txt': o15.replace(b'29/29 gates PASS', b'28/29 gates PASS', 1)}); good = not rr[23]; allf &= good\n"
  "    print(f'  input control A24 r15 checker record altered: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt'); had = os.path.isfile(SUMS); keep_s = open(SUMS, 'rb').read() if had else b''\n"
  "    try:\n"
  "        open(SUMS, 'wb').write(keep_s + b'0' * 64 + b'  __pycache__/build_phaseA.cpython-313.pyc\\n')\n"
  "        _, rr = gates(outs, verbose=False); good = not rr[29]; allf &= good\n"
  "        print(f'  file control A30 bytecode cache listed in the manifest: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    finally:\n"
  "        open(SUMS, 'wb').write(keep_s) if had else os.remove(SUMS)\n"
  "    c15 = B.rd('inputs/source_custody_r15.json'); rv = B.rd('inputs/receiving_review_phaseA_r14_20261020.md')\n", 1)
assert t.count('file control A30') == 1
a = '"""Phase A r15 gates on RER v0.2 DRAFT r4.9'; assert t.count(a) == 1
t = t.replace(a, '"""Phase A r16 gates on RER v0.2 DRAFT r4.10 (r16: source r4.10, G9 W3 text only).\n'
  'r16: A24 pins r4.10, its package and the r4.9/r4.8 bases, the r4.9 identity in the r4.10 manifest, path_in_r4_10_package on every row, and the r13 and\n'
  'r15 checker records. A25 compares with the pinned r15 registry: records and source table equal; among the gap entries only RER-G9 text_sha256 changes.\n'
  'A28 compares with the pinned r15 matrix: rows differ only by path_in_r4_10_package; owners, warning and blocked register unchanged; G9 audits pending.\n'
  'A30 the package manifest lists no bytecode cache. The r14/r15 A25 (r13 registry) and r15 A28 (r14 matrix) are retired; their results stay in the pinned records.\n'
  'Earlier wording, kept as history: Phase A r15 gates on RER v0.2 DRAFT r4.9', 1)
open(C, 'w', encoding='utf-8').write(t)

p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/r4_10_package_SHA256SUMS.txt'] + ['inputs/phaseA_r15_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched')
