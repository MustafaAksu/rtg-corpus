# RER Phase A r16: change record (Phase A pass on RER r4.10)

**Date:** 20 Oct 2026.
**From:** Claude, RER co-owner (preparer). The preparer does not accept his own work.
**Status:** NONCANONICAL Phase A candidate, revision 16. Nothing is adopted, frozen or published.
**Answers:** the receiving decision on RER r4.10 of 20 Oct 2026 (ACCEPT SCOPED, draft only). It authorized r16 on the actual r4.10 bytes. Its conditions: the r15 outputs kept as history; the 91-row matrix, statuses, pins and the other 19 records unchanged; the G9 text hash updated; G9/1 and G9/3 kept `PENDING_PER_REFERENCE_AUDIT`. The decision also included a packaging note on Python bytecode caches.

## 1. Source and base

- **Source Markdown:** RER r4.10 (`5b1d0654…b53c`; package `ac3dd776…7041`; base r4.9 `9c0f43fc…cc84`). It replaces r4.9 in the package.
- **r4.10 package manifest:** added as `inputs/r4_10_package_SHA256SUMS.txt`, which pins r4.9. Every row carries `path_in_r4_10_package`.
- **Base package:** Phase A r15 (`127a2a8e…be61`, accepted), extracted fresh.
- **Patch:** `patch_r16.py`.
- **r15 history:** the five r15 outputs and the r15 checker output are kept byte-unchanged under `inputs/phaseA_r15_outputs/` and pinned. The registry output is now `RER_REGISTRY_v0_2_r4_10_PHASEA.json`.
- **Catalog:** no content change; only the check date and an `_about` sentence.

## 2. Result

- **Matrix:** 91 rows, unchanged from r15 except the added `path_in_r4_10_package` field (true on 24 rows and equal to `path_in_r4_9_package` on every row: the r4.10 package carries the same cited files as r4.9). The G9 Reference lines are byte-identical, so the G9 rows keep their values; G9/0, G9/1 and G9/3 stay `PENDING_PER_REFERENCE_AUDIT`. Status counts are unchanged: VERIFIED 32 / OWNER_REPORTED 3 / HISTORICAL 50 / BLOCKED 6; authentication 60 / 6 / 24 / 1.
- **Registry:** the 20 records and the source table are unchanged. Among the four gap entries only RER-G9's `text_sha256` changes (its body text changed in r4.10); its references are identical.
- **Owners, warning, blocked register:** owner_current, SYNC-DYAD-OPEN20-BINF (computed CHECK plus the receiving disposition) and the blocked register are unchanged, apart from schema and source hash.

## 3. Packaging (receiver note)

- **What happened:** from Phase A r14 and RER r4.9 on, the packages carried `__pycache__/*.pyc` files and listed them in `SHA256SUMS.txt`. A later Python run can rewrite them, so the manifest could then fail on files that are not sources.
- **Fixed in r16:**
  - the inherited bytecode caches and the old manifest are removed before the build;
  - the builder and checker are run here with bytecode writing disabled;
  - the new manifest lists no bytecode cache, and the new gate **A30** checks this.
- **For a receiver run:** a plain `python -I` run may still create caches next to the scripts. They are not in the manifest, so `sha256sum -c` is unaffected.
- **Not changed:** the pinned r4.10 package manifest (`inputs/r4_10_package_SHA256SUMS.txt`) is the accepted package's own record, cache entries included, and is kept byte-unchanged.

## 4. Gates: 30/30 PASS; controls 98/98 fail as required

| Gate | r16 requirement |
|---|---|
| A6 | also checks `path_in_r4_10_package` against the r4.10 manifest |
| A24 (re-based) | r4.10, its package and the r4.9/r4.8 bases pinned; the r4.9 identity in the r4.10 manifest; `path_in_r4_10_package` on every row; the r13 (28/28) and r15 (29/29) checker records kept |
| A25 (re-based on r15) | records, source table and gap entries equal r15, except RER-G9 `text_sha256` (references identical) |
| A28 (re-based on r15) | every row differs from r15 only by `path_in_r4_10_package`; owners, the warning with its disposition, and the blocked register unchanged; the RER-G9 audits pending |
| A30 (new) | the package manifest lists no `__pycache__` or `.pyc` |

**Retired gates:** the r14/r15 A25 (r13 registry equality) and the r15 A28 (r14 matrix equality). Their results stay in the pinned r15 checker record, which A24 requires.

**Controls: 15 new output controls.**
- A24: source recorded as r4.9; package hash replaced; r4.9 base dropped; a row without the r4.10 flag.
- A25: r15 gap entries re-used; a G9 reference changed; another gap entry changed; a record changed.
- A28: r15 rows re-used; a row status changed; G9/1 closed; G9/3 closed; the warning disposition dropped; the blocked register changed; an owner entry changed.

**Other new controls:**
- input control: the r15 checker record altered;
- file control: a bytecode cache entry listed in the manifest.

**Total:** 81 carried + 15 + 1 + 1 = 98.

**Clean extraction.** Re-extracted into an empty directory and run twice with a plain `python -I` (caches allowed). Both runs gave output byte-identical to the stored checker output, and `sha256sum -c` passed after each run.

## 5. Not changed, and open

- RER r4.10 text, grades, pins and OPEN boundaries.
- G9/1 and G9/3 per-reference audits (receiver).
- G2 §5b, the two ER-2B blocks and the author-conflicted Phase B reviews.
