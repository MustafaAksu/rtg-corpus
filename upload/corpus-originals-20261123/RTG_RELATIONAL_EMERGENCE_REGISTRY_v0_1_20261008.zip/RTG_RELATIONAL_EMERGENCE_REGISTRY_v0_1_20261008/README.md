# RTG Relational Emergence Registry — initial v0.1, 8 October 2026

**Noncanonical working registry.** No owner DSN, frozen record, scientific RID, representation profile or physical model is amended or selected.

Start with [`RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_1_DRAFT.md`](RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_1_DRAFT.md). It preserves the attached proposal's seven levels, its distinction between derived properties/effective descriptions/physical emergence, and its triad-first objective.

The registry contains **16 six-field records** and the **seven candidate-property agenda**. Local entry identifiers are navigation keys only. Every record names a baseline readout and distinguishes static representation, exact/failed/untested dynamics, memory requirements and physical interpretation.

## Contents

- `data/REGISTRY.json`: machine-readable entries, methods, watchlist and next-source requests.
- `data/REGISTRY.schema.json`: schema enforcing the six required fields and noncanonical status.
- `data/SOURCE_MANIFEST.json` / `SOURCE_EXCERPTS.json`: exact source hashes and cited passages.
- `data/TRIAD_CLOSURE_REQUEST.json`: bounded first-triad experiment specification, with missing inputs explicit.
- `sources/`: unchanged copies of the request, consulted owner/representation files and archived Methodology v1.3. Copying a source does not assert a new full-file scientific audit.
- `scripts/` and `logs/`: new exact local algebra checks, build/render scripts and mechanical validation.

## Reproduce

Python 3, SymPy and jsonschema; executed versions appear in `environment.json`.

```sh
python scripts/run_all.py
```

Expected results: **28 local exact checks PASS**; **16 mechanical checks PASS**; both named negative controls exit 1 at their intended assertions. They reject claiming that Gram-only data determine the orientation sign, and that contraction proves an autonomous amplitude-only return.

The algebra script imports no historical producer. It derives the one-dimensional primitive T^6 ray jet using Fraction arithmetic and checks carrier/constraint identities with SymPy. The generic closure theorem and static quotient argument are proved in the document; finite checks do not certify their universal scope by enumeration. No primitive coupled-K3 update, minimal finite-memory model, physical emergence theorem, or historical certificate campaign is supplied or rerun.

The **primary next target is still the triad**: an independently specified standalone vector law, its incidence, metric/orientation, clock and admissible domain. The root-closed diagnostic already has a defined ODE, but that is not a derived quotient of that missing microscopic vector law. K4 shadow data are not silently used as standalone K3 data.

All source files are preserved. `data/INPUT_INTEGRITY.json` records the unchanged initial non-cache input paths; the package manifest establishes artifact identity, not scientific adoption.
