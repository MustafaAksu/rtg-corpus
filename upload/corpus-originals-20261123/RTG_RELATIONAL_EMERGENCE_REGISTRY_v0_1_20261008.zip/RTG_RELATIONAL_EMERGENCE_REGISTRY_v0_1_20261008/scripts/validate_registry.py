#!/usr/bin/env python3
"""Mechanical source, schema and current-use checks; not a science certificate."""
from pathlib import Path
import re,json,hashlib
import jsonschema
ROOT=Path(__file__).resolve().parents[1]
r=json.loads((ROOT/'data/REGISTRY.json').read_text());schema=json.loads((ROOT/'data/REGISTRY.schema.json').read_text());checks=[]
def ck(name,value):
 ok=bool(value);checks.append({'name':name,'pass':ok});print(('PASS 'if ok else 'FAIL ')+name,flush=True)
 if not ok:raise AssertionError(name)
errors=list(jsonschema.Draft202012Validator(schema).iter_errors(r))
ck('JSON schema validates the complete instance',not errors)
es=r['entries'];ids=[e['entry_id']for e in es]
ck('sixteen unique local records',len(es)==16 and len(set(ids))==16)
fields=set(r['methods']['required_six_fields'])
ck('every record contains exactly the six requested fields',all(set(e['record'])==fields for e in es))
ck('source hashes match actual preserved package bytes',all(hashlib.sha256((ROOT/d['package_path']).read_bytes()).hexdigest()==d['sha256'] for d in r['sources'].values()))
validrefs=True;ridvalid=True
for e in es:
 for ref in e['source_refs']:
  validrefs &= ref['source_id'] in r['sources']
  src=r['sources'][ref['source_id']];txt=(ROOT/src['package_path']).read_text();ls=txt.splitlines()
  if ref['lines']:validrefs &= 1<=ref['lines'][0]<=ref['lines'][1]<=len(ls)
  if ref['owner_rid']:ridvalid &= ref['owner_rid'] in txt
ck('all source references and line ranges resolve',validrefs)
ck('each asserted owner RID occurs in its actual cited source',ridvalid)
ck('no owner adoption or new RRF profile is claimed',not any(r['adoption'].values()) and all(not e['new_owner_RID_assigned'] and not e['new_RRF_profile_registered'] for e in es))
rrf=(ROOT/r['sources']['RRF']['package_path']).read_text()
ck('any non-null profile is present in adopted RRF text',all(e['record']['carrier']['rrf_profile'] is None or e['record']['carrier']['rrf_profile'] in rrf for e in es))
alg=json.loads((ROOT/'data/algebra_checks.json').read_text())
ck('local evidence tags refer to existing records or framework theorem',all(k in ids+['RER-METHOD']for t in alg['checks']for k in t['entry_ids']))
ck('twenty-eight exact checks were actually successful',alg['check_count']==28 and len(alg['checks'])==28 and all(c['pass']for c in alg['checks']))
ck('all seven requested candidate categories retained',set(w['candidate']for w in r['candidate_watchlist'])=={'Cycle holonomy','Relational frustration','Coherence order parameter','Defect charge','Collective memory','Effective stiffness','Effective dimensionality'})
md=(ROOT/'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_1_DRAFT.md').read_text()
ck('Markdown has one detailed section per local record',all(md.count('### '+id+' — ')==1 for id in ids))
ck('generated human-readable file has no unexpected controls',not any(ord(c)<32 and c not in '\n\t\r'for c in md))
opened=False;blocks=0;bad=False;lines=md.splitlines()
for i,l in enumerate(lines):
 if l.strip()==r'\[':
  if opened:bad=True
  opened=True
 elif l.strip()==r'\]':
  if not opened:bad=True
  opened=False;blocks+=1;j=i+1
  while j<len(lines)and not lines[j].strip():j+=1
  if j>=len(lines)or not lines[j].strip().startswith(('(rep:','(transport:')):bad=True
ck('all displayed formulas balanced and profile/abstract-marked',blocks>0 and not opened and not bad)
byid={e['entry_id']:e for e in es}
ck('triad exact coupled closure is still explicitly pending',byid['RER-T02']['record']['closure_status']['status']=='STATIC_QUOTIENT_ONLY' and byid['RER-T03']['record']['closure_status']['status']=='DEFINED_DIAGNOSTIC_NOT_DERIVED_QUOTIENT')
ck('source-side memory result is not certified as finite network memory',not byid['RER-N01']['record']['memory']['finite_memory_closure_certified'])
(ROOT/'data/validation.json').write_text(json.dumps({'status':'mechanical validation only','count':len(checks),'all_pass':True,'checks':checks},indent=2)+'\n')
print('VALIDATION',len(checks),'PASS')
