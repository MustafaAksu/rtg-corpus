#!/usr/bin/env python3
"""Build a source-pinned initial working registry, not an owner adoption.

The source text is authoritative for imported claims. Local entry identifiers
are navigation keys, not new scientific RIDs or registered RRF profiles.
"""
from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT.parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_specs=[
 ('SPEC','Pasted text.txt','sources/REQUEST_SPECIFICATION.txt','user specification',[(1,226)]),
 ('METHOD',None,'sources/DSN_METHODOLOGY_v1_3.md','methodology, recovered from accepted-release archive',[(21,70),(270,318),(350,429),(547,588)]),
 ('TRIAD','RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6.md',None,'adopted scientific owner',[(1,18),(143,171),(309,333),(367,477),(547,718),(719,773)]),
 ('GEN','RTG_GENESIS_GEOMETRY_DSN_v2_8_5.md',None,'adopted scientific owner',[(1,14),(616,717),(718,805)]),
 ('DYAD','RTG_DYADIC_OSCILLATOR_DSN_v6_4_10.md',None,'adopted scientific owner',[(1,24),(382,442),(581,665)]),
 ('RRF','RTG_RRF_REPRESENTATION_REGISTRY_v0_7.md',None,'adopted working representation standard, not a physics owner',[(1,76),(78,199),(224,257),(272,308)]),
 ('NUM','RTG_NUMBER_GENESIS_DSN_v1_20_7.md',None,'scientific owner',[(1,18),(394,438),(1551,1598),(2341,2447)]),
 ('RECOG','RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md',None,'scientific owner; version-specific claims used',[(1,45),(691,725),(1002,1045)]),
 ('TDR','RTG_DISCRETE_GENESIS_DSN_v2_12_13.md',None,'discrete scientific owner; continuous-branch firewall retained',[(1,18),(519,595),(760,798)]),
 ('OPENM','RTG_OPEN_M_DSN_v0_7_1.md',None,'adopted scientific owner',[(1,18)]),
 ('OFN','RTG_ONTOLOGICAL_FOUNDATIONS_v0_8.md',None,'adopted ontology/model-selection owner',[(1,35)]),
]
sources={};excerpts=[]
for sid,original,rel,kind,ranges in source_specs:
 if rel is None:rel='sources/'+original
 dest=ROOT/rel
 if original and not dest.exists():shutil.copyfile(RUNTIME/original,dest)
 lines=dest.read_text().splitlines()
 sources[sid]={'source_id':sid,'filename':original or dest.name,'package_path':rel,'sha256':h(dest),'bytes':dest.stat().st_size,'lines':len(lines),'role':kind,
  'inspection':'Full attached specification; other sources read at the declared passages only. No source scientific certificate rerun.' if sid=='SPEC' else 'Named passages inspected; not a full fresh scientific audit of this source.',
  'read_ranges':[{'first':a,'last':min(b,len(lines))} for a,b in ranges]}
 excerpts.append({'source_id':sid,'sha256':h(dest),'ranges':[{'first':a,'last':min(b,len(lines)),'text':'\n'.join(f'{j}: {lines[j-1]}'for j in range(a,min(b,len(lines))+1))}for a,b in ranges]})
(ROOT/'data/SOURCE_MANIFEST.json').write_text(json.dumps(sources,indent=2)+'\n')
(ROOT/'data/SOURCE_EXCERPTS.json').write_text(json.dumps(excerpts,indent=2)+'\n')

def ref(src,section,lines=None,rid=None):
 return {'source_id':src,'section':section,'lines':lines,'owner_rid':rid}

def entry(id,title,level,owner,grade,origin,refs,carrier,obs,constraints,action,closure,memory,baseline,novelty,not_claimed,next_test,check_ids=None):
 return {'entry_id':id,'title':title,'level':level,'custodian_requested':owner,'review_status':'INITIAL_DRAFT_NOT_OWNER_ACCEPTED',
 'claim_status':grade,'claim_origin':origin,'source_refs':refs,
 'record':{'carrier':carrier,'observables':obs,'constraints':constraints,'transformation_law':action,'closure_status':closure,'memory':memory},
 'comparison_baseline':baseline,'information_assessment':novelty,'physical_emergence_status':'OPEN_NOT_ESTABLISHED_BY_THIS_ENTRY',
 'not_claimed':not_claimed,'next_test':next_test,'evidence_status':'Source reading plus only the specifically mapped new local checks; no historical certificate replay.',
 'local_algebra_checks':check_ids or [],'new_owner_RID_assigned':False,'new_RRF_profile_registered':False}

def car(model,state,profile,domain,clock):return {'model':model,'primitive_state':state,'rrf_profile':profile,'domain':domain,'clock':clock}
def act(text,physical='not selected by this registry'):return {'rule':text,'physical_status':physical}
def clo(code,statement,T=None):return {'status':code,'statement':statement,'specified_update':T,'minimality':'NOT_CLAIMED'}
def mem(lost,need,proved=False):return {'information_discarded_or_unresolved':lost,'possible_augmentation_or_requirement':need,'finite_memory_closure_certified':proved,'minimal_memory_dimension':None}

E=[]
E.append(entry('RER-T01','Unoriented triad Gram readout','Triad','Triadic / Genesis; OFN for physical interpretation','ALG','attached example and source carrier definitions, checked locally',
 [ref('SPEC','§3',[57,82]),ref('GEN','§§6.1,6.6',[616,633]),ref('TRIAD','§§6.15–6.16',[547,609])],
 car('Primitive two-mode carrier, not a specified standalone update','(s,c) ∈ V², V=R², metric B_G',None,'All carrier pairs; sign comparison uses Qs,Qc>0 and noncollinearity','no dynamics selected'),
 ['Y_G=(Qs,Qc,Isc), Qs=sᵀBs, Qc=cᵀBc, Isc=sᵀBc'],['Qs,Qc≥0; QsQc−Isc²≥0; the squared raw determinant is constrained by Gram data; its sign is not determined by them'],
 act('Invariant under common B-orthogonal frame change. Reflection reverses signed area; this is a kinematic comparison, not an adopted physical gauge.'),
 clo('OPEN_NO_COUPLED_MAP','Same Gram data do not determine signed orientation; no primitive coupled one-step or six-step closure claim.',None),
 mem('Orientation sign and common frame are not in Y_G.','Adding signed orientation resolves this static loss; it has not been proved sufficient dynamically.'),
 'Compare Y_G with the complete ordered pair (s,c).','Orientation is extra relative to Gram-only data, not extra relative to the full vectors.',
 ['No new substance, independent birth datum or physical chirality law is inferred.'],
 'Supply a branch-specific Tpost; find same Y_G with different Y_G after update, or prove fibre constancy.'))
E.append(entry('RER-T02','Signed triad Gram readout','Triad','Triadic / Genesis; RRF for any new transport','ALG','request §3–4 plus locally proved kinematic reconstruction',
 [ref('SPEC','§§3–4',[57,110]),ref('GEN','§§6.1,6.6',[774,792]),ref('RRF','§§0,2.5,6–7',[284,308])],
 car('Primitive B_G carrier; not identified with producer metric B_T','(s,c) ∈ V²',None,'Qs>0 reconstruction patch; other degeneracies separately noted','same as Tpost once supplied'),
 ['Y_O=(Qs,Qc,Isc,Omega_G)','Omega_G=(sqrt(3)/2)(s_eta c_rho−s_rho c_eta)'],
 ['QsQc−Isc²=Omega_G²; four numbers are constrained, not four freely independent coordinates.','At Omega_G=0 the orientation sign distinction disappears.'],
 act('Invariant under simultaneous orientation-preserving B-isometries; a B-reflection changes Omega_G→−Omega_G. This quotient is kinematic unless the actual model admits it.'),
 clo('STATIC_QUOTIENT_ONLY','On Qs>0, Y_O determines the pair up to a common proper B-isometry. No assertion that Tpost descends to this quotient.',None),
 mem('A common oriented frame is discarded by the quotient.','Its necessity for future Y_O must be tested against the actual vector law; no finite-memory closure supplied.'),
 'Compare signed Gram data with Y_G and with the full ordered pair.','Sign resolves a coarse-observable ambiguity. It does not add state data absent from the pair.',
 ['Kinematic orbit completeness does not imply physical gauge equivalence or autonomous evolution.','No isolated-dyad h is applied edgewise or to the coupled system.'],
 'Primary registry experiment: on one standalone K3 vector law, test Φ(Tx)=Φ(Tx′) whenever Φ(x)=Φ(x′).'))
E.append(entry('RER-T03','Root-closed T-6d diagnostic state','Triad / lifted K4 diagnostic','Triadic','DEF; ALG within the recorded diagnostic','adopted owner model definition; root identities checked locally',
 [ref('TRIAD','§6.4',[367,401]),ref('TRIAD','§6.18',[719,773]),ref('RRF','§7',[300,308])],
 car('M_root: recovered lifted diagnostic; NOT primitive standalone K3','(QsT,QcT,IT,r), fixed branch ε=±1',None,'QsT>0,QcT>0,r>0, QsT QcT−IT²>0 before guards','diagnostic ODE parameter; not an identified exact-return time-one map'),
 ['OmegaT=ε sqrt(QsT QcT−IT²)','mu=IT/sqrt(QsT QcT); nu=OmegaT/sqrt(QsT QcT); K=mu²+nu²'],
 ['K≡1; OmegaT is derived, not an extra independent state.','Root singularity QsTQcT−IT²=0 differs from the boundary of an ambient independent-orientation disk.','For identical planar vectors only: B_T=2B_G, Q_T=2Q_G, I_T=2I_G, OmegaT=−2OmegaG. This is not a birth/generator bridge.'],
 act('Branch, metric and normalized orientation are fixed as in the producer. Source relabel/phase conventions travel with the coefficients.'),
 clo('DEFINED_DIAGNOSTIC_NOT_DERIVED_QUOTIENT','The four-variable ODE is specified in the owner and is internally a closed diagnostic on its regular branch. That does not prove it is a reduction of primitive K3/K4.', 'Triadic v1.6 §6.4 equations, Ω reclosed from the root; branch stops at declared guards.'),
 mem('Independent orientation is not a hidden fifth state in M_root; branch continuation remains unprovided.','Do not add K<1 data by substituting into the root model. Specify a different carrier and law first.'),
 'Compare a defined reduced diagnostic with a claimed descent from a separate microscopic map.','A closed set of prescribed ODE formulas is not itself an emergence theorem.',
 ['No historical wedge, x*, inward/outward sector, no-basin or fatal classification is current corrected-model evidence.','K≡1 does not freeze QsT,QcT or r.'],
 'Recover or identify the exact source-to-diagnostic map and clock before testing dynamical descent.'))
E.append(entry('RER-T04','Generated child: new role versus independent birth datum','Triad birth','Genesis / Triadic; identity semantics with OFN/RRF','ALG under stated trial; source birth family retains its owner scope','source-leading family with explicitly chosen exact diagnostic graph',
 [ref('GEN','§6.3',[669,717]),ref('TRIAD','§6.1',[309,333]),ref('SPEC','§§1,3,6',[12,33])],
 car('Exact diagnostic trial, not full adopted physical birth contract','s∈V; iota_kappa(s)=(s,kappa Qs J_Qs)',None,'fixed real kappa; nonzero new direction requires s≠0 and kappa≠0','instant of initialization only'),
 ['retained s; child c=kappa Qs J_Qs','Gram_B(s,c)=diag(Qs,kappa² Qs³)'],
 ['Projection to s is a left inverse; rank D iota=2.','Common full birth family has additional higher-order terms and unsolved policy/retention/event choices; it is not replaced by this graph.'],
 act('The original marked/ordered role structure is supplied for this trial. No pole-swap quotient, source attachment, or physical extra direction follows from it.'),
 clo('EVENT_ONLY_NO_EVOLUTION','Initialization is deterministic in s. Dynamical reducibility requires an independent Tpost and Tpost iota=iota Tpre.',None),
 mem('No independent child datum was supplied by this exact graph.','Need complete identity/retention/attachment and a post-event map; do not encode the desired reduction by definition.'),
 'Compare input dimension with output representation dimension.','New nonzero geometric direction is not new independently specified birth data.',
 ['No physical event predicate or physical kappa is selected.','No preservation of this graph under evolution is claimed.'],
 'Obtain the specified branch Tpost and evaluate its defect from the embedded image.'))
E.append(entry('RER-T05','Jacobi blocks and geometric dimensionality','Triad / K4','Triadic / Genesis','ALG; source scope correction','adopted mode/carrier distinction plus local example',
 [ref('GEN','§6.4',[718,731]),ref('TRIAD','§6.16',[584,609])],
 car('Three Jacobi mode blocks in one value carrier','(s,c,d)∈V³; V=R² with B_G',None,'mode block coordinates with declared incidence weights','no autonomous dynamics asserted'),
 ['mode-label independence; carrier and product-space ranks; primitive seed norms'],
 ['s,J_Qs span one V for s≠0, not the six-dimensional product V³.','Different product blocks can be orthogonal while their carrier values are identical/nonorthogonal.'],
 act('Jacobi-label transformations and transformations in V are different actions; a physical spatial embedding is a separate construction.'),
 clo('STATIC_TYPING_ONLY','No dynamics or emergent spatial dimension follows from a rank or label count.',None),
 mem('Rank of a displayed carrier does not classify independent historical data.','Supply enlarged metric/embedding/source map for a physical-dimension claim.'),
 'Separate mode index space, product state space, and physical geometry.','Mode structure is derived; physical extra dimension remains unestablished.',
 ['No apex–UV-slot identification; d block/seed are not erased.'],
 'Only after an embedding is defined, test rank invariance and stability of its declared metric/observable.'))
E.append(entry('RER-D01','Full lifted dyad in the registered W-frame','Dyad','Dyadic / RRF','DEF; ALG transport','registered invertible representation',
 [ref('RRF','§§2.2–2.3,3',[94,126]),ref('RRF','T-L',[184,199]),ref('GEN','§6.1',[616,633])],
 car('Selected primitive continuous T','(rho,eta) on the lift; W=rho−eta/2+i sqrt(3)eta/2','RRF-DYAD-W','lifted local domain; do not replace eta with wrapped angle silently','one T step or explicitly six-step F_W'),
 ['Re W, Im W; Qprim=|W|²','F_W=L T^6 L^{-1}'],['L is invertible; no phase or lift information is lost on the specified branch.'],
 act('Use registered T-L. Registered S_h, naive sign and wrapped inversion remain different unless their stated transports identify them.'),
 clo('EXACT_INVERTIBLE_TRANSPORT','Complete W coordinates support the transported deterministic update exactly. This is a full-state representation, not compression to collective amplitude.', 'F_W=L T^6 L^{-1}, fixed primitive T'),
 mem('No loss relative to the specified lifted state.','No extra memory is required for this full-state update; minimality among arbitrary representations is not claimed.',True),
 'Compare real lifted coordinates with their invertible complex frame.','Representation change, not independent emergence.',
 ['No dyad-to-network identification follows.'],
 'Use as the exact reference when testing reduced observables.'))
E.append(entry('RER-D02','Dyadic amplitude alone','Dyad','Dyadic; new registry-local nonclosure check','ALG','new exact local counterexample using the specified T; proof in checks note',
 [ref('DYAD','§6.14 primitive contraction / radial jet',[640,659], 'DYAD-THM-PRIM-CTR'),ref('SPEC','§§4B,6',[104,142])],
 car('Selected primitive continuous T, six-step return','(rho,eta) on common small lifted domain','RRF-DYAD-W','sufficiently small nonzero t; both (t,0) and (−t,0) admitted','exact T^6'),
 ['Y=Qprim=rho²−rho eta+eta²'],['Same input Y=t² at (t,0) and (−t,0).'],
 act('Q is invariant under kinematic B-isometries; that does not make T covariant under the whole group.'),
 clo('DISPROVED_EXACT_CLOSURE','Q(T^6(t,0))−Q(T^6(−t,0))=−5t^5/12+O(t^7), nonzero for sufficiently small positive t. No deterministic exact Q-only update on that common domain.', 'fixed primitive T^6, not angular-average or surrogate map'),
 mem('Direction/phase discarded by Q changes its next value.','Retain more state or prove a memory closure; no minimal augmentation or universal scalar history reconstruction proved.'),
 'Compare Q-only readout with the complete W state.','Contraction is not scalar autonomy. Counterexample identifies lost angular information, not physical new memory.',
 ['No finite numerical radius for this sign witness; no failure of the owner contraction theorem.','No inference that every triad collective readout fails.'],
 'Test a specified phase/lift augmentation; only register closure after a fibre test or exact transport.'))
E.append(entry('RER-D03','Admitted recurrence labels, winding and phase data','Dyad / Number Genesis','Number Genesis / Dyadic','OPEN','specification seed with restricted source context, not a fabricated label map',
 [ref('SPEC','§§1,6',[12,33]),ref('NUM','§§6.2,6.6',[394,438])],
 car('Must be fixed per Number Genesis comparison/history sector','Primitive state plus the specifically admitted label/history construction',None,'Owner admission and event/clock conditions not replaced by a universal (p,n) coordinate pair','owner-specific event or recurrence block'),
 ['relative phase, winding, and intended (p,n) labels: exact pair-to-carrier map NOT instantiated in this registry'],
 ['Labels must retain their owner meanings, admissibility, orientation and time convention.'],
 act('Use the owner-specific comparison map; no general label-to-phase or continuous/discrete bridge is supplied.'),
 clo('OPEN_LABEL_MAP_AND_UPDATE','A list of labels is not a complete state or a closed update. Exact intended definitions and their readout must be pinned before testing.',None),
 mem('Winding or recurrence labels may use a trajectory, not only a present state.','Declare which history/lift is read and how it updates; no extra independent data inferred from a deterministic label.'),
 'Compare candidate label-augmented readout with its actual source domain.','No novelty claim before the source map is specified.',
 ['p,n are not adopted as universal coordinates for every dyad.'],
 'Request the exact label definitions, owner RID or source block, and admitted map Phi into this proposed state.'))
E.append(entry('RER-C01','Triangle phase holonomy: node-exact versus edge-independent','Triad / larger cycles','RRF / Number Genesis; TDR only its node-exact branch','ALG under declared branch','attached example, source null theorem and exact local tests',
 [ref('SPEC','§2',[35,55]),ref('RRF','§§2.5,5–7',[272,308]),ref('TDR','§6.2',[535,547])],
 car('Two distinct constructions: node phases or independent phase edges','delta_AB,delta_BC,delta_CA ∈ R/(2pi Z)',None,'cycle labels and orientations fixed; multiplicative network realization unregistered','no network update supplied'),
 ['H_ABC=exp(i(delta_AB+delta_BC+delta_CA))'],
 ['Node-exact delta_ij=theta_j−theta_i forces H=1.','Independent phase-edge/connection data permit H≠1 algebraically.','The request uses theta_j−theta_i; TDR uses theta_i−theta_j modulo N. Null sums agree; orientation must not be silently swapped for nonzero content.'],
 act('Under the explicitly proposed vertex law delta_ij→delta_ij+alpha_j−alpha_i, H is invariant. This is not TDR’s adopted global-phase quotient or a newly registered physical local gauge.'),
 clo('KINEMATIC_NULL_OR_CONTENT_ONLY','Gauge invariance is established for the stated formula; no autonomous update for H is supplied.',None),
 mem('Cycle sum/product discards how phase is distributed among edges and any node potentials.','A reduced H law requires fibre consistency of the actual edge update; history might be needed but is not certified.'),
 'Compare node-generated edges with independently admitted edge data.','A collective observable can be identically trivial. Nonzero content is not inferred from existence of a cycle.',
 ['No multiplicative edge realization is registered by this example; no curvature theorem.'],
 'Fix an admitted edge branch and update, then test same H/different next H.'))
E.append(entry('RER-C02','Additive cycle content and cohomology class','Larger cycles / network','Number Genesis / RRF','ALG (owner-reported NG-7A); local triangle checks only','source-derived operator registry',
 [ref('NUM','§6.8 NG-7A',[2341,2447],'NUMGEN-OPEN-REC-HOL-OPERATOR'),ref('RRF','§§2.5,5',[164,177])],
 car('Finite directed graph with declared coefficient field/module','edge cochain a; incidence D and cycle operator C','RRF-NET-W-RAW','profile holds only for matching additive raw-edge realization; general operator layer independently typed','no source edge dynamics admitted here'),
 ['h=Ca; [a] modulo im Dᵀ; scalar channel observable is h or [a], not a rank','r_hol=rank(CA) only for genuinely multichannel data, with owner conditions'],
 ['CDᵀ=0; node-mediated a=Dᵀx has h=0.','NG-7A completeness uses a cycle basis / the stated fundamental-integral construction, not arbitrary rescaled rows.'],
 act('Vertex addition a→a+Dᵀg preserves h; basis changes transform h; invariant class/zero set as specified by owner. Incidence bookkeeping is not S_h.'),
 clo('OPERATOR_CLASSIFICATION_ONLY','Source operator invariants are established; no map a↦a+ or autonomous h update supplied by NG-7A.',None),
 mem('h removes exact/potential edge components.','Prove that those removed components cannot affect future h, or retain the required state. No finite-memory closure is imported.'),
 'Cycle capacity beta versus actual content h; node-potential branch versus general cochain.','Nonintegrability content can be independent of node potentials only in the admitted edge construction.',
 ['NG-7B positive physical source, non-Abelian extension and curvature remain OPEN.'],
 'Supply the network cochain dynamics and interface, then apply the exact fibre criterion.'))
E.append(entry('RER-P01','Discrete node phases and relative advance','Node / dyad','TDR-G','DEF and new exact local counterexample','source state/step definition, not a continuous-branch import',
 [ref('TDR','§§6.1–6.3',[519,595])],
 car('Discrete phase/token model with fixed N and chosen policy','(theta_i,delta_i) ∈ Z_N^{2M}, variable M permitted',None,'N even, model-specific k; state modulo common phase shift','CONV-TICK, advance then snapshot/classify/apply'),
 ['node phase where admitted; relative phases Delta_ij and relative advances d_ij'],
 ['Delta_ij=theta_i−theta_j mod N; next pre-event Delta=Delta+d.','Complete event handling requires policy and topology; no continuous birth rule imported.'],
 act('Source physical quotient is common phase shift; no arbitrary token translation gauge is inferred.','as stated in the discrete source only'),
 clo('PHASE_ONLY_DISPROVED','For N=12,k=0, theta=(0,1) with tokens (0,0) or (0,1) has equal current phases but different next relative phases, with no defect event. Relative advance is necessary for this readout.', 'one source no-defect tick on the two-node sector'),
 mem('Phase-only readout discards tokens/advance.','Include the required token/relative-advance data for the specified sector; full event closure still needs the declared policy.'),
 'Compare phases-only with the source phase/token state.','Node phase is an admitted model primitive, not a universal ontology commitment.',
 ['No physical continuous↔discrete bridge; no phase-only closure through births.'],
 'Use source full-state quotient as a reference; audit motif-only reductions with fixed policies.'))
E.append(entry('RER-N01','Retained memory versus a closed collective state','Network candidate; isolated-dyad source','RECOG / Triadic / RRF','THM source-reported for R9; OPEN for network closure','source R9 and CELL-F4 obligations, no certificate rerun',
 [ref('RECOG','§6.13a',[691,709],'RECOG-THM-R9-MEMORY'),ref('RECOG','§6.16g',[1002,1045],'RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS')],
 car('R9 is an exact single-dyad h-chart object; network carrier is not supplied','q=|z|², continuous phase lift Θ along one orbit','RRF-DYAD-NF','Source R9 paired rows: (C2,qmax)=(517,1/400) at radius1/20; (163,1/1600) at radius1/40; incompleteness windows q<|G|/C2 are smaller','exact normalized six-step return'),
 ['M(z0)=Psi_infty−Psi(z0), Psi=Θ−(2sqrt(3)/3)log q; C_z is the certified comparator track'],
 ['Do not mix native C_z with transported raw comparator.','A trajectory functional/retained phase is not by itself a declared finite-dimensional memory state for a network reduction.'],
 act('Use registered h pullback and source track; network inheritance requires OPEN-B/E and RECOG W1–W5.'),
 clo('OPEN_NETWORK_MEMORY_CLOSURE','R9 proves a scoped asymptotic memory result and comparator incompleteness, not Y+,M+ closure for a triad/network.',None),
 mem('Chosen comparator can omit phase relevant to retained memory.','Need actual network state, event attachment, cochain update, conditioning quotient and an identified memory state; minimality OPEN.'),
 'Instantaneous comparator versus full state/orbit; source result not promoted across an absent network arrow.','Information retained beyond a chosen readout is relative, not evidence of new independently generated data.',
 ['No one-memory-variable network closure, physical event-gated write-through or independent emergence theorem.'],
 'Use the W1–W5 request to define a network interface before evaluating a memory-augmented closure test.'))
E.append(entry('RER-N02','Effective stiffness of collective modes','Network / UV candidate','OPEN-M / Genesis / Triadic','OPEN','candidate from specification, bounded by current OPEN-M source',
 [ref('SPEC','§5',[145,163]),ref('OPENM','header / current scope',[1,18])],
 car('A coupled mechanism and receiver interface must be specified','complete coupled state plus declared perturbation coordinate',None,'background, metric/lowering, zero section and allowed fibre frames required','force, map or flow must be distinguished'),
 ['candidate effective stiffness: derivative/response of the specified coupled law; no numerical value registered'],
 ['Source, background and restoring block must be derived and transported together.','Hessian, covariant stiffness and update-space retention are not automatically the same tensor.'],
 act('Use the declared source/receiver actions and admissible frame subgroup; neither is selected here.'),
 clo('OPEN_DEFINITION_AND_LAW','No source-independent effective stiffness state or closed update supplied.',None),
 mem('Eliminated receiver/internal modes can carry history.','Any memoryless elimination or effective response needs its own derivation/domain.'),
 'Microscopic response versus a proposed effective mode coefficient.','A postulated interaction is not a derived emergent stiffness.',
 ['No certified numerical source-deficit calibration or physical UV mechanism is imported.'],
 'Obtain one joint source/restoring response from an independently specified mechanism.'))
E.append(entry('RER-N03','Defect and motif distributions','Network','TDR-G; no direct continuous import','DEF source; OPEN closure','source observables, no distribution dynamics derived',
 [ref('TDR','§6.11',[760,798]),ref('SPEC','§5',[145,163])],
 car('Discrete graph induced from phases under fixed policy','complete phase/token state and CONV-TICK snapshot',None,'N,k,policy,cap and pre/post measurement convention fixed','per-step or stated late-window aggregate'),
 ['defect edges; node count; clean-star and multistar counts; source motif frequencies'],
 ['Counts, fractions, windows and ratio-of-sums are distinct source observables.','Defect distribution does not automatically determine phase/token arrangement.'],
 act('Permutations and phase-shift interpretation require the same incidence/policy and measurement convention.'),
 clo('OPEN_DISTRIBUTION_CLOSURE','Definitions and numerical source statistics do not provide an autonomous update for their reduced distribution.',None),
 mem('Spatial/incidence arrangement, tokens and earlier event data may be hidden from counts.','Seek two full states with identical selected distributions and different next distributions under one policy.'),
 'Full discrete state versus motif/count readout.','Collective statistics may be useful without being autonomous state variables.',
 ['No conservation law for defect charge or universal effective equation inferred from the existing statistics.'],
 'Fix one motif-vector readout and perform an exact capped-state fibre test; no sweep executed here.'))
E.append(entry('RER-E01','Role inheritance across a clean-star event','Evolving network','TDR-G / OFN; Triadic comparison only','DEF source; OPEN post-event reduction','source exact local event, different arity from continuous birth',
 [ref('TDR','§6.3',[549,590]),ref('SPEC','§§1,6–7',[164,214])],
 car('Marked isolated post-advance K1,3 event','four existing labels (A,L1,L2,L3) and phase/tokens; fresh E',None,'literal clean star in declared narrow-band branch; not a general multistar policy','4→5 event; snapshot before update and no same-tick child advance'),
 ['theta_E+=theta_A−+N/2; delta_E+=delta_A−; delta_A+=−delta_A− (mod N)','old role labels persist; new role values are determined by the snapshot'],
 ['The event is 4→5, not continuous Phi_2to3.','Provided marks and known event type can permit reconstruction; no unmarked-history theorem imported.'],
 act('Global phase shift covariant; label identity is supplied in the indexed reference construction. Generated-from is not identical-to.'),
 clo('EVENT_ONLY_NO_REDUCTION','Deterministic newborn initialization does not prove later dynamics remains a representation of the parent system.',None),
 mem('Unmarked histories and reduced event logs can discard state.','State retention and event/readout conventions must be specified before memory or no-erasure claims.'),
 'Role count versus number of independently specified event inputs.','A new represented role can be deterministic; ontological division does not follow.',
 ['No dyad-first identity theorem, continuous/discrete bridge, or source-law equivalence.'],
 'Specify complete pre/post systems and a proposed embedding before testing an intertwining identity.'))
E.append(entry('RER-G01','Metric, curvature and effective dimensionality','Geometric regime','Genesis / OFN / OPEN-M; RRF transport','OPEN','specification candidate with existing primitive rank guard',
 [ref('SPEC','§§1,5',[12,33]),ref('GEN','§6.4',[718,731]),ref('RRF','§§5–8',[272,324]),ref('OFN','scope / model selection',[1,35])],
 car('Admissible relational structure and metric/connection not yet jointly supplied','graph/state plus explicitly defined metric, embedding, operator or cochain',None,'branch-dependent; no universal geometric carrier inferred','evolution and scale to be specified'),
 ['candidate rank, metric response, spectral/dimensional diagnostic or curvature observable; none selected as a universal RTG variable'],
 ['Product-space dimension, cycle rank, holonomy rank, metric rank and spatial dimension are different objects.','Nonzero cycle content is not automatically curvature; primitive d-mode is not a physical transverse UV direction.'],
 act('Each candidate requires its own transformation group and invariant meaning; no profile registered here.'),
 clo('OPEN_PHYSICAL_AND_EFFECTIVE_MODEL','No derived closed dynamics or physical geometry bridge is claimed.',None),
 mem('Scale dependence and eliminated structure may affect an effective diagnostic.','Specify readout and actual dynamics; memory requirement untested.'),
 'Mathematical structure rank/response versus independently realized physical geometry.','Physical emergence remains a construction target.',
 ['No spatial-dimension theorem, metric/curvature production or topology-selection claim.'],
 'Propose one invariant diagnostic on a defined carrier, then test stability and closure before physical interpretation.'))

watch=[
 {'candidate':'Cycle holonomy','entry_ids':['RER-C01','RER-C02'],'definition_status':'specified conditional operator/phase constructions','scientific_test':'Independence from node potentials; then actual-update closure.'},
 {'candidate':'Relational frustration','entry_ids':[],'definition_status':'OPEN: no preferred-edge states or admissible compatibility functional selected','scientific_test':'Define the local preferences and global compatibility target; test persistence under an actual coupled update.'},
 {'candidate':'Coherence order parameter','entry_ids':[],'definition_status':'OPEN: no phase-alignment formula or weight convention selected','scientific_test':'Select a source-admissible observable and test same-readout successor consistency.'},
 {'candidate':'Defect charge','entry_ids':['RER-N03'],'definition_status':'OPEN: defect counts exist; charge/quantization/conservation do not follow','scientific_test':'Specify the charge and test conservation, transport or event production separately.'},
 {'candidate':'Collective memory','entry_ids':['RER-N01'],'definition_status':'isolated R9 source exists; network memory state and closure OPEN','scientific_test':'Define actual network readout and history conditioning, then exhibit or reject a finite augmentation.'},
 {'candidate':'Effective stiffness','entry_ids':['RER-N02'],'definition_status':'OPEN coupled mechanism/interface','scientific_test':'Derive response from the same source update and transport the complete tensor/background data.'},
 {'candidate':'Effective dimensionality','entry_ids':['RER-G01','RER-T05'],'definition_status':'OPEN physical interpretation; no particular spectral estimator invented','scientific_test':'Choose a defined relational diagnostic, check invariance, dynamic stability and scale/metric meaning.'},
]
methods={
 'closure_criterion':{'grade':'THM','origin':'attached specification §4B; elementary proof supplied in this registry','owner_RID':None,
 'assumptions':'T:X→X deterministic on the declared invariant domain; Phi:X→Y; dynamics on Phi(X). For partial/event maps, admissibility must be included or saturated on fibres.',
 'statement':'There exists F:Phi(X)→Phi(X) with Phi∘T=F∘Phi iff Phi(x)=Phi(x′) implies Phi(Tx)=Phi(Tx′). F is unique on Phi(X).',
 'proof':'Necessity follows by applying F. For sufficiency set F(y)=Phi(Tx) for any x with Phi(x)=y. Fibre constancy makes this well-defined; T(X)⊆X supplies codomain. Uniqueness follows from surjectivity onto Phi(X).',
 'scope':'Set-map closure only: smoothness, computability, physical quotient, minimality and finite-memory claims need separate hypotheses.'},
 'required_six_fields':['carrier','observables','constraints','transformation_law','closure_status','memory'],
 'emergence_distinctions':['Model-derived property','Constructed effective description','Unestablished physical emergence'],
 'memory_contract':'If Y does not close, a proposed (Y,M) or history law must itself pass a corresponding closure test. R9 is not such a network proof. Variables computed from fixed known x add no independent input automatically.',
 'no_forced_hierarchy':'The seven-level table is a proposed organizational index, not a proved chain of maps. Undefined transitions are recorded, not constructed from shared notation.'}
queue=[
 {'priority':1,'task':'T-START','description':'Fix one standalone K3 microscopic vector law (or source cubic jet with accuracy label), incidence, normalization and clock; not K4|d=0 by default.','requested_from':['Triadic','Genesis'],'unresolved_in_this_registry':True},
 {'priority':2,'task':'T-FIBRE','description':'Test oriented Gram readout against that law: identify its fibres and transport/admissibility; prove closure or record a pair witness.','requested_from':['Triadic','RRF'],'unresolved_in_this_registry':True},
 {'priority':3,'task':'T-MEMORY','description':'Only after a witnessed failure, propose a concrete state/history augmentation and verify its update; minimality remains a separate task.','requested_from':['Triadic','RECOG'],'unresolved_in_this_registry':True},
 {'priority':4,'task':'C-NET','description':'Supply admitted edge realization, cycle operator and coupled edge/event update; run cycle/holonomy closure test.','requested_from':['Number Genesis','RRF','OFN'],'unresolved_in_this_registry':True},
]
reg={'title':'RTG Relational Emergence Registry','version':'0.1','date':'2026-10-08','status':'WORKING_DRAFT_NONCANONICAL','profile':'working infrastructure/research registry; no scientific-owner transfer',
 'requested_basis':'Pasted text.txt; source organization and definitions retained, with explicit model-specific typing and gaps',
 'lead':'Triadic branch, proposed joint Ontology–DYAD–Triadic–RRF study; other owner review not claimed',
 'naming':'RER-* are local navigation keys only, not new scientific RIDs or RRF profiles.',
 'sources':sources,'methods':methods,'entries':E,'candidate_watchlist':watch,'next_tests':queue,
 'adoption':{'registry_adopted':False,'owner_files_modified':False,'source_grades_changed':False,'physical_model_selected':False,'consumer_acceptance_claimed':False},
 'scope_of_new_checks':'Only the independent local algebra listed in data/algebra_checks.json; no historical numerical/analytic certificates rerun.',
 'history':[{'version':'0.1','date':'2026-10-08','action':'initial construction from attached specification, triad-first; source evidence and newly checked consequences separated'}]}
# Each entry's status describes its scoped primary statement; closure and adoption are independent fields.
primary = {'RER-T01':'ALG','RER-T02':'ALG','RER-T03':'DEF','RER-T04':'ALG','RER-T05':'ALG','RER-D01':'DEF','RER-D02':'ALG','RER-D03':'OPEN','RER-C01':'ALG','RER-C02':'ALG','RER-P01':'ALG','RER-N01':'THM','RER-N02':'OPEN','RER-N03':'DEF','RER-E01':'DEF','RER-G01':'OPEN'}
for ent in E:
    ent['status_explanation']=ent['claim_status']
    ent['claim_status']=primary[ent['entry_id']]
    if ent['entry_id']=='RER-C02':
        ent['record']['carrier']['rrf_profile']=None
        ent['record']['carrier']['profile_application']='Only a separately matched complex raw-edge realization a=W_net uses RRF-NET-W-RAW. General NG-7A cochains are not identified with that profile by this registry.'
# Attach fresh local test names to precisely matching entry IDs.
checks=json.loads((ROOT/'data/algebra_checks.json').read_text())
for e in E:e['local_algebra_checks']=[r['name'] for r in checks['checks'] if e['entry_id'] in r['entry_ids']]
(ROOT/'data/REGISTRY.json').write_text(json.dumps(reg,indent=2,ensure_ascii=False)+'\n')
print('Built registry:',len(E),'populated entries;',len(watch),'candidate agenda rows;',len(sources),'source identities')
