#!/usr/bin/env python3
"""Regenerate and validate the registry from bundled source data; no source writes."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
before={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'sources').rglob('*')if p.is_file()}
jobs=[('algebra','check_registry_algebra.py',[],0,None),('registry','build_registry.py',[],0,None),('schema','create_schema.py',[],0,None),('markdown','render_registry.py',[],0,None),('validation','validate_registry.py',[],0,None),('negative_gram','check_registry_algebra.py',['--negative','gram-is-complete'],1,'FALSE CONTROL: Gram-only data determine signed orientation'),('negative_amplitude','check_registry_algebra.py',['--negative','q-is-closed'],1,'FALSE CONTROL: radial contraction implies a closed Q-only update')]
res=[]
for label,script,args,expected,marker in jobs:
 cp=subprocess.run([sys.executable,'-B',str(ROOT/'scripts'/script),*args],cwd=ROOT,capture_output=True,text=True,timeout=40,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 (ROOT/'logs'/f'{label}.stdout.log').write_text(cp.stdout);(ROOT/'logs'/f'{label}.stderr.log').write_text(cp.stderr)
 ok=cp.returncode==expected
 if marker:ok=ok and ('FAIL '+marker)in cp.stdout and 'AssertionError' in cp.stderr
 res.append({'job':label,'expected_exit':expected,'actual_exit':cp.returncode,'accepted':ok,'PASS_lines':sum(l.startswith('PASS ')for l in cp.stdout.splitlines()),'FAIL_lines':sum(l.startswith('FAIL ')for l in cp.stdout.splitlines()),'stderr_bytes':len(cp.stderr.encode())})
 print(('PASS 'if ok else 'FAIL ')+label+' exit='+str(cp.returncode),flush=True)
 if not ok:print(cp.stdout,cp.stderr);raise SystemExit(1)
after={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (ROOT/'sources').rglob('*')if p.is_file()}
assert before==after,'Bundled source changed'
(ROOT/'data/RUN_STATUS.json').write_text(json.dumps({'runs':res,'sources_unchanged':True},indent=2)+'\n')
