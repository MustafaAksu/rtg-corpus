from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
text={'type':'string','minLength':1}
arraytext={'type':'array','minItems':1,'items':text}
nullable={'anyOf':[text,{'type':'null'}]}
record={'type':'object','required':['carrier','observables','constraints','transformation_law','closure_status','memory'],
 'properties':{'carrier':{'type':'object','required':['model','primitive_state','rrf_profile','domain','clock'],'properties':{'model':text,'primitive_state':text,'rrf_profile':nullable,'domain':text,'clock':text}},
 'observables':arraytext,'constraints':arraytext,
 'transformation_law':{'type':'object','required':['rule','physical_status'],'properties':{'rule':text,'physical_status':text}},
 'closure_status':{'type':'object','required':['status','statement','specified_update','minimality'],'properties':{'status':text,'statement':text,'specified_update':nullable,'minimality':{'const':'NOT_CLAIMED'}}},
 'memory':{'type':'object','required':['information_discarded_or_unresolved','possible_augmentation_or_requirement','finite_memory_closure_certified','minimal_memory_dimension'],
 'properties':{'information_discarded_or_unresolved':text,'possible_augmentation_or_requirement':text,'finite_memory_closure_certified':{'type':'boolean'},'minimal_memory_dimension':{'type':['integer','null'],'minimum':0}}}},'additionalProperties':False}
entry={'type':'object','required':['entry_id','title','level','custodian_requested','claim_status','claim_origin','source_refs','record','comparison_baseline','information_assessment','physical_emergence_status','not_claimed','next_test','new_owner_RID_assigned','new_RRF_profile_registered'],
 'properties':{'entry_id':{'type':'string','pattern':'^RER-[TDCNPGE][0-9]{2}$'},'title':text,'level':text,'custodian_requested':text,
 'claim_status':{'enum':['DEF','ALG','THM','NUM','HEUR','HYP','OPEN']},'claim_origin':text,
 'source_refs':{'type':'array','minItems':1,'items':{'type':'object','required':['source_id','section','lines','owner_rid'],'properties':{'source_id':text,'section':text,'lines':{'type':['array','null'],'items':{'type':'integer','minimum':1},'minItems':2,'maxItems':2},'owner_rid':nullable}}},
 'record':record,'comparison_baseline':text,'information_assessment':text,'physical_emergence_status':{'const':'OPEN_NOT_ESTABLISHED_BY_THIS_ENTRY'},'not_claimed':arraytext,'next_test':text,
 'new_owner_RID_assigned':{'const':False},'new_RRF_profile_registered':{'const':False}}}
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Initial RTG relational-emergence registry schema','type':'object',
 'required':['title','version','date','status','sources','methods','entries','candidate_watchlist','adoption','history'],
 'properties':{'title':text,'version':{'const':'0.1'},'date':{'const':'2026-10-08'},'status':{'const':'WORKING_DRAFT_NONCANONICAL'},'sources':{'type':'object','minProperties':1},'entries':{'type':'array','minItems':1,'items':entry},
 'methods':{'type':'object','required':['closure_criterion','required_six_fields']},'candidate_watchlist':{'type':'array','minItems':7},
 'adoption':{'type':'object','required':['registry_adopted','owner_files_modified','source_grades_changed','physical_model_selected','consumer_acceptance_claimed'],'additionalProperties':{'const':False}}}}
(ROOT/'data/REGISTRY.schema.json').write_text(json.dumps(schema,indent=2)+'\n')
print('Created local schema')
