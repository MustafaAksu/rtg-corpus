#!/usr/bin/env python3
"""Initial relational-emergence registry checks, not a physical emergence certificate.

Exact SymPy algebra and an independent Fraction-based T^6 real-ray jet.
Source theorem certificates are NOT rerun. No owner files are imported or changed.
Two negative controls reject confusing unoriented Gram data with orientation,
and confusing local contraction with a scalar autonomous amplitude map.
"""
from __future__ import annotations
import argparse, json, sys
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import sympy as s
ROOT=Path(__file__).resolve().parents[1]

def ray_return(degree: int=5):
    def add(*ps): return [sum(v,F(0)) for v in zip(*ps)]
    def scale(p,c):return [x*c for x in p]
    def mul(p,q):
        a=[F(0)]*(degree+1)
        for i,x in enumerate(p):
            for j,y in enumerate(q):
                if i+j<=degree:a[i+j]+=x*y
        return a
    def powp(p,n):
        a=[F(1)]+[F(0)]*degree
        for _ in range(n):a=mul(a,p)
        return a
    rho=[F(0),F(1)]+[F(0)]*(degree-1);eta=[F(0)]*(degree+1)
    for _ in range(6):
        si=add(*(scale(powp(eta,n),F((-1)**((n-1)//2),factorial(n))) for n in range(1,degree+1,2)))
        ex=add(*(scale(powp(rho,n),F(1,factorial(n))) for n in range(1,degree+1)))
        rho,eta=add(rho,scale(si,-1)),add(eta,ex,scale(si,-1))
    q=add(mul(rho,rho),scale(mul(rho,eta),-1),mul(eta,eta))
    return rho,eta,q

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--negative',choices=['gram-is-complete','q-is-closed'])
    args=ap.parse_args();records=[]
    def check(name,ok,entry_ids):
        ok=bool(ok);records.append({'name':name,'pass':ok,'entry_ids':entry_ids})
        print(('PASS ' if ok else 'FAIL ')+name,flush=True)
        if not ok:raise AssertionError(name)
    def eq(a,b):
        if isinstance(a,s.MatrixBase):return all(s.simplify(v)==0 for v in a-b)
        return s.simplify(s.expand(a-b))==0
    x,y,u,v=s.symbols('s1 s2 c1 c2',real=True)
    sv=s.Matrix([x,y]);cv=s.Matrix([u,v]);B=s.Matrix([[1,-s.Rational(1,2)],[-s.Rational(1,2),1]])
    J=s.Matrix([[1,-2],[2,-1]])/s.sqrt(3)
    LE=s.Matrix([[1,-s.Rational(1,2)],[0,s.sqrt(3)/2]])
    Q=lambda a:s.expand((a.T*B*a)[0])
    I=lambda a,b:s.expand((a.T*B*b)[0])
    w=lambda a,b:s.expand(a[1]*b[0]-a[0]*b[1])
    Om=lambda a,b:s.sqrt(3)*w(a,b)/2
    check('primitive B positive definite',B[0,0]>0 and B.det()==s.Rational(3,4),['RER-T01','RER-T02'])
    check('real eigenframe implements the B norm',eq(LE.T*LE,B),['RER-D01','RER-T02'])
    check('quarter turn has J^2=-I and preserves B',eq(J*J,-s.eye(2)) and eq(J.T*B*J,B),['RER-T02','RER-T04'])
    check('raw determinant Gram factor is 3/4',eq(Q(sv)*Q(cv)-I(sv,cv)**2,s.Rational(3,4)*w(sv,cv)**2),['RER-T01','RER-T02'])
    check('signed normalized Gram constraint exact',eq(Q(sv)*Q(cv)-I(sv,cv)**2,Om(sv,cv)**2),['RER-T02'])
    a=s.Matrix([1,0]);b=J*a;bn=-b
    check('explicit two configurations have identical Gram-only readout',Q(a)==1 and Q(b)==Q(bn)==1 and I(a,b)==I(a,bn)==0,['RER-T01'])
    check('those configurations have opposite nonzero orientation',Om(a,b)==-1 and Om(a,bn)==1,['RER-T01','RER-T02'])
    if args.negative=='gram-is-complete':check('FALSE CONTROL: Gram-only data determine signed orientation',eq(Om(a,b),Om(a,bn)),['RER-T01'])
    qs,qc,ic,oc=s.symbols('qs qc ic oc',real=True);qp=s.symbols('qp',positive=True)
    # This is a real Euclidean frame representative, then pulled back with LE^-1.
    se=s.Matrix([s.sqrt(qp),0]);ce=s.Matrix([ic/s.sqrt(qp),-oc/s.sqrt(qp)])
    sr=LE.inv()*se;cr=LE.inv()*ce
    check('signed-Gram reconstruction on Qs>0 reproduces Qs and I',eq(Q(sr),qp) and eq(I(sr,cr),ic),['RER-T02'])
    check('signed-Gram reconstruction reproduces Omega and constrained Qc',eq(Om(sr,cr),oc) and eq(Q(cr),(ic**2+oc**2)/qp),['RER-T02'])
    # Same-vector convention comparison ONLY; not generator/event identification.
    BT=2*B;OmegaT=-s.sqrt(3)*w(sv,cv)
    check('producer and primitive norm conventions scale 2, orientation -2',eq((sv.T*BT*sv)[0],2*Q(sv)) and eq(OmegaT,-2*Om(sv,cv)),['RER-T03'])
    check('producer metric Gram relation holds in its own units',eq((sv.T*BT*sv)[0]*(cv.T*BT*cv)[0]-(sv.T*BT*cv)[0]**2,OmegaT**2),['RER-T03'])
    check('root closure fixes K=1',eq((ic**2+(qs*qc-ic**2))/(qs*qc),1),['RER-T03'])
    fs,fc,fi=s.symbols('fs fc fi');K=(ic**2+oc**2)/(qs*qc)
    fo=(qc*fs+qs*fc-2*ic*fi)/(2*oc)
    Kdot=s.diff(K,qs)*fs+s.diff(K,qc)*fc+s.diff(K,ic)*fi+s.diff(K,oc)*fo
    check('root-implied derivative has zero Kdot on its regular constraint surface',eq(Kdot.subs(oc**2,qs*qc-ic**2),0),['RER-T03'])
    k=s.symbols('kappa',real=True);child=k*Q(sv)*J*sv
    embed=s.Matrix.vstack(sv,child)
    check('leading child trial adds no local free datum: upper derivative is identity',embed.jacobian([x,y])[:2,:]==s.eye(2) and embed.jacobian([x,y]).rank()==2,['RER-T04'])
    check('trial child Gram norm and orthogonality',eq(Q(child),k*k*Q(sv)**3) and eq(I(sv,child),0),['RER-T04'])
    check('s and Js span one carrier at every nonzero s',eq(s.det(s.Matrix.hstack(sv,J*sv)),2*s.sqrt(3)*Q(sv)/3),['RER-T04','RER-T05'])
    prod=s.diag(B,B,B);e_s=s.Matrix.vstack(a,s.zeros(2,1),s.zeros(2,1));e_d=s.Matrix.vstack(s.zeros(2,1),s.zeros(2,1),a)
    check('orthogonal product blocks need not have orthogonal carrier values', (e_s.T*prod*e_d)[0]==0 and I(a,a)==1,['RER-T05'])
    rho,eta,qray=ray_return(5)
    check('primitive six-step ray has identity linear part and no quadratic part',rho[1]==1 and eta[1]==0 and rho[2]==eta[2]==0,['RER-D01','RER-D02'])
    check('primitive radial ray quartic is -1',qray[2]==1 and qray[3]==0 and qray[4]==-1,['RER-D02'])
    check('primitive radial ray quintic is -5/24',qray[5]==-F(5,24),['RER-D02'])
    gap=2*qray[5]
    check('equal initial Q has unequal next Q: fifth-degree difference -5/12',gap==-F(5,12) and gap!=0,['RER-D02'])
    if args.negative=='q-is-closed':check('FALSE CONTROL: radial contraction implies a closed Q-only update',gap==0,['RER-D02'])
    # Request orientation: delta_ij = theta_j-theta_i, kept distinct from TDR convention.
    D=s.Matrix([[-1,0,1],[1,-1,0],[0,1,-1]]);C=s.Matrix([[1,1,1]])
    check('triangle cycle annihilates incidence transpose',C*D.T==s.zeros(1,3),['RER-C01','RER-C02'])
    theta=s.Matrix(s.symbols('thetaA thetaB thetaC'));alpha=s.Matrix(s.symbols('alphaA alphaB alphaC'));edge=s.Matrix(s.symbols('aAB aBC aCA'))
    check('additive cycle content is invariant under declared vertex-gauge shift',eq(C*(edge+D.T*alpha),C*edge),['RER-C01','RER-C02'])
    check('node-potential triangle has exactly zero additive content',C*D.T*theta==s.zeros(1,1),['RER-C01'])
    check('independent-edge triangle can have nontrivial U1 holonomy',s.exp(s.I*s.pi/2)==s.I and s.I!=1,['RER-C01'])
    # One full no-event discrete step in the two-node branch, N=12,k=0.
    th=(0,1);va=(0,0);vb=(0,1);N=12
    after=lambda vv:tuple((th[i]+vv[i])%N for i in range(2))
    ta,tb=after(va),after(vb)
    rel=lambda tt:(tt[0]-tt[1])%N
    check('discrete same present phases can yield different next phases without any defect event',rel(ta)!=rel(tb) and rel(ta)!=N//2 and rel(tb)!=N//2,['RER-P01'])
    check('source relative-phase kinematics uses the missing relative advance',
          all(rel(after(vv))==(rel(th)+vv[0]-vv[1])%N for vv in (va,vb)), ['RER-P01'])
    # Generic construction realizes the fibre criterion: one closed and one nonclosed map.
    X=range(4);phi=lambda t:t//2;Tgood={0:2,1:3,2:0,3:1};Tbad={0:0,1:2,2:0,3:0}
    closes=lambda TT:all(phi(i)!=phi(j) or phi(TT[i])==phi(TT[j]) for i in X for j in X)
    check('finite examples distinguish fibre-consistent and inconsistent updates',closes(Tgood) and not closes(Tbad),['RER-METHOD'])
    report={'status':'new initial-registry finite algebra checks; not an owner certificate rerun','check_count':len(records),'all_pass':all(r['pass'] for r in records),'checks':records,'ray_Q_coefficients':{str(i):str(c)for i,c in enumerate(qray)if c},'dyad_nonclosure_leading_difference':str(gap),'scope':['The general quotient criterion is proved in the written registry, not by these examples.','Gram completeness uses the reconstruction plus declared kinematic SO(B), not physical gauge selection.','No coupled primitive K3 update is supplied or certified.','No finite-memory minimality or physical emergence is certified.']}
    (ROOT/'data/algebra_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print('RESULT',len(records),'PASS',flush=True)
if __name__=='__main__':
    try: main()
    except Exception as e:
        print('CHECK FAILURE:',type(e).__name__,str(e),file=sys.stderr)
        sys.exit(1)
