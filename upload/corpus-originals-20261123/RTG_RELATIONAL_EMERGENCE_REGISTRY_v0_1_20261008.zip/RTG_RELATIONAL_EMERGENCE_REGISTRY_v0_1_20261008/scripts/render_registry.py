#!/usr/bin/env python3
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
r=json.loads((ROOT/'data/REGISTRY.json').read_text())
S=r['sources']; E={e['entry_id']:e for e in r['entries']}
def esc(s):return str(s).replace('|','\\|').replace('\n',' ')
def refs(e):
    out=[]
    for v in e['source_refs']:
        d=S[v['source_id']];tail=f"; lines {v['lines'][0]}–{v['lines'][1]}" if v['lines'] else ''
        rid=f"; `{v['owner_rid']}`" if v['owner_rid'] else '; source locator only (no new RID)'
        out.append(f"[{v['source_id']}: {v['section']}]({d['package_path']}){tail}{rid}")
    return '<br>'.join(out)
def record(e):
    d=e['record'];c=d['carrier'];a=d['transformation_law'];cl=d['closure_status'];m=d['memory']
    out=[f"### {e['entry_id']} — {e['title']}",
    f"**Primary scoped statement:** `[{e['claim_status']}]`. **Origin:** {e['claim_origin']}.  ",
    f"**Proposed review/custody interface:** {e['custodian_requested']}. No review/adoption by those streams is implied.",
    '| Required field | Initial record |','|---|---|',
    '| Carrier | '+esc(f"{c['model']}. State: {c['primitive_state']}. Profile: {c['rrf_profile'] or '[UNREGISTERED / abstract; no profile invented]'}. Domain: {c['domain']}. Clock: {c['clock']}.")+' |',
    '| Observables | '+esc(' '.join(d['observables']))+' |',
    '| Constraints | '+esc(' '.join(d['constraints']))+' |',
    '| Transformation law | '+esc(a['rule']+' Physical status: '+a['physical_status']+'.')+' |',
    '| Closure status | **'+esc(cl['status'])+'**. '+esc(cl['statement'])+' |',
    '| Memory | '+esc(m['information_discarded_or_unresolved']+' '+m['possible_augmentation_or_requirement']+' Minimum sufficient memory: not established.')+' |',
    f"**Information comparison.** {e['comparison_baseline']} {e['information_assessment']}",
    '**Not established:** '+ ' '.join(e['not_claimed'])+' Physical emergence and minimal effective-state claims are not certified by this record.',
    '**Next test:** '+e['next_test'],
    '**Sources:** '+refs(e),
    '**New local evidence:** '+ ('; '.join(e['local_algebra_checks']) if e['local_algebra_checks'] else 'Source transcription/inspection only; no source certificate or dynamics rerun in this entry.'), '']
    if c.get('profile_application'):out.insert(6,'| Profile boundary | '+esc(c['profile_application'])+' |')
    head='\n\n'.join(out[:3])
    body=[]
    for line in out[3:]:
        if line.startswith('**'):body.append('')
        body.append(line)
    return head+'\n\n'+'\n'.join(body)
head=r'''# RTG — Relational Emergence Registry v0.1

**Date:** 8 October 2026  
**Document profile:** Initial working infrastructure/research registry. **NONCANONICAL DRAFT.**  
**Lead:** Triadic branch; proposed joint Ontology–DYAD–Triadic–RRF study, with source-specific Genesis, Number Genesis, RECOG, TDR-G and OPEN-M interfaces. No other stream's acceptance is inferred.  
**Requested basis:** [Attached specification](sources/REQUEST_SPECIFICATION.txt), preserved byte-for-byte.  
**Authority:** Original technical owners retain their claims, grades and physical-model authority. This file registers candidate readouts and test status, not new physics or RRF profiles. `RER-*` identifiers are local navigation keys, not scientific RIDs.  
**Methodology:** Source/claim/adoption separation follows the archived [DSN Methodology v1.3](sources/DSN_METHODOLOGY_v1_3.md), §§0.5–0.6, 3.3 and 4. This working-registry layout is not an owner-DSN migration.

**Initial state.** Sixteen records now carry the requested six-part contract. Triad records lead the register. Exact kinematic identities and the defined root-model ODE are distinguished from an unproved reduction of a microscopic triadic update. The initial checks find a static sign loss in Gram-only data and a genuine Q-only closure failure in the specified six-step dyad. Cycle holonomy is separately recorded for node-exact and independent-edge branches. No physical emergence hierarchy, minimal network state, finite-memory closure, or closed coupled primitive K3 dynamics has been established. Seven candidate properties from the specification remain an explicit research agenda; undefined metrics, charges and response laws are not filled with generic substitutes.

**Document map:** §1 hierarchy; §2 six-part contract and guards; §3 triad-first entries; §4 other levels; §5 closure and memory tests; §6 local evidence; §7 candidate agenda; §8 owner requests and execution order; §9 source/provenance record.

## 1. Proposed hierarchy — organizational, not a proved chain

| Relational level | Proposed properties, following the attachment | Present interpretation |
|---|---|---|
| Node | Phase, cyclic order | Primitive structure only in a model admitting node states |
| Dyad | Relative phase, admitted p,n labels, amplitude Q, winding, resonance | Pair-level information with owner-specific domains and clocks |
| Triad | Chirality, oriented area, holonomy, compatibility constraints | Readout-relative sign and constraint structure; autonomous coupled closure untested |
| Larger cycles | Independent cycle holonomies, winding classes, frustration | Require admitted cycle/edge data and actual dynamics |
| Network | Coherent modes, synchronization, defects, memory | Candidate effective readouts, not automatically state variables |
| Evolving network | Transport, inheritance, stable patterns | Require complete event and continuation contracts |
| Geometric regime | Metric, curvature, dimensionality | Physical realization remains OPEN |

[HEUR] Retain the attachment's three categories: **model-derived property**, **constructed effective description**, **unestablished physical emergence**. There is no asserted chain X0→Y1→Y2→…: each arrow must be defined, and incidence/fibre-product constructions may be required instead.

## 2. Registry contract and guards

[DEF] Every record contains

\[
(\text{carrier},\ \text{observables},\ \text{constraints},\ \text{transformation law},\ \text{closure status},\ \text{memory}).
\]
(rep: [ABSTRACT]; requested registry schema, not a physical carrier)

The machine record also names the compared baseline, source/version/hash/locator, result scope, model clock, evidence actually checked, next test, and separate adoption state. A numerical PASS count is not a count of emergence theorems.

**Guard RER-G1 — relative information.** “New” must name the baseline readout. A signed area can be new relative to three Gram numbers while already determined by the full ordered vectors. A new formula or collective function is not automatically new independent data. A joint collection of component states may determine what no single component alone determines.

**Guard RER-G2 — static versus dynamic completeness.** Invariance and static orbit completeness do not imply that the actual dynamics descends to the invariant coordinates. Conversely, a prescribed closed diagnostic ODE is not evidence that it is a reduction of a separately specified microscopic map.

**Guard RER-G3 — model/profile/action.** Every comparison carries all three. RRF v0.7's DYAD-W→NET-W-RAW bridge remains OPEN; normalizing isolated edges does not leave network closure unchanged. Multiplicative network edges and TDR-G profiles remain unregistered. Abstract examples stay marked abstract/unregistered, not silently assigned a profile.

**Guard RER-G4 — orientation units.** Keep primitive Omega_G=(sqrt(3)/2)omega_raw separate from recovered producer Omega_T=−sqrt(3)omega_raw. For identical planar values only, B_T=2B_G gives Q_T=2Q_G, I_T=2I_G and Omega_T=−2Omega_G. No generator, event or birth-law transport follows from those metric identities.

**Guard RER-G5 — no restored diagnostics.** Adopted Triadic v1.6 governs this draft. The historical x*, safety wedge, fatal sectors and no-basin chain are not current premises. M_root is root-closed with K=1; independent-orientation K<1 models need a separately admitted carrier and rate.

**Guard RER-G6 — history and physical interpretation.** A retained phase theorem is not a one-variable network memory-closure theorem. Node identity, deterministic role generation, cycle content, product dimension, and physical spacetime dimension are separate questions. No source/adoption/consumer state changes by inclusion here.

## 3. Triad-first registry
'''
text=[head]
for k in ['RER-T01','RER-T02','RER-T03','RER-T04','RER-T05']:text.append(record(E[k]))
text.append('## 4. Other relational levels — initial records\n\nThese records preserve the attachment’s broader programme; they do not insert unproved maps into the triad-first experiment.\n')
for k in ['RER-P01','RER-D01','RER-D02','RER-D03','RER-C01','RER-C02','RER-N01','RER-N02','RER-N03','RER-E01','RER-G01']:text.append(record(E[k]))
text.append(r'''## 5. Exact representation, closed dynamics, and memory

### 5.1 [THM] Exact deterministic quotient criterion

**Origin:** attachment §4B; the elementary proof is supplied here. **Scope:** deterministic set maps, no physical selection.

Let T:X→X on the declared invariant domain and Phi:X→Y. There exists a unique update on Phi(X) satisfying

\[
\Phi\circ T=F\circ\Phi
\]
(rep: [ABSTRACT]; deterministic common-domain reduction)

if and only if

\[
\Phi(x)=\Phi(x')\ \Longrightarrow\ \Phi(Tx)=\Phi(Tx').
\]
(rep: [ABSTRACT]; fibre-consistency test)

**Proof.** Necessity follows by applying F. Conversely define F(y)=Phi(Tx) using any x with Phi(x)=y. The condition makes the value independent of the representative. T(X)⊆X ensures the codomain. Uniqueness holds on Phi(X). □

For partial/event updates, use an invariant domain or record the event/admissibility predicate and ensure the relevant domain is determined by the reduced data. Different input/output arities require typed maps; this theorem does not identify them. Smoothness, locality, allowed computation and minimum dimension are further properties, not hidden consequences.

### 5.2 Exact static quotient is only the first test

For the primitive signed-Gram data, put Omega_G=−det(L_Es,L_Ec), where L_EᵀL_E=B_G. On Qs>0 choose the Euclidean representative

\[
s_E=(\sqrt{Q_s},0),\qquad
c_E=\left(\frac{I_{sc}}{\sqrt{Q_s}},-\frac{\Omega_G}{\sqrt{Q_s}}\right).
\]
(rep: [UNREGISTERED]; kinematic representative of the primitive B_G pair, not a physical frame choice)

The Gram constraint makes |c_E|²=Qc. Any ordered pair with the same signed readout is related to this representative by a simultaneous proper B-isometry. Thus the static fibres are known on this patch. At Qs=0 a separate chart is required; at Omega_G=0 chirality sign is not a distinct value.

This construction does not assert that the microscopic Tpost admits this common-rotation quotient. That is precisely the first triadic closure test still pending. The physical RRF pole action is not replaced by the kinematic isometry group used in this proof.

### 5.3 Memory must receive its own closure test

When Y fails, a proposed state (Y,M) must come with an actual map or source-defined evolution and satisfy the same fibre criterion. Alternatively, a history law must specify which histories are admitted and what information is retained. Neither finite memory nor sufficiency of the entire observed past is presumed.

If T and the complete x are fixed and known, values computed from x do not automatically add independent state information. Access to a counterfactual evaluation may still be operationally disallowed. A physical access restriction and an information-theoretic distinction therefore need separate entries.

R9’s source memory theorem is retained in RER-N01 with its native comparator and paired domains. Its known existence does not select M for a different triadic or network model. No registry entry presently proves minimal finite-memory closure for that enlarged setting.

## 6. First executed checks and their boundaries

**New local algebra only.** `scripts/check_registry_algebra.py` uses exact SymPy identities and a separate Fraction recurrence for the primitive real-ray T^6 jet. It imports no historical producer code. It does not rerun owner certificates, establish physical emergence, or produce a coupled primitive vector law.

### A. Orientation sign is missing from Gram-only data

For s=(1,0), c_+=J_Qs and c_-=−J_Qs,

\[
(Q_s,Q_c,I_{sc})=(1,1,0),\qquad
\Omega_G(s,c_+)=-1,\quad\Omega_G(s,c_-)=+1.
\]
(rep: [UNREGISTERED]; exact primitive B_G kinematic witness)

This is additional information **relative to that coarse readout**, not relative to the supplied vectors. Whether the distinction is physical depends on the admissible action.

### B. Local contraction does not make Q autonomous

The selected primitive analytic map is T(rho,eta)=(rho−sin eta, eta+exp rho−1−sin eta). Along (t,0), exact jet composition gives

\[
Q(T^6(t,0))=t^2-t^4-\frac5{24}t^5+O(t^6).
\]
(rep: RRF-DYAD-LIFT; lifted primitive Q on a common sufficiently small domain)

Consequently

\[
Q(T^6(t,0))-Q(T^6(-t,0))=-\frac5{12}t^5+O(t^7).
\]
(rep: RRF-DYAD-LIFT; actual analytic six-step map, no phase average)

The two input Q values are equal. Analyticity and the nonzero leading difference imply unequal successor Q for sufficiently small positive t. Hence a Q-only deterministic update on a common domain containing both rays is impossible. No explicit numerical witness radius is claimed. This does not invalidate the owner’s local contraction theorem or rule out a richer sufficient state.

### C. Triadic constraints and cycle controls

The checks reproduce the Gram relation, root-model K identity, rank-two leading child graph, one-carrier determinant and distinct product-block orthogonality. Triangle incidence verifies CDᵀ=0 and cancellation of node gauge shifts. The independent-edge holonomy example supplies only a conditional nontrivial algebraic value, not a physical connection source.

A no-event TDR-G example also shows why current phases alone do not determine the next relative phases: the source tokens matter. No TDR-G owner engine, birth-history census or continuous/discrete bridge is rerun.

**Negative controls:** the false claims “Gram-only data determine the sign” and “contraction implies Q-only closure” must each fail at their intended assertion with exit 1. Positive and negative logs remain separate. The validator checks schema, source identities and internal consistency, not the scientific truth of unexecuted models.
''')
text.append('## 7. Candidate agenda from the specification\n\n| Candidate | Initial status | Main test |\n|---|---|---|')
for w in r['candidate_watchlist']:text.append('| '+esc(w['candidate'])+' | '+esc(w['definition_status'])+' | '+esc(w['scientific_test'])+' |')
text.append('''
## 8. Next study unit and inter-stream requests

[HEUR] The first nontrivial target remains the **triad**, as requested. The dyadic and cycle checks above are controls, not a substitute for that experiment.

| Priority | Unit | Required input and decision |
|---:|---|---|''')
for q in r['next_tests']:text.append(f"| {q['priority']} | {q['task']} | {esc(q['description'])} Requested from: {esc(', '.join(q['requested_from']))}. |")
text.append('''
The initial triadic request is narrow: a branch-indexed standalone K3 vector law or independently generated jet, its incidence/mode realization, metric/orientation convention, exact clock, and admissible domain. The current standalone radial polynomial is not replaced by the K4 shadow. A finite-jet mismatch can reject an exact identity; a finite-jet success cannot certify an exact reduced map without the remaining domain/remainder argument.

RRF/OFN review is needed to decide which identities/actions are physical and which are conditional bookkeeping. It is not necessary to wait for every physical OPEN before constructing explicitly conditional tests. DYAD owns its local generator/chart inputs; RECOG owns the scope of its comparator/memory results; Number Genesis owns admitted label and cochain claims. This registry supplies no reverse proof dependency or consumer acceptance.

**Completion criterion for the next iteration:** either a correctly typed closed update for a specified triadic readout, or a source-checkable pair x,x′ with equal proposed readout and unequal successor readout. If neither is yet supplied, record the missing vector/source contract rather than choosing dynamics to force closure.

## 9. Source, evidence and lifecycle record

| Source key | Exact source | SHA-256 | Reading scope |
|---|---|---|---|''')
for k,d in S.items():
 ranges=', '.join(str(a['first'])+'–'+str(a['last']) for a in d['read_ranges'])
 text.append(f"| {k} | [{d['filename']}]({d['package_path']}) | `{d['sha256']}` | {ranges} |")
text.append('''
Full source copies are preserved in the package so quoted definitions have exact identities. Only the declared passages were freshly inspected, except the attached specification, which was read completely. A copy included for context is not evidence of a fresh whole-source audit. Source scientific grades remain their owners’ grades; new local tests are separately identified.

**Historical availability.** Some older attachment references are unavailable. No current input needed for this draft was missing. Historical source certificates named by the owners were not re-executed; the registry does not require their reupload merely to record the scoped source statements.

**Adoption state:** NONCANONICAL v0.1 DRAFT. No scientific-owner DSN, frozen correction record, RRF profile, RID or physical model was modified. All cross-stream acceptance is pending. This registry adds no canonical physical-emergence theorem.

**Version history:** v0.1, 8 October 2026 — first registry from the attached specification; sixteen six-field records, seven candidate agenda items, triad-first work queue, exact local checks, explicit source/closure/memory boundaries. No prior registry version or retired owner claim is replaced.
''')
out='\n\n'.join(text)
(ROOT/'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_1_DRAFT.md').write_text(out)
print('Rendered',len(out.split()),'words;',len(out.splitlines()),'lines')
