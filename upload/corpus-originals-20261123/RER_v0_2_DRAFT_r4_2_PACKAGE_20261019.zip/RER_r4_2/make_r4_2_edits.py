"""Edit list RER v0.2 DRAFT r4.1 -> r4.2: R41-SUM-01 (two current-summary locations), Triadic r2 review status,
Stage-2 guard decision, E2 (Genesis v2.8.8 adopted; theorem pins kept on the byte-verified v2.8.7 text)."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_1.md').read_text(encoding='utf-8')
assert hashlib.sha256(B.encode()).hexdigest() == '19f16436a747a8ef836f0cb46e4374318dbbbaa75a6540f3ef61130936e3be42'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.1\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.2\n')
ed('M2', 'metadata', '**Date:** 19 October 2026 (r4.1); r4 18 October 2026;', '**Date:** 19 October 2026 (r4.2 and r4.1); r4 18 October 2026;')
ed('M3', 'metadata', '**Document status:** DRAFT r4.1 — source erratum E1',
   '**Document status:** DRAFT r4.2 — editorial synchronization of two current summaries (receiving finding R41-SUM-01), Triadic r2 review status, Stage-2 guard decision and source note E2 (Genesis v2.8.8), built deterministically on the exact r4.1 bytes (SHA-256 `19f16436a747a8ef836f0cb46e4374318dbbbaa75a6540f3ef61130936e3be42`) by `build_r4_2_draft.py`; no record, grade or contract changes. r4.1 was: source erratum E1')
ed('S1', 'summary sync (R41-SUM-01)',
   'D3 (Triadic birth-remainder scope) is pending Triadic owner correction (v1.6.1 DRAFT r1 exists). Stage-2 status is unchanged: K=6 pilot 8/8, K=8 stopped at 1/8, global certificate and TM lemma review OPEN.',
   'D3 (Triadic birth-remainder scope): Triadic v1.6.1 DRAFT r2 is scientifically review-ACCEPTED by the receiving co-owner (19 Oct); the PI release decision is pending and the adopted Triadic owner remains v1.6. Stage-2: K=6 pilot 8/8, K=8 stopped at 1/8; a scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct); the per-stage guard a ≤ 1 is decided for the shared record contract but not yet installed; regional K_N, governing coverage and the global certificate remain OPEN.')
ed('S2', 'summary sync (R41-SUM-01)',
   'Independent Taylor-model lemma review and governing coverage remain OPEN;',
   'A scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026); the per-stage derivative-domain guard a ≤ 1 is to be enforced in the shared record contract; governing coverage, regional constants and global certification remain OPEN;')

_L = B.splitlines()
_l701 = next(l for l in _L if l.startswith('[ALG] **FINITE_ORDER.** Formal E7/E8 expansions'))
_old = 'Independent Taylor-model lemma review and governing full-domain coverage remain OPEN;'
assert _l701.count(_old) == 1
ed('S3', 'summary sync (R41-SUM-01 extension, preparer-found)', _l701,
   '**r4.2 current-use overlay (RER-F3-N7N8):** the Closure-status cell of the contract table above is the preserved r3.1 snapshot and is not edited; for current use, a scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026), the per-stage guard a ≤ 1 is to be enforced in the shared record contract, and governing coverage, regional constants and global certification remain OPEN.\n'
   + _l701.replace(_old, 'A scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026; per-stage guard a ≤ 1 pending installation); governing full-domain coverage remains OPEN;'))
ed('S4', 'summary sync (R41-SUM-01 extension, preparer-found)', 'Independent TM lemma review and global constants remain OPEN.',
   'The scoped TM lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026); the per-stage guard a ≤ 1, regional and global constants remain OPEN.')
ed('T1', 'status', 'DRAFT r2 answers D3-R1/H-R1 (+E1); next, receiving review of r2, then the Triadic release gate',
   'DRAFT r2 answers D3-R1/H-R1 (+E1) and is scientifically review-ACCEPTED (19 Oct); next, the PI release decision (new v1.6.1 adoption metadata kept distinct from inherited v1.6 release records)')
ed('T2', 'status', 'BYTE-VERIFIED by its preparer (12/12 gates; exact reversal to r1); receiving review pending |',
   'BYTE-VERIFIED by its preparer (12/12 gates; exact reversal to r1); scientific review ACCEPTED by the receiving co-owner (19 Oct; package and rebuild byte-identical on the receiving side); PI release pending |')
ed('G1', 'queue', '(19 Oct; scoped support; per-stage a ≤ 1 guard still to be enforced or verified)',
   '(19 Oct; scoped support; per-stage a ≤ 1 guard: decided for the shared `triad_stage2_contract.py` validator — exact decimal-string edge_bound, 0 ≤ a ≤ 1, no tolerance, contract revision/hash to be pinned in the next validation report — installation in the maintained source pending)')
ed('E2a', 'pointer (E2)', '**Companion documents:** Genesis v2.8.7 (adopted 18 Oct 2026; v2.8.6 and v2.8.5 historical);',
   '**Companion documents:** Genesis v2.8.8 (adopted 19 Oct 2026; maintenance release: Dyadic repin and ν₅ attribution; per its release record the K3/6S theorems, §6.3a–b and SG-15/16 are byte-identical to v2.8.7, so RER theorem citations stay on the byte-verified v2.8.7 text); Genesis v2.8.7 (adopted 18 Oct 2026, superseded 19 Oct; v2.8.6 and v2.8.5 historical);')
ed('E2b', 'pointer (E2)',
   '| `GEN287` | Genesis v2.8.7, ADOPTED 18 Oct 2026 (1564 lines) | `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361` | BYTE-VERIFIED (RER editor, 18 Oct); §§1, 3, 6.3a, 6.3a.1, 6.3b, 7, 8 SOURCE-READ |',
   '| `GEN287` | Genesis v2.8.7, ADOPTED 18 Oct 2026 (1564 lines); superseded by v2.8.8 on 19 Oct, cited text unchanged | `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361` | BYTE-VERIFIED (RER editor, 18 Oct; receiving co-owner, 19 Oct); §§1, 3, 6.3a, 6.3a.1, 6.3b, 7, 8 SOURCE-READ |\n'
   '| `GEN288` | Genesis v2.8.8, ADOPTED 19 Oct 2026 (1581 lines; maintenance: live Dyadic pins → v6.4.13, `DYAD-ALG-NU5-P5` attribution, M2c closed; §6.3a–b, SG-15/16, claim-tag counts and GEN RID set identical to v2.8.7) | `9abd36169a4bf6056318605c0399ff1f91c53f157b9181bdbfdb9faed3000f37` | OWNER-REPORTED (release record `claude/GENESIS_V2_8_8_RELEASE_RECORD.md`); not byte-verified here; not used as a theorem pin |')
H = '[ALG] R4.1 (19 Oct 2026) is a narrow rebuild on the exact r4 bytes.'
ed('H1', 'metadata', H,
   '[ALG] R4.2 (19 Oct 2026) is an editorial rebuild on the exact r4.1 bytes. It answers receiving finding R41-SUM-01: the header status summary and §1 now state the current D3 object (Triadic v1.6.1 DRAFT r2, review-ACCEPTED, PI release pending) and separate the reported scoped TM lemma review from the open per-stage guard, regional constants and global certificate. It records the receiving decision to enforce a ≤ 1 in the shared record contract (not installed) and source note E2: Genesis v2.8.8 adopted 19 Oct is a maintenance release whose cited theorem text is byte-identical to v2.8.7 per its release record, so the theorem pins stay on the byte-verified v2.8.7 text. No record, grade, contract table, G5/G6 status or earlier revision text changes.\n' + H)
ed('H2', 'metadata', '**Release boundary (r4.1):**', '**Release boundary (r4.2):** r4.2 is a noncanonical review draft; it adopts, freezes and accepts nothing. **Release boundary (r4.1):**')
Path('r4_1_to_r4_2_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1), encoding='utf-8'); print(len(E), 'edits')
