"""Gates for RER v0.2 DRAFT r4.2 (on r4.1 bytes). Exit 0 iff all pass; --tamper runs negative controls.
Structural: M1 base SHA; M2 rebuild; M3 reversal to r4.1; M4 24 headings + 16 r3.1 contract tables byte-identical; M5 tag counts
unchanged (editorial release: no claim tag added or removed); M6 four r4 records still owner-adoption pending.
Carried r4.1 scope gates: C1 no live Dyadic v6.4.12.1 pin; C2 OPEN 20 split; C3 G5 only with C^3; C4 mean-feedback only with H_spec;
C5 no Lemma-F RID in RER-TRIAD records.
Summary synchronization (R41-SUM-01): U1 status summary names DRAFT r2 and no longer 'DRAFT r1 exists'; U2 no current summary says the
TM lemma review is OPEN; U3 both summaries keep RECEIVER-REPORTED and keep regional/global certification OPEN; U4 every current-state line
naming the TM lemma review (outside §9 history and outside the frozen r3.1 contract tables) distinguishes it from the open guard/coverage/
certificate, and a frozen stale table cell is covered by a current-use overlay in its record.
E2: E1 Genesis v2.8.8 recorded OWNER-REPORTED, not used as a theorem pin (all [import: ...GENESIS... ] tags still v2.8.7)."""
import sys, re, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_2_draft as B
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
def gates(d, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.1 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.1 byte-exactly', ok and rev == b)
    heads = re.findall(r'^### RER-[A-Z0-9-]+ — .*$', b, re.M)
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    g('M4 headings and r3.1 contract tables byte-identical', len(heads) == 24 and all(h in d for h in heads) and len(tables) == 16 and all(t in d for t in tables))
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    g('M5 claim-tag counts unchanged except the one [ALG] history entry', all(d.count(t) == b.count(t) + (1 if t == '[ALG]' else 0) for t in tags))
    new = ['RER-GEN-K3-MODAL', 'RER-DYAD-FORMAL-INVOLUTION', 'RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION']
    g('M6 four r4 records still owner-adoption pending', all(re.search(re.escape(k) + r' — [^\n]*\n\*\*Primary grade:\*\*[^\n]*Registry/owner adoption:\*\* pending', d) for k in new))
    bad = [l for l in d.splitlines() if 'v6.4.12.1' in l and not re.search(r'r4 pin|r4 pinned|superseded|current pin v6\.4\.13|R4\.1 \(19 Oct 2026\)|released as v6\.4\.12\.1|R4 \(18 Oct 2026\)|Dyadic v6\.4\.12\.1 cites', l)]
    g('C1 no live Dyadic v6.4.12.1 pin', not bad)
    rec = d.split('### RER-DYAD-FORMAL-INVOLUTION')[1].split('\n### ')[0]
    g('C2 OPEN 20 split retained', '[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness.' not in rec and '[OPEN] OPEN 20 B-∞ existence' in rec and '[OPEN] OPEN 20 B-6' in rec)
    g('C3 G5 closure only with C^3', not [l for l in d.splitlines() if 'CLOSED_AT_OWNER_GRADE' in l and 'C^3' not in l])
    g('C4 mean-feedback theorem only with H_spec', not [l for l in d.splitlines() if 'GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO' in l and 'H_spec' not in l])
    triad = ''.join(d.split('### ' + k)[1].split('\n### ')[0] for k in ['RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION'])
    g('C5 no Lemma-F RID in RER-TRIAD records', not re.search(r'DYAD-CAND-FLAT|DYAD-CAND-SMOOTH|DYAD-THM-FORMAL-Z6', triad))
    L = d.splitlines(); summ = next(l for l in L if l.startswith('**Status summary:**')); s1 = next(l for l in L if l.startswith('[OPEN] N=7/8 whole-region constants'))
    g('U1 status summary names Triadic DRAFT r2; no "DRAFT r1 exists"', 'DRAFT r1 exists' not in d and 'v1.6.1 DRAFT r2' in summ)
    g('U2 no current summary calls the TM lemma review OPEN', not re.search(r'TM lemma review OPEN|lemma review and governing coverage remain OPEN', summ + s1))
    g('U3 both summaries keep RECEIVER-REPORTED and keep certification OPEN', all('RECEIVER-REPORTED' in x and 'remain OPEN' in x for x in (summ, s1)))
    hist = d.split('## 9.')[1] if '## 9.' in d else ''
    frozen = set(x for tb in tables for x in tb.splitlines())
    cur = [l for l in d.split('## 9.')[0].splitlines() if re.search(r'lemma review', l, re.I) and l not in frozen]
    f3 = d.split('### RER-F3-N7N8')[1].split('\n### ')[0]
    stale_cells = [l for l in f3.splitlines() if l in frozen and re.search(r'lemma review[^|]*remain OPEN', l)]
    g('U4 every current-state lemma-review line separates review from open guard/coverage/certificate',
      (not stale_cells or 'r4.2 current-use overlay (RER-F3-N7N8)' in f3) and cur and all(re.search(r'RECEIVER-REPORTED|performed|reported completed|done', l) and re.search(r'guard|a ≤ 1|remain OPEN|OPEN', l) for l in cur), f'{len(cur)} lines')
    gen_imports = re.findall(r'\[import: RTG_GENESIS_GEOMETRY_DSN_v([0-9.]+)', d)
    g('E2 Genesis v2.8.8 recorded OWNER-REPORTED, theorem imports stay v2.8.7', '`GEN288`' in d and 'not used as a theorem pin' in d and gen_imports and set(gen_imports) == {'2.8.7'}, f'{len(gen_imports)} imports')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    T = [('U1', 11, d0.replace('Triadic v1.6.1 DRAFT r2 is scientifically', 'Triadic v1.6.1 DRAFT r1 exists; it is scientifically', 1)),
         ('U2', 12, d0.replace('regional K_N, governing coverage and the global certificate remain OPEN.', 'global certificate and TM lemma review OPEN.', 1)),
         ('U3', 13, d0.replace('reported completed (RECEIVER-REPORTED, 19 Oct 2026)', 'completed (19 Oct 2026)', 1)),
         ('E2', 15, d0.replace('`[import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3a.1', '`[import: RTG_GENESIS_GEOMETRY_DSN_v2.8.8 §6.3a.1', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    # the delivered r4.1 bytes must fail the summary gates (the finding the r4.1 checker missed)
    _, rb = gates(b, verbose=False); print(f'  r4.1 bytes: U1..U4 = {rb[11:15]} (expected all False)'); allf &= not any(rb[11:15])
    ok = ok and allf
sys.exit(0 if ok else 1)
