"""Phase A r16 -> r17, part B (gates). Re-bases A19, A23, A24, A25, A26, A28, A29 and adds A31 (FORMAL-AGE grade change recorded) and A32 (new owner
versions owner-reported only). r16 outputs are kept under inputs/phaseA_r16_outputs/. Arg: TARGET_DIR."""
import sys, os
D = sys.argv[1]
C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    assert t.count(a) == 1, a[:60]; i = t.index(a); j = t.index(b, i); return t[:i] + new + t[j:]
def one(t, a, b):
    assert t.count(a) == 1, a[:80]; return t.replace(a, b)
assert t.count("'out/RER_REGISTRY_v0_2_r4_10_PHASEA.json'") == 2
t = t.replace("'out/RER_REGISTRY_v0_2_r4_10_PHASEA.json'", "'out/RER_REGISTRY_v0_2_r4_11_PHASEA.json'")
t = one(t, "pkg410 = B.rd('inputs/r4_10_package_SHA256SUMS.txt').decode()\n", "pkg410 = B.rd('inputs/r4_10_package_SHA256SUMS.txt').decode(); pkg411 = B.rd('inputs/r4_11_package_SHA256SUMS.txt').decode()\n")
t = one(t, "        if x.get('path_in_r4_10_package') and ('  ' + x['cited_path'] + '\\n') not in pkg410: bb.append(x['key'] + ':pkg410')\n",
        "        if x.get('path_in_r4_10_package') and ('  ' + x['cited_path'] + '\\n') not in pkg410: bb.append(x['key'] + ':pkg410')\n        if x.get('path_in_r4_11_package') and ('  ' + x['cited_path'] + '\\n') not in pkg411: bb.append(x['key'] + ':pkg411')\n")
t = one(t, "g('A19 owner currency equals the frozen catalog; Dyadic v6.4.15/v6.4.16 and OFN v0.9 not current; catalog date/scope/authority recorded'",
        "g('A19 owner currency equals the frozen catalog; Dyadic v6.4.15-v6.4.18, RECOG v0.3.20/v0.3.21, RRF v0.8.3 and OFN v0.9 not current; catalog date/scope/authority recorded'")
t = one(t, "and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16', '6.4.17') and oc['RECOG']['version'] == '0.3.21' and oc['OFN']['version'] == '0.10'",
        "and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16', '6.4.17', '6.4.18') and oc['RECOG']['version'] == '0.3.22' and oc['RRF']['version'] == '0.8.4' and oc['OFN']['version'] == '0.10'")

NEW_A23 = r'''    D19 = '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'
    hs = dy.get('history', {})
    r13 = [x for x in dyrows if x['key'] == 'DYAD6413']; r18 = [x for x in dyrows if x['key'] == 'DYAD6418']
    dy_ok = (dy['version'] == '6.4.19' and dy['sha256'] == D19 and dy['evidence'] == 'OWNER_REPORTED' and D19 not in avail and D18 in avail and D17 in avail and f18_ok
             and 'claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md' in dy.get('note', '') and 'not replayed here' in dy.get('note', '') and 'bytes not held here' in dy.get('note', '')
             and f14.get('key') == 'DYAD6418' and f14.get('sha256') == D18 and bool(f14.get('container')) and C14.get('container_chain_status', '').startswith('PREPARER_DECLARED') and s18_ok
             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok
             and hs.get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED' and hs.get('phaseA_r9_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r9_r11'].get('sha256') == D17
             and hs.get('phaseA_r12_r13', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12_r13'].get('sha256') == D18 and hs['phaseA_r12_r13'].get('version') == '6.4.18'
             and hs.get('phaseA_r14_r16', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r14_r16'].get('sha256') == D18 and hs['phaseA_r14_r16'].get('version') == '6.4.18'
             and dy.get('superseded', {}).get('version') == '6.4.18' and dy['superseded'].get('sha256') == D18 and dy['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and len(dyrows) == 2 and len(r13) == 1 and len(r18) == 1
             and all(x['cited_version'] == '6.4.13' and x['cited_sha256'] == '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED'
                     and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' and x['verified_current_hash'] is None
                     and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['current_owner_version'] == '6.4.19' for x in r13)
             and all(x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' and x['row_kind'] == 'RECORD_IMPORT' and x['n'] == 3 and x['cited_version'] == '6.4.18' and x['cited_sha256'] == D18
                     and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['available_file'] == 'sources_available/' + FN18
                     and x['currency'] == 'UNCHANGED_OWNER_REPORTED' and x['status'] == 'OWNER_REPORTED' and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED'
                     and x['current_owner_version'] == '6.4.19' and 'Phase A r17' in x['currency_reason'] and x['path_in_r4_9_package'] is True
                     and x.get('receiver_section_check', '').startswith('RECEIVER-REPORTED') for x in r18))
    g('A23 Dyadic v6.4.19 owner-reported (bytes not held); v6.4.18 byte-verified identity kept as superseded (file, custody r14, section check); v6.4.17 identity and r8-r16 history kept; DYAD6413 pin v6.4.13 RECHECK; DYAD6418 pin v6.4.18 UNCHANGED_OWNER_REPORTED', dy_ok, f'{len(dyrows)} Dyadic rows')
'''
t = cut(t, "    hs = dy.get('history', {})\n    r13 = [x for x in dyrows", "    sm = reg['source_markdown']", NEW_A23)

NEW_A24_25 = r'''    sm = reg['source_markdown']
    H13 = 'inputs/phaseA_r13_outputs/'; o13 = ri(H13 + 'check_phaseA_output_r13.txt').decode('utf-8'); H15 = 'inputs/phaseA_r15_outputs/'; o15 = ri(H15 + 'check_phaseA_output_r15.txt').decode('utf-8')
    H16 = 'inputs/phaseA_r16_outputs/'; o16 = ri(H16 + 'check_phaseA_output_r16.txt').decode('utf-8')
    man411 = B.rd('inputs/r4_11_package_SHA256SUMS.txt').decode()
    src_ok = (sm['file'].endswith('_r4_11.md') and sm['sha256'] == B.MD_SHA == '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8' and sm['package_zip_sha256'] == 'f55652773396fe5ed56b22659aa603dfa267f09f420e7c7089ae6d5c92d43073'
              and sm.get('base_r4_10_sha256') == '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c' and sm.get('base_r4_10_package_zip_sha256') == 'ac3dd7768a3109645fcec3f7500c14f62804ccb853727e0755237194d1447041'
              and sm.get('base_r4_9_sha256') == '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84' and sm.get('base_r4_8_sha256') == '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'
              and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA
              and all('path_in_r4_11_package' in x for x in cm['rows']) and '28/28 gates PASS' in o13 and '29/29 gates PASS' in o15 and '30/30 gates PASS' in o16 and 'BAD' not in o13 + o15 + o16
              and '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c  RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_10.md\n' in man411)
    g('A24 r4.11 source pass: r4.11, package and r4.10/r4.9/r4.8 bases pinned; r4.10 identity in the r4.11 manifest; every row carries path_in_r4_11_package; r13, r15 and r16 checker records kept', src_ok)
    g16 = json.loads(B.rd(H16 + 'RER_REGISTRY_v0_2_r4_10_PHASEA.json'))
    G16 = {x['id']: x for x in g16['gap_entries']}; G17 = {x['id']: x for x in reg['gap_entries']}
    dg = sorted(k for k in G16 if G16[k] != G17.get(k))
    R16 = {x['id']: x for x in g16['records']}; R17 = {x['id']: x for x in reg['records']}
    dr = sorted(k for k in R16 if R16[k] != R17.get(k))
    a6, a7 = R16.get('RER-TRIAD-FORMAL-AGE', {}), R17.get('RER-TRIAD-FORMAL-AGE', {})
    dka = sorted(k for k in set(a6) | set(a7) if a6.get(k) != a7.get(k))
    AGEK = ['claim_lines', 'fields', 'grade_tags', 'primary_grade', 'primary_grade_line', 'prior_review_receipt', 'unclassified_lines']
    f6, f7 = a6.get('fields', {}), a7.get('fields', {})
    u6, u7 = a6.get('unclassified_lines', []), a7.get('unclassified_lines', [])
    age_ok = (dka == AGEK and a7.get('grade_tags') == ['ALG'] and a6.get('grade_tags') == ['THM'] and a7.get('primary_grade') == '[ALG] (formal; source grade, r4.11)'
              and a7.get('primary_grade_line') == a6.get('primary_grade_line', '').replace('**Primary grade:** [THM].', '**Primary grade:** [ALG] (formal; source grade, r4.11).', 1) != a6.get('primary_grade_line')
              and len(a6.get('claim_lines', [])) == len(a7.get('claim_lines', [])) == 1 and a6['claim_lines'][0].startswith('[THM] **FORMAL_ONLY.**') and a7['claim_lines'][0] == '[ALG]' + a6['claim_lines'][0][5:]
              and sorted(k for k in set(f6) | set(f7) if f6.get(k) != f7.get(k)) == ['Evidence', 'Review receipt'] and f7['Evidence'].startswith(f6['Evidence'] + ' r4.11: ') and f7['Review receipt'].startswith(f6['Review receipt'] + ' r4.11: ')
              and len(u7) == len(u6) + 1 and [l for l in u7 if not l.startswith('**Grade provenance** (r4.11):')] == u6 and sum(l.startswith('**Grade provenance** (r4.11):') for l in u7) == 1)
    st6, st7 = g16['source_table'], reg['source_table']
    dst = sorted(k for k in set(st6) | set(st7) if st6.get(k) != st7.get(k))
    st_ok = (dst == ['RECOG'] and sorted(k for k in st6['RECOG'] if st6['RECOG'][k] != st7['RECOG'].get(k)) == ['description'] and set(st6['RECOG']) == set(st7['RECOG'])
             and 'frozen 19 Oct 2026 per the G1 record `5c00f66d…9b55`' in st7['RECOG']['description'] and st7['RECOG']['sha256'] == st6['RECOG']['sha256'])
    strip = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown', 'gap_entries', 'records', 'source_table')}
    r_ok = (strip(reg) == strip(g16) and list(R16) == list(R17) and dr == ['RER-TRIAD-FORMAL-AGE'] and age_ok and st_ok and set(G16) == set(G17) and dg == ['RER-G9']
            and {k: v for k, v in G17['RER-G9'].items() if k != 'text_sha256'} == {k: v for k, v in G16['RER-G9'].items() if k != 'text_sha256'}
            and G17['RER-G9']['text_sha256'] != G16['RER-G9']['text_sha256'] and len(reg['records']) == 20 and g16['schema'] == 'RER-REGISTRY-PHASEA/16' and reg['schema'] == 'RER-REGISTRY-PHASEA/17')
    g('A25 r16 registry equality: 20 records equal except RER-TRIAD-FORMAL-AGE (grade [THM] -> [ALG], same statement; Evidence/receipt extended; one grade-provenance line); gap entries equal except RER-G9 text_sha256; source table equal except the RECOG description', r_ok, f'records differing: {dr}; FORMAL-AGE keys: {dka}; gaps: {dg}; source table: {dst}')
'''
t = cut(t, "    sm = reg['source_markdown']\n    H13 = ", "    rc = oc['RECOG'];", NEW_A24_25)

NEW_A26 = r'''    rc = oc['RECOG']; G22 = '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
    G1R = '5c00f66dae7d4de6ccd4a04d642a23edfc861bbd6bd55e432513747fbd679b55'
    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']
    FN21 = 'RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md'; P21 = os.path.join(HERE, 'sources_available', FN21)
    file_ok = FN21 not in withhold and os.path.isfile(P21) and sha(open(P21, 'rb').read()) == G21
    C13 = json.loads(ri('inputs/source_custody_r13.json')); f13 = C13.get('files', {}).get(FN21, {})
    sc13 = ri('inputs/recog_v0_3_21_section_check/compare_output.txt').decode('utf-8')
    sc13_ok = (f'v0.3.20 {G20} MATCH' in sc13 and f'v0.3.21 {G21} MATCH' in sc13 and sc13.count('IDENTICAL') == 2 and 'DIFFERENT' not in sc13
               and 'hunks inside cited blocks: 0' in sc13 and 'RESULT: PASS' in sc13)
    rng = {m.group(1): [int(m.group(2)), int(m.group(3))] for m in re.finditer(r'^  (§6\.6a|§6\.16g) +v0\.3\.20 lines (\d+)-(\d+) ', sc13, re.M)}
    rows_rng_ok = len(rr_) == 2 and len(rng) == 2 and all(any(x['section_or_RID'].startswith(s + ' ') and x['lines'] == v for s, v in rng.items()) for x in rr_) and len({tuple(x['lines']) for x in rr_}) == 2
    hs = rc.get('history', {}); fz = rc.get('frozen_edition', {})
    rc_ok = (rc['version'] == '0.3.22' and rc['sha256'] == G22 and rc['evidence'] == 'OWNER_REPORTED' and G22 not in avail and G21 in avail and G20 in avail and file_ok
             and 'claude/RECOG_v0_3_22_RELEASE_RECORD.md' in rc.get('note', '') and 'bytes not held here' in rc.get('note', '')
             and f13.get('key') == 'RECOG0321' and f13.get('sha256') == G21 and bool(f13.get('container')) and C13.get('container_chain_status', '').startswith('PREPARER_DECLARED') and sc13_ok and rows_rng_ok
             and hs.get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r6_r11'].get('sha256') == G20 and hs['phaseA_r6_r11'].get('version') == '0.3.20'
             and hs.get('phaseA_r12', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12'].get('sha256') == G21 and hs['phaseA_r12'].get('version') == '0.3.21'
             and hs.get('phaseA_r13_r16', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r13_r16'].get('sha256') == G21 and hs['phaseA_r13_r16'].get('version') == '0.3.21'
             and rc.get('superseded', {}).get('version') == '0.3.21' and rc['superseded'].get('sha256') == G21 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and fz.get('version') == '0.3.20' and fz.get('sha256') == G20 and fz.get('evidence', '').startswith('BYTE_VERIFIED')
             and fz.get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED') and G1R in fz.get('frozen', '') and 'bytes are not held' in fz.get('frozen', '')
             and all(x['cited_version'] == '0.3.20' and x['cited_sha256'] == G20 and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'
                     and x['available_file'] == 'sources_available/RECOG__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md' and x['currency'] == 'UNCHANGED_OWNER_REPORTED' and x['status'] == 'OWNER_REPORTED'
                     and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['current_owner_version'] == '0.3.22' and 'Phase A r17' in x['currency_reason']
                     and x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' and x['reviewer_disposition'] == 'PENDING' and x.get('receiver_section_check', '').startswith('RECEIVER-REPORTED') for x in rr_))
    g('A26 RECOG v0.3.22 owner-reported (bytes not held); v0.3.21 byte-verified identity kept as superseded (file, custody r13, section check 2/2 IDENTICAL); v0.3.20 frozen edition kept (frozen status owner-reported, G1 record named); r6-r16 history kept; RER pins stay v0.3.20; RECOG rows UNCHANGED_OWNER_REPORTED; per-reference audit pending', rc_ok, f'{len(rr_)} RECOG rows; ranges {rng}')
'''
t = cut(t, "    rc = oc['RECOG']; G21 = ", "    mdl = md.split('\\n'); W = [w", NEW_A26)

NEW_A28 = r'''    m16 = json.loads(B.rd(H16 + 'SOURCE_CURRENCY_MATRIX.json')); b16 = json.loads(B.rd(H16 + 'BLOCKED_SOURCE_REGISTER.json'))
    NEWO = ('Dyadic', 'RECOG', 'RRF')
    OWNF = {'currency', 'currency_reason', 'current_owner_evidence', 'current_owner_sha256', 'current_owner_version', 'path_in_r4_11_package', 'status', 'verified_current_hash'}
    dk = [(x['owner'], sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k))) for x, y in zip(cm['rows'], m16['rows'])]
    rows16_ok = (len(cm['rows']) == len(m16['rows']) == 91 and all((x['key'], x['record'], x['n'], x['row_kind']) == (y['key'], y['record'], y['n'], y['row_kind']) for x, y in zip(cm['rows'], m16['rows']))
                 and all(d == ['path_in_r4_11_package'] for o, d in dk if o not in NEWO)
                 and all(set(d) <= OWNF and 'path_in_r4_11_package' in d and 'current_owner_version' in d for o, d in dk if o in NEWO)
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256')}
    sa6, sa7 = m16['owner_catalog']['source_authority'], meta.get('source_authority', {})
    rest16_ok = (stripb(br) == stripb(b16) and set(oc) == set(m16['owner_current']) and all(oc[o] == m16['owner_current'][o] for o in oc if o not in NEWO)
                 and all(oc[o] != m16['owner_current'][o] for o in NEWO) and cm.get('scientific_sync_warnings') == m16.get('scientific_sync_warnings')
                 and cm['watch_items'][:-1] == m16['watch_items'] and cm['watch_items'][-1].startswith('Phase A r17 (21 Oct 2026): source is RER r4.11')
                 and meta.get('scope') == m16['owner_catalog']['scope'] and set(sa6) == set(sa7) and sorted(o for o in sa6 if sa6[o] != sa7[o]) == list(NEWO)
                 and cm['bytes_not_available_to_preparer'] == m16['bytes_not_available_to_preparer'] and m16['schema'] == 'RER-SOURCE-CURRENCY/16' and cm['schema'] == 'RER-SOURCE-CURRENCY/17')
    g('A28 r16 matrix equality: 91 rows; rows of unchanged owners differ only by path_in_r4_11_package; Dyadic/RECOG/RRF rows differ only in owner-currency fields (pins, bytes and authentication unchanged); other owners, warning, blocked register and G9 audits unchanged', rows16_ok and rest16_ok, f'{sum(1 for o, d in dk if (o not in NEWO and d != ["path_in_r4_11_package"]) or (o in NEWO and not set(d) <= OWNF))} row(s) with other differences')
'''
t = cut(t, "    m15 = json.loads(B.rd(H15 + 'SOURCE_CURRENCY_MATRIX.json'))", "    H83 = ", NEW_A28)

NEW_A29 = r'''    H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'; F84 = '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'
    FN83 = 'RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md'; P83 = os.path.join(HERE, 'sources_available', FN83)
    f83_ok = FN83 not in withhold and os.path.isfile(P83) and sha(open(P83, 'rb').read()) == H83
    C15 = json.loads(ri('inputs/source_custody_r15.json')); f15 = C15.get('files', {}).get(FN83, {})
    rr83 = [x for x in cm['rows'] if x['key'] == 'RRF083']; rr82 = [x for x in cm['rows'] if x['key'] == 'RRF082']; rrf = [x for x in cm['rows'] if x['owner'] == 'RRF']; orr = oc.get('RRF', {})
    a29 = (f83_ok and f15.get('key') == 'RRF083' and f15.get('sha256') == H83 and bool(f15.get('container')) and C15.get('container_chain_status', '').startswith('PREPARER_DECLARED')
           and len(rr83) == 1 and all(x['cited_sha256'] == H83 and x['cited_version'] == '0.8.3' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'
                                      and x['available_file'] == 'sources_available/' + FN83 and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL'
                                      and 'Phase A r17' in x['currency_reason'] and x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' for x in rr83)
           and len(rr82) == 1 and all(x['cited_version'] == '0.8.2' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED' and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and 'Phase A r17' in x['currency_reason'] for x in rr82)
           and len(rrf) == 14 and all(x['current_owner_version'] == '0.8.4' and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT' for x in rrf)
           and orr.get('version') == '0.8.4' and orr.get('sha256') == F84 and orr.get('evidence') == 'OWNER_REPORTED' and F84 not in avail
           and 'claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md' in orr.get('note', '') and 'bytes not held here' in orr.get('note', '')
           and orr.get('superseded', {}).get('version') == '0.8.3' and orr['superseded'].get('sha256') == H83 and orr['superseded'].get('evidence', '').startswith('HASH_VERIFIED_BY_RECEIVER')
           and orr.get('history', {}).get('phaseA_to_r16', {}).get('evidence') == 'HASH_VERIFIED_BY_RECEIVER' and orr['history']['phaseA_to_r16'].get('sha256') == H83)
    g('A29 RRF v0.8.4 owner-reported (bytes not held); v0.8.3 kept as superseded (receiver-hashed); RRF083 bytes still verified here (file, custody r15) but RECHECK_IN_PHASE_B; RRF082 RECHECK_IN_PHASE_B; no RRF row CURRENT or with a verified current hash', a29, f'{len(rrf)} RRF rows')
'''
t = cut(t, "    H83 = ", "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt')\n    sums", NEW_A29)

NEW_A31_32 = r'''    FNF = 'FORMAL__FORMAL_AGE_FAMILY_REVIEW.md'; PF = os.path.join(HERE, 'sources_available', FNF); HF = 'b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899'
    ag = next((x for x in reg['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE'), {})
    gp = [l for l in ag.get('unclassified_lines', []) if l.startswith('**Grade provenance** (r4.11):')]
    agrows = [x for x in cm['rows'] if x['record'] == 'RER-TRIAD-FORMAL-AGE']
    a31 = (FNF not in withhold and os.path.isfile(PF) and sha(open(PF, 'rb').read()) == HF and ag.get('grade_tags') == ['ALG'] and ag.get('primary_grade', '').startswith('[ALG]')
           and all(not l.startswith('[THM]') for l in ag.get('claim_lines', [])) and len(gp) == 1 and HF in gp[0] and '[ALG, formal — accepted with scope corrections]' in gp[0]
           and 'written by the author of the result' in gp[0] and 'd388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab' in gp[0] and 'statement, scope and exactness are unchanged' in gp[0]
           and ag.get('adoption_status') == 'PENDING' and ag.get('contract', {}).get('Closure status') is not None
           and any(x['key'] == 'FORMAL' and x['cited_sha256'] == HF and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in agrows)
           and 'RER-TRIAD-FORMAL-AGE primary grade [ALG]' in cm['watch_items'][-1] and 'b170dbff…3899' in cm['watch_items'][-1])
    g('A31 FORMAL-AGE grade change recorded: grade [ALG] with the grade-provenance line (FORMAL source grade b170dbff…, r2 review by the result author); FORMAL bytes held and cited; adoption PENDING; watch item', a31, f'tags {ag.get("grade_tags")}')
    NV = [('Dyadic', '6.4.19', '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9', 'claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md'),
          ('RECOG', '0.3.22', '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9', 'claude/RECOG_v0_3_22_RELEASE_RECORD.md'),
          ('RRF', '0.8.4', '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce', 'claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md')]
    allfiles = {sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) for f in os.listdir(os.path.join(HERE, 'sources_available'))}
    a32 = all(oc.get(o, {}).get('version') == v and oc[o].get('sha256') == h and oc[o].get('evidence') == 'OWNER_REPORTED' and h not in allfiles and rec in oc[o].get('note', '')
              and KV.get(o) == v and rec in KV['_source_authority'].get(o, '') and 'bytes not held here' in KV['_source_authority'][o]
              and all(x['cited_version'] != v and x['cited_sha256'] != h and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT'
                      for x in cm['rows'] if x['owner'] == o)
              and h[:8] in cm['watch_items'][-1] for o, v, h, rec in NV) and all(x['verified_current_hash'] not in [h for _, _, h, _ in NV] for x in cm['rows'])
    g('A32 new owner versions (Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4) OWNER_REPORTED only: record-stated hashes, no held file, no verified current hash, no pin moved, not CURRENT', a32)
    return all(res), res

outs ='''
t = one(t, "    return all(res), res\n\nouts =", NEW_A31_32)

# ---- negative controls: retire the r16 A23-A26/A28/A29 controls and add the r17 ones
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
assert block[0].startswith("    T = [('") and all(l.startswith("         ('") for l in block[1:])
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]; ents[-1] = ents[-1][:-1]
keep = [e.rstrip(',') for e in ents if not any(e.startswith("('" + g + ' ') for g in ('A23', 'A24', 'A25', 'A26', 'A28', 'A29'))]
D18s = "'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'"; D19s = "'40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'"
G21s = "'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'"; G22s = "'0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'"
H83s = "'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'"; F84s = "'2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'"
M16 = "json.loads(B.rd('inputs/phaseA_r16_outputs/SOURCE_CURRENCY_MATRIX.json'))"; G16R = "json.loads(B.rd('inputs/phaseA_r16_outputs/RER_REGISTRY_v0_2_r4_10_PHASEA.json'))"
NEWC = f'''('A19 Dyadic v6.4.18 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.18')))
('A19 RECOG v0.3.21 claimed current', 18, mut(C, lambda d: d['owner_current']['RECOG'].update(version='0.3.21')))
('A19 RRF v0.8.3 claimed current', 18, mut(C, lambda d: d['owner_current']['RRF'].update(version='0.8.3')))
('A23 v6.4.19 promoted to BYTE_VERIFIED without bytes', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED')))
('A23 v6.4.19 relabelled HASH_VERIFIED_BY_RECEIVER (owner-side verification taken as receiver evidence)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='HASH_VERIFIED_BY_RECEIVER')))
('A23 v6.4.19 hash replaced', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64)))
('A23 Dyadic owner entry left in the r16 state (v6.4.18 current)', 22, mut(C, lambda d: d['owner_current'].update(Dyadic={M16}['owner_current']['Dyadic'])))
('A23 r14-r16 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r14_r16')))
('A23 r12-r13 OWNER_REPORTED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r12_r13')))
('A23 r9-r11 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r9_r11')))
('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r8')))
('A23 superseded v6.4.18 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))
('A23 release-record reference dropped from the note', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(note='adopted 20 Oct 2026')))
('A23 DYAD6418 row left CURRENT/VERIFIED (r16 state)', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(currency='CURRENT', status='VERIFIED')))
('A23 DYAD6418 row given the v6.4.18 hash as verified current hash', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(verified_current_hash={D18s})))
('A23 DYAD6418 pin silently moved to v6.4.19', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(cited_version='6.4.19', cited_sha256={D19s})))
('A23 DYAD6418 receiver section-check receipt dropped', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').pop('receiver_section_check')))
('A23 DYAD6413 row given a verified current hash', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(verified_current_hash={D18s})))
('A23 DYAD6413 promoted to CURRENT/VERIFIED', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='CURRENT', status='VERIFIED')))
('A24 source recorded as r4.10', 23, mut(R, lambda d: d['source_markdown'].update(sha256='5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c')))
('A24 r4.11 package hash replaced', 23, mut(R, lambda d: d['source_markdown'].update(package_zip_sha256='0' * 64)))
('A24 r4.10 base dropped', 23, mut(R, lambda d: d['source_markdown'].pop('base_r4_10_sha256')))
('A24 a row without path_in_r4_11_package', 23, mut(C, lambda d: d['rows'][0].pop('path_in_r4_11_package')))
('A25 r16 FORMAL-AGE record re-used ([THM] grade)', 24, mut(R, lambda d: d['records'].__setitem__([x['id'] for x in d['records']].index('RER-TRIAD-FORMAL-AGE'), next(x for x in {G16R}['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE'))))
('A25 FORMAL-AGE statement altered beyond the grade tag', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'].__setitem__(0, next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'][0].replace('unique', 'canonical', 1))))
('A25 FORMAL-AGE contract cell changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['contract'].update(Memory='edited')))
('A25 FORMAL-AGE import changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['imports'].pop()))
('A25 FORMAL-AGE grade-provenance line dropped', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'].remove(next(l for l in next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'] if l.startswith('**Grade provenance**')))))
('A25 FORMAL-AGE task changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE').update(task='CLOSED')))
('A25 r16 gap entries re-used (G9 text hash of r4.10)', 24, mut(R, lambda d: d.update(gap_entries={G16R}['gap_entries'])))
('A25 a G9 reference line changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G9')['references'][-1].update(section='6.3 (edited)')))
('A25 another gap entry changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G10').update(text_sha256='0' * 64)))
('A25 another record changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED')))
('A25 RECOG source-table hash changed', 24, mut(R, lambda d: d['source_table']['RECOG'].update(sha256={G21s})))
('A25 RECOG source-table description left in the r16 state', 24, mut(R, lambda d: d['source_table']['RECOG'].update(description={G16R}['source_table']['RECOG']['description'])))
('A25 another source-table entry changed', 24, mut(R, lambda d: d['source_table']['FORMAL'].update(description='edited')))
('A26 v0.3.22 promoted to BYTE_VERIFIED without bytes', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED')))
('A26 v0.3.22 hash replaced', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(sha256='0' * 64)))
('A26 RECOG owner entry left in the r16 state (v0.3.21 current)', 25, mut(C, lambda d: d['owner_current'].update(RECOG={M16}['owner_current']['RECOG'])))
('A26 r13-r16 BYTE_VERIFIED history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r13_r16')))
('A26 r12 OWNER_REPORTED history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r12')))
('A26 r6-r11 BYTE_VERIFIED v0.3.20 history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r6_r11')))
('A26 superseded v0.3.21 identity dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('superseded')))
('A26 v0.3.20 frozen edition dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('frozen_edition')))
('A26 v0.3.20 frozen statement dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['frozen_edition'].pop('frozen')))
('A26 G1 freeze-record hash dropped from the frozen statement', 25, mut(C, lambda d: d['owner_current']['RECOG']['frozen_edition'].update(frozen='FROZEN 19 Oct 2026 — OWNER_REPORTED (v0.3.21 release record; record bytes are not held here)')))
('A26 RECOG row left UNCHANGED_VERIFIED/VERIFIED (r16 state)', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='UNCHANGED_VERIFIED', status='VERIFIED')))
('A26 RECOG row given the v0.3.21 hash as verified current hash', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(verified_current_hash={G21s})))
('A26 RECOG pin silently moved to v0.3.22', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(cited_version='0.3.22', cited_sha256={G22s})))
('A26 G9/1 per-reference audit marked done', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG' and x['n'] == 1).update(gap_reference_review='AUDITED')))
('A26 RECOG row line range not covered by the section check', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(lines=[517, 560])))
('A26 receiver section-check receipt dropped from a RECOG row', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').pop('receiver_section_check')))
('A28 r16 matrix rows re-used', 27, mut(C, lambda d: d.update(rows={M16}['rows'])))
('A28 an unchanged-owner row status changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(status='VERIFIED')))
('A28 an RRF row pin hash changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(cited_sha256='0' * 64)))
('A28 a Dyadic row authentication changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(authentication='RECEIVER_BYTE_VERIFIED')))
('A28 G9/1 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 1).update(gap_reference_review='CLOSED')))
('A28 G9/3 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 3).update(gap_reference_review='CLOSED')))
('A28 warning disposition dropped', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition')))
('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited')))
('A28 OFN owner entry changed', 27, mut(C, lambda d: d['owner_current']['OFN'].update(note='edited')))
('A28 r17 watch item dropped', 27, mut(C, lambda d: d['watch_items'].pop()))
('A28 Triadic source authority changed', 27, mut(C, lambda d: d['owner_catalog']['source_authority'].update(Triadic='edited')))
('A29 RRF083 row left CURRENT/VERIFIED (r16 state)', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='CURRENT', status='VERIFIED')))
('A29 RRF083 row left RECEIVER_BYTE_VERIFIED', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(authentication='RECEIVER_BYTE_VERIFIED')))
('A29 RRF083 pin hash altered', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(cited_sha256='0' * 64)))
('A29 RRF083 given the v0.8.3 hash as verified current hash', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(verified_current_hash={H83s})))
('A29 RRF082 left UNCHANGED_OWNER_REPORTED (r16 state)', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED')))
('A29 RRF owner entry left in the r16 state (v0.8.3 current)', 28, mut(C, lambda d: d['owner_current'].update(RRF={M16}['owner_current']['RRF'])))
('A29 v0.8.4 relabelled HASH_VERIFIED_BY_RECEIVER', 28, mut(C, lambda d: d['owner_current']['RRF'].update(evidence='HASH_VERIFIED_BY_RECEIVER')))
('A29 superseded v0.8.3 record dropped', 28, mut(C, lambda d: d['owner_current']['RRF'].pop('superseded')))
('A31 FORMAL-AGE grade tag back to THM', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE').update(grade_tags=['THM'])))
('A31 grade-provenance line without the author statement', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'].__setitem__(0, next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'][0].replace('written by the author of the result', 'an independent review', 1))))
('A31 claim line left [THM]', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'].__setitem__(0, '[THM]' + next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'][0][5:])))
('A31 FORMAL-AGE adoption promoted', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE').update(adoption_status='ADOPTED')))
('A31 watch item without the grade change', 30, mut(C, lambda d: d['watch_items'].__setitem__(-1, d['watch_items'][-1].replace('primary grade [ALG]', 'grade unchanged', 1))))
('A32 RECOG v0.3.22 relabelled BYTE_VERIFIED_HERE', 31, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED_HERE')))
('A32 a Dyadic row given the v6.4.19 hash as verified current hash', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(verified_current_hash={D19s})))
('A32 an RRF pin moved to v0.8.4', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(cited_version='0.8.4', cited_sha256={F84s})))
('A32 adoption-record reference dropped from the RRF note', 31, mut(C, lambda d: d['owner_current']['RRF'].update(note='adopted 20 Oct 2026')))
('A32 a RECOG row marked CURRENT', 31, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='CURRENT')))'''.split('\n')
t = t[:i] + '    T = [' + (',\n         ').join(keep + NEWC) + ']' + t[j:]
# file and input controls for the new gates (inserted before the A30 manifest control)
t = one(t, "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt'); had = os.path.isfile(SUMS)",
        "    o16 = B.rd('inputs/phaseA_r16_outputs/check_phaseA_output_r16.txt')\n"
        "    _, rr = gates(outs, verbose=False, inp={'inputs/phaseA_r16_outputs/check_phaseA_output_r16.txt': o16.replace(b'30/30 gates PASS', b'29/30 gates PASS', 1)}); good = not rr[23]; allf &= good\n"
        "    print(f'  input control A24 r16 checker record altered: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    _, rr = gates(outs, verbose=False, withhold=('FORMAL__FORMAL_AGE_FAMILY_REVIEW.md',)); good = not rr[30]; allf &= good\n"
        "    print(f'  file control A31 FORMAL source review withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt'); had = os.path.isfile(SUMS)")
a = '"""Phase A r16 gates on RER v0.2 DRAFT r4.10 (r16: source r4.10, G9 W3 text only).'; assert t.count(a) == 1
t = t.replace(a, '"""Phase A r17 gates on RER v0.2 DRAFT r4.11 (r17: source r4.11; Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 owner-reported).\n'
  'r17: A19 requires Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 as current. A23/A26/A29 (re-based): the new current versions are OWNER_REPORTED with no\n'
  'held file; v6.4.18, v0.3.21 (byte-verified here) and v0.8.3 (receiver-hashed; bytes held since r15) are kept as superseded identities with their file,\n'
  'custody and section-check evidence; v0.3.20 is kept as the frozen RECOG edition with its G1 record named; RER pins are unchanged; DYAD6418 and the RECOG\n'
  'rows are UNCHANGED_OWNER_REPORTED, RRF082/RRF083 RECHECK_IN_PHASE_B, and no row carries a verified current hash for these owners. A24 pins r4.11, its\n'
  'package and the r4.10/r4.9/r4.8 bases and keeps the r13, r15 and r16 checker records. A25 compares with the pinned r16 registry: only RER-TRIAD-FORMAL-AGE\n'
  '(grade [THM] -> [ALG] with the same statement), RER-G9 text_sha256 and the RECOG source-table description change. A28 compares with the pinned r16\n'
  'matrix: rows of other owners differ only by path_in_r4_11_package; Dyadic/RECOG/RRF rows only in owner-currency fields. A31 records the FORMAL-AGE grade\n'
  'change; A32 keeps the three new owner versions OWNER_REPORTED only. The r16 A23-A26/A28/A29 wording and controls are retired; their results stay in the\n'
  'pinned r16 record.\n'
  'Earlier wording, kept as history: Phase A r16 gates on RER v0.2 DRAFT r4.10 (r16: source r4.10, G9 W3 text only).', 1)
open(C, 'w', encoding='utf-8').write(t)
print('patched B')
