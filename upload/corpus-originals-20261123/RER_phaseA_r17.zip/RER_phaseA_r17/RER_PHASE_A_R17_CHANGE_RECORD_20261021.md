# RER Phase A r17: change record

**Date:** 21 Oct 2026.
**From:** Claude, RER co-owner (preparer). The receiver decides on acceptance.
**Status:** NONCANONICAL Phase A pass. Nothing is adopted, frozen or published. No Markdown edited; no grade, status, owner or pin changed by the builder.
**Authorized by:** the receiving decision of 21 Oct 2026: RER r4.11 ACCEPT SCOPED; Phase A r17 authorized. Conditions:
- run on the exact r4.11 bytes;
- parse FORMAL-AGE `primary_grade` / `grade_tags` as `[ALG]`;
- renew the G9 text hash;
- keep the other 18 records, all import pins and every scientific OPEN state;
- catalog Dyadic v6.4.19, RRF v0.8.4 and RECOG v0.3.22 as `OWNER_REPORTED` only.

## 1. Inputs

| Object | SHA-256 |
|---|---|
| Source: RER r4.11 | `2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8` |
| r4.11 package | `f55652773396fe5ed56b22659aa603dfa267f09f420e7c7089ae6d5c92d43073` (manifest in `inputs/r4_11_package_SHA256SUMS.txt`) |
| Base r4.10 | `5b1d0654…b53c` (listed in the r4.11 manifest) |
| Phase A r16 outputs and checker output | kept unchanged under `inputs/phaseA_r16_outputs/` (pinned) |

- **Built by:** `patch_r17a.py` (catalog and builder) and `patch_r17b.py` (gates), run on a fresh copy of the r16 package.

## 2. Owner catalog (all three new versions OWNER_REPORTED)

| Owner | Current (r17) | Hash (stated in the owner record) | Kept as superseded | Owner record (project path; bytes of the new file not held) |
|---|---|---|---|---|
| Dyadic | v6.4.19 | `40c9e63f…6ec9` | v6.4.18 `f70308f1…458d`, BYTE_VERIFIED (file, custody r14, section check) | `claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md`; owner-side verification record `claude/RTG_DYADIC_v6_4_19_RELEASE_VERIFICATION_RECORD.md` reports external release verification, not replayed here |
| RECOG | v0.3.22 | `0dcce9e4…bcd9` | v0.3.21 `a3459522…0ae3`, BYTE_VERIFIED (file, custody r13, section check). Frozen edition v0.3.20 `fdb8c9a7…b8df` kept, frozen status OWNER_REPORTED; the G1 record `5c00f66d…9b55` is named, its bytes not held | `claude/RECOG_v0_3_22_RELEASE_RECORD.md` |
| RRF | v0.8.4 | `2fb0a0fe…afce` | v0.8.3 `b393657e…a187`, HASH_VERIFIED_BY_RECEIVER; bytes also held since r15 | `claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md` |

The earlier history entries are kept, and each owner gains one entry for the r13/r14–r16 state.

**Key rules:** no pin changes.

| Key | Rule change | Reason (r17 text appended) |
|---|---|---|
| DYAD6418 (pin v6.4.18) | CURRENT → **UNCHANGED_OWNER_REPORTED** | v6.4.19 release record: §2 byte-identical to v6.4.18 (owner-run R11); new §6.14 only; no other result, grade or OPEN status changed; §6.17 equality not checked here |
| RECOG (pin v0.3.20) | UNCHANGED_VERIFIED → **UNCHANGED_OWNER_REPORTED** | v0.3.22 additive (pre-existing RIDs keep statement and grade); v0.3.21 → v0.3.22 section equality not checked; the v0.3.20 → v0.3.21 section check stays on record |
| RRF083 (pin v0.8.3) | CURRENT → **RECHECK_IN_PHASE_B** | the v0.8.4 adoption record names a live B-∞ status correction and the W3 owner scope, with no per-section change list; cited §2.3/§2.4b not checked |
| RRF082 (pin v0.8.2) | UNCHANGED_OWNER_REPORTED → **RECHECK_IN_PHASE_B** | same reason (cited §2.4b/§4.2) |
| DYAD6413, RRF08_ADOPTED | unchanged (RECHECK_IN_PHASE_B) | r17 note appended |

The receiver's limit is kept: adoption of a newer owner version does not show section equality and does not change an older attribution.

## 3. Result

**Registry, against r16:** exactly three things change.
- **RER-TRIAD-FORMAL-AGE:**
  - `primary_grade` `[ALG] (formal; source grade, r4.11)`, `grade_tags` `['ALG']`;
  - claim line `[THM]` → `[ALG]` with the same statement;
  - Evidence and Review receipt extended, and `prior_review_receipt` follows;
  - one grade-provenance line among the unclassified lines.
  
  Contract, imports, OPEN, task and adoption are unchanged.
- **RER-G9:** `text_sha256`.
- **Source table:** the RECOG description.

**Matrix:** 91 rows, as before.
- The 73 rows of other owners and families differ only by `path_in_r4_11_package`.
- 18 Dyadic/RECOG/RRF rows change only in owner-currency fields. Pins, bytes and authentication are unchanged.
- Status: VERIFIED 28, OWNER_REPORTED 5, HISTORICAL 52, BLOCKED 6. In r16 it was 32/3/50/6.
- The sync warning (incl. disposition) and the blocked register are unchanged.
- G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.

## 4. Gates: 32/32 PASS; negative controls 137/137 fail as required

**Re-based:**
- **A19:** current versions are v6.4.19, v0.3.22 and v0.8.4; the earlier versions are rejected as current.
- **A23, A26, A29:** the new versions are OWNER_REPORTED with no held file. The superseded identities keep their file, custody and section-check evidence. RECOG's frozen edition names the G1 record. Row currencies are as in §2, and no verified current hash is set.
- **A24:** r4.11, its package and the r4.10/r4.9/r4.8 bases; the r13, r15 and r16 checker records.
- **A25:** equality with the r16 registry, as in §3. For FORMAL-AGE, the claim must equal the r16 claim with only the tag changed.
- **A28:** equality with the r16 matrix, as in §3.

**New:**
- **A31:** the FORMAL-AGE grade change is recorded. It requires the grade-provenance line with the FORMAL hash, the source grade, the result-author statement and the r2 review hash; the FORMAL file held and cited; adoption PENDING; and the watch item.
- **A32:** the three new versions are OWNER_REPORTED only. That means the record-stated hash, no file with that hash, no verified current hash, no pin moved, not CURRENT, and record and authority entries naming the owner record.

**Controls:** 121 tampers plus 16 file and input controls. The r16 controls for A23–A26, A28 and A29 are retired and replaced.
- **New tampers include:**
  - each owner left in its r16 state;
  - the new versions promoted to BYTE_VERIFIED or HASH_VERIFIED_BY_RECEIVER;
  - pins moved to the new versions;
  - DYAD6418, RECOG and RRF083 rows left in their r16 currency;
  - history, superseded or frozen entries dropped;
  - the G1 hash dropped;
  - the r16 FORMAL-AGE record re-used;
  - the FORMAL-AGE statement, contract, import or task altered;
  - the grade-provenance line dropped or its author statement replaced;
  - the claim line left `[THM]`;
  - adoption promoted.
- **New file and input controls:** the FORMAL source withheld (A31); the r16 checker record altered (A24).

**Correction made while building:**
- A25 first assumed the grade-provenance line was appended at the end of the unclassified lines; the parser places it first, in document order. The check now requires exactly one added line with every other line unchanged.
- The two related controls now target that line.
- A31 and A32 were first placed before A30, which shifted control indices; they now follow A30.

**Clean extraction:** run twice with `python -I -B`; output byte-identical to the stored `check_phaseA_output.txt`. The manifest lists no bytecode cache (A30).

## 5. Open (unchanged)

- G9/1 and G9/3 per-reference audits.
- G2 §5b.
- The two ER-2B blocks.
- Phase B author-conflicted records outside B-06.
- Optional: byte verification and section checks of Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4, should the original files be supplied. Only these would change OWNER_REPORTED.
