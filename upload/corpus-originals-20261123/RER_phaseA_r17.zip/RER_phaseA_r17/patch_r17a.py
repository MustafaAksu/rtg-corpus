"""Phase A r16 -> r17, part A (catalog + builder): receiving decision of 21 Oct 2026 (RER r4.11 ACCEPT SCOPED; Phase A r17 authorized).
- Source Markdown: RER r4.11 (2cd3f0e9...4dd8; package f5565277...3073) replaces r4.10; r4.11 package manifest added; rows carry path_in_r4_11_package.
- Owner catalog: Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 current, all OWNER_REPORTED (hashes as stated in the owner records; bytes not held).
  v6.4.18 / v0.3.21 / v0.8.3 kept as superseded identities with their earlier evidence; v0.3.20 kept as the frozen edition.
- Keys: DYAD6418 CURRENT -> UNCHANGED_OWNER_REPORTED; RECOG UNCHANGED_VERIFIED -> UNCHANGED_OWNER_REPORTED; RRF083 CURRENT -> RECHECK_IN_PHASE_B;
  RRF082 UNCHANGED_OWNER_REPORTED -> RECHECK_IN_PHASE_B; DYAD6413 and RRF08_ADOPTED reasons extended. No pin changes.
Args: TARGET_DIR R411_PACKAGE_DIR."""
import sys, os, json, shutil, hashlib
D, P411 = sys.argv[1:3]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
R411 = '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8'; R411Z = 'f55652773396fe5ed56b22659aa603dfa267f09f420e7c7089ae6d5c92d43073'
R410 = '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c'; R410Z = 'ac3dd7768a3109645fcec3f7500c14f62804ccb853727e0755237194d1447041'
MD11 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_11.md'; MD10 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_10.md'
D19 = '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'; D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
G22 = '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'
G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'; G1R = '5c00f66dae7d4de6ccd4a04d642a23edfc861bbd6bd55e432513747fbd679b55'
F84 = '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'; H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
m11 = open(os.path.join(P411, MD11), 'rb').read(); assert sha(m11) == R411
assert not any(x == '__pycache__' for _, ds, _ in os.walk(D) for x in ds)
os.remove(os.path.join(D, 'SHA256SUMS.txt'))  # a fresh manifest is written at packaging
H = os.path.join(D, 'inputs/phaseA_r16_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r16.txt'))
os.remove(os.path.join(D, MD10)); open(os.path.join(D, MD11), 'wb').write(m11)
os.remove(os.path.join(D, 'RER_PHASE_A_R16_CHANGE_RECORD_20261020.md'))
shutil.copyfile(os.path.join(P411, 'SHA256SUMS.txt'), os.path.join(D, 'inputs/r4_11_package_SHA256SUMS.txt'))

# ---- known-versions ledger
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
assert (KV['Dyadic'], KV['RECOG'], KV['RRF']) == ('6.4.18', '0.3.21', '0.8.3')
KV['Dyadic'] = '6.4.19'; KV['RECOG'] = '0.3.22'; KV['RRF'] = '0.8.4'; KV['_catalog_checked'] = '2026-10-21 (Phase A r17, preparer)'
SA = KV['_source_authority']
SA['Dyadic'] = ('owner release record claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md and owner-side release verification record claude/RTG_DYADIC_v6_4_19_RELEASE_VERIFICATION_RECORD.md '
                '(owner-reported; v6.4.19 bytes not held here). Superseded v6.4.18: bytes held and hashed here (sources_available, inputs/source_custody_r14.json), hash independently '
                'confirmed by the receiver. Earlier v6.4.17: bytes held and hashed here (sources_available, inputs/source_custody_r9.json), hash independently confirmed by the receiver.')
SA['RECOG'] = ('owner release record claude/RECOG_v0_3_22_RELEASE_RECORD.md (owner-reported; v0.3.22 bytes not held here). Superseded v0.3.21: bytes held and hashed here '
               '(sources_available, inputs/source_custody_r13.json), hash independently confirmed by the receiver. Frozen v0.3.20: file byte-verified here (sources_available); its frozen '
               'status (19 Oct 2026) is owner-reported (v0.3.21 release record; RECOG G3 notice to RER, which names the freeze record).')
SA['RRF'] = ('adoption record claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md (owner-reported; v0.8.4 bytes not held here). Superseded v0.8.3: adoption record; file hashed '
             'by the receiving co-owner; bytes also held and hashed here since Phase A r15 (sources_available, inputs/source_custody_r15.json).')
open(p, 'w').write(dump(KV))

# ---- owner catalog
p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p)); OC = CS['owner_current']
dy = OC['Dyadic']; assert dy['version'] == '6.4.18' and dy['sha256'] == D18 and dy['evidence'] == 'BYTE_VERIFIED'
hist = dict(dy['history']); hist['phaseA_r14_r16'] = {'version': '6.4.18', 'sha256': D18, 'evidence': 'BYTE_VERIFIED', 'note': dy['note']}
OC['Dyadic'] = {
    'version': '6.4.19', 'sha256': D19, 'evidence': 'OWNER_REPORTED', 'history': hist,
    'note': ('adopted 20 Oct 2026 per its release record (claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md); the hash is the one stated there and was not computed in this package '
             '(bytes not held here). The owner-side release verification record (claude/RTG_DYADIC_v6_4_19_RELEASE_VERIFICATION_RECORD.md, 21 Oct 2026) reports an external '
             'release verification (RELEASE VERIFIED / ADOPTED; file hash PASS); not replayed here. Per the release record: new DYAD-THM-LPHASE-ROWA-REMAINDER [THM] (§6.14 '
             'L-PHASE row A) and three artifact IDs (RIDs 132 → 136, none removed); §2 and §3 byte-identical to v6.4.18 (owner-run release checker R11); no other result, RID '
             'grade or OPEN status changed; OPEN 20 PARTIAL, B-an and B-6 OPEN.'),
    'superseded': {'version': '6.4.18', 'sha256': D18, 'evidence': 'BYTE_VERIFIED (Phase A r14: file held, custody r14, section check; hash receiver-confirmed)'}}
rc = OC['RECOG']; assert rc['version'] == '0.3.21' and rc['sha256'] == G21 and rc['evidence'] == 'BYTE_VERIFIED' and rc['superseded']['version'] == '0.3.20'
hist = dict(rc['history']); hist['phaseA_r13_r16'] = {'version': '0.3.21', 'sha256': G21, 'evidence': 'BYTE_VERIFIED', 'note': rc['note']}
fz = dict(rc['superseded'])
fz['frozen'] = ('FROZEN 19 Oct 2026 — OWNER_REPORTED (stated in the v0.3.21 release record: "v0.3.20 (frozen 19 Oct 2026)", and in the RECOG G3 notice to RER (53341b9a…14b5, '
                f'received via the PI on 21 Oct 2026), which names the freeze record RECOG_v0_3_20_FREEZE_DECISION_PROVENANCE.md, SHA-256 {G1R}; that record\'s bytes are not held '
                'here; RER r4.11 records the frozen status)')
OC['RECOG'] = {
    'version': '0.3.22', 'sha256': G22, 'evidence': 'OWNER_REPORTED', 'history': hist,
    'note': ('adopted 20 Oct 2026 per its release record (claude/RECOG_v0_3_22_RELEASE_RECORD.md); hash stated there, not computed here (bytes not held here). Per the record: '
             'eight scientific RIDs and four artifact IDs added (§6.13b, A1a phase interface), none lost; every pre-existing RID keeps its statement and grade; R6 and every '
             'other OPEN status unchanged; not frozen; independent release verification optional and not claimed.'),
    'superseded': {'version': '0.3.21', 'sha256': G21, 'evidence': 'BYTE_VERIFIED (Phase A r13: file held, custody r13, section check; hash receiver-confirmed)'},
    'frozen_edition': fz}
rf = OC['RRF']; assert rf['version'] == '0.8.3' and rf['sha256'] == H83 and rf['evidence'] == 'HASH_VERIFIED_BY_RECEIVER'
OC['RRF'] = {
    'version': '0.8.4', 'sha256': F84, 'evidence': 'OWNER_REPORTED',
    'history': {'phaseA_to_r16': {'version': '0.8.3', 'sha256': H83, 'evidence': 'HASH_VERIFIED_BY_RECEIVER', 'note': rf['note']}},
    'note': ('adopted 20 Oct 2026 as the RRF working representation standard per its adoption record (claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md); hash '
             'stated there, not computed here (bytes not held here). Per the record: editorial/publication metadata and a new adoption boundary; the reviewed scientific '
             'assertions are not modified; the reviewer checked a live B-∞ status correction and the W3 owner scope (RECOG v0.3.21 same cohomology space; different-space '
             'transport an OPEN additional RRF interface); RRF OPEN-A/B/E not closed. No per-section change list is given.'),
    'superseded': {'version': '0.8.3', 'sha256': H83, 'evidence': 'HASH_VERIFIED_BY_RECEIVER (adoption-record hash, receiver-hashed; bytes also held and hashed here since Phase A r15, custody r15)'}}
K = CS['keys']
k = K['DYAD6418']; assert k['rule'] == 'CURRENT'
k['rule'] = 'UNCHANGED_OWNER_REPORTED'
k['reason'] += (' Phase A r17: current Dyadic is v6.4.19 (owner-reported, bytes not held). Per its release record §2 (including OPEN 20) is byte-identical to v6.4.18 (owner-run '
                'release checker R11), the change is the new §6.14 L-PHASE result, and no other result, RID grade or OPEN status changed; byte equality of the cited §6.17 is not '
                'checked here. Currency UNCHANGED_OWNER_REPORTED; the RER pin stays on v6.4.18 (bytes held and verified here).')
k = K['DYAD6413']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r17: current Dyadic is v6.4.19 (owner-reported; §2 and §3 byte-identical to v6.4.18 and only §6.14 added, per its release record). Rule unchanged; RER '
                'pins stay on v6.4.13.')
k = K['RECOG']; assert k['rule'] == 'UNCHANGED_VERIFIED'
k['rule'] = 'UNCHANGED_OWNER_REPORTED'
k['reason'] += (' Phase A r17: current RECOG is v0.3.22 (owner-reported, bytes not held). Its release record states that every pre-existing RID keeps its statement and grade and '
                'that the RID set only grows; byte equality of §6.6a and §6.16g between v0.3.21 and v0.3.22 is not checked here. Currency UNCHANGED_OWNER_REPORTED; the '
                'v0.3.20 → v0.3.21 section check stays on record; RER pins stay on v0.3.20 (frozen 19 Oct 2026, owner-reported).')
k = K['RRF083']; assert k['rule'] == 'CURRENT'
k['rule'] = 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r17: current RRF is v0.8.4 (owner-reported, bytes not held). Its adoption record names a live B-∞ status correction and the W3 owner scope but gives '
                'no per-section change list; the cited §2.3 and §2.4b are not byte-checked against v0.8.4. Currency RECHECK_IN_PHASE_B; the RER pin stays on v0.8.3 (bytes held '
                'and verified here).')
k = K['RRF082']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED'
k['rule'] = 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r17: current RRF is v0.8.4 (owner-reported, bytes not held). Its adoption record gives no per-section change list and names a live B-∞ status '
                'correction; the cited §2.4b/§4.2 are not checked against v0.8.4. Currency RECHECK_IN_PHASE_B; the RER pin stays on v0.8.2.')
k = K['RRF08_ADOPTED']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += '; Phase A r17: current RRF is v0.8.4 (owner-reported); rule unchanged, RER pin stays on v0.8'
CS['_about'] += (' Phase A r17 (21 Oct): source RER r4.11; Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 current (all OWNER_REPORTED); v6.4.18, v0.3.21 and v0.8.3 kept as '
                 'superseded identities; v0.3.20 kept as the frozen RECOG edition; no pin changed.')
open(p, 'w').write(dump(CS))

# ---- builder
rp('build_phaseA.py', [
 ('"""RER Phase A r16 builder (deterministic; r16 runs on RER r4.10 (G9 W3 text only);',
  '"""RER Phase A r17 builder (deterministic; r17 runs on RER r4.11 (FORMAL-AGE grade [ALG], G9 source fidelity) with the Dyadic v6.4.19 / RECOG v0.3.22 / RRF v0.8.4 catalog; r16 runs on RER r4.10 (G9 W3 text only);'),
 (f"MD = '{MD10}'\nMD_SHA = '{R410}'\nR410_ZIP_SHA = '{R410Z}'\n", f"MD = '{MD11}'\nMD_SHA = '{R411}'\nR411_ZIP_SHA = '{R411Z}'\nBASE_R410_SHA = '{R410}'\nR410_ZIP_SHA = '{R410Z}'\n"),
 ("    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.10 hash mismatch'", "    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.11 hash mismatch'"),
 ("pkg410 = man('inputs/r4_10_package_SHA256SUMS.txt')\n", "pkg410 = man('inputs/r4_10_package_SHA256SUMS.txt'); pkg411 = man('inputs/r4_11_package_SHA256SUMS.txt')\n"),
 ("'path_in_r4_10_package': path in pkg410, 'cited_path': path,", "'path_in_r4_10_package': path in pkg410, 'path_in_r4_11_package': path in pkg411, 'cited_path': path,"),
 ("'RER-REGISTRY-PHASEA/16'", "'RER-REGISTRY-PHASEA/17'"), ("'RER-SOURCE-CURRENCY/16'", "'RER-SOURCE-CURRENCY/17'"), ("'RER-BLOCKED-SOURCES/16'", "'RER-BLOCKED-SOURCES/17'"),
 ("'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R410_ZIP_SHA, 'base_r4_9_sha256': BASE_R49_SHA,",
  "'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R411_ZIP_SHA, 'base_r4_10_sha256': BASE_R410_SHA, 'base_r4_10_package_zip_sha256': R410_ZIP_SHA, 'base_r4_9_sha256': BASE_R49_SHA,"),
 ("    return {'out/RER_REGISTRY_v0_2_r4_10_PHASEA.json': dump(reg),", "    return {'out/RER_REGISTRY_v0_2_r4_11_PHASEA.json': dump(reg),"),
 ("'# RER r4.10 — source-currency matrix (Phase A r16, noncanonical)'", "'# RER r4.11 — source-currency matrix (Phase A r17, noncanonical)'"),
 ("'# RER r4.10 — blocked-source register (Phase A r16, noncanonical)'", "'# RER r4.11 — blocked-source register (Phase A r17, noncanonical)'"),
 ("| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 / r4.10 pkg |", "| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 / r4.10 / r4.11 pkg |"),
 ("{yn(x['path_in_r4_10_package'])} |", "{yn(x['path_in_r4_10_package'])} / {yn(x['path_in_r4_11_package'])} |"),
 ("The r15 line above (W3 waiting for RF-1) is kept as history.']}",
  "The r15 line above (W3 waiting for RF-1) is kept as history.',\n"
  "                          'Phase A r17 (21 Oct 2026): source is RER r4.11 (2cd3f0e9…4dd8; package f5565277…3073), accepted ACCEPT SCOPED as a DRAFT: RER-TRIAD-FORMAL-AGE primary grade [ALG] (formal; the source grade of FORMAL_AGE_FAMILY_REVIEW b170dbff…3899, B-06 grade/provenance correction; the earlier [THM] rested on the result author\\'s own review); statement, scope, FORMAL_ONLY, imports and OPEN unchanged; RER-G9 W1/W3 quote RECOG §6.16g verbatim; RECOG v0.3.20 recorded frozen 19 Oct 2026 (G1 record 5c00f66d…9b55). Owner catalog: Dyadic v6.4.19 (40c9e63f…6ec9), RECOG v0.3.22 (0dcce9e4…bcd9) and RRF v0.8.4 (2fb0a0fe…afce) current, all OWNER_REPORTED (bytes not held); v6.4.18, v0.3.21 and v0.8.3 kept as superseded identities with their earlier evidence; no RER pin changed. DYAD6418 and the RECOG rows UNCHANGED_OWNER_REPORTED; RRF082 and RRF083 RECHECK_IN_PHASE_B. Adoption of a newer owner version does not show section equality or change an older attribution. G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.']}"),
])
p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/r4_11_package_SHA256SUMS.txt'] + ['inputs/phaseA_r16_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched A')
