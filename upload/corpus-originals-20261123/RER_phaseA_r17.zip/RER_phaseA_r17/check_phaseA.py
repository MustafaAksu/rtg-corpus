"""Phase A r17 gates on RER v0.2 DRAFT r4.11 (r17: source r4.11; Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4 owner-reported).
r17: A19 requires Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 as current. A23/A26/A29 (re-based): the new current versions are OWNER_REPORTED with no
held file; v6.4.18, v0.3.21 (byte-verified here) and v0.8.3 (receiver-hashed; bytes held since r15) are kept as superseded identities with their file,
custody and section-check evidence; v0.3.20 is kept as the frozen RECOG edition with its G1 record named; RER pins are unchanged; DYAD6418 and the RECOG
rows are UNCHANGED_OWNER_REPORTED, RRF082/RRF083 RECHECK_IN_PHASE_B, and no row carries a verified current hash for these owners. A24 pins r4.11, its
package and the r4.10/r4.9/r4.8 bases and keeps the r13, r15 and r16 checker records. A25 compares with the pinned r16 registry: only RER-TRIAD-FORMAL-AGE
(grade [THM] -> [ALG] with the same statement), RER-G9 text_sha256 and the RECOG source-table description change. A28 compares with the pinned r16
matrix: rows of other owners differ only by path_in_r4_11_package; Dyadic/RECOG/RRF rows only in owner-currency fields. A31 records the FORMAL-AGE grade
change; A32 keeps the three new owner versions OWNER_REPORTED only. The r16 A23-A26/A28/A29 wording and controls are retired; their results stay in the
pinned r16 record.
Earlier wording, kept as history: Phase A r16 gates on RER v0.2 DRAFT r4.10 (r16: source r4.10, G9 W3 text only).
r16: A24 pins r4.10, its package and the r4.9/r4.8 bases, the r4.9 identity in the r4.10 manifest, path_in_r4_10_package on every row, and the r13 and
r15 checker records. A25 compares with the pinned r15 registry: records and source table equal; among the gap entries only RER-G9 text_sha256 changes.
A28 compares with the pinned r15 matrix: rows differ only by path_in_r4_10_package; owners, warning and blocked register unchanged; G9 audits pending.
A30 the package manifest lists no bytecode cache. The r14/r15 A25 (r13 registry) and r15 A28 (r14 matrix) are retired; their results stay in the pinned records.
Earlier wording, kept as history: Phase A r15 gates on RER v0.2 DRAFT r4.9 (r15: SYNC-DYAD-OPEN20-BINF receiving disposition; RRF v0.8.3 bytes).
r15: A27 also requires the receiving disposition CLOSED — SOURCE_SYNCHRONIZED linked to the pinned r14 receiving review (hash recomputed), its
scope boundary, and the unchanged computed CHECK status. A28 now compares with the pinned r14 outputs (only the RRF083 row byte evidence, the RRF083
byte-gap entry and the disposition may differ; G9 audits stay pending). A29 RRF083 BYTE_VERIFIED_HERE only with the real file and custody r15;
the RRF owner-level evidence stays HASH_VERIFIED_BY_RECEIVER. The r14 A28 (r13 matrix equality) is retired; its result stays in the pinned r14 checker record.
Earlier wording, kept as history: Phase A r14 gates on RER v0.2 DRAFT r4.9 (r12: owner-currency catalog update; r13: RECOG v0.3.21 byte verification; r14: source r4.9, Dyadic v6.4.18 byte verification).
r14 (replaces the A23/A24/A25/A27/A28 wording below, which is kept as history): A23 Dyadic v6.4.18 BYTE_VERIFIED only with the real file, custody r14 and the
v6.4.17 -> v6.4.18 section check (3 identical, 2 changed, pattern as expected); v6.4.17 identity and r8, r9-r11, r12-r13 history kept; DYAD6413 row: pin v6.4.13,
RECHECK_IN_PHASE_B, sync link; DYAD6418 row: CURRENT, VERIFIED, bytes matched. A24 r4.9 source and bases pinned; path_in_r4_9_package on every row; the r13 outputs
and their 28/28 checker record kept (the r9/r10 regression gates of r10-r13 are retired; their results stay in that record). A25 registry equality with r13 except the
r4.9 synchronization of the DYAD record. A27 SYNC-DYAD-OPEN20-BINF recomputed: a live line is a whole Markdown line; the old OPEN line is only quoted; replacement lines
live; status CHECK, never CLOSED. A28 matrix equality with r13 (90 rows; only path_in_r4_9_package and the DYAD6413 owner-evidence fields change) plus one DYAD6418 row. Markdown is re-read by plain line scanning, independent of tools/rer_parse.py.
Exit 0 iff all pass; --tamper runs negative controls (each must fail its named gate).
A1 r4.6 source SHA and input pins. A2 determinism: a fresh build equals the stored outputs byte for byte (same parser; not a second
independent parser). A3 record set: Markdown headings vs JSON ids, same order, 20, no duplicates, gaps separate.
A4 literal field mirror: every line reproduced by a structured JSON field (grade line, six contract cells, claim lines, named fields,
each import line and each OPEN line, imports/OPENs/claims in order) is re-found verbatim in the record's Markdown span; every non-blank
span line is either such a line or listed verbatim in unclassified_lines (no line dropped). Line order across different fields is
not reconstructed, and the meaning of a line is not checked.
A5 one matrix row per record import and per gap reference; required fields. A6 byte and package-path claims (r4.4 and r4.5
manifests). A7 stale owner pins carry a non-CURRENT status and a reason. A8 ER-2B firewall. A9 no promotion. A10 RRF-CND01
provenance split. A11 legacy snapshot separate. A12 blocked register complete. A13 packaging finding complete and repaired in r4.5.
A14 receiver status vocabulary. A15 gap-reference coverage (13 G7-G10 Reference lines, equal to the receiver crosswalk; each records the received
editor disposition and a pending per-reference audit as two separate fields). A16 authentication vocabulary (BYTE_VERIFIED_HERE iff bytes matched here; RECEIVER_BYTE_VERIFIED only for
receiver-reported keys; no hash => UNAUTHENTICATED_NO_HASH). A17 13/13 gap-reference cited_path non-null and equal to the
link target of the reference line (bracket-aware). A18 blocked register records the RRF-editor hashes exactly where r4.6 states them
(Q7), the coincidence ZIP keeps no hash, and both ER-2B records stay blocked. A19 owner currency: owner_current equals the pinned latest adopted versions
(inputs/owner_versions_known.json); in particular Dyadic v6.4.15, Dyadic v6.4.16 and OFN v0.9 are rejected as current; the frozen catalog carries its check
date, scope (not live discovery) and per-owner source authority, mirrored in the matrix. A20 the editor response is pinned by hash.
A21 owner-current evidence discipline: evidence is in the catalog vocabulary; BYTE_VERIFIED only with matching bytes in sources_available;
OFN v0.10 stays OWNER_REPORTED with the release-record hash, v0.9 recorded as superseded, and no OFN row carries a verified current hash.
A22 source custody: every sources_available file added in r6 has a custody entry (key, sha256, container) whose hash equals the file
and the cited hash; the container chain is marked preparer-declared. ER01 record-import rows stay BLOCKED although ER01 bytes are present;
the ER01 gap reference (G8/0) is HISTORICAL with verified bytes and a pending per-reference audit (r7, A6-G8-01).
A23 Dyadic currency (r9): v6.4.17 is current with evidence BYTE_VERIFIED, which requires the real file in sources_available with the expected
hash and a matching custody entry (inputs/source_custody_r9.json); the r8 OWNER_REPORTED state is kept as history; v6.4.16 recorded as superseded;
the section-check record shows both file hashes MATCH and 5/5 blocks IDENTICAL; every Dyadic row carries the v6.4.17 hash as verified current hash,
owner evidence BYTE_VERIFIED and a non-CURRENT currency; the DYAD6413 pin stays v6.4.13 with its cited hash and receiver authentication.
--tamper also runs a file-level control: the checker is re-run with the v6.4.17 file withheld from sources_available, and A23 must fail.
A24 r4.7 source pass (r10): the outputs record the r4.7 source and package hashes and the r4.6 base; the matrix equals the pinned r9 matrix
row for row (identity, cited hash, bytes, authentication, currency, status) except exactly one added RECORD_IMPORT row RRF083 in
RER-DYAD-FORMAL-INVOLUTION (n=2; cited v0.8.3 with the adopted hash; CURRENT; RECEIVER_BYTE_VERIFIED; OWNER_REPORTED); every row carries
path_in_r4_7_package; the registry equals the pinned r9 registry for the other 19 records, and for RER-DYAD-FORMAL-INVOLUTION differs only in
text fields (r11, on r4.8: primary_grade '[THM] (owner grade)' and grade_tags ['THM'] as in r9; exactness, task, adoption and OPEN items unchanged).
A25 equality with the r10 outputs (r11): the 90 matrix rows equal the pinned r10 rows in every identity/evidence field and carry path_in_r4_8_package;
the other 19 registry records equal r10; RER-DYAD-FORMAL-INVOLUTION differs from r10 only in primary_grade, primary_grade_line, grade_tags and
unclassified_lines (the source-note line), with primary_grade '[THM] (owner grade)', grade_tags ['THM'] and exactly one unclassified source-note line
carrying DYAD-ALG-CENT-KERNEL [ALG]; the r10 outputs are present unchanged under inputs/phaseA_r10_outputs/.
r12: in A24/A25 the owner-currency fields (currency, status, current_owner_version, verified_current_hash) of Dyadic and RECOG rows are excluded
from the identity comparison; they are checked exactly by A23 (Dyadic) and A26 (RECOG). A23 (r12): Dyadic current v6.4.18 OWNER_REPORTED with the
release-record hash and no held file; v6.4.17 superseded with its BYTE_VERIFIED identity (file, custody r9, section check still required); r8 and
r9-r11 states in history; Dyadic rows: no verified current hash, OWNER_REPORTED, currency RECHECK_IN_PHASE_B, sync_warning set; DYAD6413 pin v6.4.13.
A26 RECOG currency: v0.3.21 OWNER_REPORTED, no held file; v0.3.20 superseded BYTE_VERIFIED with its file held and its frozen status OWNER_REPORTED;
RECOG rows UNCHANGED_OWNER_REPORTED / OWNER_REPORTED, bytes still matched, no verified current hash. A27 scientific sync warning
SYNC-DYAD-OPEN20-BINF: present, tied to RER-DYAD-FORMAL-INVOLUTION/DYAD6413, owner v6.4.18 OWNER_REPORTED; status recomputed from the source:
OPEN while every listed line is present in the Markdown, and never CLOSED by Phase A.
A26 (r13, replaces the r12 wording above): RECOG v0.3.21 current with evidence BYTE_VERIFIED, which requires the real file in sources_available with the
expected hash, a matching custody entry (inputs/source_custody_r13.json) and the section-check record (both hashes MATCH, 2/2 IDENTICAL, no change hunk
inside the cited blocks, RESULT PASS) whose v0.3.20 line ranges equal the `lines` of the two RECOG rows; history keeps r6-r11 (BYTE_VERIFIED v0.3.20) and
r12 (OWNER_REPORTED v0.3.21); v0.3.20 superseded with its BYTE_VERIFIED identity and frozen status; RECOG rows: pins v0.3.20 with the original hash,
UNCHANGED_VERIFIED, VERIFIED, verified current hash v0.3.21, PENDING_PER_REFERENCE_AUDIT kept. A28 (r13) equality with the pinned r12 outputs: the 90 matrix rows
equal r12 in every field except, for the two RECOG rows only, currency, currency_reason, status, current_owner_evidence, verified_current_hash and
receiver_section_check; registry and blocked register equal r12 except schema; owner_current equal except RECOG; sync warnings equal; one watch item added.
--tamper also runs file/input controls: v0.3.21 file withheld; section-check output altered; custody hash altered.
r10 wording kept as history: (r10, on r4.7: exactness, task, adoption and OPEN items unchanged; primary_grade starts with the r9 value '[THM] (owner grade)' and, because the
parser reads up to '. **Exactness', now also holds the O3 per-RID labels, so grade_tags is ['ALG', 'THM'] - finding R10-F1, recorded, not repaired)."""
import sys, os, re, json, hashlib, copy
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); import build_phaseA as B
sha = lambda b: hashlib.sha256(b).hexdigest()
CAT_PINS = {'catalog_sources.json': None, 'catalog_records.json': None}  # filled from PINS file
PINS = json.load(open(os.path.join(HERE, 'PINS.json')))
md = open(os.path.join(HERE, B.MD), encoding='utf-8').read()
L = md.split('\n')

def md_records():
    out, cur = [], None
    for ln in L:
        m = re.match(r'^### (RER-[A-Z0-9-]+) — ', ln)
        if m or ln.startswith('## ') or ln.startswith('<a id='):
            if cur: out.append(cur); cur = None
        if m: cur = {'id': m.group(1), 'lines': []}
        elif cur is not None: cur['lines'].append(ln)
    if cur: out.append(cur)
    return out

def gates(outs, verbose=True, withhold=(), inp=None):
    res = []; inp = inp or {}
    ri = lambda p: inp[p] if p in inp else B.rd(p)
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_11_PHASEA.json']); cm = json.loads(outs['out/SOURCE_CURRENCY_MATRIX.json']); br = json.loads(outs['out/BLOCKED_SOURCE_REGISTER.json'])
    g('A1 source and catalog pins', sha(md.encode()) == B.MD_SHA and all(sha(open(os.path.join(HERE, f), 'rb').read()) == h for f, h in PINS['inputs'].items()))
    fresh = B.build()
    g('A2 deterministic rebuild equals stored outputs', all(fresh[p] == outs[p] for p in fresh) and set(fresh) == set(outs))
    mr = md_records(); gaps = {'RER-G7', 'RER-G8', 'RER-G9', 'RER-G10'}
    mids = [r['id'] for r in mr if r['id'] not in gaps]; jids = [r['id'] for r in reg['records']]
    g('A3 record set mirrors Markdown', mids == jids and len(set(jids)) == len(jids) == 20 and sorted(x['id'] for x in reg['gap_entries']) == sorted(gaps), f'{len(jids)} records')
    bad = []; nlines = 0; nuncl = 0
    for r in mr:
        if r['id'] in gaps: continue
        j = next((x for x in reg['records'] if x['id'] == r['id']), None)
        if j is None: bad.append((r['id'], 'missing')); continue
        span = r['lines']; spanset = set(span)
        gl = next((l for l in span if l.startswith('**Primary grade:**')), '')
        if j['primary_grade'] is None or j['primary_grade'] not in gl or ('`' + j['task'] + '`') not in gl or j.get('primary_grade_line') != gl: bad.append((r['id'], 'grade/task'))
        struct = {gl, '| Field | Contract |', '|---|---|'}
        for row in ['Carrier', 'Observables', 'Constraints', 'Transformation law', 'Closure status', 'Memory']:
            cell = next((l for l in span if l.startswith('| ' + row + ' | ')), None)
            if cell is None or cell != f"| {row} | {j['contract'][row]} |": bad.append((r['id'], row))
            struct.add(f"| {row} | {j['contract'][row]} |")
        if [l for l in span if l.startswith('Import/reference:')] != [i['line'] for i in j['imports']]: bad.append((r['id'], 'import lines'))
        if [l for l in span if l.startswith('[OPEN] ')] != ['[OPEN] ' + o for o in j['open_items']]: bad.append((r['id'], 'OPEN lines'))
        if [l for l in span if re.match(r'^\[(THM|ALG|NUM|DEF)\]', l)] != j['claim_lines']: bad.append((r['id'], 'claim lines'))
        for k, v in j['fields'].items():
            if v is not None:
                if f"**{k}:** {v}" not in spanset: bad.append((r['id'], k))
                struct.add(f"**{k}:** {v}")
        struct |= set(j['claim_lines']) | {'[OPEN] ' + o for o in j['open_items']} | {i['line'] for i in j['imports']}
        if any(u not in spanset for u in j['unclassified_lines']): bad.append((r['id'], 'unclassified not in span'))
        left = [l for l in span if l.strip() and l not in struct and l not in set(j['unclassified_lines'])]
        if left: bad.append((r['id'], f'{len(left)} lines unaccounted'))
        nlines += sum(1 for l in span if l.strip()); nuncl += len(j['unclassified_lines'])
    g('A4 literal field mirror; every record line accounted for', not bad, f'{len(bad)} mismatches {bad[:2]}; {nlines} lines, {nuncl} unclassified (verbatim)')
    need = ['record', 'key', 'source_doc', 'cited_version', 'cited_sha256', 'current_owner_version', 'current_owner_sha256', 'section_or_RID', 'inspection_extent', 'currency', 'reviewer_disposition', 'bytes_status']
    gaprefs = [l for r in mr if r['id'] in gaps for l in r['lines'] if l.startswith('Reference:')]
    occ = sum(len(x['imports']) for x in reg['records']) + len(gaprefs)
    keys_ok = all(all(k in x for k in need) for x in cm['rows'])
    g('A5 one currency row per record import and per gap reference, required fields present', len(cm['rows']) == occ and keys_ok and all(x['reviewer_disposition'] == 'PENDING' for x in cm['rows']), f'{len(cm["rows"])} rows')
    bb = []
    pkg = B.rd('inputs/r4_4_package_SHA256SUMS.txt').decode(); pkg45 = B.rd('inputs/r4_5_package_SHA256SUMS.txt').decode(); pkg46 = B.rd('inputs/r4_6_package_SHA256SUMS.txt').decode(); pkg47 = B.rd('inputs/r4_7_package_SHA256SUMS.txt').decode(); pkg48 = B.rd('inputs/r4_8_package_SHA256SUMS.txt').decode(); pkg49 = B.rd('inputs/r4_9_package_SHA256SUMS.txt').decode(); pkg410 = B.rd('inputs/r4_10_package_SHA256SUMS.txt').decode(); pkg411 = B.rd('inputs/r4_11_package_SHA256SUMS.txt').decode()
    for x in cm['rows']:
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH':
            f = os.path.join(HERE, x['available_file'] or '')
            if not os.path.isfile(f) or sha(open(f, 'rb').read()) != x['cited_sha256']: bb.append(x['key'])
        elif x['available_file']: bb.append(x['key'])
        if x['path_in_r4_4_package'] and ('  ' + x['cited_path'] + '\n') not in pkg: bb.append(x['key'] + ':pkg')
        if x['path_in_r4_5_package'] and ('  ' + x['cited_path'] + '\n') not in pkg45: bb.append(x['key'] + ':pkg45')
        if x['path_in_r4_6_package'] and ('  ' + x['cited_path'] + '\n') not in pkg46: bb.append(x['key'] + ':pkg46')
        if x.get('path_in_r4_7_package') and ('  ' + x['cited_path'] + '\n') not in pkg47: bb.append(x['key'] + ':pkg47')
        if x.get('path_in_r4_8_package') and ('  ' + x['cited_path'] + '\n') not in pkg48: bb.append(x['key'] + ':pkg48')
        if x.get('path_in_r4_9_package') and ('  ' + x['cited_path'] + '\n') not in pkg49: bb.append(x['key'] + ':pkg49')
        if x.get('path_in_r4_10_package') and ('  ' + x['cited_path'] + '\n') not in pkg410: bb.append(x['key'] + ':pkg410')
        if x.get('path_in_r4_11_package') and ('  ' + x['cited_path'] + '\n') not in pkg411: bb.append(x['key'] + ':pkg411')
    g('A6 byte and package-path claims are true', not bb, f'{bb[:3]}')
    st = [x for x in cm['rows'] if x['source_family'] == 'OWNER_DSN' and x['current_owner_version'] and x['cited_version'] != x['current_owner_version']
          and (x['currency'] in ('CURRENT',) or not x['currency_reason'])]
    g('A7 stale owner pins carry a non-CURRENT status and a reason', not st, f'{len(st)} stale')
    er = [x for x in reg['records'] if x['id'] in ('RER-ER2B-T6D', 'RER-ER2B-CARRIER')]
    g('A8 ER-2B firewall', len(er) == 2 and all(x['phaseA_status'] == 'BLOCKED_SOURCE_UNVERIFIED' and x['accepted_cohort_eligible'] is False and x['grade_status'] == 'SOURCE_CLAIMED_NOT_RER_ADOPTED' for x in er)
      and all(x['accepted_cohort_eligible'] for x in reg['records'] if x not in er))
    g('A9 no promotion: adoption PENDING everywhere', all(x['adoption_status'] == 'PENDING' and x['registry_owner_adoption'].startswith('pending') for x in reg['records']))
    c = next(x for x in reg['records'] if x['id'] == 'RER-RRF-CND01')
    g('A10 RRF-CND01 provenance split', c['claim_provenance'] == 'RER_NATIVE_STANDARD_MATH' and '[DEF] proposed interface' in c.get('provenance_note', '') and 'NOT the source of the [THM]' in c.get('provenance_note', ''))
    lg = reg['legacy_v0_1_snapshot']
    g('A11 legacy v0.1 snapshot separate', lg['label'] == 'HISTORICAL_SNAPSHOT_NOT_AN_ADOPTION_COHORT' and len(lg['entries']) == 16 and not set(e['key'] for e in lg['entries']) & set(jids))
    srcs = {b['source'] for b in br['blocked']}
    mpi = {m for x in reg['records'] for m in x['missing_primary_inputs']}
    dna = {re.findall(r'`([^`]+)`', l)[1] for l in L if l.startswith('| `') and 'Direct source not available' in l}
    erb = next((b for b in br['blocked'] if b['source'] == 'RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'), {})
    g('A12 blocked register complete', mpi <= srcs and dna <= srcs and set(erb.get('blocked_records', [])) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'}, f'{len(srcs)} sources')
    lost = sorted(set(x['key'] for x in cm['rows'] if x['path_in_r4_package'] and not x['path_in_r4_4_package']))
    rep_ok = all(x['path_in_r4_5_package'] and x['path_in_r4_6_package'] for x in cm['rows'] if x['key'] in lost) and br.get('repaired_in_r4_5') == lost
    g('A13 packaging finding complete; every lost file carried by r4.5 at its cited path', lost == br['lost_in_packaging'] and all(k in br['packaging_finding'] for k in lost) and rep_ok, f'{len(lost)} files')
    st_ok = all(x['status'] in ('VERIFIED', 'OWNER_REPORTED', 'HISTORICAL', 'BLOCKED') and x['status'] == B.status_of(x) for x in cm['rows'])
    vh_ok = all((x['verified_current_hash'] is None) or (x['current_owner_evidence'] in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER') and x['verified_current_hash'] == x['current_owner_sha256']) for x in cm['rows'])
    ver_ok = all(x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in cm['rows'] if x['status'] == 'VERIFIED')
    g('A14 receiver status vocabulary and verified-hash discipline', st_ok and vh_ok and ver_ok)
    xw = json.loads(B.rd('inputs/RECEIVER_GAP_REFERENCE_CROSSWALK_20261019.json'))
    jg = [(gp['id'], q['line']) for gp in reg['gap_entries'] for q in gp['references']]
    mg = [(r['id'], l) for r in mr if r['id'] in gaps for l in r['lines'] if l.startswith('Reference:')]
    rows_g = [x for x in cm['rows'] if x['row_kind'] == 'GAP_REFERENCE']
    g('A15 gap-reference coverage (13; equals receiver crosswalk; editor disposition received, per-reference audit pending)', len(mg) == 13 and jg == mg and sorted(l for _, l in mg) == sorted(r['reference_text'] for r in xw['rows'])
      and len(rows_g) == 13 and all(x.get('interface_questions', '').startswith('EDITOR_DISPOSITION_RECEIVED') and x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' and 'phaseC_disposition' not in x for x in rows_g), f'{len(rows_g)} rows')
    CSK = json.loads(B.rd('catalog_sources.json'))['keys']
    def auth(x):
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH': return 'BYTE_VERIFIED_HERE'
        if CSK.get(x['key'], {}).get('receiver_byte_verified'): return 'RECEIVER_BYTE_VERIFIED'
        return 'HASH_PRINTED_UNVERIFIED' if x['cited_sha256'] else 'UNAUTHENTICATED_NO_HASH'
    g2 = [x for x in cm['rows'] if x['key'] == 'G2NOTE04']
    g('A16 authentication vocabulary; G2NOTE04 unauthenticated', all(x['authentication'] == auth(x) for x in cm['rows']) and bool(g2) and all(x['authentication'] == 'UNAUTHENTICATED_NO_HASH' for x in g2))
    def target(l):
        i = l.index('['); depth = 0
        for k in range(i, len(l)):
            depth += (l[k] == '[') - (l[k] == ']')
            if depth == 0: break
        assert l[k + 1] == '(' or l[k + 1:k + 3] == ' ('
        j = l.index('(', k + 1); return __import__('urllib.parse').parse.unquote(l[j + 1:l.index(')', j)])
    gp = [(x['cited_path'], target(next(q['line'] for gg in reg['gap_entries'] if gg['id'] == x['record'] for q in [gg['references'][x['n']]]))) for x in rows_g]
    g('A17 gap-reference paths: 13/13 non-null and equal to the link target', len(gp) == 13 and all(p and p == t for p, t in gp), f'{sum(1 for p, t in gp if p and p == t)}/13')
    Q7 = json.loads(B.rd('inputs/rrf_editor_q7_hashes.json'))
    bys = __import__('collections').defaultdict(lambda: {'blocked_records': []}, {b['source']: b for b in br['blocked']})
    g('A18 Q7 custody in the blocked register; ZIP unhashed; ER-2B still blocked',
      bys['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md'].get('rrf_editor_sha256') == Q7['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md']
      and bys['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'].get('rrf_editor_sha256') == Q7['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']
      and 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip' in bys and 'rrf_editor_sha256' not in bys['ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip']
      and set(bys['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']['blocked_records']) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'})
    KV = json.loads(B.rd('inputs/owner_versions_known.json'))
    oc = cm['owner_current']
    meta = cm.get('owner_catalog', {})
    g('A19 owner currency equals the frozen catalog; Dyadic v6.4.15-v6.4.18, RECOG v0.3.20/v0.3.21, RRF v0.8.3 and OFN v0.9 not current; catalog date/scope/authority recorded', all(oc.get(o, {}).get('version') == v for o, v in KV.items() if not o.startswith('_'))
      and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16', '6.4.17', '6.4.18') and oc['RECOG']['version'] == '0.3.22' and oc['RRF']['version'] == '0.8.4' and oc['OFN']['version'] == '0.10' and all(x['current_owner_version'] == oc[x['owner']]['version'] for x in cm['rows'] if x['owner'] in oc)
      and meta.get('checked') == KV['_catalog_checked'] and meta.get('scope') == KV['_scope'] and 'not live release discovery' in meta.get('scope', '')
      and meta.get('source_authority') == KV['_source_authority'] and set(KV['_source_authority']) == set(oc), f"Dyadic {oc['Dyadic']['version']}, OFN {oc['OFN']['version']}")
    g('A20 RRF editor response pinned', sha(B.rd('inputs/RRF_EDITOR_RESPONSE_TO_RER_PHASEA_v0_2_20261019.md')) == '413a869b49a295652af1379510fbece2d10619daffd5874c1320e1d686113084')
    avail = {sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) for f in os.listdir(os.path.join(HERE, 'sources_available')) if f not in withhold}
    ev_ok = all(v['evidence'] in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER', 'OWNER_REPORTED', 'PRINTED_ONLY') and (v['evidence'] != 'BYTE_VERIFIED' or v['sha256'] in avail) for v in oc.values())
    o = oc['OFN']
    ofn_ok = (o['evidence'] == 'OWNER_REPORTED' and o['sha256'] == 'acb70a8cfc7962abcc047dedffb59e9ceca8f2e9843d6203df6eba54f5ed5dfa'
              and o.get('superseded', {}).get('version') == '0.9' and o['superseded'].get('sha256') == '5ae8fdabad35a370f5709afa4d5dca6491e154c75f8a6f15fbb32d251fe59795'
              and all(x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT' for x in cm['rows'] if x['owner'] == 'OFN'))
    g('A21 owner-current evidence discipline; OFN v0.10 owner-reported only', ev_ok and ofn_ok)
    CU = json.loads(B.rd('inputs/source_custody_r6.json'))['files']
    cited = {}
    for x in cm['rows']: cited.setdefault(x['key'], set()).add(x['cited_sha256'])
    cu_ok = len(CU) == 14 and all(os.path.isfile(os.path.join(HERE, 'sources_available', f)) and sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) == e['sha256'] and cited.get(e['key']) == {e['sha256']} and f.startswith(e['key'] + '__') and e.get('container') for f, e in CU.items())
    er_rec = [x for x in cm['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'RECORD_IMPORT']
    er_gap = [x for x in cm['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'GAP_REFERENCE']
    er_ok = (len(er_rec) == 3 and all(x['status'] == 'BLOCKED' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in er_rec)
             and [(x['record'], x['n']) for x in er_gap] == [('RER-G8', 0)] and all(x['status'] == 'HISTORICAL' and x['currency'] == 'SNAPSHOT_RECHECK_IN_PHASE_B' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['gap_reference_review'] == 'PENDING_PER_REFERENCE_AUDIT' for x in er_gap)
             and json.loads(B.rd('inputs/source_custody_r6.json')).get('container_chain_status', '').startswith('PREPARER_DECLARED'))
    g('A22 r6 source custody (container chain preparer-declared); ER01 record rows blocked, G8/0 historical', cu_ok and er_ok, f'{len(CU)} custody entries')
    dy = oc['Dyadic']; D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'; D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
    dyrows = [x for x in cm['rows'] if x['owner'] == 'Dyadic']
    C9 = json.loads(B.rd('inputs/source_custody_r9.json')); f9 = C9['files'].get('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md', {})
    sc = B.rd('inputs/dyad_v6_4_17_section_check/compare_output.txt').decode('utf-8')
    sc_ok = (sc.count('IDENTICAL') == 5 and 'RESULT: PASS' in sc and 'DIFFERENT' not in sc and 'v6.4.16 33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0 MATCH' in sc
             and f'v6.4.17 {D17} MATCH' in sc)
    FN18 = 'DYAD6418__RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md'; P18 = os.path.join(HERE, 'sources_available', FN18)
    f18_ok = FN18 not in withhold and os.path.isfile(P18) and sha(open(P18, 'rb').read()) == D18
    C14 = json.loads(ri('inputs/source_custody_r14.json')); f14 = C14.get('files', {}).get(FN18, {})
    s18 = ri('inputs/dyad_v6_4_18_section_check/compare_output.txt').decode('utf-8')
    s18_ok = (f'v6.4.17 {D17} MATCH' in s18 and f'v6.4.18 {D18} MATCH' in s18 and s18.count(' IDENTICAL ') == 3 and s18.count(' CHANGED ') == 2 and 'RESULT: PASS' in s18
              and 'release-record expectation (OPEN 19, §6.15, §6.16 identical; OPEN 20, §6.17 changed): True' in s18)
    D19 = '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'
    hs = dy.get('history', {})
    r13 = [x for x in dyrows if x['key'] == 'DYAD6413']; r18 = [x for x in dyrows if x['key'] == 'DYAD6418']
    dy_ok = (dy['version'] == '6.4.19' and dy['sha256'] == D19 and dy['evidence'] == 'OWNER_REPORTED' and D19 not in avail and D18 in avail and D17 in avail and f18_ok
             and 'claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md' in dy.get('note', '') and 'not replayed here' in dy.get('note', '') and 'bytes not held here' in dy.get('note', '')
             and f14.get('key') == 'DYAD6418' and f14.get('sha256') == D18 and bool(f14.get('container')) and C14.get('container_chain_status', '').startswith('PREPARER_DECLARED') and s18_ok
             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok
             and hs.get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED' and hs.get('phaseA_r9_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r9_r11'].get('sha256') == D17
             and hs.get('phaseA_r12_r13', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12_r13'].get('sha256') == D18 and hs['phaseA_r12_r13'].get('version') == '6.4.18'
             and hs.get('phaseA_r14_r16', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r14_r16'].get('sha256') == D18 and hs['phaseA_r14_r16'].get('version') == '6.4.18'
             and dy.get('superseded', {}).get('version') == '6.4.18' and dy['superseded'].get('sha256') == D18 and dy['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and len(dyrows) == 2 and len(r13) == 1 and len(r18) == 1
             and all(x['cited_version'] == '6.4.13' and x['cited_sha256'] == '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED'
                     and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' and x['verified_current_hash'] is None
                     and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['current_owner_version'] == '6.4.19' for x in r13)
             and all(x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' and x['row_kind'] == 'RECORD_IMPORT' and x['n'] == 3 and x['cited_version'] == '6.4.18' and x['cited_sha256'] == D18
                     and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['available_file'] == 'sources_available/' + FN18
                     and x['currency'] == 'UNCHANGED_OWNER_REPORTED' and x['status'] == 'OWNER_REPORTED' and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED'
                     and x['current_owner_version'] == '6.4.19' and 'Phase A r17' in x['currency_reason'] and x['path_in_r4_9_package'] is True
                     and x.get('receiver_section_check', '').startswith('RECEIVER-REPORTED') for x in r18))
    g('A23 Dyadic v6.4.19 owner-reported (bytes not held); v6.4.18 byte-verified identity kept as superseded (file, custody r14, section check); v6.4.17 identity and r8-r16 history kept; DYAD6413 pin v6.4.13 RECHECK; DYAD6418 pin v6.4.18 UNCHANGED_OWNER_REPORTED', dy_ok, f'{len(dyrows)} Dyadic rows')
    sm = reg['source_markdown']
    H13 = 'inputs/phaseA_r13_outputs/'; o13 = ri(H13 + 'check_phaseA_output_r13.txt').decode('utf-8'); H15 = 'inputs/phaseA_r15_outputs/'; o15 = ri(H15 + 'check_phaseA_output_r15.txt').decode('utf-8')
    H16 = 'inputs/phaseA_r16_outputs/'; o16 = ri(H16 + 'check_phaseA_output_r16.txt').decode('utf-8')
    man411 = B.rd('inputs/r4_11_package_SHA256SUMS.txt').decode()
    src_ok = (sm['file'].endswith('_r4_11.md') and sm['sha256'] == B.MD_SHA == '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8' and sm['package_zip_sha256'] == 'f55652773396fe5ed56b22659aa603dfa267f09f420e7c7089ae6d5c92d43073'
              and sm.get('base_r4_10_sha256') == '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c' and sm.get('base_r4_10_package_zip_sha256') == 'ac3dd7768a3109645fcec3f7500c14f62804ccb853727e0755237194d1447041'
              and sm.get('base_r4_9_sha256') == '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84' and sm.get('base_r4_8_sha256') == '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'
              and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA
              and all('path_in_r4_11_package' in x for x in cm['rows']) and '28/28 gates PASS' in o13 and '29/29 gates PASS' in o15 and '30/30 gates PASS' in o16 and 'BAD' not in o13 + o15 + o16
              and '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c  RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_10.md\n' in man411)
    g('A24 r4.11 source pass: r4.11, package and r4.10/r4.9/r4.8 bases pinned; r4.10 identity in the r4.11 manifest; every row carries path_in_r4_11_package; r13, r15 and r16 checker records kept', src_ok)
    g16 = json.loads(B.rd(H16 + 'RER_REGISTRY_v0_2_r4_10_PHASEA.json'))
    G16 = {x['id']: x for x in g16['gap_entries']}; G17 = {x['id']: x for x in reg['gap_entries']}
    dg = sorted(k for k in G16 if G16[k] != G17.get(k))
    R16 = {x['id']: x for x in g16['records']}; R17 = {x['id']: x for x in reg['records']}
    dr = sorted(k for k in R16 if R16[k] != R17.get(k))
    a6, a7 = R16.get('RER-TRIAD-FORMAL-AGE', {}), R17.get('RER-TRIAD-FORMAL-AGE', {})
    dka = sorted(k for k in set(a6) | set(a7) if a6.get(k) != a7.get(k))
    AGEK = ['claim_lines', 'fields', 'grade_tags', 'primary_grade', 'primary_grade_line', 'prior_review_receipt', 'unclassified_lines']
    f6, f7 = a6.get('fields', {}), a7.get('fields', {})
    u6, u7 = a6.get('unclassified_lines', []), a7.get('unclassified_lines', [])
    age_ok = (dka == AGEK and a7.get('grade_tags') == ['ALG'] and a6.get('grade_tags') == ['THM'] and a7.get('primary_grade') == '[ALG] (formal; source grade, r4.11)'
              and a7.get('primary_grade_line') == a6.get('primary_grade_line', '').replace('**Primary grade:** [THM].', '**Primary grade:** [ALG] (formal; source grade, r4.11).', 1) != a6.get('primary_grade_line')
              and len(a6.get('claim_lines', [])) == len(a7.get('claim_lines', [])) == 1 and a6['claim_lines'][0].startswith('[THM] **FORMAL_ONLY.**') and a7['claim_lines'][0] == '[ALG]' + a6['claim_lines'][0][5:]
              and sorted(k for k in set(f6) | set(f7) if f6.get(k) != f7.get(k)) == ['Evidence', 'Review receipt'] and f7['Evidence'].startswith(f6['Evidence'] + ' r4.11: ') and f7['Review receipt'].startswith(f6['Review receipt'] + ' r4.11: ')
              and len(u7) == len(u6) + 1 and [l for l in u7 if not l.startswith('**Grade provenance** (r4.11):')] == u6 and sum(l.startswith('**Grade provenance** (r4.11):') for l in u7) == 1)
    st6, st7 = g16['source_table'], reg['source_table']
    dst = sorted(k for k in set(st6) | set(st7) if st6.get(k) != st7.get(k))
    st_ok = (dst == ['RECOG'] and sorted(k for k in st6['RECOG'] if st6['RECOG'][k] != st7['RECOG'].get(k)) == ['description'] and set(st6['RECOG']) == set(st7['RECOG'])
             and 'frozen 19 Oct 2026 per the G1 record `5c00f66d…9b55`' in st7['RECOG']['description'] and st7['RECOG']['sha256'] == st6['RECOG']['sha256'])
    strip = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown', 'gap_entries', 'records', 'source_table')}
    r_ok = (strip(reg) == strip(g16) and list(R16) == list(R17) and dr == ['RER-TRIAD-FORMAL-AGE'] and age_ok and st_ok and set(G16) == set(G17) and dg == ['RER-G9']
            and {k: v for k, v in G17['RER-G9'].items() if k != 'text_sha256'} == {k: v for k, v in G16['RER-G9'].items() if k != 'text_sha256'}
            and G17['RER-G9']['text_sha256'] != G16['RER-G9']['text_sha256'] and len(reg['records']) == 20 and g16['schema'] == 'RER-REGISTRY-PHASEA/16' and reg['schema'] == 'RER-REGISTRY-PHASEA/17')
    g('A25 r16 registry equality: 20 records equal except RER-TRIAD-FORMAL-AGE (grade [THM] -> [ALG], same statement; Evidence/receipt extended; one grade-provenance line); gap entries equal except RER-G9 text_sha256; source table equal except the RECOG description', r_ok, f'records differing: {dr}; FORMAL-AGE keys: {dka}; gaps: {dg}; source table: {dst}')
    rc = oc['RECOG']; G22 = '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
    G1R = '5c00f66dae7d4de6ccd4a04d642a23edfc861bbd6bd55e432513747fbd679b55'
    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']
    FN21 = 'RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md'; P21 = os.path.join(HERE, 'sources_available', FN21)
    file_ok = FN21 not in withhold and os.path.isfile(P21) and sha(open(P21, 'rb').read()) == G21
    C13 = json.loads(ri('inputs/source_custody_r13.json')); f13 = C13.get('files', {}).get(FN21, {})
    sc13 = ri('inputs/recog_v0_3_21_section_check/compare_output.txt').decode('utf-8')
    sc13_ok = (f'v0.3.20 {G20} MATCH' in sc13 and f'v0.3.21 {G21} MATCH' in sc13 and sc13.count('IDENTICAL') == 2 and 'DIFFERENT' not in sc13
               and 'hunks inside cited blocks: 0' in sc13 and 'RESULT: PASS' in sc13)
    rng = {m.group(1): [int(m.group(2)), int(m.group(3))] for m in re.finditer(r'^  (§6\.6a|§6\.16g) +v0\.3\.20 lines (\d+)-(\d+) ', sc13, re.M)}
    rows_rng_ok = len(rr_) == 2 and len(rng) == 2 and all(any(x['section_or_RID'].startswith(s + ' ') and x['lines'] == v for s, v in rng.items()) for x in rr_) and len({tuple(x['lines']) for x in rr_}) == 2
    hs = rc.get('history', {}); fz = rc.get('frozen_edition', {})
    rc_ok = (rc['version'] == '0.3.22' and rc['sha256'] == G22 and rc['evidence'] == 'OWNER_REPORTED' and G22 not in avail and G21 in avail and G20 in avail and file_ok
             and 'claude/RECOG_v0_3_22_RELEASE_RECORD.md' in rc.get('note', '') and 'bytes not held here' in rc.get('note', '')
             and f13.get('key') == 'RECOG0321' and f13.get('sha256') == G21 and bool(f13.get('container')) and C13.get('container_chain_status', '').startswith('PREPARER_DECLARED') and sc13_ok and rows_rng_ok
             and hs.get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r6_r11'].get('sha256') == G20 and hs['phaseA_r6_r11'].get('version') == '0.3.20'
             and hs.get('phaseA_r12', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12'].get('sha256') == G21 and hs['phaseA_r12'].get('version') == '0.3.21'
             and hs.get('phaseA_r13_r16', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r13_r16'].get('sha256') == G21 and hs['phaseA_r13_r16'].get('version') == '0.3.21'
             and rc.get('superseded', {}).get('version') == '0.3.21' and rc['superseded'].get('sha256') == G21 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and fz.get('version') == '0.3.20' and fz.get('sha256') == G20 and fz.get('evidence', '').startswith('BYTE_VERIFIED')
             and fz.get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED') and G1R in fz.get('frozen', '') and 'bytes are not held' in fz.get('frozen', '')
             and all(x['cited_version'] == '0.3.20' and x['cited_sha256'] == G20 and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'
                     and x['available_file'] == 'sources_available/RECOG__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md' and x['currency'] == 'UNCHANGED_OWNER_REPORTED' and x['status'] == 'OWNER_REPORTED'
                     and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['current_owner_version'] == '0.3.22' and 'Phase A r17' in x['currency_reason']
                     and x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' and x['reviewer_disposition'] == 'PENDING' and x.get('receiver_section_check', '').startswith('RECEIVER-REPORTED') for x in rr_))
    g('A26 RECOG v0.3.22 owner-reported (bytes not held); v0.3.21 byte-verified identity kept as superseded (file, custody r13, section check 2/2 IDENTICAL); v0.3.20 frozen edition kept (frozen status owner-reported, G1 record named); r6-r16 history kept; RER pins stay v0.3.20; RECOG rows UNCHANGED_OWNER_REPORTED; per-reference audit pending', rc_ok, f'{len(rr_)} RECOG rows; ranges {rng}')
    mdl = md.split('\n'); W = [w for w in cm.get('scientific_sync_warnings', []) if w.get('id') == 'SYNC-DYAD-OPEN20-BINF']
    w = W[0] if len(W) == 1 else {}
    m13 = json.loads(B.rd(H13 + 'SOURCE_CURRENCY_MATRIX.json')); w13 = (m13.get('scientific_sync_warnings') or [{}])[0]
    rl, rp_ = w.get('rer_lines', []), w.get('replacement_lines', [])
    dyr = next((x for x in reg['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION'), {})
    w_ok = (len(W) == 1 and w.get('record') == 'RER-DYAD-FORMAL-INVOLUTION' and w.get('key') == 'DYAD6413' and w.get('owner_version') == '6.4.18' and w.get('owner_evidence') == 'BYTE_VERIFIED'
            and rl == w13.get('rer_lines') and len(rl) == 2 and rl[0].startswith('[OPEN] OPEN 20 B-∞ existence:')
            and w.get('rer_lines_present') == [l in mdl for l in rl] == [False, False] and w.get('rer_lines_quoted_only') == [(l not in mdl) and (l in md) for l in rl] and w['rer_lines_quoted_only'][0] is True
            and len(rp_) == 2 and rp_[0].startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18 §6.17, §2 OPEN 20 | RID: DYAD-THM-SMOOTH-EMBEDDING]`') and rp_[1].startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 |')
            and w.get('replacement_lines_present') == [l in mdl for l in rp_] == [True, True] and rp_[0] in dyr.get('claim_lines', []) and rp_[1] in dyr.get('claim_lines', [])
            and not any(o.startswith('OPEN 20 B-∞ existence') for o in dyr.get('open_items', []))
            and w.get('status', '').startswith('CHECK — record corrected') and 'CLOSED' not in w.get('status', '') and 'catalog change alone does not close it' in w.get('closes_only_when', '')
            and w.get('rer_correction', '').startswith('RER r4.9 (9c0f43fc')
            and (w.get('receiving_disposition') or {}).get('status') == 'CLOSED — SOURCE_SYNCHRONIZED' and 'receiving_disposition_rejected' not in w
            and w['receiving_disposition'].get('decision_sha256') == '3c6d99c434a04839acf27ebfca845ae08e9482b3ae7bbfed16cc3c80a94ea7a9' == sha(ri(w['receiving_disposition'].get('decision_file', 'inputs/none')))
            and 'not an independent proof' in w['receiving_disposition'].get('scope', '') and 'B-an and B-6 stay OPEN' in w['receiving_disposition']['scope']
            and all(x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' for x in cm['rows'] if x['key'] == 'DYAD6413'))
    g('A27 SYNC-DYAD-OPEN20-BINF recomputed on r4.9: listed lines no longer live (the OPEN line only quoted), replacement lines live, B-∞ not an OPEN item; status CHECK, never CLOSED by Phase A', w_ok, w.get('status', 'missing')[:60])
    m16 = json.loads(B.rd(H16 + 'SOURCE_CURRENCY_MATRIX.json')); b16 = json.loads(B.rd(H16 + 'BLOCKED_SOURCE_REGISTER.json'))
    NEWO = ('Dyadic', 'RECOG', 'RRF')
    OWNF = {'currency', 'currency_reason', 'current_owner_evidence', 'current_owner_sha256', 'current_owner_version', 'path_in_r4_11_package', 'status', 'verified_current_hash'}
    dk = [(x['owner'], sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k))) for x, y in zip(cm['rows'], m16['rows'])]
    rows16_ok = (len(cm['rows']) == len(m16['rows']) == 91 and all((x['key'], x['record'], x['n'], x['row_kind']) == (y['key'], y['record'], y['n'], y['row_kind']) for x, y in zip(cm['rows'], m16['rows']))
                 and all(d == ['path_in_r4_11_package'] for o, d in dk if o not in NEWO)
                 and all(set(d) <= OWNF and 'path_in_r4_11_package' in d and 'current_owner_version' in d for o, d in dk if o in NEWO)
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256')}
    sa6, sa7 = m16['owner_catalog']['source_authority'], meta.get('source_authority', {})
    rest16_ok = (stripb(br) == stripb(b16) and set(oc) == set(m16['owner_current']) and all(oc[o] == m16['owner_current'][o] for o in oc if o not in NEWO)
                 and all(oc[o] != m16['owner_current'][o] for o in NEWO) and cm.get('scientific_sync_warnings') == m16.get('scientific_sync_warnings')
                 and cm['watch_items'][:-1] == m16['watch_items'] and cm['watch_items'][-1].startswith('Phase A r17 (21 Oct 2026): source is RER r4.11')
                 and meta.get('scope') == m16['owner_catalog']['scope'] and set(sa6) == set(sa7) and sorted(o for o in sa6 if sa6[o] != sa7[o]) == list(NEWO)
                 and cm['bytes_not_available_to_preparer'] == m16['bytes_not_available_to_preparer'] and m16['schema'] == 'RER-SOURCE-CURRENCY/16' and cm['schema'] == 'RER-SOURCE-CURRENCY/17')
    g('A28 r16 matrix equality: 91 rows; rows of unchanged owners differ only by path_in_r4_11_package; Dyadic/RECOG/RRF rows differ only in owner-currency fields (pins, bytes and authentication unchanged); other owners, warning, blocked register and G9 audits unchanged', rows16_ok and rest16_ok, f'{sum(1 for o, d in dk if (o not in NEWO and d != ["path_in_r4_11_package"]) or (o in NEWO and not set(d) <= OWNF))} row(s) with other differences')
    H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'; F84 = '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'
    FN83 = 'RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md'; P83 = os.path.join(HERE, 'sources_available', FN83)
    f83_ok = FN83 not in withhold and os.path.isfile(P83) and sha(open(P83, 'rb').read()) == H83
    C15 = json.loads(ri('inputs/source_custody_r15.json')); f15 = C15.get('files', {}).get(FN83, {})
    rr83 = [x for x in cm['rows'] if x['key'] == 'RRF083']; rr82 = [x for x in cm['rows'] if x['key'] == 'RRF082']; rrf = [x for x in cm['rows'] if x['owner'] == 'RRF']; orr = oc.get('RRF', {})
    a29 = (f83_ok and f15.get('key') == 'RRF083' and f15.get('sha256') == H83 and bool(f15.get('container')) and C15.get('container_chain_status', '').startswith('PREPARER_DECLARED')
           and len(rr83) == 1 and all(x['cited_sha256'] == H83 and x['cited_version'] == '0.8.3' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'
                                      and x['available_file'] == 'sources_available/' + FN83 and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL'
                                      and 'Phase A r17' in x['currency_reason'] and x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' for x in rr83)
           and len(rr82) == 1 and all(x['cited_version'] == '0.8.2' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED' and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and 'Phase A r17' in x['currency_reason'] for x in rr82)
           and len(rrf) == 14 and all(x['current_owner_version'] == '0.8.4' and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT' for x in rrf)
           and orr.get('version') == '0.8.4' and orr.get('sha256') == F84 and orr.get('evidence') == 'OWNER_REPORTED' and F84 not in avail
           and 'claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md' in orr.get('note', '') and 'bytes not held here' in orr.get('note', '')
           and orr.get('superseded', {}).get('version') == '0.8.3' and orr['superseded'].get('sha256') == H83 and orr['superseded'].get('evidence', '').startswith('HASH_VERIFIED_BY_RECEIVER')
           and orr.get('history', {}).get('phaseA_to_r16', {}).get('evidence') == 'HASH_VERIFIED_BY_RECEIVER' and orr['history']['phaseA_to_r16'].get('sha256') == H83)
    g('A29 RRF v0.8.4 owner-reported (bytes not held); v0.8.3 kept as superseded (receiver-hashed); RRF083 bytes still verified here (file, custody r15) but RECHECK_IN_PHASE_B; RRF082 RECHECK_IN_PHASE_B; no RRF row CURRENT or with a verified current hash', a29, f'{len(rrf)} RRF rows')
    SUMS = os.path.join(HERE, 'SHA256SUMS.txt')
    sums = open(SUMS, encoding='utf-8').read() if os.path.isfile(SUMS) else ''
    g('A30 package manifest lists no Python bytecode cache (__pycache__, .pyc)', '__pycache__' not in sums and '.pyc' not in sums)
    FNF = 'FORMAL__FORMAL_AGE_FAMILY_REVIEW.md'; PF = os.path.join(HERE, 'sources_available', FNF); HF = 'b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899'
    ag = next((x for x in reg['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE'), {})
    gp = [l for l in ag.get('unclassified_lines', []) if l.startswith('**Grade provenance** (r4.11):')]
    agrows = [x for x in cm['rows'] if x['record'] == 'RER-TRIAD-FORMAL-AGE']
    a31 = (FNF not in withhold and os.path.isfile(PF) and sha(open(PF, 'rb').read()) == HF and ag.get('grade_tags') == ['ALG'] and ag.get('primary_grade', '').startswith('[ALG]')
           and all(not l.startswith('[THM]') for l in ag.get('claim_lines', [])) and len(gp) == 1 and HF in gp[0] and '[ALG, formal — accepted with scope corrections]' in gp[0]
           and 'written by the author of the result' in gp[0] and 'd388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab' in gp[0] and 'statement, scope and exactness are unchanged' in gp[0]
           and ag.get('adoption_status') == 'PENDING' and ag.get('contract', {}).get('Closure status') is not None
           and any(x['key'] == 'FORMAL' and x['cited_sha256'] == HF and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in agrows)
           and 'RER-TRIAD-FORMAL-AGE primary grade [ALG]' in cm['watch_items'][-1] and 'b170dbff…3899' in cm['watch_items'][-1])
    g('A31 FORMAL-AGE grade change recorded: grade [ALG] with the grade-provenance line (FORMAL source grade b170dbff…, r2 review by the result author); FORMAL bytes held and cited; adoption PENDING; watch item', a31, f'tags {ag.get("grade_tags")}')
    NV = [('Dyadic', '6.4.19', '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9', 'claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md'),
          ('RECOG', '0.3.22', '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9', 'claude/RECOG_v0_3_22_RELEASE_RECORD.md'),
          ('RRF', '0.8.4', '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce', 'claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md')]
    allfiles = {sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) for f in os.listdir(os.path.join(HERE, 'sources_available'))}
    a32 = all(oc.get(o, {}).get('version') == v and oc[o].get('sha256') == h and oc[o].get('evidence') == 'OWNER_REPORTED' and h not in allfiles and rec in oc[o].get('note', '')
              and KV.get(o) == v and rec in KV['_source_authority'].get(o, '') and 'bytes not held here' in KV['_source_authority'][o]
              and all(x['cited_version'] != v and x['cited_sha256'] != h and x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT'
                      for x in cm['rows'] if x['owner'] == o)
              and h[:8] in cm['watch_items'][-1] for o, v, h, rec in NV) and all(x['verified_current_hash'] not in [h for _, _, h, _ in NV] for x in cm['rows'])
    g('A32 new owner versions (Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4) OWNER_REPORTED only: record-stated hashes, no held file, no verified current hash, no pin moved, not CURRENT', a32)
    return all(res), res

outs = {p: open(os.path.join(HERE, p), 'rb').read() for p in B.build()}
ok, res = gates(outs); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    def mut(path, f):
        o = dict(outs); d = json.loads(o[path]); f(d); o[path] = B.dump(d); return o
    R, C, K = 'out/RER_REGISTRY_v0_2_r4_11_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'
    T = [('A3 drop a record', 2, mut(R, lambda d: d['records'].pop(5))),
         ('A4 change a contract cell', 3, mut(R, lambda d: d['records'][0]['contract'].__setitem__('Closure status', 'CLOSED'))),
         ('A6 false byte claim', 5, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY').update(bytes_status='BYTE_VERIFIED_MATCH', available_file='sources_available/none'))),
         ('A7 stale pin marked CURRENT', 6, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'GEN287').update(currency='CURRENT'))),
         ('A8 ER-2B unblocked', 7, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-ER2B-T6D').update(phaseA_status='ACTIVE', accepted_cohort_eligible=True))),
         ('A9 promote adoption', 8, mut(R, lambda d: d['records'][3].update(adoption_status='ADOPTED'))),
         ('A12 drop a blocked source', 11, mut(K, lambda d: d['blocked'].pop(0))),
         ('A14 printed-only row labelled VERIFIED', 13, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY' and x['currency'] != 'BLOCKED').update(status='VERIFIED'))),
         ('A4 alter one import line', 3, mut(R, lambda d: d['records'][3]['imports'][0].__setitem__('line', d['records'][3]['imports'][0]['line'].replace('SHA-256', 'SHA256', 1)))),
         ('A4 drop an unclassified line', 3, mut(R, lambda d: next(x for x in d['records'] if x['unclassified_lines'])['unclassified_lines'].pop())),
         ('A15 drop a gap reference row', 14, mut(C, lambda d: d['rows'].remove(next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE')))),
         ('A16 G2NOTE04 labelled hash-printed', 15, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'G2NOTE04').update(authentication='HASH_PRINTED_UNVERIFIED'))),
         ('A17 null a gap-reference path', 16, mut(C, lambda d: next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE' and x['record'] == 'RER-G9').update(cited_path=None))),
         ('A19 Dyadic v6.4.15 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.15'))),
         ('A15 gap row back to PENDING_RRF_EDITOR', 14, mut(C, lambda d: next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE').update(phaseC_disposition='PENDING_RRF_EDITOR'))),
         ('A18 give the ZIP an editor hash', 17, mut(K, lambda d: next(b for b in d['blocked'] if b['source'] == 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip').update(rrf_editor_sha256='0' * 64))),
         ('A19 OFN v0.9 claimed current', 18, mut(C, lambda d: d['owner_current']['OFN'].update(version='0.9'))),
         ('A19 catalog scope presented as live discovery', 18, mut(C, lambda d: d['owner_catalog'].update(scope='LIVE_RELEASE_DISCOVERY'))),
         ('A21 OFN v0.10 reported hash promoted to BYTE_VERIFIED_HERE', 20, mut(C, lambda d: d['owner_current']['OFN'].update(evidence='BYTE_VERIFIED_HERE'))),
         ('A21 OFN v0.10 promoted to BYTE_VERIFIED without bytes', 20, mut(C, lambda d: d['owner_current']['OFN'].update(evidence='BYTE_VERIFIED'))),
         ('A22 ER01 record-import row unblocked', 21, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'RECORD_IMPORT').update(status='HISTORICAL'))),
         ('A22 G8/0 back to BLOCKED', 21, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'GAP_REFERENCE').update(status='BLOCKED', currency='BLOCKED'))),
         ('A21 OFN row given a verified current hash', 20, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(verified_current_hash='acb70a8cfc7962abcc047dedffb59e9ceca8f2e9843d6203df6eba54f5ed5dfa'))),
         ('A19 Dyadic v6.4.16 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.16'))),
         ('A19 Dyadic v6.4.17 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.17'))),
         ('A19 RECOG v0.3.20 claimed current', 18, mut(C, lambda d: d['owner_current']['RECOG'].update(version='0.3.20'))),
         ('A27 sync warning removed', 26, mut(C, lambda d: d.update(scientific_sync_warnings=[]))),
         ('A27 sync warning marked CLOSED by Phase A', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='CLOSED — record corrected'))),
         ('A27 sync warning left OPEN (quotation read as a live OPEN)', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='OPEN — record correction required', rer_lines_present=[True, False]))),
         ('A27 quoted-only flag forged', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(rer_lines_quoted_only=[False, False]))),
         ('A27 replacement line altered', 26, mut(C, lambda d: d['scientific_sync_warnings'][0]['replacement_lines'].__setitem__(0, d['scientific_sync_warnings'][0]['replacement_lines'][0].replace("DX'(0) = 0", 'DX(0) = 0', 1)))),
         ('A27 listed r4.8 lines altered', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(rer_lines=['[OPEN] OPEN 20 B-∞ existence: (paraphrased)', d['scientific_sync_warnings'][0]['rer_lines'][1]]))),
         ('A27 B-∞ existence re-added as a live OPEN item', 26, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['open_items'].append('OPEN 20 B-∞ existence: a C^∞ local involution'))),
         ('A27 DYAD6413 row loses its sync_warning link', 26, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').pop('sync_warning'))),
         ('A27 disposition removed', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition'))),
         ('A27 computed status overwritten with CLOSED', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='CLOSED — SOURCE_SYNCHRONIZED'))),
         ('A27 disposition carried while the record line is live (status OPEN)', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='OPEN — record correction required', rer_lines_present=[True, True]))),
         ('A27 disposition decision hash altered', 26, mut(C, lambda d: d['scientific_sync_warnings'][0]['receiving_disposition'].update(decision_sha256='0' * 64))),
         ('A27 disposition scope claims proof certification', 26, mut(C, lambda d: d['scientific_sync_warnings'][0]['receiving_disposition'].update(scope='independent proof certified; B-an and B-6 stay OPEN'))),
         ('A27 disposition rejected flag present', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(receiving_disposition_rejected='x'))),
         ('A19 Dyadic v6.4.18 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.18'))),
         ('A19 RECOG v0.3.21 claimed current', 18, mut(C, lambda d: d['owner_current']['RECOG'].update(version='0.3.21'))),
         ('A19 RRF v0.8.3 claimed current', 18, mut(C, lambda d: d['owner_current']['RRF'].update(version='0.8.3'))),
         ('A23 v6.4.19 promoted to BYTE_VERIFIED without bytes', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED'))),
         ('A23 v6.4.19 relabelled HASH_VERIFIED_BY_RECEIVER (owner-side verification taken as receiver evidence)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='HASH_VERIFIED_BY_RECEIVER'))),
         ('A23 v6.4.19 hash replaced', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64))),
         ('A23 Dyadic owner entry left in the r16 state (v6.4.18 current)', 22, mut(C, lambda d: d['owner_current'].update(Dyadic=json.loads(B.rd('inputs/phaseA_r16_outputs/SOURCE_CURRENCY_MATRIX.json'))['owner_current']['Dyadic']))),
         ('A23 r14-r16 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r14_r16'))),
         ('A23 r12-r13 OWNER_REPORTED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r12_r13'))),
         ('A23 r9-r11 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r9_r11'))),
         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r8'))),
         ('A23 superseded v6.4.18 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded'))),
         ('A23 release-record reference dropped from the note', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(note='adopted 20 Oct 2026'))),
         ('A23 DYAD6418 row left CURRENT/VERIFIED (r16 state)', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(currency='CURRENT', status='VERIFIED'))),
         ('A23 DYAD6418 row given the v6.4.18 hash as verified current hash', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(verified_current_hash='f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'))),
         ('A23 DYAD6418 pin silently moved to v6.4.19', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(cited_version='6.4.19', cited_sha256='40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'))),
         ('A23 DYAD6418 receiver section-check receipt dropped', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').pop('receiver_section_check'))),
         ('A23 DYAD6413 row given a verified current hash', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(verified_current_hash='f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'))),
         ('A23 DYAD6413 promoted to CURRENT/VERIFIED', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='CURRENT', status='VERIFIED'))),
         ('A24 source recorded as r4.10', 23, mut(R, lambda d: d['source_markdown'].update(sha256='5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c'))),
         ('A24 r4.11 package hash replaced', 23, mut(R, lambda d: d['source_markdown'].update(package_zip_sha256='0' * 64))),
         ('A24 r4.10 base dropped', 23, mut(R, lambda d: d['source_markdown'].pop('base_r4_10_sha256'))),
         ('A24 a row without path_in_r4_11_package', 23, mut(C, lambda d: d['rows'][0].pop('path_in_r4_11_package'))),
         ('A25 r16 FORMAL-AGE record re-used ([THM] grade)', 24, mut(R, lambda d: d['records'].__setitem__([x['id'] for x in d['records']].index('RER-TRIAD-FORMAL-AGE'), next(x for x in json.loads(B.rd('inputs/phaseA_r16_outputs/RER_REGISTRY_v0_2_r4_10_PHASEA.json'))['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')))),
         ('A25 FORMAL-AGE statement altered beyond the grade tag', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'].__setitem__(0, next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'][0].replace('unique', 'canonical', 1)))),
         ('A25 FORMAL-AGE contract cell changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['contract'].update(Memory='edited'))),
         ('A25 FORMAL-AGE import changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['imports'].pop())),
         ('A25 FORMAL-AGE grade-provenance line dropped', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'].remove(next(l for l in next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'] if l.startswith('**Grade provenance**'))))),
         ('A25 FORMAL-AGE task changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE').update(task='CLOSED'))),
         ('A25 r16 gap entries re-used (G9 text hash of r4.10)', 24, mut(R, lambda d: d.update(gap_entries=json.loads(B.rd('inputs/phaseA_r16_outputs/RER_REGISTRY_v0_2_r4_10_PHASEA.json'))['gap_entries']))),
         ('A25 a G9 reference line changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G9')['references'][-1].update(section='6.3 (edited)'))),
         ('A25 another gap entry changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G10').update(text_sha256='0' * 64))),
         ('A25 another record changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED'))),
         ('A25 RECOG source-table hash changed', 24, mut(R, lambda d: d['source_table']['RECOG'].update(sha256='a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'))),
         ('A25 RECOG source-table description left in the r16 state', 24, mut(R, lambda d: d['source_table']['RECOG'].update(description=json.loads(B.rd('inputs/phaseA_r16_outputs/RER_REGISTRY_v0_2_r4_10_PHASEA.json'))['source_table']['RECOG']['description']))),
         ('A25 another source-table entry changed', 24, mut(R, lambda d: d['source_table']['FORMAL'].update(description='edited'))),
         ('A26 v0.3.22 promoted to BYTE_VERIFIED without bytes', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED'))),
         ('A26 v0.3.22 hash replaced', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(sha256='0' * 64))),
         ('A26 RECOG owner entry left in the r16 state (v0.3.21 current)', 25, mut(C, lambda d: d['owner_current'].update(RECOG=json.loads(B.rd('inputs/phaseA_r16_outputs/SOURCE_CURRENCY_MATRIX.json'))['owner_current']['RECOG']))),
         ('A26 r13-r16 BYTE_VERIFIED history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r13_r16'))),
         ('A26 r12 OWNER_REPORTED history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r12'))),
         ('A26 r6-r11 BYTE_VERIFIED v0.3.20 history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r6_r11'))),
         ('A26 superseded v0.3.21 identity dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('superseded'))),
         ('A26 v0.3.20 frozen edition dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('frozen_edition'))),
         ('A26 v0.3.20 frozen statement dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['frozen_edition'].pop('frozen'))),
         ('A26 G1 freeze-record hash dropped from the frozen statement', 25, mut(C, lambda d: d['owner_current']['RECOG']['frozen_edition'].update(frozen='FROZEN 19 Oct 2026 — OWNER_REPORTED (v0.3.21 release record; record bytes are not held here)'))),
         ('A26 RECOG row left UNCHANGED_VERIFIED/VERIFIED (r16 state)', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='UNCHANGED_VERIFIED', status='VERIFIED'))),
         ('A26 RECOG row given the v0.3.21 hash as verified current hash', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(verified_current_hash='a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'))),
         ('A26 RECOG pin silently moved to v0.3.22', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(cited_version='0.3.22', cited_sha256='0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'))),
         ('A26 G9/1 per-reference audit marked done', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG' and x['n'] == 1).update(gap_reference_review='AUDITED'))),
         ('A26 RECOG row line range not covered by the section check', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(lines=[517, 560]))),
         ('A26 receiver section-check receipt dropped from a RECOG row', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').pop('receiver_section_check'))),
         ('A28 r16 matrix rows re-used', 27, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r16_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows']))),
         ('A28 an unchanged-owner row status changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(status='VERIFIED'))),
         ('A28 an RRF row pin hash changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(cited_sha256='0' * 64))),
         ('A28 a Dyadic row authentication changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(authentication='RECEIVER_BYTE_VERIFIED'))),
         ('A28 G9/1 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 1).update(gap_reference_review='CLOSED'))),
         ('A28 G9/3 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 3).update(gap_reference_review='CLOSED'))),
         ('A28 warning disposition dropped', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition'))),
         ('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited'))),
         ('A28 OFN owner entry changed', 27, mut(C, lambda d: d['owner_current']['OFN'].update(note='edited'))),
         ('A28 r17 watch item dropped', 27, mut(C, lambda d: d['watch_items'].pop())),
         ('A28 Triadic source authority changed', 27, mut(C, lambda d: d['owner_catalog']['source_authority'].update(Triadic='edited'))),
         ('A29 RRF083 row left CURRENT/VERIFIED (r16 state)', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='CURRENT', status='VERIFIED'))),
         ('A29 RRF083 row left RECEIVER_BYTE_VERIFIED', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(authentication='RECEIVER_BYTE_VERIFIED'))),
         ('A29 RRF083 pin hash altered', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(cited_sha256='0' * 64))),
         ('A29 RRF083 given the v0.8.3 hash as verified current hash', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(verified_current_hash='b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'))),
         ('A29 RRF082 left UNCHANGED_OWNER_REPORTED (r16 state)', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED'))),
         ('A29 RRF owner entry left in the r16 state (v0.8.3 current)', 28, mut(C, lambda d: d['owner_current'].update(RRF=json.loads(B.rd('inputs/phaseA_r16_outputs/SOURCE_CURRENCY_MATRIX.json'))['owner_current']['RRF']))),
         ('A29 v0.8.4 relabelled HASH_VERIFIED_BY_RECEIVER', 28, mut(C, lambda d: d['owner_current']['RRF'].update(evidence='HASH_VERIFIED_BY_RECEIVER'))),
         ('A29 superseded v0.8.3 record dropped', 28, mut(C, lambda d: d['owner_current']['RRF'].pop('superseded'))),
         ('A31 FORMAL-AGE grade tag back to THM', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE').update(grade_tags=['THM']))),
         ('A31 grade-provenance line without the author statement', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'].__setitem__(0, next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['unclassified_lines'][0].replace('written by the author of the result', 'an independent review', 1)))),
         ('A31 claim line left [THM]', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'].__setitem__(0, '[THM]' + next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE')['claim_lines'][0][5:]))),
         ('A31 FORMAL-AGE adoption promoted', 30, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-TRIAD-FORMAL-AGE').update(adoption_status='ADOPTED'))),
         ('A31 watch item without the grade change', 30, mut(C, lambda d: d['watch_items'].__setitem__(-1, d['watch_items'][-1].replace('primary grade [ALG]', 'grade unchanged', 1)))),
         ('A32 RECOG v0.3.22 relabelled BYTE_VERIFIED_HERE', 31, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED_HERE'))),
         ('A32 a Dyadic row given the v6.4.19 hash as verified current hash', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(verified_current_hash='40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'))),
         ('A32 an RRF pin moved to v0.8.4', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(cited_version='0.8.4', cited_sha256='2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'))),
         ('A32 adoption-record reference dropped from the RRF note', 31, mut(C, lambda d: d['owner_current']['RRF'].update(note='adopted 20 Oct 2026'))),
         ('A32 a RECOG row marked CURRENT', 31, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='CURRENT')))]
    allf = True
    for n, i, o in T:
        _, rr = gates(o, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rr = gates(outs, verbose=False, withhold=('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md',)); good = not rr[22]; allf &= good
    print(f'  file control A23 v6.4.17 file withheld from sources_available: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rr = gates(outs, verbose=False, withhold=('RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md',)); good = not rr[25]; allf &= good
    print(f'  file control A26 v0.3.21 file withheld from sources_available: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rr = gates(outs, verbose=False, withhold=('DYAD6418__RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md',)); good = not rr[22]; allf &= good
    print(f'  file control A23 v6.4.18 file withheld from sources_available: {"FAILS (good)" if good else "still passes (BAD)"}')
    s18 = B.rd('inputs/dyad_v6_4_18_section_check/compare_output.txt'); c14 = B.rd('inputs/source_custody_r14.json'); o13 = B.rd('inputs/phaseA_r13_outputs/check_phaseA_output_r13.txt')
    for n, p, bb, gi in [('A23 v6.4.18 section-check pattern not as expected', 'inputs/dyad_v6_4_18_section_check/compare_output.txt', s18.replace(b'): True', b'): False', 1), 22),
                         ('A23 custody r14 hash altered', 'inputs/source_custody_r14.json', c14.replace(b'f70308f19f5955c0', b'0000000000000000', 1), 22),
                         ('A24 r13 checker record altered', 'inputs/phaseA_r13_outputs/check_phaseA_output_r13.txt', o13.replace(b'28/28 gates PASS', b'27/28 gates PASS', 1), 23)]:
        _, rr = gates(outs, verbose=False, inp={p: bb}); good = not rr[gi]; allf &= good
        print(f'  input control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rr = gates(outs, verbose=False, withhold=('RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md',)); good = not rr[28]; allf &= good
    print(f'  file control A29 RRF v0.8.3 file withheld from sources_available: {"FAILS (good)" if good else "still passes (BAD)"}')
    o15 = B.rd('inputs/phaseA_r15_outputs/check_phaseA_output_r15.txt')
    _, rr = gates(outs, verbose=False, inp={'inputs/phaseA_r15_outputs/check_phaseA_output_r15.txt': o15.replace(b'29/29 gates PASS', b'28/29 gates PASS', 1)}); good = not rr[23]; allf &= good
    print(f'  input control A24 r15 checker record altered: {"FAILS (good)" if good else "still passes (BAD)"}')
    o16 = B.rd('inputs/phaseA_r16_outputs/check_phaseA_output_r16.txt')
    _, rr = gates(outs, verbose=False, inp={'inputs/phaseA_r16_outputs/check_phaseA_output_r16.txt': o16.replace(b'30/30 gates PASS', b'29/30 gates PASS', 1)}); good = not rr[23]; allf &= good
    print(f'  input control A24 r16 checker record altered: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rr = gates(outs, verbose=False, withhold=('FORMAL__FORMAL_AGE_FAMILY_REVIEW.md',)); good = not rr[30]; allf &= good
    print(f'  file control A31 FORMAL source review withheld from sources_available: {"FAILS (good)" if good else "still passes (BAD)"}')
    SUMS = os.path.join(HERE, 'SHA256SUMS.txt'); had = os.path.isfile(SUMS); keep_s = open(SUMS, 'rb').read() if had else b''
    try:
        open(SUMS, 'wb').write(keep_s + b'0' * 64 + b'  __pycache__/build_phaseA.cpython-313.pyc\n')
        _, rr = gates(outs, verbose=False); good = not rr[29]; allf &= good
        print(f'  file control A30 bytecode cache listed in the manifest: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        open(SUMS, 'wb').write(keep_s) if had else os.remove(SUMS)
    c15 = B.rd('inputs/source_custody_r15.json'); rv = B.rd('inputs/receiving_review_phaseA_r14_20261020.md')
    for n, p, bb, gi in [('A29 custody r15 hash altered', 'inputs/source_custody_r15.json', c15.replace(b'b393657e75e78ce4', b'0000000000000000', 1), 28),
                         ('A27 receiving-review file altered', 'inputs/receiving_review_phaseA_r14_20261020.md', rv + b'x', 26)]:
        _, rr = gates(outs, verbose=False, inp={p: bb}); good = not rr[gi]; allf &= good
        print(f'  input control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    sc = B.rd('inputs/recog_v0_3_21_section_check/compare_output.txt'); cu = B.rd('inputs/source_custody_r13.json')
    for n, p, b in [('section-check output shows a DIFFERENT block', 'inputs/recog_v0_3_21_section_check/compare_output.txt', sc.replace(b'IDENTICAL', b'DIFFERENT', 1)),
                    ('section-check output shows a change hunk inside a cited block', 'inputs/recog_v0_3_21_section_check/compare_output.txt', sc.replace(b'hunks inside cited blocks: 0', b'hunks inside cited blocks: 1')),
                    ('custody hash altered', 'inputs/source_custody_r13.json', cu.replace(b'a3459522c8f58204', b'0000000000000000', 1))]:
        _, rr = gates(outs, verbose=False, inp={p: b}); good = not rr[25]; allf &= good
        print(f'  input control A26 {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    ok = ok and allf
sys.exit(0 if ok else 1)
