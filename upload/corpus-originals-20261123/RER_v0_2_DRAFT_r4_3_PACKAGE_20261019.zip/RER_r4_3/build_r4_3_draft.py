"""Deterministic build: RER v0.2 DRAFT r4.2 -> r4.3 from the pinned edit list (exact-once replacements)."""
import json, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent
BASE = HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_2.md'
BASE_SHA = 'a443cc8233516f385818a7fffb010dcbacda09825edb2eccd5debd025ed77079'
EDITS_FILE = HERE / 'r4_2_to_r4_3_edits.json'
OUT = HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_3.md'
def load():
    b = BASE.read_bytes(); assert hashlib.sha256(b).hexdigest() == BASE_SHA, 'r4.2 base hash mismatch'
    return b.decode('utf-8'), json.loads(EDITS_FILE.read_text(encoding='utf-8'))
def apply(text, edits):
    for e in edits:
        n = text.count(e['old'])
        if n != 1: raise SystemExit(f"edit {e['id']}: old string occurs {n} times")
        text = text.replace(e['old'], e['new'])
    return text
if __name__ == '__main__':
    t, E = load(); out = apply(t, E).encode('utf-8'); OUT.write_bytes(out)
    print(f'built {OUT.name} ({len(E)} edits); sha256 {hashlib.sha256(out).hexdigest()}')
    print('edit list sha256', hashlib.sha256(EDITS_FILE.read_bytes()).hexdigest())
