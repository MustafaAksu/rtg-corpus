"""Edit list RER v0.2 DRAFT r4.2 -> r4.3: receiving finding R42-U5 (two current-use wording repairs in RER-F3-N7N8)."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_2.md').read_text(encoding='utf-8')
assert hashlib.sha256(B.encode()).hexdigest() == 'a443cc8233516f385818a7fffb010dcbacda09825edb2eccd5debd025ed77079'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.2\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.3\n')
ed('M2', 'metadata', '**Date:** 19 October 2026 (r4.2 and r4.1);', '**Date:** 19 October 2026 (r4.3, r4.2 and r4.1);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.2 — editorial synchronization',
   '**Document status:** DRAFT r4.3 — two current-use wording repairs in RER-F3-N7N8 (receiving finding R42-U5), built deterministically on the exact r4.2 bytes (SHA-256 `a443cc8233516f385818a7fffb010dcbacda09825edb2eccd5debd025ed77079`) by `build_r4_3_draft.py`; no record, grade or contract changes. r4.2 was: editorial synchronization')
ed('U5a', 'current-use wording (R42-U5)',
   '[OPEN] independent proof review and separately authorized full governing-region work;',
   '[OPEN] independent review of a future end-to-end governing-region certificate (distinct from the scoped one-step Taylor-model lemma review, which is reported completed: RECEIVER-REPORTED, 19 Oct 2026) and separately authorized full governing-region work;')
ed('U5b', 'current-use wording (R42-U5)', '**Next test:** (r4.1) The lemma review is done',
   '**Next test:** (r4.2 current use; first recorded in r4.1) The scoped lemma review is done')
H = '[ALG] R4.2 (19 Oct 2026) is an editorial rebuild on the exact r4.1 bytes.'
ed('H1', 'metadata', H, '[ALG] R4.3 (19 Oct 2026) answers receiving finding R42-U5 on the exact r4.2 bytes: in RER-F3-N7N8 the open item now names the future end-to-end governing-region certificate review and separates it from the completed scoped one-step lemma review (RECEIVER-REPORTED), and the Next-test line carries the current-use label. The r4.2 scientific delta was accepted scoped by the receiving co-owner. No record, grade, contract table, G5/G6 status or earlier revision text changes.\n' + H)
ed('H2', 'metadata', '**Release boundary (r4.2):**', '**Release boundary (r4.3):** r4.3 is a noncanonical review draft; it adopts, freezes and accepts nothing. **Release boundary (r4.2):**')
Path('r4_2_to_r4_3_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1), encoding='utf-8'); print(len(E), 'edits')
