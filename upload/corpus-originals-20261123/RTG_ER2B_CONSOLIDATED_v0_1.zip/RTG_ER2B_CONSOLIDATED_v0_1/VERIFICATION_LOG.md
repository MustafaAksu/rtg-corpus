# Exact check log — scoped execution on 10 October 2026

All named commands were executed successfully from their preserved source extraction or current source file. These are **scoped** validations; none asserts owner adoption or a certified physical model.

| Test | Outcome | Source scope |
|---|---|---|
| `check_genesis_sixjet_scope.py` | **PASS** | Full rational cubic jet, controls, equivariance; original source writes fixed /mnt/data path |
| `check_closed_form.py` | **23/23 PASS** | General six-coefficient quadratic classification, double sum, examples |
| `check_orientation_and_cyclic_basis.py` | **27/27 PASS** | Bridge, basis, complex coefficient; imports source G3 |
| `check_observable_response.py` | **24/24 PASS** | Imports audited source G3; signed Gram and N response |
| `check_source_split.py` | **17/17 PASS** | General q special orbit and Genesis source split, not full four-D jet |
| `check_chart_closure_scope.py` | **9/9 PASS** | Normalizer and additive-carrier checks; original source coefficients imported |
| `repro/check_iterate_family.py` | **PASS** | Fresh independent n1..6 cubic mixed derivative and n2 fourth-order witness |

**Important:** The general-quadratic, chirality, observable, source-split and normalizer tests have overlapping imported source claims. Adding their check counts would not produce a count of independent scientific theorems. The fresh `repro/check_iterate_family.py` regenerates a limited clock ladder and fourth-degree n=2 witness, not the full six-step exact analytic return.
