# ER-2B handoff — DYAD

**Source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md` · **Relevant local claims:** ER2B-C02–C05, C10, C14–C15 · **Status:** noncanonical for scoped owner review, not an adopted import.

## Fixed scientific context

Conditional Genesis map \(\mathcal N=P_\mathcal C T^{\times3}\) on \(\sum r_e=0\), projection within **every** primitive step, six-step return \(F_6=\mathcal N^6\), lifted additive edge coordinates \((\rho,\eta)\). Clock/carrier/observable choices are conditional. No new physical K3, chirality, time or resonant kernel is selected.

## Specific review request

Compare isolated μ and triadic ν only in the same primitive W chart and six-step clock. ν=μ₃+μ₂₂/3 is specific to the projected K3 model with additive closure in original (ρ,η) coordinates. Do not transport primitive source split as an invariant physical process; owner DYAD contraction remains a theorem about the isolated map.

## Required disposition

Please inspect the full consolidation and its source hashes; record `ACCEPT SCOPED`, `REQUEST RECHECK`, or `REJECT` for the named local claims and explicitly state any matching or missing model/clock/carrier/observable bridge. This message has **not** amended your adopted DSN or created an owner RID.
