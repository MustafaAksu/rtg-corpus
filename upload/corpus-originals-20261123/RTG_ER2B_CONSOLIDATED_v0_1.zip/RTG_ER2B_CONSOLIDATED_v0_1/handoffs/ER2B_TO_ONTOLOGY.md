# ER-2B handoff — ONTOLOGY

**Source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md` · **Relevant local claims:** ER2B-C15–C18 · **Status:** noncanonical for scoped owner review, not an adopted import.

## Fixed scientific context

Conditional Genesis map \(\mathcal N=P_\mathcal C T^{\times3}\) on \(\sum r_e=0\), projection within **every** primitive step, six-step return \(F_6=\mathcal N^6\), lifted additive edge coordinates \((\rho,\eta)\). Clock/carrier/observable choices are conditional. No new physical K3, chirality, time or resonant kernel is selected.

## Specific review request

Distinguish mathematical primitive update from ontological time, and node-difference closure from dyad-first additive postulate. Four choices: incidence, clock, observables, additive carrier. Opposite projected-K3 local radial signs can arise under different carrier laws with identical isolated edge T; neither physical law selected.

## Required disposition

Please inspect the full consolidation and its source hashes; record `ACCEPT SCOPED`, `REQUEST RECHECK`, or `REJECT` for the named local claims and explicitly state any matching or missing model/clock/carrier/observable bridge. This message has **not** amended your adopted DSN or created an owner RID.
