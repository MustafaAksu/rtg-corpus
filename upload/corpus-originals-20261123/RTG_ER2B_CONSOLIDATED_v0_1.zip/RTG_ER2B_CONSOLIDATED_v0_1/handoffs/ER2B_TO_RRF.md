# ER-2B handoff — RRF

**Source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md` · **Relevant local claims:** ER2B-C04, C07, C09, C15–C16 · **Status:** noncanonical for scoped owner review, not an adopted import.

## Fixed scientific context

Conditional Genesis map \(\mathcal N=P_\mathcal C T^{\times3}\) on \(\sum r_e=0\), projection within **every** primitive step, six-step return \(F_6=\mathcal N^6\), lifted additive edge coordinates \((\rho,\eta)\). Clock/carrier/observable choices are conditional. No new physical K3, chirality, time or resonant kernel is selected.

## Specific review request

Register the additive carrier as an independent representation field, distinguish passive H-transport of closure ΣH(z_e)=0 from newly imposed Σz_e=0. G₃ is linear-frame-covariant under all origin-fixing smooth rechartings; separability split requires slot-structure transport.

## Required disposition

Please inspect the full consolidation and its source hashes; record `ACCEPT SCOPED`, `REQUEST RECHECK`, or `REJECT` for the named local claims and explicitly state any matching or missing model/clock/carrier/observable bridge. This message has **not** amended your adopted DSN or created an owner RID.
