# ER-2B handoff — TRIADIC

**Source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md` · **Relevant local claims:** ER2B-C06–C13 · **Status:** noncanonical for scoped owner review, not an adopted import.

## Fixed scientific context

Conditional Genesis map \(\mathcal N=P_\mathcal C T^{\times3}\) on \(\sum r_e=0\), projection within **every** primitive step, six-step return \(F_6=\mathcal N^6\), lifted additive edge coordinates \((\rho,\eta)\). Clock/carrier/observable choices are conditional. No new physical K3, chirality, time or resonant kernel is selected.

## Specific review request

Signed area S=Ω_G for the Genesis/RER eigenframe; same planar components give Ω_T=−2Ω_G, B_T=2B_G in Triadic v1.6. χ Ω_G w₃ is a conditional Genesis cubic term, not a physical child-lift law. Do not restore withdrawn wedge or safety-basin conclusions.

## Required disposition

Please inspect the full consolidation and its source hashes; record `ACCEPT SCOPED`, `REQUEST RECHECK`, or `REJECT` for the named local claims and explicitly state any matching or missing model/clock/carrier/observable bridge. This message has **not** amended your adopted DSN or created an owner RID.
