# ER-2B handoff — PRE_LEGACY

**Source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md` · **Relevant local claims:** ER2B-C01–C03, C17–C18 · **Status:** noncanonical for scoped owner review, not an adopted import.

## Fixed scientific context

Conditional Genesis map \(\mathcal N=P_\mathcal C T^{\times3}\) on \(\sum r_e=0\), projection within **every** primitive step, six-step return \(F_6=\mathcal N^6\), lifted additive edge coordinates \((\rho,\eta)\). Clock/carrier/observable choices are conditional. No new physical K3, chirality, time or resonant kernel is selected.

## Specific review request

Legacy R_ij has effective phase/frequency/spin inputs, not primitive node properties. Uniform odd node-node flow yields r-dot=−3P_C g(r), but no Genesis primitive finite-time identification follows. Avoid confusing node-node with edge-edge resonance; request selected clock and admissible observables before comparing kernels.

## Required disposition

Please inspect the full consolidation and its source hashes; record `ACCEPT SCOPED`, `REQUEST RECHECK`, or `REJECT` for the named local claims and explicitly state any matching or missing model/clock/carrier/observable bridge. This message has **not** amended your adopted DSN or created an owner RID.
