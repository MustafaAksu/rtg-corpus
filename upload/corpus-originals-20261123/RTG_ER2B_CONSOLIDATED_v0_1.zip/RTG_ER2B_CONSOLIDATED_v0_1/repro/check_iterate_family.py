#!/usr/bin/env python3
"""Independent rational 4-var polynomial check of selected Omega_n components.
Exact Taylor jets for analytic Genesis primitive T and P_C after each step.
No adopted owner document is modified. n=2 calculated through degree 4,
n=3..6 through degree 3. Raises AssertionError on mismatch.
"""
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path
D=4
Z=(0,)*D
V=[{tuple(int(j==i) for j in range(D)):Q(1)} for i in range(D)]

def add(*polys):
 o={}
 for p in polys:
  for k,v in p.items():o[k]=o.get(k,Q(0))+v
 return {k:v for k,v in o.items() if v}
def sc(p,q): return {k:v*q for k,v in p.items() if v*q}
def mul(p,q,lim):
 o={}
 for k,u in p.items():
  for j,v in q.items():
   e=tuple(k[i]+j[i] for i in range(D))
   if sum(e)<=lim:o[e]=o.get(e,Q(0))+u*v
 return {k:v for k,v in o.items() if v}
def power(p,n,lim):
 o={Z:Q(1)}
 for _ in range(n):o=mul(o,p,lim)
 return o
def tmap(r,e,lim):
 r2=power(r,2,lim);r3=power(r,3,lim);e3=power(e,3,lim)
 rho=add(r,sc(e,-1),sc(e3,Q(1,6)))
 eta=add(r,sc(r2,Q(1,2)),sc(r3,Q(1,6)),sc(e3,Q(1,6)))
 if lim>=4:eta=add(eta,sc(power(r,4,lim),Q(1,24)))
 return rho,eta
def step(v,lim):
 a=v[:2];b=v[2:];c=tuple(sc(add(a[i],b[i]),-1) for i in range(2))
 raw=[tmap(*edge,lim) for edge in (a,b,c)]
 means=[sc(add(*(edge[i] for edge in raw)),Q(1,3)) for i in range(2)]
 return tuple(add(raw[j][i],sc(means[i],-1)) for j in range(2) for i in range(2))
def deg(p,n):return {k:v for k,v in p.items() if sum(k)==n}
def mixed(p,i,j,n):
 out={}
 for k,c in p.items():
  if sum(k)!=n or not (k[i] and k[2+j]):continue
  e=list(k);e[i]-=1;e[2+j]-=1;e=tuple(e)
  out[e]=out.get(e,Q(0))+c*k[i]*k[2+j]
 return {k:v for k,v in out.items() if v}
def fmt(p):
 if not p:return '0'
 names=('a1','a2','b1','b2')
 return ' + '.join(f'{c}'+''.join(f'*{nm}^{v}' for nm,v in zip(names,k) if v) for k,c in sorted(p.items()))
def Lterms(items):
 """convert expected linear polynomial {variable index:rational coefficient}."""
 return {tuple(int(i==j) for i in range(D)):Q(v) for j,v in items.items() if v}
# n=2: desired quadratic Omega_11 = -1/2(a1^2-b1^2) in BOTH outputs.
x=tuple(V)
for i in range(2):x=step(x,4)
diff=[add(x[k],sc(x[k+2],-1)) for k in (0,1)]
ref={(2,0,0,0):Q(-1,2),(0,0,2,0):Q(1,2)}
assert all(mixed(p,0,0,4)==ref for p in diff),[fmt(mixed(p,0,0,4)) for p in diff]
assert all(not mixed(p,i,j,3) for p in diff for i,j in product(range(2),repeat=2))
rows={'n2_omega_a1b1_fourth_order': [fmt(mixed(p,0,0,4)) for p in diff]}
# cubic leading values for n>=3 (user-derived, rechecked here independently).
expected={
 3:({},{1:Q(-1,3),3:Q(1,3)}),
 4:({1:Q(1,3),3:Q(-1,3)},{1:Q(-1,3),3:Q(1,3)}),
 5:({1:Q(2,3),3:Q(-2,3)},{1:Q(1,3),3:Q(-1,3)}),
 6:({1:Q(1,3),3:Q(-1,3)},{1:Q(2,3),3:Q(-2,3)})
}
x=tuple(V)
for n in range(1,7):
 x=step(x,3)
 diff=[add(x[k],sc(x[k+2],-1)) for k in (0,1)]
 vals=[mixed(p,0,0,3) for p in diff]
 if n==1:assert all(not mixed(p,i,j,3) for p in diff for i,j in product(range(2),repeat=2))
 elif n==2:assert all(not mixed(p,i,j,3) for p in diff for i,j in product(range(2),repeat=2))
 else:
  assert vals==[Lterms(e) for e in expected[n]], (n, vals)
 rows[f'n{n}_omega_a1b1_cubic']=[fmt(p) for p in vals]
assert all(not deg(p,2) for p in x),'six step quadratic jet nonzero'
result={'scope':'n=2 a1 b1 fourth-order witness; n=1..6 a1 b1 cubic jets; all four n=2 cubic mixed-derivative blocks zero',
 'source':'Genesis T analytic Taylor expansion and P_C step repeated in independent sparse Fraction polynomials',
 'pass':True,'results':rows}
out=Path(__file__).resolve().parents[1]/'evidence'/'iterate_family_checks.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('PASS: n=1..6 leading specified Omega_n, n=2 quartic, n=6 quadratic jet 0')
