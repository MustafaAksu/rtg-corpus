#!/usr/bin/env python3
"""Verify package file content SHA-256 against package MANIFEST.json.
No file writes. Intended for extracted delivery directory.
"""
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'MANIFEST.json').read_text())
count=0
for rel,expected in M['package_files_sha256'].items():
 p=ROOT/rel
 assert p.is_file(),f'MISSING: {rel}'
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 assert actual==expected,(rel,actual,expected)
 count+=1
print('PACKAGE_MANIFEST_PASS',count,'files; manifest not self-hashed')
