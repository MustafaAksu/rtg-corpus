# RTG ER-2B Consolidated v0.1 — transfer package

**Status:** noncanonical inter-stream research package, 10 October 2026. No adoption or owner-file modification. Language: English, aligned to scientific DSNs; user-facing summary may be in Turkish.

## Read in this order

1. [`RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md`](RTG_ER2B_CONSOLIDATED_STUDY_v0_1.md): **full 18-entry result and boundary ledger**, definitions, proofs/scope, eight-component table, observable responses and model-selection interface.
2. [`HANDOFF_TO_STREAMS.md`](HANDOFF_TO_STREAMS.md): **copyable, destination-specific excerpts** for DYAD / Genesis / Triadic / RRF / OFN / Pre-Legacy / RER–RECOG.
3. `handoffs/`: one-file-per-stream variants with the same scientific contract and an explicit review request.
4. [`CLAIM_REGISTER.json`](CLAIM_REGISTER.json): machine-readable local IDs and routed owner reviews; *not* an official RID register.
5. [`MANIFEST.json`](MANIFEST.json): source-to-snapshot mapping, SHA-256 digests and tests rerun **in this consolidation**.
6. `evidence/genesis_sixjet_obstruction_audit.json`: all four full \(G_3\) coordinate polynomials and derivative data; `evidence/source_notes/`: 5 original noncanonical work notes; `evidence/original_review_archives/`: preserved prior proof/evidence zip files.
7. [`repro/check_iterate_family.py`](repro/check_iterate_family.py): standalone exact rational check of selected \(n=1\ldots6\) step ladder; `evidence/iterate_family_checks.json` is its saved output.

**Minimal forward:** Send the whole ZIP package and the appropriate stream excerpt, with the `MANIFEST.json` digest. Never forward just one coefficient without the declared four choices (incidence, clock, observable, additive carrier).

## Brief status key

`[ALG]`: exact algebra for the named model; `[THM, model]`: conditional theorem with stated premises; `[OPEN]`: unresolved model/physical selection; `[HEUR]`: proposed programme action, not derived law. Script checks validate **declared subproblems**, not new owner certification. No files in this transfer package replace adopted DYAD v6.4.10, Genesis Geometry v2.8.5, Triadic v1.6, Pre-Legacy v0.8, Ontology v0.8 or RRF v0.7.

**Primary unresolved issue:** in what relational carrier are the three edge components additive? The six-step projected model can expand in the existing additive carrier, whereas a different model imposing linear closure in a normalized chart contracts. This is a *model-selection difference*, not instability under passive coordinate changes.
