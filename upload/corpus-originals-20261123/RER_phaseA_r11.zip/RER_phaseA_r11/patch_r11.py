"""Phase A r10 -> r11: fresh Phase A pass on the exact RER v0.2 DRAFT r4.8 bytes (receiver authorization, 20 Oct 2026, after R10-F1 closure).
- Source Markdown replaced by r4.8 (2dfebebf...0e3e); all outputs rebuilt from it. r10 outputs are kept unchanged as historical evidence under
  inputs/phaseA_r10_outputs/ (pinned); r9 outputs stay under inputs/phaseA_r9_outputs/.
- r4.8 package manifest added; rows carry path_in_r4_8_package; registry output renamed to r4_8.
- A24 is re-based on r4.8 (r9 + one RRF083 row; DYAD record parses to the r9 grade again).
- New A25: equality with the r10 outputs except the R10-F1 fields of RER-DYAD-FORMAL-INVOLUTION.
Exact-once text replacements. Args: TARGET_DIR R48_MD R48_PACKAGE_SHA256SUMS. Run once on a fresh copy of r10."""
import sys, os, json, shutil, hashlib
D, R48, R48SUMS = sys.argv[1], sys.argv[2], sys.argv[3]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:90]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
R48_SHA = '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'
R48_ZIP = '26efafc9efd3c3c5208c4e7238d99162bc99fd755357b436fa89f6d2db654a9f'
R47_SHA = '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d'
assert sha(R48) == R48_SHA
os.remove(os.path.join(D, 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_7.md'))
shutil.copyfile(R48, os.path.join(D, 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md'))
shutil.copyfile(R48SUMS, os.path.join(D, 'inputs/r4_8_package_SHA256SUMS.txt'))
H = os.path.join(D, 'inputs/phaseA_r10_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r10.txt'))

for f, k in (('catalog_sources.json', '_about'), ('catalog_records.json', '_about')):
    p = os.path.join(D, f); C = json.load(open(p))
    C[k] += ' Phase A r11 (20 Oct): source moved to RER r4.8 (R10-F1 layout edit only); no catalog content change.'
    open(p, 'w').write(dump(C))
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p)); KV['_catalog_checked'] = '2026-10-20 (Phase A r11, preparer)'; open(p, 'w').write(dump(KV))

rp('build_phaseA.py', [
 ('"""RER Phase A r10 builder (deterministic). Inputs: exact r4.7 Markdown (r4.6 +',
  '"""RER Phase A r11 builder (deterministic). Inputs: exact r4.8 Markdown (r4.7 with the R10-F1 layout edit; r4.7 = r4.6 +'),
 ("MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_7.md'\nMD_SHA = '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d'\n",
  f"MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md'\nMD_SHA = '{R48_SHA}'\nR48_ZIP_SHA = '{R48_ZIP}'\nBASE_R47_SHA = '{R47_SHA}'\n"),
 ("assert sha(mdb) == MD_SHA, 'r4.7 hash mismatch'", "assert sha(mdb) == MD_SHA, 'r4.8 hash mismatch'"),
 ("pkg47 = man('inputs/r4_7_package_SHA256SUMS.txt')", "pkg47 = man('inputs/r4_7_package_SHA256SUMS.txt'); pkg48 = man('inputs/r4_8_package_SHA256SUMS.txt')"),
 ("'path_in_r4_7_package': path in pkg47,", "'path_in_r4_7_package': path in pkg47, 'path_in_r4_8_package': path in pkg48,"),
 ("'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R47_ZIP_SHA, 'base_r4_6_sha256': BASE_R46_SHA,",
  "'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R48_ZIP_SHA, 'base_r4_7_sha256': BASE_R47_SHA, 'base_r4_7_package_zip_sha256': R47_ZIP_SHA, 'base_r4_6_sha256': BASE_R46_SHA,"),
 ("'RER-REGISTRY-PHASEA/10'", "'RER-REGISTRY-PHASEA/11'"), ("'RER-SOURCE-CURRENCY/10'", "'RER-SOURCE-CURRENCY/11'"), ("'RER-BLOCKED-SOURCES/10'", "'RER-BLOCKED-SOURCES/11'"),
 ("'out/RER_REGISTRY_v0_2_r4_7_PHASEA.json': dump(reg)", "'out/RER_REGISTRY_v0_2_r4_8_PHASEA.json': dump(reg)"),
 ("'# RER r4.7 — source-currency matrix (Phase A r10, noncanonical)'", "'# RER r4.8 — source-currency matrix (Phase A r11, noncanonical)'"),
 ("'# RER r4.7 — blocked-source register (Phase A r10, noncanonical)'", "'# RER r4.8 — blocked-source register (Phase A r11, noncanonical)'"),
 ("| In r4 / r4.4 / r4.5 / r4.6 / r4.7 pkg |", "| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 pkg |"),
 ("{yn(x['path_in_r4_6_package'])} / {yn(x['path_in_r4_7_package'])}", "{yn(x['path_in_r4_6_package'])} / {yn(x['path_in_r4_7_package'])} / {yn(x['path_in_r4_8_package'])}"),
 ("All outputs are rebuilt from r4.7; the r9 outputs (on r4.6) are inputs for regression only.']}",
  "All outputs are rebuilt from r4.7; the r9 outputs (on r4.6) are inputs for regression only.',\n"
  "                          'Phase A r11 (20 Oct 2026): source is RER r4.8 (2dfebebf…0e3e; package 26efafc9…4a9f), accepted ACCEPT SCOPED as a DRAFT; R10-F1 CLOSED: the DYAD record parses to primary grade [THM] (owner grade) with grade tags THM, and the per-RID owner grades (DYAD-ALG-CENT-KERNEL algebraic) sit in a separate source note. The r10 outputs (on r4.7, grade tags ALG and THM) are kept unchanged as historical evidence.']}"),
])

rp('check_phaseA.py', [
 ('"""Phase A r10 gates on RER v0.2 DRAFT r4.7.', '"""Phase A r11 gates on RER v0.2 DRAFT r4.8.'),
 ("text fields (exactness, task, adoption and OPEN items unchanged;",
  "text fields (r11, on r4.8: primary_grade '[THM] (owner grade)' and grade_tags ['THM'] as in r9; exactness, task, adoption and OPEN items unchanged).\n"
  "A25 equality with the r10 outputs (r11): the 90 matrix rows equal the pinned r10 rows in every identity/evidence field and carry path_in_r4_8_package;\n"
  "the other 19 registry records equal r10; RER-DYAD-FORMAL-INVOLUTION differs from r10 only in primary_grade, primary_grade_line, grade_tags and\n"
  "unclassified_lines (the source-note line), with primary_grade '[THM] (owner grade)', grade_tags ['THM'] and exactly one unclassified source-note line\n"
  "carrying DYAD-ALG-CENT-KERNEL [ALG]; the r10 outputs are present unchanged under inputs/phaseA_r10_outputs/.\n"
  "r10 wording kept as history: (r10, on r4.7: exactness, task, adoption and OPEN items unchanged;"),
 ("reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_7_PHASEA.json'])", "reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_8_PHASEA.json'])"),
 ("pkg47 = B.rd('inputs/r4_7_package_SHA256SUMS.txt').decode()", "pkg47 = B.rd('inputs/r4_7_package_SHA256SUMS.txt').decode(); pkg48 = B.rd('inputs/r4_8_package_SHA256SUMS.txt').decode()"),
 ("        if x.get('path_in_r4_7_package') and ('  ' + x['cited_path'] + '\\n') not in pkg47: bb.append(x['key'] + ':pkg47')\n",
  "        if x.get('path_in_r4_7_package') and ('  ' + x['cited_path'] + '\\n') not in pkg47: bb.append(x['key'] + ':pkg47')\n"
  "        if x.get('path_in_r4_8_package') and ('  ' + x['cited_path'] + '\\n') not in pkg48: bb.append(x['key'] + ':pkg48')\n"),
 ("and all('path_in_r4_7_package' in x for x in cm['rows']))", "and all('path_in_r4_7_package' in x and 'path_in_r4_8_package' in x for x in cm['rows']))"),
 ("    src_ok = (sm['file'].endswith('_r4_7.md') and sm['sha256'] == B.MD_SHA == '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d' and sm['package_zip_sha256'] == '9ab6393e94001d5c513f68af64e32d63afb0548b31879afcfc3912911ecfc14f'\n",
  "    src_ok = (sm['file'].endswith('_r4_8.md') and sm['sha256'] == B.MD_SHA == '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e' and sm['package_zip_sha256'] == '26efafc9efd3c3c5208c4e7238d99162bc99fd755357b436fa89f6d2db654a9f'\n"
  "              and sm.get('base_r4_7_sha256') == '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d' and sm.get('base_r4_7_package_zip_sha256') == '9ab6393e94001d5c513f68af64e32d63afb0548b31879afcfc3912911ecfc14f'\n"),
 ("              and dy9.get('primary_grade') == '[THM] (owner grade)' and (dy10.get('primary_grade') or '').startswith('[THM] (owner grade). Owner grades per imported RID (r4.7):')\n"
  "              and dy9.get('grade_tags') == ['THM'] and dy10.get('grade_tags') == ['ALG', 'THM'])  # finding R10-F1: the parser reads the O3 per-RID labels into primary_grade\n",
  "              and dy9.get('primary_grade') == dy10.get('primary_grade') == '[THM] (owner grade)' and dy9.get('grade_tags') == dy10.get('grade_tags') == ['THM'])  # r11: R10-F1 closed by r4.8\n"),
 ("    g('A24 r4.7 source pass: sources pinned; matrix = r9 + one RRF083 row; registry differs only in RER-DYAD-FORMAL-INVOLUTION text', src_ok and rows_ok and rec_ok, f'{len(cm[\"rows\"])} rows, {len(new)} new, {len(gone)} gone')\n",
  "    g('A24 r4.8 source pass: sources pinned; matrix = r9 + one RRF083 row; registry differs from r9 only in RER-DYAD-FORMAL-INVOLUTION text (grade parse as r9)', src_ok and rows_ok and rec_ok, f'{len(cm[\"rows\"])} rows, {len(new)} new, {len(gone)} gone')\n"
  "    H10 = 'inputs/phaseA_r10_outputs/'\n"
  "    m10 = json.loads(B.rd(H10 + 'SOURCE_CURRENCY_MATRIX.json')); g10 = json.loads(B.rd(H10 + 'RER_REGISTRY_v0_2_r4_7_PHASEA.json'))\n"
  "    i10 = [ident(x) for x in m10['rows']]; i11 = [ident(x) for x in cm['rows']]\n"
  "    m_ok = i10 == i11 and len(i11) == 90 and all('path_in_r4_8_package' in x for x in cm['rows'])\n"
  "    A10 = {x['id']: x for x in g10['records']}; A11 = {x['id']: x for x in reg['records']}\n"
  "    a, c = A10.get('RER-DYAD-FORMAL-INVOLUTION', {}), A11.get('RER-DYAD-FORMAL-INVOLUTION', {})\n"
  "    diff = sorted(k for k in set(a) | set(c) if a.get(k) != c.get(k))\n"
  "    newu = [l for l in c.get('unclassified_lines', []) if l not in a.get('unclassified_lines', [])]\n"
  "    r_ok = (set(A10) == set(A11) and all(A10[k] == A11[k] for k in A10 if k != 'RER-DYAD-FORMAL-INVOLUTION')\n"
  "            and set(diff) <= {'primary_grade', 'primary_grade_line', 'grade_tags', 'unclassified_lines'} and {'primary_grade', 'grade_tags'} <= set(diff)\n"
  "            and c.get('primary_grade') == '[THM] (owner grade)' and c.get('grade_tags') == ['THM'] and a.get('grade_tags') == ['ALG', 'THM']\n"
  "            and len(newu) == 1 and newu[0].startswith('**Owner grades per imported RID** (source note;') and '`DYAD-ALG-CENT-KERNEL` [ALG]' in newu[0])\n"
  "    g('A25 r10 equality: 90 rows unchanged; only the R10-F1 fields of RER-DYAD-FORMAL-INVOLUTION differ (grade [THM], tags [THM], source note with CENT-KERNEL [ALG])', m_ok and r_ok, f'DYAD fields differing from r10: {diff}')\n"),
 ("    R, C, K = 'out/RER_REGISTRY_v0_2_r4_7_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'",
  "    R, C, K = 'out/RER_REGISTRY_v0_2_r4_8_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'"),
 ("         ('A24 parsed grade tags silently reset to [THM] (R10-F1 hidden)', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(grade_tags=['THM']))),\n",
  "         ('A24 grade tags back to the r4.7 parse [ALG, THM]', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(grade_tags=['ALG', 'THM']))),\n"
  "         ('A25 r10 registry re-used (r4.7 parse)', 24, mut(R, lambda d: d.update(records=json.loads(B.rd('inputs/phaseA_r10_outputs/RER_REGISTRY_v0_2_r4_7_PHASEA.json'))['records']))),\n"
  "         ('A25 source note dropped from the DYAD record', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(unclassified_lines=[l for l in next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['unclassified_lines'] if not l.startswith('**Owner grades per imported RID**')]))),\n"
  "         ('A25 CENT-KERNEL relabelled [THM] in the note', 24, mut(R, lambda d: (lambda r: r.update(unclassified_lines=[l.replace('`DYAD-ALG-CENT-KERNEL` [ALG]', '`DYAD-ALG-CENT-KERNEL` [THM]') for l in r['unclassified_lines']]))(next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')))),\n"
  "         ('A25 one matrix row altered vs r10', 24, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='UNCHANGED_OWNER_REPORTED'))),\n"
  "         ('A25 another record altered vs r10', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C02').update(title='x'))),\n"),
])
print('patched')
