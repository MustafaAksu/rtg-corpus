"""Gates for RER v0.2 DRAFT r4.7 (on the exact r4.6 bytes). Exit 0 iff all pass; --tamper runs negative controls.
Structural:
 M1 r4.6 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.6 byte-exactly.
 L1 locality: every changed line of r4.6 lies in the RER-DYAD-FORMAL-INVOLUTION record, the three header metadata lines,
    the §9 R4.6 history line (an entry is inserted before it) or the release-boundary line.
 L2 the other 19 record spans and all 24 record headings are byte-identical; the 16 r3.1 contract tables are byte-identical.
 L3 claim-tag counts change exactly by [ALG] +2 (DYAD-ALG-CENT-KERNEL grade label, §9 entry) and [THM] +2 (two per-RID grade labels).
 L4 in the record: primary grade, exactness and task unchanged; adoption still pending; all [OPEN] lines unchanged; the r4.6 carrier cell
    unchanged (its editorial history stays visible); the DYAD6413 pin unchanged (v6.4.13 import tags only).
Content (Phase B-05 items):
 X1 (O1) Transformation law carries "λ-equivariant normal form" and the formula R_0=T^3 o F^{-1/2}; no unqualified "for any formal
    Poincaré–Dulac normalizer h^." remains.
 X2 (O2) the analytic bridge line carries R(0)=0 and the §6.15 domain convention; the Domain line no longer makes the §6.15(b)
    hypotheses the bridge's hypotheses (they are recorded as sufficient for R(0)=0) and keeps the r4–r4.6 wording as history.
 X3 (O3) per-RID grades: CENT-KERNEL [ALG], FORMAL-INVOLUTION-UNIQUE [THM], FORMAL-CENTRALIZER [THM], ANALYTIC-CLOCK-BRIDGE [THM — analytic].
 X4 (O4) flat-uniqueness line carries "existing", R(0) = 0, the §6.15 domain convention, near 0, and the Lemma F ball/flat-contact scope.
 X5 (O5) the G2 §2a SOURCE-READ receipt is marked historical with no current byte access (G2NOTE04 UNAUTHENTICATED_NO_HASH).
 X6 (O6) an RRF083 import line with the full v0.8.3 hash, citing §2.3 and §2.4b, follows the RRF082 line, which is kept.
 K1 every byte-available cited evidence file is at its cited path with its cited hash (carried from r4.6)."""
import sys, re, hashlib, difflib, json
from pathlib import Path
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_7_draft as B
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
KEY = 'RER-DYAD-FORMAL-INVOLUTION'
RRF083 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]
    out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def gates(d, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.6 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.6 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    i0, i1, _ = Sb[KEY]
    allowed = set(range(i0, i1)) | {0, 3, 6} | {i for i, l in enumerate(Lb) if l.startswith('[ALG] R4.6 (19 Oct 2026)') or l.startswith('**Release boundary (r4.6):**')}
    bad = []
    for tag, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes():
        if tag == 'equal': continue
        idx = set(range(a1, a2)) if a2 > a1 else {a1}
        if not idx <= allowed: bad.append((tag, a1, a2))
    g('L1 locality: changes only in the DYAD record, header lines 1/4/7, §9 R4.6 anchor and release boundary', not bad, f'{len(bad)} out-of-scope hunks')
    others = [k for k in Sb if k != KEY]
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    g('L2 other 19 records, 24 headings and 16 r3.1 contract tables byte-identical', len(Sb) == 24 and set(Sb) == set(Sd) and len(others) == 23
      and all(Sb[k][2] == Sd[k][2] for k in others) and len(tables) == 16 and all(t in d for t in tables), f'{len(Sb)} spans')
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    g('L3 claim-tag deltas exactly [ALG] +2 and [THM] +2', all(d.count(t) == b.count(t) + {'[ALG]': 2, '[THM]': 2}.get(t, 0) for t in tags))
    rb_, rd_ = Sb[KEY][2], Sd[KEY][2] if KEY in Sd else ''
    gl = lambda r: next((l for l in r.split('\n') if l.startswith('**Primary grade:**')), '')
    PRE = '**Primary grade:** [THM] (owner grade).'
    opens = lambda r: [l for l in r.split('\n') if l.startswith('[OPEN]')]
    car = lambda r: next((l for l in r.split('\n') if l.startswith('| Carrier |')), None)
    g('L4 grade/exactness/task unchanged, adoption pending, OPEN lines, carrier cell and DYAD6413 pin unchanged',
      gl(rb_).startswith(PRE) and gl(rd_).startswith(PRE + ' Owner grades per imported RID') and gl(rd_).endswith(gl(rb_)[len(PRE):])
      and 'Registry/owner adoption:** pending' in gl(rd_) and opens(rd_) == opens(rb_) and car(rd_) == car(rb_) and car(rd_) is not None
      and re.findall(r'\[import: RTG_DYADIC_OSCILLATOR_DSN_v([0-9.]+)', rd_) == ['6.4.13', '6.4.13'] and '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' in rd_)
    law = next((l for l in rd_.split('\n') if l.startswith('| Transformation law |')), '')
    g('X1 (O1) λ-equivariant normal form condition; formula unchanged', 'λ-equivariant normal form' in law and 'R_0=T^3 o F^{-1/2}=h^(-I)h^{-1}' in law
      and 'for any formal Poincaré–Dulac normalizer h^.' not in law and 'without a normalizer' in law)
    br = next((l for l in rd_.split('\n') if l.startswith('[THM] **FORMAL_ONLY.**')), ''); dom = next((l for l in rd_.split('\n') if l.startswith('**Domain / admissibility:**')), '')
    g('X2 (O2) analytic bridge: R(0)=0 and §6.15 domain convention; (b) hypotheses only sufficient; history kept',
      'local involution R with R(0)=0 that commutes with T^6' in br and '§6.15 domain convention' in br and 'an analytic involution with R T^6 = T^6 R and DR(0)=-I commutes exactly with T.' not in br
      and 'R(0)=0' in dom and 'domain convention' in dom and 'are sufficient for R(0)=0 but are not the bridge\'s own hypotheses' in dom and 'History (r4–r4.6):' in dom)
    g('X3 (O3) per-RID owner grades with DYAD-ALG-CENT-KERNEL [ALG]', all(s in gl(rd_) for s in ('`DYAD-ALG-CENT-KERNEL` [ALG]', '`DYAD-THM-FORMAL-INVOLUTION-UNIQUE` [THM]', '`DYAD-THM-FORMAL-CENTRALIZER` [THM]', '`DYAD-THM-ANALYTIC-CLOCK-BRIDGE` `[THM — analytic]`')))
    fl = next((l for l in rd_.split('\n') if l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17')), '')
    g('X4 (O4) flat uniqueness: existing object, R(0) = 0, domain convention, near 0, Lemma F scope', all(s in fl for s in ('existing C^∞ local involution', 'R(0) = 0', '§6.15 domain convention', 'near 0', 'forward-invariant ball', 'flat-contact hypothesis'))
      and 'An existing C^∞ involution with DR(0) = −I commuting with F commutes with T and is unique.' not in fl)
    ev = next((l for l in rd_.split('\n') if l.startswith('**Evidence:**')), '')
    g('X5 (O5) G2 §2a receipt historical, no current byte access', all(s in ev for s in ('SOURCE-READ receipt is historical', 'not held by the RER preparer or receiver', 'UNAUTHENTICATED_NO_HASH', 'not a current byte-access claim')))
    L = rd_.split('\n'); i82 = next((i for i, l in enumerate(L) if l.startswith('Import/reference: [RRF082:')), -1)
    g('X6 (O6) RRF083 import line (full hash, §2.3 and §2.4b) follows the kept RRF082 line', i82 >= 0 and i82 + 1 < len(L) and L[i82 + 1].startswith('Import/reference: [RRF083: §2.3, §2.4b')
      and RRF083 in L[i82 + 1] and L[i82] == next(l for l in rb_.split('\n') if l.startswith('Import/reference: [RRF082:')))
    pins = json.loads((HERE / 'CITED_EVIDENCE_PINS.json').read_text(encoding='utf-8'))
    from urllib.parse import unquote
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 every byte-available cited evidence file at its cited path with its cited hash', not miss and len(pins) == 21, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    rec = d0.split('### ' + KEY + ' — ')[1].split('\n<a id=')[0]
    T = [('L1 edit outside the record (RER-TRIAD-FORMAL-INVOLUTION grade line)', 3, d0.replace('### RER-TRIAD-FORMAL-INVOLUTION — ', '### RER-TRIAD-FORMAL-INVOLUTION — (r4.7) ', 1)),
         ('L3 one extra [THM] tag in the record', 5, d0.replace('`DYAD-THM-ANALYTIC-CLOCK-BRIDGE` `[THM — analytic]`', '`DYAD-THM-ANALYTIC-CLOCK-BRIDGE` [THM]', 1)),
         ('L4 an OPEN line altered', 6, d0.replace('[OPEN] OPEN 20 B-an: convergence of R_0, equivalently of F^{1/2}.', '[OPEN] OPEN 20 B-an: convergence of R_0.', 1)),
         ('L4 carrier cell rewritten', 6, d0.replace('r4.6 carrier per RRF editor Q5; r4–r4.5 label was profile RRF-DYAD-W (RRF v0.8.2 §2.3, §2.4b).', 'Carrier per RRF editor Q5.', 1)),
         ('L4 primary grade changed', 6, d0.replace('**Primary grade:** [THM] (owner grade). Owner grades', '**Primary grade:** [ALG] (owner grade). Owner grades', 1)),
         ('L4 DYAD pin moved to v6.4.17', 6, d0.replace('`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.16', '`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.17 §6.16', 1)),
         ('X1 λ-equivariant condition dropped', 7, d0.replace(' with λ-equivariant normal form (owner condition', ' (owner condition', 1)),
         ('X2 R(0)=0 dropped from the bridge line', 8, d0.replace('a real-analytic local involution R with R(0)=0 that commutes', 'a real-analytic local involution R that commutes', 1)),
         ('X3 CENT-KERNEL labelled [THM]', 9, d0.replace('`DYAD-ALG-CENT-KERNEL` [ALG]', '`DYAD-ALG-CENT-KERNEL` [THM]', 1)),
         ('X4 flat-uniqueness hypotheses dropped', 10, d0.replace('An existing C^∞ local involution R with R(0) = 0, RF = FR in the sense of the owner\'s §6.15 domain convention, and DR(0) = −I commutes with T near 0', 'An existing C^∞ involution with DR(0) = −I commuting with F commutes with T', 1)),
         ('X5 G2 receipt presented as current', 11, d0.replace('that SOURCE-READ receipt is historical (r4 build)', 'that SOURCE-READ receipt is current', 1)),
         ('X6 RRF083 hash removed', 12, d0.replace('SHA-256 `' + RRF083 + '` (OWNER-REPORTED via its adoption record, as in the source table)', 'hash not recorded', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rb6 = gates(b, verbose=False); good = not any(rb6[7:13]); allf &= good
    print(f'  r4.6 bytes: X1..X6 = {rb6[7:13]} (expected all False)')
    pins = json.loads((HERE / 'CITED_EVIDENCE_PINS.json').read_text(encoding='utf-8')); p0 = HERE / sorted(pins)[0]
    keep = p0.read_bytes(); p0.write_bytes(keep + b'x')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[13]; allf &= good
        print(f'  tamper K1 (one evidence file altered): {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        p0.write_bytes(keep)
    ok = ok and allf
sys.exit(0 if ok else 1)
