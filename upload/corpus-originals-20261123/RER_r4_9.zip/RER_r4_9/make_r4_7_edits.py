"""Edit list RER v0.2 DRAFT r4.6 -> r4.7: narrow record-text revision of RER-DYAD-FORMAL-INVOLUTION only, implementing the six
follow-up items of the Phase B-05 receiving review (20 Oct 2026; receiver authorization of the same day):
  O1 owner condition on the normalizer identification (lambda-equivariant normal form);
  O2 analytic clock bridge hypotheses (R(0)=0, §6.15 domain convention; the §6.15(b) hypotheses only make R(0)=0 automatic);
  O3 per-RID owner grades (DYAD-ALG-CENT-KERNEL is [ALG]);
  O4 flat-uniqueness hypotheses (existing C^inf object, R(0)=0, domain convention; Lemma F scope);
  O5 G2 note §2a source access: the historical SOURCE-READ receipt is not a current byte-access claim;
  O6 RRF v0.8.3 carrier pin: an import line for the RRF v0.8.3 sections the r4.6 carrier cell cites.
Plus metadata (title, date, status line), one [ALG] §9 history entry and one release-boundary sentence.
No grade, OPEN status, contract-cell other than the Transformation-law cell, carrier cell, pin or other record changes.
Owner text checked against Dyadic v6.4.17 §§6.15-6.17 (bytes e07cf2b9...4bfc; byte-identical to v6.4.16 in these sections, Phase A r9)."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md').read_text(encoding='utf-8')
BASE_SHA = '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
RRF083 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix):
    ls = [l for l in B.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]
rec = B.split('### RER-DYAD-FORMAL-INVOLUTION — ')[1].split('\n<a id=')[0]
def rline(prefix):
    ls = [l for l in rec.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); assert B.count(ls[0]) == 1; return ls[0]

# metadata
ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.6\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.7\n')
ed('M2', 'metadata', '**Date:** 19 October 2026 (r4.6, r4.5,', '**Date:** 20 October 2026 (r4.7); 19 October 2026 (r4.6, r4.5,')
ed('M3', 'metadata', '**Document status:** DRAFT r4.6 — implements the written RRF editor disposition',
   f'**Document status:** DRAFT r4.7 — narrow record-text revision of RER-DYAD-FORMAL-INVOLUTION only (six Phase B-05 follow-up items: owner hypotheses carried to the point of use, per-RID owner grades, G2 source-access boundary, RRF v0.8.3 carrier pin), built deterministically on the exact r4.6 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_7_draft.py`; no grade, OPEN status, pin or other record changes; prepared by the RER editor, who wrote this record, for independent receiving review. r4.6 was: implements the written RRF editor disposition')

# O3 per-RID owner grades (primary grade unchanged)
g = rline('**Primary grade:** [THM] (owner grade).')
ed('O3', 'B05-O3', g, g.replace('**Primary grade:** [THM] (owner grade).',
   '**Primary grade:** [THM] (owner grade). Owner grades per imported RID (r4.7): `DYAD-THM-FORMAL-INVOLUTION-UNIQUE` [THM], `DYAD-THM-FORMAL-CENTRALIZER` [THM], `DYAD-ALG-CENT-KERNEL` [ALG], `DYAD-THM-ANALYTIC-CLOCK-BRIDGE` `[THM — analytic]`, all formal-category except the analytic bridge.', 1))

# O1 lambda-equivariant normal form
law = rline('| Transformation law | R_0=T^3 o F^{-1/2}=h^(-I)h^{-1} for any formal Poincaré–Dulac normalizer h^.')
ed('O1', 'B05-O1', law, law.replace('for any formal Poincaré–Dulac normalizer h^.',
   'for any formal Poincaré–Dulac normalizer h^ with λ-equivariant normal form (owner condition, DYAD v6.4.13 §6.16 Identification; r4.7). R_0 itself is defined without a normalizer.', 1))

# O2 analytic clock bridge
br = rline('[THM] **FORMAL_ONLY.** `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.16')
old2 = 'an analytic involution with R T^6 = T^6 R and DR(0)=-I commutes exactly with T.'
assert br.count(old2) == 1
ed('O2a', 'B05-O2', br, br.replace(old2, 'a real-analytic local involution R with R(0)=0 that commutes with T^6 in the sense of the owner\'s §6.15 domain convention (0 ∈ int D_Φ) and has DR(0)=-I commutes exactly with T on a neighbourhood of 0 (owner hypotheses, r4.7; under the §6.15(b) hypotheses R(0)=0 is automatic).', 1))
dom = rline('**Domain / admissibility:** Formal; the analytic bridge is local under the owner\'s §6.15(b) hypotheses.')
ed('O2b', 'B05-O2', dom, '**Domain / admissibility:** Formal; the analytic bridge is local: its hypotheses are R real-analytic, R(0)=0, the owner\'s §6.15 domain convention and DR(0)=-I (r4.7). The §6.15(b) hypotheses (C^3, R commuting with T^6 on V ⊂ U_T ∪ {0}) are sufficient for R(0)=0 but are not the bridge\'s own hypotheses. History (r4–r4.6): ' + dom[len('**Domain / admissibility:** '):])

# O4 flat uniqueness hypotheses
fl = rline('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17')
old4 = 'An existing C^∞ involution with DR(0) = −I commuting with F commutes with T and is unique.'
assert fl.count(old4) == 1
ed('O4', 'B05-O4', fl, fl.replace(old4, 'An existing C^∞ local involution R with R(0) = 0, RF = FR in the sense of the owner\'s §6.15 domain convention, and DR(0) = −I commutes with T near 0 and is unique (F1, F2; r4.7 carries these owner hypotheses). Lemma F itself is stated on a forward-invariant ball B_r ⊂ {Q ≤ 1/400} under a flat-contact hypothesis.', 1))

# O5 G2 source access
ev = rline('**Evidence:** owner theorem SOURCE-READ (project copy);')
old5 = 'independent polar-coordinate proof of the kernel lemma in the G2 consolidated note v0.4 §2a, SOURCE-READ.'
assert ev.count(old5) == 1
ed('O5', 'B05-O5', ev, ev.replace(old5, old5 + ' r4.7 source-access boundary: that SOURCE-READ receipt is historical (r4 build). The note\'s bytes are not held by the RER preparer or receiver (G2NOTE04: no hash printed, UNAUTHENTICATED_NO_HASH; G2 §5b carrier identification pending), so it is not a current byte-access claim. The Dyadic owner records this proof as a citation candidate, not an import (DYAD v6.4.12 adoption interface note); the record does not rest on it.', 1))

# O6 RRF v0.8.3 carrier pin
r82 = rline('Import/reference: [RRF082: §2.4b, §4.2]')
ed('O6', 'B05-O6', r82, r82 + f'\nImport/reference: [RRF083: §2.3, §2.4b (`RRF-DYAD-NF` row, formal involution)] (project copy `RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md`; not in this package); SHA-256 `{RRF083}` (OWNER-REPORTED via its adoption record, as in the source table). r4.7: the pin for the RRF v0.8.3 sections cited by the r4.6 carrier cell; the RRF082 line above is kept as the r4–r4.5 history pin.')

# §9 history and release boundary
h46 = line('[ALG] R4.6 (19 Oct 2026) implements the written RRF editor disposition')
ed('H1', 'history', h46, '[ALG] R4.7 (20 Oct 2026) is a narrow record-text revision on the exact r4.6 bytes, limited to RER-DYAD-FORMAL-INVOLUTION. It implements the six follow-up items of the Phase B-05 receiving review (20 Oct 2026): (O1) the owner condition "λ-equivariant normal form" on the normalizer identification; (O2) the analytic clock bridge hypotheses R(0)=0 and the §6.15 domain convention, with the §6.15(b) hypotheses recorded as sufficient for R(0)=0, not as the bridge\'s hypotheses; (O3) per-RID owner grades, with DYAD-ALG-CENT-KERNEL shown at its own (algebraic) owner grade; (O4) the flat-uniqueness hypotheses for existing C^∞ objects and the Lemma F scope; (O5) the G2 note §2a SOURCE-READ receipt marked historical, with no current byte access; (O6) an RRF v0.8.3 import line for the sections the r4.6 carrier cell cites. The owner text was checked against Dyadic v6.4.17 §§6.15–6.17, which are byte-identical to v6.4.16 in these sections (Phase A r9); the pins stay on v6.4.13. The r4.6 carrier cell, all grades, OPEN statuses and the other nineteen records are unchanged. The record was written by the RER editor (the preparer); its acceptance belongs to the receiver.\n' + h46)
rb = '**Release boundary (r4.6):** r4.6 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.7):** r4.7 is a noncanonical review draft; it adopts, freezes and accepts nothing. ' + rb)

# apply in sequence to make sure each old string is still unique after earlier edits
t = B
for e in E:
    assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_6_to_r4_7_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
