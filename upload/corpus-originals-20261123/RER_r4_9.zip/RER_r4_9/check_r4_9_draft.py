"""Gates for RER v0.2 DRAFT r4.9 (on the exact r4.8 bytes). Exit 0 iff all pass; --tamper runs negative controls.
 M1 r4.8 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.8 byte-exactly.
 L1 locality: changed r4.8 lines only at header 1/4/7; in RER-DYAD-FORMAL-INVOLUTION the source note, Order / error, Evidence, the RRF083 import
    line (one line inserted after it), the B-∞ existence OPEN line, the Lemma F / F1–F3 line and Non-transfer; the DYAD6414 source-table row
    (one row inserted after it); the §9 R4.8 anchor (one entry inserted before it); the release-boundary line.
 L2 the other 23 record spans, the 24 headings and the 16 r3.1 contract tables byte-identical; in RER-DYAD-FORMAL-INVOLUTION every r4.8 line
    outside the L1 set is byte-identical (primary-grade line, contract table, analytic-bridge [THM], B-an, B-6 and physical-exchange OPEN lines,
    DYAD6413 / RRF082 / RRF083 import lines, Domain, Map, Contract type, Review receipt, Next test).
 L3 claim tags: raw counts change by exactly [THM] +4, [ALG] +1; line-leading tags in the record change by exactly [THM] +1, [OPEN] -1.
 P1 record framing kept (receiver D-A option 1): with the unchanged Phase A parser the record parses to primary_grade '[THM] (owner grade)',
    grade_tags ['THM'], exactness FORMAL_ONLY, task, adoption, contract cells and contract type identical to r4.8; every other record parses identically.
 S1 B-∞ existence: the r4.8 OPEN line is gone as a line (quoted only inside the superseding [THM] line); the new [THM] line imports
    DYAD-THM-SMOOTH-EMBEDDING from v6.4.18 at C^∞ germ scope and carries E1-E4, the E2 restriction DX'(0) = 0, the qualitative radius, the
    route distinction, "B-an and B-6 stay OPEN" and the owner-grade / no-independent-proof-review boundary.
 S2 Lemma F / F1–F3 line: identical to r4.8 except the one existence sentence; it keeps Lemma F [THM], F1–F3 [THM — conditional], the owner
    hypotheses and the triad non-transfer, and states that F1–F3 assert no existence themselves while E1–E4 supply the objects.
 S3 OPEN items = r4.8 OPEN items minus exactly the B-∞ existence item (B-an, B-6, physical exchange byte-identical).
 S4 pins (receiver D-B): imports = r4.8 imports + one DYAD6418 row (v6.4.18 hash, cited path, §2 OPEN 20, §6.17); the DYAD6413 import line and
    source-table row byte-identical; a DYAD6418 source-table row with the same hash.
 S5 non-transfer and scope fields: Non-transfer ends with the exact r4.9 sentence (DYAD-THM-PRIM-CTR; nothing follows for Triadic G6, B-an/B-6, pole exchange, G2 carrier map); the
    source note states that the record-level labels do not make every imported result formal; Order / error keeps analytic convergence OPEN;
    Evidence records owner-grade import without proof review (D-C). DYAD-THM-SMOOTH-EMBEDDING occurs nowhere outside the DYAD record, the
    DYAD6418 source-table row and the §9 / header metadata.
 K1 every byte-available cited evidence file at its cited path with its cited hash (21 carried + Dyadic v6.4.18 = 22)."""
import sys, re, hashlib, difflib, json, importlib.util
from pathlib import Path
from urllib.parse import unquote
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_9_draft as B
PARSER = HERE / 'tools/rer_parse_phaseA_r10.py'; PARSER_SHA = '7b6b98aa1417c6bab99b6447f9f5756a04d3fc74f5b9f7d767cb75b55138a7b7'
spec = importlib.util.spec_from_file_location('rer_parse_r10', PARSER); P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
PINS_FILE = HERE / 'CITED_EVIDENCE_PINS_r4_9.json'
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
KEY = 'RER-DYAD-FORMAL-INVOLUTION'; RID = 'DYAD-THM-SMOOTH-EMBEDDING'
D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'; D18_PATH = 'sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md'
BINF = '[OPEN] OPEN 20 B-∞ existence: a C^∞ local involution with DR(0) = −I commuting with T (equivalently a C^∞ tangent-to-identity square root of F).'
OLD_S = 'No existence is asserted; the RID word CAND is an identifier, not a status.'
PREF = {'note': '**Owner grades per imported RID** (source note;', 'order': '**Order / error:**', 'ev': '**Evidence:**', 'rrf': 'Import/reference: [RRF083:',
        'binf': '[OPEN] OPEN 20 B-∞ existence:', 'flat': '[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 |', 'nt': '**Non-transfer:**'}
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]; out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def parsed(t): return {rid: P.parse_record(rid, title, body) for rid, title, body in P.blocks(t)}
def gates(d, verbose=True, pins_file=PINS_FILE):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.8 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.8 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    i0, i1 = Sb[KEY][0], Sb[KEY][1]
    rec_idx = {k: next(i for i in range(i0, i1) if Lb[i].startswith(p)) for k, p in PREF.items()}
    allowed = {0, 3, 6} | set(rec_idx.values()) | {i for i, l in enumerate(Lb) if l.startswith('| `DYAD6414` |') or l.startswith('[ALG] R4.8 (20 Oct 2026)') or l.startswith('**Release boundary (r4.8):**')}
    def in_scope(a1, a2): return set(range(a1, a2)) <= allowed if a2 > a1 else bool({a1 - 1, a1} & allowed)  # an insertion must sit next to an allowed line
    bad = [(t, a1, a2) for t, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes() if t != 'equal' and not in_scope(a1, a2)]
    g('L1 locality: header 1/4/7; seven DYAD record lines; DYAD6414 row; §9 R4.8 anchor; release boundary', not bad, f'{len(bad)} out-of-scope hunks')
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    others = [k for k in Sb if k != KEY]
    keep_b = [Lb[i] for i in range(i0, i1) if i not in rec_idx.values()]
    dl = Sd.get(KEY, (0, 0, ''))[2].split('\n')
    changed_d = [l for l in dl if any(l.startswith(p) for p in (PREF['note'], PREF['order'], PREF['ev'], PREF['flat'], PREF['nt'], 'Import/reference: [DYAD6418:', 'Import/reference: [RRF083:'))
                 or l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18')]
    keep_d = [l for l in dl if l not in changed_d]
    g('L2 other spans, headings, r3.1 tables and the unchanged DYAD lines byte-identical', set(Sb) == set(Sd) and len(Sb) == 24 and all(Sb[k][2] == Sd[k][2] for k in others)
      and len(tables) == 16 and all(t in d for t in tables) and keep_b == keep_d and len(changed_d) == 8)
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    lead = lambda ls, t: sum(1 for l in ls if l.startswith(t))
    lb_rec = Lb[i0:i1]
    g('L3 claim tags: raw [THM] +4, [ALG] +1; record line-leading [THM] +1, [OPEN] -1', all(d.count(t) == b.count(t) + {'[THM]': 4, '[ALG]': 1}.get(t, 0) for t in tags)
      and lead(dl, '[THM]') == lead(lb_rec, '[THM]') + 1 and lead(dl, '[OPEN]') == lead(lb_rec, '[OPEN]') - 1 and all(lead(dl, t) == lead(lb_rec, t) for t in ('[ALG]', '[DEF]', '[NUM]')))
    pb, pd = parsed(b), parsed(d); x8, x9 = pb[KEY], pd.get(KEY, {})
    g('P1 record framing kept (D-A option 1): grade [THM] (owner grade), tags [THM], FORMAL_ONLY, contract and type unchanged; other records parse identically',
      hashlib.sha256(PARSER.read_bytes()).hexdigest() == PARSER_SHA and x9.get('primary_grade') == '[THM] (owner grade)' and x9.get('grade_tags') == ['THM'] and x9.get('exactness_codes') == ['FORMAL_ONLY']
      and all(x9.get(f) == x8[f] for f in ('primary_grade', 'exactness_text', 'exactness_codes', 'task', 'registry_owner_adoption', 'contract'))
      and x9.get('fields', {}).get('Contract type') == x8['fields']['Contract type'] == '`FORMAL_SYMMETRY_CLASSIFICATION`.' and all(pb[r] == pd.get(r) for r in pb if r != KEY))
    new = [l for l in dl if l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18 §6.17, §2 OPEN 20 | RID: ' + RID + ']`')]
    nl = new[0] if len(new) == 1 else ''
    need = ['C^∞ germ scope', '(E1)', '(E2)', '(E3)', '(E4)', "DX'(0) = 0", 'is not claimed', "r'' is qualitative", 'no finite-C^k constant', 'G_∞^{-n} F^n', 'F^{-n} R_∞ F^n stays unproved',
            'B-an and B-6 stay OPEN', 'C^∞ existence is not analytic convergence', 'not independently reviewed', 'r4.8\'s line "' + BINF + '" is superseded.']
    g('S1 B-∞ existence: OPEN line replaced by one scoped [THM] owner import (E1-E4, E2 restriction, qualitative radius, route, B-an/B-6 OPEN)',
      BINF not in dl and BINF in Lb and len(new) == 1 and all(s in nl for s in need) and 'analytic' not in nl.replace('not analytic convergence', '').replace('analytic convergence', ''), f'{len(new)} line(s); missing {[s for s in need if s not in nl][:2]}')
    f8 = Lb[rec_idx['flat']]; f9 = [l for l in dl if l.startswith(PREF['flat'])]
    f9 = f9[0] if len(f9) == 1 else ''
    pre, post = f8.split(OLD_S)
    g('S2 Lemma F / F1–F3 line: only the existence sentence changed; grades, hypotheses and triad non-transfer kept',
      f9.startswith(pre) and f9.endswith(post) and OLD_S not in f9 and 'F1–F3 themselves assert no existence' in f9 and RID + ' E1–E4' in f9 and 'the roots K_m, J and R' in f9
      and 'Lemma F [THM]; F1–F3 [THM — conditional]' in f9 and 'Not transferred to the triad' in f9 and 'The RID word CAND is an identifier, not a status.' in f9)
    o8 = x8['open_items']; o9 = x9.get('open_items', [])
    g('S3 OPEN items = r4.8 minus exactly B-∞ existence; B-an, B-6, physical exchange byte-identical', o9 == [o for o in o8 if not o.startswith('OPEN 20 B-∞ existence:')] and len(o9) == len(o8) - 1 == 3
      and all(('[OPEN] ' + o) in dl for o in o9))
    i8, i9 = x8['imports'], x9.get('imports', [])
    add = [i for i in i9 if i.get('key') == 'DYAD6418']
    st8, st9 = P.source_table(b), P.source_table(d)
    g('S4 pins (D-B): imports = r4.8 + one DYAD6418 (v6.4.18 hash, cited path); DYAD6413 import line and table row unchanged; DYAD6418 table row',
      i9[:len(i8)] == i8 and len(i9) == len(i8) + 1 and len(add) == 1 and add[0]['cited_sha256'] == D18 and unquote(add[0]['path']) == D18_PATH and add[0]['section'] == '§2 OPEN 20, §6.17'
      and st9.get('DYAD6418', {}).get('sha256') == D18 and st9['DYAD6413'] == st8['DYAD6413'] and next(i for i in i9 if i['key'] == 'DYAD6413') == next(i for i in i8 if i['key'] == 'DYAD6413')
      and set(st9) == set(st8) | {'DYAD6418'})
    fd = x9.get('fields', {}); note = next((l for l in dl if l.startswith(PREF['note'])), '')
    out_rec = d.replace(Sd.get(KEY, (0, 0, ''))[2], '')
    occ_ok = all((RID not in l) or l.startswith('| `DYAD6418` |') or l.startswith('[ALG] R4.9 (20 Oct 2026)') or l.startswith('**Document status:** DRAFT r4.9') for l in out_rec.split('\n'))
    g('S5 scope fields: Non-transfer, source note (D-A), Order / error, Evidence (D-C); RID confined to the record, its table row and metadata',
      (fd.get('Non-transfer') or '').endswith(' r4.9: the C^∞ embedding (E1–E4) is not transferred either: its proof uses the isolated-dyad contraction DYAD-THM-PRIM-CTR, and nothing follows for Triadic G6, for analytic convergence (B-an, B-6), for physical pole exchange or for the G2 carrier map.')
      and 'transfers to' not in (fd.get('Non-transfer') or '')
      and 'do not say that every imported result of this record is formal' in note and '`DYAD-ALG-CENT-KERNEL` [ALG]' in note
      and 'analytic convergence remains OPEN 20 B-an/B-6' in (fd.get('Order / error') or '') and 'not an independent proof certification' in (fd.get('Evidence') or '') and occ_ok)
    pins = json.loads(pins_file.read_text(encoding='utf-8'))
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 every byte-available cited evidence file at its cited path with its cited hash (22, incl. Dyadic v6.4.18)', not miss and len(pins) == 22 and pins.get(D18_PATH, {}).get('sha256') == D18, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    L0 = d0.split('\n'); NL = next(l for l in L0 if l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18'))
    FL = next(l for l in L0 if l.startswith(PREF['flat']))
    T = [('L1 edit outside the record', 3, d0.replace('### RER-TRIAD-FORMAL-INVOLUTION — ', '### RER-TRIAD-FORMAL-INVOLUTION — (r4.9) ', 1)),
         ('L2 analytic-bridge line altered', 4, d0.replace('a real-analytic local involution R with R(0)=0 that commutes', 'a real-analytic local involution R that commutes', 1)),
         ('L3 extra [THM] label in Order / error', 5, d0.replace('C^∞ existence (not convergence) is CLOSED since Dyadic v6.4.18', 'C^∞ existence (not convergence) is CLOSED [THM] since Dyadic v6.4.18', 1)),
         ('P1 exactness widened (D-A option 2 not chosen)', 6, d0.replace('**Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12',
                                                                         '**Exactness:** `FORMAL_ONLY`, `C_INFTY_EXISTENCE`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12', 1)),
         ('P1 primary grade changed', 6, d0.replace('**Primary grade:** [THM] (owner grade). **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12',
                                                    '**Primary grade:** [THM] (owner grade; formal and C^∞). **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12', 1)),
         ('S1 B-∞ existence OPEN line left in place', 7, d0.replace(NL, BINF + '\n' + NL, 1)),
         ('S1 E2 restriction dropped', 7, d0.replace(" (uniqueness among all C^∞ generators of F is not claimed)", '', 1).replace("X is unique only among C^∞ generators X' with DX'(0) = 0", 'X is the unique C^∞ generator', 1)),
         ('S1 import claims analytic realization', 7, d0.replace('C^∞ existence is not analytic convergence: B-an and B-6 stay OPEN (lines above).', 'This gives the analytic realization of R_0.', 1)),
         ('S1 qualitative-radius boundary dropped', 7, d0.replace("The radius r'' is qualitative; no numerical radius and no finite-C^k constant is imported. ", '', 1)),
         ('S2 "No existence is asserted" kept unchanged as current text', 8, d0.replace(FL, FL.split('F1–F3 themselves assert no existence')[0] + OLD_S + FL.split('so F1–F3 apply to them (r4.9; r4.1–r4.8: "No existence is asserted"). The RID word CAND is an identifier, not a status.')[1], 1)),
         ('S2 F1–F3 regraded [THM]', 8, d0.replace('Lemma F [THM]; F1–F3 [THM — conditional] on Lemma F and on existence', 'Lemma F [THM]; F1–F3 [THM] on Lemma F and on existence', 1)),
         ('S3 B-an OPEN line dropped', 9, d0.replace('[OPEN] OPEN 20 B-an: convergence of R_0, equivalently of F^{1/2}.\n', '', 1)),
         ('S3 physical exchange closed', 9, d0.replace('[OPEN] Physical exchange (RRF OPEN-A).', '[DEF] Physical exchange (RRF OPEN-A): not addressed.', 1)),
         ('S4 DYAD6413 pin silently moved to v6.4.18', 10, d0.replace('Import/reference: [DYAD6413: §6.15, §6.16, §6.17, §2 OPEN 19/20] (project copy `RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md`; not in this package); SHA-256 `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542`',
                                                                   'Import/reference: [DYAD6413: §6.15, §6.16, §6.17, §2 OPEN 19/20] (project copy `RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md`; not in this package); SHA-256 `' + D18 + '`', 1)),
         ('S4 DYAD6418 hash wrong in the import line', 10, d0.replace('(sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md); SHA-256 `' + D18 + '`', '(sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md); SHA-256 `' + '0' * 64 + '`', 1)),
         ('S4 DYAD6418 source-table row dropped', 10, '\n'.join(l for l in L0 if not l.startswith('| `DYAD6418` |'))),
         ('S5 transfer to Triadic G6 asserted', 11, d0.replace('nothing follows for Triadic G6, for analytic convergence', 'the result transfers to Triadic G6; nothing follows for analytic convergence', 1)),
         ('S5 D-A reading caution dropped from the source note', 11, d0.replace(' The record-level grade, the Exactness `FORMAL_ONLY` and the contract type describe the formal classification only; they do not say that every imported result of this record is formal (the analytic bridge and the C^∞ embedding are not).', '', 1)),
         ('S5 Evidence claims proof certification', 11, d0.replace('and the import is not an independent proof certification.', 'and the import certifies the proof.', 1)),
         ('S5 RID mentioned outside the record', 11, d0.replace('**Non-transfer:** No triad statement follows.', '**Non-transfer:** No triad statement follows. DYAD-THM-SMOOTH-EMBEDDING applies here too.', 1) if '**Non-transfer:** No triad statement follows.' in d0 else d0 + '\nDYAD-THM-SMOOTH-EMBEDDING applies to the triad.\n')]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, r8 = gates(b, verbose=False); good = not r8[7] and not r8[10]; allf &= good
    print(f'  r4.8 bytes: S1, S4 = {[r8[7], r8[10]]} (expected both False)')
    keep = PARSER.read_bytes(); PARSER.write_bytes(keep + b'\n# changed\n')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[6]; allf &= good
        print(f'  tamper P1 parser file changed: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        PARSER.write_bytes(keep)
    p18 = HERE / D18_PATH; keep = p18.read_bytes(); p18.write_bytes(keep + b'x')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[12]; allf &= good
        print(f'  tamper K1 Dyadic v6.4.18 evidence file altered: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        p18.write_bytes(keep)
    pins = json.loads(PINS_FILE.read_text(encoding='utf-8')); pins.pop(D18_PATH); tmp = HERE / '_pins_tamper.json'; tmp.write_text(json.dumps(pins), encoding='utf-8')
    try:
        _, rr = gates(d0, verbose=False, pins_file=tmp); good = not rr[12]; allf &= good
        print(f'  tamper K1 v6.4.18 pin dropped from the pin list: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        tmp.unlink()
    ok = ok and allf
sys.exit(0 if ok else 1)
