"""Gates for RER v0.2 DRAFT r4.8 (on the exact r4.7 bytes). Exit 0 iff all pass; --tamper runs negative controls.
 M1 r4.7 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.7 byte-exactly.
 L1 locality: changed lines of r4.7 only at header lines 1/4/7, the RER-DYAD-FORMAL-INVOLUTION primary-grade line (one line inserted after it),
    the §9 R4.7 history anchor (one entry inserted before it) and the release-boundary line.
 L2 the other 23 heading spans, 24 headings and 16 r3.1 contract tables byte-identical; in RER-DYAD-FORMAL-INVOLUTION every line other than the
    grade line and the new source-note line is byte-identical to r4.7 (so the r4.7 O1, O2, O4, O5, O6 text is carried unchanged).
 L3 claim-tag deltas exactly [ALG] +1 (the §9 entry); the per-RID labels move, they are not added.
 G1 the primary-grade line equals the r4.6 line byte-exactly (record-level grade `[THM] (owner grade)` only).
 G2 the line directly below it is the source note carrying the r4.7 per-RID text verbatim, with DYAD-ALG-CENT-KERNEL [ALG].
 G3 with the unchanged Phase A parser (tools/rer_parse_phaseA_r10.py, pinned hash = Phase A r10 tools/rer_parse.py) the record parses to
    primary_grade '[THM] (owner grade)' and grade_tags ['THM'] on r4.8, and to grade_tags ['ALG', 'THM'] on r4.7 (historical R10-F1);
    exactness, task and adoption parse unchanged; every other record parses identically on r4.7 and r4.8.
 K1 every byte-available cited evidence file at its cited path with its cited hash (carried)."""
import sys, re, hashlib, difflib, json, importlib.util
from pathlib import Path
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_8_draft as B
PARSER = HERE / 'tools/rer_parse_phaseA_r10.py'; PARSER_SHA = '7b6b98aa1417c6bab99b6447f9f5756a04d3fc74f5b9f7d767cb75b55138a7b7'
spec = importlib.util.spec_from_file_location('rer_parse_r10', PARSER); P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
r46 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md').read_text(encoding='utf-8')
KEY = 'RER-DYAD-FORMAL-INVOLUTION'; NOTE = '**Owner grades per imported RID** (source note;'
LABELS = ('`DYAD-THM-FORMAL-INVOLUTION-UNIQUE` [THM]', '`DYAD-THM-FORMAL-CENTRALIZER` [THM]', '`DYAD-ALG-CENT-KERNEL` [ALG]', '`DYAD-THM-ANALYTIC-CLOCK-BRIDGE` `[THM — analytic]`')
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]; out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def parsed(t): return {rid: P.parse_record(rid, title, body) for rid, title, body in P.blocks(t)}
def gates(d, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.7 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.7 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    gi = next(i for i, l in enumerate(Lb) if l.startswith('**Primary grade:** [THM] (owner grade). Owner grades per imported RID'))
    allowed = {0, 3, 6, gi} | {i for i, l in enumerate(Lb) if l.startswith('[ALG] R4.7 (20 Oct 2026)') or l.startswith('**Release boundary (r4.7):**')}
    bad = [(t, a1, a2) for t, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes() if t != 'equal' and not (set(range(a1, a2)) if a2 > a1 else {a1}) <= allowed]
    g('L1 locality: header 1/4/7, DYAD grade line, §9 R4.7 anchor, release boundary only', not bad, f'{len(bad)} out-of-scope hunks')
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    others = [k for k in Sb if k != KEY]
    db = [l for l in Sb[KEY][2].split('\n') if not l.startswith('**Primary grade:**')]
    dd = [l for l in Sd.get(KEY, (0, 0, ''))[2].split('\n') if not l.startswith('**Primary grade:**') and not l.startswith(NOTE)]
    g('L2 other spans, headings, r3.1 tables and the rest of the DYAD record byte-identical', set(Sb) == set(Sd) and len(Sb) == 24 and all(Sb[k][2] == Sd[k][2] for k in others)
      and len(tables) == 16 and all(t in d for t in tables) and db == dd)
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    g('L3 claim-tag deltas exactly [ALG] +1', all(d.count(t) == b.count(t) + {'[ALG]': 1}.get(t, 0) for t in tags))
    rec = Sd.get(KEY, (0, 0, ''))[2].split('\n'); g46 = next(l for l in spans(r46)[KEY][2].split('\n') if l.startswith('**Primary grade:**'))
    k = next((i for i, l in enumerate(rec) if l.startswith('**Primary grade:**')), -1)
    g('G1 primary-grade line equals the r4.6 line byte-exactly', k >= 0 and rec[k] == g46)
    note = rec[k + 1] if 0 <= k < len(rec) - 1 else ''
    g47 = Lb[gi]; moved = g47[g47.index(' Owner grades per imported RID (r4.7): ') + len(' Owner grades per imported RID (r4.7): '):g47.index(' **Exactness:**')]
    g('G2 source-note line directly below carries the r4.7 per-RID text verbatim (CENT-KERNEL [ALG])', note.startswith(NOTE) and note.endswith(moved) and all(x in note for x in LABELS) and d.count(NOTE) == 1)
    pb, pd = parsed(b), parsed(d); x7, x8 = pb[KEY], pd.get(KEY, {})
    g('G3 unchanged parser: r4.8 grade [THM] (owner grade), tags [THM]; r4.7 tags [ALG, THM] (R10-F1, historical); other records parse identically',
      hashlib.sha256(PARSER.read_bytes()).hexdigest() == PARSER_SHA and x8.get('primary_grade') == '[THM] (owner grade)' and x8.get('grade_tags') == ['THM'] and x7['grade_tags'] == ['ALG', 'THM']
      and all(x8.get(f) == x7[f] for f in ('exactness_text', 'exactness_codes', 'task', 'registry_owner_adoption', 'contract', 'imports')) and all(pb[r] == pd.get(r) for r in pb if r != KEY))
    pins = json.loads((HERE / 'CITED_EVIDENCE_PINS.json').read_text(encoding='utf-8'))
    from urllib.parse import unquote
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 every byte-available cited evidence file at its cited path with its cited hash', not miss and len(pins) == 21, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    n0 = next(l for l in d0.split('\n') if l.startswith(NOTE))
    T = [('L1 edit outside the record', 3, d0.replace('### RER-TRIAD-FORMAL-INVOLUTION — ', '### RER-TRIAD-FORMAL-INVOLUTION — (r4.8) ', 1)),
         ('L2 another DYAD line altered (O2 bridge wording)', 4, d0.replace('a real-analytic local involution R with R(0)=0 that commutes', 'a real-analytic local involution R that commutes', 1)),
         ('L3 an extra [THM] label in the note', 5, d0.replace('`DYAD-THM-ANALYTIC-CLOCK-BRIDGE` `[THM — analytic]`', '`DYAD-THM-ANALYTIC-CLOCK-BRIDGE` [THM]', 1)),
         ('G1 per-RID labels left on the grade line (r4.7 layout)', 6, d0.replace('**Primary grade:** [THM] (owner grade). **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12',
                                                                          '**Primary grade:** [THM] (owner grade). Owner grades: see note. **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems adopted in Dyadic v6.4.12', 1)),
         ('G2 CENT-KERNEL relabelled [THM] in the note', 7, d0.replace(n0, n0.replace('`DYAD-ALG-CENT-KERNEL` [ALG]', '`DYAD-ALG-CENT-KERNEL` [THM]'), 1)),
         ('G2 source note dropped', 7, d0.replace('\n' + n0, '', 1)),
         ('G3 grade line rewritten to a mixed grade', 8, d0.replace('**Primary grade:** [THM] (owner grade). **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems',
                                                                 '**Primary grade:** [THM] (owner grade) with an [ALG] kernel. **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / owner theorems', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, r7 = gates(b, verbose=False); good = not r7[6] and not r7[8]; allf &= good
    print(f'  r4.7 bytes: G1, G3 = {[r7[6], r7[8]]} (expected both False)')
    keep = PARSER.read_bytes(); PARSER.write_bytes(keep + b'\n# changed\n')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[8]; allf &= good
        print(f'  tamper G3 parser file changed: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        PARSER.write_bytes(keep)
    pins = json.loads((HERE / 'CITED_EVIDENCE_PINS.json').read_text(encoding='utf-8')); p0 = HERE / sorted(pins)[0]
    keep = p0.read_bytes(); p0.write_bytes(keep + b'x')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[9]; allf &= good
        print(f'  tamper K1 (one evidence file altered): {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        p0.write_bytes(keep)
    ok = ok and allf
sys.exit(0 if ok else 1)
