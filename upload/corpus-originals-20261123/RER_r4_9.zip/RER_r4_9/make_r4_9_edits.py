"""Edit list RER v0.2 DRAFT r4.8 -> r4.9 (receiving decision of 20 Oct 2026 on the Dyadic v6.4.18 source reading: ACCEPT SCOPED;
D-A option 1, D-B new key DYAD6418, D-C owner-grade import). Changes RER-DYAD-FORMAL-INVOLUTION only, plus one source-table row,
metadata, one [ALG] §9 history entry and one release-boundary sentence.
C1 the r4.8 line "[OPEN] OPEN 20 B-∞ existence: ..." is replaced by a scoped [THM] owner import of DYAD-THM-SMOOTH-EMBEDDING (v6.4.18).
C2 the §6.17 Lemma F / F1–F3 line: only the sentence "No existence is asserted;" is replaced (F1–F3 assert no existence themselves;
   existence of the objects is supplied at owner level by E1–E4 since v6.4.18). Grades, hypotheses and the triad non-transfer are kept.
C3 a new Import/reference line DYAD6418 (v6.4.18 §2 OPEN 20, §6.17) after the RRF083 line; the DYAD6413 pin line is unchanged.
C4 source note: the record-level grade/exactness/contract type describe the formal classification, not every imported result (D-A),
   and the new RID's owner grade.
C5 Order / error: analytic convergence vs C^∞ existence. C6 Evidence: source-access level of the new import (D-C).
C7 Non-transfer: the C^∞ embedding is not transferred (Triadic G6, B-an/B-6, pole exchange, G2 carrier map).
T1 source-table row DYAD6418 after DYAD6414.
Not changed: primary-grade line, Exactness FORMAL_ONLY, Task, contract table, contract type, B-an/B-6/physical-exchange OPEN lines,
the analytic-bridge [THM] line, every other record, the r3.1 tables."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md').read_text(encoding='utf-8')
BASE_SHA = '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
SECCHK = '02d16047…f21b'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix):
    ls = [l for l in B.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.8\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.9\n')
ed('M2', 'metadata', '**Date:** 20 October 2026 (r4.8, r4.7);', '**Date:** 20 October 2026 (r4.9, r4.8, r4.7);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.8 — one layout edit',
   f'**Document status:** DRAFT r4.9 — narrow owner-synchronization revision of RER-DYAD-FORMAL-INVOLUTION (Dyadic v6.4.18: OPEN 20 B-∞ existence CLOSED by DYAD-THM-SMOOTH-EMBEDDING at C^∞ germ scope; new pin DYAD6418; receiving decisions D-A, D-B, D-C of 20 Oct 2026), built deterministically on the exact r4.8 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_9_draft.py`; the record-level grade, exactness, contract, the B-an/B-6/physical-exchange OPEN items, the DYAD6413 pin and all other records are unchanged. r4.8 was: one layout edit')

binf = line('[OPEN] OPEN 20 B-∞ existence:')
ed('C1', 'content', binf,
   '[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18 §6.17, §2 OPEN 20 | RID: DYAD-THM-SMOOTH-EMBEDDING]` (r4.9; owner grade [THM] at C^∞ germ scope: C^∞ local germs at P1, raw frame W, lifted chart) OPEN 20 B-∞ existence is CLOSED at the owner (Dyadic v6.4.18). '
   "(E1) On a ball U* = B(0, r'') there is a C^∞ vector field X with j^∞X = log F and F = φ^1_X. "
   "(E2) X is unique only among C^∞ generators X' with DX'(0) = 0 (uniqueness among all C^∞ generators of F is not claimed). "
   '(E3) For every m ≥ 1, K_m = φ_X^{1/m} is the unique C^∞ tangent-to-identity root with K_m^m = F, and it commutes with T. '
   '(E4) J = T∘K_6^{-1} satisfies J^6 = id, DJ(0) = A, JT = TJ; R = T^3∘K_2^{-1} is a C^∞ local involution with DR(0) = −I and RT = TR, unique by F2, satisfying the §6.15 domain convention with V = B ∩ R^{-1}(B). '
   "The radius r'' is qualitative; no numerical radius and no finite-C^k constant is imported. The owner's proof route is Φ_∞ = lim G_∞^{-n} F^n (G_∞ the Borel time-one map, unrelated to G = J^2); the earlier route F^{-n} R_∞ F^n stays unproved. "
   'C^∞ existence is not analytic convergence: B-an and B-6 stay OPEN (lines above). Imported at owner grade from the byte-verified owner statement; the owner\'s proof records are not independently reviewed here. '
   'r4.8\'s line "' + binf + '" is superseded.')

flat = line('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 |')
old_s = 'No existence is asserted; the RID word CAND is an identifier, not a status.'
assert flat.count(old_s) == 1
ed('C2', 'content', flat, flat.replace(old_s,
   'F1–F3 themselves assert no existence (owner grades unchanged in v6.4.18); since Dyadic v6.4.18 the existence of the objects they concern — the roots K_m, J and R — is supplied at owner level by DYAD-THM-SMOOTH-EMBEDDING E1–E4 (owner §6.17 recorded distinction (iv); line above), so F1–F3 apply to them (r4.9; r4.1–r4.8: "No existence is asserted"). The RID word CAND is an identifier, not a status.'))

rrf = line('Import/reference: [RRF083: §2.3, §2.4b')
ed('C3', 'content', rrf, rrf + '\n'
   f'Import/reference: [DYAD6418: §2 OPEN 20, §6.17] (sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md); SHA-256 `{D18}` (BYTE-VERIFIED by the RER preparer against the release record, hash receiver-confirmed 20 Oct 2026; section comparison v6.4.17 → v6.4.18: §2 OPEN 19, §6.15, §6.16 identical, §2 OPEN 20 and §6.17 changed, receiver-accepted). r4.9: pin for the v6.4.18 results only (DYAD-THM-SMOOTH-EMBEDDING and the OPEN 20 status); the DYAD6413 line above stays the pin for §6.15, §6.16, Lemma F and F1–F3.')

note = line('**Owner grades per imported RID** (source note;')
tail = 'all formal-category except the analytic bridge.'
assert note.endswith(tail)
ed('C4', 'content', note, note + ' r4.9: `DYAD-THM-SMOOTH-EMBEDDING` [THM] (Dyadic v6.4.18; C^∞ germ scope — neither formal-category nor analytic). The record-level grade, the Exactness `FORMAL_ONLY` and the contract type describe the formal classification only; they do not say that every imported result of this record is formal (the analytic bridge and the C^∞ embedding are not).')

order = '**Order / error:** All formal orders. Convergence: OPEN 20 (`DYAD-OPEN-INVOLUTION-REALIZATION`).'
ed('C5', 'content', order, order + ' r4.9: analytic convergence remains OPEN 20 B-an/B-6; C^∞ existence (not convergence) is CLOSED since Dyadic v6.4.18 (DYAD-THM-SMOOTH-EMBEDDING, qualitative radius).')

ev = line('**Evidence:** owner theorem SOURCE-READ (project copy);')
ed('C6', 'content', ev, ev + ' r4.9: the DYAD-THM-SMOOTH-EMBEDDING statement, its scope labels and recorded distinctions are SOURCE-READ from the byte-verified v6.4.18 (DYAD6418) and imported at owner grade (receiving decision D-C); the owner\'s seven SESSION proof records (DYAD-ART-OPEN20-BINF-RECORDS) and checks (DYAD-ART-OPEN20-BINF-CHECKS) are owner-reported, not read or rerun here, and the import is not an independent proof certification.')

nt = '**Non-transfer:** No triad statement follows (see RER-TRIAD-FORMAL-INVOLUTION). No physical pole exchange. S_h is not upgraded beyond degree 6.'
ed('C7', 'content', nt, nt + ' r4.9: the C^∞ embedding (E1–E4) is not transferred either: its proof uses the isolated-dyad contraction DYAD-THM-PRIM-CTR, and nothing follows for Triadic G6, for analytic convergence (B-an, B-6), for physical pole exchange or for the G2 carrier map.')

d14 = line('| `DYAD6414` |')
ed('T1', 'source-table', d14, d14 + '\n'
   f'| `DYAD6418` | Dyadic v6.4.18 adopted 20 Oct (`DYAD-THM-SMOOTH-EMBEDDING` [THM], C^∞ germ scope; OPEN 20 B-∞ existence CLOSED, B-an and B-6 OPEN; notice N14) | `{D18}` | BYTE-VERIFIED (RER preparer, 20 Oct; equal to the release record `claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md`; hash receiver-confirmed); §2 OPEN 20 and §6.17 SOURCE-READ; v6.4.17 → v6.4.18 section comparison receiver-accepted (`DYAD_v6_4_18_SECTION_CHECK_r1.zip` `{SECCHK}`); citation pin for the v6.4.18 results only (r4.9) |')

h48 = line('[ALG] R4.8 (20 Oct 2026) is a one-edit layout revision')
ed('H1', 'history', h48, '[ALG] R4.9 (20 Oct 2026) is a narrow owner-synchronization revision on the exact r4.8 bytes, limited to RER-DYAD-FORMAL-INVOLUTION, after the receiving acceptance of the Dyadic v6.4.18 source reading (decisions D-A option 1, D-B new key DYAD6418, D-C owner-grade import). '
   'The line stating OPEN 20 B-∞ existence OPEN is replaced by a scoped owner import of DYAD-THM-SMOOTH-EMBEDDING (C^∞ germ scope; E2 only for generators with zero linear part; qualitative radius); in the Lemma F / F1–F3 line only the sentence on existence changes (F1–F3 assert none themselves; the objects exist at owner level by E1–E4). '
   'New pin DYAD6418 with a source-table row; DYAD6413 stays the pin for §6.15, §6.16, Lemma F and F1–F3. The source note, Order / error, Evidence and Non-transfer fields record the scope: formal record-level labels, analytic convergence (B-an, B-6) OPEN, owner-grade import without independent proof review, no transfer to the triad, to pole exchange or to the G2 carrier map. '
   'The primary-grade line, Exactness, Task, contract table and type, the other OPEN items and all other records are unchanged. Phase A warning SYNC-DYAD-OPEN20-BINF is not closed by this draft; its closure needs a Phase A pass on the accepted bytes.\n' + h48)
rb = '**Release boundary (r4.8):** r4.8 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.9):** r4.9 is a noncanonical review draft; it adopts, freezes and accepts nothing, and it certifies no owner proof. ' + rb)

t = B
for e in E:
    assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_8_to_r4_9_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
