"""Edit list RER v0.2 DRAFT r4.7 -> r4.8: one content edit implementing the receiver's R10-F1 decision (20 Oct 2026, option (b)).
G1 RER-DYAD-FORMAL-INVOLUTION: the primary-grade line returns to its r4.6 text (only `[THM] (owner grade)` as the grade); the r4.7
   per-RID owner grades move unchanged to a separate source-note line directly below it (DYAD-ALG-CENT-KERNEL stays [ALG]).
Plus metadata (title, date, status line), one [ALG] §9 history entry and one release-boundary sentence.
The Phase A parser is not changed. No grade, OPEN status, pin, contract cell or other record changes."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_7.md').read_text(encoding='utf-8')
BASE_SHA = '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
R46 = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md').read_text(encoding='utf-8')
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(t, prefix):
    ls = [l for l in t.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.7\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.8\n')
ed('M2', 'metadata', '**Date:** 20 October 2026 (r4.7);', '**Date:** 20 October 2026 (r4.8, r4.7);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.7 — narrow record-text revision',
   f'**Document status:** DRAFT r4.8 — one layout edit in RER-DYAD-FORMAL-INVOLUTION (receiving decision on Phase A finding R10-F1: the per-RID owner grades move from the primary-grade line to a separate source-note line), built deterministically on the exact r4.7 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_8_draft.py`; no grade, OPEN status, pin or other record changes. r4.7 was: narrow record-text revision')

g47 = line(B, '**Primary grade:** [THM] (owner grade). Owner grades per imported RID (r4.7):')
g46 = line(R46.split('### RER-DYAD-FORMAL-INVOLUTION — ')[1].split('\n<a id=')[0], '**Primary grade:** [THM] (owner grade).')
sent = ' Owner grades per imported RID (r4.7): '
i = g47.index(sent); j = g47.index(' **Exactness:**')
labels = g47[i + len(sent):j]                     # the r4.7 per-RID text, moved verbatim
assert g47[:i] + g47[j:] == g46 and labels.endswith('all formal-category except the analytic bridge.')
ed('G1', 'R10-F1', g47, g46 + '\n**Owner grades per imported RID** (source note; r4.7 content, own line since r4.8; the record-level primary grade above summarizes the principal formal result): ' + labels)

h47 = line(B, '[ALG] R4.7 (20 Oct 2026) is a narrow record-text revision')
ed('H1', 'history', h47, '[ALG] R4.8 (20 Oct 2026) is a one-edit layout revision on the exact r4.7 bytes, answering Phase A finding R10-F1 by the receiver\'s option (b). In RER-DYAD-FORMAL-INVOLUTION the primary-grade line is restored to its r4.6 text, so the machine-parsed primary grade is again the r4.6 owner-grade label (theorem grade only); the r4.7 per-RID owner grades move verbatim to a separate source-note line below it (DYAD-ALG-CENT-KERNEL keeps its algebraic owner grade). The Phase A parser is unchanged; the Phase A r10 output with grade tags ALG and THM stays as the historical r4.7 record. No grade, OPEN status, pin or other record changes.\n' + h47)
rb = '**Release boundary (r4.7):** r4.7 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.8):** r4.8 is a noncanonical review draft; it adopts, freezes and accepts nothing. ' + rb)

t = B
for e in E:
    assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_7_to_r4_8_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
