"""Gates for RER v0.2 DRAFT r4.6 (on r4.5 bytes); all r4.5 gates carried (M1-M3 against r4.5; M5 allows exactly the five [DEF] overlays and one [ALG] history entry), plus R1-R6 for the RRF editor disposition (Q1-Q7). From r4.5: S1 (A-P1) and K1 (cited evidence at cited paths). From r4.4: (U1 now requires the adopted Triadic v1.6.1), plus P1-P4 pointer gates. Exit 0 iff all pass; --tamper runs negative controls.
Structural: M1 base SHA; M2 rebuild; M3 reversal to r4.1; M4 24 headings + 16 r3.1 contract tables byte-identical; M5 tag counts
unchanged (editorial release: no claim tag added or removed); M6 four r4 records still owner-adoption pending.
Carried r4.1 scope gates: C1 no live Dyadic v6.4.12.1 pin; C2 OPEN 20 split; C3 G5 only with C^3; C4 mean-feedback only with H_spec;
C5 no Lemma-F RID in RER-TRIAD records.
Summary synchronization (R41-SUM-01): U1 status summary names DRAFT r2 and no longer 'DRAFT r1 exists'; U2 no current summary says the
TM lemma review is OPEN; U3 both summaries keep RECEIVER-REPORTED and keep regional/global certification OPEN; U4 every current-state line
naming the TM lemma review (outside §9 history and outside the frozen r3.1 contract tables) distinguishes it from the open guard/coverage/
certificate, and a frozen stale table cell is covered by a current-use overlay in its record.
E2: E1 Genesis v2.8.8 recorded OWNER-REPORTED, not used as a theorem pin (all [import: ...GENESIS... ] tags still v2.8.7)."""
import sys, re, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_6_draft as B
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
def gates(d, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.5 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.5 byte-exactly', ok and rev == b)
    heads = re.findall(r'^### RER-[A-Z0-9-]+ — .*$', b, re.M)
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    g('M4 headings and r3.1 contract tables byte-identical', len(heads) == 24 and all(h in d for h in heads) and len(tables) == 16 and all(t in d for t in tables))
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    g('M5 claim-tag counts unchanged except five [DEF] overlays and one [ALG] history entry', all(d.count(t) == b.count(t) + {'[ALG]': 1, '[DEF]': 5}.get(t, 0) for t in tags))
    new = ['RER-GEN-K3-MODAL', 'RER-DYAD-FORMAL-INVOLUTION', 'RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION']
    g('M6 four r4 records still owner-adoption pending', all(re.search(re.escape(k) + r' — [^\n]*\n\*\*Primary grade:\*\*[^\n]*Registry/owner adoption:\*\* pending', d) for k in new))
    bad = [l for l in d.splitlines() if 'v6.4.12.1' in l and not re.search(r'r4 pin|r4 pinned|superseded|current pin v6\.4\.13|R4\.1 \(19 Oct 2026\)|released as v6\.4\.12\.1|R4 \(18 Oct 2026\)|Dyadic v6\.4\.12\.1 cites', l)]
    g('C1 no live Dyadic v6.4.12.1 pin', not bad)
    rec = d.split('### RER-DYAD-FORMAL-INVOLUTION')[1].split('\n### ')[0]
    g('C2 OPEN 20 split retained', '[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness.' not in rec and '[OPEN] OPEN 20 B-∞ existence' in rec and '[OPEN] OPEN 20 B-6' in rec)
    g('C3 G5 closure only with C^3', not [l for l in d.splitlines() if 'CLOSED_AT_OWNER_GRADE' in l and 'C^3' not in l])
    g('C4 mean-feedback theorem only with H_spec', not [l for l in d.splitlines() if 'GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO' in l and 'H_spec' not in l])
    triad = ''.join(d.split('### ' + k)[1].split('\n### ')[0] for k in ['RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION'])
    g('C5 no Lemma-F RID in RER-TRIAD records', not re.search(r'DYAD-CAND-FLAT|DYAD-CAND-SMOOTH|DYAD-THM-FORMAL-Z6', triad))
    L = d.splitlines(); summ = next(l for l in L if l.startswith('**Status summary:**')); s1 = next(l for l in L if l.startswith('[OPEN] N=7/8 whole-region constants'))
    g('U1 status summary names adopted Triadic v1.6.1; no "DRAFT r1 exists"', 'DRAFT r1 exists' not in d and 'Triadic v1.6.1 adopted 19 Oct 2026' in summ)
    g('U2 no current summary calls the TM lemma review OPEN', not re.search(r'TM lemma review OPEN|lemma review and governing coverage remain OPEN', summ + s1))
    g('U3 both summaries keep RECEIVER-REPORTED and keep certification OPEN', all('RECEIVER-REPORTED' in x and 'remain OPEN' in x for x in (summ, s1)))
    hist = d.split('## 9.')[1] if '## 9.' in d else ''
    frozen = set(x for tb in tables for x in tb.splitlines())
    cur = [l for l in d.split('## 9.')[0].splitlines() if re.search(r'lemma review', l, re.I) and l not in frozen]
    f3 = d.split('### RER-F3-N7N8')[1].split('\n### ')[0]
    stale_cells = [l for l in f3.splitlines() if l in frozen and re.search(r'lemma review[^|]*remain OPEN', l)]
    g('U4 every current-state lemma-review line separates review from open guard/coverage/certificate',
      (not stale_cells or 'r4.2 current-use overlay (RER-F3-N7N8)' in f3) and cur and all(re.search(r'RECEIVER-REPORTED|performed|reported completed|done', l) and re.search(r'guard|a ≤ 1|remain OPEN|OPEN', l) for l in cur), f'{len(cur)} lines')
    cur2 = [l for l in d.split('## 9.')[0].splitlines() if l not in frozen]
    generic = [l for l in cur2 if re.search(r'proof review', l, re.I) and not re.search(r'end-to-end|lemma', l, re.I)]
    g('U5 no unqualified "proof review" in current text; no stale (r4.1) current-use label', not generic and '**Next test:** (r4.1)' not in d, f'{len(generic)} generic')
    T161 = '95340abe57e999ed48681502152113d8fdb3102f74f45a25aa66c2d0092d451f'
    comp = next(l for l in d.splitlines() if l.startswith('**Companion documents:**'))
    g('P1 Triadic v1.6.1 is the cited Triadic source (companion, import, source table)', T161 in comp and 'Import/reference: [TRIAD161: Triadic v1.6.1 (adopted' in d and '| `TRIAD161` |' in d and 'Triadic v1.6 (adopted) and' not in d)
    g('P2 RRF v0.8.3 governs; v0.8.2 historical', '[DEF] Adopted RRF v0.8.3 now governs' in d and '| `RRF083` |' in d and 'adopted RRF v0.8.3 working standard' in comp)
    g('P3 Dyadic v6.4.14 recorded but not used as a citation pin', '| `DYAD6414` |' in d and not re.search(r'\[import: RTG_DYADIC_OSCILLATOR_DSN_v6\.4\.14', d))
    p = HERE / 'sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md'
    g('P4 cited Triadic v1.6.1 present at cited path with cited hash', p.exists() and hashlib.sha256(p.read_bytes()).hexdigest() == T161)
    gen_imports = re.findall(r'\[import: RTG_GENESIS_GEOMETRY_DSN_v([0-9.]+)', d)
    g('E2 Genesis v2.8.8 recorded OWNER-REPORTED, theorem imports stay v2.8.7', '`GEN288`' in d and 'not used as a theorem pin' in d and gen_imports and set(gen_imports) == {'2.8.7'}, f'{len(gen_imports)} imports')
    cut = d.split('## 9.')[0]
    src_rows = [l for l in cut.splitlines() if l.startswith('| `TRIAD161_DRAFT')]
    # text after the first ' was:' in a line is a revision-history chain (e.g. the header status line)
    stale = [l for l in cut.splitlines() if l not in src_rows and l not in frozen and re.search(r'v1\.6\.1 DRAFT r[12]', l.split(' was:')[0]) and not re.search(r'historical|History|history|is historical', l)]
    g('S1 (A-P1) no live statement treats a Triadic v1.6.1 DRAFT as the current source', not stale and 'it is a draft, not an adopted owner source' not in d, f'{len(stale)} stale')
    import json as _j
    pins = _j.loads((HERE / 'CITED_EVIDENCE_PINS.json').read_text(encoding='utf-8'))
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in __import__('urllib.parse').parse.unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 every byte-available cited evidence file is at its cited path with its cited hash', not miss and len(pins) == 21, f'{len(pins)} pins, {len(miss)} bad')
    Q7 = __import__('json').loads((HERE / 'inputs/rrf_editor_q7_hashes.json').read_text(encoding='utf-8'))
    def rec(k): return d.split('### ' + k + ' — ')[1].split('\n### ')[0] if ('### ' + k + ' — ') in d else ''
    g7, g9, g10, cnd, dyad, car_er = rec('RER-G7'), rec('RER-G9'), rec('RER-G10'), rec('RER-RRF-CND01'), rec('RER-DYAD-FORMAL-INVOLUTION'), rec('RER-ER2B-CARRIER')
    toks = ['CHANGED-SCOPE', 'node exchange acting on that complete state', 'edge-slot permutation', 'same selected full update', 'Eσ = RE', 'EF = KE', 'admissible fixed-state witness', '`regularity:`', '`clock:`', '`domain:`']
    g('R1 (Q1/Q6) G7 and CND01 carry the complete-state node-exchange realization contract; no live "§6.2 SAME-SCOPE"', all(all(t in x for t in toks) for x in (g7, cnd))
      and 'RER-native standard mathematics' in cnd and 'proposed interface (definition grade)' in cnd and not re.search(r'§6\.2[^.;]{0,40}SAME-SCOPE', d.split('## 9.')[0]))
    i1, i2 = g9.find('RECOG v0.3.20 §6.6a, `RECOG-ALG-SHEAR-ORIENTATION-CONJUGACY`'), g9.find('IMP-O09-03 is a consumer cross-reference')
    g('R2 (Q2) G9 owner-first: RECOG pin before the OFN consumer cross-reference', 0 <= i1 < i2)
    P = '65186f393985ed502512c875601891cec999830abc2cc7db2fe01dd94f554e86'
    g('R3 (Q3/Q4) G10 cites the separate proposal by hash, non-normative; old live §6.4 [OPEN] wording gone', P in g10 and 'NON-NORMATIVE' in g10 and d.count(P) >= 2
      and '[OPEN] RRF §6.4 includes finite-jet wording under FORMAL_ONLY.' not in d)
    oldcar = '| Carrier | Formal germs of the isolated dyad at P1 in the raw linear frame W=L(rho,eta); profile RRF-DYAD-W (RRF v0.8.2 §2.3, §2.4b). Not the triad carrier. |'
    law = '| Transformation law | R_0=T^3 o F^{-1/2}=h^(-I)h^{-1} for any formal Poincaré–Dulac normalizer h^. The finite chart S_h=h_6(-I)h_6^{-1} equals R_0 only through jet degree 6. |'
    g('R4 (Q5) formal involution carrier: raw-W germ, RRF-DYAD-NF + §2.4b registration, finite S_h only to degree 6; formula unchanged', oldcar not in d and law in dyad
      and all(t in dyad for t in ('written in the raw linear frame W=L(rho,eta)', 'without a normalizer', 'RRF-DYAD-NF + §2.4b', 'equal to R_0 only through jet degree 6', 'not the network raw W')))
    zipl = [l for l in d.splitlines() if l.startswith('**Missing primary input:** `ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip`')]
    unk = [l for l in d.splitlines() if 'hash unknown in this session' in l and l.startswith('**Missing primary input:**')]
    g('R5 (Q7) editor-hashed sources recorded as RRF_EDITOR_VERIFIED; ZIP stays unverified; ER-2B stays blocked',
      all(Q7[k] in d for k in ('RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md', 'RTG_RRF_COINCIDENCE_ADMISSIBILITY_REVIEW_v0_1.md', 'RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'))
      and d.count('RRF_EDITOR_VERIFIED') >= 6 and len(zipl) == 1 and unk == zipl and 'provenance and execution unverified' in zipl[0]
      and 'stays BLOCKED_SOURCE_UNVERIFIED' in car_er and 'the v0.2 evidence package remains absent' in cnd)
    g('R6 editor response pinned and described as noncanonical', Q7['response_sha256'] in d and 'NONCANONICAL written interface response' in d and 'amends no RRF text' in d)
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    T = [('U1', 11, d0.replace('Triadic v1.6.1 adopted 19 Oct 2026 on PI authorization', 'Triadic v1.6.1 DRAFT r1 exists', 1)),
         ('U2', 12, d0.replace('regional K_N, governing coverage and the global certificate remain OPEN.', 'global certificate and TM lemma review OPEN.', 1)),
         ('U3', 13, d0.replace('reported completed (RECEIVER-REPORTED, 19 Oct 2026)', 'completed (19 Oct 2026)', 1)),
         ('E2', 20, d0.replace('`[import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3a.1', '`[import: RTG_GENESIS_GEOMETRY_DSN_v2.8.8 §6.3a.1', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    # the delivered r4.1 bytes must fail the summary gates (the finding the r4.1 checker missed)
    T2 = [('U5', 15, d0.replace('[OPEN] independent review of a future end-to-end governing-region certificate (distinct from the scoped one-step Taylor-model lemma review, which is reported completed: RECEIVER-REPORTED, 19 Oct 2026)', '[OPEN] independent proof review', 1))]
    for n, i, t in T2:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    T3 = [('P1', 16, d0.replace('Import/reference: [TRIAD161: Triadic v1.6.1 (adopted', 'Import/reference: [TRIAD161X: Triadic v1.6.1 (adopted', 1)), ('P3', 18, d0.replace('`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.16', '`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.14 §6.16', 1))]
    for n, i, t in T3:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    T4 = [('S1', 21, d0.replace('The r4–r4.4 reference to Triadic v1.6.1 DRAFT r1 at this point is historical.', 'Triadic v1.6.1 DRAFT r1 (D3) records the same conditionality on the Triadic side; it is a draft, not an adopted owner source.', 1))]
    for n, i, t in T4:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    T5 = [('R1', 23, d0.replace('§6.2 is CHANGED-SCOPE (`', '§6.2 is SAME-SCOPE (`', 1)),
          ('R2', 24, d0.replace('OFN v0.9 IMP-O09-03 is a consumer cross-reference only.', 'OFN v0.9 IMP-O09-03 is the primary pin.', 1)),
          ('R3', 25, d0.replace('[OPEN] The noncanonical closure proposal', '[OPEN] RRF §6.4 includes finite-jet wording under FORMAL_ONLY. [OPEN] The noncanonical closure proposal', 1)),
          ('R4', 26, d0.replace('RRF-DYAD-NF + §2.4b (formal only)', 'RRF-DYAD-W (formal only)', 1)),
          ('R5', 27, d0.replace('hash unknown in this session; r4.6: no hash recorded by RRF either (Q7); provenance and execution unverified.', 'r4.6: byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED).', 1))]
    for n, i, t in T5:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    _, rb = gates(b, verbose=False); print(f'  r4.5 bytes: R1..R5 = {rb[23:28]} (expected all False)'); allf &= not any(rb[23:28])
    import shutil, tempfile
    pins = __import__('json').loads((HERE / 'CITED_EVIDENCE_PINS.json').read_text(encoding='utf-8')); p0 = HERE / sorted(pins)[0]
    keep = p0.read_bytes(); p0.write_bytes(keep + b'x')
    try:
        _, rr = gates(d0, verbose=False); print(f'  tamper K1 (one evidence file altered): gate {"FAILS (good)" if not rr[22] else "still passes (BAD)"}'); allf &= not rr[22]
    finally:
        p0.write_bytes(keep)
    ok = ok and allf
sys.exit(0 if ok else 1)
