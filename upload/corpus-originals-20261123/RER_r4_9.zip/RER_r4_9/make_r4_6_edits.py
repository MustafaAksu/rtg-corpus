"""Edit list RER v0.2 DRAFT r4.5 -> r4.6: implements the written RRF editor disposition of Q1-Q8
(RRF_EDITOR_RESPONSE_TO_RER_PHASEA_v0_2_20261019.md). Point-of-use overlays for G7-G10 and RER-RRF-CND01 (frozen r3.1
contract tables are not edited), the carrier cell of RER-DYAD-FORMAL-INVOLUTION (r4 record), the G10 [OPEN] line, and the
Q7 source-custody lines. No grade, record, contract-table or OPEN-status change.
Q7 full hashes are read from inputs/rrf_editor_q7_hashes.json, which must be extracted from the editor response whose own
SHA-256 is pinned below."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_5.md').read_text(encoding='utf-8')
assert hashlib.sha256(B.encode()).hexdigest() == '5691e20a9a854c449f9a72a126aa31619c5d71bb5d74a7a436001eb376bf8c19'
RESP_SHA = '413a869b49a295652af1379510fbece2d10619daffd5874c1320e1d686113084'
Q7 = json.loads(Path('inputs/rrf_editor_q7_hashes.json').read_text(encoding='utf-8'))
assert Q7['response_sha256'] == RESP_SHA
H_RESP, H_REV, H_ER2 = Q7['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md'], Q7['RTG_RRF_COINCIDENCE_ADMISSIBILITY_REVIEW_v0_1.md'], Q7['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']
assert H_RESP.startswith('897bfad0') and H_REV.startswith('ef89db5c') and H_ER2.startswith('ea26d3d1')
assert H_ER2 == 'ea26d3d1a4853ac88d1938dcb66c76eda4d55980ebf6f4d61091b97d67b2bb5e'  # also reported independently by ER-2B v0.3 Part A.6
PROP = '65186f393985ed502512c875601891cec999830abc2cc7db2fe01dd94f554e86'
RRF083 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
ED = f'RRF editor response v0.2 (19 Oct 2026, NONCANONICAL written interface response, SHA-256 `{RESP_SHA}`)'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix):
    ls = [l for l in B.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.5\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.6\n')
ed('M2', 'metadata', '**Date:** 19 October 2026 (r4.5, r4.4,', '**Date:** 19 October 2026 (r4.6, r4.5, r4.4,')
ed('M3', 'metadata', '**Document status:** DRAFT r4.5 — one current-use provenance repair',
   f'**Document status:** DRAFT r4.6 — implements the written RRF editor disposition of Q1–Q8 ({ED}) at the points of use, built deterministically on the exact r4.5 bytes (SHA-256 `5691e20a9a854c449f9a72a126aa31619c5d71bb5d74a7a436001eb376bf8c19`) by `build_r4_6_draft.py`; the editor response is not an RRF amendment and not RER adoption; no grade, record, contract table or OPEN status changes. r4.5 was: one current-use provenance repair')

CONTRACT = ('a physical coincidence exclusion requires a realization contract that declares: (i) the complete physical state, including all transition-relevant data; '
            '(ii) σ as the node exchange acting on that complete state — an edge-slot permutation, a zero edge or equal coordinates do not qualify; '
            '(iii) F as the same selected full update, with Fσ = σF for that update; (iv) the encoding/action intertwining Eσ = RE and EF = KE at one shared clock; '
            '(v) an actually admissible fixed-state witness; and (vi) explicit `regularity:`, `clock:` and `domain:` declarations')
g7 = line('[DEF] RRF-CND-01 is an interface proposal.')
ed('G7', 'Q1/Q6', g7, g7 + f'\n\n[DEF] **r4.6 current-use overlay (RRF editor Q1, Q6).** Per the {ED}: RRF v0.8.3 §0.3 is SAME-SCOPE with v0.8; §6.2 is CHANGED-SCOPE (`{RRF083}`), so the v0.8 §6.2 pins below are historical and not a same-section repin. The general fixed-set lemma is unchanged and remains mathematics; applied physically, {CONTRACT}. This overlay asserts no realization.')
g8 = line('[DEF] Move state, dynamics, readout, action, closure/incidence, events and domain together under a passive chart.')
ed('G8', 'Q1', g8, g8 + '\n\n[DEF] **r4.6 current-use overlay (RRF editor Q1).** The §0.3 passive-versus-new-model rule is SAME-SCOPE in RRF v0.8.3. Where the passive/new-model distinction is used for a physical coincidence inference, the G7 realization contract applies; otherwise G8 is unchanged.')
g9 = line('[DEF] Cross-model T_k/T_-k conjugacy, a within-chart involution, edge bookkeeping and physical pole exchange remain distinct.')
ed('G9', 'Q2', g9, g9 + '\n\n[DEF] **r4.6 current-use overlay (RRF editor Q2: SAME-SCOPE, owner-first).** Scientific owner first: RECOG v0.3.20 §6.6a, `RECOG-ALG-SHEAR-ORIENTATION-CONJUGACY` (freeze candidate). OFN v0.9 IMP-O09-03 is a consumer cross-reference only. RRF v0.8.3 §4.2a is the representation-interface pin; RRF v0.8.3 §6.3 is byte-identical with v0.8 §6.3. The v0.8 pins below are historical.')
g10 = line('[DEF] RRF v0.8 is the adopted working representation standard, authenticated by its header/hash.')
ed('G10', 'Q3/Q4', g10, g10 + f'\n\n[DEF] **r4.6 current-use overlay (RRF editor Q3, Q4).** The v0.8 §6.4 pins below are historical. From RRF v0.8.1 on, the closure taxonomy is the separate noncanonical proposal `RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md` (SHA-256 `{PROP}`, as recorded by the RRF editor); RRF v0.8.3 §6.4 is a non-normative pointer, not the taxonomy. The RER closure taxonomy remains NON-NORMATIVE: not a mandatory RRF profile field, owner theorem, numerical certificate, physical test or physical selection.')
op = line('[OPEN] RRF §6.4 includes finite-jet wording under FORMAL_ONLY.')
ed('G10b', 'Q3', op, '[OPEN] The noncanonical closure proposal `RTG_RRF_RER_DYNAMICAL_CLOSURE_PROPOSAL_v0_1.md` (former RRF v0.8 §6.4 content; SHA-256 `' + PROP + '`) includes finite-jet wording under FORMAL_ONLY. RER retains the distinction between all-orders formal existence and finite-order equality pending interface clarification of that proposal, not a unilateral RRF amendment. History (r4–r4.5): ' + op[len('[OPEN] '):])

nt = line('**Next test:** Supply complete state/action/encoding/physical clock and genuine admissible witness.')
ed('C1', 'Q1/Q6/Q7', nt, f'[DEF] **r4.6 current-use overlay (RRF editor Q1, Q6, Q7).** The frozen r3.1 contract above is read as follows. Provenance split (Q6 confirmed): the theorem-grade implication `F sigma=sigma F => F(Fix sigma) subset Fix sigma` is RER-native standard mathematics (deterministic equivariance), stated generally; the Identity–Action / Carrier–Encoding / Clock–Model / separate-Merge structure is the RRF v0.8.3 §6.2 proposed interface (definition grade) (CHANGED-SCOPE from v0.8, `{RRF083}`), which is not the source of the theorem grade. For the physical specialization, {CONTRACT}. The specialization does not replace the general statement and asserts no realization. Q7 source custody: see the missing-input lines below; bytes byte-hashed by the RRF editor are `RRF_EDITOR_VERIFIED`, which is distinct from inspection by the RER preparer or receiver, from certificate replay and from physical admissibility.\n' + nt)
ed('C2', 'Q7', '**Missing primary input:** `RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md`; hash unknown in this session. Secondary references do not authenticate it.\n**Missing primary input:** `ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip`; hash unknown in this session. Secondary references do not authenticate it.\n**Missing primary input:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`; hash unknown in this session.',
   f'**Missing primary input:** `RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md`; r4.6: SHA-256 `{H_RESP}` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED; Q7); bytes not inspected by the RER preparer or receiver. Secondary references do not authenticate it.\n**Missing primary input:** `ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip`; hash unknown in this session; r4.6: no hash recorded by RRF either (Q7); provenance and execution unverified. Secondary references do not authenticate it.\n**Missing primary input:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`; r4.6: SHA-256 `{H_ER2}` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED; Q7; the same identity is source-reported by ER-2B consolidated v0.3 Part A.6); bytes not inspected by the RER preparer or receiver; the v0.2 evidence package remains absent.')
ed('C3', 'Q7', '**Missing primary input:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`; hash unknown in this session. Secondary references do not authenticate it.\n[OPEN] RER receiving verification of ER-2B v0.2 C19–C20',
   f'**Missing primary input:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`; r4.6: SHA-256 `{H_ER2}` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED; Q7; also source-reported by ER-2B consolidated v0.3 Part A.6); bytes not inspected by the RER preparer or receiver; the v0.2 evidence package remains absent, so this record stays BLOCKED_SOURCE_UNVERIFIED. Secondary references do not authenticate it.\n[OPEN] RER receiving verification of ER-2B v0.2 C19–C20')
for k, h in (('ER02', H_ER2), ('COINC_RESPONSE', H_RESP)):
    row = line(f'| `{k}` | Direct source not available |')
    ed('S-' + k, 'Q7', row, row[:-1].rstrip() + f'; r4.6: SHA-256 `{h}` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED, Q7); bytes still not available to RER |')
row = line('| `COINC_CERT` | Direct source not available |')
ed('S-COINC_CERT', 'Q7', row, row[:-1].rstrip() + '; r4.6: no hash recorded by RRF either (Q7) |\n'
   f'| `COINC_REVIEW` | RRF coincidence admissibility review v0.1 (noncanonical; reported by the RRF editor, not cited by any RER record) | `RTG_RRF_COINCIDENCE_ADMISSIBILITY_REVIEW_v0_1.md`; SHA-256 `{H_REV}` byte-hashed by the RRF editor (RRF_EDITOR_VERIFIED, Q7); bytes not available to RER |')

car = '| Carrier | Formal germs of the isolated dyad at P1 in the raw linear frame W=L(rho,eta); profile RRF-DYAD-W (RRF v0.8.2 §2.3, §2.4b). Not the triad carrier. |'
ed('D1', 'Q5', car, '| Carrier | Formal germs of the isolated dyad at P1, written in the raw linear frame W=L(rho,eta) (frame of RRF-DYAD-W, RRF v0.8.3 §2.3); R_0 is defined there without a normalizer (DYAD v6.4.13 §6.16). RRF registers the formal involution at RRF-DYAD-NF + §2.4b (formal only); the RRF-DYAD-W relabeling candidate is the finite S_h, equal to R_0 only through jet degree 6. The isolated-dyad W is not the network raw W (RRF-NET-W-RAW provisional; bridge OPEN). r4.6 carrier per RRF editor Q5; r4–r4.5 label was profile RRF-DYAD-W (RRF v0.8.2 §2.3, §2.4b). Not the triad carrier. |')

H = '[ALG] R4.5 (19 Oct 2026) is a one-sentence current-use repair'
ed('H1', 'metadata', H, f'[ALG] R4.6 (19 Oct 2026) implements the written RRF editor disposition of Q1–Q8 ({ED}) on the exact r4.5 bytes: G7–G10 and RER-RRF-CND01 receive point-of-use overlays (Q1 §6.2 CHANGED-SCOPE with the complete-state node-exchange realization contract; Q2 owner-first RECOG pin; Q3 closure taxonomy cited from the separate noncanonical proposal; Q4 non-normative; Q6 provenance split); the carrier cell of RER-DYAD-FORMAL-INVOLUTION separates the raw-W formal germ from the RRF-DYAD-NF registration and the finite S_h (Q5); Q7 source hashes are recorded as RRF_EDITOR_VERIFIED without unblocking any record. The frozen r3.1 contract tables, all grades, all OPEN statuses and earlier revision text are unchanged.\n' + H)
ed('H2', 'metadata', '**Release boundary (r4.5):**', '**Release boundary (r4.6):** r4.6 is a noncanonical review draft; it adopts, freezes and accepts nothing; the RRF editor response it implements is noncanonical and amends no RRF text. **Release boundary (r4.5):**')
Path('r4_5_to_r4_6_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1), encoding='utf-8'); print(len(E), 'edits')
