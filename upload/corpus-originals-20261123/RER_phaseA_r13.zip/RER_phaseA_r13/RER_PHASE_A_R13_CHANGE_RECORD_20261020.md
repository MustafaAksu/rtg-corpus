# RER Phase A r13: change record (RECOG current-version byte verification)

**Date:** 20 Oct 2026.
**From:** Claude, RER co-owner (preparer). The preparer does not accept his own work.
**Status:** NONCANONICAL Phase A candidate, revision 13. Nothing is adopted, frozen or published.
**Answers:** the receiving decision of 20 Oct 2026 (RECOG section comparison ACCEPT SCOPED; Phase A r13 authorized as a narrow source-currency revision). It is a preparation authorization, not a scientific acceptance.

## 1. Base

- **Source Markdown:** unchanged, RER r4.8 (`2dfebebf…0e3e`).
- **Base package:** Phase A r12 (`78575592…1953`, accepted), extracted fresh.
- **Patch:** `patch_r13.py`, at the package root.
- **r12 history:** the five r12 outputs and the r12 checker output are kept byte-unchanged under `inputs/phaseA_r12_outputs/` and pinned in `PINS.json`.

## 2. Inputs added

| Path | Content |
|---|---|
| `sources_available/RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md` | RECOG v0.3.21, `a3459522…0ae3` (PI upload; equals the release record; receiver confirmed the same hash) |
| `inputs/source_custody_r13.json` | custody entry for that file; container chain PREPARER_DECLARED |
| `inputs/recog_v0_3_21_section_check/` | the accepted section check: script, three outputs, note (package `0e5e38b4…1463`) |

## 3. Catalog changes (RECOG only)

| Field | r12 | r13 |
|---|---|---|
| Current version | v0.3.21 `a3459522…0ae3` | unchanged |
| Evidence | OWNER_REPORTED | BYTE_VERIFIED |
| History | `phaseA_r6_r11` (BYTE_VERIFIED v0.3.20) | kept, plus `phaseA_r12` (OWNER_REPORTED v0.3.21) |
| Superseded v0.3.20 | `fdb8c9a7…b8df`, BYTE_VERIFIED, `FROZEN 19 Oct 2026 — OWNER_REPORTED` | unchanged |
| Key `RECOG` rule | UNCHANGED_OWNER_REPORTED | UNCHANGED_VERIFIED; reason cites the section check; `receiver_section_check` receipt added |

`inputs/owner_versions_known.json`: version unchanged (0.3.21); check date and RECOG source authority updated. The other owners, the Dyadic entry and SYNC-DYAD-OPEN20-BINF are unchanged.

## 4. Result

**Matrix.** 90 rows. Exactly two rows change, RER-G9/0 (§6.6a) and RER-G9/1 (§6.16g), in these fields only: `currency` (→ UNCHANGED_VERIFIED), `currency_reason`, `status` (OWNER_REPORTED → VERIFIED), `current_owner_evidence` (→ BYTE_VERIFIED), `verified_current_hash` (→ `a3459522…0ae3`), `receiver_section_check` (added). Kept: pin v0.3.20 with `fdb8c9a7…b8df`, bytes BYTE_VERIFIED_MATCH, `PENDING_PER_REFERENCE_AUDIT`, reviewer disposition PENDING.

| Measure | r12 | r13 |
|---|---|---|
| VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED | 28 / 6 / 50 / 6 | 30 / 4 / 50 / 6 |
| Authentication | 58 / 7 / 24 / 1 | unchanged |

Registry and blocked register: differ from r12 only in `schema`.

**W3 note in the reason field.** G9/1's reason states that section equality does not resolve the W3 interface question (RECOG §7.2 RF-1: §6.16g requires $a^-, a^+$ in the same space; RRF v0.8.3 §6.3 describes a comparison or transport between spaces). The per-reference audit of G9/1 stays open; the RRF editor's answer to RF-1 is the input for it.

## 5. Gates: 28/28 PASS; controls 76/76 fail as required

| Gate | Requires |
|---|---|
| A26 (rewritten) | RECOG v0.3.21 BYTE_VERIFIED only with the real file, matching custody and a section-check record (both MATCH, 2 IDENTICAL, 0 hunks inside, PASS) whose v0.3.20 ranges equal the two rows' `lines`; r6–r11 and r12 history; v0.3.20 identity and frozen status; rows on pin v0.3.20 with the original hash, UNCHANGED_VERIFIED, VERIFIED, verified hash v0.3.21, audit pending, receiver receipt |
| A28 (new) | equality with the pinned r12 outputs except the six RECOG row fields above, the RECOG catalog entry and one new watch item |

A1–A25 and A27 are carried; A1 now also pins the new inputs and the r12 outputs.

**New controls (19):**
- evidence back to OWNER_REPORTED; relabelled BYTE_VERIFIED_HERE; hash replaced;
- a row left in the r12 state; pin silently moved to v0.3.21; G9/1 audit marked done;
- r12 or r6–r11 history dropped; row line range not covered by the section check; receiver receipt dropped;
- A28: r12 rows re-used; a non-RECOG row reason edited; a RECOG field outside the currency set changed; the sync-warning action edited; the Dyadic entry changed; the blocked register changed;
- file control: v0.3.21 withheld from `sources_available`;
- input controls: section-check output with a DIFFERENT block; with a hunk inside a cited block; custody hash altered.

One r12 control ("v0.3.21 promoted to BYTE_VERIFIED without bytes") is replaced by the file control and "evidence back to OWNER_REPORTED". The old-version-current control (A19, v0.3.20) is carried.

**Clean extraction.** Re-extracted into an empty directory and run with `python -I`: output byte-identical to the stored checker output.

## 6. Not changed

- RER text, grades, OPEN statuses and pins; RER-DYAD-FORMAL-INVOLUTION and SYNC-DYAD-OPEN20-BINF (still OPEN; Dyadic v6.4.18 bytes not held; r4.9 waits for them).
- ER-2B blocked; G2 §5b pending; the 13 gap references `PENDING_PER_REFERENCE_AUDIT`; author-conflicted Phase B reviews with the receiver.
