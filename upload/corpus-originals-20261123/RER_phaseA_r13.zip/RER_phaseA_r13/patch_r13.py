"""Phase A r12 -> r13: RECOG current-version byte verification (receiving decision of 20 Oct 2026: RECOG section comparison ACCEPT SCOPED;
narrow source-currency revision authorized). Source Markdown unchanged (RER r4.8).
- RECOG v0.3.21 bytes added: sources_available/RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md (a3459522...0ae3), custody
  inputs/source_custody_r13.json, section check inputs/recog_v0_3_21_section_check/ (both hashes MATCH; §6.6a and §6.16g IDENTICAL;
  0 change hunks inside the cited blocks; receiver-run independently).
- Catalog: RECOG current v0.3.21 evidence BYTE_VERIFIED; the r12 OWNER_REPORTED state kept as history (phaseA_r12); v0.3.20 kept as
  superseded with its BYTE_VERIFIED identity, original hash and frozen history; key RECOG rule UNCHANGED_VERIFIED (cited blocks
  byte-identical), RER pins stay v0.3.20.
- Rows RER-G9/0 and RER-G9/1: only currency, currency_reason, status, current_owner_evidence, verified_current_hash and
  receiver_section_check change. PENDING_PER_REFERENCE_AUDIT kept.
- r12 outputs moved to inputs/phaseA_r12_outputs/ (history, pinned). A26 rewritten; new A28 (equality with r12). New negative controls.
Exact-once text replacements; catalog JSON edits by key. Args: TARGET_DIR RECOG_V0321_FILE SECTION_CHECK_DIR. Run once on a fresh copy of r12."""
import sys, os, json, shutil, hashlib
D, F21, SCD = sys.argv[1], sys.argv[2], sys.argv[3]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:90]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'
G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
SC_PKG = '0e5e38b47b75af33b79fd410d178c824709e19cbd868c77109082d63902a1463'
b21 = open(F21, 'rb').read(); assert sha(b21) == G21, 'v0.3.21 hash mismatch'
FN = 'RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md'

# keep r12 outputs as history
H = os.path.join(D, 'inputs/phaseA_r12_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r12.txt'))

# bytes, section check, custody
open(os.path.join(D, 'sources_available', FN), 'wb').write(b21)
SC = os.path.join(D, 'inputs/recog_v0_3_21_section_check'); os.makedirs(SC)
SCF = ['recog_v0_3_20_v0_3_21_section_identity_check.py', 'compare_output.txt', 'single_v0_3_21_output.txt', 'negcontrol_output.txt', 'RECOG_v0_3_21_SECTION_CHECK_NOTE_20261020.md']
for f in SCF: shutil.copyfile(os.path.join(SCD, f), os.path.join(SC, f))
cmp_out = open(os.path.join(SC, 'compare_output.txt'), encoding='utf-8').read()
assert 'RESULT: PASS' in cmp_out and cmp_out.count('IDENTICAL') == 2 and 'hunks inside cited blocks: 0' in cmp_out
open(os.path.join(D, 'inputs/source_custody_r13.json'), 'w').write(dump({
    '_about': 'Phase A r13 custody for the RECOG v0.3.21 owner file.',
    'container_chain_status': 'PREPARER_DECLARED: the file hash was computed here and matches the release record; the receiver independently confirmed the same hash on 20 Oct 2026 (section-check review). The upload path is the preparer\'s declaration.',
    'files': {FN: {'key': 'RECOG0321', 'version': '0.3.21', 'sha256': G21,
                   'container': 'PI upload to the preparer session, 20 Oct 2026 (RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md, 301292 bytes, 1493 lines); hash equals the v0.3.21 release record (claude/RECOG_v0_3_21_RELEASE_RECORD.md)'}},
    'section_check': {'package_r1': 'RECOG_v0_3_21_SECTION_CHECK_r1.zip ' + SC_PKG + ' (receiver-run: manifest 7/7, both hashes MATCH, 2/2 IDENTICAL, negative controls 2/2, clean replay PASS)',
                      'files': 'inputs/recog_v0_3_21_section_check/', 'blocks': ['§6.6a CELL-G1', '§6.16g CELL-F4'],
                      'v0_3_20_sha256': G20, 'v0_3_21_sha256': G21,
                      'result': 'PASS: both file hashes MATCH; §6.6a and §6.16g byte-IDENTICAL; 0 of 19 whole-file change hunks inside the cited blocks (preparer run and independent receiver run)',
                      'scope': 'byte equality of the two cited blocks only; not a re-review of the scientific content of v0.3.21'}}))

p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
assert KV['RECOG'] == '0.3.21'
KV['_catalog_checked'] = '2026-10-20 (Phase A r13, preparer)'
KV['_source_authority']['RECOG'] = ('owner release record claude/RECOG_v0_3_21_RELEASE_RECORD.md; v0.3.21 bytes held and hashed here (sources_available, inputs/source_custody_r13.json), hash independently confirmed by the receiver. '
                                    'Superseded v0.3.20: file byte-verified here (sources_available); its frozen status (19 Oct 2026) is owner-reported by the v0.3.21 release record.')
open(p, 'w').write(dump(KV))

p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
rc = CS['owner_current']['RECOG']; assert rc['version'] == '0.3.21' and rc['sha256'] == G21 and rc['evidence'] == 'OWNER_REPORTED'
hist = dict(rc['history']); hist['phaseA_r12'] = {'version': '0.3.21', 'sha256': G21, 'evidence': 'OWNER_REPORTED', 'note': rc['note']}
CS['owner_current']['RECOG'] = {
    'version': '0.3.21', 'sha256': G21, 'evidence': 'BYTE_VERIFIED', 'history': hist, 'superseded': rc['superseded'],
    'note': 'adopted 20 Oct 2026 (release record claude/RECOG_v0_3_21_RELEASE_RECORD.md). Phase A r13: bytes held in sources_available and hashed here (inputs/source_custody_r13.json); hash independently confirmed by the receiver (20 Oct 2026). Per the release record: synchronization-only release; no scientific RID, result grade or OPEN status changed; three new artifact IDs; not frozen. The RECOG G3 notice to RER (freeze record and adopted hash) is recorded there as not yet sent.'}
k = CS['keys']['RECOG']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED' and k['cited_version'] == '0.3.20'
k['rule'] = 'UNCHANGED_VERIFIED'
k['reason'] = ('Phase A r13: current RECOG is v0.3.21 (BYTE_VERIFIED). The cited v0.3.20 blocks §6.6a (lines 517–542) and §6.16g (lines 1002–1042) are byte-identical in v0.3.21 (lines 521–546, 1006–1046); '
               'no whole-file change hunk falls inside them (inputs/recog_v0_3_21_section_check/). RER pins stay on v0.3.20. Section equality only: the per-reference audit of each gap reference stays pending, and the W3 interface question (RECOG §7.2 RF-1 vs RRF v0.8.3 §6.3) is not resolved by it.')
k['receiver_section_check'] = 'RECEIVER-REPORTED (20 Oct 2026): RECOG_v0_3_21_SECTION_CHECK_r1.zip ' + SC_PKG[:8] + '…' + SC_PKG[-4:] + ' re-run independently; manifest 7/7; both hashes MATCH; §6.6a and §6.16g BYTE-IDENTICAL; negative controls 2/2; clean replay PASS. ACCEPT SCOPED.'
CS['_about'] += ' Phase A r13 (20 Oct): RECOG v0.3.21 bytes added (inputs/source_custody_r13.json); RECOG evidence BYTE_VERIFIED; cited §6.6a and §6.16g byte-identical to v0.3.20; r12 state kept as history.'
open(p, 'w').write(dump(CS))

rp('build_phaseA.py', [
 ('"""RER Phase A r12 builder (deterministic; r12 changes only the owner-currency catalog and adds scientific sync warnings).',
  '"""RER Phase A r13 builder (deterministic; r12 changed only the owner-currency catalog and added scientific sync warnings; r13 byte-verifies the RECOG current version).'),
 ("'RER-REGISTRY-PHASEA/12'", "'RER-REGISTRY-PHASEA/13'"), ("'RER-SOURCE-CURRENCY/12'", "'RER-SOURCE-CURRENCY/13'"), ("'RER-BLOCKED-SOURCES/12'", "'RER-BLOCKED-SOURCES/13'"),
 ("'# RER r4.8 — source-currency matrix (Phase A r12, noncanonical)'", "'# RER r4.8 — source-currency matrix (Phase A r13, noncanonical)'"),
 ("'# RER r4.8 — blocked-source register (Phase A r12, noncanonical)'", "'# RER r4.8 — blocked-source register (Phase A r13, noncanonical)'"),
 ("Scientific sync warning SYNC-DYAD-OPEN20-BINF is OPEN: RER-DYAD-FORMAL-INVOLUTION still states B-∞ existence OPEN.']}",
  "Scientific sync warning SYNC-DYAD-OPEN20-BINF is OPEN: RER-DYAD-FORMAL-INVOLUTION still states B-∞ existence OPEN.',\n"
  "                          'Phase A r13 (20 Oct 2026): RECOG v0.3.21 bytes held and hashed here (a3459522…0ae3), hash independently confirmed by the receiver; the cited §6.6a and §6.16g are byte-identical to v0.3.20 (preparer and receiver runs). RECOG evidence BYTE_VERIFIED; RER-G9/0 and G9/1 UNCHANGED_VERIFIED; RER RECOG pins stay on v0.3.20; per-reference audit of both rows still pending (G9/1: W3 interface question, RECOG §7.2 RF-1 vs RRF v0.8.3 §6.3). The r12 OWNER_REPORTED line above is kept as history.']}"),
])

rp('check_phaseA.py', [
 ('"""Phase A r12 gates on RER v0.2 DRAFT r4.8 (r12: owner-currency catalog update; source unchanged).',
  '"""Phase A r13 gates on RER v0.2 DRAFT r4.8 (r12: owner-currency catalog update; r13: RECOG v0.3.21 byte verification; source unchanged).'),
 ("OPEN while every listed line is present in the Markdown, and never CLOSED by Phase A.\n",
  "OPEN while every listed line is present in the Markdown, and never CLOSED by Phase A.\n"
  "A26 (r13, replaces the r12 wording above): RECOG v0.3.21 current with evidence BYTE_VERIFIED, which requires the real file in sources_available with the\n"
  "expected hash, a matching custody entry (inputs/source_custody_r13.json) and the section-check record (both hashes MATCH, 2/2 IDENTICAL, no change hunk\n"
  "inside the cited blocks, RESULT PASS) whose v0.3.20 line ranges equal the `lines` of the two RECOG rows; history keeps r6-r11 (BYTE_VERIFIED v0.3.20) and\n"
  "r12 (OWNER_REPORTED v0.3.21); v0.3.20 superseded with its BYTE_VERIFIED identity and frozen status; RECOG rows: pins v0.3.20 with the original hash,\n"
  "UNCHANGED_VERIFIED, VERIFIED, verified current hash v0.3.21, PENDING_PER_REFERENCE_AUDIT kept. A28 (r13) equality with the pinned r12 outputs: the 90 matrix rows\n"
  "equal r12 in every field except, for the two RECOG rows only, currency, currency_reason, status, current_owner_evidence, verified_current_hash and\n"
  "receiver_section_check; registry and blocked register equal r12 except schema; owner_current equal except RECOG; sync warnings equal; one watch item added.\n"
  "--tamper also runs file/input controls: v0.3.21 file withheld; section-check output altered; custody hash altered.\n"),
 ("def gates(outs, verbose=True, withhold=()):\n    res = []\n",
  "def gates(outs, verbose=True, withhold=(), inp=None):\n    res = []; inp = inp or {}\n    ri = lambda p: inp[p] if p in inp else B.rd(p)\n"),
 ("    rc = oc['RECOG']; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'\n"
  "    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']\n"
  "    rc_ok = (rc['version'] == '0.3.21' and rc['sha256'] == G21 and rc['evidence'] == 'OWNER_REPORTED' and G21 not in avail and G20 in avail\n"
  "             and rc.get('superseded', {}).get('version') == '0.3.20' and rc['superseded'].get('sha256') == G20 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')\n"
  "             and rc['superseded'].get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED') and rc.get('history', {}).get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED'\n"
  "             and len(rr_) == 2 and all(x['cited_version'] == '0.3.20' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['currency'] == 'UNCHANGED_OWNER_REPORTED'\n"
  "                                       and x['status'] == 'OWNER_REPORTED' and x['verified_current_hash'] is None and x['current_owner_version'] == '0.3.21' for x in rr_))\n"
  "    g('A26 RECOG v0.3.21 owner-reported; v0.3.20 byte-verified bytes kept, frozen status owner-reported; RECOG rows not CURRENT', rc_ok, f'{len(rr_)} RECOG rows')\n",
  "    rc = oc['RECOG']; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'\n"
  "    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']\n"
  "    FN21 = 'RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md'; P21 = os.path.join(HERE, 'sources_available', FN21)\n"
  "    file_ok = FN21 not in withhold and os.path.isfile(P21) and sha(open(P21, 'rb').read()) == G21\n"
  "    C13 = json.loads(ri('inputs/source_custody_r13.json')); f13 = C13.get('files', {}).get(FN21, {})\n"
  "    sc13 = ri('inputs/recog_v0_3_21_section_check/compare_output.txt').decode('utf-8')\n"
  "    sc13_ok = (f'v0.3.20 {G20} MATCH' in sc13 and f'v0.3.21 {G21} MATCH' in sc13 and sc13.count('IDENTICAL') == 2 and 'DIFFERENT' not in sc13\n"
  "               and 'hunks inside cited blocks: 0' in sc13 and 'RESULT: PASS' in sc13)\n"
  "    rng = {m.group(1): [int(m.group(2)), int(m.group(3))] for m in re.finditer(r'^  (§6\\.6a|§6\\.16g) +v0\\.3\\.20 lines (\\d+)-(\\d+) ', sc13, re.M)}\n"
  "    rows_rng_ok = len(rr_) == 2 and len(rng) == 2 and all(any(x['section_or_RID'].startswith(s + ' ') and x['lines'] == v for s, v in rng.items()) for x in rr_) and len({tuple(x['lines']) for x in rr_}) == 2\n"
  "    hs = rc.get('history', {})\n"
  "    rc_ok = (rc['version'] == '0.3.21' and rc['sha256'] == G21 and rc['evidence'] == 'BYTE_VERIFIED' and G21 in avail and G20 in avail and file_ok\n"
  "             and f13.get('key') == 'RECOG0321' and f13.get('sha256') == G21 and bool(f13.get('container')) and C13.get('container_chain_status', '').startswith('PREPARER_DECLARED') and sc13_ok and rows_rng_ok\n"
  "             and hs.get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r6_r11'].get('sha256') == G20 and hs['phaseA_r6_r11'].get('version') == '0.3.20'\n"
  "             and hs.get('phaseA_r12', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12'].get('sha256') == G21 and hs['phaseA_r12'].get('version') == '0.3.21'\n"
  "             and rc.get('superseded', {}).get('version') == '0.3.20' and rc['superseded'].get('sha256') == G20 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')\n"
  "             and rc['superseded'].get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED')\n"
  "             and all(x['cited_version'] == '0.3.20' and x['cited_sha256'] == G20 and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'\n"
  "                     and x['available_file'] == 'sources_available/RECOG__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md' and x['currency'] == 'UNCHANGED_VERIFIED' and x['status'] == 'VERIFIED'\n"
  "                     and x['verified_current_hash'] == G21 and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['current_owner_version'] == '0.3.21'\n"
  "                     and x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' and x['reviewer_disposition'] == 'PENDING' and x.get('receiver_section_check', '').startswith('RECEIVER-REPORTED') for x in rr_))\n"
  "    g('A26 RECOG v0.3.21 byte-verified (file, custody r13, section check 2/2 IDENTICAL); r6-r11 and r12 history kept; v0.3.20 identity and frozen status kept; RER pins stay v0.3.20; per-reference audit pending', rc_ok, f'{len(rr_)} RECOG rows; ranges {rng}')\n"),
 ("    return all(res), res\n\nouts =",
  "    H12 = 'inputs/phaseA_r12_outputs/'\n"
  "    m12 = json.loads(B.rd(H12 + 'SOURCE_CURRENCY_MATRIX.json')); g12 = json.loads(B.rd(H12 + 'RER_REGISTRY_v0_2_r4_8_PHASEA.json')); b12 = json.loads(B.rd(H12 + 'BLOCKED_SOURCE_REGISTER.json'))\n"
  "    RCF = {'currency', 'currency_reason', 'status', 'current_owner_evidence', 'verified_current_hash', 'receiver_section_check'}\n"
  "    dk = [sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k)) for x, y in zip(cm['rows'], m12['rows'])]\n"
  "    rows12_ok = (len(cm['rows']) == len(m12['rows']) == 90 and all((not d) if y['owner'] != 'RECOG' else (bool(d) and set(d) <= RCF) for d, y in zip(dk, m12['rows']))\n"
  "                 and sum(1 for d in dk if d) == 2)\n"
  "    strip = lambda o: {k: v for k, v in o.items() if k != 'schema'}\n"
  "    oc12 = m12['owner_current']; cat12 = m12['owner_catalog']\n"
  "    rest12_ok = (strip(reg) == strip(g12) and strip(br) == strip(b12) and reg['schema'] == 'RER-REGISTRY-PHASEA/13' and cm['schema'] == 'RER-SOURCE-CURRENCY/13' and br['schema'] == 'RER-BLOCKED-SOURCES/13'\n"
  "                 and {k: v for k, v in oc.items() if k != 'RECOG'} == {k: v for k, v in oc12.items() if k != 'RECOG'} and cm.get('scientific_sync_warnings') == m12.get('scientific_sync_warnings')\n"
  "                 and cm['watch_items'][:-1] == m12['watch_items'] and len(cm['watch_items']) == len(m12['watch_items']) + 1 and cm['watch_items'][-1].startswith('Phase A r13 (20 Oct 2026): RECOG v0.3.21 bytes held')\n"
  "                 and {k: v for k, v in meta.get('source_authority', {}).items() if k != 'RECOG'} == {k: v for k, v in cat12['source_authority'].items() if k != 'RECOG'} and meta.get('scope') == cat12['scope']\n"
  "                 and cm['bytes_not_available_to_preparer'] == m12['bytes_not_available_to_preparer'] and m12['schema'] == 'RER-SOURCE-CURRENCY/12')\n"
  "    g('A28 r12 equality: only the RECOG owner-currency fields of RER-G9/0 and G9/1 and the RECOG catalog entry differ; registry, blocked register, other owners and sync warning unchanged', rows12_ok and rest12_ok, f'{sum(1 for d in dk if d)} rows differ from r12: {[d for d in dk if d][:1]}')\n"
  "    return all(res), res\n\nouts ="),
 ("         ('A26 RECOG v0.3.21 promoted to BYTE_VERIFIED without bytes', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED'))),\n",
  "         ('A26 RECOG evidence back to OWNER_REPORTED (r12 state)', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='OWNER_REPORTED'))),\n"
  "         ('A26 RECOG evidence relabelled BYTE_VERIFIED_HERE (not catalog vocabulary)', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED_HERE'))),\n"
  "         ('A26 v0.3.21 hash replaced', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(sha256='0' * 64))),\n"
  "         ('A26 RECOG row left in the r12 state (UNCHANGED_OWNER_REPORTED, no verified hash)', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED', verified_current_hash=None, current_owner_evidence='OWNER_REPORTED'))),\n"
  "         ('A26 RECOG pin silently moved to v0.3.21', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(cited_version='0.3.21', cited_sha256='a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'))),\n"
  "         ('A26 G9/1 per-reference audit marked done', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG' and x['n'] == 1).update(gap_reference_review='AUDITED'))),\n"
  "         ('A26 r12 OWNER_REPORTED history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r12'))),\n"
  "         ('A26 r6-r11 BYTE_VERIFIED v0.3.20 history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r6_r11'))),\n"
  "         ('A26 RECOG row line range not covered by the section check', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(lines=[517, 560]))),\n"
  "         ('A26 receiver section-check receipt dropped from a RECOG row', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').pop('receiver_section_check'))),\n"
  "         ('A28 r12 matrix rows re-used', 27, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r12_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows']))),\n"
  "         ('A28 non-RECOG row reason edited', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(currency_reason='edited'))),\n"
  "         ('A28 RECOG row field outside the currency set changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(section_or_RID='§6.6a (edited)'))),\n"
  "         ('A28 sync warning action edited', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].update(required_action='none'))),\n"
  "         ('A28 Dyadic catalog entry changed', 27, mut(C, lambda d: d['owner_current']['Dyadic'].update(note='edited'))),\n"
  "         ('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited'))),\n"),
 ("file control A23 v6.4.17 file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n",
  "file control A23 v6.4.17 file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    _, rr = gates(outs, verbose=False, withhold=('RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md',)); good = not rr[25]; allf &= good\n"
  "    print(f'  file control A26 v0.3.21 file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    sc = B.rd('inputs/recog_v0_3_21_section_check/compare_output.txt'); cu = B.rd('inputs/source_custody_r13.json')\n"
  "    for n, p, b in [('section-check output shows a DIFFERENT block', 'inputs/recog_v0_3_21_section_check/compare_output.txt', sc.replace(b'IDENTICAL', b'DIFFERENT', 1)),\n"
  "                    ('section-check output shows a change hunk inside a cited block', 'inputs/recog_v0_3_21_section_check/compare_output.txt', sc.replace(b'hunks inside cited blocks: 0', b'hunks inside cited blocks: 1')),\n"
  "                    ('custody hash altered', 'inputs/source_custody_r13.json', cu.replace(b'a3459522c8f58204', b'0000000000000000', 1))]:\n"
  "        _, rr = gates(outs, verbose=False, inp={p: b}); good = not rr[25]; allf &= good\n"
  "        print(f'  input control A26 {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"),
])

# input pins
p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: assert f in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/source_custody_r13.json'] + ['inputs/recog_v0_3_21_section_check/' + x for x in SCF] + ['inputs/phaseA_r12_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched')
