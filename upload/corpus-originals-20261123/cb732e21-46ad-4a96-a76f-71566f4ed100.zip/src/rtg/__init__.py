"""
rtg package root.
ASCII-only identifiers. YAML-in, JSON-out.
"""
