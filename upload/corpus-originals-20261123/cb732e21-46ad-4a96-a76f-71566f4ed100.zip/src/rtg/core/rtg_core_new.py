# rtg_core.py
# Core math, model, stability analysis, diagnostics (plots & Lyapunov).
# Numpy + Matplotlib only. ASCII console; UTF-8 files.

from __future__ import annotations
import os, math, time, json
from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Dict
import numpy as np
import matplotlib.pyplot as plt


# -------------------------------
# Utilities
# -------------------------------

def _block_diag(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    n = A.shape[0]
    m = B.shape[0]
    Z1 = np.zeros((n,m), dtype=float)
    Z2 = np.zeros((m,n), dtype=float)
    return np.block([[A, Z1],
                     [Z2, B]])


# -------------------------------
# Model specs
# -------------------------------

@dataclass
class GraphSpec:
    n: int = 3
    directed: bool = True
    deg_norm: bool = False
    # directed coupling weights (n x n), can be asymmetric
    kappa: np.ndarray = field(default_factory=lambda: np.ones((3,3), dtype=float))
    # frustration angles (n x n)
    alphas: np.ndarray = field(default_factory=lambda: np.zeros((3,3), dtype=float))
    # degree vector for row-normalization
    deg_vec: np.ndarray = field(default_factory=lambda: np.ones(3, dtype=float))

    def __post_init__(self):
        self.kappa = np.array(self.kappa, dtype=float)
        self.alphas = np.array(self.alphas, dtype=float)
        if self.deg_vec is None or len(np.atleast_1d(self.deg_vec)) != self.n:
            self.deg_vec = np.sum(np.abs(self.kappa), axis=1).astype(float)
        self.deg_vec = np.array(self.deg_vec, dtype=float)
        # guard against divide-by-zero
        self.deg_vec[self.deg_vec == 0] = 1.0


@dataclass
class Params:
    dt: float = 0.1
    gamma: float = 1.0
    scheme: str = "explicit"
    deg_norm: bool = False


# -------------------------------
# Linearization & Jacobians
# -------------------------------

def M_coupling_linear(theta: Optional[np.ndarray],
                      K: float, spec: GraphSpec) -> np.ndarray:
    """Linear coupling for small perturbations around theta (default 0)."""
    n = spec.n
    if theta is None:
        theta = np.zeros(n, dtype=float)
    C = np.zeros((n,n), dtype=float)
    for i in range(n):
        row_sum = 0.0
        for j in range(n):
            if i == j:
                continue
            c = (spec.kappa[i,j] / spec.deg_vec[i]) * np.cos(theta[j] - theta[i] - spec.alphas[i,j])
            C[i,j] = K * c
            row_sum += K * c
        C[i,i] = -row_sum
    return C


def coupling_cos_terms(theta: Optional[np.ndarray], spec: GraphSpec) -> np.ndarray:
    """Return the per-edge cosine linearization terms (WITHOUT the global K factor).

    For i!=j:
        term_ij = (kappa_ij/deg_i) * cos(theta_j - theta_i - alpha_ij)

    This matches the implementation used inside M_coupling_linear().
    The diagonal is set to 0 (diagonal terms are negative row-sums in M).
    """
    n = spec.n
    if theta is None:
        theta = np.zeros(n, dtype=float)
    T = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            T[i, j] = (spec.kappa[i, j] / spec.deg_vec[i]) * np.cos(theta[j] - theta[i] - spec.alphas[i, j])
    return T


def jacobian_factor_stats(theta: Optional[np.ndarray], spec: GraphSpec,
                          eps: float = 1e-15,
                          quantiles: Tuple[float, float, float] = (0.05, 0.50, 0.95)
                          ) -> Dict[str, float]:
    """Compute portable per-case statistics for the Jacobian cosine terms.

    Intended for L1 β-pathway diagnostics (network amplification tests).
    Statistics are computed over directed off-diagonal edges (i!=j) with nonzero kappa.

    Returns a flat dict suitable for CSV/JSON logging.
    """
    T = coupling_cos_terms(theta, spec)

    vals: List[float] = []
    n = spec.n
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            if spec.kappa[i, j] == 0:
                continue
            vals.append(T[i, j])

    if len(vals) == 0:
        return {
            "n_terms": 0,
            "mean_log_abs": float("nan"),
            "var_log_abs": float("nan"),
            "mean_abs": float("nan"),
            "p05_abs": float("nan"),
            "p50_abs": float("nan"),
            "p95_abs": float("nan"),
            "mean_raw": float("nan"),
            "var_raw": float("nan"),
        }

    v = np.asarray(vals, dtype=float)
    abs_v = np.abs(v)
    log_abs = np.log(np.maximum(abs_v, eps))
    p = np.quantile(abs_v, quantiles)

    return {
        "n_terms": int(v.size),
        "mean_log_abs": float(np.mean(log_abs)),
        "var_log_abs": float(np.var(log_abs)),
        "mean_abs": float(np.mean(abs_v)),
        f"p{int(quantiles[0]*100):02d}_abs": float(p[0]),
        f"p{int(quantiles[1]*100):02d}_abs": float(p[1]),
        f"p{int(quantiles[2]*100):02d}_abs": float(p[2]),
        "mean_raw": float(np.mean(v)),
        "var_raw": float(np.var(v)),
    }


def jacobian_inertial(K: float, p: Params, spec: GraphSpec,
                      theta: Optional[np.ndarray] = None) -> np.ndarray:
    """2n×2n Jacobian of the inertial map around theta (default 0)."""
    n = spec.n
    dt, gamma = p.dt, p.gamma
    A = 1.0 - gamma*dt
    M = M_coupling_linear(theta, K, spec)
    I = np.eye(n)

    if p.scheme.lower() in ("explicit", "e", "exp"):
        # theta_{t+1} = theta_t + dt * v_t
        # v_{t+1}     = A v_t + dt M theta_t
        return np.block([[I,       dt*I],
                         [dt*M,    A*I ]])
    elif p.scheme.lower() in ("ec", "euler_cromer", "euler-cromer"):
        # v_{t+1}     = A v_t + dt M theta_t
        # theta_{t+1} = theta_t + dt v_{t+1}
        return np.block([[I + (dt*dt)*M, dt*A*I],
                         [dt*M,          A*I   ]])
    else:
        raise ValueError(f"Unknown scheme: {p.scheme}")


# -------------------------------
# Gauge-free eigen analysis
# -------------------------------

def _leading_eigs_reduced(J: np.ndarray, n: int) -> np.ndarray:
    """Eigenvalues of J on the gauge-free subspace (drop the
    uniform theta-shift mode). Implemented by projecting out the all-ones
    direction in the theta block. For K4 this is sufficient.
    """
    # crude projection: remove theta_0 as gauge (works for our k4 uses)
    idx = list(range(2*n))
    idx.remove(0)
    Jr = J[np.ix_(idx, idx)]
    w = np.linalg.eigvals(Jr)
    # sort by magnitude
    w = w[np.argsort(-np.abs(w))]
    return w


def leading_modes(K: float, p: Params, spec: GraphSpec,
                  theta: Optional[np.ndarray] = None, topk: int = 4) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return leading eigenvalues (complex), their magnitudes, and angles."""
    J = jacobian_inertial(K, p, spec, theta=theta)
    w = _leading_eigs_reduced(J, spec.n)
    w = w[:topk]
    rho = np.abs(w)
    ang = np.angle(w)
    return w, rho, ang


# -------------------------------
# Inertial K4 step map (legacy/utility)
# -------------------------------

def step_inertial(theta: np.ndarray, v: np.ndarray, K: float, p: Params, spec: GraphSpec) -> Tuple[np.ndarray, np.ndarray]:
    """One step of inertial map:
       theta+ = theta + dt v
       v+     = (1 - gamma dt) v + dt K * sum_j kappa_ij sin(theta_j - theta_i - alpha_ij) / deg_i
    """
    dt, gamma = p.dt, p.gamma
    A = 1.0 - gamma*dt

    n = spec.n
    f = np.zeros(n, dtype=float)
    for i in range(n):
        s = 0.0
        for j in range(n):
            if i == j:
                continue
            s += spec.kappa[i,j] * np.sin(theta[j] - theta[i] - spec.alphas[i,j])
        f[i] = s / spec.deg_vec[i]

    theta2 = theta + dt*v
    v2 = A*v + (dt*K)*f
    return theta2, v2


# -------------------------------
# Lyapunov via QR (map)
# -------------------------------

def lyap_qr(K: float, p: Params, spec: GraphSpec,
            T: int = 8000, burn: int = 2000,
            seed: int = 0,
            theta0: Optional[np.ndarray] = None,
            v0: Optional[np.ndarray] = None,
            qr_every: int = 5,
            gauge_free: bool = True) -> Dict[str, float]:
    """Compute maximal Lyapunov exponent for the map using QR method.

    gauge_free=True: works permanently in the (2n-1)-dimensional subspace
    obtained by dropping the uniform theta-shift mode (theta_0 row/col).
    Q is initialised and kept in this reduced space every iteration —
    avoiding the progressive dimension-shrink bug that arises when
    Q[1:,1:] is sliced repeatedly.

    Returns dict with lmax and basic diagnostics.
    """
    rng = np.random.default_rng(seed)
    n   = spec.n
    dim = 2 * n

    theta = rng.uniform(-np.pi, np.pi, n) if theta0 is None \
            else np.array(theta0, dtype=float)
    v     = rng.normal(0.0, 0.1, n) if v0 is None \
            else np.array(v0, dtype=float)

    # gauge-free index list (remove theta_0 = index 0)
    if gauge_free:
        gf_idx = list(range(1, dim))   # indices [1 .. 2n-1]
        dim_eff = dim - 1
    else:
        gf_idx  = list(range(dim))
        dim_eff = dim

    # Q lives permanently in dim_eff × dim_eff space
    Q      = np.eye(dim_eff)
    le_sum = 0.0
    count  = 0

    # burn-in (trajectory only)
    for _ in range(burn):
        theta, v = step_inertial(theta, v, K, p, spec)

    # main QR loop
    for t in range(T):
        theta, v = step_inertial(theta, v, K, p, spec)

        # build full Jacobian then project to dim_eff subspace
        J_full = jacobian_inertial(K, p, spec, theta=theta)
        J      = J_full[np.ix_(gf_idx, gf_idx)]   # always (dim_eff × dim_eff)

        Q = J @ Q   # Q stays dim_eff × dim_eff throughout

        if (t + 1) % qr_every == 0:
            Q, R   = np.linalg.qr(Q)
            diag   = np.abs(np.diag(R))
            diag[diag == 0] = 1e-300
            le_sum += np.sum(np.log(diag))
            count  += 1

    lmax = le_sum / (count * qr_every * p.dt)
    return {
        "lmax":    float(lmax),
        "count":   int(count),
        "qr_every": int(qr_every),
        "T":       int(T),
        "burn":    int(burn),
        "seed":    int(seed),
    }


# -------------------------------
# Plot helpers (used by analysis scripts)
# -------------------------------

def ensure_dir(d: str) -> None:
    os.makedirs(d, exist_ok=True)

def save_json(obj: dict, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)

def plot_spectrum(K: np.ndarray, rho: np.ndarray, ang: np.ndarray, lbl: List[str],
                  outdir: str, tag: str) -> None:
    plt.figure(figsize=(6,4))
    for i in range(rho.shape[1]):
        plt.plot(K, rho[:,i], lw=1.0, label=lbl[i] if i < len(lbl) else f"mode{i}")
    plt.axhline(1.0, color="k", lw=0.8, ls="--")
    plt.xlabel("K"); plt.ylabel("|lambda|")
    plt.title("Leading Floquet magnitudes")
    plt.legend(loc="best", fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"{tag}_rho.png"), dpi=150)
    plt.close()

    plt.figure(figsize=(6,4))
    for i in range(ang.shape[1]):
        plt.plot(K, ang[:,i], lw=1.0, label=lbl[i] if i < len(lbl) else f"mode{i}")
    plt.xlabel("K"); plt.ylabel("arg(lambda)")
    plt.title("Leading Floquet angles")
    plt.legend(loc="best", fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"{tag}_ang.png"), dpi=150)
    plt.close()

def plot_grid_overview(K: np.ndarray, rho: np.ndarray, ang: np.ndarray, lbl: List[str],
                       outdir: str, tag: str) -> None:
    plt.figure(figsize=(6,4))
    plt.plot(K, rho, lw=1.0, label="|lambda|max")
    plt.axhline(1.0, color="k", lw=0.8, ls="--")
    plt.xlabel("K"); plt.ylabel("spectral radius")
    plt.title("Grid overview (leading mode)")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"{tag}_grid_overview.png"), dpi=150)
    plt.close()

# ============================================================
# RESTORED FUNCTIONS — merged from prior version
# DSN references throughout match RTG_MASTER_DSN_v1.0
# ============================================================


# -----------------------------------------------
# Topology builder
# -----------------------------------------------

def build_ringdiag_spec(n: int, phi: float,
                        eps_asym: float = 0.25,
                        deg_norm: bool = False) -> GraphSpec:
    """Build directed ring+diagonal GraphSpec for DSN §1 substrate.

    Coupling convention (DSN §1):
        theta_dot_i = omega_i + K * sum_j kappa_ij
                      * [sin(theta_j-theta_i) + eps_asym*sin(theta_j-theta_i+phi)]
                      / deg_i

    The asymmetric phase-shifted term is encoded via a second directed
    edge with weight eps_asym and alpha_ij = -phi (so sin(Δθ - alpha) =
    sin(Δθ + phi)).

    For an n-node ring with skip-1 diagonals every node i connects to:
        i+1 (ring-fwd), i-1 (ring-bwd), i+2 (diag-fwd), i-2 (diag-bwd).
    Each forward edge gets an asymmetric companion.
    """
    # Build adjacency: ring forward/backward + diagonal forward/backward
    adj = set()
    for i in range(n):
        adj.add((i, (i+1) % n))
        adj.add((i, (i-1) % n))
        if n > 4:
            adj.add((i, (i+2) % n))
            adj.add((i, (i-2) % n))

    kappa  = np.zeros((n, n), dtype=float)
    alphas = np.zeros((n, n), dtype=float)

    for (i, j) in adj:
        if i == j:
            continue
        kappa[i, j]  += 1.0
        # asymmetric frustrated companion on same edge
        kappa[i, j]  += eps_asym
        alphas[i, j]  = -phi   # sin(Δθ - (-phi)) = sin(Δθ + phi)

    spec = GraphSpec(n=n, directed=True, deg_norm=deg_norm,
                     kappa=kappa, alphas=alphas)
    # store metadata for downstream use
    spec._phi      = phi       # type: ignore[attr-defined]
    spec._eps_asym = eps_asym  # type: ignore[attr-defined]
    return spec


# -----------------------------------------------
# Fixed-point finder
# -----------------------------------------------

def find_fixed_point(omega: np.ndarray, K: float, spec: GraphSpec,
                     theta0: Optional[np.ndarray] = None,
                     max_iter: int = 3000,
                     tol: float = 1e-9,
                     lr: float = 0.03) -> Tuple[np.ndarray, bool]:
    """Find synchronised fixed point via damped gradient descent.

    Minimises max|omega_i + K*F_i(theta)| where F_i is the coupling force.
    Returns (theta_fp, converged).
    """
    n = spec.n
    rng = np.random.default_rng(17)
    theta = rng.uniform(-np.pi, np.pi, n) if theta0 is None \
            else np.array(theta0, dtype=float).copy()

    def _residual(th: np.ndarray) -> np.ndarray:
        f = np.zeros(n, dtype=float)
        for i in range(n):
            s = sum(spec.kappa[i, j] * np.sin(th[j] - th[i] - spec.alphas[i, j])
                    for j in range(n) if j != i)
            f[i] = s / spec.deg_vec[i]
        return omega + K * f

    for _ in range(max_iter):
        res = _residual(theta)
        if np.max(np.abs(res)) < tol:
            return theta, True
        # diagonal of coupling Jacobian for step scaling
        M = M_coupling_linear(theta, K, spec)
        diag = np.diag(M).copy()          # .copy() avoids read-only view
        diag[np.abs(diag) < 1e-12] = -1.0
        theta -= lr * res / np.abs(diag)

    return theta, np.max(np.abs(_residual(theta))) < tol * 1e3


# -----------------------------------------------
# Spectrum sweep
# -----------------------------------------------

def scan_spectrum(K_arr: np.ndarray, p: Params, spec: GraphSpec,
                  omega: Optional[np.ndarray] = None,
                  topk: int = 4,
                  find_fp: bool = True,
                  fp_tol: float = 1e-8) -> Dict[str, np.ndarray]:
    """Sweep K_arr and collect leading Floquet eigenvalues.

    Returns dict:
        'K'        (nK,)
        'rho'      (nK, topk)   magnitudes
        'ang'      (nK, topk)   angles
        'fp_ok'    (nK,) bool
        'theta_fp' (nK, n)
    """
    nK, n = len(K_arr), spec.n
    rho_arr      = np.full((nK, topk), np.nan)
    ang_arr      = np.full((nK, topk), np.nan)
    fp_ok        = np.zeros(nK, dtype=bool)
    theta_fp_arr = np.zeros((nK, n), dtype=float)

    if omega is None:
        omega = np.zeros(n, dtype=float)

    theta_prev = None
    for ki, K in enumerate(K_arr):
        if find_fp:
            th_fp, ok = find_fixed_point(omega, K, spec, theta0=theta_prev, tol=fp_tol)
            fp_ok[ki]        = ok
            theta_use        = th_fp if ok else np.zeros(n)
            theta_prev       = th_fp
        else:
            theta_use = np.zeros(n)

        theta_fp_arr[ki] = theta_use
        _, rho, ang = leading_modes(K, p, spec, theta=theta_use, topk=topk)
        rho_arr[ki, :len(rho)] = rho
        ang_arr[ki, :len(ang)] = ang

    return {"K": K_arr, "rho": rho_arr, "ang": ang_arr,
            "fp_ok": fp_ok, "theta_fp": theta_fp_arr}


# -----------------------------------------------
# NS bifurcation search
# -----------------------------------------------

_SPARK_NAN = {
    "K_spark": float("nan"), "lam1_rho": float("nan"),
    "lam1_ang": float("nan"), "lam2_rho": float("nan"),
    "lam2_ang": float("nan"), "spectral_gap": float("nan"),
    "ang_separation": float("nan"), "fp_ok": False,
}


def find_k_spark(p: Params, spec: GraphSpec,
                 omega: Optional[np.ndarray] = None,
                 K_lo: float = 0.01, K_hi: float = 10.0,
                 tol: float = 1e-5, max_iter: int = 60,
                 fp_tol: float = 1e-8) -> Dict[str, float]:
    """Binary search for K_spark (|lambda_1| first crosses 1).

    Always returns a complete dict (NaN-filled on failure).

    Keys (DSN O_INTER_MODAL_GAP_EXPORT):
        K_spark, lam1_rho, lam1_ang, lam2_rho, lam2_ang,
        spectral_gap, ang_separation, fp_ok
    """
    n = spec.n
    if omega is None:
        omega = np.zeros(n, dtype=float)

    def _eval(K: float) -> Tuple[float, float, float, float, bool]:
        th, ok = find_fixed_point(omega, K, spec, tol=fp_tol)
        theta_use = th if ok else np.zeros(n)
        _, rho, ang = leading_modes(K, p, spec, theta=theta_use, topk=4)
        r1 = float(rho[0]) if len(rho) > 0 else 0.0
        a1 = float(ang[0]) if len(ang) > 0 else 0.0
        r2 = float(rho[1]) if len(rho) > 1 else 0.0
        a2 = float(ang[1]) if len(ang) > 1 else 0.0
        return r1, a1, r2, a2, ok

    r_lo, *_ = _eval(K_lo)
    r_hi, *_ = _eval(K_hi)

    # extend bracket automatically if needed
    if r_lo >= 1.0:
        return {**_SPARK_NAN, "error": "rho1>=1 at K_lo; lower K_lo"}
    if r_hi < 1.0:
        # try extending K_hi
        for _ in range(8):
            K_hi *= 2.0
            r_hi, *_ = _eval(K_hi)
            if r_hi >= 1.0:
                break
        if r_hi < 1.0:
            return {**_SPARK_NAN, "error": "rho1<1 even at K_hi*256; increase K_hi"}

    for _ in range(max_iter):
        K_mid = 0.5 * (K_lo + K_hi)
        r_mid, *_ = _eval(K_mid)
        if r_mid < 1.0:
            K_lo = K_mid
        else:
            K_hi = K_mid
        if K_hi - K_lo < tol:
            break

    K_spark = 0.5 * (K_lo + K_hi)
    r1, a1, r2, a2, ok = _eval(K_spark)

    return {
        "K_spark":       float(K_spark),
        "lam1_rho":      r1,
        "lam1_ang":      a1,
        "lam2_rho":      r2,
        "lam2_ang":      a2,
        "spectral_gap":  float(1.0 - r2),
        "ang_separation": float(abs(a1 - a2)),
        "fp_ok":         bool(ok),
    }


# -----------------------------------------------
# Threshold-free lam2 extrapolation
# -----------------------------------------------

def k_lam2_hit_extrapolated(scan: Dict[str, np.ndarray],
                             K_spark: float) -> float:
    """Linear extrapolation of K where |lam2|=1 (threshold-free).

    DSN: V_B1_MODE_COMPETITION_PRIMARY — Λ_comp = K_fracture − K_lam2_hit_pred.
    Negative Λ_comp → competitor crossed |lam|=1 before observed fracture → B1.
    """
    K_arr = scan["K"]
    rho   = scan["rho"]
    mask  = (K_arr > K_spark) & np.isfinite(rho[:, 1])
    if mask.sum() < 3:
        return float("nan")
    Kf = K_arr[mask]
    r2 = rho[mask, 1]
    coeffs = np.polyfit(Kf, r2, 1)
    if abs(coeffs[0]) < 1e-14:
        return float("nan")
    return float((1.0 - coeffs[1]) / coeffs[0])


# -----------------------------------------------
# Fracture detection
# -----------------------------------------------

def find_k_fracture(p: Params, spec: GraphSpec,
                    omega: Optional[np.ndarray] = None,
                    K_spark: float = 1.0,
                    K_hi: float = 20.0,
                    rho_threshold: float = 1.5,
                    comp_threshold: float = 0.995,
                    n_steps: int = 500,
                    fp_tol: float = 1e-8) -> Dict[str, float]:
    """Scan K from K_spark to K_hi and detect NS circle fracture.

    Fracture criteria (first triggered wins):
        1. comp_ratio = |lam2|/|lam1| > comp_threshold (mode competition B1)
        2. |lam1| > rho_threshold (amplitude explosion)

    Also tracks K_lam2_hit (first K where |lam2| >= 1, threshold-free anchor).

    Returns complete dict with NaN-fills on failure.
    """
    n = spec.n
    if omega is None:
        omega = np.zeros(n, dtype=float)

    nan_result: Dict[str, float] = {
        "K_fracture": float("nan"), "comp_ratio": float("nan"),
        "lam1_rho": float("nan"),   "lam2_rho": float("nan"),
        "lam1_ang": float("nan"),   "lam2_ang": float("nan"),
        "K_lam2_hit": float("nan"), "method": "none",
    }

    K_arr       = np.linspace(K_spark, K_hi, n_steps)
    K_lam2_hit  = float("nan")
    K_fracture  = float("nan")
    frac_result = dict(nan_result)

    theta_prev  = None
    prev_r2     = 0.0
    lam2_seen   = False

    for K in K_arr:
        th, ok    = find_fixed_point(omega, K, spec, theta0=theta_prev, tol=fp_tol)
        theta_use = th if ok else np.zeros(n)
        theta_prev = th
        _, rho, ang = leading_modes(K, p, spec, theta=theta_use, topk=4)

        r1 = float(rho[0]) if len(rho) > 0 else 1.0
        r2 = float(rho[1]) if len(rho) > 1 else 0.0
        a1 = float(ang[0]) if len(ang) > 0 else 0.0
        a2 = float(ang[1]) if len(ang) > 1 else 0.0

        # track first lam2 crossing
        if not lam2_seen and prev_r2 < 1.0 <= r2:
            K_lam2_hit = float(K)
            lam2_seen  = True
        prev_r2 = r2

        # fracture detection (record first trigger only)
        if math.isnan(K_fracture):
            comp = r2 / r1 if r1 > 1e-12 else 0.0
            if comp > comp_threshold or r1 > rho_threshold:
                K_fracture = float(K)
                frac_result.update({
                    "K_fracture": K_fracture,
                    "comp_ratio": comp,
                    "lam1_rho":   r1, "lam2_rho": r2,
                    "lam1_ang":   a1, "lam2_ang": a2,
                    "method": "comp_ratio" if comp > comp_threshold else "amplitude",
                })

    # fallback: use lam2 crossing as fracture proxy
    if math.isnan(K_fracture) and not math.isnan(K_lam2_hit):
        frac_result["K_fracture"] = K_lam2_hit
        frac_result["method"]     = "lam2_crossing_fallback"

    frac_result["K_lam2_hit"] = K_lam2_hit
    return frac_result


# -----------------------------------------------
# Resonance gap
# -----------------------------------------------

def compute_res_gap(lam1_ang: float, lam2_ang: float,
                    max_p: int = 10, max_q: int = 10) -> Dict[str, float]:
    """Distance from lam1_ang to nearest p:q rational rotation.

    DSN: V_C_PROTECTIVE_MODULATOR, H_RATIONAL_STRUCTURE_PREFERRED.

    Returns:
        single_mode_gap   — min |lam1/(2π) − p/q| * 2π  (radians)
        inter_modal_gap   — |lam1_ang − lam2_ang| (mod π)
        res_gap_p/q       — best rational approximation numerator/denominator
        dQ                — raw normalised distance (for H_RATIONAL_STRUCTURE)
    """
    norm = (lam1_ang / (2.0 * np.pi)) % 1.0
    best, best_p, best_q = float("inf"), 1, 1
    for q in range(1, max_q + 1):
        for pp in range(1, min(q, max_p) + 1):
            d = abs(norm - pp / q)
            d = min(d, 1.0 - d)
            if d < best:
                best, best_p, best_q = d, pp, q

    inter = abs(lam1_ang - lam2_ang)
    inter = inter % np.pi
    if inter > np.pi / 2:
        inter = np.pi - inter

    return {
        "single_mode_gap": float(best * 2.0 * np.pi),
        "inter_modal_gap": float(inter),
        "res_gap_p":       int(best_p),
        "res_gap_q":       int(best_q),
        "dQ":              float(best),
    }


# -----------------------------------------------
# Mode competition metrics
# -----------------------------------------------

def mode_competition_metrics(scan: Dict[str, np.ndarray],
                             K_spark: float,
                             K_fracture: float) -> Dict[str, float]:
    """B1 evidence metrics from spectrum scan.

    DSN: V_B1_MODE_COMPETITION_PRIMARY
        comp_ratio@fracture ≈ 0.97-0.99 → B1
        Lambda_comp < 0            → competitor crossed |lam|=1 before fracture
    """
    K_arr = scan["K"]
    rho   = scan["rho"]
    ang   = scan["ang"]

    def _at(K_target: float, col: int, arr: np.ndarray) -> float:
        idx = int(np.argmin(np.abs(K_arr - K_target)))
        return float(arr[idx, col]) if arr.shape[1] > col else float("nan")

    r1_f = _at(K_fracture, 0, rho)
    r2_f = _at(K_fracture, 1, rho)
    a1_f = _at(K_fracture, 0, ang)
    a2_f = _at(K_fracture, 1, ang)

    comp_ratio  = r2_f / r1_f if r1_f > 1e-12 else float("nan")
    K_lam2_pred = k_lam2_hit_extrapolated(scan, K_spark)
    Lambda_comp = K_fracture - K_lam2_pred

    idx_sp  = int(np.argmin(np.abs(K_arr - K_spark)))
    gap_sp  = float(1.0 - rho[idx_sp, 1]) if rho.shape[1] > 1 else float("nan")

    return {
        "comp_ratio_at_fracture": comp_ratio,
        "lam1_rho_fracture":      r1_f,
        "lam2_rho_fracture":      r2_f,
        "lam1_ang_fracture":      a1_f,
        "lam2_ang_fracture":      a2_f,
        "K_lam2_hit_pred":        K_lam2_pred,
        "Lambda_comp":            Lambda_comp,
        "spectral_gap_at_spark":  gap_sp,
        "b1_supported":           bool(Lambda_comp < 0),
    }


# -----------------------------------------------
# NS circle amplitude
# -----------------------------------------------

def ns_circle_radius(theta0: np.ndarray, v0: np.ndarray,
                     K: float, p: Params, spec: GraphSpec,
                     n_burn: int = 600, n_measure: int = 600) -> float:
    """RMS velocity amplitude on the NS circle (proxy for circle radius H).

    DSN: measure_window() → W_obs = ΔH * gamma²/K*
    """
    theta, v = np.array(theta0), np.array(v0)
    for _ in range(n_burn):
        theta, v = step_inertial(theta, v, K, p, spec)
    acc = 0.0
    for _ in range(n_measure):
        theta, v = step_inertial(theta, v, K, p, spec)
        acc += float(np.sqrt(np.mean(v**2)))
    return acc / n_measure


def measure_window(p: Params, spec: GraphSpec,
                   omega: Optional[np.ndarray] = None,
                   K_spark: float = 1.0,
                   K_fracture: float = 5.0,
                   n_burn: int = 800, n_measure: int = 800,
                   seed: int = 0) -> Dict[str, float]:
    """Measure ΔH_obs and W_obs = ΔH_obs * gamma²/K_spark.

    DSN: THM_SPECTRAL_WINDOW, §3.5.
    """
    n = spec.n
    if omega is None:
        omega = np.zeros(n, dtype=float)
    rng = np.random.default_rng(seed)

    def _H(K: float) -> float:
        th_fp, _ = find_fixed_point(omega, K, spec)
        v0 = rng.normal(0.0, 0.05, n)
        return ns_circle_radius(th_fp, v0, K, p, spec,
                                n_burn=n_burn, n_measure=n_measure)

    K_lo = K_spark   * 1.02   # just above spark
    K_hi = K_fracture * 0.98  # just below fracture
    H_lo = _H(K_lo)
    H_hi = _H(K_hi)
    dH   = H_hi - H_lo
    W    = dH * p.gamma**2 / K_spark

    return {
        "W_obs": float(W), "delta_H": float(dH),
        "H_spark": float(H_lo), "H_fracture": float(H_hi),
        "K_spark": float(K_spark), "K_fracture": float(K_fracture),
        "K_lo_measured": float(K_lo), "K_hi_measured": float(K_hi),
    }


# -----------------------------------------------
# Full per-case diagnosis export
# -----------------------------------------------

def export_diagnosis_point(phi: float, dt: float, gamma: float,
                           p: Params, spec: GraphSpec,
                           omega: Optional[np.ndarray] = None,
                           K_lo: float = 0.01,
                           K_hi_spark: float = 15.0,
                           K_hi_frac: float = 30.0,
                           n_scan: int = 300,
                           fp_tol: float = 1e-8) -> Dict:
    """Full per-case diagnostic for spectral theorem pipeline.

    Computes all L1 DSN quantities in one call:
      K_spark, lam1_ang, lam2_ang, spectral_gap  (O_INTER_MODAL_GAP_EXPORT)
      K_fracture, comp_ratio, Lambda_comp         (V_B1_MODE_COMPETITION_PRIMARY)
      K_lam2_hit_pred                             (V_B1, threshold-free)
      res_gap, inter_modal_gap, dQ               (V_C_PROTECTIVE_MODULATOR)
      Jacobian cos-term stats at K_spark          (O_BETA_DERIVATION_JACOBIAN)
      R_K = (K_frac-K_spark)/K_spark             (V_RK_THRESHOLD_ACTIVATION)
      X   = K_spark/gamma²                       (THM_SPECTRAL_WINDOW X_ref)

    Returns flat dict suitable for diagnosis_points.csv row.
    """
    n = spec.n
    if omega is None:
        omega = np.zeros(n, dtype=float)

    out: Dict = {"phi": phi, "dt": dt, "gamma": gamma, "n_nodes": n}

    # ---- K_spark ----
    spark = find_k_spark(p, spec, omega=omega,
                         K_lo=K_lo, K_hi=K_hi_spark, fp_tol=fp_tol)
    out.update({f"spark_{k}": v for k, v in spark.items()})
    K_spark = spark.get("K_spark", float("nan"))

    if math.isnan(K_spark):
        out["error"] = "K_spark not found"
        return out

    # ---- full K scan ----
    K_scan = np.linspace(max(K_lo, K_spark * 0.95), K_hi_frac, n_scan)
    scan   = scan_spectrum(K_scan, p, spec, omega=omega, topk=4, fp_tol=fp_tol)

    # ---- K_fracture ----
    frac = find_k_fracture(p, spec, omega=omega,
                           K_spark=K_spark, K_hi=K_hi_frac, fp_tol=fp_tol)
    out.update({f"frac_{k}": v for k, v in frac.items()})
    K_fracture = frac.get("K_fracture", float("nan"))

    if not math.isnan(K_fracture):
        mc = mode_competition_metrics(scan, K_spark, K_fracture)
        out.update({f"mc_{k}": v for k, v in mc.items()})
        out["R_K"] = (K_fracture - K_spark) / K_spark
        out["X"]   = K_spark / gamma**2 if gamma != 0 else float("nan")

    # ---- resonance gap at K_spark ----
    rg = compute_res_gap(spark.get("lam1_ang", 0.0),
                         spark.get("lam2_ang", 0.0))
    out.update({f"rg_{k}": v for k, v in rg.items()})

    # ---- Jacobian cos-term stats at K_spark (β-pathway) ----
    th_fp, _ = find_fixed_point(omega, K_spark, spec, tol=fp_tol)
    jac = jacobian_factor_stats(th_fp, spec)
    out.update({f"jac_{k}": v for k, v in jac.items()})

    return out


# -----------------------------------------------
# Plot helper — mode competition
# -----------------------------------------------

def plot_mode_competition(scan: Dict[str, np.ndarray],
                          K_spark: float, K_fracture: float,
                          outdir: str, tag: str) -> None:
    """Plot |lam1| and |lam2| vs K with K_spark and K_fracture marked.

    DSN: V_B1_MODE_COMPETITION_PRIMARY.
    """
    K_arr = scan["K"]
    rho   = scan["rho"]

    plt.figure(figsize=(7, 4))
    plt.plot(K_arr, rho[:, 0], lw=1.2, label="|lambda_1| primary")
    if rho.shape[1] > 1:
        plt.plot(K_arr, rho[:, 1], lw=1.2, ls="--", label="|lambda_2| competitor")
    plt.axhline(1.0, color="k", lw=0.8, ls=":", alpha=0.6)
    plt.axvline(K_spark,   color="b", lw=0.9, ls=":", alpha=0.7,
                label=f"K_spark={K_spark:.3f}")
    plt.axvline(K_fracture, color="r", lw=0.9, ls=":", alpha=0.7,
                label=f"K_frac={K_fracture:.3f}")
    plt.xlabel("K"); plt.ylabel("|lambda|")
    plt.title("Mode competition: primary vs competitor")
    plt.legend(loc="best", fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"{tag}_mode_competition.png"), dpi=150)
    plt.close()