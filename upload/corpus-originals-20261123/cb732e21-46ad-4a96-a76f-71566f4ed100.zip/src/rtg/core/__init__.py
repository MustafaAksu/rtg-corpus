"""
rtg.core: shared utilities for pipelines and library modules.
"""
