"""
file: src/rtg/core/io.py
purpose: Standard IO utilities for RTG toolkit pipelines.
notes:
  - YAML is for human configs (input).
  - JSON is for machine results (output).
  - ASCII-only keys in YAML/JSON for cross-platform stability.
"""

from __future__ import annotations

import json
import os
import sys
import time
import subprocess
from dataclasses import dataclass
from typing import Any, Dict, Optional

import yaml


# -----------------------------
# Basic helpers
# -----------------------------

def utc_timestamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise ValueError(f"YAML config must be a mapping/dict: {path}")
    return data


def save_yaml(path: str, data: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False)


def save_json(path: str, data: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=False)


def get_git_commit() -> Optional[str]:
    try:
        out = subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL)
        return out.decode("utf-8").strip()
    except Exception:
        return None


def make_run_id(prefix: str = "run") -> str:
    # ASCII-only, filesystem safe
    return f"{prefix}_{time.strftime('%Y%m%d_%H%M%S', time.gmtime())}"


# -----------------------------
# Results schema
# -----------------------------

@dataclass(frozen=True)
class ResultSchema:
    schema_version: str = "1.0"


def write_run_artifacts(
    *,
    out_dir: str,
    script_path: str,
    run_id: str,
    seed: int,
    config_path: Optional[str],
    config_data: Optional[Dict[str, Any]],
    params: Dict[str, Any],
    metrics: Dict[str, Any],
    artifacts: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Writes:
      - out_dir/config_used.yaml (if config_data provided)
      - out_dir/config_used.json (if config_data provided)
      - out_dir/results.json (always)
      - out_dir/run.log (append-friendly)

    Returns:
      path to results.json
    """
    ensure_dir(out_dir)
    git_commit = get_git_commit()

    if artifacts is None:
        artifacts = {"figures": [], "files": []}

    # Save config_used
    if config_data is not None:
        save_yaml(os.path.join(out_dir, "config_used.yaml"), config_data)
        save_json(os.path.join(out_dir, "config_used.json"), config_data)

    payload: Dict[str, Any] = {
        "schema_version": ResultSchema().schema_version,
        "run_id": run_id,
        "script": script_path,
        "timestamp_utc": utc_timestamp(),
        "git_commit": git_commit,
        "seed": int(seed),
        "config_path": config_path,
        "params": params,
        "metrics": metrics,
        "artifacts": artifacts,
    }

    results_path = os.path.join(out_dir, "results.json")
    save_json(results_path, payload)

    # Log summary
    log_path = os.path.join(out_dir, "run.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write("=" * 72 + "\n")
        f.write(f"timestamp_utc: {payload['timestamp_utc']}\n")
        f.write(f"run_id: {run_id}\n")
        f.write(f"script: {script_path}\n")
        f.write(f"git_commit: {git_commit}\n")
        f.write(f"seed: {seed}\n")
        if config_path:
            f.write(f"config_path: {config_path}\n")
        f.write(f"results_json: {results_path}\n")
        f.write("=" * 72 + "\n")

    return results_path


# -----------------------------
# CLI standard args helper
# -----------------------------

def add_standard_args(ap) -> None:
    ap.add_argument("--config", type=str, required=True, help="YAML config file")
    ap.add_argument("--out", type=str, required=True, help="Output directory")
    ap.add_argument("--seed", type=int, default=0, help="RNG seed (default: 0)")
    ap.add_argument("--run-id", type=str, default=None, help="Run ID (default: timestamp)")
    ap.add_argument("--no-plots", action="store_true", help="Disable plot generation")
