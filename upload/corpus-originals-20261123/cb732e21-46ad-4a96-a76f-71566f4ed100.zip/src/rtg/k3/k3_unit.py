"""
file: src/rtg/k3/k3_unit.py
purpose: K3 (triangle) curvature unit: canonical baselines, targets, and helpers.

Conventions:
- F is a FULL face rotation angle (radians).
- "half-angle energy" refers to half-angle edge variables a_e, with U_e = exp_su2(2*a_vec).
- "full-angle energy" uses full angle vectors (2*a), which is 4x the half-angle energy.

For an isolated triangle with total face flux/angle F, minimal equal-split solution:
  a_e = F/6 on each of 3 edges (half-angle scalar)
  C_half = 3*(F/6)^2 = F^2/12
  C_full = 4*C_half = F^2/3

Holonomy target:
  Tr(H)/2 = cos(F/2)
"""

from __future__ import annotations

import numpy as np


def k3_energy_iso_half(F: float) -> float:
    """Isolated triangle minimal energy in half-angle variables: F^2/12."""
    F = float(F)
    return (F * F) / 12.0


def k3_energy_iso_full(F: float) -> float:
    """Isolated triangle minimal energy in full-angle convention: F^2/3."""
    F = float(F)
    return (F * F) / 3.0


def k3_target_tr_half(F: float) -> float:
    """Target half-trace: cos(F/2)."""
    return float(np.cos(0.5 * float(F)))


def k3_gap_from_tr_half(tr_half: float, F: float) -> float:
    """Gap metric: |tr_half - cos(F/2)|."""
    return float(abs(float(tr_half) - k3_target_tr_half(F)))


def k3_equal_split_half_angles(F: float) -> np.ndarray:
    """
    Return half-angle scalars a_e for equal split on 3 edges.
    a_e = F/6 for each edge (since sum of full angles 2a_e = F -> sum a_e = F/2).
    """
    a = float(F) / 6.0
    return np.array([a, a, a], dtype=float)
