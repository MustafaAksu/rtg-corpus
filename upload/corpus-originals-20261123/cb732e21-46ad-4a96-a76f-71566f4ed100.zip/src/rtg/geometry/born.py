"""
file: src/rtg/geometry/born.py
purpose: Born statistics as Jacobian pushforward via inverse-CDF projection.

core idea:
  - internal variable z has invariant density pi_density(z) on [0,1]
  - define internal CDF H(z) = integral_0^z pi_density(u) du
  - define target CDF F(x) = integral_{x_min}^x psi_sq(x') dx' / integral_{x_min}^{x_max} psi_sq
  - then G(z) = F^{-1}(H(z)) ensures pushforward density rho(x) = psi_sq(x)

notes:
  - ASCII-only identifiers
  - This module provides generic helpers; callers supply psi_sq(x) and pi_density(z)
"""

from __future__ import annotations

from typing import Callable, Tuple
import numpy as np


def normalize_density(x: np.ndarray, dens: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    d = np.asarray(dens, dtype=float)
    dx = float(x[1] - x[0]) if x.size >= 2 else 1.0
    z = float(np.sum(d) * dx)
    if z <= 0.0 or not np.isfinite(z):
        raise ValueError("density normalization failed")
    return d / z


def build_cdf_from_density(x: np.ndarray, dens: np.ndarray) -> np.ndarray:
    """
    Build discrete CDF on the same grid as dens.
    Returns cdf in [0,1], monotone nondecreasing.
    """
    x = np.asarray(x, dtype=float)
    d = normalize_density(x, dens)
    dx = float(x[1] - x[0]) if x.size >= 2 else 1.0
    cdf = np.cumsum(d) * dx
    cdf[-1] = 1.0  # force exact endpoint
    return cdf


def inverse_cdf(x: np.ndarray, cdf: np.ndarray, u: np.ndarray) -> np.ndarray:
    """
    Discrete inverse CDF using searchsorted.
    x: grid for target variable
    cdf: monotone array in [0,1] same length as x
    u: values in [0,1]
    """
    x = np.asarray(x, dtype=float)
    cdf = np.asarray(cdf, dtype=float)
    u = np.asarray(u, dtype=float)
    idx = np.searchsorted(cdf, u, side="left")
    idx = np.clip(idx, 0, x.size - 1)
    return x[idx]


def map_z_to_x(
    z: np.ndarray,
    *,
    x_grid: np.ndarray,
    psi_sq_density: np.ndarray,
    pi_density_z: np.ndarray,
    z_grid: np.ndarray,
) -> np.ndarray:
    """
    Map internal z samples to x samples using G(z)=F^{-1}(H(z)).

    Inputs:
      z: samples (not necessarily uniform)
      z_grid: grid for pi_density_z
      pi_density_z: density on z_grid
      x_grid: grid for psi_sq_density
      psi_sq_density: unnormalized density on x_grid

    Returns:
      x samples
    """
    z_grid = np.asarray(z_grid, dtype=float)
    pi_density_z = normalize_density(z_grid, pi_density_z)
    H = build_cdf_from_density(z_grid, pi_density_z)

    x_grid = np.asarray(x_grid, dtype=float)
    psi_sq_density = normalize_density(x_grid, psi_sq_density)
    F = build_cdf_from_density(x_grid, psi_sq_density)

    # Convert z -> u via H(z)
    # We approximate H(z) using interpolation on z_grid
    u = np.interp(z, z_grid, H, left=0.0, right=1.0)
    x = inverse_cdf(x_grid, F, u)
    return x


def logistic_map_r4(z: np.ndarray) -> np.ndarray:
    """One step of logistic map at r=4: z -> 4 z (1-z)."""
    return 4.0 * z * (1.0 - z)


def doubling_map(z: np.ndarray) -> np.ndarray:
    """One step of doubling map: z -> (2z) mod 1."""
    return np.mod(2.0 * z, 1.0)
