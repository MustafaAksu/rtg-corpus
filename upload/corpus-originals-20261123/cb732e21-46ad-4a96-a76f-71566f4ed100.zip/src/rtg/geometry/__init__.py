"""
rtg.geometry: Jacobian pushforward / Born construction utilities.
"""
