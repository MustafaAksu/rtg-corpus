"""
file: src/rtg/k4/topology.py
purpose: K4 graph builder for inertial Jacobian scans (toolkit-native).
notes:
  - minimal subset needed by k4 NS scout runner
  - uses rtg.core.rtg_core.Params and GraphSpec dataclasses
"""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from rtg.core.rtg_core import Params, GraphSpec


@dataclass
class K4Params(Params):
    topology: str = "ringdiag"   # ringdiag | quat_sym
    w_diag: float = 0.15
    sigma2: float = 0.0
    triad_phi: float = 0.0
    near2: float = 0.05          # kept for compatibility


def build_k4_ringdiag(p: K4Params) -> GraphSpec:
    n = 4
    kappa = np.zeros((n, n), dtype=float)

    # ring 0-1-2-3-0
    for i in range(n):
        j = (i + 1) % n
        kappa[i, j] = 1.0 + (p.eps_asym if p.directed else 0.0)
        kappa[j, i] = 1.0 - (p.eps_asym if p.directed else 0.0)

    # diagonals 0<->2, 1<->3
    d = float(p.w_diag + p.sigma2)
    for (a, b) in [(0, 2), (2, 0), (1, 3), (3, 1)]:
        kappa[a, b] = d

    np.fill_diagonal(kappa, 0.0)

    alphas = np.zeros((n, n), dtype=float)
    if abs(p.triad_phi) > 0.0:
        alphas[2, 0] = float(p.triad_phi)
        alphas[3, 1] = float(p.triad_phi)

    deg_vec = np.sum(np.abs(kappa), axis=1)
    if not p.deg_norm:
        deg_vec = np.ones_like(deg_vec)

    return GraphSpec(
        n=n,
        directed=p.directed,
        eps_asym=p.eps_asym,
        F_triangle=0.0,
        kappa=kappa,
        alphas=alphas,
        deg_vec=deg_vec,
        deg_norm=p.deg_norm,
    )


def build_k4_quat_sym(p: K4Params) -> GraphSpec:
    n = 4
    kappa = np.ones((n, n), dtype=float)
    np.fill_diagonal(kappa, 0.0)

    ring_pairs = [(0, 1), (1, 2), (2, 3), (3, 0)]
    for (i, j) in ring_pairs:
        kappa[i, j] = 1.0 + (p.eps_asym if p.directed else 0.0)
        kappa[j, i] = 1.0 - (p.eps_asym if p.directed else 0.0)

    diag_w = float(p.w_diag + p.sigma2)
    for (a, b) in [(0, 2), (2, 0), (1, 3), (3, 1)]:
        kappa[a, b] = diag_w

    alphas = np.zeros((n, n), dtype=float)
    if abs(p.triad_phi) > 0.0:
        alphas[2, 0] = float(p.triad_phi)
        alphas[3, 1] = float(p.triad_phi)

    deg_vec = np.sum(np.abs(kappa), axis=1)
    if not p.deg_norm:
        deg_vec = np.ones_like(deg_vec)

    return GraphSpec(
        n=n,
        directed=p.directed,
        eps_asym=p.eps_asym,
        F_triangle=0.0,
        kappa=kappa,
        alphas=alphas,
        deg_vec=deg_vec,
        deg_norm=p.deg_norm,
    )


def build_k4_spec(p: K4Params) -> GraphSpec:
    topo = str(p.topology).lower()
    if topo == "ringdiag":
        return build_k4_ringdiag(p)
    if topo in ("quat_sym", "quat", "tetra"):
        return build_k4_quat_sym(p)
    raise ValueError(f"Unknown topology: {p.topology}")
