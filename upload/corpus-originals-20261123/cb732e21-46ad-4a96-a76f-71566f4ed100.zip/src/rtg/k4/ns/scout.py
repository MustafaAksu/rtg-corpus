"""
file: src/rtg/k4/ns/scout.py
purpose: K4 NS scout utilities (eigenpair tracking, K sweep, simple bracket/refine).
notes:
  - Uses rtg_core for Jacobian + gauge-free basis.
  - Keeps logic minimal; advanced diagnostics stay in separate modules later.
  - ASCII-only identifiers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from rtg.core.rtg_core import jacobian_inertial, gauge_free_basis_theta, block_diag


def eig_pairs(J: np.ndarray, n: int) -> List[complex]:
    """
    Return one representative per complex conjugate pair (imag >= 0) from gauge-free reduction.
    Sorted by |lambda| descending.
    """
    Qtheta = gauge_free_basis_theta(n)
    Q = block_diag(Qtheta, Qtheta)
    Jr = Q.T @ J @ Q
    w = np.linalg.eigvals(Jr)
    keep = [complex(lam) for lam in w if lam.imag >= -1e-12]
    keep.sort(key=lambda z: -abs(z))
    return keep[: (n - 1)]


def scan_k4_pairs(K_grid: np.ndarray, p, g) -> Dict[str, np.ndarray]:
    """
    For each K in grid, compute eigenpairs and return arrays:
      rhos[j,i] = |lambda_j(K_i)|
      angs[j,i] = angle(lambda_j(K_i)) in [0,pi]
    where j=0..(n-2) corresponds to (n-1) complex pairs for K4.
    """
    K_grid = np.asarray(K_grid, dtype=float)
    m = g.n - 1
    rhos = np.zeros((m, K_grid.size), dtype=float)
    angs = np.zeros((m, K_grid.size), dtype=float)

    for i, K in enumerate(K_grid):
        J = jacobian_inertial(float(K), p, g, theta=None)
        pairs = eig_pairs(J, g.n)
        for j, lam in enumerate(pairs):
            rhos[j, i] = abs(lam)
            ang = abs(np.angle(lam))
            ang = min(ang, 2.0 * np.pi - ang)
            angs[j, i] = ang

    return {"K": K_grid, "rhos": rhos, "angs": angs}


def find_pair_bracket(K: np.ndarray, rho: np.ndarray, ang: np.ndarray, ang_tol: float) -> Optional[Tuple[float, float]]:
    """
    Find K interval where rho crosses 1 with angle away from 0 and pi.
    """
    for i in range(K.size - 1):
        ok_i = (ang[i] > ang_tol) and (abs(ang[i] - np.pi) > ang_tol)
        ok_j = (ang[i + 1] > ang_tol) and (abs(ang[i + 1] - np.pi) > ang_tol)
        if ok_i and ok_j:
            if (rho[i] - 1.0) * (rho[i + 1] - 1.0) <= 0.0:
                return float(K[i]), float(K[i + 1])
    return None


def refine_pair(K_lo: float, K_hi: float, pair_idx: int, p, g, iters: int = 32) -> Tuple[float, float, float]:
    """
    Bisection refinement to |lambda| ~ 1 for selected pair.
    Returns (K_star, rho_star, ang_star).
    """
    bestK, bestr, besta = float("nan"), float("nan"), float("nan")
    for _ in range(iters):
        km = 0.5 * (K_lo + K_hi)
        J = jacobian_inertial(float(km), p, g, theta=None)
        lam = eig_pairs(J, g.n)[pair_idx]
        r = abs(lam)
        a = abs(np.angle(lam))
        a = min(a, 2.0 * np.pi - a)
        bestK, bestr, besta = km, r, a
        if r >= 1.0:
            K_hi = km
        else:
            K_lo = km
    return float(bestK), float(bestr), float(besta)
