"""
rtg.k4.ns: K4 Neimark-Sacker tools (scout, ns_fit).
"""
