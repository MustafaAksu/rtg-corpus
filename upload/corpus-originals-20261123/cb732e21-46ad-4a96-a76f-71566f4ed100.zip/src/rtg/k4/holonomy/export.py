"""
file: src/rtg/k4/holonomy/export.py
purpose: Export SU(2) edges and face loops to JSON for downstream tools (kappa3 scan).
notes:
  - outputs ASCII-only JSON keys
  - complex matrices encoded as [[[re,im],...],...] shape (2,2,2)
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np


def encode_complex_matrix(U: np.ndarray) -> list:
    U = np.asarray(U, dtype=complex)
    out = np.zeros((2, 2, 2), dtype=float)
    out[..., 0] = np.real(U)
    out[..., 1] = np.imag(U)
    return out.tolist()


def export_kappa3_input(
    out_path: str,
    *,
    U_edges: Sequence[np.ndarray],
    faces: Sequence[Sequence[Tuple[int, int]]],
    meta: Dict[str, Any] | None = None,
) -> str:
    """
    Write JSON with keys:
      - U_edges: list of encoded 2x2 complex matrices
      - faces: list of face loops, each loop is list of [edge_index, sign]
      - meta: optional metadata dict
    """
    payload: Dict[str, Any] = {
        "U_edges": [encode_complex_matrix(U) for U in U_edges],
        "faces": [[[int(e), int(s)] for (e, s) in loop] for loop in faces],
        "meta": meta or {},
    }
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return out_path
