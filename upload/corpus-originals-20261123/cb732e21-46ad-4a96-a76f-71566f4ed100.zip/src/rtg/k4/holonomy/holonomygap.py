r"""
file: src/rtg/k4/holonomy/holonomygap.py
purpose:
  - K4 incidence, analytic flux pattern, aligned + non-aligned LS lifts
  - SU(2) face holonomy and holonomy-gap diagnostics
notes:
  - Uses rtg.algebra.su2.exp_su2 (closed form; no SciPy)
  - IMPORTANT conventions:
      * F_faces are FULL face rotation angles (radians)
      * "half-angle lift" solves for edge vectors A_e such that
            sum_face A_e = (F_face/2) * n_face
        and then uses U_e = exp_su2(2 * A_e)
      * This matches trace/2 target: cos(F_face/2)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from rtg.algebra.su2 import exp_su2


EDGE_LIST: List[Tuple[int, int]] = [
    (0, 1),  # e0
    (0, 2),  # e1
    (0, 3),  # e2
    (1, 2),  # e3
    (1, 3),  # e4
    (2, 3),  # e5
]


def k4_incidence_matrix() -> np.ndarray:
    """
    Faces x edges incidence for K4, with edge order EDGE_LIST.

    Faces (with orientation):
      f0: (0,1,2)
      f1: (0,1,3)
      f2: (0,2,3)
      f3: (1,2,3)
    """
    return np.array(
        [
            [1.0, -1.0, 0.0, 1.0, 0.0, 0.0],  # f0
            [1.0, 0.0, -1.0, 0.0, 1.0, 0.0],  # f1
            [0.0, 1.0, -1.0, 0.0, 0.0, 1.0],  # f2
            [0.0, 0.0, 0.0, 1.0, -1.0, 1.0],  # f3
        ],
        dtype=float,
    )


def analytic_flux_pattern(triad_phi: float) -> np.ndarray:
    """
    Addendum pattern:
      faces 0 and 3 carry -triad_phi, faces 1 and 2 are 0.
    triad_phi is a FULL angle (radians).
    """
    return np.array([-triad_phi, 0.0, 0.0, -triad_phi], dtype=float)


def parse_na_axes(spec: str) -> List[np.ndarray]:
    """
    Parse axis pattern like 'zxxz' into 4 unit vectors.
    """
    mapping = {
        "x": np.array([1.0, 0.0, 0.0]),
        "y": np.array([0.0, 1.0, 0.0]),
        "z": np.array([0.0, 0.0, 1.0]),
    }
    axes: List[np.ndarray] = []
    for i in range(4):
        if i < len(spec) and spec[i].lower() in mapping:
            axes.append(mapping[spec[i].lower()].copy())
        else:
            axes.append(mapping["z"].copy())
    return axes


def _unit(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=float).reshape(3)
    n = float(np.linalg.norm(v))
    if n == 0.0:
        return np.array([0.0, 0.0, 1.0], dtype=float)
    return v / n


def face_holonomy(U_edges: List[np.ndarray], B: np.ndarray, f: int) -> np.ndarray:
    """
    Generic face holonomy from SU(2) edge transports and incidence B.
    """
    H = np.eye(2, dtype=complex)
    for e in range(B.shape[1]):
        coeff = B[f, e]
        if coeff == 0.0:
            continue
        U = U_edges[e]
        if coeff < 0.0:
            U = U.conj().T
        H = U @ H
    return H


def aligned_lift_half_angles(F_faces: np.ndarray) -> Tuple[np.ndarray, float, float]:
    """
    Aligned z-axis lift in HALF-ANGLE variables a_e:

      B a = F/2, minimize sum a_e^2

    Returns:
      a_edges: (6,) half-angle edge scalars
      C_half : sum a_e^2
      C_full : sum (2 a_e)^2 = 4*C_half   (full-angle energy)
    """
    B = k4_incidence_matrix()
    F = np.asarray(F_faces, dtype=float).reshape(4)
    rhs = 0.5 * F
    a_edges, *_ = np.linalg.lstsq(B, rhs, rcond=None)
    C_half = float(np.sum(a_edges**2))
    C_full = 4.0 * C_half
    return a_edges, C_half, C_full


def aligned_edges_to_su2(a_edges: np.ndarray) -> List[np.ndarray]:
    """
    Convert aligned half-angles a_e into SU(2) edges:
      full angle vector = (0,0, 2*a_e)
      U_e = exp_su2(full_vec)
    """
    a_edges = np.asarray(a_edges, dtype=float).reshape(6)
    U_edges: List[np.ndarray] = []
    for e in range(6):
        full_vec = np.array([0.0, 0.0, 2.0 * a_edges[e]], dtype=float)
        U_edges.append(exp_su2(full_vec))
    return U_edges


def non_aligned_lift_half_angles(
    F_faces: np.ndarray,
    axes: List[np.ndarray],
    lambda_reg: float = 0.0,
) -> Tuple[np.ndarray, List[np.ndarray], Dict[str, float]]:
    """
    Non-aligned HALF-ANGLE LS lift:

      For each face f, target half-angle vector is:
        b_f = (F_f/2) * n_f

      Constraints in stacked form:
        (kron(B, I3)) * A_flat = b
      where A_flat is edge-major: [A0x,A0y,A0z, A1x,A1y,A1z, ...] (len=18)

    If lambda_reg == 0:
      uses np.linalg.lstsq for minimum-norm LS (exact if consistent).

    If lambda_reg > 0:
      solves Tikhonov normal equations.

    Returns:
      A_edges: (6,3) half-angle edge vectors
      U_edges: SU(2) edges using U_e = exp_su2(2*A_e)
      stats  : dict with energies + residual norms
    """
    B = k4_incidence_matrix()
    F = np.asarray(F_faces, dtype=float).reshape(4)
    axes_u = [_unit(a) for a in axes]

    # Correct ordering for face-major b and edge-major A_flat:
    C = np.kron(B, np.eye(3))  # (12,18)

    b = np.zeros(12, dtype=float)
    for f in range(4):
        b[3 * f: 3 * f + 3] = 0.5 * F[f] * axes_u[f]

    if lambda_reg == 0.0:
        A_flat, *_ = np.linalg.lstsq(C, b, rcond=None)
    else:
        CT = C.T
        A_mat = CT @ C + float(lambda_reg) * np.eye(C.shape[1])
        rhs = CT @ b
        A_flat = np.linalg.solve(A_mat, rhs)

    A_edges = A_flat.reshape(6, 3)

    # Energies (half-angle vs full-angle)
    C_half = float(np.sum(A_edges**2))
    C_full = 4.0 * C_half

    resid = C @ A_flat - b
    resid_l2 = float(np.linalg.norm(resid))

    # Exponentiate: full angle vec = 2*A_e
    U_edges = [exp_su2(2.0 * A_edges[e]) for e in range(6)]

    stats = {
        "C_half": C_half,
        "C_full": C_full,
        "resid_l2": resid_l2,
    }
    return A_edges, U_edges, stats


def holonomy_gaps(
    U_edges: List[np.ndarray],
    F_faces: np.ndarray,
) -> Dict[int, Dict[str, float]]:
    """
    Compute per-face holonomy gaps:
      gap_f = Re(Tr(H_f)/2) - cos(F_f/2)
    """
    B = k4_incidence_matrix()
    F = np.asarray(F_faces, dtype=float).reshape(4)

    out: Dict[int, Dict[str, float]] = {}
    for f in range(4):
        Hf = face_holonomy(U_edges, B, f)
        tr_half = float(np.real(np.trace(Hf) / 2.0))
        cos_half = float(np.cos(0.5 * F[f]))
        gap = tr_half - cos_half
        out[f] = {
            "F": float(F[f]),
            "tr_half": tr_half,
            "cos_half": cos_half,
            "gap": float(gap),
            "abs_gap": float(abs(gap)),
        }
    return out


def compute_dynamic_flux(theta_traj: np.ndarray, g) -> np.ndarray:
    """
    Compute face flux F_f(t) from a theta trajectory and graph spec g (needs g.alphas).
    Uses EDGE_LIST and incidence B.
    """
    theta_traj = np.asarray(theta_traj, dtype=float)
    T_eff, _n = theta_traj.shape
    B = k4_incidence_matrix()

    F_traj = np.zeros((T_eff, 4), dtype=float)
    for t in range(T_eff):
        th = theta_traj[t]
        for f in range(4):
            Ff = 0.0
            for e_idx, (i, j) in enumerate(EDGE_LIST):
                coeff = B[f, e_idx]
                if coeff == 0.0:
                    continue
                if coeff > 0.0:
                    dtheta = th[j] - th[i] - g.alphas[i, j]
                else:
                    dtheta = th[i] - th[j] - g.alphas[j, i]
                Ff += dtheta
            F_traj[t, f] = float(np.angle(np.exp(1j * Ff)))
    return F_traj
