"""
rtg.k4.holonomy: K4 holonomy/lift/stiffness pipelines.
"""
