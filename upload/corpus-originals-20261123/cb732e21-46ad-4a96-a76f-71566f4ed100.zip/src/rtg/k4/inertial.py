"""
file: src/rtg/k4/inertial.py
purpose: minimal inertial Kuramoto map + K4 builders (no legacy rtg_core.py)
notes:
  - keeps conventions compatible with your existing K4 scout + holonomy scripts
  - numpy-only
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Tuple, Optional

import numpy as np


@dataclass
class GraphSpec:
    n: int
    kappa: np.ndarray               # (n,n)
    alphas: np.ndarray              # (n,n)
    deg_vec: np.ndarray             # (n,)
    deg_norm: bool = False
    directed: bool = False
    eps_asym: float = 0.0


@dataclass
class K4Params:
    # integrator
    scheme: str = "explicit"        # "explicit" or "ec"
    dt: float = 0.1
    gamma: float = 0.3

    # graph
    topology: str = "quat_sym"      # "ringdiag" | "quat_sym"
    directed: bool = False
    eps_asym: float = 0.0
    deg_norm: bool = False

    # K4 weights
    w_diag: float = 0.15
    sigma2: float = 0.0

    # frustration seed
    triad_phi: float = 0.0


def build_k4_ringdiag(p: K4Params) -> GraphSpec:
    """
    K4 as ring + diagonals:
      ring 0-1-2-3-0
      diagonals 0<->2, 1<->3 with weight (w_diag + sigma2)
    """
    n = 4
    kappa = np.zeros((n, n), dtype=float)

    # ring (optionally directed)
    for i in range(n):
        j = (i + 1) % n
        kappa[i, j] = 1.0 + (p.eps_asym if p.directed else 0.0)
        kappa[j, i] = 1.0 - (p.eps_asym if p.directed else 0.0)

    # diagonals
    d = p.w_diag + p.sigma2
    for (a, b) in [(0, 2), (2, 0), (1, 3), (3, 1)]:
        kappa[a, b] = d

    np.fill_diagonal(kappa, 0.0)

    alphas = np.zeros((n, n), dtype=float)
    if abs(p.triad_phi) > 0.0:
        # same convention as your existing K4 code
        alphas[2, 0] = p.triad_phi
        alphas[3, 1] = p.triad_phi

    deg_vec = np.sum(np.abs(kappa), axis=1)
    if not p.deg_norm:
        deg_vec = np.ones_like(deg_vec)

    return GraphSpec(
        n=n,
        kappa=kappa,
        alphas=alphas,
        deg_vec=deg_vec,
        deg_norm=p.deg_norm,
        directed=p.directed,
        eps_asym=p.eps_asym,
    )


def build_k4_quat_sym(p: K4Params) -> GraphSpec:
    """
    Symmetric K4 used for the quaternion rung.
    Ring edges weight 1 (or 1±eps_asym if directed), diagonals weight w_diag+sigma2.
    """
    n = 4
    kappa = np.ones((n, n), dtype=float)
    np.fill_diagonal(kappa, 0.0)

    ring_pairs = [(0, 1), (1, 2), (2, 3), (3, 0)]
    for (i, j) in ring_pairs:
        kappa[i, j] = 1.0 + (p.eps_asym if p.directed else 0.0)
        kappa[j, i] = 1.0 - (p.eps_asym if p.directed else 0.0)

    diag_w = p.w_diag + p.sigma2
    for (a, b) in [(0, 2), (2, 0), (1, 3), (3, 1)]:
        kappa[a, b] = diag_w

    alphas = np.zeros((n, n), dtype=float)
    if abs(p.triad_phi) > 0.0:
        alphas[2, 0] = p.triad_phi
        alphas[3, 1] = p.triad_phi

    deg_vec = np.sum(np.abs(kappa), axis=1)
    if not p.deg_norm:
        deg_vec = np.ones_like(deg_vec)

    return GraphSpec(
        n=n,
        kappa=kappa,
        alphas=alphas,
        deg_vec=deg_vec,
        deg_norm=p.deg_norm,
        directed=p.directed,
        eps_asym=p.eps_asym,
    )


def build_k4_spec(p: K4Params) -> GraphSpec:
    topo = p.topology.lower()
    if topo == "ringdiag":
        return build_k4_ringdiag(p)
    if topo in ("quat_sym", "quat"):
        return build_k4_quat_sym(p)
    raise ValueError(f"Unknown topology: {p.topology}")


def step_inertial(
    theta: np.ndarray,
    vel: np.ndarray,
    K: float,
    p: K4Params,
    g: GraphSpec,
    noise: float = 0.0,
    rng: Optional[np.random.Generator] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    One step of inertial Kuramoto map (explicit or Euler-Cromer).
    """
    n = g.n
    f = np.zeros(n, dtype=float)

    for i in range(n):
        s = 0.0
        for j in range(n):
            if i == j:
                continue
            s += g.kappa[i, j] * math.sin(theta[j] - theta[i] - g.alphas[i, j])
        s /= g.deg_vec[i]
        f[i] = K * s

    if p.scheme.lower() in ("explicit", "e", "exp"):
        theta_new = theta + p.dt * vel
        vel_new = (1.0 - p.gamma * p.dt) * vel + p.dt * f
    elif p.scheme.lower() in ("ec", "euler_cromer", "euler-cromer"):
        vel_new = (1.0 - p.gamma * p.dt) * vel + p.dt * f
        theta_new = theta + p.dt * vel_new
    else:
        raise ValueError(f"Unknown scheme: {p.scheme}")

    if noise > 0.0:
        if rng is None:
            rng = np.random.default_rng()
        theta_new = theta_new + rng.normal(0.0, noise, size=theta.shape)

    return theta_new, vel_new
