"""
rtg.k4: K4-specific modules (holonomy, ns).
"""
