# src/rtg/simplicial/diamond.py
"""
src/rtg/simplicial/diamond.py
Diamond motif: two tetrahedra sharing a face.
Nodes: 0,1,2 shared base; 3 tip A; 4 tip B
Edges: 9
Faces: 7 triangles (1 shared + 3 on tet A + 3 on tet B)

This file defines combinatorics only (no dynamics).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple, Dict
import numpy as np


@dataclass(frozen=True)
class DiamondSpec:
    n: int = 5

    # Edge list (unordered as undirected edges, but we will orient faces)
    # Base:  (0,1), (1,2), (2,0)
    # Tip A: (0,3), (1,3), (2,3)
    # Tip B: (0,4), (1,4), (2,4)
    edge_list: Tuple[Tuple[int, int], ...] = (
        (0, 1), (1, 2), (2, 0),
        (0, 3), (1, 3), (2, 3),
        (0, 4), (1, 4), (2, 4),
    )

    # Face list as oriented node triplets.
    # We keep a consistent orientation convention inside each triangle,
    # but note that tetrahedra volumes are not explicitly represented here.
    face_list: Tuple[Tuple[int, int, int], ...] = (
        (0, 1, 2),  # f0 shared

        (0, 1, 3), (1, 2, 3), (2, 0, 3),  # f1..f3 tet A surface faces

        (0, 1, 4), (1, 2, 4), (2, 0, 4),  # f4..f6 tet B surface faces
    )


def _edge_index_map(edge_list: Tuple[Tuple[int, int], ...]) -> Dict[Tuple[int, int], int]:
    """
    Map both (u,v) and (v,u) to the same edge index.
    """
    E: Dict[Tuple[int, int], int] = {}
    for idx, (u, v) in enumerate(edge_list):
        E[(u, v)] = idx
        E[(v, u)] = idx
    return E


def diamond_incidence_matrix() -> np.ndarray:
    """
    Faces x Edges incidence matrix B, shape (7, 9).
    For each face (a,b,c), we add oriented boundary edges:
      (a->b), (b->c), (c->a)
    If boundary direction matches stored undirected edge direction, we put +1,
    else -1 (since we look up undirected index, sign depends on traversal).

    IMPORTANT:
    - The edge_list is undirected. We assign sign based purely on traversal.
    - This is consistent with the holonomy product rule using U or U^† for negative sign.
    """
    spec = DiamondSpec()
    E = _edge_index_map(spec.edge_list)

    B = np.zeros((len(spec.face_list), len(spec.edge_list)), dtype=float)

    for f_idx, (a, b, c) in enumerate(spec.face_list):
        boundary = [(a, b), (b, c), (c, a)]
        for (u, v) in boundary:
            e_idx = E[(u, v)]
            # Determine sign relative to canonical undirected orientation as stored in edge_list
            u0, v0 = spec.edge_list[e_idx]
            sgn = +1.0 if (u, v) == (u0, v0) else -1.0
            B[f_idx, e_idx] = sgn

    return B
