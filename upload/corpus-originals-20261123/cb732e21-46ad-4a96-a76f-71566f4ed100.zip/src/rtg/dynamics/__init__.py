"""
rtg.dynamics: dynamical modules (caputo, ghost, barrier, ns).
"""
