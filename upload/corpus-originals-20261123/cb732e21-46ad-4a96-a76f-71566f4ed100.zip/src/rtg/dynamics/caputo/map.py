"""
file: src/rtg/dynamics/caputo/map.py
purpose: Caputo-increment logistic map + first-exit (fracture) detection.

model:
  g(x) = r * x * (1 - x)
  d[n] = g(x[n]) - x[n]
  x[n+1] = x0 + sum_{j=0..m-1} w[j] * d[n-j]
where m = min(M, n+1) and w are Caputo weights.

notes:
  - ASCII-only identifiers
  - returns (x, stats) for reproducibility
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np

from rtg.dynamics.caputo.weights import caputo_weights


def logistic_classic(r: float, x0: float, n_steps: int) -> np.ndarray:
    x = np.empty(n_steps + 1, dtype=float)
    x[0] = float(x0)
    rr = float(r)
    for n in range(n_steps):
        x[n + 1] = rr * x[n] * (1.0 - x[n])
    return x


def logistic_caputo_increment(
    alpha: float,
    r: float,
    x0: float,
    n_steps: int,
    m: Optional[int] = None,
    *,
    clip: Optional[Tuple[float, float]] = None,
    force_caputo_sum_when_alpha1: bool = False,
    break_on_oob: bool = False,
) -> Tuple[np.ndarray, Dict[str, object]]:
    """
    Simulate Caputo-increment logistic map.

    Args:
      alpha: fractional order in (0, 1]
      r: logistic parameter
      x0: initial condition
      n_steps: number of iterations
      m: memory depth M; if None uses full history (n_steps+1)
      clip: optional (lo, hi) bounds applied to x[n+1] (for numerical safety)
      force_caputo_sum_when_alpha1: if True, run Caputo sum even for alpha=1
      break_on_oob: if True, stop at first x leaving [0,1] (fracture)

    Returns:
      x: array (n_steps+1,)
      stats: dict with tau_exit and diagnostics
    """
    a = float(alpha)
    rr = float(r)
    x0f = float(x0)

    if not (0.0 < a <= 1.0):
        raise ValueError("alpha must be in (0, 1].")
    if n_steps < 1:
        raise ValueError("n_steps must be >= 1.")

    # alpha=1 shortcut (classic map)
    if a == 1.0 and not force_caputo_sum_when_alpha1:
        x = logistic_classic(rr, x0f, int(n_steps))
        oob = (x < 0.0) | (x > 1.0)
        tau_exit = int(np.argmax(oob)) if np.any(oob) else None
        stats0: Dict[str, object] = {
            "alpha": a,
            "r": rr,
            "x0": x0f,
            "m": int(n_steps + 1) if m is None else int(m),
            "oob_count": int(np.sum(oob)),
            "clip_count": 0,
            "diverged": False,
            "finite_steps": int(n_steps),
            "max_abs_x": float(np.max(np.abs(x[np.isfinite(x)]))) if np.isfinite(x).any() else float("nan"),
            "tau_exit": tau_exit,
        }
        return x, stats0

    # memory depth
    m_eff = (n_steps + 1) if m is None else int(m)
    if m_eff < 1:
        raise ValueError("m must be >= 1.")
    w = caputo_weights(a, m_eff)

    x = np.empty(n_steps + 1, dtype=float)
    d = np.empty(n_steps + 1, dtype=float)
    x[0] = x0f

    oob_count = 0
    clip_count = 0
    diverged = False
    finite_steps = 0
    max_abs_x = abs(x0f)
    tau_exit: Optional[int] = None

    for n in range(n_steps):
        g = rr * x[n] * (1.0 - x[n])
        d[n] = g - x[n]

        m_use = min(m_eff, n + 1)
        start = n - m_use + 1
        d_slice = d[start : n + 1][::-1]
        conv = float(np.dot(w[:m_use], d_slice))
        x_next_raw = x0f + conv

        # first exit detection relative to invariant interval [0,1]
        if (x_next_raw < 0.0) or (x_next_raw > 1.0):
            oob_count += 1
            if tau_exit is None:
                tau_exit = n + 1
            if break_on_oob:
                x[n + 1] = x_next_raw
                x[n + 2 :] = np.nan
                finite_steps = n + 1
                max_abs_x = max(max_abs_x, abs(float(x_next_raw)))
                break

        x_next = x_next_raw
        if clip is not None:
            lo, hi = clip
            if (x_next < lo) or (x_next > hi):
                clip_count += 1
            x_next = float(np.clip(x_next, lo, hi))

        x[n + 1] = x_next
        finite_steps = n + 1
        if np.isfinite(x_next):
            max_abs_x = max(max_abs_x, abs(float(x_next)))

        if not np.isfinite(x_next):
            diverged = True
            x[n + 1 :] = np.nan
            break

    stats: Dict[str, object] = {
        "alpha": a,
        "r": rr,
        "x0": x0f,
        "m": int(m_eff),
        "oob_count": int(oob_count),
        "clip_count": int(clip_count),
        "diverged": bool(diverged),
        "finite_steps": int(finite_steps),
        "max_abs_x": float(max_abs_x),
        "tau_exit": int(tau_exit) if tau_exit is not None else None,
    }
    return x, stats
