"""
rtg.dynamics.caputo: discrete Caputo-increment map utilities.
"""
