"""
file: src/rtg/dynamics/caputo/weights.py
purpose: Caputo-type weight generation (stable recursion), ASCII-only.

definition:
  w[0] = 1
  w[j+1] = w[j] * (j + alpha) / (j + 1)

notes:
  - alpha in (0, 1]
  - M is the memory depth (positive int)
"""

from __future__ import annotations

from typing import Optional
import numpy as np


def caputo_weights(alpha: float, m: int, *, dtype=np.float64) -> np.ndarray:
    """
    Compute Caputo-type weights using stable recursion.

    Args:
      alpha: fractional order in (0, 1]
      m: number of weights (memory depth), m >= 1
      dtype: numpy dtype (default float64)

    Returns:
      w: array shape (m,), with w[0]=1
    """
    if not (0.0 < float(alpha) <= 1.0):
        raise ValueError("alpha must be in (0, 1].")
    if int(m) < 1:
        raise ValueError("m must be >= 1.")

    m = int(m)
    a = float(alpha)

    w = np.empty(m, dtype=dtype)
    w[0] = 1.0
    for j in range(m - 1):
        w[j + 1] = w[j] * ((j + a) / (j + 1.0))
    return w


def caputo_gain(alpha: float, m: int) -> float:
    """
    Total inertial gain G_m = sum_{j=0..m-1} w[j].
    """
    w = caputo_weights(alpha, m)
    return float(np.sum(w))
