"""
file: src/rtg/dynamics/barrier/survival.py
purpose: Target 3 stochastic barrier survival with censoring (Kaplan-Meier),
         and survival-derived lambda_hat for Arrhenius scaling tests.

model (operational time u):
  dX = (mu + X^2) du + sigma dW_u,   mu < 0 (barrier)

physical time t:
  dt = du                          if alpha=1
  dt = du^(1/alpha) * S_alpha      if 0<alpha<1, S_alpha ~ positive alpha-stable
  where Laplace: E[exp(-s S)] = exp(-s^alpha)

outputs:
  - times (censored at t_max)
  - events (1=escaped, 0=censored)
  - Kaplan-Meier survival S(t)
  - lambda_hat from midrange fit: -ln S ~ (lambda/gamma(1+alpha)) t^alpha

notes:
  - ASCII-only identifiers
  - use YAML for configs, JSON for results in scripts
"""

from __future__ import annotations

import math
from typing import Dict, Tuple

import numpy as np
import pandas as pd


def positive_alpha_stable(alpha: float, size: int, rng: np.random.Generator) -> np.ndarray:
    """
    One-sided (totally skewed) alpha-stable sampler with Laplace:
      E[exp(-s S)] = exp(-s^alpha),  0<alpha<1
    """
    a = float(alpha)
    if not (0.0 < a < 1.0):
        raise ValueError("alpha must be in (0,1) for positive stable increments.")

    u = rng.uniform(1e-12, math.pi - 1e-12, size=size)
    w = rng.exponential(scale=1.0, size=size)

    s = (np.sin(a * u) / (np.sin(u) ** a)) * ((np.sin((1.0 - a) * u) / w) ** ((1.0 - a) / a))

    bad = ~np.isfinite(s)
    if np.any(bad):
        for _ in range(3):
            if not np.any(bad):
                break
            u2 = rng.uniform(1e-12, math.pi - 1e-12, size=int(np.sum(bad)))
            w2 = rng.exponential(scale=1.0, size=int(np.sum(bad)))
            s2 = (np.sin(a * u2) / (np.sin(u2) ** a)) * ((np.sin((1.0 - a) * u2) / w2) ** ((1.0 - a) / a))
            s[bad] = s2
            bad = ~np.isfinite(s)

    return s


def simulate_fpt_subordinated(
    alpha: float,
    mu: float,
    sigma: float,
    du: float,
    t_max: float,
    n_traj: int,
    *,
    escape_level: float = 0.0,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Simulate subordinated FPTs (times, events) for barrier escape.

    - mu must be < 0
    - start at x_s = -sqrt(-mu)
    - escape when x >= escape_level and t <= t_max
    - events[i] = 1 if escaped, else 0 (censored)
    """
    a = float(alpha)
    mu = float(mu)
    sigma = float(sigma)
    du = float(du)
    t_max = float(t_max)

    if mu >= 0.0:
        raise ValueError("Barrier crossing requires mu < 0.")
    if not (0.0 < a <= 1.0):
        raise ValueError("alpha must be in (0,1].")
    if sigma <= 0.0:
        raise ValueError("sigma must be > 0.")
    if du <= 0.0 or t_max <= 0.0:
        raise ValueError("du and t_max must be > 0.")
    if int(n_traj) < 10:
        raise ValueError("n_traj too small.")

    n_traj = int(n_traj)
    rng = np.random.default_rng(int(seed))

    x_s = -math.sqrt(-mu)
    times = np.empty(n_traj, dtype=float)
    events = np.empty(n_traj, dtype=int)
    du_sqrt = math.sqrt(du)

    for i in range(n_traj):
        x = x_s
        t = 0.0
        escaped = False

        for _ in range(5_000_000):
            if t >= t_max:
                break

            drift = mu + x * x
            x = x + drift * du + sigma * du_sqrt * rng.normal()

            if a == 1.0:
                dt = du
            else:
                dt = (du ** (1.0 / a)) * float(positive_alpha_stable(a, 1, rng)[0])

            t += dt
            if (x >= escape_level) and (t <= t_max):
                escaped = True
                break

        times[i] = min(t, t_max)
        events[i] = 1 if escaped else 0

    return times, events


def kaplan_meier(times: np.ndarray, events: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Kaplan-Meier survival estimator.
    Returns:
      t_points, s_points
    """
    order = np.argsort(times)
    t = times[order]
    e = events[order]

    n = len(t)
    at_risk = n
    s_val = 1.0

    t_points = [0.0]
    s_points = [1.0]

    i = 0
    while i < n:
        t_i = t[i]
        j = i
        while j < n and t[j] == t_i:
            j += 1

        d = int(np.sum(e[i:j]))
        c = (j - i) - d

        if d > 0:
            s_val *= (1.0 - d / at_risk)
            t_points.append(float(t_i))
            s_points.append(float(s_val))

        at_risk -= (d + c)
        i = j
        if at_risk <= 0:
            break

    return np.array(t_points), np.array(s_points)


def fit_lambda_from_survival(alpha: float, t: np.ndarray, s: np.ndarray) -> float:
    """
    Heuristic midrange fit:
      -ln S(t) ~ (lambda / gamma(1+alpha)) * t^alpha
    => lambda_hat = slope * gamma(1+alpha)
    """
    a = float(alpha)
    eps = 1e-12
    s = np.clip(s, eps, 1.0 - eps)
    y = -np.log(s)
    x = t**a

    mask = (s < 0.8) & (s > 0.2) & np.isfinite(x) & np.isfinite(y)
    if np.sum(mask) < 3:
        mask = (s < 0.95) & (s > 0.05) & np.isfinite(x) & np.isfinite(y)
    if np.sum(mask) < 3:
        return float("nan")

    slope, _ = np.polyfit(x[mask], y[mask], 1)
    slope = max(float(slope), 0.0)
    return float(slope * math.gamma(1.0 + a))


def run_survival_dataset(
    alpha: float,
    mu_grid: np.ndarray,
    sigma: float,
    du: float,
    t_max: float,
    n_traj: int,
    *,
    seed: int,
) -> pd.DataFrame:
    """
    Build lambda_hat(mu) dataset for fixed alpha.
    Returns DataFrame with:
      mu, lambda_hat, escape_frac, censor_frac
    """
    rows = []
    base_seed = int(seed)

    for idx, mu in enumerate(mu_grid):
        times, events = simulate_fpt_subordinated(
            alpha=float(alpha),
            mu=float(mu),
            sigma=float(sigma),
            du=float(du),
            t_max=float(t_max),
            n_traj=int(n_traj),
            escape_level=0.0,
            seed=base_seed + idx,
        )

        escape_frac = float(np.mean(events))
        censor_frac = 1.0 - escape_frac

        t_km, s_km = kaplan_meier(times, events)
        lam_hat = fit_lambda_from_survival(alpha, t_km, s_km)

        rows.append(
            {
                "mu": float(mu),
                "lambda_hat": float(lam_hat),
                "escape_frac": escape_frac,
                "censor_frac": censor_frac,
            }
        )

    return pd.DataFrame(rows)


def fit_arrhenius_r2(df_raw: pd.DataFrame, sigma: float, p_exponent: float, n_fit: int) -> float:
    """
    Compute R2 for ln(lambda_hat) vs x = |mu|^p / sigma^2 using first n_fit points.
    Returns R2 (nan if insufficient).
    """
    x = (np.abs(df_raw["mu"].values) ** float(p_exponent)) / (float(sigma) ** 2)
    y = np.log(df_raw["lambda_hat"].values)

    ok = np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]
    if x.size < max(2, int(n_fit)):
        return float("nan")

    x_fit = x[: int(n_fit)]
    y_fit = y[: int(n_fit)]
    slope, intercept = np.polyfit(x_fit, y_fit, 1)
    y_pred = slope * x_fit + intercept

    sst = float(np.sum((y_fit - y_fit.mean()) ** 2))
    sse = float(np.sum((y_fit - y_pred) ** 2))
    return float(1.0 - sse / sst) if sst > 0 else float("nan")
