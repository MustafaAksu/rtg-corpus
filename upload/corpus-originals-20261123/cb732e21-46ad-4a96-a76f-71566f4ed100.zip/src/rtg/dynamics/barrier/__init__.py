"""
rtg.dynamics.barrier: stochastic barrier survival (KM + subordination).
"""
