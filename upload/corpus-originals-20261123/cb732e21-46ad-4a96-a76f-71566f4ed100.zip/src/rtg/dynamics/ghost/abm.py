"""
file: src/rtg/dynamics/ghost/abm.py
purpose: Fractional ABM-PECE solver for deterministic ghost scaling.
model:
  D_t^alpha x(t) = mu + x(t)^2,  x(0)=0,  0<alpha<=1,  mu>0
escape:
  tau = inf{ t>0 : x(t) >= kappa * sqrt(mu) }
notes:
  - Implements Diethelm endpoint correction term (a0) for corrector.
  - Supports finite history cutoff m (approximate finite memory).
  - ASCII-only identifiers.
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np


def abm_weights(alpha: float, m: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Precompute ABM weights indexed by lag l=1..m.

    Predictor weights (Adams-Bashforth):
      b_l = l^alpha - (l-1)^alpha

    Corrector interior weights (Adams-Moulton for j>=1):
      a_l = (l+1)^(alpha+1) - 2*l^(alpha+1) + (l-1)^(alpha+1)

    Note:
      - endpoint a0 coefficient depends on n and is handled in stepping loop.
    """
    a = float(alpha)
    if not (0.0 < a <= 1.0):
        raise ValueError("alpha must be in (0, 1].")
    if int(m) < 1:
        raise ValueError("m must be >= 1.")

    m = int(m)
    l = np.arange(1, m + 1, dtype=float)

    b = l**a - (l - 1.0) ** a

    ap = a + 1.0
    a_int = (l + 1.0) ** ap - 2.0 * l**ap + (l - 1.0) ** ap

    return b.astype(float), a_int.astype(float)


def ghost_escape_time_abm(
    alpha: float,
    mu: float,
    *,
    h: float,
    t_max: float,
    kappa: float,
    m: int,
    b: Optional[np.ndarray] = None,
    a_int: Optional[np.ndarray] = None,
) -> float:
    """
    Compute escape time tau using ABM-PECE with history cutoff m.

    Returns:
      tau (float): escape time; returns t_max if no escape before t_max.

    Special case:
      alpha=1 -> analytic solution for dx/dt = mu + x^2 with x(0)=0:
        tau = arctan(kappa) / sqrt(mu)
    """
    a = float(alpha)
    if not (0.0 < a <= 1.0):
        raise ValueError("alpha must be in (0, 1].")
    if float(mu) <= 0.0:
        raise ValueError("mu must be > 0.")
    if float(h) <= 0.0:
        raise ValueError("h must be > 0.")
    if float(t_max) <= 0.0:
        raise ValueError("t_max must be > 0.")
    if float(kappa) <= 1.0:
        raise ValueError("kappa should be > 1 (e.g. 10).")
    if int(m) < 1:
        raise ValueError("m must be >= 1.")

    mu = float(mu)
    h = float(h)
    t_max = float(t_max)
    kappa = float(kappa)
    m = int(m)

    x0 = 0.0
    x_thresh = kappa * math.sqrt(mu)

    if a == 1.0:
        return math.atan(kappa) / math.sqrt(mu)

    n_steps = int(t_max / h)
    if n_steps < 10:
        raise ValueError("t_max/h too small for a meaningful run.")

    m_eff = min(m, n_steps + 1)
    if b is None or a_int is None:
        b, a_int = abm_weights(a, m_eff)

    g1 = math.gamma(a + 1.0)
    g2 = math.gamma(a + 2.0)
    h_a = h**a

    x = np.zeros(n_steps + 1, dtype=float)
    f = np.zeros(n_steps + 1, dtype=float)
    x[0] = x0
    f[0] = mu + x0**2

    for n in range(n_steps):
        m_use = min(n + 1, m_eff)
        f_hist = f[n - m_use + 1 : n + 1][::-1]  # [f_n, f_{n-1}, ...]

        # predictor
        sum_b = float(np.dot(b[:m_use], f_hist))
        x_pred = x0 + (h_a / g1) * sum_b
        f_pred = mu + x_pred**2

        # corrector interior
        sum_a = float(np.dot(a_int[:m_use], f_hist))

        # Diethelm endpoint correction if f0 included (n+1 <= m_eff)
        if (n + 1) <= m_eff:
            l0 = n + 1
            a_l0 = float(a_int[l0 - 1])
            a0 = (n ** (a + 1.0)) - ((n - a) * (n + 1.0) ** a)
            sum_a += (a0 - a_l0) * float(f[0])

        x_next = x0 + (h_a / g2) * (f_pred + sum_a)

        if not math.isfinite(x_next):
            return float("nan")

        x[n + 1] = x_next
        f[n + 1] = mu + x_next**2

        if x_next >= x_thresh:
            return (n + 1) * h

    return t_max


def fit_gamma_from_mu_grid(mu_grid: np.ndarray, tau_grid: np.ndarray, *, t_max: float) -> float:
    """
    Fit log(tau) ~ -gamma log(mu) for uncensored points (tau < 0.995*t_max).
    """
    mu = np.asarray(mu_grid, dtype=float)
    tau = np.asarray(tau_grid, dtype=float)

    ok = np.isfinite(mu) & np.isfinite(tau) & (mu > 0.0) & (tau > 0.0) & (tau < 0.995 * float(t_max))
    if int(np.sum(ok)) < 3:
        return float("nan")

    x = np.log(mu[ok])
    y = np.log(tau[ok])
    slope, _ = np.polyfit(x, y, 1)
    return -float(slope)
