"""
rtg.dynamics.ghost: deterministic ghost scaling (fractional ABM-PECE).
"""
