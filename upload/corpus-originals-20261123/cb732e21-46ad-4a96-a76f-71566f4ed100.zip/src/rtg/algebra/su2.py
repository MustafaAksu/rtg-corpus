"""
file: src/rtg/algebra/su2.py
purpose: SU(2) primitives (ASCII-only), optimized for portability.
notes:
  - No SciPy dependency. Uses closed-form SU(2) exp and axis-angle log.
  - Matrices are 2x2 complex numpy arrays.
"""

from __future__ import annotations

import numpy as np


# Pauli matrices
SIGMA_X = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
SIGMA_Y = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex)
SIGMA_Z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
I2 = np.eye(2, dtype=complex)


def exp_su2(vec: np.ndarray, eps: float = 1e-14) -> np.ndarray:
    """
    Closed-form SU(2) exponential:
      U = cos(theta/2) I - i sin(theta/2) (n·sigma)
    where theta = ||vec|| and n = vec/theta.
    """
    v = np.asarray(vec, dtype=float).reshape(3)
    theta = float(np.linalg.norm(v))
    if theta < eps:
        return I2.copy()

    n = v / theta
    ns = n[0] * SIGMA_X + n[1] * SIGMA_Y + n[2] * SIGMA_Z
    c = np.cos(theta / 2.0)
    s = np.sin(theta / 2.0)
    return (c * I2) - (1.0j * s) * ns


def su2_log(U: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    """
    Axis-angle log for SU(2), returning su(2) generator X (anti-Hermitian, traceless)
    such that exp(X) = U.

    Returns X in su(2). Suitable for BCH commutator diagnostics.
    """
    U = np.asarray(U, dtype=complex)
    tr = np.real(np.trace(U))
    c = np.clip(tr / 2.0, -1.0 + eps, 1.0 - eps)
    phi = float(np.arccos(c))  # SU(2) half-angle in [0, pi]
    s = float(np.sin(phi))

    if phi < 1e-10:
        X = 0.5 * (U - U.conj().T)
        X = 0.5 * (X - X.conj().T)
        X -= (np.trace(X) / 2.0) * I2
        return X

    A = (U - U.conj().T) / (2.0j)  # Hermitian
    if abs(s) < eps:
        s = eps

    X = (-1.0j) * (phi / s) * A
    X = 0.5 * (X - X.conj().T)
    X -= (np.trace(X) / 2.0) * I2
    return X


def comm(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    return A @ B - B @ A


def fro_norm(A: np.ndarray) -> float:
    return float(np.linalg.norm(A, ord="fro"))
