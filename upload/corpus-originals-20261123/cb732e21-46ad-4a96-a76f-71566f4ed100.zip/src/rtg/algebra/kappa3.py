"""
file: src/rtg/algebra/kappa3.py
purpose: Lie-rank (BCH-like) obstruction diagnostics: rank1, rank2, rank3 (kappa3).
notes:
  - rank3 is a symmetric nested-commutator proxy, suitable for sector detection.
"""

from __future__ import annotations

import numpy as np
from typing import Dict, List, Sequence, Tuple

from rtg.algebra.su2 import su2_log, comm, fro_norm


class Kappa3Diagnostic:
    def __init__(self, tol_screen: float = 1e-6, tol_kappa3: float = 1e-9):
        self.tol_screen = float(tol_screen)
        self.tol_kappa3 = float(tol_kappa3)

    def measure_ranks_from_U_loop(self, U_list: Sequence[np.ndarray]) -> Dict[str, float]:
        Xs = [su2_log(U) for U in U_list]
        m = len(Xs)

        rank1 = np.zeros((2, 2), dtype=complex)
        for X in Xs:
            rank1 += X

        rank2 = np.zeros((2, 2), dtype=complex)
        for i in range(m):
            for j in range(i + 1, m):
                rank2 += comm(Xs[i], Xs[j])
        rank2 *= 0.5

        rank3 = np.zeros((2, 2), dtype=complex)
        for i in range(m):
            for j in range(m):
                if j == i:
                    continue
                for k in range(m):
                    if k == i or k == j:
                        continue
                    rank3 += comm(Xs[i], comm(Xs[j], Xs[k]))
        rank3 *= (1.0 / 12.0)

        return {
            "rank1_norm": fro_norm(rank1),
            "rank2_norm": fro_norm(rank2),
            "kappa3_norm": fro_norm(rank3),
        }

    def analyze_sector(self, U_list: Sequence[np.ndarray]) -> Dict[str, object]:
        d = self.measure_ranks_from_U_loop(U_list)
        r1_ok = d["rank1_norm"] < self.tol_screen
        r2_ok = d["rank2_norm"] < self.tol_screen
        r3_on = d["kappa3_norm"] > self.tol_kappa3
        return {"is_ghost_sector": bool(r1_ok and r2_ok and r3_on), "details": d}
