"""
rtg.algebra: SU(2) + K4 lift + kappa3 diagnostics.
"""
