"""
file: src/rtg/algebra/k4_lift.py
purpose: K4 incidence, face holonomy, and linear LS lift initializers.
notes:
  - Uses exp_su2 from rtg.algebra.su2
  - ASCII-only identifiers.
"""

from __future__ import annotations

import numpy as np
from typing import List, Tuple

from rtg.algebra.su2 import exp_su2


def k4_incidence_matrix() -> np.ndarray:
    return np.array(
        [
            [1.0, -1.0, 0.0, 1.0, 0.0, 0.0],
            [1.0, 0.0, -1.0, 0.0, 1.0, 0.0],
            [0.0, 1.0, -1.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 0.0, 1.0, -1.0, 1.0],
        ],
        dtype=float,
    )


def face_holonomy_from_B(U_edges: List[np.ndarray], B: np.ndarray, face_index: int) -> np.ndarray:
    H = np.eye(2, dtype=complex)
    row = B[face_index]
    for e, sgn in enumerate(row):
        if abs(sgn) < 1e-12:
            continue
        U = U_edges[e]
        if sgn < 0:
            U = U.conj().T
        H = U @ H
    return H


def linear_ls_init(B: np.ndarray, face_flux: np.ndarray, face_axes: np.ndarray) -> np.ndarray:
    """
    Solve C A = b with C = kron(I3, B), b stacks face_flux[f] * face_axes[f].
    Returns A_flat shape (18,).
    """
    B = np.asarray(B, dtype=float)
    F = np.asarray(face_flux, dtype=float).reshape(4)
    axes = np.asarray(face_axes, dtype=float).reshape(4, 3)

    # normalize axes
    for f in range(4):
        nrm = float(np.linalg.norm(axes[f]))
        axes[f] = axes[f] / nrm if nrm > 1e-12 else np.array([0.0, 0.0, 1.0])

    C = np.kron(np.eye(3), B)  # (12,18)
    b = np.zeros(12, dtype=float)
    for f in range(4):
        b[3 * f : 3 * f + 3] = F[f] * axes[f]

    A_flat, *_ = np.linalg.lstsq(C, b, rcond=None)
    return np.asarray(A_flat, dtype=float)


def build_U_edges_from_A(A_flat: np.ndarray) -> List[np.ndarray]:
    A_edges = np.asarray(A_flat, dtype=float).reshape(6, 3)
    return [exp_su2(A_edges[e]) for e in range(6)]
