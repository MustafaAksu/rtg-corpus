# RER Phase B batch — L1 finalization package (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE. This package completes the five L1 items of the receiving co-owner's batch review of 21 Oct 2026 (`receipts/BATCH_RECEIVING_REVIEW_20261021.md`, `bd80f89d…`; `receipts/L1_FINALIZATION_DELTA_20261021.json`) **on the same r4.14 target** — distinct revision identity **r4.14-L1**, no r4.15, no r22, no new scientific cycle. The submitted batch (`RER_PHASE_B_BATCH_20261021.zip` `08c13277…5786`), the r4.14 candidate (`92f983e6…f044`), Phase A r21 (`3eb4e137…62e1`) and the r20 baseline (`adfedefd…3abc`) are unchanged and remain the history. Nothing here is an adoption, freeze or publication.

| L1 item | Done where | Check |
|---|---|---|
| **01 title/date** | `rer_r4_14_L1/`: r4.14-L1 text `032f2211229ab55d6f5f2477f19b75bb29c55a32d7574682be514b18ae0070d3` (8 exact-once edits on the candidate; 30-line diff) — title "DRAFT r4.14", date list names r4.14 | `check_r4_14_L1_draft.py` D3 |
| **02 count 10 + 2 = 12** | status line, §8 row, §9 entry of r4.14-L1 | D3 (no stale "10" aggregate) |
| **03 table attribution** | `dispositions/out/DISPOSITION_TABLE_20_RECORDS.md/.json`: FORMAL-INVOLUTION without "(d) conditional" (kept on BIRTH-GRAPH); FORMAL-AGE: r2 review preparer-authored, distinct from the FORMAL structural note, no author identity newly authenticated; column relabelled "summary" | `make_disposition_table.py --check` |
| **04 K3 typing** | `k3_econjugacy/K3_ECONJUGACY_REVIEW_PACKET_20261021.md` §1: E₀ (3×2), P₀, Ē = E₀⊗I₂: R⁴ → C_raw, P̄, E_W = (I₃⊗L)Ē; outcome recorded | — (text) |
| **05 receipt integration** | RER-GEN-K3-MODAL Review receipt (append-only, in r4.14-L1); table 18 REVIEWED_SCOPED + 2 BLOCKED_SOURCE_UNVERIFIED; Phase A regenerated once as **r21-L1** (`phaseA_r21_L1/RER_phaseA_r21_L1.zip` `076fd118820996513d4367de001a58b6a2bf7c4e4dace5db0b90cdff984ed274`) with the receiver sidecar `REFERENCE_DISPOSITIONS_20261021.json` attached to the 27 reference rows as `receiving_disposition_20261021`; pre-review fields kept as history | r4.14-L1 D2; Phase A A37 (37/37 gates, 221 controls) |

## Identities

| Object | SHA-256 |
|---|---|
| RER r4.14-L1 text | `032f2211229ab55d6f5f2477f19b75bb29c55a32d7574682be514b18ae0070d3` |
| `RER_r4_14_L1.zip` (= submitted r4.14 package + L1 files + receiver batch files) | `ca931651e8f8c6500e4ba0f2807a84981310e1246c048af341172248f8385e1d` |
| `RER_phaseA_r21_L1.zip` | `076fd118820996513d4367de001a58b6a2bf7c4e4dace5db0b90cdff984ed274` |
| receiver batch review / sidecar / K3 proof / L1 delta | `bd80f89d…` / `3536c207…b78d` / `bb0926ce…` / `3a2542a4…` (full hashes in the tables' JSON and `SHA256SUMS.txt`) |

## Replay (focused L1 identity checks, as instructed)

```
# RER
unzip rer_r4_14_L1/RER_r4_14_L1.zip && cd RER_r4_14_L1 && sha256sum -c SHA256SUMS.txt
python -I -B build_r4_14_L1_draft.py && python -I -B check_r4_14_L1_draft.py --controls   # 8/8 gates, 7 controls
# Phase A
unzip phaseA_r21_L1/RER_phaseA_r21_L1.zip && cd RER_phaseA_r21_L1 && sha256sum -c SHA256SUMS.txt
python -I -B build_phaseA.py && python -I -B check_phaseA.py --tamper                      # 37/37 gates, 221 controls
# table
cd dispositions && python -I -B make_disposition_table.py --check
```

## Unchanged from the submitted batch

`audit/` (13-row audit; outputs byte-identical to the submitted package), `k3_econjugacy/` scripts and logs, `dispositions/MISSING_SOURCE_DISPOSITIONS_20261021.md`, the prior receipts B-01…B-08 / r4.7 / r20 / Fast-Track.

## What remains for the PI

The adoption-scope decision on these exact bytes (r4.14-L1 + r21-L1), if the receiver confirms the L1 set: proposed scope (receiver §6) = 18 scoped reviewed scientific payloads + 2 ER-2B records explicitly outside scientific acceptance + historical unverifiable references (RRF v0.8 pins) and enumerated OPEN items (Stage-2 regional/global certificate and multi-step error control, G6, graph completion, G2 carrier, physical realization). Not described as "all 20 payloads verified" or "all old archives verified".
