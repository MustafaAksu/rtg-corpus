# RER Phase A r21-L1 — regeneration record (21 Oct 2026, preparer)

**Role.** PREPARER_ROLE. r21-L1 is the **one regeneration** of the Phase A outputs on the L1-finalized RER r4.14-L1, as instructed by the receiving co-owner's batch review of 21 Oct 2026 (§7: "regenerate linked source/hash outputs once and run a focused allowed-diff/identity check with the existing baseline"). It is not a new Phase A step (no r22) and not an acceptance.

| Object | Identity |
|---|---|
| Source RER r4.14-L1 | `032f2211229ab55d6f5f2477f19b75bb29c55a32d7574682be514b18ae0070d3` (package `RER_r4_14_L1.zip` `ca931651e8f8c6500e4ba0f2807a84981310e1246c048af341172248f8385e1d`) |
| Submitted candidate r4.14 (history) | `92f983e6…f044` (package `f86616f8…179e`) |
| Phase A r21 (history; ACCEPT SCOPED as the faithful pre-review image) | `3eb4e137…62e1`; outputs and checker record in `inputs/phaseA_r21_outputs/` |
| Baseline Phase A r20 (unchanged) | `adfedefd…3abc` (`inputs/baseline_r20.json`) |
| Receiver batch review / sidecar | `inputs/BATCH_RECEIVING_REVIEW_20261021.md` `bd80f89d…`; `inputs/REFERENCE_DISPOSITIONS_20261021.json` `3536c207…b78d`; coverage, decision, K3 proof and L1 delta files pinned |
| L1 contract | `inputs/delta_contract_r21_L1.json` (gate A37; chain r20 → r21 → r21-L1 in A35) |

## What differs from the r21 image (gate A37 enforces exactly this)

- Registry (`out/RER_REGISTRY_v0_2_r4_14_PHASEA.json`, schema `…/21-L1`): source identity (r4.14-L1 + its package, with the candidate identities kept in `source_markdown`); **RER-GEN-K3-MODAL** Review receipt / `prior_review_receipt` append-only (batch receiving decision: E-conjugacy ACCEPT SCOPED [ALG]). The other 19 records, the 4 gap entries, the 23 Reference lines and the source table are identical.
- Matrix (`out/SOURCE_CURRENCY_MATRIX.json`, schema `…/21-L1`): the **103 rows are identical** (43/2/52/6; 74/4/24/1) except that exactly the **27 reference rows** (13 historical gap + 2 historical record uses + 12 current `RRF084`) carry the new field `receiving_disposition_20261021` copied from the receiver sidecar — three held pins `AUDITED_AT_PIN`; twelve historical v0.8 uses `HISTORICAL_PIN_SOURCE_UNVERIFIED`; twelve current references `ACCEPT_SCOPED_*` (ER2B-CARRIER `…_CONTEXT_ONLY`, G10 §6.4 `…_POINTER_ONLY`). The pre-review fields `gap_reference_review` (PENDING_PER_REFERENCE_AUDIT / PROPOSED_CURRENT_REFERENCE) and `preparer_audit` are **kept unchanged as history** — the two axes the receiver asked to keep separate (current use reviewed vs. historical v0.8 bytes unverified) are now two fields. Watch item +1; catalog check label r21-L1. Owner_current, SYNC receipt, blocked register (except schema/source hash) and missing-bytes list identical.

## Checker

37 gates PASS; **221 negative controls** (170 tampers + 51 file/input), each fails its named gate. Changed vs r21: A24 (source r4.14-L1, title line "DRAFT r4.14", candidate pinned as history, r21 record kept), A28/A35 (contract chain), new **A37** (L1 identity vs the r21 image). New controls: sidecar field missing / misattached / relabelled as authenticated; pre-review field overwritten by the disposition (history erased); K3-MODAL receipt rewritten; untouched record or gap entry changed vs r21; L1 contract chain broken; sidecar altered; r21 record altered.

```
unzip RER_phaseA_r21_L1.zip && cd RER_phaseA_r21_L1
sha256sum -c SHA256SUMS.txt
python -I -B build_phaseA.py          # out/* byte-identical
python -I -B check_phaseA.py --tamper # 37/37 PASS, 221 controls, exit 0
```

## Status

RER r4.14-L1 + Phase A r21-L1 are the publication/adoption **object candidates** after the batch review. Coverage: 18 REVIEWED_SCOPED + 2 BLOCKED_SOURCE_UNVERIFIED (receiver sidecar). No adoption, freeze or publication; the PI's adoption-scope decision is separate and is made on these exact bytes if the receiver confirms the L1 set.
