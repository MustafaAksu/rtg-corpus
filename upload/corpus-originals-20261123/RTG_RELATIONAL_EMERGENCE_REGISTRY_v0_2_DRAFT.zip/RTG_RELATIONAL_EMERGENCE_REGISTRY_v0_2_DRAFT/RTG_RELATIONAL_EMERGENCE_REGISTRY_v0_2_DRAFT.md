# RTG — Relational Emergence Registry v0.2

**Status:** NONCANONICAL DRAFT — review pending. **Date:** 14 October 2026.
**Source baseline:** RER v0.1, 16 original machine entries preserved unchanged. **No physical selection, scientific RID, RRF profile or owner adoption.**

## 1. Decision and scientific boundaries

[SESSION] Synchronize conditional RER findings and RRF owner v0.8 update plan. Adopted RRF v0.7 remains governing; proposed v0.8 is not yet adopted. Dynamical closure is not physical emergence. RER local IDs are navigation keys, not owner RIDs.

[DEF] Retain the six original entry fields: carrier, observables, constraints, transformation law, closure, memory. Optional research contract:

\[\mathcal K_{\mathrm{closure}}=(S,F,O,\pi,D,p,\mathcal E).\]

The contract is NOT a mandatory RRF profile field. Record clock, action, provenance and adoption separately. Exact, finite-order, controlled approximate, nonclosure and formal-only are distinct.

## 2. RRF v0.8 plan: proposed interface guards

**RER-G7 — Full-state coincidence [THM conditional].** If a deterministic full-state update F commutes with exchange sigma, then Fix(sigma) is invariant. Physical application additionally requires full state X, physical exchange, admissible fixed initial state, encoding E, representation action R, and a common-clock intertwining E sigma=R E and E F_phys=K E. Do not equate equal coordinates, zero edge relation, exchange-fixed full configuration, and physical node merge. A projected K3 counterexample alone is not physical exclusion.

**RER-G8 — Passive transport / additive carrier [ALG conditional].** Transporting dynamics and observables under a chart H is not the same operation as imposing new additive closure in H-coordinates. ER-2B C15A–C20 are conditional noncanonical comparisons; no carrier family or quartic threshold is physically selected.

**RER-G9 — Action typing.** Cross-model orientation conjugacy (RECOG S T_k S=T_-k), within-chart involution, and physical pole exchange are distinct. CELL-F4 W1–W5 are inheritance prerequisites, not an adopted network state. RRF OPEN-A/B/E1/E2 stay OPEN.

**RER-G10 — Registry independence.** Four RRF dyad profiles remain unchanged; RRF-NET-W-RAW provisional. No independent Z2 connection, network profile, source/lowering choice or physical K3 law is introduced.

## 3. New conditional records (supplementary to 16 unchanged original records)

| Local key | Registered result | Grade |
|---|---|---|
| `RER-GEN-C01` | unsigned Gram nonclosure cubic surrogate | `ALG`; noncanonical, no owner adoption |
| `RER-GEN-C02` | signed Gram closure cubic surrogate | `ALG`; noncanonical, no owner adoption |
| `RER-GEN-C03` | signed Gram nonclosure analytic six-step modal model | `ALG`; noncanonical, no owner adoption |
| `RER-GEN-C04` | quintic common-angle harmonics 1 and 3 | `ALG`; noncanonical, no owner adoption |
| `RER-GEN-C05` | ambient delayed observable rank 4 at nonzero witnesses | `THM-CONDITIONAL`; noncanonical, no owner adoption |
| `RER-GEN-C06` | child-free c=0 invariant, local minimal dimension 2 | `THM-CONDITIONAL`; noncanonical, no owner adoption |
| `RER-GEN-C07` | nonzero kappa birth graph not invariant | `ALG`; noncanonical, no owner adoption |
| `RER-GEN-C08` | natural factor candidates fail on reachable sheets | `ALG`; noncanonical, no owner adoption |
| `RER-GEN-C09` | fixed-age sheets separate, parent-only factor fails | `ALG`; noncanonical, no owner adoption |
| `RER-TRIAD-FORMAL-AGE` | formal polynomial-in-age family and tau+1 intertwining | `THM-FORMAL`; noncanonical, no owner adoption |
| `RER-TRIAD-AGE-CURVATURE` | w13 transverse fibre curvature, fixed parent chart | `ALG`; noncanonical, no owner adoption |
| `RER-TRIAD-REGULAR-3FOLD` | regular origin-containing C1 3-fold obstruction | `THM-CONDITIONAL`; noncanonical, no owner adoption |
| `RER-ER2B-T6D` | negative typed comparison conditional modal vs historical T6d | `ALG-CONDITIONAL`; noncanonical, no owner adoption |
| `RER-ER2B-CARRIER` | passive transport versus additive carrier replacement | `ALG-CONDITIONAL`; noncanonical, no owner adoption |
| `RER-F3-N7N8` | finite jets verified; full-domain certified constants pending | `ALG-OPEN`; noncanonical, no owner adoption |
| `RER-RRF-CND01` | full-state exchange-fixed admissibility bridge | `THM-CONDITIONAL`; noncanonical, no owner adoption |

## 4. Explicit scientific safeguards

[ALG] C01–C04 concern specified surrogate/full analytic modal maps; do not overwrite the physical target `NO_TARGET_VECTOR_LAW_SELECTED`. C05–C09 concern specified local domains, finite birth ages and named observables; no universal 2D-factor no-go follows. Formal fractional-age suspension does not establish convergence or physical memory. The w13 wedge is fixed-parent-chart data, not a universal coordinate invariant.

[ALG/OPEN] N=7/8 formal defect orders are accepted. Stage1 v2 sample boxes are source-reported; Stage2 driver/coverage verifier requires integrity repairs. No full-domain certified K7,2 or K8,2 is adopted. Do not label this `CONTROLLED_APPROXIMATE_CLOSURE` yet.

[OPEN] ER-2B v0.2 C19/C20, historical T-6d producer descent, physical additive carrier, coincidence encoding/clock, RRF pole action and OPEN-M source/lowering remain unresolved.

## 5. Work queue and custody

1. Triadic + contributor: Stage2 v3.1 verifier and K=8 pilot; independent analytic-tail review before any full-region certificate.
2. Genesis/OFN/RRF: Identity–Action / Carrier–Encoding / Clock–Model contract; no physical exclusion from a projected witness alone.
3. Triadic: historical T-6d producer-to-diagnostic correspondence, independent of ER-2B.
4. RER: reconcile source hashes and owner acceptance for each supplementary record before promotion.
5. RRF: optional closure-contract reference only; do not install a mandatory profile field before an adopted reduced representation.

## 6. Provenance and review boundary

**Inspected:** RER v0.1 Markdown/JSON; supplied full RRF owner plan dated 14 Oct 2026; current project RRF v0.7 and selected Genesis/Dyadic/OFN/RECOG source metadata. Supplementary entries are assembled from conversation-reported research packages and must not be described as a fresh independent rerun. The adopted Triadic v1.6 standalone owner file and full ER-2B v0.2 evidence are not available in the active mount; original owner hashes and detailed RID pins require reauthentication.

**Version discipline:** v0.1 preserved, v0.2 working draft only; no adoption action performed.
