"""Edit list RER v0.2 DRAFT r4.3 -> r4.4: pointer synchronization after the 19 Oct 2026 owner releases
(Triadic v1.6.1 adopted; Dyadic v6.4.14; RRF v0.8.3). No record, grade or contract changes."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_3.md').read_text(encoding='utf-8')
assert hashlib.sha256(B.encode()).hexdigest() == '0dadf6e888ffc926b9c988dcd94021dc4832a873aec5406f1da0c199b885b159'
T161 = '95340abe57e999ed48681502152113d8fdb3102f74f45a25aa66c2d0092d451f'
L = B.split('\n')
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.3\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.4\n')
ed('M2', 'metadata', '**Date:** 19 October 2026 (r4.3, r4.2 and r4.1);', '**Date:** 19 October 2026 (r4.4, r4.3, r4.2 and r4.1);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.3 — two current-use wording repairs',
   '**Document status:** DRAFT r4.4 — pointer synchronization after the 19 Oct 2026 owner releases (Triadic v1.6.1 adopted; Dyadic v6.4.14; RRF v0.8.3), built deterministically on the exact r4.3 bytes (SHA-256 `0dadf6e888ffc926b9c988dcd94021dc4832a873aec5406f1da0c199b885b159`) by `build_r4_4_draft.py`; no record, grade, contract or OPEN status changes. r4.3 was: two current-use wording repairs')
# companion line
ed('C1', 'pointer', 'Dyadic v6.4.13 (adopted 18 Oct 2026; the v6.4.12.1 pin of r4 is superseded); Triadic v1.6 (adopted) and Triadic v1.6.1 DRAFT r2 (separate draft source object, not adopted; DRAFT r1 superseded as a draft); adopted RRF v0.8.2 working standard (v0.8.1, v0.8, v0.7 and v0.8-INTEGRATION-DRAFT-1 historical);',
   'Dyadic v6.4.14 (adopted 19 Oct 2026; OPEN 3 additions only; per its release record all v6.4.13 RIDs and grades are unchanged, so RER Dyadic citations stay on v6.4.13); Dyadic v6.4.13 (adopted 18 Oct 2026; byte-verified by the receiving co-owner; the v6.4.12.1 pin of r4 is superseded); Triadic v1.6.1 (adopted 19 Oct 2026, SHA-256 `' + T161 + '`; supersedes v1.6; the D3 birth-remainder scope correction is owner text; DRAFTs r1 and r2 are history); adopted RRF v0.8.3 working standard (19 Oct 2026; v0.8.2, v0.8.1, v0.8, v0.7 and v0.8-INTEGRATION-DRAFT-1 historical);')
# status summary D3 sentence
ed('S1', 'status', 'D3 (Triadic birth-remainder scope): Triadic v1.6.1 DRAFT r2 is scientifically review-ACCEPTED by the receiving co-owner (19 Oct); the PI release decision is pending and the adopted Triadic owner remains v1.6.',
   'D3 (Triadic birth-remainder scope): CLOSED at the Triadic owner — Triadic v1.6.1 adopted 19 Oct 2026 on PI authorization (metadata-only release of the review-accepted DRAFT r2; release integrity verified by the receiving co-owner).')
# RRF governance
ed('R1', 'pointer', '[DEF] Adopted RRF v0.8.2 now governs as the working representation standard (r4 repin; v0.8 and v0.8.1 historical).',
   '[DEF] Adopted RRF v0.8.3 now governs as the working representation standard (r4.4 repin; adopted 19 Oct 2026). Per its adoption record the only scientific-scope change is §2.4c, now B-6 ⇔ B-an ∧ B-3 and hence B-6 ⇒ B-an, which RER-DYAD-FORMAL-INVOLUTION already states; the RER section citations of v0.8.2 are retained as exact pins. Historical: v0.8.2 (r4 repin), v0.8 and v0.8.1.')
g10 = '**RER-G10 r4 overlay — RRF v0.8.2.**'
ed('R2', 'pointer', g10, '**RER-G10 r4.4 overlay — RRF v0.8.3.** Adopted RRF v0.8.3 (19 Oct 2026, `b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187` as reported by its adoption record) governs. Its §2.4c correction matches RER; G2 v0.4 is a noncanonical interface note; the RRF-side RER proposal remains nonnormative; profiles, R11/VF-1 guards and OPEN-A/B/E are unchanged. The r4 overlay below is retained as history.\n' + g10)
rrf = next(l for l in L if l.startswith('| `RRF082` |'))
ed('R3', 'pointer', rrf, rrf.replace('| SOURCE-READ; header-authenticated (gap G1) |', '| SOURCE-READ; header-authenticated (gap G1); r4.4: SHA-256 `f09dbb12f4b65b13c3f08ec049dcd701b04ca24c4b55876b565868f288555461` reported by the RRF v0.8.3 adoption record (not byte-verified here) |') + '\n'
   '| `RRF083` | RRF v0.8.3 ADOPTED working standard 19 Oct (§2.4c correction; G2 v0.4 noncanonical note) | `b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187` | OWNER-REPORTED (adoption record `claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3_ADOPTION_RECORD.md`); §3.1 SOURCE-READ (identical to v0.8.2); governing pin from r4.4 |')
ed('R4', 'queue', '| P1 (r4) | RRF editor | Review the r4 G7–G10 overlay against adopted v0.8.2;', '| P1 (r4) | RRF editor | Review the r4 G7–G10 overlay against adopted v0.8.3 (v0.8.2 at r4);')
# Dyadic v6.4.14
d13 = next(l for l in L if l.startswith('| `DYAD6413` |'))
ed('D1', 'pointer', d13, d13.replace('| OWNER-VERIFIED (Genesis v2.8.8 owner-pass manifest);', '| OWNER-VERIFIED (Genesis v2.8.8 owner-pass manifest); byte-hashed by the receiving co-owner (19 Oct);') + '\n'
   '| `DYAD6414` | Dyadic v6.4.14 adopted 19 Oct (OPEN 3 chart-level results: `DYAD-ALG-OPEN3-LEADING`, `DYAD-THM-OPEN3-SPIRAL-REM`; no RID removed; OPEN 20 unchanged) | `7fb8510563af17701dce7815c0a0f10771f0ff69490d22d1ea3d1af120b56bdd` | OWNER-REPORTED (release record `claude/RTG_DYADIC_v6_4_14_RELEASE_RECORD.md`; reviewer release verification pending there); not used as a citation pin — RER imports none of the added RIDs |')
# Triadic
t16 = next(l for l in L if l.startswith('| `TRIAD16` |'))
ed('T1', 'pointer', t16, t16.replace('Triadic v1.6 (adopted owner; unchanged)', 'Triadic v1.6 (adopted 5 Oct; superseded by v1.6.1 on 19 Oct; preserved)'))
r2row = next(l for l in L if l.startswith('| `TRIAD161_DRAFT_R2` |'))
ed('T2', 'pointer', r2row, r2row.replace('PI release pending |', 'released 19 Oct as v1.6.1 (metadata-only) |') + '\n'
   '| `TRIAD161` | Triadic v1.6.1 ADOPTED 19 Oct 2026 (PI authorization; metadata-only release of DRAFT r2; §§1–8 byte-identical to r2) | `' + T161 + '` | BYTE-VERIFIED by its preparer (release gates 10/10) and by the receiving co-owner (RELEASE-INTEGRITY PASS); governing Triadic pin from r4.4 |')
imp = next(l for l in L if l.startswith('Import/reference: [TRIAD161_DRAFT_R2:'))
ed('T3', 'pointer', imp, 'Import/reference: [TRIAD161: Triadic v1.6.1 (adopted 19 Oct 2026), §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md); SHA-256 `' + T161 + '`; the cited sections are byte-identical to DRAFT r2. History (r4.1–r4.3 citation): ' + imp[len('Import/reference: '):])
ed('T4', 'pointer', '[DEF] Adopted Triadic v1.6 is preserved with SHA-256 c768687cec6d52ffd358dc362cee4348f076160943564adaa461e6c7c4595b36.',
   '[DEF] Adopted Triadic v1.6 is preserved with SHA-256 c768687cec6d52ffd358dc362cee4348f076160943564adaa461e6c7c4595b36 (superseded on 19 Oct 2026 by adopted Triadic v1.6.1, SHA-256 ' + T161 + ').')
q = next(l for l in L if l.startswith('| P0 (r4) | Triadic owners | D3:'))
ed('T5', 'queue', q, '| P0 (r4) | Triadic owners | D3: DONE — Triadic v1.6.1 adopted 19 Oct 2026 (receiving review ACCEPTED r2; release integrity PASS). RER now cites v1.6.1 as the single Triadic source object. History: ' + q[len('| P0 (r4) | Triadic owners | D3: '):])
H = '[ALG] R4.3 (19 Oct 2026) answers receiving finding R42-U5'
ed('H1', 'metadata', H, '[ALG] R4.4 (19 Oct 2026) is a pointer synchronization on the exact r4.3 bytes after three owner releases of 19 Oct: Triadic v1.6.1 adopted (D3 closed at the owner; RER cites it as the single Triadic source object; the v1.6 and draft rows stay as history), Dyadic v6.4.14 (recorded; RER citations stay on v6.4.13 because no cited RID changed) and RRF v0.8.3 (now the governing working standard; its §2.4c correction matches RER). No record, grade, contract table, G5/G6 status or earlier revision text changes.\n' + H)
ed('H2', 'metadata', '**Release boundary (r4.3):**', '**Release boundary (r4.4):** r4.4 is a noncanonical review draft; it adopts, freezes and accepts nothing. **Release boundary (r4.3):**')
Path('r4_3_to_r4_4_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1), encoding='utf-8'); print(len(E), 'edits')
