# RER Phase B-07 — neutral review packet

RER Phase B-07 neutral review packet (NONCANONICAL; preparer Claude, RER co-owner). Verbatim quotations of byte-pinned sources, provenance-labelled proof material and questions; no PASS/FAIL, grade or acceptance recommendation is given for any claim.

**Review (receiver decides per record or claim: ACCEPT SCOPED, CORRECTION REQUIRED, INSUFFICIENT EVIDENCE):** `RER-TRIAD-FORMAL-INVOLUTION`, `RER-TRIAD-BIRTH-GRAPH-INVOLUTION`

**Context inventories:** B-05 inventory and B-06 packet (sources/history/) are PREPARER_AUTHORED context; the receiver decisions on them (`ACCEPT SCOPED`) cover them as packets/inventories only, not as scientific review of these records.

**Currency note:** Source RER r4.11 (2cd3f0e9…4dd8) and Phase A r17 (receiver decision of 21 Oct 2026: `ACCEPT SCOPED`). Triadic v1.6.1 is current; Genesis current v2.8.9 is owner-reported; Dyadic current v6.4.19 is owner-reported (v6.4.18 held here for comparison only).

## RER-TRIAD-FORMAL-INVOLUTION

RER r4.11 lines 906–947; span SHA-256 `b74deb4bd7b6e83db4381c03ef7204905668807bf026c404c6e36be814774264`. Byte-identical to r4.6 (lines 901–942): yes; B-06 context span SHA-256 `b74deb4bd7b6e83db4381c03ef7204905668807bf026c404c6e36be814774264`.

### Record text (verbatim)

```
### RER-TRIAD-FORMAL-INVOLUTION — Formal involution of the conditional modal map; uniqueness only at the primitive clock with linear part −I_4
**Primary grade:** [THM] for (i); [ALG] for (ii). **Exactness:** `FORMAL_ONLY` for (i); `FINITE_ORDER` for (ii). **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none (Triadic co-owner result; not owner-adopted; the preparer is not its reviewer).

| Field | Contract |
|---|---|
| Carrier | Formal germ R[[s1,s2,c1,c2]]; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | Formal state; slot actions rho_Pi = P Pi E (x) I_2. |
| Constraints | DN(0)=A(+)A, A^3=-I; F=N^6=id+G_3+O(4). Fixed conditional model; no physical selection. |
| Transformation law | S^_triad := N^3 o F^{-1/2}. Every slot permutation rho_Pi commutes exactly with N, hence with S^_triad. |
| Closure status | (i) FORMAL_UNIQUE_PRIMITIVE_CLOCK. (ii) LEMMA_K_DOES_NOT_TRANSFER: the cubic kernel is two-dimensional. |
| Memory | Formal symmetry only; no physical node exchange and no memory carrier. |

[THM] **(i) FORMAL_ONLY.** S^_triad is a formal involution with DS^(0)=-I_4 that commutes with N and with every rho_Pi, and it is the unique formal involution that both commutes with N and has linear part -I_4. Proof (dimension-free): R commutes with F hence with the unique tangent-to-identity root F^{-1/2}, so with S^; R S^ is a tangent-to-identity involution, hence the identity. The exact jet check `TRIAD_BGJ_PY` (degree ≤ 5) confirms S^S^=id, S^N=NS^, DS^=-I_4, slot commutation for all four actions, S^ != -I.

[ALG] **(ii) FINITE_ORDER.** Two dyad facts do not transfer. (a) The real commutant of A(+)A is all complex-linear maps of C^2, so involutions commuting with N need not have DR(0)=±I (the exact slot reflections are examples). (b) dim ker(ad_{X_3}) on degree-k real fields of R^4 is 0, **2**, 0, 0, 0, 0 for k=2,…,7 (dyad: 1 at k=3). [NUM] identification in chiral modes u=w1+λw2, v=w1+λ̄w2: the kernel is spanned by A=(a u|u|^2, -iβ*|u|^2 v) and B=(-iβ*|v|^2 u, a v|v|^2), a=1/6-i√3/9, β*=2√3/9, X_3=A+B (fit residual 1e-14). Hence the formal tangent-to-identity centralizer of the triad's F is not known to be {exp(sX)}, uniqueness for involutions commuting with F only is OPEN, and there is no triadic analogue of DYAD-THM-ANALYTIC-CLOCK-BRIDGE.
Formula/witness: `S = N^3 o F^(-1/2)`; `F^(-1/2) = x - g/2 + (3/8)(g o F - g) + O(7)`, g=F-id; `dim ker ad_X3 |_k = (0,2,0,0,0,0)`.

**Domain / admissibility:** Formal germ at 0; kernel dimensions exact for k ≤ 7 only.

**Map / clock:** Uniqueness at the **primitive** clock N. The six-step-only class is OPEN (G6).

**Factor or parametrization tested:** Not a factor; a symmetry classification.

**Order / error:** (i) all formal orders by proof, jet check through degree 5; (ii) exact for k=2,…,7. No convergence.

**Contract type:** `FORMAL_SYMMETRY_CLASSIFICATION`.

**Evidence:** `TRIAD_BGJ_PY` EXECUTED (Triadic contributor; RER editor replay exit 0). Kernel: exact-rational `TRIAD_CK_PY` source-executed (≈90 s); on the receiving side its run timed out after degrees 2–5, so no identical-script replay exists; the receiving co-owner built an independent alternative exact certificate (exact rank lower bounds in two prime fields matched by exact rational null vectors at k = 3), PASS (0,2,0,0,0,0) for k = 2–7, with its zero-cubic negative control failing as expected (19 Oct 2026; RECEIVER-REPORTED, files not in this package); independent float64 SVD replay `TRIAD_KR_PY` EXECUTED by the RER editor (PASS; negative control `--control-real` exits 1) — [NUM] grade; the [ALG] grade of the kernel dimensions rests on the source exact script and the independent receiving-side exact certificate. Note: β*=0 alone also yields dimension 2 (two decoupled dyads), so the dimension is not attributed to the chiral coupling.

**Review receipt:** Triadic reviewer ACCEPT (formal, 15 Oct); RER editor ACCEPT SCOPED with the primitive-clock / -I_4 scope (17 Oct). Independent scientific receiving review of the proof of (i) by a reviewer other than its author is still required before any owner adoption.
Import/reference: [TRIAD_BGJ: TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md §1] (sources/current/TRIAD_R4/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md); SHA-256 `494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413`.
Import/reference: [TRIAD_BGJ_PY: triad_formal_involution_birth_jet.py] (sources/current/TRIAD_R4/triad_formal_involution_birth_jet.py); SHA-256 `5c020986bc0ee54b4c9f0795e954e625088802253b78546a479d17fb193a9feb`.
Import/reference: [TRIAD_CK_PY: triad_cubic_centralizer_kernel_check.py] (sources/current/TRIAD_R4/triad_cubic_centralizer_kernel_check.py); SHA-256 `fac5ffe7ccfefc9ded108b413e04d2bddb1e6d3fbb1b835edea5ba88af082e91`.
Import/reference: [TRIAD_KR_PY: triad_cubic_kernel_chiral_replay.py] (sources/current/TRIAD_R4/triad_cubic_kernel_chiral_replay.py); SHA-256 `5447338c3fd30064b51e0360c0724aa9350ed8a34b3d78a5570ffaf2185f5584`.
Import/reference: [G2NOTE04: DYAD–RRF–OFN G2 consolidated note v0.4 §2] (sources/current/DYAD_RRF_OFN_G2_CONSOLIDATED_NOTE_v0_4.md); no hash printed in the source.
[OPEN] G6: six-step-only uniqueness — whether span{A,B} extends to a two-parameter formal centralizer of F.
[OPEN] Convergence of S^_triad.
[OPEN] Physical node exchange (OFN OPEN-OPA, RRF OPEN-A).

**Next test:** Solve [X,Y]=0 order by order with Y_3=B; the zero kernels at k ≥ 4 make the completion unique if unobstructed, so only the cokernel obstruction has to be computed.

**Non-transfer:** No physical node exchange; slot symmetry is not node-coincidence invariance (RRF §6.2); no identification with the dyad's R_0 or with the h-transported carrier (G2 note §5b). No automatic RRF registration or owner adoption.
```

### Imports (Phase A r17)

| n | Key | Cited | Section / lines | Bytes | Authentication | Currency | Status |
|---|---|---|---|---|---|---|---|
| 0 | `TRIAD_BGJ` | artifact `494b34f2915e` | TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md §1  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 1 | `TRIAD_BGJ_PY` | artifact `5c020986bc0e` | triad_formal_involution_birth_jet.py  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 2 | `TRIAD_CK_PY` | artifact `fac5ffe7ccfe` | triad_cubic_centralizer_kernel_check.py  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 3 | `TRIAD_KR_PY` | artifact `5447338c3fd3` | triad_cubic_kernel_chiral_replay.py  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 4 | `G2NOTE04` | DYAD–RRF–OFN G2 consolidated note v0.4 (noncanonical) `—` | DYAD–RRF–OFN G2 consolidated note v0.4 §2  | NO_HASH_PRINTED | UNAUTHENTICATED_NO_HASH | ARTIFACT_PINNED | HISTORICAL |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| (i) uniqueness proof, "Proof (dimension-free)", in the [THM] line | RER record text (r4.11) | RER record text; no other held source contains this proof sentence (X-TFI-1 lists jet identity checks only); its author is not named in the held sources |
| BGJ note §0–§1 (withdrawn claim; identity checks) | X-TFI-1 | HELD (494b34f2…9413); written by the Triadic contributor (the note says "My earlier statement"); identity of the contributor not established here |
| jet check script triad_formal_involution_birth_jet.py | X-TFI-2, X-TFI-3 | HELD (5c020986…feb); the record states a Triadic contributor run and an "RER editor replay exit 0": PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence |
| jet log triad_formal_involution_birth_jet.log (34d48bd2…4012) | pinned in X-BGI-2 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet |
| exact kernel script triad_cubic_centralizer_kernel_check.py | X-TFI-4 | HELD (fac5ffe7…0574); the record states it was source-executed (≈90 s) and that the receiving-side run of this script timed out after degrees 2–5 |
| alternative exact kernel certificate of the receiving co-owner (19 Oct 2026; two prime fields, rational null vectors at k = 3, zero-cubic control) | Evidence field | RECEIVER-REPORTED as stated in the record; NOT_HELD — identity as stated in the record or its source; bytes not in this packet; it is the receiver's own earlier work |
| float64 replay triad_cubic_kernel_chiral_replay.py | X-TFI-5 | HELD (5447338c…f5584); the record states "EXECUTED by the RER editor": PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence |
| K3 SESSION record v0.1.2 chiral identities / Genesis v2.8.6 §6.3a (d) (source of the replay's X_3) | X-TFI-5 docstring | NOT_HELD — identity as stated in the record or its source; bytes not in this packet |
| [NUM] identification of the kernel basis A, B (fit residual 1e-14) | record (ii) | RER record text; none of the four held scripts computes A, B or a fit residual (no held file prints these values) |
| G2 consolidated note v0.4 §2 | Import/reference G2NOTE04 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet (no hash printed; Phase A r17: UNAUTHENTICATED_NO_HASH) |
| Dyadic v6.4.18 §6.16 (dyad counterpart) | X-TFI-6 | OWNER (Dyadic), HELD (f70308f1…458d); comparison only; not an import of this record. Current Dyadic is v6.4.19 (OWNER_REPORTED; Phase A r17) |
| review receipts: Triadic reviewer (15 Oct); RER editor (17 Oct) | Review receipt field | NOT_HELD — identity as stated in the record or its source; bytes not in this packet; the Triadic reviewer is not identified in the held sources; the RER editor receipt: PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence |

### Questions for the receiver (no answer is implied)

- **Q-TFI-1** ((i) proof steps): The [THM] line gives a three-step proof: R commutes with F, hence with "the unique tangent-to-identity root F^{-1/2}"; hence with S^; "R S^ is a tangent-to-identity involution, hence the identity". Which facts does each step use — uniqueness of tangent-to-identity formal roots, R S^ = S^ R (needed for R S^ to be an involution), and "a tangent-to-identity formal involution is the identity" — and where, if anywhere, are they stated or cited in the held sources (X-TFI-1 has no proof; compare the dyad argument in X-TFI-6)?
- **Q-TFI-2** ((i) construction of S^): S^ := N^3 ∘ F^{-1/2} with F = N^6. Which properties are used to get S^∘S^ = id and DS^(0) = −I_4 — A^3 = −I (Constraints), N^3 commuting with F^{-1/2}, (N^3)^2 = F — and are they proved for all formal orders or checked through degree 5 only (X-TFI-2, X-TFI-3; Order/error says "(i) all formal orders by proof, jet check through degree 5")?
- **Q-TFI-3** ((i) scope): Uniqueness is claimed among formal involutions that commute with N and have linear part −I_4 (title, Closure (i), Map/clock "primitive clock N"); the six-step-only class is OPEN (G6). Is every statement of (i) in the record scoped this way?
- **Q-TFI-4** (slot commutation): The Transformation-law cell says every slot permutation ρ_Π "commutes exactly with N", and the [THM] line includes commutation with every ρ_Π. X-TFI-1/X-TFI-3 check the swaps 2↔3, 1↔2, 1↔3 and the 3-cycle through degree 5. Is the exact (all-order) commutation stated with a structural reason in any held source (Observables cell: ρ_Π = P Π E ⊗ I_2)?
- **Q-TFI-5** ((ii)(a) commutant): The record states that the real commutant of A⊕A is all complex-linear maps of C^2, so involutions commuting with N need not have DR(0) = ±I. Which property of A (A^3 = −I; eigenvalues) does this use, and which held source states it?
- **Q-TFI-6** ((ii)(b) kernel dimensions — evidence): dim ker(ad_{X_3}) = (0,2,0,0,0,0) for k = 2…7 is graded [ALG] on the exact script X-TFI-4 (held; the preparer's timing run is listed below as scheduling information only) and on the receiving co-owner's own alternative certificate (files not in this packet); X-TFI-5 is a [NUM] float64 replay from an independently built X_3 whose source (K3 SESSION v0.1.2 / Genesis v2.8.6 §6.3a (d)) is not held. Which of these does the receiver count for the [ALG] grade, and is the statement scoped to k ≤ 7 wherever it is used ("kernel dimensions exact for k ≤ 7 only")?
- **Q-TFI-7** ((ii) [NUM] kernel basis): The record gives an explicit basis A, B in chiral modes with a, β* and "fit residual 1e-14". No held script computes this basis or residual. Is the [NUM] line needed for any claim of the record, or is it descriptive?
- **Q-TFI-8** (consequences stated as non-claims): From (ii) the record concludes that the triad's formal centralizer "is not known to be {exp(sX)}", that uniqueness for involutions commuting with F only is OPEN, and that there is "no triadic analogue of DYAD-THM-ANALYTIC-CLOCK-BRIDGE". Are these worded as absence of a result (OPEN), not as negative theorems?
- **Q-TFI-9** (β* = 0 remark): The Evidence field notes that β* = 0 alone also gives dimension 2 (two decoupled dyads), and X-TFI-5 uses a different control (c0 real, b = 0). Does any line of the record attribute the dimension 2 to the chiral coupling?
- **Q-TFI-10** (grades and receipts): Record level: [THM] for (i), [ALG] for (ii); FORMAL_ONLY for (i), FINITE_ORDER for (ii). The two receipts (Triadic reviewer, RER editor) are not held; the RER editor is the preparer's role. The record itself says an independent review of the proof of (i) "is still required". What evidence does the receiver need for (i) and for (ii) separately?

### Source extracts (verbatim)

#### X-TFI-1 — BGJ note: header, §0 withdrawn claim, §1 identity checks (the note contains no written uniqueness proof)

`sources/triad/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md` lines 1–17; extract SHA-256 `4a5fbe9745cebcd0d8cba77fd67df0ecbe099170abd64780faeecdaf83b34982`

````
# Triadic: formal involution vs. birth graph, exact jets through degree 5 (15 Oct 2026)

Scope: the conditional modal model 𝒩 = (P⊗I₂)∘T_e^{×3}∘(E⊗I₂), formal jets only (exact rationals, truncation degree 5).
Nothing here is analytic, uniform or physical. RER r3.1 stays unfrozen. These are record candidates, not adoptions.

## 0. [COR] Withdrawn claim
My earlier statement Ŝ_triad(B_κ(s)) = B_κ(−s) + O(|s|⁵) was unproven, and it is **false**:
- The componentwise defect starts at degree 2.
- The graph defect starts at degree 4.

## 1. Identity checks [ALG, exact jet, degree ≤ 5]
Ŝ = 𝒩³∘ℱ^{−1/2}, with ℱ = 𝒩⁶ = id + g and ℱ^{−1/2} = x − ½g + (3/8)(g∘ℱ − g) + O(7). All of the following PASS:
- Ŝ∘Ŝ = id;
- Ŝ∘𝒩 = 𝒩∘Ŝ;
- DŜ(0) = −I₄;
- ρ_Π commutes with both 𝒩 and Ŝ, for the swaps 2↔3, 1↔2, 1↔3 and the 3-cycle;
- Ŝ ≠ −I, because its quadratic jet is nonzero.
````

#### X-TFI-2 — triad_formal_involution_birth_jet.py: docstring and imports (construction of S, list of checks)

`sources/triad/triad_formal_involution_birth_jet.py` lines 1–22; extract SHA-256 `dc5728e8f01421aa69267213ecb976409b24ea421791c9f3508a2c26f396a9c0`

````
#!/usr/bin/env python3
"""
Formal triadic involution S = N^3 o F^(-1/2) of the conditional modal map, exact jet through degree D=5,
and its interaction with the trial birth graph B_k(s) = (s, kt Q(s) M s)   (kappa = sqrt3*kt, M = [[1,-2],[2,-1]]).

Construction (formal, exact rationals, standard library only):
  F = N^6 = id + g,  g = O(|X|^3);  F^(-1/2) = (F*)^(-1/2) x = sum_k C(-1/2,k) (F* - I)^k x,
  (F* - I) x_i = g_i,  (F* - I)^2 x_i = g_i o F - g_i;  through degree 5 only k <= 2 contribute.
Checks:  S o S = id,  S o N = N o S,  DS(0) = -I,  S o R = R o S  for the slot swap R(s,c) = (s,-c),
         and for the other two slot transpositions (c = +-3s/2 fixed sets) via their linear actions.
Birth graph:
  covariance defect   D(s) = S(B(s)) - B(-s)                      (componentwise; chart-dependent)
  graph defect        G(s) = S_c(B(s)) - C(S_s(B(s)))             (zero iff S maps the graph to itself)
Both are reported as homogeneous components of degree 2..5 in s=(r,e), for kt = 1 and kt = 2 (they are affine in kt
through degree 5, because c enters at most linearly there).
Usage:  python triad_formal_involution_birth_jet.py      (exit 0 iff all identity checks pass)
"""
import sys
from fractions import Fraction as Fr
from math import factorial
D = 5
NV = 4   # X = (s_r, s_e, c_r, c_e)
````

#### X-TFI-3 — triad_formal_involution_birth_jet.py: the identity-check block (degree ≤ 5)

`sources/triad/triad_formal_involution_birth_jet.py` lines 97–121; extract SHA-256 `704b33aae38bc5ce1b5e77a69dcf158329b2a9365b330ab58860a99eb6aa3b50`

````
ok_all = True
def check(name, cond):
    global ok_all
    ok_all &= bool(cond); print(('PASS ' if cond else 'FAIL ') + name)
check('F = N^6 has linear part I and no quadratic part', all(homog(F[i], 1) == X[i] and not homog(F[i], 2) for i in range(NV)))
check('DS(0) = -I', all(homog(S[i], 1) == pscale(X[i], -1) for i in range(NV)))
SS = vcompose(S, S); check('S o S = id through degree 5', all(SS[i] == X[i] for i in range(NV)))
SN = vcompose(S, Nmap); NS = vcompose(Nmap, S)
check('S o N = N o S through degree 5', all(SN[i] == NS[i] for i in range(NV)))
# slot actions: R23 (s,c)->(s,-c); R12, R13: linear maps P Pi E (x) I2 computed from E,P
E = [[Fr(1), Fr(0)], [Fr(-1, 2), Fr(1)], [Fr(-1, 2), Fr(-1)]]
Pm = [[Fr(2, 3), Fr(-1, 3), Fr(-1, 3)], [Fr(0), Fr(1, 2), Fr(-1, 2)]]
def slot_action(perm):
    PiE = [E[perm[k]] for k in range(3)]                       # rows of Pi E
    R = [[sum(Pm[a][k]*PiE[k][b] for k in range(3)) for b in range(2)] for a in range(2)]   # 2x2 on (s,c) mode labels
    # acts on X = (s_r,s_e,c_r,c_e) as R (x) I2:  s' = R00 s + R01 c,  c' = R10 s + R11 c
    return [padd(pscale(X[0], R[0][0]), pscale(X[2], R[0][1])), padd(pscale(X[1], R[0][0]), pscale(X[3], R[0][1])),
            padd(pscale(X[0], R[1][0]), pscale(X[2], R[1][1])), padd(pscale(X[1], R[1][0]), pscale(X[3], R[1][1]))]
for name, perm in (('swap 2<->3', (0, 2, 1)), ('swap 1<->2', (1, 0, 2)), ('swap 1<->3', (2, 1, 0)), ('3-cycle', (1, 2, 0))):
    Rv = slot_action(perm)
    NR = vcompose(Nmap, Rv); RN = vcompose(Rv, Nmap)
    SR = vcompose(S, Rv); RS = vcompose(Rv, S)
    check(f'slot action {name}: commutes with N (exact model symmetry) and with S (uniqueness consequence)',
          all(NR[i] == RN[i] for i in range(NV)) and all(SR[i] == RS[i] for i in range(NV)))
check('S is NOT -I (nonzero quadratic jet)', any(homog(S[i], 2) for i in range(NV)))
````

#### X-TFI-4 — triad_cubic_centralizer_kernel_check.py, whole file (exact-rational kernel dimensions; source of the [ALG] grade of (ii)(b))

`sources/triad/triad_cubic_centralizer_kernel_check.py` lines 1–85; extract SHA-256 `9f79b47d2f0d9eec14c7f41928d8e8252dc2c9f5e0358d3e0fdad97a9d99cab1`

````
#!/usr/bin/env python3
"""Exact homogeneous kernel of ad_{X3} for the TRIAD six-step return F = N^6 of the conditional modal map
(N from triad_formal_involution_birth_jet.py, which must sit alongside). X3 = cubic part of F (= cubic of log F).
Real vector fields on R^4 = (s_r, s_e, c_r, c_e), degrees k = 2..7, exact rationals. Exit 0 iff dims = (0,2,0,0,0,0).
Contrast: for the isolated dyad, DYAD-ALG-CENT-KERNEL gives dim 1 at k = 3 (R X3 only)."""
from pathlib import Path
from fractions import Fraction as Fr
from itertools import combinations_with_replacement
src = (Path(__file__).resolve().parent / 'triad_formal_involution_birth_jet.py').read_text()
exec(src.split('# --------------------------------------------------------------- birth graph')[0].split('ok_all = True')[0])
X3 = [homog(F[i], 3) for i in range(4)]
def dpart(p, j):
    o = {}
    for m, v in p.items():
        if m[j]:
            mm = list(m); mm[j] -= 1; o[tuple(mm)] = o.get(tuple(mm), 0) + v*m[j]
    return o
def pm(a, b):  # untruncated product
    o = {}
    for m1, v1 in a.items():
        for m2, v2 in b.items():
            m = tuple(p+q for p, q in zip(m1, m2)); o[m] = o.get(m, 0) + v1*v2
    return {m: v for m, v in o.items() if v}
dX = [[dpart(X3[i], j) for j in range(4)] for i in range(4)]
def bracket(Y):  # [X3, Y]_i = sum_j X3_j d_j Y_i - Y_j d_j X3_i
    out = []
    for i in range(4):
        acc = {}
        for j in range(4):
            for t in (pm(X3[j], dpart(Y[i], j)),):
                for m, v in t.items(): acc[m] = acc.get(m, 0) + v
            for m, v in pm(Y[j], dX[i][j]).items(): acc[m] = acc.get(m, 0) - v
        out.append({m: v for m, v in acc.items() if v})
    return out
def rank(rows):
    rows = [dict(r) for r in rows if r]; r = 0; piv = {}
    basis = []
    for row in rows:
        row = dict(row)
        for c, (brow) in list(piv.items()):
            pass
        # reduce against basis
        changed = True
        for (pc, b) in basis:
            if pc in row:
                f = row[pc]
                for c, v in b.items():
                    row[c] = row.get(c, 0) - f*v
                    if row[c] == 0: del row[c]
        if row:
            pc = min(row); f = row[pc]; row = {c: v/f for c, v in row.items()}
            # back-reduce existing
            nb = []
            for (qc, b) in basis:
                if pc in b:
                    g = b[pc]; b = dict(b)
                    for c, v in row.items():
                        b[c] = b.get(c, 0) - g*v
                        if b[c] == 0: del b[c]
                nb.append((qc, b))
            basis = nb + [(pc, row)]
    return len(basis), basis
def mon(k):
    out = []
    for c in combinations_with_replacement(range(4), k):
        m = [0]*4
        for i in c: m[i] += 1
        out.append(tuple(m))
    return out
dims = {}
for k in (2, 3, 4, 5, 6, 7):
    ms = mon(k); n = 4*len(ms)
    # columns = unknown index; build the linear map: for each unknown, its bracket image; rank of image vectors
    cols = []
    for i in range(4):
        for m in ms:
            Y = [{} for _ in range(4)]; Y[i] = {m: Fr(1)}
            img = bracket(Y)
            cols.append({(ii, mm): v for ii in range(4) for mm, v in img[ii].items()})
    rk, _ = rank(cols)
    dims[k] = n - rk
    print(f'k={k}: dim X_k = {n}, kernel dim = {n-rk}', flush=True)
import sys
ok = dims == {2: 0, 3: 2, 4: 0, 5: 0, 6: 0, 7: 0}
print('expected kernel dimensions (0,2,0,0,0,0):', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
````

#### X-TFI-5 — triad_cubic_kernel_chiral_replay.py, whole file (float64 replay; [NUM])

`sources/triad/triad_cubic_kernel_chiral_replay.py` lines 1–59; extract SHA-256 `5a2f85197876d79a063f9d85c74762ea6f850bfcb8ad4d69d043930375afdff9`

````
#!/usr/bin/env python3
"""Independent replay of dim ker(ad_X3) on degree-k fields, k=2..7, for the triad six-step cubic.
Independent of triad_formal_involution_birth_jet.py: X3 is built from the K3 SESSION record v0.1.2 chiral identities
   du = c0 u|u|^2 - i b N u,  dv = c0 v|v|^2 - i b N v,  N=|u|^2+|v|^2,  c0 = 1/6 + i sqrt3/9,  b = 2 sqrt3/9
(Genesis v2.8.6 §6.3a (d)). Kernel dimension is invariant under the real-linear change (s,c) <-> (u,v).
Method: complexify (u, ub, v, vb independent); the real kernel dimension of a real operator equals the complex
kernel dimension of its complexification. Rank by numpy SVD (float64) with an explicit gap report. [NUM] replay.
Exit 0 iff dims = (0,2,0,0,0,0) and every rank decision has a singular-value gap > 1e6.
Negative control --control-real (c0 real, b = 0; rotations survive) must exit 1. Note: b = 0 alone does NOT change
the k = 3 dimension (two decoupled dyads also give 2), so it is not used as a control."""
import sys, itertools, numpy as np
c0 = 1/6 + 1j*np.sqrt(3)/9; b = 2*np.sqrt(3)/9
if '--control-real' in sys.argv: c0, b = 1/6, 0.0   # negative control: real cubic, no chiral coupling
# variables: 0=u,1=ub,2=v,3=vb ; polynomials as dict exponent-tuple -> complex
def P(*terms): return {e: c for e, c in terms}
U, UB, V, VB = (1,0,0,0), (0,1,0,0), (0,0,1,0), (0,0,0,1)
add = lambda *es: tuple(map(sum, zip(*es)))
X = [  # du, dub, dv, dvb
 P((add(U,U,UB), c0 - 1j*b), (add(U,V,VB), -1j*b)),
 P((add(UB,UB,U), np.conj(c0) + 1j*b), (add(UB,V,VB), 1j*b)),
 P((add(V,V,VB), c0 - 1j*b), (add(V,U,UB), -1j*b)),
 P((add(VB,VB,V), np.conj(c0) + 1j*b), (add(VB,U,UB), 1j*b)),
]
def d(p, j):
    o = {}
    for e, c in p.items():
        if e[j]:
            f = list(e); f[j] -= 1; o[tuple(f)] = o.get(tuple(f), 0) + c*e[j]
    return o
def mul(p, q):
    o = {}
    for e1, c1 in p.items():
        for e2, c2 in q.items():
            e = add(e1, e2); o[e] = o.get(e, 0) + c1*c2
    return o
dX = [[d(X[i], j) for j in range(4)] for i in range(4)]
def mons(k): return [e for e in itertools.product(range(k+1), repeat=4) if sum(e) == k]
dims = {}; ok = True
for k in range(2, 8):
    ms = mons(k); out = {e: n for n, e in enumerate(mons(k+2))}
    cols = []
    for i in range(4):
        for m in ms:
            Y = [{} for _ in range(4)]; Y[i] = {m: 1.0}
            col = np.zeros(4*len(out), complex)
            for a in range(4):
                acc = {}
                for j in range(4):
                    for e, c in mul(X[j], d(Y[a], j)).items(): acc[e] = acc.get(e, 0) + c
                    for e, c in mul(Y[j], dX[a][j]).items(): acc[e] = acc.get(e, 0) - c
                for e, c in acc.items(): col[a*len(out) + out[e]] += c
            cols.append(col)
    M = np.array(cols).T; s = np.linalg.svd(M, compute_uv=False)
    n = M.shape[1]; rank = int((s > 1e-9*s[0]).sum()); ker = n - rank
    gap = (s[rank-1]/max(s[rank], 1e-300)) if rank < len(s) else float('inf')
    dims[k] = ker; ok &= gap > 1e6
    print(f'k={k}: unknowns {n}, kernel dim {ker}, smallest kept sv {s[rank-1]:.3e}, next {s[rank] if rank < len(s) else 0:.3e}')
ok &= dims == {2: 0, 3: 2, 4: 0, 5: 0, 6: 0, 7: 0}
print('dims', tuple(dims.values()), '->', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
````

#### X-TFI-6 — Dyadic v6.4.18 §6.16 (dyad counterpart: formal involution, centralizer, DYAD-ALG-CENT-KERNEL) — comparison only

`sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` lines 905–952; extract SHA-256 `fe057e24c263c9c2a00067482e7da4cdd5f3588be462da335cc2c92a0756704b`

````
### §6.16 Formal Centralizer of the Six-Step Return `[ALG / THM — formal]` {#sec-6-16-centralizer}

> **[SG-14 applies]** **[SG-15 applies]** Formal mathematics about the selected $T$. Nothing here establishes convergence, an analytic or smooth involution, a physical exchange, or any factor contract.

**Provenance.** Dyadic-owner proof (16 Oct 2026), recorded in `DYAD_OPEN19_FORMAL_CENTRALIZER_PROOF_SESSION.md` v1.2. External review of v1.0 and v1.1: ACCEPT. RRF sync review v0.2: `ACCEPT SCOPED`, with the $a=0$ boundary correction applied below (Steps 2–3).

`[DEF]` **Setting.** $F=T^6$ in the raw linear frame $W=\mathcal L(\rho,\eta)$; $F=\mathrm{id}+G_3+O(|W|^4)$ with $G_3=\mu|W|^2W$, $\mu=-\tfrac12-\tfrac{2i\sqrt3}{3}$, no quadratic term (DYAD-THM-C21, §6.7). Real formal vector fields with vanishing 1-jet are written by their complex component $V(z,\bar z)$; $\mathfrak X_k$ denotes the homogeneous fields of degree $k$. $X:=\log F=X_3+X_4+\cdots$ (formal), with $X_3$ of component $V_3=\mu z^2\bar z$.

`[ALG]` [RID: DYAD-ALG-CENT-KERNEL] `[v6.4.12 r1]` **Lemma K (homogeneous kernel).** For every $k\ge2$,
$$\ker(\operatorname{ad}_{X_3})\cap\mathfrak X_k=\mathbb R\,X_3\ (k=3),\qquad =0\ (k\ne3).$$
Only $\Re\mu\ne0$ and $\Im\mu\ne0$ are used.

*Proof.*
1. *Bracket on a monomial.* For $B=c\,z^a\bar z^b$, $a+b=k$: $[X_3,B]=c\,\alpha_{a,b}\,z^{a+1}\bar z^{b+1}-\mu\,\bar c\,z^{b+2}\bar z^{a}$, with $\alpha_{a,b}=(a-2)\mu+b\bar\mu$.
2. *Coefficient equations.* The output $z^{a+1}\bar z^{b+1}$ receives the first term from $(a,b)$ and the second from $\phi(a,b)=(b+1,a-1)$ when $a\ge1$. For $a=0$ the partner $(b+1,-1)$ does not exist. The second term of the input $(0,b)$ lands on the $\bar z$-free monomial $(b+2,0)$, which receives nothing else. Hence $[X_3,Y]=0$ for $Y=\sum c_{a,b}z^a\bar z^b$ iff
$$c_{a,b}\alpha_{a,b}=\mu\,\bar c_{\phi(a,b)}\ (a\ge1),\qquad c_{0,b}\alpha_{0,b}=0,\qquad \mu\,\bar c_{0,b}=0 .$$
Outputs $(0,q)$ receive nothing. $\phi$ is an involution on $\{a\ge1\}$ with fixed points $a=b+1$.
3. *Boundary $a=0$.* $\mu\ne0$ gives $c_{0,b}=0$; this removes $(0,2)$ at $k=2$. `[COR r1]` The proof record v1.1 stated that $(p,0)$ outputs give no further condition and used the factor $b\bar\mu-2\mu$ instead. The conclusion was right; the bookkeeping is corrected here (RRF sync review v0.2).
4. *Two-element orbits* ($a\ge1$, $\phi(a,b)\ne(a,b)$). With $c_1=c_{a,b}$, $c_2=c_{\phi(a,b)}$, $\alpha_2=(b-1)\mu+(a-1)\bar\mu$: $c_1\alpha_1=\mu\bar c_2$, $c_2\alpha_2=\mu\bar c_1$. If $\alpha_2=0$ then $c_1=c_2=0$. Otherwise $c_1(\alpha_1\bar\alpha_2-|\mu|^2)=0$. The imaginary part of the factor is $\Im(\mu^2)[(a-2)(a-1)-b(b-1)]$ with $\Im(\mu^2)=2\Re\mu\Im\mu\ne0$. It vanishes only for $b=a-1$ (a fixed point, excluded) or $b=2-a$ ($k=2$); the only two-element orbit left at $k=2$ is $(1,1)\leftrightarrow(2,0)$, where the real part equals $-|\mu|^2\ne0$. So $c_1=c_2=0$.
5. *Fixed points* $(a,a-1)$, $k=2a-1$. The equation is $c\alpha=\mu\bar c$ with $\alpha=(a-2)\mu+(a-1)\bar\mu$, and $|\alpha|^2-|\mu|^2=(a-1)(a-2)\cdot4(\Re\mu)^2$. A nonzero $c$ forces $a\in\{1,2\}$. $a=1$ is linear (excluded); $a=2$ gives $k=3$, $\alpha=\bar\mu$, and $c\bar\mu=\mu\bar c$ means $c\in\mathbb R\mu$, i.e. $Y\in\mathbb RX_3$. $\square$

`[THM]` [RID: DYAD-THM-FORMAL-CENTRALIZER] `[v6.4.12 r1]` `[scope: formal category, real coefficients]` **Theorem C.** $\operatorname{Cent}_{{\rm formal},\,DG(0)=I}(F)=\{\exp(sX):s\in\mathbb R\}$.

*Proof.* Tangent-to-identity formal maps form a pro-unipotent group, so $G=\exp Y$. If $G$ commutes with $F=\exp X$ then $e^{\operatorname{ad}X}Y=Y$; since $(e^{\operatorname{ad}X}-1)=\operatorname{ad}X\cdot\psi(\operatorname{ad}X)$ with $\psi$ invertible, $[X,Y]=0$. The lowest term $Y_k$ satisfies $[X_3,Y_k]=0$, so by Lemma K $k=3$ and $Y_3=sX_3$. Then $Y-sX$ commutes with $X$ and starts above degree 3, so it vanishes by Lemma K. $\square$

`[THM]` [RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE] `[v6.4.12 r1]` `[scope: formal category]` **Corollary U.** Let $R_0:=T^3\circ F^{-1/2}=T^3\circ\exp(-\tfrac12X)$.
- (i) $R_0$ is a formal involution with $DR_0(0)=-I$ that commutes with $T$, hence with $F$.
- (ii) Every formal involution $\widehat R$ commuting with $F$ with $D\widehat R(0)=-I$ equals $R_0$.

*Proof.* (i) $T$ commutes with $F$, so $\mathrm{Ad}_TX=X$ and $T^3$ commutes with every $\exp(sX)$. Then $R_0^2=T^6\exp(-X)=\mathrm{id}$ and $DR_0(0)=A^3=-I$. (ii) $C=\widehat RR_0$ is tangent to the identity and commutes with $F$, so $C=\exp(sX)$ by Theorem C. Since $R_0$ commutes with $X$, $\widehat R^2=C^2R_0^2=\exp(2sX)=\mathrm{id}$, so $s=0$. $\square$

No normalizer is used. `[ALG]` **Identification.** For any formal Poincaré–Dulac normalizer $\widehat h$ with $\lambda$-equivariant normal form, $\widehat S=\widehat h(-I)\widehat h^{-1}$ satisfies (ii) because $-I=\lambda^3$; hence $\widehat S=R_0$. In normal-form coordinates the centralizer $\{\exp(s\widehat X)\}$ consists of $\lambda$-equivariant maps, which answers OPEN 19 as registered. $\widehat S=R_0$ is a formal identity only; see §6.15 on $S_h$.

`[ALG]` **Problem B reduction** (OPEN 20). $T^3$ is analytic and invertible near $0$ and $F^{1/2}=R_0T^3$. So $R_0$ converges iff the tangent-to-identity formal square root $F^{1/2}$ of the six-step return converges. ($T^3=R_0\circ F^{1/2}$ factors the analytic square root of $F$ with linear part $-I$.) Existence of a formal root does not imply convergence; the question is not answered here.

`[THM]` [RID: DYAD-THM-FORMAL-Z6-GENERATOR] `[v6.4.13]` `[scope: formal category]` **Canonical ℤ₆ generator.** Let $J:=T\circ\exp(-\tfrac16X)=T\circ F^{-1/6}$. Then $J^6=\mathrm{id}$, $JT=TJ$, $DJ(0)=A$, $R_0=J^3$ and $G:=J^2=T^2F^{-1/3}$. $J$ is the unique formal map commuting with $F$ with linear part $A$ and $J^6=\mathrm{id}$; likewise $G$ (order 3, linear part $A^2$).

*Proof.* $T$ commutes with $X$, so $J^6=T^6\exp(-X)=\mathrm{id}$ and $J$ commutes with $T$. If $J'$ has the stated properties, $J'J^{-1}$ is tangent to the identity and commutes with $F$, so $J'=\exp(sX)J$ (Theorem C); $J$ commutes with $X$, so $\mathrm{id}=J'^6=\exp(6sX)$ and $s=0$. The same argument applies to $G$. $\square$ (No use of the full centralizer of $T$ is needed; cf. FMS v0.5.1 R3, SESSION.)

`[ALG]` `[v6.4.13]` **Analytic realization hierarchy** (OPEN 20). Let $K:=F^{1/6}=\exp(\tfrac16X)$. (a) $K$ converges ⟺ $J=TK^{-1}$ converges ⟺ an analytic chart exists in which $T$ commutes exactly with $A$: given analytic $J$, $\Phi=\tfrac16\sum_{k=0}^5A^{-k}J^k$ satisfies $D\Phi(0)=I$, $\Phi J=A\Phi$, so $\Phi T\Phi^{-1}$ commutes with $A$; conversely, in such a chart $A^{-1}T'$ is an analytic tangent-to-identity sixth root. (b) $K$ converges ⟺ $F^{1/2}$ and $F^{1/3}$ converge: $F^{1/2}=K^3$, $F^{1/3}=K^2$, and $K=F^{1/2}\circ F^{-1/3}$, with exact commutation by the identity theorem. Hence B-6 ⇒ B-an. The admissible exactly-equivariant charts are $\{\psi\circ\Phi:\psi A=A\psi\}$.

**Finite reproductions** `[ALG]` `[scope: finite checks; not certificates of the all-order statements]`:
- `dyad_open19_kernel_check.py` (DYAD-ART-OPEN19-KERNEL): real Jacobian brackets, exact sympy, $k=2,\dots,13$; kernel dimensions $0,1,0,\dots,0$, the $k=3$ field parallel to $X_3$; exit-gated.
- `dyad_open19_a0_boundary_check.py` (DYAD-ART-OPEN19-KERNEL): the Step 2–3 boundary structure for $b=0,\dots,7$; exit-gated, negative control exits 1.
- `dyad_open19_R0_identity_cert.py` (DYAD-ART-OPEN19-R0CERT): 3 truncations ($N=6,8,12$) × 7 assertions — $R_0^2=\mathrm{id}$, $R_0f=fR_0$, $R_0F=FR_0$, $DR_0(0)=-I$, $f\circ h=h\circ n$, $\mathcal J_{\le N}(h(-I)h^{-1})=\mathcal J_{\le N}R_0$, $[R_0]_2=2h_2$; all PASS; negative control (root factor $\tfrac13$) exits 1. At $N=6$ it reproduces RECOG/RRF's $S_6$. It shares the engine of DYAD-ART-RE-REFEREE and is not an independent third implementation.
- Cross-check reference `[reviewer-reported; not owner-inspected]`: `cent.py` (SHA-256 prefix `c6189068`, suffix `4624`; complex-component method) reports kernel dimensions $0,1,0,\dots,0$ for $k=2,\dots,13$. Computational support only.

`[OPEN]` **Not established by this section:** convergence of $R_0$ and analytic or $C^\infty$ existence of a non-identity commuting involution (OPEN 20); exact commutation of a $C^\infty$ six-step involution with $T$; physical exchange or G2 realization (SG-14/15, RRF OPEN-A, OFN OPEN-OPA); equivalence of $EF=TE$ and $EF=T^6E$.
````

## RER-TRIAD-BIRTH-GRAPH-INVOLUTION

RER r4.11 lines 950–991; span SHA-256 `4f69e4ad224ccbe71802e02e741c427e6f9452605c03eba2f3cca4ce62918645`. Byte-identical to r4.6 (lines 945–986): yes; B-06 context span SHA-256 `4f69e4ad224ccbe71802e02e741c427e6f9452605c03eba2f3cca4ce62918645`.

### Record text (verbatim)

```
### RER-TRIAD-BIRTH-GRAPH-INVOLUTION — Birth graph under S^_triad: degree-4 graph defect, unique even completion, no permutation of age sheets
**Primary grade:** [ALG]. **Exactness:** `FORMAL_ONLY` with exact jets through degree 5. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none (Triadic co-owner result; not owner-adopted; the preparer is not its reviewer).

| Field | Contract |
|---|---|
| Carrier | Trial birth graph B_kappa(s)=(s, kappa~ Q(s) M s), M=[[1,-2],[2,-1]], kappa=sqrt3 kappa~ (= Genesis c_0^{[3]}=kappa Qs J_Q s); formal age family C(s,tau) (RER-TRIAD-FORMAL-AGE). kappa is the Triadic birth coefficient; it is not the Genesis mean-feedback parameter gamma. |
| Observables | Covariance defect D(s)=S^(B(s))-B(-s); graph defect G(s)=S^_c(B)-C(S^_s(B)). |
| Constraints | Fixed real kappa~; formal; the age-sheet statement uses the pinned kappa~=1 table POLY. |
| Transformation law | Covariance (D) and graph invariance (G) are separate contracts; D's degree-2/3 parent terms are effects of S^'s nonlinear chart, not graph data. |
| Closure status | (a) The cubic graph is not S^-invariant: G vanishes at degrees 2–3, is first nonzero at degree 4, and is exactly kappa~-linear. (b) Unique even completion C_4=G_4/2; with it the defect vanishes through degree 5. (c) S^ maps no age sheet onto any age sheet (kappa~=1). |
| Memory | Formal graph geometry; selects no birth initialization, post-birth law or memory carrier. |

[ALG] **(a)** G_4 = kappa~·[3/4 r^4 - 4 r^3 e + 6 r^2 e^2 - 6 r e^3 + 11/4 e^4, 11/4 r^4 - 7 r^3 e + 9 r^2 e^2 - 7 r e^3 + 2 e^4] != 0; D_parent nonzero from degree 2 and kappa-free through degree 5; D_child zero at degrees 2–3, first nonzero at degree 4, proportional to kappa~. [COR] (contributor, 15 Oct) the earlier claim S^(B_kappa(s)) = B_kappa(-s) + O(|s|^5) is withdrawn.
[ALG] **(b)** For c=C_3+C_4+O(5) the degree-4 graph defect is G_4[C_3]-2C_4 (checked for a generic quartic), so C_4=G_4/2 is the unique degree-4 completion; with it the defect vanishes through degree 5 (kappa~=1,2); odd terms C_5 drop out of G_5. Scope: a formal completion through degree 5; all-order existence not claimed.
[ALG] **(c)** POLY has C_4 ≡ 0 for every tau (deg_tau C_4 ≤ 0), so the S^-image of every sheet has quartic Phi_4=G_4 != 0 and is not a sheet tau' for any real tau'.
[ALG] **(d) Remainder-order bookkeeping under a stated child contract.** Child contract used here: the child functional is the graph value itself — a birth places the state on c=C(s) over the current parent inside the conditional modal model; its remainder order p is the leading degree of C(s)-kappa Qs J_Q s. Under this contract the S^-invariant completion has p=4 (C_4 != 0 for kappa~ != 0) and every formal age sheet has p ≥ 5 (C_4 ≡ 0). So, under this contract, S^-compatibility of the birth graph and the Genesis fifth-order branch (OPEN 5/2B, GCL-06) are mutually exclusive. [OPEN] Which child functional, if any, is physical; whether birth is a graph initialization at all; whether either graph is the post-birth law; selection of the p=4 or p=5 branch. An S^-compatible graph existing does not select p=4, and the age family does not select p=5. Adopted Triadic v1.6.1 (§6.1, §6.15, §6.17.2, §7.2, CN-02) states the complete-child remainder and the full-child phase/ratio estimates conditionally on Genesis GCL-06 and the selected child functional. It does not adopt the RER formal-involution graph contract of this record or select the physical p=4 / p≥5 branch. The r4–r4.4 reference to Triadic v1.6.1 DRAFT r1 at this point is historical.
Formula/witness: `G = S_c(B) - C(S_s(B))` first nonzero at degree 4; `G4[C3+C4] = G4[C3] - 2 C4`; `Phi4 = G4 - C4`.

**Domain / admissibility:** Formal; jets through degree 5; (c) on the kappa~=1 table; kappa~-linearity of G_4 extends (a),(b) to every kappa~.

**Map / clock:** S^_triad of RER-TRIAD-FORMAL-INVOLUTION (primitive-clock involution). Contrast: RER-GEN-C07 measures the F-invariance defect of the same graph at degree 5; different object.

**Factor or parametrization tested:** Graph invariance and covariance under the formal involution; not a factor.

**Order / error:** Exact jets through degree 5; no convergence, no remainder constant.

**Contract type:** `GRAPH_INVARIANCE_TEST_UNDER_FORMAL_SYMMETRY_NOT_FACTOR`.

**Evidence:** `TRIAD_BGJ_PY` and `TRIAD_GC_PY` EXECUTED (Triadic contributor; RER editor replays exit 0); POLY re-hashed unchanged.

**Review receipt:** RER editor ACCEPT SCOPED (17 Oct) with the explicit child contract in (d). Independent scientific receiving review by a reviewer other than the author is still required before any owner adoption.
Import/reference: [TRIAD_BGJ: §§2–4] (sources/current/TRIAD_R4/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md); SHA-256 `494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413`.
Import/reference: [TRIAD_GC_PY: triad_involution_graph_completion.py] (sources/current/TRIAD_R4/triad_involution_graph_completion.py); SHA-256 `024c9ad1ee5d36ecc088de1e8301109c75fd236d524987ce4a2e681cf89a0574`.
Import/reference: [POLY: age_family_polynomials_kt1.json] (sources/current/age_family_polynomials_kt1.json); SHA-256 `03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c`.
Import/reference: [GEN287: §2 OPEN 5/2B remainder-order guard; §6.3 GCL-06] (sources/current/RTG_GENESIS_GEOMETRY_DSN_v2_8_7.md); SHA-256 `d5d1e57c6eea0800cf8bf3e3f6b5905873e719df0969d15144ca55197cd2e361`.
Import/reference: [TRIAD161: Triadic v1.6.1 (adopted 19 Oct 2026), §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md); SHA-256 `95340abe57e999ed48681502152113d8fdb3102f74f45a25aa66c2d0092d451f`; the cited sections are byte-identical to DRAFT r2. History (r4.1–r4.3 citation): [TRIAD161_DRAFT_R2: Triadic v1.6.1 DRAFT r2, §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r2.md); DRAFT, not adopted; SHA-256 `dd67907fc21e457e413c3d6ee924617bc7818c1c200a9bde04fb67649d79b3e7`. r4 cited DRAFT r1 (`31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea`) at sources/current/TRIAD_R4/, while the r4 package held that file at sources/current/ (path erratum); r4.1 places both drafts under sources/current/TRIAD_R4/. Record (d) is independent of the Triadic D3 decision (receiving review, 19 Oct).
[OPEN] All-order existence of the even completion; analytic realization.
[OPEN] Which graph, if any, is the physical birth initialization; physical p-branch selection.

**Next test:** Extend (b) to degree 7: is the degree-6 even completion forced and the degree-7 defect automatic?

**Non-transfer:** No physical birth law, reset or healing inference, compulsory memory, or selection of the p=4 branch. No automatic RRF registration or owner adoption.
```

### Imports (Phase A r17)

| n | Key | Cited | Section / lines | Bytes | Authentication | Currency | Status |
|---|---|---|---|---|---|---|---|
| 0 | `TRIAD_BGJ` | artifact `494b34f2915e` | §§2–4  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 1 | `TRIAD_GC_PY` | artifact `024c9ad1ee5d` | triad_involution_graph_completion.py  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 2 | `POLY` | kappa_tilde=1 / through degree 9 `03042f84016a` | age_family_polynomials_kt1.json  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 3 | `GEN287` | 2.8.7 `d5d1e57c6eea` | §2 OPEN 5/2B remainder-order guard; §6.3 GCL-06  | PRINTED_ONLY | RECEIVER_BYTE_VERIFIED | UNCHANGED_OWNER_REPORTED | OWNER_REPORTED |
| 4 | `TRIAD161` | 1.6.1 `95340abe57e9` | Triadic v1.6.1 (adopted 19 Oct 2026), §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries  | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | CURRENT | VERIFIED |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| BGJ note §§2–4 (D, G, consequences) and §5–§6 | X-BGI-1, X-BGI-2 | HELD (494b34f2…9413); Triadic contributor |
| birth-graph section of triad_formal_involution_birth_jet.py | X-BGI-3 | HELD (5c020986…feb); the record states contributor runs and RER editor replays: PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence |
| completion script triad_involution_graph_completion.py | X-BGI-4 | HELD (024c9ad1…0574); needs the jet script alongside; RER editor replay: PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence |
| completion log triad_involution_graph_completion.log (206ec8d3…ec84) | pinned in X-BGI-2 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet |
| κ̃ = 1 age-family table (degree-3/4 entries) | X-BGI-5 | HELD (03042f84…d83c); the table is the one used by RER-TRIAD-FORMAL-AGE; none of the held scripts reads it |
| formal age family C(s,τ) | RER-TRIAD-FORMAL-AGE (B-06) | separate RER record; its B-06 receiver decisions apply to it, not to this record |
| Genesis v2.8.7 §2 OPEN 5/2B and §6.3 GCL-06 | Import/reference GEN287 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet; Phase A r17: RECEIVER_BYTE_VERIFIED, OWNER_REPORTED (current Genesis v2.8.9) |
| Triadic v1.6.1 §6.1, §6.15 (D3-R1 line), §6.17.2, §7.2, §7.4 CN-02 | X-BGI-6…10 | OWNER (Triadic), HELD (95340abe…451f); Phase A r17: CURRENT |
| Triadic v1.6.1 DRAFT r1 / r2 (history citation in the TRIAD161 import line) | Import/reference TRIAD161 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet (dd67907f…b3e7, 31b87c3e…630ea) |
| RER-GEN-C07 (contrast: F-invariance defect at degree 5) | Map / clock field | separate RER record; not reviewed here |
| review receipt of the RER editor (17 Oct; wording as quoted in the record) | Review receipt field | NOT_HELD — identity as stated in the record or its source; bytes not in this packet; PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence |

### Questions for the receiver (no answer is implied)

- **Q-BGI-1** (objects): The Carrier cell defines B_κ(s) = (s, κ̃ Q(s) M s), M = [[1,−2],[2,−1]], κ = √3 κ̃, "(= Genesis c_0^{[3]} = κ Q_s J_Q s)", and S^ from RER-TRIAD-FORMAL-INVOLUTION. Are these the objects of X-BGI-1 and X-BGI-3, and is the identification with the Genesis cubic stated in a held source (X-BGI-6 §6.1)?
- **Q-BGI-2** ((a) graph defect): Compare the G_4 polynomial in (a) with X-BGI-1 §3. The record says G is "exactly κ̃-linear"; X-TFI-2 says D and G are "affine in kt through degree 5, because c enters at most linearly there". Is the κ̃-linearity scoped to degree ≤ 5 in the record (Domain: "κ̃-linearity of G_4 extends (a),(b) to every κ̃")?
- **Q-BGI-3** ((b) completion identity): (b) uses G_4[C_3 + C_4] = G_4[C_3] − 2C_4 "(checked for a generic quartic)". X-BGI-4 states the reason (DS = −I, C_4 even) and checks it. Is the identity derived for all quartics or checked on a symbolic generic quartic, and is (b) scoped as "a formal completion through degree 5; all-order existence not claimed" wherever it is used?
- **Q-BGI-4** ((c) age sheets): (c) rests on C_4 ≡ 0 for every τ in the κ̃ = 1 table (X-BGI-5: the "d4" entry) and on G_4 ≠ 0. The table lists binomial coefficients up to degree 9; "deg_τ C_4 ≤ 0" also follows from the age-family degree bound floor((d−3)/2) (RER-TRIAD-FORMAL-AGE, B-06). Which of the two does the record rely on, and is (c) scoped to κ̃ = 1 and to the comparison at degree 4?
- **Q-BGI-5** ((c) all real τ): The record and X-BGI-1 §4(b) say the S^-image of a sheet is not a sheet τ′ "for any real τ′". The comparison is made on the degree-4 jet. Does the argument use any property of the family beyond C_4 ≡ 0 and the degree-3 term being τ-independent (X-BGI-5 "d3")?
- **Q-BGI-6** ((d) contract-conditional statement): (d) states mutual exclusivity of S^-compatibility and the fifth-order branch only "under this contract" (child functional = graph value) and keeps the physical choice OPEN. Compare with X-BGI-6…10: Triadic v1.6.1 states the remainder conditionally on GCL-06 and the selected child functional and, per the record, does not adopt this graph contract. Does any line of the record select p = 4 or p = 5, or transfer (d) to Triadic?
- **Q-BGI-7** (Genesis references): (d) and the [OPEN] lines cite Genesis v2.8.7 §2 OPEN 5/2B and §6.3 GCL-06; those bytes are not in this packet (Phase A r17: receiver byte-verified earlier; current Genesis v2.8.9 owner-reported). Does the receiver need them for this decision?
- **Q-BGI-8** (dependence): This record uses S^ (RER-TRIAD-FORMAL-INVOLUTION, reviewed in the same round) and C(s,τ) (RER-TRIAD-FORMAL-AGE, B-06). If the receiver's decision on (i) of the involution record is scoped or corrected, which claims of this record are affected?
- **Q-BGI-9** (withdrawn claim and covariance): The [COR] note withdraws S^(B_κ(s)) = B_κ(−s) + O(|s|^5) (X-TFI-1 §0). The record separates covariance D (degree-2/3 parent terms from S^'s chart) and invariance G. Are these kept apart in every claim line?

### Source extracts (verbatim)

#### X-BGI-1 — BGJ note §2 covariance defect, §3 graph defect, §4 consequences

`sources/triad/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md` lines 19–45; extract SHA-256 `4736074a83e74fa4fa79343b9bf7ccab1f3af8fd46e00bef15e58c130dc26545`

````
## 2. Componentwise covariance D(s) = Ŝ(B_κ(s)) − B_κ(−s) [ALG]
B_κ(s) = (s, κ̃Q(s)Ms), with M = [[1,−2],[2,−1]] and s = (r,e).

| degree | parent | child |
|---|---|---|
| 2 | [−½r² + ½re − ¼e², −¼r² + ¼e²] (κ-free) | 0 |
| 3 | [−3/16 r³ + 5/16 r²e − 5/16 re² + 1/8 e³, −1/8 r³ + 3/16 r²e − 1/16 re² − 1/16 e³] (κ-free) | 0 |
| 4 | κ-free (see log) | κ̃·[−r³e + 3/2 r²e² − 3/2 re³ + ½e⁴, ½r⁴ − 5/2 r³e + 3r²e² − 5/2 re³ + ½e⁴] |
| 5 | κ-free (see log) | ∝ κ̃ (see log) |

The degree-2 and degree-3 parent terms come from Ŝ's own nonlinear jet (Ŝ(s,0) ≠ (−s,0)). They are chart effects, not graph data.
Covariance and graph invariance are separate contracts, as the review said. D answers covariance; G below answers invariance.

## 3. Graph-invariance defect G(s) = Ŝ_c(B) − C_κ(Ŝ_s(B)) [ALG]
- G vanishes at degrees 2 and 3. It is exactly linear in κ̃: G = κ̃·G_lin, with G₀ = 0 (consistent with c = 0 being the exact 2↔3 fixed set).
- G₄ = κ̃·[¾r⁴ − 4r³e + 6r²e² − 6re³ + 11/4 e⁴, 11/4 r⁴ − 7r³e + 9r²e² − 7re³ + 2e⁴] ≠ 0.
- G₅ for the bare cubic graph: see the log (∝ κ̃).

## 4. Consequences [ALG, formal]
(a) **The defect at degree 4 is purely even-order.** For c = C₃ + C₄ + O(5), the degree-4 graph defect is G₄[C₃] − 2C₄. This was checked for a generic quartic C₄.
- So the formal Ŝ-invariant completion is unique at degree 4: C₄ = G₄/2.
- With C₄ = G₄/2, the defect vanishes through degree 5 (checked for κ̃ = 1, 2). Odd-order terms C₅ drop out of G₅.
- So "the cubic graph B_κ is not Ŝ-invariant" is a statement about that truncation. It is **not** an obstruction to the existence of an Ŝ-invariant graph tangent to it.

(b) **Ŝ does not permute the age sheets (at κ̃ = 1).** The pinned table age_family_polynomials_kt1.json (03042f84…d83c) has 𝒞₄ ≡ 0 for every τ. The degree-4 jet of each sheet is therefore the bare cubic, and the Ŝ-image of every sheet has quartic Φ₄ = G₄ − 0 = G₄ ≠ 0.
- Hence Ŝ_triad(sheet τ) is **not** an age sheet 𝒞(·, τ′) for any τ′. This holds for the formal family at all real τ, and is decided at degree 4.
- An Ŝ-compatible birth graph would have to carry the quartic G₄/2, which the Genesis-derived age family does not have.
````

#### X-BGI-2 — BGJ note §5 record-table position and §6 pins (incl. the two logs)

`sources/triad/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md` lines 47–66; extract SHA-256 `c6c5016b1f5fe3a48bbbbce1ef56c8af2b5cddfc2f044892d50fee3bf10d2dec`

````
## 5. Record-table position (agreeing with the review, plus this result)

| candidate | status |
|---|---|
| RER-DYAD-FORMAL-INVOLUTION | [THM], FORMAL_ONLY |
| RER-TRIAD-FORMAL-INVOLUTION (incl. slot commutation) | [THM], FORMAL_ONLY; jet check §1 [ALG] |
| U^{−1/2} = (ℱ^{−1/2})* | [ALG]; 𝒞(s,τ) ≠ full-state iterate |
| R_n ≈ √(19/3)(Q₀/Qₙ)^{3/2} | [ALG leading normal-form]/[NUM]; L-SHADOW-POLY [OPEN] |
| Birth graph vs Ŝ_triad | [ALG, formal, deg ≤ 5]: cubic B_κ not invariant (first defect deg 4, ∝ κ̃); unique even completion C₄ = G₄/2; age sheets not permuted (κ̃ = 1 table). Physical/Genesis birth-role transport: [OPEN] |
| Smooth/analytic realization; physical exchange | [OPEN] |

## 6. Pins
| file | SHA-256 |
|---|---|
| triad_formal_involution_birth_jet.py | 5c020986bc0ee54b4c9f0795e954e625088802253b78546a479d17fb193a9feb |
| triad_formal_involution_birth_jet.log | 34d48bd29d68f1a1e86adf38966047bc2ab96c4900b6b9b790fff628f4974012 |
| triad_involution_graph_completion.py (needs the file above alongside) | 024c9ad1ee5d36ecc088de1e8301109c75fd236d524987ce4a2e681cf89a0574 |
| triad_involution_graph_completion.log | 206ec8d3d1d1907ec459a6a989980c1259b93d35cebfe3b15f4f7a53d9e0ec84 |

Both scripts use only the Python standard library and finish in about 1 s; exit 0 means all identity checks pass.
````

#### X-BGI-3 — triad_formal_involution_birth_jet.py: birth-graph section (D and G, κ̃ = 1, 2)

`sources/triad/triad_formal_involution_birth_jet.py` lines 123–161; extract SHA-256 `d4e4f743ae9e2719d001ee5fe65cab32222ccaec8bb80a077f158d66925596a3`

````
# --------------------------------------------------------------- birth graph
def birth(kt):
    r, e = X[0], X[1]
    Q = padd(padd(pmul(r, r), pmul(r, e), -1), pmul(e, e))
    c_r = pscale(pmul(Q, padd(r, pscale(e, 2), -1)), kt)
    c_e = pscale(pmul(Q, padd(pscale(r, 2), e, -1)), kt)
    return [r, e, c_r, c_e]
def Cgraph_of(kt, sv):
    r, e = sv
    Q = padd(padd(pmul(r, r), pmul(r, e), -1), pmul(e, e))
    return [pscale(pmul(Q, padd(r, pscale(e, 2), -1)), kt), pscale(pmul(Q, padd(pscale(r, 2), e, -1)), kt)]
def fmt(p):
    if not p: return '0'
    terms = []
    for m, v in sorted(p.items(), key=lambda t: (-t[0][0], t[0])):
        mono = '*'.join(f'{x}^{k}' if k > 1 else x for x, k in zip(('r', 'e', 'cr', 'ce'), m) if k)
        terms.append(f'{v}*{mono}' if mono else str(v))
    return ' + '.join(terms)
results = {}
for kt in (Fr(1), Fr(2)):
    B = birth(kt); Bm = [compose(b, [pscale(X[0], -1), pscale(X[1], -1), X[2], X[3]]) for b in B]   # B(-s)
    SB = vcompose(S, B)
    Dv = [padd(SB[i], Bm[i], -1) for i in range(NV)]
    G = [padd(SB[2+i], Cgraph_of(kt, SB[0:2])[i], -1) for i in range(2)]
    results[kt] = (Dv, G)
    print(f'\n=== kt = {kt} ===')
    for d in range(2, D+1):
        print(f' degree {d}:  D_parent = [{fmt(homog(Dv[0], d))}] , [{fmt(homog(Dv[1], d))}]')
        print(f'            D_child  = [{fmt(homog(Dv[2], d))}] , [{fmt(homog(Dv[3], d))}]')
        print(f'            G (graph defect) = [{fmt(homog(G[0], d))}] , [{fmt(homog(G[1], d))}]')
    lowG = min([deg(m) for p in G for m in p] or [None])
    print(f' first nonzero degree of the graph defect G: {lowG}')
# kt-dependence of G (affine): kappa-free part and kt-linear part
G1, G2 = results[Fr(1)][1], results[Fr(2)][1]
Glin = [padd(G2[i], G1[i], -1) for i in range(2)]; G0 = [padd(G1[i], Glin[i], -1) for i in range(2)]
print('\nG = G0 + kt*Glin:  G0 (kt-free) =', [fmt(p) for p in G0])
print('                   Glin          =', [fmt(p) for p in Glin])
print(f'\nidentity checks: {"ALL PASS" if ok_all else "FAILURES"}')
sys.exit(0 if ok_all else 1)
````

#### X-BGI-4 — triad_involution_graph_completion.py, whole file (degree-4 completion identity; degree-5 re-evaluation)

`sources/triad/triad_involution_graph_completion.py` lines 1–40; extract SHA-256 `2d9e932403c92a089e708f4701135fa50c1caabb04feea6c784f85438cb77c71`

````
#!/usr/bin/env python3
"""
Companion to triad_formal_involution_birth_jet.py (reuses its exact jets; the parent file must sit alongside).
Question: does the S_triad-image of an age sheet c = C(s,tau) coincide with ANY age sheet?  And what is the unique
S-invariant even-order completion of the cubic graph?
  (a) degree-4 graph defect of c = C3(s) + C4(s) + O(5) is G4[C3] - 2*C4 (checked below for a generic C4), hence the
      S-image graph has quartic Phi4 = G4[C3] - C4 (DS = -I, C4 even); invariance at degree 4 iff C4 = G4[C3]/2.
  (b) with C4 := G4/2 the graph defect is re-evaluated through degree 5 (odd-degree completion terms C5 drop out of G5).
Exit 0 iff the stated identities hold.
"""
import sys
from pathlib import Path
src = (Path(__file__).resolve().parent / 'triad_formal_involution_birth_jet.py').read_text()
exec(src.split('# --------------------------------------------------------------- birth graph')[0].replace('ok_all = True', 'ok_all = True\nprint("[parent identity checks]")'))
exec(src.split('# --------------------------------------------------------------- birth graph')[1].split('results = {}')[0])
def graph_defect(Cfun):
    Bv = [X[0], X[1]] + Cfun([X[0], X[1]]); SB = vcompose(S, Bv)
    return [padd(SB[2+i], Cfun(SB[0:2])[i], -1) for i in range(2)]
def homog_s(p, d): return homog(p, d)
ok = ok_all
for kt in (Fr(1), Fr(2)):
    C3 = lambda sv, kt=kt: Cgraph_of(kt, sv)
    G = graph_defect(C3); G4 = [homog(G[i], 4) for i in range(2)]
    # (a) image graph of an arbitrary quartic C4 (test with a generic C4 and with the age-family value C4 = 0)
    gen = [padd(pscale(pmul(pmul(X[0], X[0]), pmul(X[0], X[1])), Fr(3)), pscale(pmul(pmul(X[1], X[1]), pmul(X[1], X[1])), Fr(-5))),
           pscale(pmul(pmul(X[0], X[0]), pmul(X[1], X[1])), Fr(7))]
    C34 = lambda sv, kt=kt: [padd(Cgraph_of(kt, sv)[i], compose(gen[i], sv + [X[2], X[3]])) for i in range(2)]
    Gg = graph_defect(C34)
    lin = all(homog(Gg[i], 4) == padd(G4[i], pscale(gen[i], -2)) for i in range(2))
    print(f'kt={kt}: degree-4 graph defect is G4[C3] - 2*C4 for a generic quartic C4: {"PASS" if lin else "FAIL"}'); ok &= lin
    # (b) completion
    C4 = [pscale(G4[i], HALF) for i in range(2)]
    Cc = lambda sv, kt=kt: [padd(Cgraph_of(kt, sv)[i], compose(C4[i], sv + [X[2], X[3]])) for i in range(2)]
    Gc = graph_defect(Cc)
    z4 = all(not homog(Gc[i], 4) for i in range(2)); z5 = all(not homog(Gc[i], 5) for i in range(2))
    print(f'kt={kt}: completed graph C3 + G4/2: degree-4 defect zero: {"PASS" if z4 else "FAIL"}; degree-5 defect zero: {z5}')
    if not z5: print('   G5 after completion =', [fmt(homog(Gc[i], 5)) for i in range(2)])
    ok &= z4
    print(f'   C4 = G4/2 = [{fmt(C4[0])}] , [{fmt(C4[1])}]')
print('\nall stated identities:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
````

#### X-BGI-5 — age_family_polynomials_kt1.json: degree-3 and degree-4 entries (κ̃ = 1 table; the record's (c) cites C_4 ≡ 0)

`sources/triad/age_family_polynomials_kt1.json` lines 2–35; extract SHA-256 `7e23a720b7f323293b84462987f1ec6b68ce025ebc079af011a63ec491621a95`

````
 "d3": {
  "binom0": [
   [
    "1",
    "-3",
    "3",
    "-2"
   ],
   [
    "2",
    "-3",
    "3",
    "-1"
   ]
  ]
 },
 "d4": {
  "binom0": [
   [
    "0",
    "0",
    "0",
    "0",
    "0"
   ],
   [
    "0",
    "0",
    "0",
    "0",
    "0"
   ]
  ]
 },
````

#### X-BGI-6 — Triadic v1.6.1 §6.1 (birth kinematics; D3 scope of the remainder)

`sources/owner/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md` lines 310–335; extract SHA-256 `67f04eb9e3c70cdb18f0b722f18e70390123241aafbc20f0b4d3fe5bdea28b69`

````
### §6.1 Birth Kinematics and $K_3$ Order Separation `[ALG / mixed]` {#sec-6-1-birth}

`[DEF]` **Birth map.** $\Phi_{2\to3}$ denotes the declared continuous birth family; the complete physical event remains OPEN.

`[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3 #sec-6-3-triad, one-dimensional birth theorem | RID unavailable; artifact locator `GEN-ART-PHI-2TO3`] **Leading birth kinematics.** The admissible leading child is $c_0^{[3]}=\kappa Q_sJ_Qs$, hence at leading order
$$Q_c(0)=\kappa^2Q_s^3,\qquad u(0)=\kappa^2Q_s^2 .$$
`[ALG]` `[scope: conditional on the selected child functional]` `[COR v1.6.1 — D3]` If the selected complete child functional preserves this cubic leading term and inherits a fifth-order absolute remainder (Genesis GCL-06), then $Q_c(0)=\kappa^2Q_s^3+O(Q_s^4)$ and $u(0)=\kappa^2Q_s^2+O(Q_s^3)$. If a raw six-step residual quartic is retained by the child functional, only $c_0=c_0^{[3]}+O(\|s\|^4)$, $Q_c(0)=\kappa^2Q_s^3+O(Q_s^{7/2})$ follow. v1.6 stated the fifth-order remainder unconditionally; that was the Genesis v2.8.4 wording, narrowed by Genesis v2.8.5 GCL-06 and retained in v2.8.6/v2.8.7.
`[OPEN]` Physical residual and child-functional selection (Genesis GCL-06). `[COR v1.6.1 r2 — D3-R1]` T-6u's leading ratios (§6.17) and the §7.2 reference-policy leading coefficients use only $Q_c^{[\rm lead]}$ and are unaffected. The full-child ratio and phase clauses of §6.15 and CN-02 (§7.4) do use the remainder order; they carry the $p$-dependent bounds under the same GCL-06 premise. (r1 stated that no downstream T-6 result used the remainder order; that assurance was too broad.)

`[ALG]` [scope: structure] Shear reference $\kappa=-2\sqrt3/3$; recoil reference $\kappa=-1/2$. No physical policy preference is selected.

`[ALG]` `[scope: limited]` **T-1 — isolated quartic pump coefficient.** The scoped extraction contains
$$+\frac14Q_s^2.$$
This does not establish global $K_3$ explosiveness.

`[ALG]` `[scope: historical return coefficient record]` A separate recorded return calculation contains
$$-24Q_s^2,\qquad -24Q_c^2,$$
so the coefficient magnitude ratio $24/(1/4)=96$ is exact.

`[COR]` **Correspondence status.** The ledger no longer uses 96:1 as proof that one common system's healing dominates its pump. A passive near-identity chart with identity linear part cannot reverse the cubic-return sign by itself; the missing correspondence could instead involve a different generator, lift, projection, mode or observable. Until that map is supplied, the coefficient comparison is bookkeeping and the global-explosiveness inference from T-1 is simply withdrawn/not established.

`[ALG]` `[scope: rigid diagonal birth gauge / implemented loading family]` **T-2b — Diagonal birth gauge.** Under its stated gauge,
$$d_\rho=-\frac r{\sqrt{21}},\quad d_\eta=\frac{2r}{\sqrt{21}},\quad d_z=\frac r{\sqrt3},\quad Q_d=r^2.$$
Its source/embedding interpretation remains separate from T-6t/CN-01.

`[NUM]` **T-4h — Finite-$Q_d$ escape threshold.** $Q_{s,*}^{\rm escape}\approx0.6594477844$ in the reduced Race-A model.
````

#### X-BGI-7 — Triadic v1.6.1 §6.15, D3-R1 line (p-dependent orders; non-implication witness)

`sources/owner/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md` lines 567–567; extract SHA-256 `eb10fe03469e3e6b3f857360c02f25d2d724633a55bbfa09e9b93beaa9a1f1a4`

````
`[ALG]` [scope: fixed negative reference $\kappa$, leading birth term] Both recorded policies have leading child phase $-\pi/2$. Only the unit direction has phase $+\pi/2$. `[ALG]` `[scope: conditional on the selected child functional]` `[COR v1.6.1 r2 — D3-R1]` For a complete child preserving that cubic with $c_0-c_0^{[3]}=O(\|s_*\|^p)$, $p>3$, and fixed $\kappa\ne0$: $W(c_0)/W(s_*)=i\kappa Q_s+O(Q_s^{(p-1)/2})$, and for fixed negative $\kappa$ the local phase is $-\pi/2+O(Q_s^{(p-3)/2})$ (Genesis v2.8.7 OPEN 5/2B remainder-order guard, GCL-06), absent a separate higher-order directional statement. The v1.6 bounds $O(Q_s^2)$ (ratio) and $O(Q_s)$ (phase) are the $p=5$ case and require the fifth-order child contract; a transmitted raw-residual quartic ($p=4$) permits only $O(Q_s^{3/2})$ and $O(Q_s^{1/2})$. These are upper orders, not claims of nonzero drift; constants are for fixed nonzero $\kappa$. Non-implication witness `[ALG]`: on $s=(t,0)$, $t>0$, the child $c=\kappa Q_sJ_Qs+(t^4,t^4)$ preserves the cubic and gives $W(c)/W(s)=i\kappa t^2+\tfrac{1+i\sqrt3}{2}t^3$, $Q(c)=\kappa^2t^6+\sqrt3\kappa t^7+t^8$ and phase $-\pi/2-t/(2\kappa)+O(t^2)$; it is a mathematical witness (co-owner receiving review, 19 Oct 2026), not a physical child, the actual raw-residual coefficient or the RER formal graph completion. This does not change T-6m's declared fixed-direction diagnostic input or extend its dynamics to every birth completion.
````

#### X-BGI-8 — Triadic v1.6.1 §6.17.2 (leading policy family and higher-order scope)

`sources/owner/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md` lines 650–671; extract SHA-256 `c6966beb3545249edbfb69125b2777ac37acfeccac907aa310ea0e7b128c3379`

````
#### §6.17.2 Leading policy family and higher-order scope

`[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3 #sec-6-3-triad, one-dimensional birth theorem | RID unavailable] The source admissible pure-transverse birth family has leading term
$$c_0^{[3]}=\kappa Q_sJ_Qs,\qquad
Q_c^{[\rm lead]}=\kappa^2Q_s^3,\qquad
\kappa\in\mathbb R\setminus\{0\}.$$
`[ALG]` `[scope: conditional on the selected child functional]` `[COR v1.6.1 — D3]` The remainder $c_0=c_0^{[3]}+O(\|s\|^5)$ written here in v1.6 holds only if the selected child functional inherits a fifth-order remainder (Genesis GCL-06); a retained raw-residual quartic gives $O(\|s\|^4)$. T-6u uses only $Q_c^{[\rm lead]}$, so no T-6u value changes.
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; leading birth input, physical policy not selected)
`[ALG]` [scope: source reference-policy structure, not physical selection] The four-case test uses only $\kappa_{\rm shear}=-2\sqrt3/3$ and $\kappa_{\rm recoil}=-1/2$, separately imported in §6.1/§7.2. Depends on: the source pure-transverse family and fixed-policy leading limit; $Q_c^{[\rm lead]}$ denotes only its leading coefficient. Neither the physical residual nor retention is selected, and T-6m retains its own fixed-direction calculation.

`[ALG]` The leading generated numerator $Q_{d,1}^{[s^3]}=7Q_s^3/1024$ is independent of fixed $\kappa$. The isolated squared $c^3$ channel is
$$Q_{d,1}^{[c^3]}=\frac{61}{34992}\kappa^6Q_s^9,$$
which is $O(Q_s^6)$ **relative to** the leading $O(Q_s^3)$ numerator, not an absolute $O(Q_s^6)$ term.
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; channel-specific birth scaling, fixed $\kappa$)

`[COR]` The $c^3$ channel is not the only policy-dependent contribution beyond leading order. The source also contains $s^2c$ and $sc^2$ vector channels, and squared-vector interference is not a sum of isolated channel norms. The complete homogeneous cubic source supplies the following independent subleading check.

`[ALG]` [scope: exact trial $c=\kappa Q_sJ_Qs$; homogeneous cubic vector only]
$$Q\!\left(G_{3,d}(s,c,0)\right)
=\frac7{1024}Q_s^3-\frac{5\sqrt3\kappa}{1728}Q_s^4+O(Q_s^5).$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; substitution into the cubic vector polynomial only)
This additional calculation confirms the unchanged leading coefficient while preventing misuse of the $c^3$ suppression as a bound on every correction. The unknown full-return remainder has not been bounded here; no uniform finite-amplitude sixfold result is claimed.
````

#### X-BGI-9 — Triadic v1.6.1 §7.2 (revised source inputs and claim-level custody)

`sources/owner/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md` lines 807–824; extract SHA-256 `b99db581d8e5b406e59d71473ad7653a8a924d1b083e345b1bff9aa4b1dc86c7`

````
### §7.2 Revised source inputs and claim-level custody

The entries below identify the exact inspected source statements; no module or artifact identifier is borrowed as a theorem-specific RID. Requests beginning `REQ-T16-` are local governance tracking keys, not newly assigned Genesis RIDs. All uses remain conditional on the source model; this consumer does not promote its physical premises.

- `[DEF]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.1 #sec-6-1-primitive, Quadratic form | RID: GEN-DEF-PRIMITIVE-METRIC; invariance $A^\top BA=B$: GEN-THM-PRIMITIVE-METRIC-INVARIANCE] **Metric definition.** $B$ and $Q(v)=v^TBv$ are the fixed primitive convention used in §§6.1/6.15–6.17. Source status: `[DEF]`/`[THM]`. Depends on: the stated real two-component carrier. Verification: source-read; matrix properties rechecked in the new certificate. Governance: REQ-T16-METRIC resolved in v1.6.1 — owner RIDs assigned by Genesis v2.8.5 §6.1 and retained in v2.8.7.
- `[ALG]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.6 #sec-6-6-phase, Symplectic phase-drift operator | RID unavailable; artifact locator `GEN-ART-JQ-PHASEDRIFT`; v1.6.1 repin, value unchanged] **Oriented quarter-turn.** The stated $J_Q$, $J_Q^2=-I$ and $a^TBJ_Qb=(\sqrt3/2)\omega_{ab}$, with $\omega_{ab}=a_2b_1-a_1b_2$. Source status: `[ALG]`. Depends on: that $B$ and ordered wedge convention, not the differently normalized T-6d variable. Verification: source-read and exact algebra rerun. Governance: REQ-T16-JQ; owner assignment pending.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3 #sec-6-3-triad, one-dimensional birth theorem | RID unavailable] **Leading admissible birth family.** $c_0^{[3]}=\kappa Q_sJ_Qs_*$, hence $Q_c=\kappa^2Q_s^3$ at leading order. Source status: `[THM]`. Depends on: the source admissible pure-transverse family and fixed nonzero real $\kappa$; physical event/residual/retention selection is not part of this import. Verification: source-read against adopted v2.8.7 (§1 and §6.3 wording retained from v2.8.5 GCL-06); leading algebra checked, historical microscopic proof not rerun. Governance: REQ-T16-BIRTH; owner assignment pending; `GEN-ART-PHI-2TO3` is an artifact locator only.
- `[ALG]` `[scope: conditional on the selected child functional]` `[COR v1.6.1 — D3]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §1 and §6.3, remainder clause | RID unavailable] **Birth remainder order.** If the selected complete child functional preserves the cubic leading term and inherits a fifth-order absolute remainder, then $c_0=c_0^{[3]}+O(\|s_*\|^5)$ and $Q_c=\kappa^2Q_s^3+O(Q_s^4)$; if a raw-residual quartic is retained, $c_0=c_0^{[3]}+O(\|s_*\|^4)$ and $Q_c=\kappa^2Q_s^3+O(Q_s^{7/2})$ are not excluded. v1.6 imported the fifth-order form unconditionally from v2.8.4. Source status: conditional `[ALG]`/`[OPEN]` in Genesis (GCL-06). Depends on: the child-functional selection, which is OPEN in Genesis. Formal instance (reference only, noncanonical): RER r4 candidate RER-TRIAD-BIRTH-GRAPH-INVOLUTION, where the $\widehat S_{\rm triad}$-compatible completion of the same leading graph carries a nonzero quartic.
- `[ALG]` [scope: structure] [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3 #sec-6-3-triad, Shear policy | RID unavailable; v1.6.1 repin, value unchanged] **Shear reference.** $\kappa=-2\sqrt3/3$, $Q_c^{[\rm lead]}=4Q_s^3/3$. Source status: `[ALG structure]`, rendered canonically above without a grade change. Depends on: the chosen shear prescription and leading birth family. Verification: source-read and specialization checked. Governance: REQ-T16-SHEAR; no physical preference assigned.
- `[ALG]` [scope: structure] [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.3 #sec-6-3-triad, Recoil policy | RID unavailable; v1.6.1 repin, value unchanged] **Recoil reference.** $\kappa=-1/2$, $Q_c^{[\rm lead]}=Q_s^3/4$. Source status: `[ALG structure]`. Depends on: the chosen recoil prescription and leading birth family. Verification: source-read and specialization checked. Governance: REQ-T16-RECOIL; no physical preference assigned.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.4 #sec-6-4-tetrahedral, Tetrahedral chronological protection | RID unavailable; v1.6.1 repin, statement unchanged] **Block order.** $G_2=0$ for the specified primitive six-step block; radial amplitude starts at quartic order. Source status: `[THM]`. Depends on: the source common linear block and chronological/parity construction, not an arbitrary post-birth map. Verification: source-read, not microscopically regenerated. Governance: REQ-T16-CHRONO.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.5 #sec-6-5-quartic, Full primitive quartic drift | RID unavailable; v1.6.1 repin, polynomial unchanged] **Radial polynomial.** The printed $\mathcal P_4=2d^TBG_{3,d}$ is the input to the zero-apex derivative calculation. Source status: `[THM]`. Depends on: that six-step block, chronological protection, $B$ and wedge convention. Verification: complete polynomial inspected/transcribed, not a rerun of `genesis_k4_route_census.py`. Governance: REQ-T16-P4.
- `[ALG]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.5 #sec-6-5-quartic, Vector apex seeding | RID unavailable; artifact locator `GEN-ART-G3D-SEED`; v1.6.1 repin, values unchanged] **Generated vector seeds.** $Q(V_s)=7Q_s^3/1024$ and $Q(V_c)=61Q_c^3/34992$. Source status: `[ALG]`. Depends on: the preceding polynomial/block and its zero-apex derivative. Verification: source-read and independently re-extracted from those printed premises; `GEN-ART-G3D-SEED` is an artifact locator, not a result RID. Governance: REQ-T16-VSEED.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.6 #sec-6-6-phase, Birth symmetry theorem | RID unavailable; v1.6.1 repin, values unchanged] **Seeded cross-invariants.** $I_{V_s,s}=\omega_{V_s,s}=-Q_s^2/16$. Source status: `[THM]`. Depends on: the stated birth gauge and oriented source carrier. Verification: source-read; both identities and the local $D_{\rm birth}$ evaluation rechecked. Governance: REQ-T16-BSYMM; `GEN-ART-JQ-PHASEDRIFT` remains only an artifact locator.
- `[DEF]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §2 OPEN-GEN-II-HINDEX, displayed norm and status-table definition row | module locator `GEN-OPEN-HINDEX`; v1.6.1 repin, definition unchanged; Genesis GCL-03 (v2.8.5) makes the lowering $S_f=Bc_f$ a conditional bridge, which does not alter the imported norm definition] **HINDEX norm definition.** $\|H\|_B^2=\lambda_{\max}(B^{-1}H^TB^{-1}H)$ for the stipulated covector-valued source block. Source status: the definition row is `[DEF/ALG]`; only that definition is imported, while local consequences have their own `[ALG]` statements. Depends on: input metric $B$ and output covector metric $B^{-1}$. Verification: exact source row inspected; local coherent-family calculation rerun. Governance: REQ-T16-HINDEX; `GEN-OPEN-HINDEX` is a module locator, not a substitute claim RID. No proof that a physical child seed equals this source operator is imported.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.7 §6.5 #sec-6-5-quartic, standalone chiral admissibility polynomial | GEN-THM-DELTA-QC; v1.6.1 repin, polynomial unchanged] **Standalone radial input for consistency notice CN-03.** $P_c=Q_c^2/3+(I_{sc}+\omega_{sc})^2/4+5\omega_{sc}^2/16$. Source status: `[THM]`. Depends on: the stated standalone branch and primitive wedge convention. Verification: source-read; the $I_{sc}=0$ sign-even specialization is checked locally. This does not import the downstream GSPLIT interpretation back into Triadic.

**Claim-level proof direction:** Genesis primitive definitions/theorems → Triadic successor algebra → Genesis/OPEN-M consumer applications. The frame-map, GSPLIT interface conclusion and RRF are reference-only pointers. `apex_ratio_setup.py` is consumer-side verification if recovered, not a source of ownership; it and the microscopic route census are not present in the supplied package. The three historical Triadic certificates, in contrast, have been recovered and rerun with their original bytes (§8).
````

#### X-BGI-10 — Triadic v1.6.1 §7.4 CN-02 block (with the CN-03 text that follows it)

`sources/owner/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md` lines 845–856; extract SHA-256 `9a4867d7f7125bb49c10046eec33cc5eae9d270351f5a1f1c3988a44aba5684f`

````
**CN-02 — Genesis WPHASE and dependent OPEN-M uses.** Targets: Genesis v2.8.4 §2 / §8 `GEN-OPEN-WPHASE` and `GEN-ART-WPHASE` (§8, source line 907); OPEN M v0.6 AUDIT-1-DIMENSIONAL/R-CHIRALITY-CLOSURE and summaries using the old unit ratio as a physical child ratio. Let $\mu_6=-1/2-2i\sqrt3/3$ as in the inherited cubic record (§7.1), and distinguish the face-phase diagnostic $F_{\rm face}$ below from the return map also denoted $F_W$ in other studies:
$$F_{\rm unit}=\frac\pi2+\arg\mu_6\approx-0.4086378551,$$
$$F_{\rm face}^{(0)}=-\frac\pi2+\arg\mu_6\approx-3.5502305087\equiv2.7329547985\pmod{2\pi}\qquad(\kappa<0).$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; fixed eigenframe; leading signed-child phase diagnostic)
`[ALG]` The leading signed factor has constant phase for fixed sign of $\kappa$; both registered policies are negative. A positive-$\kappa$ policy shifts this phase by $\pi$. `[COR v1.6.1 r2 — D3-R1]` For a complete child with $c_0-c_0^{[3]}=O(\|s\|^p)$, $p>3$ (selected child functional, Genesis GCL-06), the full family obeys $F_{\rm face}=F_{\rm face}^{(0)}+O(Q_s^{(p-3)/2})$ unless higher-order directional preservation is separately established: $O(Q_s)$ under the fifth-order child contract, only $O(Q_s^{1/2})$ if a raw-residual quartic is transmitted. Thus leading phase-amplitude independence survives, but the amplitude ratio $i\kappa Q_s+O(Q_s^{(p-1)/2})$ is not amplitude-sterile, and exact full-phase independence is not proved. This sign correction agrees with the declared T-6m reference angle; it does not rederive its flow or select a physical energy-to-source relation. Genesis should rename its face-phase symbol to $F_{\rm face}$, or annotate it unambiguously at every live use, to distinguish it from the six-step return $F_W$ in Dyadic/RECOG/RRF. The `GEN-ART-WPHASE` entry still lists the retracted $F_W(\eta_*)$ target as `[OPEN]`; reconcile that artifact description with the withdrawn parametrization while retaining its history. A convention-only notation entry may be proposed to RRF; no RRF profile or claim is registered here. **Consumer status: OPEN; update sign, extent, symbol and artifact interpretation at each use.**

**CN-03 — Positive GSPLIT consistency, without reverse proof dependency.** Reference target: Genesis v2.8.4 `GEN-OPEN-WPHASE-GSPLIT`. The load-bearing input is the upstream standalone polynomial `GEN-THM-DELTA-QC` imported in §7.2, not the downstream interpretation. At $I_{sc}=0$, the primitive Gram identity gives $\omega_{sc}^2=4Q_sQ_c/3$ and hence
$$\left.P_c\right|_{I_{sc}=0}
=\frac13Q_c^2+\frac9{16}\omega_{sc}^2
=\frac13Q_c^2+\frac34Q_sQ_c.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; sign-even algebraic specialization of the imported standalone polynomial)
`[ALG]` This expression is unchanged by the child sign reversal $\omega_{sc}\mapsto-\omega_{sc}$. It supports retaining the GSPLIT polynomial across the directional correction; it does not determine any other amplitude interpretation. This check requires the exact $I_{sc}=0$ diagnostic, not every higher-order birth completion. **Consumer status: positive consistency notice; no Genesis record altered.**
````

## Preparer runs (timing only — not receiver evidence)

| Script | Wall time | Normal mode | Negative mode |
|---|---|---|---|
| triad_formal_involution_birth_jet.py | ≈1 s | exit 0, last line "identity checks: ALL PASS" | — |
| triad_involution_graph_completion.py (jet script alongside) | ≈1 s | exit 0, last line "all stated identities: PASS" | — |
| triad_cubic_kernel_chiral_replay.py (numpy 2.5.3) | ≈0.6 s | exit 0, "dims (0, 2, 0, 0, 0, 0) -> PASS" | --control-real: exit 1, "dims (0, 6, 0, 0, 0, 0) -> FAIL" |
| triad_cubic_centralizer_kernel_check.py (jet script alongside) | ≈101 s | exit 0, "expected kernel dimensions (0,2,0,0,0,0): PASS" | — |
