"""RER Phase B-07 neutral review packet (preparer: Claude, RER co-owner; NONCANONICAL).
Scope (receiving decision of 21 Oct 2026): two Triadic records for independent receiving review -- RER-TRIAD-FORMAL-INVOLUTION and
RER-TRIAD-BIRTH-GRAPH-INVOLUTION -- on RER r4.11 and Phase A r17. The B-05/B-06 context inventories may be used; they are not acceptance.
The packet quotes byte-pinned sources, lists proof material with its provenance and states questions. It gives no PASS/FAIL, grade or
acceptance recommendation for any claim; the receiver decides ACCEPT SCOPED / CORRECTION REQUIRED / INSUFFICIENT EVIDENCE per record or claim.
Usage: python -I -B b07_packet.py              -> verify inputs, build, write B07_REVIEW_PACKET.json/.md; exit 0 iff all gates pass
       python -I -B b07_packet.py --check      -> verify and compare with the stored outputs byte for byte (no write)
       python -I -B b07_packet.py --negcontrol -> negative controls (each must make its gate fail); exit 0 iff all do"""
import sys, re, json, hashlib, copy
from pathlib import Path
HERE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
FILES = {
 'RER11': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_11.md', '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8'),
 'RER6': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md', '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'),
 'MATRIX17': ('sources/rer/PHASEA_r17_SOURCE_CURRENCY_MATRIX.json', '4ff673cf6967b57463e2b36f611047a44d6eb9b2ed54bd2f5a80918fce08c9d0'),
 'BGJ': ('sources/triad/TRIAD_FORMAL_INVOLUTION_BIRTH_GRAPH_JET_20261015.md', '494b34f2915e6922e4b36c2bcee242b454c2e7ac5f60670b49d6a82648a89413'),
 'BGJPY': ('sources/triad/triad_formal_involution_birth_jet.py', '5c020986bc0ee54b4c9f0795e954e625088802253b78546a479d17fb193a9feb'),
 'CKPY': ('sources/triad/triad_cubic_centralizer_kernel_check.py', 'fac5ffe7ccfefc9ded108b413e04d2bddb1e6d3fbb1b835edea5ba88af082e91'),
 'KRPY': ('sources/triad/triad_cubic_kernel_chiral_replay.py', '5447338c3fd30064b51e0360c0724aa9350ed8a34b3d78a5570ffaf2185f5584'),
 'GCPY': ('sources/triad/triad_involution_graph_completion.py', '024c9ad1ee5d36ecc088de1e8301109c75fd236d524987ce4a2e681cf89a0574'),
 'POLY': ('sources/triad/age_family_polynomials_kt1.json', '03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c'),
 'TRIAD161': ('sources/owner/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1.md', '95340abe57e999ed48681502152113d8fdb3102f74f45a25aa66c2d0092d451f'),
 'DYAD6418': ('sources/owner/RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md', 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'),
 'B05INV': ('sources/history/RER_PHASE_B05_NEUTRAL_SOURCE_INVENTORY_20261020.json', 'b9a978dad834f7a0c21344ac4088e89ae6a779312b43dd417facbdd7fb0aa5e7'),
 'B05INVMD': ('sources/history/RER_PHASE_B05_NEUTRAL_SOURCE_INVENTORY_20261020.md', 'fcf7a081658f22a221f3cadf17e708476a494f81aa40a3911673beee5f04ebf4'),
 'B06PKT': ('sources/history/B06_REVIEW_PACKET.json', 'ad9e37285acab8cb5554467f8a022c389ee56cc8fd9d361a52348ce5d440d9e0'),
}
REVIEW = ['RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION']
# verbatim extracts: (id, record, file key, start-line prefix, end rule, label); end rule = ('prefix', p) | ('line',) | ('end',)
EXTRACTS = [
 ('X-TFI-1', 'RER-TRIAD-FORMAL-INVOLUTION', 'BGJ', '# Triadic: formal involution', ('prefix', '## 2. '), 'BGJ note: header, §0 withdrawn claim, §1 identity checks (the note contains no written uniqueness proof)'),
 ('X-TFI-2', 'RER-TRIAD-FORMAL-INVOLUTION', 'BGJPY', '#!/usr/bin/env python3', ('prefix', '# --------------------------------------------------------------- sparse'), 'triad_formal_involution_birth_jet.py: docstring and imports (construction of S, list of checks)'),
 ('X-TFI-3', 'RER-TRIAD-FORMAL-INVOLUTION', 'BGJPY', 'ok_all = True', ('prefix', '# --------------------------------------------------------------- birth graph'), 'triad_formal_involution_birth_jet.py: the identity-check block (degree ≤ 5)'),
 ('X-TFI-4', 'RER-TRIAD-FORMAL-INVOLUTION', 'CKPY', '#!/usr/bin/env python3', ('end',), 'triad_cubic_centralizer_kernel_check.py, whole file (exact-rational kernel dimensions; source of the [ALG] grade of (ii)(b))'),
 ('X-TFI-5', 'RER-TRIAD-FORMAL-INVOLUTION', 'KRPY', '#!/usr/bin/env python3', ('end',), 'triad_cubic_kernel_chiral_replay.py, whole file (float64 replay; [NUM])'),
 ('X-TFI-6', 'RER-TRIAD-FORMAL-INVOLUTION', 'DYAD6418', '### §6.16', ('prefix', '### §6.17'), 'Dyadic v6.4.18 §6.16 (dyad counterpart: formal involution, centralizer, DYAD-ALG-CENT-KERNEL) — comparison only'),
 ('X-BGI-1', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'BGJ', '## 2. ', ('prefix', '## 5. '), 'BGJ note §2 covariance defect, §3 graph defect, §4 consequences'),
 ('X-BGI-2', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'BGJ', '## 5. ', ('end',), 'BGJ note §5 record-table position and §6 pins (incl. the two logs)'),
 ('X-BGI-3', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'BGJPY', '# --------------------------------------------------------------- birth graph', ('end',), 'triad_formal_involution_birth_jet.py: birth-graph section (D and G, κ̃ = 1, 2)'),
 ('X-BGI-4', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'GCPY', '#!/usr/bin/env python3', ('end',), 'triad_involution_graph_completion.py, whole file (degree-4 completion identity; degree-5 re-evaluation)'),
 ('X-BGI-5', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'POLY', ' "d3": {', ('prefix', ' "d5": {'), 'age_family_polynomials_kt1.json: degree-3 and degree-4 entries (κ̃ = 1 table; the record\'s (c) cites C_4 ≡ 0)'),
 ('X-BGI-6', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'TRIAD161', '### §6.1 Birth Kinematics', ('prefix', '### §6.2 '), 'Triadic v1.6.1 §6.1 (birth kinematics; D3 scope of the remainder)'),
 ('X-BGI-7', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'TRIAD161', '`[ALG]` [scope: fixed negative reference $\\kappa$', ('line',), 'Triadic v1.6.1 §6.15, D3-R1 line (p-dependent orders; non-implication witness)'),
 ('X-BGI-8', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'TRIAD161', '#### §6.17.2', ('prefix', '#### §6.17.3'), 'Triadic v1.6.1 §6.17.2 (leading policy family and higher-order scope)'),
 ('X-BGI-9', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'TRIAD161', '### §7.2 ', ('prefix', '### §7.3 '), 'Triadic v1.6.1 §7.2 (revised source inputs and claim-level custody)'),
 ('X-BGI-10', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION', 'TRIAD161', '**CN-02 — ', ('prefix', '**CN-04 — '), 'Triadic v1.6.1 §7.4 CN-02 block (with the CN-03 text that follows it)'),
]
NOT_HELD = 'NOT_HELD — identity as stated in the record or its source; bytes not in this packet'
PREP_ROLE = 'PREPARER_ROLE — the "RER editor" named here is the preparer of this packet (Claude, RER co-owner/editor); not independent receiver evidence'
# (item, where, provenance, import keys covered)
PROOF = {
 'RER-TRIAD-FORMAL-INVOLUTION': [
  ('(i) uniqueness proof, "Proof (dimension-free)", in the [THM] line', 'RER record text (r4.11)', 'RER record text; no other held source contains this proof sentence (X-TFI-1 lists jet identity checks only); its author is not named in the held sources', []),
  ('BGJ note §0–§1 (withdrawn claim; identity checks)', 'X-TFI-1', 'HELD (494b34f2…9413); written by the Triadic contributor (the note says "My earlier statement"); identity of the contributor not established here', ['TRIAD_BGJ']),
  ('jet check script triad_formal_involution_birth_jet.py', 'X-TFI-2, X-TFI-3', 'HELD (5c020986…feb); the record states a Triadic contributor run and an "RER editor replay exit 0": ' + PREP_ROLE, ['TRIAD_BGJ_PY']),
  ('jet log triad_formal_involution_birth_jet.log (34d48bd2…4012)', 'pinned in X-BGI-2', NOT_HELD, []),
  ('exact kernel script triad_cubic_centralizer_kernel_check.py', 'X-TFI-4', 'HELD (fac5ffe7…0574); the record states it was source-executed (≈90 s) and that the receiving-side run of this script timed out after degrees 2–5', ['TRIAD_CK_PY']),
  ('alternative exact kernel certificate of the receiving co-owner (19 Oct 2026; two prime fields, rational null vectors at k = 3, zero-cubic control)', 'Evidence field', 'RECEIVER-REPORTED as stated in the record; ' + NOT_HELD + '; it is the receiver\'s own earlier work', []),
  ('float64 replay triad_cubic_kernel_chiral_replay.py', 'X-TFI-5', 'HELD (5447338c…f5584); the record states "EXECUTED by the RER editor": ' + PREP_ROLE, ['TRIAD_KR_PY']),
  ('K3 SESSION record v0.1.2 chiral identities / Genesis v2.8.6 §6.3a (d) (source of the replay\'s X_3)', 'X-TFI-5 docstring', NOT_HELD, []),
  ('[NUM] identification of the kernel basis A, B (fit residual 1e-14)', 'record (ii)', 'RER record text; none of the four held scripts computes A, B or a fit residual (no held file prints these values)', []),
  ('G2 consolidated note v0.4 §2', 'Import/reference G2NOTE04', NOT_HELD + ' (no hash printed; Phase A r17: UNAUTHENTICATED_NO_HASH)', ['G2NOTE04']),
  ('Dyadic v6.4.18 §6.16 (dyad counterpart)', 'X-TFI-6', 'OWNER (Dyadic), HELD (f70308f1…458d); comparison only; not an import of this record. Current Dyadic is v6.4.19 (OWNER_REPORTED; Phase A r17)', []),
  ('review receipts: Triadic reviewer (15 Oct); RER editor (17 Oct)', 'Review receipt field', NOT_HELD + '; the Triadic reviewer is not identified in the held sources; the RER editor receipt: ' + PREP_ROLE, []),
 ],
 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION': [
  ('BGJ note §§2–4 (D, G, consequences) and §5–§6', 'X-BGI-1, X-BGI-2', 'HELD (494b34f2…9413); Triadic contributor', ['TRIAD_BGJ']),
  ('birth-graph section of triad_formal_involution_birth_jet.py', 'X-BGI-3', 'HELD (5c020986…feb); the record states contributor runs and RER editor replays: ' + PREP_ROLE, []),
  ('completion script triad_involution_graph_completion.py', 'X-BGI-4', 'HELD (024c9ad1…0574); needs the jet script alongside; RER editor replay: ' + PREP_ROLE, ['TRIAD_GC_PY']),
  ('completion log triad_involution_graph_completion.log (206ec8d3…ec84)', 'pinned in X-BGI-2', NOT_HELD, []),
  ('κ̃ = 1 age-family table (degree-3/4 entries)', 'X-BGI-5', 'HELD (03042f84…d83c); the table is the one used by RER-TRIAD-FORMAL-AGE; none of the held scripts reads it', ['POLY']),
  ('formal age family C(s,τ)', 'RER-TRIAD-FORMAL-AGE (B-06)', 'separate RER record; its B-06 receiver decisions apply to it, not to this record', []),
  ('Genesis v2.8.7 §2 OPEN 5/2B and §6.3 GCL-06', 'Import/reference GEN287', NOT_HELD + '; Phase A r17: RECEIVER_BYTE_VERIFIED, OWNER_REPORTED (current Genesis v2.8.9)', ['GEN287']),
  ('Triadic v1.6.1 §6.1, §6.15 (D3-R1 line), §6.17.2, §7.2, §7.4 CN-02', 'X-BGI-6…10', 'OWNER (Triadic), HELD (95340abe…451f); Phase A r17: CURRENT', ['TRIAD161']),
  ('Triadic v1.6.1 DRAFT r1 / r2 (history citation in the TRIAD161 import line)', 'Import/reference TRIAD161', NOT_HELD + ' (dd67907f…b3e7, 31b87c3e…630ea)', []),
  ('RER-GEN-C07 (contrast: F-invariance defect at degree 5)', 'Map / clock field', 'separate RER record; not reviewed here', []),
  ('review receipt of the RER editor (17 Oct; wording as quoted in the record)', 'Review receipt field', NOT_HELD + '; ' + PREP_ROLE, []),
 ],
}
TIMING = [  # preparer runs on the session machine, 21 Oct 2026; recorded only to help scheduling; NOT receiver evidence
 ('triad_formal_involution_birth_jet.py', '≈1 s', 'exit 0, last line "identity checks: ALL PASS"', '—'),
 ('triad_involution_graph_completion.py (jet script alongside)', '≈1 s', 'exit 0, last line "all stated identities: PASS"', '—'),
 ('triad_cubic_kernel_chiral_replay.py (numpy 2.5.3)', '≈0.6 s', 'exit 0, "dims (0, 2, 0, 0, 0, 0) -> PASS"', '--control-real: exit 1, "dims (0, 6, 0, 0, 0, 0) -> FAIL"'),
 ('triad_cubic_centralizer_kernel_check.py (jet script alongside)', '≈101 s', 'exit 0, "expected kernel dimensions (0,2,0,0,0,0): PASS"', '—'),
]
QUESTIONS = {
 'RER-TRIAD-FORMAL-INVOLUTION': [
  ('Q-TFI-1', '(i) proof steps', 'The [THM] line gives a three-step proof: R commutes with F, hence with "the unique tangent-to-identity root F^{-1/2}"; hence with S^; "R S^ is a tangent-to-identity involution, hence the identity". Which facts does each step use — uniqueness of tangent-to-identity formal roots, R S^ = S^ R (needed for R S^ to be an involution), and "a tangent-to-identity formal involution is the identity" — and where, if anywhere, are they stated or cited in the held sources (X-TFI-1 has no proof; compare the dyad argument in X-TFI-6)?'),
  ('Q-TFI-2', '(i) construction of S^', 'S^ := N^3 ∘ F^{-1/2} with F = N^6. Which properties are used to get S^∘S^ = id and DS^(0) = −I_4 — A^3 = −I (Constraints), N^3 commuting with F^{-1/2}, (N^3)^2 = F — and are they proved for all formal orders or checked through degree 5 only (X-TFI-2, X-TFI-3; Order/error says "(i) all formal orders by proof, jet check through degree 5")?'),
  ('Q-TFI-3', '(i) scope', 'Uniqueness is claimed among formal involutions that commute with N and have linear part −I_4 (title, Closure (i), Map/clock "primitive clock N"); the six-step-only class is OPEN (G6). Is every statement of (i) in the record scoped this way?'),
  ('Q-TFI-4', 'slot commutation', 'The Transformation-law cell says every slot permutation ρ_Π "commutes exactly with N", and the [THM] line includes commutation with every ρ_Π. X-TFI-1/X-TFI-3 check the swaps 2↔3, 1↔2, 1↔3 and the 3-cycle through degree 5. Is the exact (all-order) commutation stated with a structural reason in any held source (Observables cell: ρ_Π = P Π E ⊗ I_2)?'),
  ('Q-TFI-5', '(ii)(a) commutant', 'The record states that the real commutant of A⊕A is all complex-linear maps of C^2, so involutions commuting with N need not have DR(0) = ±I. Which property of A (A^3 = −I; eigenvalues) does this use, and which held source states it?'),
  ('Q-TFI-6', '(ii)(b) kernel dimensions — evidence', 'dim ker(ad_{X_3}) = (0,2,0,0,0,0) for k = 2…7 is graded [ALG] on the exact script X-TFI-4 (held; the preparer\'s timing run is listed below as scheduling information only) and on the receiving co-owner\'s own alternative certificate (files not in this packet); X-TFI-5 is a [NUM] float64 replay from an independently built X_3 whose source (K3 SESSION v0.1.2 / Genesis v2.8.6 §6.3a (d)) is not held. Which of these does the receiver count for the [ALG] grade, and is the statement scoped to k ≤ 7 wherever it is used ("kernel dimensions exact for k ≤ 7 only")?'),
  ('Q-TFI-7', '(ii) [NUM] kernel basis', 'The record gives an explicit basis A, B in chiral modes with a, β* and "fit residual 1e-14". No held script computes this basis or residual. Is the [NUM] line needed for any claim of the record, or is it descriptive?'),
  ('Q-TFI-8', 'consequences stated as non-claims', 'From (ii) the record concludes that the triad\'s formal centralizer "is not known to be {exp(sX)}", that uniqueness for involutions commuting with F only is OPEN, and that there is "no triadic analogue of DYAD-THM-ANALYTIC-CLOCK-BRIDGE". Are these worded as absence of a result (OPEN), not as negative theorems?'),
  ('Q-TFI-9', 'β* = 0 remark', 'The Evidence field notes that β* = 0 alone also gives dimension 2 (two decoupled dyads), and X-TFI-5 uses a different control (c0 real, b = 0). Does any line of the record attribute the dimension 2 to the chiral coupling?'),
  ('Q-TFI-10', 'grades and receipts', 'Record level: [THM] for (i), [ALG] for (ii); FORMAL_ONLY for (i), FINITE_ORDER for (ii). The two receipts (Triadic reviewer, RER editor) are not held; the RER editor is the preparer\'s role. The record itself says an independent review of the proof of (i) "is still required". What evidence does the receiver need for (i) and for (ii) separately?'),
 ],
 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION': [
  ('Q-BGI-1', 'objects', 'The Carrier cell defines B_κ(s) = (s, κ̃ Q(s) M s), M = [[1,−2],[2,−1]], κ = √3 κ̃, "(= Genesis c_0^{[3]} = κ Q_s J_Q s)", and S^ from RER-TRIAD-FORMAL-INVOLUTION. Are these the objects of X-BGI-1 and X-BGI-3, and is the identification with the Genesis cubic stated in a held source (X-BGI-6 §6.1)?'),
  ('Q-BGI-2', '(a) graph defect', 'Compare the G_4 polynomial in (a) with X-BGI-1 §3. The record says G is "exactly κ̃-linear"; X-TFI-2 says D and G are "affine in kt through degree 5, because c enters at most linearly there". Is the κ̃-linearity scoped to degree ≤ 5 in the record (Domain: "κ̃-linearity of G_4 extends (a),(b) to every κ̃")?'),
  ('Q-BGI-3', '(b) completion identity', '(b) uses G_4[C_3 + C_4] = G_4[C_3] − 2C_4 "(checked for a generic quartic)". X-BGI-4 states the reason (DS = −I, C_4 even) and checks it. Is the identity derived for all quartics or checked on a symbolic generic quartic, and is (b) scoped as "a formal completion through degree 5; all-order existence not claimed" wherever it is used?'),
  ('Q-BGI-4', '(c) age sheets', '(c) rests on C_4 ≡ 0 for every τ in the κ̃ = 1 table (X-BGI-5: the "d4" entry) and on G_4 ≠ 0. The table lists binomial coefficients up to degree 9; "deg_τ C_4 ≤ 0" also follows from the age-family degree bound floor((d−3)/2) (RER-TRIAD-FORMAL-AGE, B-06). Which of the two does the record rely on, and is (c) scoped to κ̃ = 1 and to the comparison at degree 4?'),
  ('Q-BGI-5', '(c) all real τ', 'The record and X-BGI-1 §4(b) say the S^-image of a sheet is not a sheet τ′ "for any real τ′". The comparison is made on the degree-4 jet. Does the argument use any property of the family beyond C_4 ≡ 0 and the degree-3 term being τ-independent (X-BGI-5 "d3")?'),
  ('Q-BGI-6', '(d) contract-conditional statement', '(d) states mutual exclusivity of S^-compatibility and the fifth-order branch only "under this contract" (child functional = graph value) and keeps the physical choice OPEN. Compare with X-BGI-6…10: Triadic v1.6.1 states the remainder conditionally on GCL-06 and the selected child functional and, per the record, does not adopt this graph contract. Does any line of the record select p = 4 or p = 5, or transfer (d) to Triadic?'),
  ('Q-BGI-7', 'Genesis references', '(d) and the [OPEN] lines cite Genesis v2.8.7 §2 OPEN 5/2B and §6.3 GCL-06; those bytes are not in this packet (Phase A r17: receiver byte-verified earlier; current Genesis v2.8.9 owner-reported). Does the receiver need them for this decision?'),
  ('Q-BGI-8', 'dependence', 'This record uses S^ (RER-TRIAD-FORMAL-INVOLUTION, reviewed in the same round) and C(s,τ) (RER-TRIAD-FORMAL-AGE, B-06). If the receiver\'s decision on (i) of the involution record is scoped or corrected, which claims of this record are affected?'),
  ('Q-BGI-9', 'withdrawn claim and covariance', 'The [COR] note withdraws S^(B_κ(s)) = B_κ(−s) + O(|s|^5) (X-TFI-1 §0). The record separates covariance D (degree-2/3 parent terms from S^\'s chart) and invariance G. Are these kept apart in every claim line?'),
 ],
}
VERDICT = re.compile(r'\b(PASS|PASSES|FAIL|ACCEPT|ACCEPTED|REJECT|REJECTED|CORRECT|INCORRECT|VALID|INVALID|recommend|recommended|verdict|we conclude|is proved|is wrong|sound|unsound)\b', re.I)

def load(): return {k: (HERE / p).read_bytes() for k, (p, h) in FILES.items()}
def span(md, rid):
    L = md.split('\n'); i = [n for n, l in enumerate(L) if l.startswith('### ' + rid + ' — ')]
    if len(i) != 1: return None
    i = i[0]; j = next((k for k in range(i + 1, len(L)) if L[k].startswith('### RER-') or L[k].startswith('<a id=') or L[k].startswith('## ')), len(L))
    while j > i and not L[j - 1].strip(): j -= 1
    return i + 1, j, '\n'.join(L[i:j])
def classify(text):
    L = text.split('\n'); out = {'heading': L[0], 'primary_grade_line': None, 'contract_rows': [], 'claim_lines': [], 'open_lines': [], 'import_lines': [], 'fields': [], 'other_lines': []}
    for l in L[1:]:
        if not l.strip() or l in ('| Field | Contract |', '|---|---|'): continue
        if l.startswith('**Primary grade:**'): out['primary_grade_line'] = l
        elif l.startswith('| '): out['contract_rows'].append(l)
        elif re.match(r'^\[(THM|ALG|NUM|DEF)\]', l): out['claim_lines'].append(l)
        elif l.startswith('[OPEN] '): out['open_lines'].append(l)
        elif l.startswith('Import/reference:'): out['import_lines'].append(l)
        elif re.match(r'^\*\*[^*]+:\*\*', l): out['fields'].append(l)
        else: out['other_lines'].append(l)
    return out
def extract(B, fk, start, end):
    t = B[fk].decode('utf-8'); L = t.split('\n'); i = [n for n, l in enumerate(L) if l.startswith(start)]
    if len(i) != 1: return None
    i = i[0]
    if end[0] == 'line': j = i + 1
    elif end[0] == 'end': j = len(L)
    else: j = next((k for k in range(i + 1, len(L)) if L[k].startswith(end[1])), None)
    if j is None: return None
    while j > i + 1 and not L[j - 1].strip(): j -= 1
    return i + 1, j, '\n'.join(L[i:j])
def build(B):
    md = B['RER11'].decode('utf-8'); md6 = B['RER6'].decode('utf-8'); M = json.loads(B['MATRIX17']); P6 = json.loads(B['B06PKT'])
    recs = {}
    for rid in REVIEW:
        s = span(md, rid)
        if s is None: recs[rid] = None; continue
        i, j, t = s; s6 = span(md6, rid); c6 = P6['records'].get(rid, {})
        rows = [{k: x.get(k) for k in ('n', 'key', 'cited_path', 'section_or_RID', 'lines', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash')} for x in M['rows'] if x['record'] == rid]
        r = {'id': rid, 'role': 'REVIEW', 'rer_r4_11_lines': [i, j], 'span_sha256': sha(t.encode('utf-8')), 'text': t, 'parts': classify(t), 'phaseA_r17_rows': rows,
             'trail': {'r4_6_lines': None if s6 is None else [s6[0], s6[1]], 'r4_6_span_sha256': None if s6 is None else sha(s6[2].encode('utf-8')),
                       'b06_context_span_sha256': c6.get('span_sha256'), 'b06_context_role': c6.get('role'), 'unchanged_since_r4_6': s6 is not None and s6[2] == t}}
        r['extracts'] = []
        for xid, rec, fk, st, en, label in EXTRACTS:
            if rec != rid: continue
            e = extract(B, fk, st, en)
            r['extracts'].append({'id': xid, 'file': FILES[fk][0], 'file_sha256': FILES[fk][1], 'label': label, 'lines': None if e is None else [e[0], e[1]],
                                  'sha256': None if e is None else sha(e[2].encode('utf-8')), 'text': None if e is None else e[2]})
        r['proof_material'] = [{'item': a, 'where': b, 'provenance': c, 'import_keys': k} for a, b, c, k in PROOF[rid]]
        r['questions'] = [{'id': q, 'topic': tp, 'question': qt} for q, tp, qt in QUESTIONS[rid]]
        recs[rid] = r
    return {'_about': 'RER Phase B-07 neutral review packet (NONCANONICAL; preparer Claude, RER co-owner). Verbatim quotations of byte-pinned sources, provenance-labelled proof material and questions; no PASS/FAIL, grade or acceptance recommendation is given for any claim.',
            'scope': {'review': REVIEW, 'decision_options_of_the_receiver': ['ACCEPT SCOPED', 'CORRECTION REQUIRED', 'INSUFFICIENT EVIDENCE'],
                      'context_inventories': 'B-05 inventory and B-06 packet (sources/history/) are PREPARER_AUTHORED context; the receiver decisions on them (`ACCEPT SCOPED`) cover them as packets/inventories only, not as scientific review of these records'},
            'files': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()},
            'records': recs,
            'preparer_runs_timing_only': [{'script': a, 'wall_time': b, 'normal_mode': c, 'negative_mode': d, 'label': 'PREPARER_RUN — scheduling information, not receiver evidence'} for a, b, c, d in TIMING],
            'currency_note': 'Source RER r4.11 (2cd3f0e9…4dd8) and Phase A r17 (receiver decision of 21 Oct 2026: `ACCEPT SCOPED`). Triadic v1.6.1 is current; Genesis current v2.8.9 is owner-reported; Dyadic current v6.4.19 is owner-reported (v6.4.18 held here for comparison only).'}
def render(P):
    J = (json.dumps(P, ensure_ascii=False, indent=1) + '\n').encode('utf-8')
    L = ['# RER Phase B-07 — neutral review packet', '', P['_about'], '',
         f"**Review (receiver decides per record or claim: {', '.join(P['scope']['decision_options_of_the_receiver'])}):** " + ', '.join(f'`{r}`' for r in P['scope']['review']), '',
         '**Context inventories:** ' + P['scope']['context_inventories'] + '.', '', '**Currency note:** ' + P['currency_note'], '']
    for rid in P['scope']['review']:
        r = P['records'][rid]; tr = r['trail']
        L += [f'## {rid}', '', f"RER r4.11 lines {r['rer_r4_11_lines'][0]}–{r['rer_r4_11_lines'][1]}; span SHA-256 `{r['span_sha256']}`. Byte-identical to r4.6 (lines {tr['r4_6_lines'][0]}–{tr['r4_6_lines'][1]}): {'yes' if tr['unchanged_since_r4_6'] else 'no'}; B-06 context span SHA-256 `{tr['b06_context_span_sha256']}`.", '',
              '### Record text (verbatim)', '', '```', r['text'], '```', '',
              '### Imports (Phase A r17)', '', '| n | Key | Cited | Section / lines | Bytes | Authentication | Currency | Status |', '|---|---|---|---|---|---|---|---|']
        L += [f"| {x['n']} | `{x['key']}` | {x['cited_version']} `{(x['cited_sha256'] or '—')[:12]}` | {x['section_or_RID']} {x['lines'] or ''} | {x['bytes_status']} | {x['authentication']} | {x['currency']} | {x['status']} |" for x in r['phaseA_r17_rows']]
        L += ['', '### Proof material and provenance', '', '| Item | Where | Provenance |', '|---|---|---|'] + [f"| {p['item']} | {p['where']} | {p['provenance']} |" for p in r['proof_material']]
        L += ['', '### Questions for the receiver (no answer is implied)', ''] + [f"- **{q['id']}** ({q['topic']}): {q['question']}" for q in r['questions']]
        L += ['', '### Source extracts (verbatim)', '']
        for x in r['extracts']:
            L += [f"#### {x['id']} — {x['label']}", '', f"`{x['file']}` lines {x['lines'][0]}–{x['lines'][1]}; extract SHA-256 `{x['sha256']}`", '', '````', x['text'], '````', '']
    L += ['## Preparer runs (timing only — not receiver evidence)', '', '| Script | Wall time | Normal mode | Negative mode |', '|---|---|---|---|'] + [f"| {t['script']} | {t['wall_time']} | {t['normal_mode']} | {t['negative_mode']} |" for t in P['preparer_runs_timing_only']]
    return J, ('\n'.join(L) + '\n').encode('utf-8')
def gates(B, P, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    on_disk = sorted(str(f.relative_to(HERE)) for f in (HERE / 'sources').rglob('*') if f.is_file())
    g('B1 input pins: every file under sources/ is pinned, every pin is present with its hash', on_disk == sorted(p for p, h in FILES.values()) and all(sha(B[k]) == h for k, (p, h) in FILES.items()), f'{len(FILES)} files')
    R = P['records']; md = B['RER11'].decode('utf-8')
    ok2 = all(R.get(r) and span(md, r) and R[r]['text'] == span(md, r)[2] and R[r]['span_sha256'] == sha(R[r]['text'].encode('utf-8')) and R[r]['text'] in md for r in REVIEW)
    g('B2 record spans: each record found once in r4.11, text verbatim, span hash recomputes', ok2)
    M = json.loads(B['MATRIX17'])
    ok3 = all(R[r] and [x['key'] for x in R[r]['phaseA_r17_rows']] == [x['key'] for x in M['rows'] if x['record'] == r]
              and len(R[r]['phaseA_r17_rows']) == len(R[r]['parts']['import_lines']) for r in REVIEW)
    g('B3 Phase A r17 rows match the pinned matrix and the record\'s Import/reference lines', ok3)
    X = [x for r in REVIEW for x in (R[r] or {}).get('extracts', [])]
    ok4 = len(X) == len(EXTRACTS) and all(x['text'] and x['sha256'] == sha(x['text'].encode('utf-8')) and x['text'] in B[next(k for k, (p, h) in FILES.items() if p == x['file'])].decode('utf-8') for x in X)
    g('B4 source extracts: anchors unique, non-empty, verbatim, hashes recompute', ok4, f'{len(X)} extracts')
    P6 = json.loads(B['B06PKT'])
    ok5 = all(R[r]['trail']['unchanged_since_r4_6'] and R[r]['trail']['r4_6_span_sha256'] == R[r]['span_sha256'] == P6['records'][r]['span_sha256']
              and P6['records'][r]['role'].startswith('CONTEXT_ONLY') for r in REVIEW)
    g('B5 trail: both records byte-identical in r4.6 and r4.11 and equal to the B-06 context spans (which were not reviewed in B-06)', ok5)
    texts = [q['question'] for r in REVIEW for q in R[r]['questions']] + [p['provenance'] for r in REVIEW for p in R[r]['proof_material']] + [p['item'] for r in REVIEW for p in R[r]['proof_material']] \
            + [P['_about'], P['currency_note'], P['scope']['context_inventories']]
    unq = lambda t: re.sub(r'`[^`]*`', '', re.sub(r'"[^"]*"', '', t)).replace('no PASS/FAIL', '')  # quoted source text is not preparer judgement
    hits = [t[:50] for t in texts if VERDICT.search(unq(t))]
    g('B6 neutrality: no verdict word in the preparer-written questions, provenance and notes', not hits, f'{len(hits)} hit(s) {hits[:1]}')
    ok7 = P['scope']['review'] == REVIEW and len(REVIEW) == 2 and set(R) == set(REVIEW) and all(R[r]['role'] == 'REVIEW' and R[r]['questions'] and R[r]['extracts'] for r in REVIEW)
    g('B7 scope: exactly the two Triadic review records, each with questions and extracts', ok7)
    pm = [p for r in REVIEW for p in R[r]['proof_material']]
    ok8 = all(('RECEIVER' not in p['provenance'] or 'Phase A r17: RECEIVER_BYTE_VERIFIED' in p['provenance'] or 'as stated in the record' in p['provenance'] or 'not independent receiver evidence' in p['provenance']) for p in pm) \
          and all('PREPARER_ROLE' in p['provenance'] for p in pm if 'RER editor' in p['provenance'] or 'RER editor' in p['item']) \
          and all(t['label'].startswith('PREPARER_RUN') and 'not receiver evidence' in t['label'] for t in P['preparer_runs_timing_only'])
    g('B8 provenance: RER-editor items labelled PREPARER_ROLE, receiver items only as stated or Phase A labels, preparer runs labelled; nothing preparer-made is receiver evidence', ok8)
    ok9 = all(sorted(k for p in R[r]['proof_material'] for k in p['import_keys']) == sorted(x['key'] for x in R[r]['phaseA_r17_rows']) for r in REVIEW)
    g('B9 coverage: every Import/reference key of each record appears exactly once in its proof-material table', ok9)
    return all(res), res
if __name__ == '__main__':
    B = load(); a = sys.argv[1:]
    if a and a[0] == '--negcontrol':
        P0 = build(B); allf = True
        def run(n, BB, PP, gi):
            global allf
            _, rr = gates(BB, PP, verbose=False); good = not rr[gi]; allf &= good
            print(f'  negative control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
        fl = lambda b: b[:100] + bytes([b[100] ^ 1]) + b[101:]
        T1, T2 = REVIEW
        run('B1 one byte flipped in the BGJ note', dict(B, BGJ=fl(B['BGJ'])), P0, 0)
        P1 = copy.deepcopy(P0); P1['records'][T1]['text'] = P1['records'][T1]['text'].replace('[THM]', '[ALG]', 1); run('B2 record text paraphrased', B, P1, 1)
        P2 = copy.deepcopy(P0); P2['records'][T2]['phaseA_r17_rows'].pop(); run('B3 an import row dropped', B, P2, 2)
        P3 = copy.deepcopy(P0); P3['records'][T2]['extracts'][4]['text'] = P3['records'][T2]['extracts'][4]['text'].replace('"0"', '"1"', 1); run('B4 the POLY degree-4 extract altered', B, P3, 3)
        P4 = copy.deepcopy(P0); P4['records'][T1]['trail']['unchanged_since_r4_6'] = False; run('B5 trail flag forged', B, P4, 4)
        P5 = copy.deepcopy(P0); P5['records'][T1]['questions'][0]['question'] += ' The uniqueness is proved.'; run('B6 verdict inserted in a question', B, P5, 5)
        P6 = copy.deepcopy(P0); P6['records'][T2]['proof_material'][0]['provenance'] += ' — sound'; run('B6 judgement word in provenance', B, P6, 5)
        P7 = copy.deepcopy(P0); P7['scope']['review'] = REVIEW + ['RER-TRIAD-FORMAL-AGE']; run('B7 a third record added to the scope', B, P7, 6)
        P8 = copy.deepcopy(P0); P8['records'][T1]['proof_material'][2]['provenance'] = 'HELD; RER editor replay exit 0'; run('B8 RER-editor replay without the PREPARER_ROLE label', B, P8, 7)
        P9 = copy.deepcopy(P0); P9['records'][T1]['proof_material'][5]['provenance'] = 'RECEIVER-VERIFIED certificate'; run('B8 receiver certificate relabelled as verified', B, P9, 7)
        P10 = copy.deepcopy(P0); P10['preparer_runs_timing_only'][3]['label'] = 'RECEIVER_RUN'; run('B8 preparer run labelled receiver run', B, P10, 7)
        P11 = copy.deepcopy(P0); P11['records'][T2]['proof_material'][6]['import_keys'] = []; run('B9 GEN287 dropped from the proof-material table', B, P11, 8)
        sys.exit(0 if allf else 1)
    P = build(B); ok, res = gates(B, P); J, Md = render(P)
    if a and a[0] == '--check':
        same = (HERE / 'B07_REVIEW_PACKET.json').read_bytes() == J and (HERE / 'B07_REVIEW_PACKET.md').read_bytes() == Md
        print(f'{sum(res)}/{len(res)} gates PASS; stored outputs byte-identical: {same}'); sys.exit(0 if ok and same else 1)
    (HERE / 'B07_REVIEW_PACKET.json').write_bytes(J); (HERE / 'B07_REVIEW_PACKET.md').write_bytes(Md)
    print(f'{sum(res)}/{len(res)} gates PASS; B07_REVIEW_PACKET.json {sha(J)[:16]}, B07_REVIEW_PACKET.md {sha(Md)[:16]}'); sys.exit(0 if ok else 1)
