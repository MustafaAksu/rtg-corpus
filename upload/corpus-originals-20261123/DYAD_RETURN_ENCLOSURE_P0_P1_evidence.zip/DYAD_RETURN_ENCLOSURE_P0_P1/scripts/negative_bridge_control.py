#!/usr/bin/env python3
"""Expected-negative test: perturb a reconstructed raw target, not any owner file.
Demonstrates that gauge_bridge_p6.py prints discrepancies but does not fail its exit status.
"""
from pathlib import Path
import subprocess, shutil, json, sys
import sympy as sp
w=Path(__file__).resolve().parents[1]
base=w/'runs/reconstructed_chain/outputs'
run=w/'runs/negative_bridge_control';out=run/'outputs';out.mkdir(parents=True,exist_ok=True)
for n in ['phi1_p6_deg5.json','phi6_p6_lie_generator.json','jet6_deg5.json']:shutil.copyfile(base/n,out/n)
d=json.loads((out/'jet6_deg5.json').read_text())
d['(0, 5)']=str(sp.sympify(d['(0, 5)'])+sp.Rational(1,1000))
(out/'jet6_deg5.json').write_text(json.dumps(d,indent=2)+'\n')
(run/'PROVENANCE.txt').write_text('EXPECTED NEGATIVE TEST: reconstructed (0,5) raw target shifted by +1/1000; no supplied source changed.\n')
with (w/'logs/negative_bridge_control.log').open('w') as log:
 p=subprocess.run([sys.executable,str(w/'inputs/gauge_bridge_p6.py')],cwd=run,stdout=log,stderr=subprocess.STDOUT,timeout=30)
s=(w/'logs/negative_bridge_control.log').read_text()
assert p.returncode==0 and '1.00e-03' in s
(w/'outputs/negative_bridge_control.json').write_text(json.dumps({'target_perturbation':'1/1000 to raw c05','reported_error':'1.00e-03','exit_code':p.returncode,'finding':'source bridge prints errors but does not gate nonzero exit on them'},indent=2)+'\n')
print('EXPECTED NEGATIVE CONTROL: raw target error 1e-3 is printed, but process exit remains 0.')
