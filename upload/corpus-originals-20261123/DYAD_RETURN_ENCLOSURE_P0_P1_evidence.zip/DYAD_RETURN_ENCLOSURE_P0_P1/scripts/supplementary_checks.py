#!/usr/bin/env python3
"""Inspect unmodified module functions; pin the homological obstruction matrix.
Exploratory implementation defects are kept separate from the p=6 core proof.
"""
from pathlib import Path
import importlib.util, json, sympy as s, mpmath as mp
import exact_return_audit as a
w=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('supplied_pstep',w/'inputs/normalize_pstep_lie.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# Negative control for the declared general quadratic-leading input interface.
f={(1,0):mp.mpc(1),(2,0):mp.mpc(1)}
v,vb=m.log_map_from_raw(f,5);back,_=m.exp_vector_field_to_map(v,vb,5)
diff=m.sub(back,f)
assert abs(m.gc(back,3,0)-1)<mp.mpf('1e-60')
print('PASS detection: generic quadratic-leading input is not supported by the implemented log; x+x^2 reconstructs with nonzero x^3.')
print('exp(implemented_log(x+x^2)) - (x+x^2) =',diff)
# Exact rank certificate for the unique quadratic change removing F4.
mu=a.K(-a.Q(1,2),-a.Q(2,3));v3={(2,1):mu};omega=a.K(0,1)
monos=[(p,4-p) for p in range(5)];cols=[]
for k in [(2,0),(1,1),(0,2)]:
 for c in [a.K(1),omega]:
  hh={k:c};br=a.sub(a.act(hh,v3,4),a.act(v3,hh,4))
  cols.append([v for k4 in monos for v in [a.cget(br,k4).a,a.cget(br,k4).b]])
M=s.Matrix.hstack(*(s.Matrix(c) for c in cols));_,inds=M.T.rref();rows=list(inds);minor=M[rows,:].det()
assert minor!=0
report={'quadratic_homological_matrix':[[str(v) for v in row] for row in M.tolist()],
 'rows':'(Re coefficient, Im/sqrt(3) coefficient) for (0,4),(1,3),...,(4,0)',
 'columns':'real and i*sqrt(3) parts of h20,h11,h02',
 'full_rank_minor_rows_0indexed':rows,'full_rank_minor_det':str(minor),
 'generic_U2_nonzero_negative_control':{str(k):str(v) for k,v in diff.items()}}
(w/'outputs/supplementary_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS exact quadratic homological rank 6; minor determinant =',minor)
