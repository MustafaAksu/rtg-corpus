#!/usr/bin/env python3
"""Second arithmetic implementation: SymPy polynomial rings, not audit K/Poly helpers.
Checks the real primitive degree-six jet and the full complex conjugacy identities.
"""
from pathlib import Path
import json, ast, time
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
W=Path(__file__).resolve().parents[1];D=6;t=time.perf_counter();checks=[]
def check(name,c):
 c=bool(c);print(('PASS ' if c else 'FAIL ')+name,flush=True);checks.append({'check':name,'pass':c});assert c

def algebra(R):
 def trim(p):return R.from_dict({k:c for k,c in p.items() if sum(k)<=D})
 def mul(p,q):return trim(p*q)
 def power(p,n):
  r=R.one
  for _ in range(n):r=mul(r,p)
  return r
 def compose(p,x,y):
  xp=[power(x,k) for k in range(D+1)];yp=[power(y,k) for k in range(D+1)]
  return sum((mul(xp[a],yp[b])*c for (a,b),c in p.items()),R.zero)
 return trim,mul,power,compose

def load(R,name):
 data=json.loads((W/'outputs'/name).read_text())
 return R.from_dict({ast.literal_eval(k):R.domain.from_sympy(s.sympify(v)) for k,v in data.items()})
R,r,e=ring('r,e',QQ);tr,mul,power,comp=algebra(R)
a,b=r,e
for n in range(6):
 sinb=b-power(b,3)/6+power(b,5)/120
 expa=sum((power(a,k)/s.factorial(k) for k in range(1,7)),R.zero)
 a,b=tr(a-sinb),tr(b+expa-sinb)
check('independent SymPy primitive rho jet, all degrees <=6',a==load(R,'primitive_rho_deg6.json'))
check('independent SymPy primitive eta jet, all degrees <=6',b==load(R,'primitive_eta_deg6.json'))
qdelta=tr(a*a-a*b+b*b-r*r+r*e-e*e)
check('independent SymPy radial deltaQ, all degrees <=6',qdelta==load(R,'radial_deltaQ_deg6.json'))

K=QQ.algebraic_field(s.sqrt(3)*s.I);C,z,zb=ring('z,zb',K);tr,mul,power,comp=algebra(C)
def conjugate(p):
 return C.from_dict({(b,a):K.from_sympy(s.conjugate(K.to_sympy(c))) for (a,b),c in p.items()})
f1=load(C,'jet1_deg6_reconstructed.json');f6=load(C,'jet6_deg6_reconstructed.json')
h=load(C,'coordinate_h_deg6_reconstructed.json');nf=load(C,'normalized_onestep_deg6.json');ret=load(C,'normalized_sixstep_deg6.json')
check('independent SymPy one-step full conjugacy f o h = h o nf',comp(f1,h,conjugate(h))==comp(h,nf,conjugate(nf)))
check('independent SymPy six-step full conjugacy F o h = h o ret',comp(f6,h,conjugate(h))==comp(h,ret,conjugate(ret)))
i=z
for _ in range(6):i=comp(nf,i,conjugate(i))
check('independent SymPy normalized iterate identity',i==ret)
(W/'outputs/independent_sympy_check.json').write_text(json.dumps({'checks':checks,'seconds':time.perf_counter()-t,'implementation':'SymPy polynomial rings, separate from Fraction quadratic-field engine'},indent=2)+'\n')
print('SECOND IMPLEMENTATION COMPLETE',time.perf_counter()-t,flush=True)
