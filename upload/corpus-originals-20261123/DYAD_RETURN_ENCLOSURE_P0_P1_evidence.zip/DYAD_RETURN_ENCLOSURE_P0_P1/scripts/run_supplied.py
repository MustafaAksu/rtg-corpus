from pathlib import Path
import subprocess, time, json, os, sys
w=Path(__file__).resolve().parents[1]
cases=[('normalize_p6_liegauge_exact', [sys.executable,str(w/'inputs/normalize_p6_liegauge_exact.py')],300),
       ('ng_l1_original', [sys.executable,str(w/'inputs/ng_l1_primitive_contraction_cert_v1.py')],300),
       ('gauge_bridge_original', [sys.executable,str(w/'inputs/gauge_bridge_p6.py')],30)]
for name,cmd,limit in cases:
 run=w/'runs'/name;run.mkdir(parents=True,exist_ok=True)
 pid=os.fork()
 if pid==0:
  t=time.perf_counter()
  with (w/'logs'/f'{name}.log').open('w') as out:
   try:
    r=subprocess.run(cmd,cwd=run,stdout=out,stderr=subprocess.STDOUT,timeout=limit)
    result={'exit_code':r.returncode,'command':cmd,'seconds':time.perf_counter()-t}
   except subprocess.TimeoutExpired:
    result={'timeout':limit,'command':cmd,'seconds':time.perf_counter()-t}
  (w/'logs'/f'{name}_status.json').write_text(json.dumps(result,indent=2)+'\n')
  os._exit(0)
print('Started isolated source runs; status files under logs/.')
