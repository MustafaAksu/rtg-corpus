#!/usr/bin/env python3
"""Portable sequential replay of this audit. No original project paths are modified."""
from pathlib import Path
import subprocess, sys, json, time
w=Path(__file__).resolve().parents[1]
for d in ['logs','outputs','runs']:(w/d).mkdir(exist_ok=True)
# Run the two self-contained supplied scripts unchanged.
for label,name in [('normalize_p6_liegauge_exact','normalize_p6_liegauge_exact.py'),('ng_l1_original','ng_l1_primitive_contraction_cert_v1.py')]:
 cwd=w/'runs'/label;cwd.mkdir(exist_ok=True);start=time.perf_counter()
 with (w/'logs'/f'{label}.log').open('w') as out:
  r=subprocess.run([sys.executable,str(w/'inputs'/name)],cwd=cwd,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 (w/'logs'/f'{label}_status.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-start},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
# New exact reconstruction and semantic checks.
for name in ['exact_return_audit.py','independent_sympy_check.py','supplementary_checks.py','run_reconstructed_inputs.py','negative_bridge_control.py']:
 print('Running',name,flush=True)
 with (w/'logs'/(Path(name).stem+'.log')).open('w') as out:
  r=subprocess.run([sys.executable,str(w/'scripts'/name)],cwd=w,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 if r.returncode:raise SystemExit(f'{name} failed; see logs/')
print('Audit replay complete. This does not supply an interval-certified domain or remainder constant.')
