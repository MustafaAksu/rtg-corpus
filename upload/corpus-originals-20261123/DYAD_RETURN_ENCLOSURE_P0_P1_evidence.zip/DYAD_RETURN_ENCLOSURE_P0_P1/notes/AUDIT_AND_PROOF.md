# Supplied normalization artifacts — audit and exact P1 result

## 1. Scope and source handling

All six new inputs were read and copied byte-for-byte to inputs/. Source files and all pre-existing project files were not edited. The input hash manifest records identity at this review, not agreement with an unavailable historical manifest.

Source runs:

* normalize_p6_liegauge_exact.py: unmodified run, exit 0, prints ALL PASS. It uses 120-digit mpmath, tolerance pruning, and no assertions; it is not an exact-arithmetic implementation despite its filename/header.
* ng_l1_primitive_contraction_cert_v1.py: unmodified run, exit 0; all nine symbolic assertions pass. Its mathematical conclusion is local existence, not an explicit-radius enclosure.
* gauge_bridge_p6.py: initial unmodified run cannot start its calculation because outputs/phi1_p6_deg5.json is absent.
* normalize_pstep_lie.py: run unchanged using a newly reconstructed raw jet6, explicitly NOT using the uploaded jet1 as a p-step input; exits 0.
* gauge_bridge_p6.py: subsequently run unchanged using independently reconstructed Phi1/raw6 and the source-generated Phi6 file; exits 0. The three reported coefficient discrepancies are about 10^-80. This is a reconstructed-input check, not a replay using archived owner exports.

The original historical Phi1 JSON and its generating homological solver remain unavailable. They are not needed for the new exact calculation, but are needed to authenticate historical convention identity.

## 2. Exact primitive reconstruction

A new sparse polynomial implementation uses Fraction pairs in Q(chi), chi^2=-3, chi=i sqrt(3). It contains no tolerance pruning or numerical recognition of rational coefficients.

Route A composes the real primitive map six times using rational coefficients and then changes to W. Route B constructs the primitive one-step W map directly and composes it. Their complete jets through degree six agree. A second implementation using SymPy polynomial rings separately verifies both real jets, the radial polynomial, the one-step conjugacy, the six-step conjugacy, and the normalized iterate identity.

The uploaded jet1 JSON equals the raw one-step W map exactly through degree five, including its nonzero quadratic coefficients. It is not a quadratic-free normalized map.

The primitive cubic and radial coefficients reproduce:

\[
\mu=-\frac12-\frac{2i\sqrt3}{3},\qquad
\Delta Q_4=-Q^2,
\]
\[
\Delta Q_5=\frac{Q}{24}(5\eta^3-43\eta^2\rho+4\eta\rho^2-5\rho^3).
\]

On the primitive real ray W=t, the quartic term is

\[
F_W(t)=t+\mu t^3-\frac{5+25i\sqrt3}{48}t^4+O(t^5).
\]

This term is nonzero. It cannot be placed inside an O(|W|^5) primitive remainder.

## 3. Three distinct operations in the uploaded scripts

### 3.1 Archival coordinate change

The archival script computes the formal log V of F_W through degree five, selects its nonresonant part V_nr, and builds a coordinate map beginning at degree four:

\[
\Phi_{\rm archive}=id+h_4+h_{5,nr}.
\]

For F_W=id+F3+F4+F5+..., a coordinate correction of degree four first affects degree six through a bracket with F3. Therefore

\[
\Phi_{\rm archive}^{-1}F_W\Phi_{\rm archive}
=F_W+O(|W|^6).
\]

Every raw coefficient through degree five is unchanged, not just c32 and c05. In particular F4 is not removed. The script's own docstring says it does not zero nonresonant channels. Its retained-coefficient output is correct in that limited sense, but it is not the desired three-channel normal form.

### 3.2 Projection of the dynamical logarithm

The generic p-step script forms

\[
G_{\rm proj}=\exp(P\log F_W),
\]

where P deletes every channel except (2,1),(3,2),(0,5). This deletes the quartic map terms and retains the raw resonant quintics. P is a projection of the dynamics, not a solved coordinate-change equation. The script exports the generator of this projected dynamics under a Phi6 filename.

### 3.3 The bridge test

If n=Phi1^{-1} f Phi1 and Psi=Phi1^{-1} Phi6, then algebraically

\[
\Psi^{-1}n^6\Psi=\Phi6^{-1}F_W\Phi6,
\]

not automatically G_proj. Here the exported Phi6 begins with the same cubic vector as F_W, so the degree-five bridge returns the raw jet. We reproduced this identity exactly and the uploaded script reproduces it numerically on reconstructed inputs. It does NOT prove F_W is conjugate to G_proj.

An expected-negative test changes the reconstructed raw c05 target by 1/1000. The source bridge prints a 1e-3 discrepancy but still exits 0. It has no assertion/exit gate for the printed comparisons.

## 4. Actual direct polynomial one-step normalization

The exactly solved coordinate map has

\[
h_2=-\frac{1+i\sqrt3}{12}z^2-\frac13z\bar z
+\frac{1-i\sqrt3}{24}\bar z^2.
\]

The remaining h3,...,h6 are supplied in coordinate_h_deg6_reconstructed.json. Their resonant coefficients are set to zero by the stated direct polynomial convention. h3 is nonzero; this is a different object from the archival nonresonant part of the return-log cubic.

Both full polynomial identities hold through degree six:

\[
f\circ h=h\circ n,\qquad
F_W\circ h=h\circ n^6.
\]

The normalized six-step jet is

\[
\widehat F(z)=z+\mu z^2\bar z+a_{32}z^3\bar z^2+a_{05}\bar z^5+O(|z|^7),
\]

where

\[
a_{32}=-\frac{97}{432}+\frac{197i\sqrt3}{324},\qquad
 a_{05}=-\frac{49}{8640}-\frac{307i\sqrt3}{25920}.
\]

All degree-two, degree-four and degree-six terms vanish in this normalized jet. The O(|z|^7) is a local analytic existence statement; no numerical C7 or domain has been computed.

For comparison, the raw coefficients retained by the projected model are

\[
c_{32}^{raw}=-\frac{77}{216}+\frac{97i\sqrt3}{648},\qquad
c_{05}^{raw}=-\frac{61}{2160}-\frac{43i\sqrt3}{6480}.
\]

The independently solved one-step normalized coefficients reproduce all three hardcoded bridge constants:

\[
A_6=\frac18-\frac{7i\sqrt3}{72},\quad
B_6=\frac{43}{17280}-\frac{227i\sqrt3}{155520},\quad
C_6=-\frac5{432}+\frac{23i\sqrt3}{3888}.
\]

In particular the bridge's B6_unverified decimal is consistent with this independently derived exact value. The true normalized lattice coefficient satisfies a05=6*conj(lambda)*B6, exactly.

## 5. Formal obstruction: the projected raw-coefficient model is not a near-identity conjugate

Scope: real formal coordinate changes with h(0)=0 and Dh(0)=I, same primitive W frame and same cubic return.

For a general real quadratic h2, cancellation of F4 requires

\[
F4+DF3\,h2-Dh2\,F3=0.
\]

The map from the six real coefficients of h2 to the ten real quartic coefficients has full rank six. The matrix and a nonzero 6x6 minor (determinant 1444/27) are exported in supplementary_checks.json. The solution is the h2 displayed above and is unique.

After that change, the pure anti-holomorphic quintic is a05. A further cubic coordinate correction modifies degree five by a bracket with F3. Each basis cubic correction has zero (0,5) component in that bracket; this is verified exactly for all eight real basis directions. Higher-order changes start affecting the return at degree six or later.

Therefore every identity-linear coordinate transformation that removes F4 has this same a05. But

\[
c_{05}^{raw}-a_{05}
=\frac{-13+3i\sqrt3}{576}\ne0.
\]

Consequently the three-channel projected model retaining raw c05 is NOT formally conjugate through degree five to the primitive return by an identity-linear coordinate change. The discrepancy is not merely an undecided cubic residual gauge.

This result does not refute the raw coefficients, the leading cubic dynamics, local contraction, or the existence of a nonzero lattice harmonic. It limits the identification between the projected model and the primitive dynamics.

## 6. Additional implementation qualifications

* normalize_pstep_lie.py is implemented correctly for log/re-exponentiation through degree five when the tangent part starts at degree three. Its advertised more general degree-two-leading input is not implemented correctly: x+x^2 reconstructs with extra x^3+x^4. The script does not validate its identity-linear/U2=0 preconditions.
* Its fixed order five cannot certify degree six or a seventh-order remainder.
* Its Phi6 export path is hardcoded and assumes an existing outputs directory; the header's general p interface is broader than that naming.
* Polynomial-key parsing uses eval in the supplied loaders. The present inputs were inspected; a reusable verifier should use literal parsing and schema validation.
* No source script here provides a rigorous numerical roundoff interval or a C6/C7 analytic remainder bound.

## 7. What is completed and what remains

Completed in the independent audit: exact primitive degree-six jet; uploaded jet identification; actual degree-six one-step coordinate normalization; exact conjugacy/iteration identities; full explanation and obstruction behind the archival/projection mismatch; reconstructed-input regression of the bridge.

Not completed: historical Phi1 provenance equivalence, explicit contraction q_ctr and six-phase tube, quantitative h inverse domain, C7 and derivative remainder bounds, RECOG heteroclinic entry, RECOG full-map memory.

Recommended next calculation: the primitive contraction branch, starting from the verified L1 radial polynomial and an explicit |R_ge6|<=C6 Q^3 bound. This branch does not depend on repairing the projected-log interpretation.

All result statuses in the owner DSNs remain unchanged.
