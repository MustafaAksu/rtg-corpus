# DYAD RETURN-ENCLOSURE — working convention contract

Status: working audit contract, not an amendment of a project DSN and not an owner-RID assignment.
The work-stage label P0 must not be confused with programme OPEN-P0 (generator selection).

## Fixed scope

Continuous p=6, K=1 primitive germ, a local lifted chart about (rho,eta)=(0,0):

\[
T(\rho,\eta)=(\rho-\sin\eta,\eta+e^\rho-1-\sin\eta),\quad F=T^6,
\quad Q_{\rm prim}=\rho^2-\rho\eta+\eta^2.
\]

No phase wrapping is performed in this local Taylor calculation. The invariant tube and its chart containment remain separate analytic proof obligations.

## Typed coordinates

\[
W=\rho+\omega\eta,\quad \omega=(-1+i\sqrt3)/2,
\quad\lambda=(1+i\sqrt3)/2,\quad |W|^2=Q_{\rm prim}.
\]

Let f=L T L^{-1}; F_W=f^6. W is the primitive LINEAR eigenframe, not a nonlinear normal-form coordinate.

The working normalized variable z is defined by W=h(z,bar z), with

\[
h(z)=z+\sum_{n=2}^6h_n(z,\bar z).
\]

This is an additive polynomial coordinate map, NOT a time-one exponential of the listed h_n. The one-step normalization is fixed by

\[
f\circ h=h\circ n+O(|z|^7),
\]

with all nonresonant coefficients of n through degree six zero and all resonant coefficients of h_n zero. Resonance means a-b-1=0 modulo 6. The exact coefficient file specifies h completely.

\[
\widehat F=h^{-1}\circ F_W\circ h,
\qquad Q_{\rm prim}=|h(z)|^2\ne|z|^2\text{ in general}.
\]

No equivalence with the historical phrase 'Lie strict-kernel' is assumed merely from the name. The archival scripts implement distinct objects described in the audit report.

## Data roles

* Uploaded jet1_deg5.json: independently identified as the RAW one-step W jet.
* New jet6_deg5_reconstructed.json: independently generated raw return; not an archived owner export.
* New phi1_deg5_reconstructed.json: direct polynomial one-step normalization h through degree five; not the missing archived Phi1.
* Projected log model exp(P log F_W): diagnostic reduced polynomial, not a certified coordinate-normalized copy of F_W.

## Acceptance obligations

A: explicit q_ctr,c>0 with 0<Q<=q_ctr => 0<Q(Fx)<=Q-cQ^2; six-phase invariant tube; chart containment.

B: explicit domain, coordinate invertibility/containment, and C7 with

\[
|\widehat F(z)-\mathcal J_{\le6}(z)|\le C_7|z|^7.
\]

A polynomial exact jet does not supply an explicit C7. The inverse function theorem supplies only local existence before quantitative bounds are derived.

NUMGEN and RECOG applications remain separately gated. No heteroclinic-entry or full-map memory theorem is closed by this audit.
