# DYAD RETURN-ENCLOSURE — supplied artifacts and exact P0/P1 audit

## Main result

The uploaded jet1 JSON is the primitive **raw** one-step W jet. The six-step jet and a true direct-polynomial one-step normalization were reconstructed exactly through degree six, then independently verified with a second polynomial arithmetic implementation.

The archival coordinate change leaves the raw quartic return intact. The separate log/projection script deletes that quartic term but retains raw quintic coefficients; its output is a projected dynamical model, not a conjugate normal form. An exact degree-five obstruction establishes this distinction, independently of naming conventions.

The Number Genesis L1 source script passes all nine exact symbolic assertions. It does not provide an explicit contraction radius, as its accompanying certificate already states.

## Read first

* `notes/P0_CONVENTION_CONTRACT.md`: typed working convention and analytic acceptance targets.
* `notes/AUDIT_AND_PROOF.md`: source execution scope, exact result, no-conjugacy argument, remaining work.
* `input_manifest.json`: SHA-256 hashes of the six supplied inputs.
* `source_integrity.json`: byte-integrity check of all pre-existing top-level input files.

## Exact outputs

`outputs/jet6_deg6_reconstructed.json`, `outputs/coordinate_h_deg6_reconstructed.json`, `outputs/normalized_onestep_deg6.json`, and `outputs/normalized_sixstep_deg6.json` contain exact SymPy-readable coefficients. The primitive real jets and radial polynomial are also exported.

These are NEW independent reconstruction artifacts. In particular `phi1_deg5_reconstructed.json` and `jet6_deg5_reconstructed.json` are not copies of the unavailable historical owner files.

## Reproduce

From this directory, with the dependencies in `requirements.txt`:

```sh
python scripts/run_all.py
```

Do not run Python with `-O`, because the supplied L1 script and the independent verifiers use assertions. The original bridge failure due to missing historical Phi1 is preserved in `logs/gauge_bridge_original.log`. The reconstructed-input bridge replay uses a separate run directory and explicitly records input provenance.

`negative_bridge_control.py` intentionally changes a reconstructed target by 1/1000. It verifies that the unmodified source bridge still exits zero despite printing the discrepancy. This is an expected negative control, not a modification of a project input.

## Limits

No explicit q_ctr, C6, C7, quantitative inverse domain, six-phase tube, heteroclinic entry or full-map lattice-memory theorem is certified here. No DSN or original artifact was edited and no official result status or ownership was changed. Programme OPEN-P0 (generator selection) is not the work-stage P0 used in this package name.
