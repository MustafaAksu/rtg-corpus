"""Independent semantic checks of reconstructed jets and harmonics. Pass counts are diagnostics."""
import json,sys
from pathlib import Path
import sympy as sp
HERE=Path(__file__).resolve().parents[1]
P=HERE/'data'
j=json.loads((P/'jet_coefficients.json').read_text())
fourier=json.loads((P/'angular_quintic_harmonics.json').read_text())
X=sr,se,cr,ce=sp.symbols('s_rho s_eta c_rho c_eta',real=True)
B=sp.Matrix([[1,sp.Rational(-1,2)],[sp.Rational(-1,2),1]])
J=sp.Matrix([[1,-2],[2,-1]])/sp.sqrt(3)
s=sp.Matrix([sr,se]); c=sp.Matrix([cr,ce])
Qs=(s.T*B*s)[0];Qc=(c.T*B*c)[0]; I=(s.T*B*c)[0]; om=se*cr-sr*ce; Omega=sp.sqrt(3)*om/2

def parse(p):
 return sp.expand(sum(sp.Rational(co)*sp.prod(v**n for v,n in zip(X,map(int,key.split(',')))) for key,co in p.items()))
G3=sp.Matrix([parse(p) for p in j['G3']]);G4=sp.Matrix([parse(p) for p in j['G4']]);Q5=[parse(p) for p in j['quintic_readout']]
checks=0

def check(cond,name):
 global checks
 if cond is not True and cond != sp.S.true:raise AssertionError(name)
 checks+=1
 print('PASS',checks,name)

def ez(v):
 if isinstance(v,sp.MatrixBase):return all(sp.expand(t)==0 for t in v)
 return sp.expand(v)==0
check(ez(J*J+sp.eye(2)), 'J^2=-I')
check(ez(J.T*B*J-B), 'J B-isometry')
check(ez(Qs*Qc-I**2-Omega**2),'signed Gram identity')
Gs_src=(Qs/sp.Integer(8)+Qc/2)*s-I*c/3-sp.sqrt(3)*(Qs/4+Qc/9)*J*s-2*sp.sqrt(3)*I*J*c/9
Gc_src=Qc*c/6+(I+om)*s/8-(4*I+9*om)*J*s/(16*sp.sqrt(3))-(sp.sqrt(3)*Qs/6+sp.sqrt(3)*Qc/3)*J*c
for i,(v,w) in enumerate(zip(G3,list(Gs_src)+list(Gc_src)),1):
 check(ez(v-w), f'G3 component {i} matches Genesis handoff')
FullJ=sp.diag(J,J)
Xv=sp.Matrix(X)
def div(scal,V):
 return sp.expand(sum(sp.diff(scal,x)*v for x,v in zip(X,V)))
for i,expr in enumerate(sp.Matrix([G3]).reshape(4,1).jacobian(X)*FullJ*Xv-FullJ*G3,1):
 check(ez(expr), f'G3 infinitesimal equivariance {i}')
q4_src=[Qs**2/4+I**2/3-4*sp.sqrt(3)*I*Omega/9+Omega**2,
        Qc**2/3+I**2/4+I*Omega/sp.sqrt(3)+3*Omega**2/4,
        (Qs/4+Qc/3)*I+sp.sqrt(3)*(Qs/6-2*Qc/9)*Omega,
        (Qs/2+2*Qc/3)*Omega]
for i,(observable,target) in enumerate(zip((Qs,Qc,I,Omega),q4_src),1):
 check(ez(div(observable,G3)-target),f'quartic {i} matches handoff')
for i,observable in enumerate((Qs,Qc,I,Omega)):
 got=Q5[i]* (sp.sqrt(3)/2 if i==3 else 1)
 check(ez(got-div(observable,G4)),f'quintic observable {i+1} is DΦ·G4')
check(ez(2*Q5[0].subs(dict(zip(X,(1,0,0,1))))-sp.Rational(349,288)),'nondegenerate -X witness 349/288')
check(ez(2*Q5[0].subs(dict(zip(X,(1,0,0,0))))-sp.Rational(5,32)),'pure-parent -X witness 5/32')
# Independent rotation-generator annihilator of the fifth-harmonic sector.
# If f(theta) has only modes +/-1,+/-3 then (D_theta^2+1)(D_theta^2+9) f=0.
def rotation_derivative(poly):
 direction=FullJ*Xv
 return sp.expand(sum(sp.diff(poly,v)*d for v,d in zip(X,direction)))
for i,poly in enumerate(Q5):
 second=rotation_derivative(rotation_derivative(poly))
 fourth=rotation_derivative(rotation_derivative(second))
 check(ez(fourth+10*second+9*poly),f'Phi quintic observable {i+1} annihilated by (D_rot^2+1)(D_rot^2+9)')
# A finite chart check of Laurent coefficients at exact common rotations:
a,h,k,angle=sp.symbols('a h k theta',real=True)
u=sp.symbols('u',nonzero=True)
co={label:{int(mode):sp.sympify(coeff,locals={'I':sp.I,'a':a,'h':h,'k':k}) for mode,coeff in d.items()} for label,d in fourier['Phi5'].items()}
for i,label in enumerate(('Qs','Qc','I','Omega')):
 check(sorted(co[label])==[-3,-1,1,3],f'{label} harmonic support exactly ±1, ±3')
 # Use a=1 h=-1/2 k=√3/2 => s=e1 c=e2
 vals={m:sp.expand(expr.subs({a:1,h:sp.Rational(-1,2),k:sp.sqrt(3)/2})) for m,expr in co[label].items()}
 for C,S,ui in ((1,0,sp.Integer(1)),(0,1,sp.I),(-1,0,sp.Integer(-1))):
  state=(C+S/sp.sqrt(3),2*S/sp.sqrt(3),
   -C/sp.Integer(2)-sp.sqrt(3)*S/2+(-S/sp.Integer(2)+sp.sqrt(3)*C/2)/sp.sqrt(3),
   2*(-S/sp.Integer(2)+sp.sqrt(3)*C/2)/sp.sqrt(3))
  poly=sp.expand((Q5[i]*(sp.sqrt(3)/2 if i==3 else 1)).subs(dict(zip(X,state))))
  ft=sp.expand(sum(v*(ui**m) for m,v in vals.items()))
  check(ez(poly-ft),f'{label} harmonic reconstruction at common angle ({C},{S})')
# Φ on witness reference (s=e1, c=e2); m1 nonzero and m3 nonzero
check(co['Qs'][1]!=0 and co['Qs'][3]!=0,'generic witness has first and third harmonics')
check(sp.expand(4*sum(sp.re(co['Qs'][m].subs({a:1,h:sp.Rational(-1,2),k:sp.sqrt(3)/2})) for m in (1,3))-sp.Rational(349,288))==0,'Fourier witness 349/288')
print(f'ALL {checks} EXACT CHECKS PASS')
if '--negative-C3' in sys.argv:
 check(3 not in co['Qs'],'wrong absence of third harmonic')

if '--negative-C3-quotient' in sys.argv:
 check(co['Qs'][1]==0,'false C3 cyclic quotient: first harmonic nonzero')
