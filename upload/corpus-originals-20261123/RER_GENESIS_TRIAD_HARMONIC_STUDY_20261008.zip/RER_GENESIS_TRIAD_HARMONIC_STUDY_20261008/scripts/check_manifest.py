"""Verify SHA-256 and size of the final package members."""
import json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text())
for f in manifest['files']:
 b=(root/f['path']).read_bytes()
 assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
print('MANIFEST PASS:',len(manifest['files']),'file bytes/hashes')
