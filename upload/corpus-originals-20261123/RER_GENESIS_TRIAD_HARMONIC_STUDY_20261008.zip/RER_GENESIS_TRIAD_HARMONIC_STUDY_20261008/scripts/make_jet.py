from fractions import Fraction as F
from functools import reduce
from collections import defaultdict
import json
from pathlib import Path
D=4; CAP=4
ZERO=(0,)*D

def constant(x):
 x=F(x)
 return {ZERO:x} if x else {}

def variable(i):
 e=list(ZERO); e[i]=1
 return {tuple(e):F(1)}

def add(*polys):
 r=defaultdict(F)
 for p in polys:
  for m,c in p.items():r[m]+=c
 return {m:c for m,c in r.items() if c}

def scale(p,a):
 a=F(a);return {m:c*a for m,c in p.items() if c*a}

def mul(a,b):
 r=defaultdict(F)
 for m,c in a.items():
  for n,d in b.items():
   k=tuple(x+y for x,y in zip(m,n))
   if sum(k)<=CAP:r[k]+=c*d
 return {m:c for m,c in r.items() if c}

def pw(p,n):
 r=constant(1)
 for _ in range(n):r=mul(r,p)
 return r

def homogeneous(p,n):return {m:c for m,c in p.items() if sum(m)==n}

def lin(ps,as_):return add(*(scale(p,a) for p,a in zip(ps,as_)))

def N(state):
 sr,se,cr,ce=state
 E=((F(1),F(0)),(F(-1,2),F(1)),(F(-1,2),F(-1)))
 P=((F(2,3),F(-1,3),F(-1,3)),(F(0),F(1,2),F(-1,2)))
 rho=[];eta=[]
 for a,b in E:
  rr=lin((sr,cr),(a,b));ee=lin((se,ce),(a,b))
  ro=add(rr,scale(ee,-1),scale(pw(ee,3),F(1,6)))
  et=add(rr,scale(pw(rr,2),F(1,2)),scale(pw(rr,3),F(1,6)),scale(pw(rr,4),F(1,24)),scale(pw(ee,3),F(1,6)))
  rho.append(ro);eta.append(et)
 return (lin(rho,P[0]),lin(eta,P[0]),lin(rho,P[1]),lin(eta,P[1]))

X=[variable(i) for i in range(4)]; Y=X
for i in range(6):
 Y=N(Y)
 print(f'iteration {i+1}',*[len(p) for p in Y],flush=True)
assert all(homogeneous(add(Y[j],scale(X[j],-1)),k)=={} for j in range(4) for k in (0,1,2))
G3=[homogeneous(p,3) for p in Y]
G4=[homogeneous(p,4) for p in Y]
print('G3 term count',list(map(len,G3)), 'G4 term count',list(map(len,G4)))
# B = [[1,-1/2],[-1/2,1]]
sr,se,cr,ce=X
Qs=add(pw(sr,2),scale(mul(sr,se),-1),pw(se,2))
Qc=add(pw(cr,2),scale(mul(cr,ce),-1),pw(ce,2))
I=add(mul(sr,cr),scale(mul(sr,ce),F(-1,2)),scale(mul(se,cr),F(-1,2)),mul(se,ce))
omega_raw=add(mul(se,cr),scale(mul(sr,ce),-1))
from itertools import product
# quintic readout effects after multiplying by G4, use custom uncapped mul allowing degree5
CAP=5
q5=add(scale(mul(sr,G4[0]),2),scale(mul(se,G4[1]),2),scale(mul(sr,G4[1]),-1),scale(mul(se,G4[0]),-1))
c5=add(scale(mul(cr,G4[2]),2),scale(mul(ce,G4[3]),2),scale(mul(cr,G4[3]),-1),scale(mul(ce,G4[2]),-1))
i5=add(mul(G4[0],cr),mul(sr,G4[2]),mul(G4[1],ce),mul(se,G4[3]),scale(mul(G4[0],ce),F(-1,2)),scale(mul(sr,G4[3]),F(-1,2)),scale(mul(G4[1],cr),F(-1,2)),scale(mul(se,G4[2]),F(-1,2)))
o5_raw=add(mul(G4[1],cr),mul(se,G4[2]),scale(mul(G4[0],ce),-1),scale(mul(sr,G4[3]),-1))
assert all(all(sum(m)==5 for m in p) for p in (q5,c5,i5,o5_raw))
# radial witness (t,0,0,t)
witness=lambda p:sum(c for m,c in p.items() if m[1]==0 and m[2]==0)
print('witness DeltaQs quintic coefficient under simultaneous -X', 2*witness(q5))
print('pure-parent difference',2*q5.get((5,0,0,0),0))
assert 2*witness(q5)==F(349,288)
assert 2*q5.get((5,0,0,0),0)==F(5,32)

P=Path(__file__).resolve().parents[1]/'data'
obj={'generator':'N=(P tensor I2) o T_e^3 o(E tensor I2); F=N^6', 'coordinates':['s_rho','s_eta','c_rho','c_eta'], 'G3':[{','.join(map(str,m)):str(c) for m,c in sorted(p.items())} for p in G3], 'G4':[{','.join(map(str,m)):str(c) for m,c in sorted(p.items())} for p in G4], 'quintic_readout':[{','.join(map(str,m)):str(c) for m,c in sorted(p.items())} for p in (q5,c5,i5,o5_raw)]}
P.joinpath('jet_coefficients.json').write_text(json.dumps(obj,indent=2)+'\n')
print('wrote jet coefficients', 'G4 terms',sum(map(len,G4)), 'quintic readout',list(map(len,(q5,c5,i5,o5_raw))))
