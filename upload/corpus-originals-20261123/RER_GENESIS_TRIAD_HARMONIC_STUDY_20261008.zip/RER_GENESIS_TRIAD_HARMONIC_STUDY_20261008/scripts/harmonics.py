"""Independently compute common-frame quintic observable Fourier polynomials
from exact rational 6-step jet. No physical gauge action selected.
"""
import json
from pathlib import Path
from fractions import Fraction as Fr
from collections import defaultdict
from math import comb
import sympy as S
P=Path(__file__).resolve().parents[1]/'data'
jet=json.loads((P/'jet_coefficients.json').read_text())
A,H,K=S.symbols('a h k',real=True) # a=sqrt(Qs); h=I/a; k=-Omega/a
u=S.symbols('u',nonzero=True)
C=S.symbols('C',real=True); V=S.symbols('S',real=True)
r=S.sqrt(3)
base=(A*C+A*V/r, 2*A*V/r,
      H*C-K*V+(H*V+K*C)/r, 2*(H*V+K*C)/r)
# faster polynomial expansion in C,S for each monomial then substitute Fourier with binomial combos
variables=[A,H,K]

def chart_monomial(exp):
 f=S.Integer(1)
 for b,n in zip(base,exp):
  if n: f*=b**n
 return S.Poly(f,C,V,domain='EX')

monset={tuple(map(int,key.split(','))) for p in jet['quintic_readout'] for key in p}
monchart={m: chart_monomial(m) for m in sorted(monset)}
print('chart monomials',len(monchart),flush=True)

def CSpower_fourier(i,j):
 # C=(u+u^-1)/2, S=(u-u^-1)/(2i)
 res=defaultdict(lambda:S.Integer(0))
 for x in range(i+1):
  for y in range(j+1):
   weight=i+j-2*(x+y)
   val=S.Rational(comb(i,x)*comb(j,y),2**(i+j))*(-1)**y*S.I**(-j)
   res[weight]+=val
 return {m:S.expand(v) for m,v in res.items() if v}

fourier_cache={(i,j): CSpower_fourier(i,j) for i in range(6) for j in range(6) if i+j==5}
out=[]
for label,obs in zip(('Qs','Qc','I','Omega_raw'),jet['quintic_readout']):
 terms=defaultdict(lambda:S.Integer(0))
 for mon, coeff in obs.items():
  poly=monchart[tuple(map(int,mon.split(',')))]
  for (ci,si),v in poly.terms():
   terms[(ci,si)]+=S.Rational(coeff)*v
 print(label,'C/S basis terms',len(terms),flush=True)
 hcoeff=defaultdict(lambda:S.Integer(0))
 for ij,v in terms.items():
  for mode,unit in fourier_cache[ij].items():
   hcoeff[mode]+=v*unit
 # maybe large but simplify each coefficient by substituting k etc can be heavy
 hcoeff={mode:S.expand(val) for mode,val in hcoeff.items() if val!=0}
 hcoeff={mode:val for mode,val in hcoeff.items() if val!=0}
 print(label, 'modes', sorted(hcoeff), flush=True)
 if label=='Omega_raw':hcoeff={m:S.sqrt(3)*v/2 for m,v in hcoeff.items()}
 out.append(hcoeff)

assert all(set(g.keys()).issubset({-5,-3,-1,1,3,5}) for g in out)
for label,hcoeff in zip(('Qs','Qc','I','Omega'),out):
 print('======',label, 'nonzero Fourier frequencies',sorted(hcoeff),flush=True)
# all exact coefficients and symbolic global structure
result={'variables':{'a':'sqrt(Qs) > 0', 'h':'I/a', 'k':'-Omega/a', 'u':'exp(i theta_s)'},
        'carrier':'B=[[1,-1/2],[-1/2,1]]', 'notation':'I is imaginary unit sqrt(-1) in coefficient strings; I_sc is represented by a*h',
        'orders':'coefficient of t^5 for inputs (s,c) scaled by t with fixed chart shape',
        'coefficient_representation': 'Phi5(theta)=sum_m Fourier[m]*exp(i m theta_s); Omega=+sqrt(3)/2 omega_raw',
        'Phi5':{label:{str(m):str(S.expand(val)) for m,val in sorted(c.items())} for label,c in zip(('Qs','Qc','I','Omega'),out)}}
(P/'angular_quintic_harmonics.json').write_text(json.dumps(result,indent=2)+'\n')

# witness base x=e1,c=e2 has a=1,h=-1/2,k=+sqrt(3)/2
point={A:1,H:S.Rational(-1,2),K:S.sqrt(3)/2}
for label,hcoeff in zip(('Qs','Qc','I','Omega'),out):
 vals={m:S.expand(val.subs(point)) for m,val in hcoeff.items()}
 print('WITNESS',label, [(m,str(vals.get(m,0))) for m in (1,3,5)],flush=True)
 if label=='Qs':
  assert S.expand(4*sum(S.re(v) for m,v in vals.items() if m>0)-S.Rational(349,288))==0 # Phi5(0)-Phi5(pi) = 4 Re sum positives
print('SAVED',P/'angular_quintic_harmonics.json')
