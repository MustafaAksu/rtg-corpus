"""Check provenance and schema of proposed branch, not physical adoption."""
import hashlib,json,sys
from pathlib import Path
p=Path(__file__).resolve().parents[1]
r=json.loads((p/'data'/'RER_TRIAD_CONDITIONAL_ENTRIES.json').read_text())
check=0

def okay(ok, label):
 global check
 if not ok:raise AssertionError(label)
 check+=1
 print(f'PASS {check}: {label}')
okay(r['physical_target_status']=='NO_TARGET_VECTOR_LAW_SELECTED','physical target remains unselected')
okay(r['document_status']=='NONCANONICAL_WORKING_SUPPLEMENT','registry is noncanonical')
okay(len(r['records'])==3,'exactly three conditional records')
okay(len({x['id'] for x in r['records']})==3,'local keys unique')
okay({x['closure_status'] for x in r['records']}=={'DISPROVED_EXACT_CLOSURE_FOR_SURROGATE','EXACT_CLOSURE_FOR_SURROGATE','DISPROVED_EXACT_CLOSURE_FOR_NAMED_MODEL'},'typed statuses present')
for fname,meta in r['source_snapshots'].items():
 b=(p/'sources'/fname).read_bytes()
 okay(hashlib.sha256(b).hexdigest()==meta['sha256'] and len(b)==meta['bytes'],f'{fname}: pinned byte/hash match')
for x in r['records']:
 for field in ('carrier','observables','constraints','transformation_law','closure_status','memory','next_test','adoption'):
  okay(bool(x[field]),f'{x["id"]}: {field} populated')
 okay(x['adoption']=='NOT_ADOPTED_NONCANONICAL',f'{x["id"]}: no owner adoption implied')
for x in r['records']:
 okay(x['parent_id'] in ('RER-T01','RER-T02'),'parent registry key preserved')
okay(all('physical' not in x['closure_status'].lower() for x in r['records']),'all statuses conditional, not physical')
print(f'ALL {check} REGISTRY CHECKS PASS')
