# RER Genesis triad conditional branch: first harmonic result

Noncanonical receiving study, 2026-10-08. The physical target remains unselected, the original registry v0.1 untouched, and no owner adoption is implied.

Read `notes/TRIAD_RECEIVING_REVIEW_AND_HARMONICS.md` first. The machine-readable proposed subrecords are in `data/RER_TRIAD_CONDITIONAL_ENTRIES.json`.

Reproduce locally with Python 3 and SymPy:

```sh
python scripts/make_jet.py
python scripts/harmonics.py
python scripts/validate.py
python scripts/validate.py --negative-C3  # intentionally fails with exit 1
python scripts/validate.py --negative-C3-quotient  # intentionally fails with exit 1
python scripts/check_registry.py
```

All source snapshots are under `sources/`; generated data retain exact rational coefficients. Reruns overwrite only generated files inside this research package.
