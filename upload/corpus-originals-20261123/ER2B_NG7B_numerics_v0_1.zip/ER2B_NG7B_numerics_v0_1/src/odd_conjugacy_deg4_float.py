from sympy import *
z,zb,e=symbols('z zb e')
lam=complex(0.5,3**0.5/2); lamb=lam.conjugate()
NN=4
def tr(f):  # truncate total degree<=N in z,zb
    f=expand(f.subs({z:e*z,zb:e*zb}))
    return sum(f.coeff(e,d) for d in range(NN+1))
def cj(f):  # complex conjugate as formal series
    return expand(conjugate(f).subs({conjugate(z):zb,conjugate(zb):z})) if False else None
def conj_series(f):
    p=Poly(expand(f),z,zb); out=0
    for (a,b),c in p.terms(): out+=conjugate(complex(c))*z**b*zb**a
    return out
def comp(f,g):  # f(g, conj g)
    gb=conj_series(g)
    return tr(f.subs({z:g,zb:gb},simultaneous=True))
# T in w coords
eta=(z-zb)/((1j*3**0.5)); rho=(z+zb)/2+eta/2
ser=lambda fn,x: sum(diff(fn(Symbol('t')),Symbol('t'),k).subs(Symbol('t'),0)/factorial(k)*x**k for k in range(NN+1))
s=ser(sin,eta); ex=ser(exp,rho)
r1=rho-s; e1=eta+ex-1-s
T=tr(r1-e1/2+(1j*3**0.5)/2*e1)
def deg(f,d):
    f=expand(f.subs({z:e*z,zb:e*zb})); return expand(f.coeff(e,d))
print("lin:",N(deg(T,1)))
def hom(g,d):  # solve lam*h - h(lam z) = -g  => h_ab = g_ab/(lam^a lamb^b - lam)
    p=Poly(g,z,zb); h=0
    for (a,b),c in p.terms(): h+=c/(lam**a*lamb**b-lam)*z**a*zb**b
    return expand(h)
def inverse(H):
    G=z
    for _ in range(NN): G=tr(z-(comp(H,G)-G))
    return G
h2=hom(deg(T,2),2); print("h2:",[N(c) for c in Poly(h2,z,zb).coeffs()])
H=z+h2; Hi=inverse(H)
T1=comp(Hi,comp(T,H))
print("T1 deg2:",N(deg(T1,2)))
c3=Poly(deg(T1,3),z,zb)
print("T1 deg3:",{m:N(N(c)) for m,c in c3.terms()})
c21=c3.coeff_monomial(z**2*zb); print("6*c21/lam =",N(6*c21/lam))
g4=deg(T1,4); print("T1 deg4 nonzero monomials:",[m for m,c in Poly(g4,z,zb).terms()])
h4=hom(g4,4); H4=z+h4; T2=comp(inverse(H4),comp(T1,H4))
print("T2 deg2:",N(deg(T2,2)),"deg4:",N(deg(T2,4)))
print('T2-T1 deg3:',N(deg(T2,3)-deg(T1,3)))
