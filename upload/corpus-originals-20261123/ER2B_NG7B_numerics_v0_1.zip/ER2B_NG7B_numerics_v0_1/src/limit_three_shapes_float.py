import math,cmath
s3=math.sqrt(3); tau=2*s3/3
def run(r,steps,marks):
    r=[list(x) for x in r]
    w0=[complex(x[0]-x[1]/2,s3/2*x[1]) for x in r]
    L=abs(sum(cmath.exp(1j*(cmath.phase(w)-tau*math.log(abs(w)**2))) for w in w0))/s3
    print(" predicted limit |h|/sqrt(N) =%.4f"%L, " Q0:",["%.2e"%abs(w)**2 for w in w0])
    for n in range(1,steps+1):
        for x in r:
            s=math.sin(x[1]); a=x[0]-s; b=x[1]+math.exp(x[0])-1-s; x[0]=a; x[1]=b
        if n in marks:
            w=[complex(x[0]-x[1]/2,s3/2*x[1]) for x in r]
            N=sum(abs(v)**2 for v in w); print("   n=%8d N=%.3e |h|/sqrt(N)=%.4f"%(n,N,abs(sum(w))/math.sqrt(N)))
marks={6*10**k for k in range(2,7)}|{3*10**6,12*10**6}
for amp,a,b in ((0.03,0.3,-0.4),(0.03,-0.8,0.1),(0.02,0.9,0.7)):
    r=[(amp,a*amp),(b*amp,amp)]; r.append((-r[0][0]-r[1][0],-r[0][1]-r[1][1]))
    print("case",amp,a,b); run(r,12*10**6,marks)
