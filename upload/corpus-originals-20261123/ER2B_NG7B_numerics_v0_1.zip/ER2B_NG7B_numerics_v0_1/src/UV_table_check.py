from sympy import *
import random
a1,a2,b1,b2,e=symbols('a1 a2 b1 b2 e')
def run(c):
    al,be,ga,de,ep,ze=c
    def T(x):
        r,h=x
        return (r-h+al*r*r+be*r*h+ga*h*h, r+de*r*r+ep*r*h+ze*h*h)
    def F(r):
        t=[T(x) for x in r]
        m=[sum(u[k] for u in t)/3 for k in range(2)]
        return [(u[0]-m[0],u[1]-m[1]) for u in t]
    tr=lambda x: tuple(sum(expand(c_).coeff(e,d)*e**d for d in range(4)) for c_ in x)
    r0=[(e*a1,e*a2),(e*b1,e*b2),(-e*a1-e*b1,-e*a2-e*b2)]
    cur=r0
    for n in range(6): cur=[tr(x) for x in F(cur)]
    quad=[expand(cur[i][k]).coeff(e,2) for i in range(2) for k in range(2)]
    D=[expand(cur[0][k]-cur[1][k]).coeff(e,3) for k in range(2)]
    Um=diff(D[0],a1,b1).coeff(a2,1); Vm=diff(D[1],a1,b1).coeff(a2,1)
    full=[[simplify(diff(D[k],A,B)) for k in range(2)] for A in (a1,a2) for B in (b1,b2)]
    # formula
    wr,wi=symbols('wr wi',real=True)
    h=2*wi/sqrt(3); r=wr+h/2
    qr=al*r*r+be*r*h+ga*h*h; qh=de*r*r+ep*r*h+ze*h*h
    Q=expand(qr-qh/2+I*sqrt(3)/2*qh)
    u,v,t=symbols('u v t')
    w=wr+I*wi; wb=wr-I*wi
    sol=solve(Poly(expand(u*w*w+v*w*wb+t*wb*wb-Q),wr,wi).coeffs(),[u,v,t],dict=True)[0]
    u,v,t=sol[u],sol[v],sol[t]
    U=simplify(-12*re(u*v)+4*sqrt(3)*im(u*v)-2*abs(v)**2-4*abs(t)**2)
    V=simplify(-12*re(u*v)-4*sqrt(3)*im(u*v)+2*abs(v)**2-8*abs(t)**2)
    tab=[[U*(a2-b2),V*(a2-b2)],[-U*(2*a1+b1)+V*(a2+2*b2),-U*(a2+2*b2)+V*(-2*a1+a2-b1+2*b2)],
         [U*(a1+2*b1)-V*(2*a2+b2),U*(2*a2+b2)+V*(a1-2*a2+2*b1-b2)],[V*(a1-b1),(V-U)*(a1-b1)]]
    ok=all(simplify(full[i][k]-tab[i][k])==0 for i in range(4) for k in range(2))
    print(c,"quad0:",all(x==0 for x in quad),"meas U,V:",Um,Vm,"formula:",U,V,"table ok:",ok)
R=Rational
run((0,0,0,R(1,2),0,0)); run((0,0,1,1,0,0))
random.seed(1)
for _ in range(2): run(tuple(R(random.randint(-5,5),random.randint(1,4)) for _ in range(6)))
