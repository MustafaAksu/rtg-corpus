import numpy as np
def T(r): return np.array([r[0]-np.sin(r[1]), r[1]+np.exp(r[0])-1-np.sin(r[1])])
def Q(r): 
    w=complex(r[0]-r[1]/2, np.sqrt(3)/2*r[1]); return abs(w)**2
for kappa in (0.0,0.5,0.9):
  for amp in (0.02,0.01):
    r=[np.array([amp,0.3*amp]),np.array([-0.4*amp,amp])]; r.append(-r[0]-r[1])
    out=[]
    for n in range(1,60001):
        t=[T(x) for x in r]; m=sum(t)/3
        r=[x-kappa*m for x in t]
        if n in (6,60,600,6000,60000):
            h=sum(r); Nn=sum(Q(x) for x in r)
            out.append((n,float(np.linalg.norm(h)),Nn,float(np.linalg.norm(h))/Nn))
    print("kappa",kappa,"amp",amp)
    for o in out: print("   n=%6d |h|=%.3e N=%.3e |h|/N=%.3f"%o)
