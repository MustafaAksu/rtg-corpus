from sympy import *
a1,a2,b1,b2,e=symbols('a1 a2 b1 b2 e')
def T(x): return (x[0]-sin(x[1]), x[1]+exp(x[0])-1-sin(x[1]))
def F(r):
    t=[T(x) for x in r]
    m=[sum(u[k] for u in t)/3 for k in range(2)]
    return [(u[0]-m[0],u[1]-m[1]) for u in t]
r0=[(e*a1,e*a2),(e*b1,e*b2),(-e*a1-e*b1,-e*a2-e*b2)]
tr=lambda x: tuple(series(c,e,0,4).removeO().expand() for c in x)
cur=r0
for n in range(6): cur=[tr(x) for x in F(cur)]
for i in range(3):
  for k in range(2):
    d=expand(cur[i][k]-r0[i][k])
    print("edge",i+1,"comp",k,"quad:",factor(d.coeff(e,2)),"| lin:",d.coeff(e,1))
    print("   G3:",factor(d.coeff(e,3)))
for k in range(2):
  D=(cur[0][k]-cur[1][k]).subs(e,1)
  for A in (a1,a2):
    for B in (b1,b2):
      print("Om",k,A,B,factor(diff(D,A,B)))
