from sympy import *
a1,a2,b1,b2,e=symbols('a1 a2 b1 b2 e',real=True)
def T(x): return (x[0]-sin(x[1]), x[1]+exp(x[0])-1-sin(x[1]))
def F(r):
    t=[T(x) for x in r]
    m=[sum(u[k] for u in t)/3 for k in range(2)]
    return [(u[0]-m[0],u[1]-m[1]) for u in t]
tr=lambda x: tuple(series(c,e,0,4).removeO().expand() for c in x)
W=lambda x: x[0]-x[1]/2+I*sqrt(3)/2*x[1]
# isolated dyad
cur=(e*a1,e*a2)
for n in range(6): cur=tr(T(cur))
g=[expand(c).coeff(e,3) for c in cur]; print("dyad quad:",[expand(c).coeff(e,2) for c in cur])
mu=simplify(W(g).subs({a1:1,a2:0})); print("mu dyad:",mu, "check form:",simplify(expand(W(g)-mu*W((a1,a2))*abs(W((a1,a2)))**2)))
# triad
r0=[(e*a1,e*a2),(e*b1,e*b2),(-e*a1-e*b1,-e*a2-e*b2)]
cur=r0
for n in range(6): cur=[tr(x) for x in F(cur)]
w=[W((a1,a2)),W((b1,b2))]; w.append(-w[0]-w[1])
G=[W(tuple(expand(c).coeff(e,3) for c in x)) for x in cur]
N=sum(expand(x*conjugate(x)) for x in w); S=im(expand(w[0]*conjugate(w[1])))
dN=expand(sum(2*re(expand(conjugate(w[k])*G[k])) for k in range(3)))
print("dN - (N^2/6+2S^2):",simplify(dN-expand(N**2/6+2*S**2)))
dS=im(expand(G[0]*conjugate(w[1])+w[0]*conjugate(G[1])))
print("dS - NS/3:",simplify(expand(dS-N*S/3)))
