from mpmath import mp, mpf, mpc, sin, exp, sqrt
mp.dps=40
s3=sqrt(3)
def T(r): return (r[0]-sin(r[1]), r[1]+exp(r[0])-1-sin(r[1]))
W=lambda r: mpc(r[0]-r[1]/2, s3/2*r[1])
mu=mpc(-0.5,-2*s3/3)
def block(amp):
    r=[(amp,mpf('0.3')*amp),(-mpf('0.4')*amp,amp)]; r.append((-r[0][0]-r[1][0],-r[0][1]-r[1][1]))
    w0=[W(x) for x in r]
    for _ in range(6): r=[T(x) for x in r]
    dh=sum(W(x) for x in r)
    pred=mu*sum(w*abs(w)**2 for w in w0)
    return dh,pred
prev=None
for k in range(1,6):
    amp=mpf(2)**(-k)/10
    dh,pred=block(amp); res=abs(dh-pred)
    print("amp %.5f |dh|=%.3e |pred|=%.3e resid=%.3e"%(amp,abs(dh),abs(pred),res), "ratio prev/this=%.2f"%(prev/res) if prev else "")
    prev=res
