#include <stdio.h>
#include <math.h>
#include <complex.h>
#include <stdlib.h>
typedef long double complex C; typedef long double R;
static R s3;
static C Tw(C w){ R eta=2*cimagl(w)/s3, rho=creall(w)+eta/2; R sn=sinl(eta); R a=rho-sn,b=eta+expm1l(rho)-sn; return (a-b/2)+I*(s3/2*b);}
static C h2(C z){ C zb=conjl(z); return (-(1+I*s3)/12)*z*z-(1.0L/3)*z*zb+((1-I*s3)/24)*zb*zb;}
static C H(C z){return z+h2(z);}
static C Hinv(C w){ C z=w; for(int i=0;i<60;i++){ C zn=w-h2(z); if(cabsl(zn-z)<1e-19L*cabsl(w)){z=zn;break;} z=zn;} return z;}
static void step(C*z,int model){ C t[3],m=0; for(int e=0;e<3;e++){ t[e]= model? Hinv(Tw(H(z[e]))) : Tw(z[e]); m+=t[e];} m/=3; for(int e=0;e<3;e++) z[e]=t[e]-m; }
static void obs(C*z,R*N,R*S){ *N=0; for(int e=0;e<3;e++)*N+=creall(z[e]*conjl(z[e])); *S=cimagl(z[0]*conjl(z[1])); }
int main(int c,char**v){ s3=sqrtl(3.0L); int model=atoi(v[1]); R amp=strtold(v[2],0), r=strtold(v[3],0), psi=strtold(v[4],0); long long M=atoll(v[5]);
 C z[3]; z[0]=amp; z[1]=amp*r*cexpl(I*psi); z[2]=-z[0]-z[1];
 R N,S; obs(z,&N,&S); R s0=S/N; R pred=s0*(N*N-12*S*S)/(6*N);
 for(int k=0;k<6;k++) step(z,model); R N1,S1; obs(z,&N1,&S1);
 printf("model %c amp %.5Lf s0 %+.6Lf N0 %.3Le | ds %+.4Le pred %+.4Le resid %+.3Le\n",model?'B':'A',amp,s0,N,S1/N1-s0,pred,S1/N1-s0-pred);
 long long mark=10;
 for(long long m=2;m<=M;m++){ for(int k=0;k<6;k++) step(z,model); obs(z,&N1,&S1);
   if(N1>0.02L){ printf("   m %lld N %.3Le s %+.5Lf  (left small regime)\n",m,N1,S1/N1); break;}
   if(m==mark){ printf("   m %lld N %.3Le s %+.5Lf\n",m,N1,S1/N1); mark*=10; } }
 return 0;}
