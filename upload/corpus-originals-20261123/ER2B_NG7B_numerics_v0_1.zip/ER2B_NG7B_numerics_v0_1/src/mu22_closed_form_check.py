from sympy import *
import random
x,y,e=symbols('x y e',real=True)
R=Rational
def run(c):
    al,be,ga,de,ep,ze=c
    q=lambda r,h:(al*r*r+be*r*h+ga*h*h, de*r*r+ep*r*h+ze*h*h)
    T=lambda p:(p[0]-p[1]+q(*p)[0], p[0]+q(*p)[1])
    cur=(e*x,e*y)
    for n in range(6):
        cur=tuple(sum(expand(c_).coeff(e,d)*e**d for d in range(4)) for c_ in T(cur))
    g=[expand(c_).coeff(e,3) for c_ in cur]
    W=lambda p:p[0]-p[1]/2+I*sqrt(3)/2*p[1]
    mu=simplify(W(g).subs({x:1,y:0}))   # w=1
    wr,wi=symbols('wr wi',real=True); h=2*wi/sqrt(3); r=wr+h/2
    Q=expand(W(q(r,h))); u,v,t=symbols('u v t'); w=wr+I*wi; wb=wr-I*wi
    s=solve(Poly(expand(u*w*w+v*w*wb+t*wb*wb-Q),wr,wi).coeffs(),[u,v,t],dict=True)[0]
    u,v,t=s[u],s[v],s[t]
    f=(9+3*sqrt(3)*I)*u*v-(3+3*sqrt(3)*I)*abs(v)**2-6*abs(t)**2
    print(c, "quad0:",all(expand(c_).coeff(e,2)==0 for c_ in cur), "diff:",simplify(expand(mu-f)))
run((0,0,0,R(1,2),0,0))
random.seed(7)
for _ in range(3): run(tuple(R(random.randint(-5,5),random.randint(1,4)) for _ in range(6)))
