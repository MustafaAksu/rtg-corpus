#include <stdio.h>
#include <math.h>
#include <complex.h>
#include <stdlib.h>
int main(int c,char**v){ long double s=strtold(v[1],0); long long M=atoll(v[2]);
 long double amp=0.03L*s, s3=sqrtl(3.0L), tau=2*s3/3;
 long double r[3][2]={{amp,0.3L*amp},{-0.4L*amp,amp},{0,0}}; r[2][0]=-r[0][0]-r[1][0]; r[2][1]=-r[0][1]-r[1][1];
 long double complex w0[3]; for(int e=0;e<3;e++) w0[e]=(r[e][0]-r[e][1]/2)+I*(s3/2*r[e][1]);
 long long mark=M/1000; if(mark<1)mark=1;
 for(long long m=1;m<=M;m++){
   for(int e=0;e<3;e++){ long double x=r[e][0],y=r[e][1];
     for(int k=0;k<6;k++){ long double sn=sinl(y); long double a=x-sn, b=y+expm1l(x)-sn; x=a;y=b;}
     r[e][0]=x;r[e][1]=y;}
   if(m==mark){ long double complex h=0; long double N=0; printf("m %lld",m);
     for(int e=0;e<3;e++){ long double complex w=(r[e][0]-r[e][1]/2)+I*(s3/2*r[e][1]); h+=w; N+=creall(w*conjl(w));
       long double ph=cargl(w)+tau*logl((long double)m); ph=fmodl(ph,2*(4*atanl(1.0L))); if(ph<0)ph+=2*(4*atanl(1.0L)); printf(" phi%d %.6Lf",e,ph);}
     printf(" ratio %.6Lf N*m %.5Lf\n",cabsl(h)/sqrtl(N),N*m); mark*=10; }
 }
 for(int e=0;e<3;e++) printf("w0 %d %.18Le %.18Le\n",e,creall(w0[e]),cimagl(w0[e]));
 return 0;}
