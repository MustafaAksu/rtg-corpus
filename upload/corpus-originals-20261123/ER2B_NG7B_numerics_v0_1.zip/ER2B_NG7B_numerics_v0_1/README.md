# ER-2B / NG-7B numerical archive v0.1 (reviewer-side, noncanonical)

Date: 2026-10-13. Produced by the reviewing Claude session. These are exploratory numerical
checks, not certificates. No owner DSN is changed by this archive.

## Model equations
- Primitive DYAD map: T(rho,eta) = (rho - sin eta, eta + exp(rho) - 1 - sin eta).
- Eigenframe: w = rho - eta/2 + i*sqrt(3)/2*eta ; tau = 2*sqrt(3)/3 ; mu = -1/2 - i*tau.
- Block = six primitive steps. m always counts blocks unless a file says "n" (primitive steps).
- Model A (raw carrier): r_e -> T(r_e) - (1/3) sum_j T(r_j), closure sum r_e = 0 in (rho,eta).
- Model B (h2 chart): z -> H^{-1}(T(H(z))) per edge, then subtract the mean in z;
  H(z) = z + h2(z), h2 = -(1+i sqrt3)/12 z^2 - (1/3) z zbar + (1-i sqrt3)/24 zbar^2.
  H^{-1} by fixed-point iteration z <- w - h2(z). Only h2 is used; T~ is odd only through degree 4
  after an additional h4 (see odd_conjugacy script), which Model B here does NOT include.
- kappa family: r_e -> T(r_e) - (kappa/3) sum_j T(r_j).
- Observables: N = sum |w_e|^2, S = Omega_G = Im(w_1 conj w_2), s = S/N, h = sum w_e.

## Build
gcc 13.3.0, `gcc -O2 -o X X.c -lm`, x86-64 long double (80-bit) in all C programs.
Python 3 with sympy 1.14.0, mpmath 1.3.0. kappa_family.py / limit_three_shapes_float.py use IEEE double.

## Files (src -> raw)
| Source | Command(s) used | Raw output | What it tests |
|---|---|---|---|
| limit_three_edges.c | `./l s M` with (s,M) = (1,2e6),(0.5,8e6),(0.25,3.2e7),(0.125,1.28e8); initial edges (amp,0.3amp),(-0.4amp,amp), amp=0.03*s | raw/limit_scale_s{1,2,4,8}.txt | kappa=0 relative holonomy limit |h|/sqrt(N), per-edge phi_e = arg w + tau ln m, N*m |
| secular_source_block.py | `python3` (mpmath, 40 digits) | raw/secular_source_block.txt | one-block Delta h vs mu*sum w|w|^2, residual ratio ~16 |
| kappa_family.py | `python3` | raw/kappa_family.txt | kappa = 0, 0.5, 0.9 first look (double precision; large-N rows are outside any small-amplitude validity) |
| limit_three_shapes_float.py | `python3` (run once, output quoted in chat only) | not archived | three shapes, raw-coordinate prediction |
| shape_flow.c | `./s model amp r psi M`; z1=amp, z2=amp*r*exp(i psi) | raw/shape_oneblock.txt, shape_long_modelA.txt, shape_long_modelB_{1..4}.txt | delta s vs s(N^2-12S^2)/(6N); long-run s |
| shape_invariant_E.c | `./e 1 amp 0.6 psi 1` | raw/shape_invariant_E.txt | E = ln(J_B'/J_B), J_B = |s|^3 N/(1-12 s^2) |
| odd_conjugacy_deg4_float.py | `python3` | quoted in chat | h2, h4 remove even degrees through 4 (double precision, not exact) |
| G3_sixstep_jet.py, UV_table_check.py, mu22_closed_form_check.py, mu_dN_dS_check.py | `python3` (sympy, exact) | quoted in chat | earlier ER-2B checks: G3, (U,V) table at 4 q, mu22(q) at 4 q, mu, dN, dS |

Model B long runs: psi order in files 1..4 = 3.14159265358979 (r=0.4), 3.0416, 3.2416 (r=0.6), 2.1444 (r=1.0); 3e6 blocks requested,
runs were cut by a 280 s timeout, so the last printed row is m = 1e6.

## Known limitations
- Single initial shape family for most tests; no interval arithmetic; no error bars.
- Exact-rational version of the odd-conjugacy check was not completed (timed out).
- In limit_three_edges.c one of the three initial edges at scale 1 exceeds the DYAD tube seed bound Q <= 1/625.
- Scripts were written for one-off use; some print labels are terse.
