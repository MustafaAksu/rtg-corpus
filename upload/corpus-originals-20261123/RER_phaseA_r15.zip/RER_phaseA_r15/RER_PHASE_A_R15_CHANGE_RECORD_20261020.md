# RER Phase A r15: change record (two metadata operations)

**Date:** 20 Oct 2026.
**From:** Claude, RER co-owner (preparer). The preparer does not accept his own work.
**Status:** NONCANONICAL Phase A candidate, revision 15. Nothing is adopted, frozen or published.
**Answers:** the receiving decision of 20 Oct 2026 on the G9 W3 quotation packet, which authorized r15 with exactly two operations:
1. SYNC-DYAD-OPEN20-BINF → `CLOSED — SOURCE_SYNCHRONIZED`, linked to the Phase A r14 receiving decision;
2. RRF083 → `BYTE_VERIFIED_HERE`, with the real v0.8.3 file, SHA-256 and custody.

## 1. Base

- **Source Markdown:** unchanged, RER r4.9 (`9c0f43fc…cc84`).
- **Base package:** Phase A r14 (`c523d351…5644`, accepted), extracted fresh.
- **Patch:** `patch_r15.py`.
- **r14 history:** the five r14 outputs and the r14 checker output are kept byte-unchanged under `inputs/phaseA_r14_outputs/` and pinned.

## 2. Operation 1: receiving disposition of SYNC-DYAD-OPEN20-BINF

- **Decision file:** the r14 receiving review is pinned as `inputs/receiving_review_phaseA_r14_20261020.md` (`3c6d99c4…a7a9`, equal to the file the receiver sent).
- **Catalog entry:** the warning gets a `receiving_disposition`:
  - status `CLOSED — SOURCE_SYNCHRONIZED`;
  - the decision, file and hash;
  - scope: "source synchronization … only; not an independent proof of DYAD-THM-SMOOTH-EMBEDDING, not an RER adoption, and not a status set by the Phase A builder; B-an and B-6 stay OPEN".
- **Machine status unchanged:** the computed `status` stays the r14 value `CHECK — record corrected …`, as the receiver required.
- **Builder rule:** the builder carries the disposition only while the computed status is `CHECK — record corrected`. If a listed line became live again, it would drop the disposition and record `receiving_disposition_rejected`.
- **Rendered output:** the matrix Markdown shows the disposition next to the computed status and states that the computed status is not overwritten.

## 3. Operation 2: RRF v0.8.3 bytes

- **File:** `sources_available/RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md`, `b393657e…a187` (PI upload; equals the adoption-record hash; receiver confirmed).
- **Custody:** `inputs/source_custody_r15.json`.
- **Row RER-DYAD-FORMAL-INVOLUTION / RRF083 (n = 2):** bytes PRINTED_ONLY → BYTE_VERIFIED_MATCH; authentication RECEIVER_BYTE_VERIFIED → BYTE_VERIFIED_HERE; inspection extent → FULL_FILE_HASH; status OWNER_REPORTED → VERIFIED (mechanical: CURRENT plus matched bytes). Its reason and receiver note gain one sentence each. The currency (CURRENT) and the pin are unchanged.
- **Not changed:** the RRF owner-level entry keeps `HASH_VERIFIED_BY_RECEIVER`. Raising it would change the owner-evidence field of every RRF row, which was not authorized.
- **Byte gap:** RRF083 leaves the byte-availability gap list. RRF08_ADOPTED and RRF082 stay in it; the RRF v0.8 bytes are still not held.

## 4. Result

| Measure | r14 | r15 |
|---|---|---|
| VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED | 31 / 4 / 50 / 6 | 32 / 3 / 50 / 6 |
| BYTE_VERIFIED_HERE / RECEIVER / PRINTED / NONE | 59 / 7 / 24 / 1 | 60 / 6 / 24 / 1 |

- **Matrix:** 91 rows; exactly one row (RRF083) differs from r14.
- **Registry:** equal to r14 except schema.
- **Blocked register:** equal except schema and the RRF083 byte-gap key.
- **Unchanged:** owner_current, the warning's other fields and its computed status, RER-G9/0, G9/1 and G9/3 (`PENDING_PER_REFERENCE_AUDIT`).

## 5. Gates: 29/29 PASS; controls 99/99 fail as required

| Gate | r15 requirement |
|---|---|
| A27 (extended) | as in r14, plus: disposition `CLOSED — SOURCE_SYNCHRONIZED`; decision hash = recomputed hash of the pinned review file; scope states "not an independent proof" and "B-an and B-6 stay OPEN"; no rejection flag; computed status still CHECK |
| A28 (re-based on r14) | only the RRF083 row (in its byte-evidence fields), the RRF083 byte-gap key and the disposition differ; registry, owners, other rows, warning status and every RER-G9 audit unchanged |
| A29 (new) | RRF083 BYTE_VERIFIED_HERE / VERIFIED only with the real file and custody r15; RRF owner-level evidence stays HASH_VERIFIED_BY_RECEIVER |

The r14 A28 (r13 matrix equality) is retired. Its result stays in the pinned r14 checker record.

**Controls: 17 new output controls.**
- A27 (6): disposition removed; computed status overwritten with CLOSED; disposition carried while the status is OPEN; decision hash altered; scope claims proof certification; rejection flag present.
- A28 (8): r14 rows re-used; another row edited; RRF083 currency changed; G9/1 audit marked done; RRF owner evidence raised; another byte-gap key removed; a registry record changed; the warning text changed.
- A29 (3): RRF083 left RECEIVER_BYTE_VERIFIED; status left OWNER_REPORTED; pin hash altered.

**Other new controls:**
- file control: RRF v0.8.3 file withheld;
- input controls: custody r15 hash altered; review file altered.

**Total:** 79 controls carried + 17 + 1 + 2 = 99.

**Clean extraction.** Re-extracted into an empty directory and run with `python -I`: output byte-identical to the stored checker output.

## 6. Not changed, and open

- RER r4.9 text, grades, pins and OPEN boundaries.
- **W3:** no interface decision is recorded here. G9/1 is in `SCOPE_CLARIFICATION_PENDING` per the receiver's audit note, which is not a machine field in this pass. G9/3 still lacks the RRF v0.8 bytes. The RRF editor's RF-1 answer is needed.
- G2 §5b and the two ER-2B blocks are open. The author-conflicted Phase B reviews are with the receiver.
