"""Phase A r14 -> r15: two metadata operations authorized by the receiving decision of 20 Oct 2026 (W3 packet review). Source unchanged (RER r4.9).
(1) SYNC-DYAD-OPEN20-BINF: receiving disposition CLOSED — SOURCE_SYNCHRONIZED, linked to the Phase A r14 receiving review
    (RECEIVING_REVIEW_20261020__3_.md, 3c6d99c4...a7a9, pinned under inputs/). The machine-computed status stays the r14 CHECK value; the
    builder carries the disposition only while no listed line is live and every replacement line is live (otherwise it is rejected).
(2) RRF083: RRF v0.8.3 bytes added (sources_available/RRF083__..., custody inputs/source_custody_r15.json); the RRF083 row becomes
    BYTE_VERIFIED_MATCH / BYTE_VERIFIED_HERE / VERIFIED. The RRF owner_current entry (HASH_VERIFIED_BY_RECEIVER) is not changed.
Nothing else changes: rows, records, pins, OPEN states, G9/1 and G9/3 PENDING_PER_REFERENCE_AUDIT. r14 outputs kept under inputs/phaseA_r14_outputs/.
Gates: A27 extended (disposition); A28 re-based on the r14 outputs; new A29 (RRF083 custody). Args: TARGET_DIR RRF083_FILE REVIEW_R14_FILE."""
import sys, os, json, shutil, hashlib
D, F83, REV = sys.argv[1:4]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'; HREV = '3c6d99c434a04839acf27ebfca845ae08e9482b3ae7bbfed16cc3c80a94ea7a9'
b83 = open(F83, 'rb').read(); assert sha(b83) == H83
brev = open(REV, 'rb').read(); assert sha(brev) == HREV
FN = 'RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md'; RV = 'inputs/receiving_review_phaseA_r14_20261020.md'

H = os.path.join(D, 'inputs/phaseA_r14_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r14.txt'))
open(os.path.join(D, 'sources_available', FN), 'wb').write(b83)
open(os.path.join(D, RV), 'wb').write(brev)
open(os.path.join(D, 'inputs/source_custody_r15.json'), 'w').write(dump({
    '_about': 'Phase A r15 custody for the RRF v0.8.3 owner file.',
    'container_chain_status': 'PREPARER_DECLARED: the file hash was computed here and equals the adoption-record hash; the receiver independently confirmed the same hash on 20 Oct 2026 (W3 quotation packet review). The upload path is the preparer\'s declaration.',
    'files': {FN: {'key': 'RRF083', 'version': '0.8.3', 'sha256': H83,
                   'container': 'PI upload to the preparer session, 20 Oct 2026 (RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md, 97717 bytes, 563 lines); hash equals the adoption record claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3_ADOPTION_RECORD.md; also carried in RER_G9_W3_QUOTE_PACKET_r1.zip (74d3a8ca…79ba)'}}}))

p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p)); KV['_catalog_checked'] = '2026-10-20 (Phase A r15, preparer)'; open(p, 'w').write(dump(KV))
p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
k = CS['keys']['RRF083']; assert k['rule'] == 'CURRENT'
k['reason'] += ' Phase A r15: the v0.8.3 bytes are also held and hashed here (inputs/source_custody_r15.json); the RRF owner-level evidence entry is unchanged.'
k['receiver_note'] += ' (r4.7-era statement; since Phase A r15 the preparer also holds the bytes.)'
w = CS['scientific_sync_warnings'][0]; assert w['id'] == 'SYNC-DYAD-OPEN20-BINF' and 'receiving_disposition' not in w
w['receiving_disposition'] = {'status': 'CLOSED — SOURCE_SYNCHRONIZED',
    'decision': 'Phase A r14 independent receiving review, 20 Oct 2026 (ACCEPT SCOPED; warning suitable to close as source-synchronization completed)',
    'decision_file': RV, 'decision_sha256': HREV,
    'scope': 'source synchronization of RER-DYAD-FORMAL-INVOLUTION with Dyadic v6.4.18 only; not an independent proof of DYAD-THM-SMOOTH-EMBEDDING, not an RER adoption, and not a status set by the Phase A builder; B-an and B-6 stay OPEN',
    'recorded_in': 'Phase A r15 (catalog revision)'}
CS['_about'] += ' Phase A r15 (20 Oct): SYNC-DYAD-OPEN20-BINF receiving disposition CLOSED — SOURCE_SYNCHRONIZED (r14 receiving review, 3c6d99c4…a7a9); RRF v0.8.3 bytes added (inputs/source_custody_r15.json).'
open(p, 'w').write(dump(CS))

rp('build_phaseA.py', [
 ('"""RER Phase A r14 builder (deterministic;', '"""RER Phase A r15 builder (deterministic; r15 adds a receiving disposition to SYNC-DYAD-OPEN20-BINF and the RRF v0.8.3 bytes;'),
 ("'RER-REGISTRY-PHASEA/14'", "'RER-REGISTRY-PHASEA/15'"), ("'RER-SOURCE-CURRENCY/14'", "'RER-SOURCE-CURRENCY/15'"), ("'RER-BLOCKED-SOURCES/14'", "'RER-BLOCKED-SOURCES/15'"),
 ("'# RER r4.9 — source-currency matrix (Phase A r14, noncanonical)'", "'# RER r4.9 — source-currency matrix (Phase A r15, noncanonical)'"),
 ("'# RER r4.9 — blocked-source register (Phase A r14, noncanonical)'", "'# RER r4.9 — blocked-source register (Phase A r15, noncanonical)'"),
 ("        for w in CS.get('scientific_sync_warnings', [])]\n",
  "        for w in CS.get('scientific_sync_warnings', [])]\n"
  "    for w in cm['scientific_sync_warnings']:  # r15: a receiving disposition is carried only on a corrected record; the computed status is never overwritten\n"
  "        if 'receiving_disposition' in w and not w['status'].startswith('CHECK — record corrected'):\n"
  "            w['receiving_disposition_rejected'] = 'disposition present but the computed status is not CHECK — record corrected'; w.pop('receiving_disposition')\n"),
 ("Closes only when: {w['closes_only_when']}\" for w in cm.get('scientific_sync_warnings', [])]",
  "Closes only when: {w['closes_only_when']}\" + (f\" **Receiving disposition:** {w['receiving_disposition']['status']} ({w['receiving_disposition']['decision']}; `{w['receiving_disposition']['decision_sha256'][:8]}…`; scope: {w['receiving_disposition']['scope']}). The computed status above is the machine record and is not overwritten.\" if w.get('receiving_disposition') else '') for w in cm.get('scientific_sync_warnings', [])]"),
 ("The r12 OWNER_REPORTED Dyadic line above is kept as history.']}",
  "The r12 OWNER_REPORTED Dyadic line above is kept as history.',\n"
  "                          'Phase A r15 (20 Oct 2026): SYNC-DYAD-OPEN20-BINF receiving disposition CLOSED — SOURCE_SYNCHRONIZED (Phase A r14 receiving review 3c6d99c4…a7a9; source synchronization only, no independent proof certification); the machine-computed status stays CHECK. RRF v0.8.3 bytes held and hashed here (b393657e…a187), hash receiver-confirmed; row RRF083 BYTE_VERIFIED_HERE. RER-G9 rows G9/1 (W3 scope clarification) and G9/3 (RRF v0.8 bytes) stay PENDING_PER_REFERENCE_AUDIT; the W3 interface question waits for the RRF editor (RF-1).']}"),
])

C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    assert t.count(a) == 1; i = t.index(a); j = t.index(b, i); return t[:i] + new + t[j:]
t = t.replace("            and w.get('rer_correction', '').startswith('RER r4.9 (9c0f43fc')\n",
  "            and w.get('rer_correction', '').startswith('RER r4.9 (9c0f43fc')\n"
  "            and (w.get('receiving_disposition') or {}).get('status') == 'CLOSED — SOURCE_SYNCHRONIZED' and 'receiving_disposition_rejected' not in w\n"
  "            and w['receiving_disposition'].get('decision_sha256') == '3c6d99c434a04839acf27ebfca845ae08e9482b3ae7bbfed16cc3c80a94ea7a9' == sha(ri(w['receiving_disposition'].get('decision_file', 'inputs/none')))\n"
  "            and 'not an independent proof' in w['receiving_disposition'].get('scope', '') and 'B-an and B-6 stay OPEN' in w['receiving_disposition']['scope']\n", 1)
assert "receiving_disposition_rejected' not in w" in t
NEW_A28_29 = r'''    H14 = 'inputs/phaseA_r14_outputs/'
    m14 = json.loads(B.rd(H14 + 'SOURCE_CURRENCY_MATRIX.json')); g14 = json.loads(B.rd(H14 + 'RER_REGISTRY_v0_2_r4_9_PHASEA.json')); b14 = json.loads(B.rd(H14 + 'BLOCKED_SOURCE_REGISTER.json'))
    RF = {'bytes_status', 'available_file', 'inspection_extent', 'authentication', 'status', 'currency_reason', 'receiver_note'}
    dk = [(y['key'], sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k))) for x, y in zip(cm['rows'], m14['rows'])]
    rows14_ok = (len(cm['rows']) == len(m14['rows']) == 91 and [(x['record'], x['row_kind'], x['n'], x['key']) for x in cm['rows']] == [(y['record'], y['row_kind'], y['n'], y['key']) for y in m14['rows']]
                 and all((not d) if k != 'RRF083' else (bool(d) and set(d) <= RF) for k, d in dk) and sum(1 for k, d in dk if d) == 1)
    strip = lambda o: {k: v for k, v in o.items() if k != 'schema'}
    gap = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'byte_availability_gap')}
    w14 = m14['scientific_sync_warnings'][0]; w15 = (cm.get('scientific_sync_warnings') or [{}])[0]
    rest14_ok = (strip(reg) == strip(g14) and gap(br) == gap(b14) and br['byte_availability_gap']['note'] == b14['byte_availability_gap']['note']
                 and br['byte_availability_gap']['keys'] == [k for k in b14['byte_availability_gap']['keys'] if k != 'RRF083'] and 'RRF083' in b14['byte_availability_gap']['keys']
                 and cm['bytes_not_available_to_preparer'] == [k for k in m14['bytes_not_available_to_preparer'] if k != 'RRF083']
                 and oc == m14['owner_current'] and {k: v for k, v in w15.items() if k != 'receiving_disposition'} == w14 and w15.get('status') == w14.get('status')
                 and cm['watch_items'][:-1] == m14['watch_items'] and cm['watch_items'][-1].startswith('Phase A r15 (20 Oct 2026): SYNC-DYAD-OPEN20-BINF receiving disposition')
                 and {k: v for k, v in meta.items() if k != 'checked'} == {k: v for k, v in m14['owner_catalog'].items() if k != 'checked'}
                 and m14['schema'] == 'RER-SOURCE-CURRENCY/14' and cm['schema'] == 'RER-SOURCE-CURRENCY/15'
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    g('A28 r14 equality: only the RRF083 row (byte evidence), the RRF083 byte-gap entry and the warning disposition differ; registry, other rows, owners, warning status and G9 audits unchanged', rows14_ok and rest14_ok, f'{sum(1 for k, d in dk if d)} row(s) differ: {[(k, d) for k, d in dk if d][:1]}')
    H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'; FN83 = 'RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md'; P83 = os.path.join(HERE, 'sources_available', FN83)
    f83_ok = FN83 not in withhold and os.path.isfile(P83) and sha(open(P83, 'rb').read()) == H83
    C15 = json.loads(ri('inputs/source_custody_r15.json')); f15 = C15.get('files', {}).get(FN83, {})
    rr83 = [x for x in cm['rows'] if x['key'] == 'RRF083']; orr = oc.get('RRF', {})
    a29 = (f83_ok and f15.get('key') == 'RRF083' and f15.get('sha256') == H83 and bool(f15.get('container')) and C15.get('container_chain_status', '').startswith('PREPARER_DECLARED')
           and len(rr83) == 1 and all(x['cited_sha256'] == H83 and x['cited_version'] == '0.8.3' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'
                                      and x['available_file'] == 'sources_available/' + FN83 and x['currency'] == 'CURRENT' and x['status'] == 'VERIFIED' and x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' for x in rr83)
           and orr.get('version') == '0.8.3' and orr.get('sha256') == H83 and orr.get('evidence') == 'HASH_VERIFIED_BY_RECEIVER')
    g('A29 RRF083 byte-verified here (file, custody r15); RRF owner-level evidence unchanged', a29, f'{len(rr83)} RRF083 row(s)')
'''
t = cut(t, "    k13 = lambda x: (x['record'], x['row_kind'], x['n'], x['key'])\n", "    return all(res), res\n\nouts =", NEW_A28_29)
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
assert block[0].startswith("    T = [('") and all(l.startswith("         ('") for l in block[1:])
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]
ents[-1] = ents[-1][:-1]
keep = [e.rstrip(',') for e in ents if not e.startswith("('A28 ")]
NEWC = r'''('A27 disposition removed', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition')))
('A27 computed status overwritten with CLOSED', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='CLOSED — SOURCE_SYNCHRONIZED')))
('A27 disposition carried while the record line is live (status OPEN)', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='OPEN — record correction required', rer_lines_present=[True, True])))
('A27 disposition decision hash altered', 26, mut(C, lambda d: d['scientific_sync_warnings'][0]['receiving_disposition'].update(decision_sha256='0' * 64)))
('A27 disposition scope claims proof certification', 26, mut(C, lambda d: d['scientific_sync_warnings'][0]['receiving_disposition'].update(scope='independent proof certified; B-an and B-6 stay OPEN')))
('A27 disposition rejected flag present', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(receiving_disposition_rejected='x')))
('A28 r14 matrix rows re-used', 27, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r14_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows'])))
('A28 another row changed (OFN reason)', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(currency_reason='edited')))
('A28 RRF083 row currency changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='UNCHANGED_VERIFIED')))
('A28 G9/1 audit marked done', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 1).update(gap_reference_review='SCOPE_CLARIFIED')))
('A28 RRF owner evidence raised to BYTE_VERIFIED', 27, mut(C, lambda d: d['owner_current']['RRF'].update(evidence='BYTE_VERIFIED')))
('A28 another byte-gap key removed', 27, mut(K, lambda d: d['byte_availability_gap']['keys'].remove('RRF082')))
('A28 registry record changed', 27, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C02').update(title='x')))
('A28 warning text field changed', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].update(required_action='none')))
('A29 RRF083 row left RECEIVER_BYTE_VERIFIED', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(authentication='RECEIVER_BYTE_VERIFIED')))
('A29 RRF083 row status left OWNER_REPORTED', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(status='OWNER_REPORTED')))
('A29 RRF083 pin hash altered', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(cited_sha256='0' * 64)))'''.split('\n')
newblock = '    T = [' + (',\n         ').join(keep + NEWC) + ']'
t = t[:i] + newblock + t[j:]
t = t.replace("    sc = B.rd('inputs/recog_v0_3_21_section_check/compare_output.txt'); cu = B.rd('inputs/source_custody_r13.json')\n",
  "    _, rr = gates(outs, verbose=False, withhold=('RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md',)); good = not rr[28]; allf &= good\n"
  "    print(f'  file control A29 RRF v0.8.3 file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    c15 = B.rd('inputs/source_custody_r15.json'); rv = B.rd('inputs/receiving_review_phaseA_r14_20261020.md')\n"
  "    for n, p, bb, gi in [('A29 custody r15 hash altered', 'inputs/source_custody_r15.json', c15.replace(b'b393657e75e78ce4', b'0000000000000000', 1), 28),\n"
  "                         ('A27 receiving-review file altered', 'inputs/receiving_review_phaseA_r14_20261020.md', rv + b'x', 26)]:\n"
  "        _, rr = gates(outs, verbose=False, inp={p: bb}); good = not rr[gi]; allf &= good\n"
  "        print(f'  input control {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    sc = B.rd('inputs/recog_v0_3_21_section_check/compare_output.txt'); cu = B.rd('inputs/source_custody_r13.json')\n", 1)
assert t.count("file control A29 RRF v0.8.3") == 1
a = '"""Phase A r14 gates on RER v0.2 DRAFT r4.9'
assert t.count(a) == 1
t = t.replace(a, '"""Phase A r15 gates on RER v0.2 DRAFT r4.9 (r15: SYNC-DYAD-OPEN20-BINF receiving disposition; RRF v0.8.3 bytes).\n'
  'r15: A27 also requires the receiving disposition CLOSED — SOURCE_SYNCHRONIZED linked to the pinned r14 receiving review (hash recomputed), its\n'
  'scope boundary, and the unchanged computed CHECK status. A28 now compares with the pinned r14 outputs (only the RRF083 row byte evidence, the RRF083\n'
  'byte-gap entry and the disposition may differ; G9 audits stay pending). A29 RRF083 BYTE_VERIFIED_HERE only with the real file and custody r15;\n'
  'the RRF owner-level evidence stays HASH_VERIFIED_BY_RECEIVER. The r14 A28 (r13 matrix equality) is retired; its result stays in the pinned r14 checker record.\n'
  'Earlier wording, kept as history: Phase A r14 gates on RER v0.2 DRAFT r4.9', 1)
open(C, 'w', encoding='utf-8').write(t)

p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/source_custody_r15.json', RV] + ['inputs/phaseA_r14_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched')
