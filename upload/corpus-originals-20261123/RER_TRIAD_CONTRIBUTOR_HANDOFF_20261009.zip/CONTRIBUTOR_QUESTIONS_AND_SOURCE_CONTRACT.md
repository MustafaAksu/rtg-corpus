# Contributor handoff — Genesis conditional modal C01–C09 and F3

**9 October 2026 · Source-read, noncanonical · No owner DSN, RER main register or physical model amended.**

## 1. Registry identity, source files and replay order

RER means **Relational Emergence Registry** (not a separate adopted scientific owner). `RER/REGISTRY.json` contains 16 initial records and `RER/REGISTRY.schema.json` describes the contract. Required fields: **carrier, observables, constraints, transformation law, closure status, memory**; further provenance/clock/domain/grade information is explicit. C01–C09 are conditional proposed linked records, not new adopted Genesis results and not official RIDs. Physical target remains `NO_TARGET_VECTOR_LAW_SELECTED`.

Unmodified source archives are under `ORIGINAL_PACKAGES/`, while complete replay-ready working copies are in `C08/`, `C09/`, `JET_PRODUCER/`. `RUN_CHECKS.py` verifies source SHA, independently regenerates the 4th-degree jet from the declared primitive formula, reruns C08/C09, and optionally exercises the expected negative controls (`python RUN_CHECKS.py --negatives`).

**Order:** read `SOURCE/GENESIS_TO_RER_TRIAD_CLOSURE.md` → reproduce `JET_PRODUCER/scripts/make_jet.py` → run C08 `check_f3_reachable.py` → run C09 `check_interage_geometry.py` → assess different-age factor maps. Original C08 script requires `C08/source/jet_coefficients.json`; it was absent from the standalone folder but present in its ZIP. In this package it is supplied.

## 2. Exact model contract: E, P, T_e and the clock

Let each edge take values in the **same coordinate chart** `(rho,eta)` and set `X=(s_rho,s_eta,c_rho,c_eta)` in `V²`, `V=R²`. The edge embedding is

\[
E=\begin{pmatrix}1&0\\-1/2&1\\-1/2&-1\end{pmatrix},
\quad P=(E^TE)^{-1}E^T=\begin{pmatrix}2/3&-1/3&-1/3\\0&1/2&-1/2\end{pmatrix}.
\]

The primitive edge map is

\[
T_e(\rho,\eta)=(\rho-\sin\eta,\ \eta+e^\rho-1-\sin\eta).
\]

Each modal step is `N=(P⊗I₂)∘T_e^{×3}∘(E⊗I₂)`; **reprojection occurs after each primitive edge step**. The retained return is `F=N^6`, and `F^n=N^{6n}` with the same schedule. The projection is the **Euclidean least-squares pseudoinverse in the three incidence/edge labels**. Because one identical positive definite `B` is applied to each edge carrier, the same `P⊗I₂` is also obtained by minimizing the sum of their common `B`-quadratic errors; this does **not** establish a chosen physical projection/gauge policy. It is NOT a B-orthogonal projection selecting physical triadic outcomes from the unprojected microdynamics.

The model is a **noncanonical conditional analytic standalone modal construction**, traced to a Genesis parity study and defined in the Genesis→RER source handoff. It is not a theorem incorporated in adopted Genesis v2.8.5, not the primitive K4 shadow, not `M_root`, and not the historical T-6 lifted graph-force producer. No historical parity execution-byte identity is newly certified by these files.

## 3. Are the Genesis and conditional modal cubic results the same?

**Mathematically one relevant radial polynomial matches. This is NOT proof that the full generators or their physical mechanisms are identical.** From the conditional modal `G₃`, with `Ω_G=(√3/2)ω_raw` and `ω_raw=s_eta c_rho - s_rho c_eta`, the quartic `Q_c` increment is

\[
P_{Qc}^{(4)}=\frac13Q_c^2+\frac14I^2+\frac{I\Omega_G}{\sqrt3}+\frac34\Omega_G^2.
\]

Adopted Genesis OPEN 1C / `GEN-THM-DELTA-QC` gives

\[
\frac13Q_c^2+\frac14(I+\omega_{raw})^2+\frac5{16}\omega_{raw}^2,
\]

which is **identically the same polynomial** under `ω_raw=2 Ω_G/√3`. At `I=0` and the primitive Gram identity `Ω_G²=Q_s Q_c`, this reduces to `Q_c²/3+3 Q_s Q_c/4`, exactly the GSPLIT expression. These identities compare the specified scalar channels and conventions; they do not identify the full vector jet, projection schedule, K4 producer, raw Dyadic return, or physical birth process. Never transfer κ, μ₆ or B_T coefficients by name alone.

## 4. Meaning of C05/C06 conditional [THM] claims

- **C05**: `det D H₃(t(1,0,0,1))=(12645889/11943936)t^17+O(t^18)` for analytic `F`, with target `Q_s` and four delayed observations `H₃=(Q_s,Q_s∘F,Q_s∘F²,Q_s∘F³)`. Since the coefficient is nonzero, for each sufficiently small **positive** `t` the rank is four on some ambient open neighborhood of that point. This prohibits a `C¹` observable-preserving factor of dimension <4 on a neighborhood containing that point and its required forward orbit. It is **not a uniform lower bound over every point of a punctured ball**, not valid at zero, and does not supply an explicit radius. The analytic `O(t^18)` remainder establishes existence of a sufficiently small interval by the definition of little/asymptotic control; no numerical enclosure is supplied.
- **C06**: on exact invariant `M₀={c=0}`, `det D(Q_s,Q_s∘F_s)(t,0)=−t^5/64+O(t^6)`; rank two for small positive `t`. Therefore **no `C¹` factor below the full two-dimensional stratum** can preserve all future `Q_s` near the witness. The identity representation gives the upper bound two. This does not establish a reduction of a physical post-birth stratum.
- Both results are **conditional analytic-model theorems**, not promoted owner claims; `d_min=n` is shorthand for the stronger and more precise *no locally smaller smooth factor for the stated target and domain*.

## 5. F3 cross-age factor: which regularity?

The **reachable** problem is the scientific question: for fixed nonzero κ under the one-time birth hypothesis A, define `Bκ(s)=(s, κQ(s)J_Qs)` and `M_{κ,n}=F^n Bκ(U_n)`; on `Rκ=⋃_{n≥0}M_{κ,n}`, seek one autonomous factor `π` satisfying `O=Otilde∘π` and `π∘F=Ftilde∘π` on every admitted state and successor. Compare two distinct ages whenever `π(X)=π(X')`. The exact admissible domains and any terminal/age criteria must be provided.

A `C¹` **ambient extension** is a useful *stronger test class* and would be obstructed on a full ambient open domain by C05, but that ambient theorem does not automatically forbid an extension that only intertwines on `Rκ`. A `C¹` structure specified **sheet by sheet**, with explicit overlap/accumulation compatibility, is a different class. A bare set-theoretic factor is insufficient to establish an effective smooth state. The countable union need not be one manifold. Different fixed ages have local 2D sheets; this alone does not produce one common 2D factor. Neither an age label nor memory is selected.

## 6. New contributor observation: B-orthogonality and an age fingerprint

On the *exact trial graph* `Cκ(s)=κ Q(s)J_Qs`, `sᵀB Cκ(s)=0` **exactly**, not just to leading order. For fixed finite n, C09 gives

\[
c_n(s)=C_κ(s)-n\frac{\sqrt3κ}{6}Q(s)^2s+O_n(\lVert s\rVert^6)
\]

in **current-parent** chart; therefore

\[
I_{sc,n}(s)=-n\frac{\sqrt3κ}{6}Q(s)^3+O_n(\lVert s\rVert^7),\quad
\Omega_{G,n}(s)=-κ Q(s)^2+O_n(\lVert s\rVert^7).
\]

For fixed finite `n`, fixed `κ≠0`, nonzero sufficiently small `s`, an asymptotic **present-state age fingerprint** is

\[
\frac{2\sqrt3\,I_{sc}}{\Omega_G Q_s}=n+O_n(\lVert s\rVert).
\]

This is derived from C09’s jet; it is **not** an exact integer readout, globally uniform over `n`, proof of minimal factor, compulsory physical memory, or RECOG recognition/identifiability. Since `I` is already a signed-Gram observable, this candidate need not add a separate information carrier. To promote anything into RECOG, test attachment/role identity, observational robustness and distinguishability from a common driver; no recognized physical event is presently supplied.

## 7. Priority and check boundaries

1. **(a) Reproduce C09** using the producer formula and frozen jet; independently check at least the `n−m` graph difference and scalar contraction, not only rerun the author script.
2. **(b) Design F3** with a declared observable and explicit smoothness/compatibility contract on the reachable union, not automatically on an ambient neighborhood.
3. **(c) RECOG** after establishing an admitted physical/observational interpretation. Future-equivalence is a mathematical relation, not yet a recognition mechanism.

No new stream, physical model selection or RER canonical update is authorized by this handoff. Original project owner files remain unchanged.
