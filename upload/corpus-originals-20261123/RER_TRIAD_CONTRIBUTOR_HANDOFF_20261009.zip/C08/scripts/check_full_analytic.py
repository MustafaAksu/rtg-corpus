import mpmath as m
m.mp.dps=95
R=m.mpf
J=m.matrix([[1,-2],[2,-1]])/m.sqrt(3)
def te(s):
 r,e=s; return m.matrix([r-m.sin(e),e+m.exp(r)-1-m.sin(e)])
def N(s,c):
 a,b,d=te(s),te(-s/2+c),te(-s/2-c)
 return R(2)/3*a-(b+d)/3, (b-d)/2
def F(s,c):
 for _ in range(6):s,c=N(s,c)
 return s,c
def Q(s):return s[0]**2-s[0]*s[1]+s[1]**2
def C(s,k):return k*Q(s)*J*s
for k in [-R(1)/2,-2*m.sqrt(3)/3]:
 print('KAPPA',m.nstr(k,15))
 for tv in ['0.04','0.02','0.01']:
  t=R(tv); s=m.matrix([t,0]); z=m.matrix([-t,0]);
  p=F(s,C(s,k))[0]; pm=F(z,C(z,k))[0]
  signedgram_diff=(Q(p)-Q(pm))/t**5
  def fun(r,e):
   sn=m.matrix([r,e]); parent,_=F(sn,C(sn,k));return parent[0]-t,parent[1]
  ur,ue=m.findroot(fun,(t,0),solver='mdnewton',tol=R('1e-75'))
  w=m.matrix([ur,ue]); parent1,child1=F(w,C(w,k)); parent0=s
  next0,_=F(parent0,C(parent0,k));next1,_=F(parent1,child1)
  print('t',tv, 'gram/t5',m.nstr(signedgram_diff,15),'parent/t9', [m.nstr((next1[i]-next0[i])/t**9,18) for i in range(2)])
 print('expected',m.nstr(5/R(32),17), [m.nstr(-k**2/R(18),17),m.nstr(k**2/R(9),17)])
