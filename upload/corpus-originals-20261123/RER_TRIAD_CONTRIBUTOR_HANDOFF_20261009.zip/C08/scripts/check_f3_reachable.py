#!/usr/bin/env python3
"""Exact source-jet checks for conditional Genesis one-time-birth A model.
Not a physical K3 certification. The negative control is expected to exit 1.
"""
import argparse, json, hashlib
from pathlib import Path
import sympy as S
ap=argparse.ArgumentParser();ap.add_argument('--negative-parent-closure',action='store_true'); args=ap.parse_args()
source=Path(__file__).resolve().parents[1]/'source'/'jet_coefficients.json'
d=json.loads(source.read_text())
r,e,c,h,k,t=S.symbols('r e c h k t', real=True)
X=(r,e,c,h)
def poly(d):return S.expand(sum(S.Rational(v)*S.prod(x**int(n) for x,n in zip(X,key.split(','))) for key,v in d.items()))
G3=S.Matrix([poly(z) for z in d['G3']]); G4=S.Matrix([poly(z) for z in d['G4']])
s=S.Matrix([r,e]); Q=r*r-r*e+e*e; J=S.Matrix([[1,-2],[2,-1]])/S.sqrt(3)
C=k*Q*J*s; R=-S.sqrt(3)*k*S.Rational(1,6)*Q**2*s
G3s=S.Matrix(G3[:2,:]); G4s=S.Matrix(G4[:2,:])
g3q=S.expand((2*r-e)*G3s[0]+(2*e-r)*G3s[1]).subs({c:0,h:0})
g4q=S.expand((2*r-e)*G4s[0]+(2*e-r)*G4s[1]).subs({c:0,h:0})
source_defect=G3[2:,:].subs({c:C[0],h:C[1]})-C.jacobian(s)*G3s.subs({c:0,h:0})
def homog(expr,degree):return S.expand(sum(v*r**ab[0]*e**ab[1] for ab,v in S.Poly(S.expand(expr),r,e).terms() if sum(ab)==degree))
source_defect5=S.Matrix([homog(v,5) for v in source_defect])
Dnext=S.simplify(G3s.jacobian(S.Matrix([c,h])).subs({c:C[0],h:C[1]})*R)
expected_next=S.Matrix([-k*k*(2*e+r)*Q**4/18,k*k*(2*r-3*e)*Q**4/18])
expected_q5=Q*(5*r**3-8*e*r**2-9*e**2*r-5*e**3)/64
checks={
'P01 source jet 4 coordinates':len(G3)==4 and len(G4)==4,
'P02 cubic parent even in child':all(S.expand(v.subs({c:-c,h:-h})-v)==0 for v in G3s),
'P03 quartic parent even in child':all(S.expand(v.subs({c:-c,h:-h})-v)==0 for v in G4s),
'P04 leading parent amplitude fourth-degree radial':S.expand(g3q-Q**2/4)==0,
'P05 parent quintic on child-free':S.expand(g4q-expected_q5)==0,
'P06 same signed Gram for opposite birth states':all(S.expand(v.subs({r:-r,e:-e})-v)==0 for v in (Q,S.expand(C.T*S.Matrix([[1,-S.Rational(1,2)],[-S.Rational(1,2),1]])*C)[0])),
'P06b all signed-Gram initial components match under global sign':all(S.expand(v.subs({r:-r,e:-e})-v)==0 for v in (Q, S.expand(C.T*S.Matrix([[1,-S.Rational(1,2)],[-S.Rational(1,2),1]])*C)[0], S.expand((s.T*S.Matrix([[1,-S.Rational(1,2)],[-S.Rational(1,2),1]])*C)[0]), S.expand(S.sqrt(3)/2*(e*C[0]-r*C[1])))),
'P07 opposite birth parent difference coefficient':S.expand(2*g4q.subs({r:t,e:0})-5*t**5/32)==0,
'P08 graph defect fifth degree':all(S.simplify(source_defect5[i]-R[i])==0 for i in range(2)),
'P09 C graph order3':all(S.Poly(S.expand(v),r,e).total_degree()==3 for v in C),
'P10 normal source defect order5':all(S.Poly(S.expand(v),r,e).total_degree()==5 for v in R),
'P11 parent successor cross-age vector':all(S.simplify(Dnext[i]-expected_next[i])==0 for i in range(2)),
'P12 parent successor cross-age ray':all(S.simplify(Dnext[i].subs({r:t,e:0})-val)==0 for i,val in enumerate((-k**2*t**9/18,k**2*t**9/9))),
'P13 two ages differ for k nonzero':S.expand(Dnext[0])!=0 and S.expand(Dnext[1])!=0,
'P14 one-delay rank on birth age zero':S.simplify((S.diff(Q,r)*S.diff(g3q+g4q,e)-S.diff(Q,e)*S.diff(g3q+g4q,r)).subs({r:t,e:0})+t**5/64)==0,
}
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' '+name)
 if not ok:raise AssertionError(name)
if args.negative_parent_closure:
 assert all(S.expand(val)==0 for val in Dnext),'INTENDED FAILURE: parent-only projection across birth ages is not closed'
print('SUMMARY',len(checks),'PASS exit 0')
print('SOURCE_SHA256',hashlib.sha256(source.read_bytes()).hexdigest())
