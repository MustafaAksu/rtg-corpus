#!/usr/bin/env python3
"""Reproduce conditional-source jet and C08/C09 checks from complete local layout.
No owner files or input bytes modified. Python stdlib + SymPy for C08/C09.
"""
from pathlib import Path
import argparse
from tempfile import TemporaryDirectory
from subprocess import run
import hashlib, shutil, sys
ap=argparse.ArgumentParser();ap.add_argument('--negatives',action='store_true',help='also rerun the two expected-failure controls');args=ap.parse_args()
ROOT=Path(__file__).resolve().parent
TARGET='15a7d0569a1e8ceefe04260ce83e204acb2eeed20b2639eebd810e14ee992824'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[ROOT/'C08/source/jet_coefficients.json',ROOT/'C09/source_copy/source/jet_coefficients.json',ROOT/'JET_PRODUCER/data/jet_coefficients.json']
for p in paths:
 assert sha(p)==TARGET,(p,sha(p))
 print('PASS JET SHA',p.relative_to(ROOT))
with TemporaryDirectory() as td:
 p=Path(td);(p/'scripts').mkdir();(p/'data').mkdir()
 shutil.copy2(ROOT/'JET_PRODUCER/scripts/make_jet.py',p/'scripts/make_jet.py')
 r=run([sys.executable,str(p/'scripts/make_jet.py')],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 assert (p/'data/jet_coefficients.json').read_bytes()==paths[0].read_bytes()
 print('PASS fresh six-step rational jet regeneration; source byte-identical')
for name in ['C08/scripts/check_f3_reachable.py','C09/scripts/check_interage_geometry.py']:
 r=run([sys.executable,str(ROOT/name)],capture_output=True,text=True)
 assert r.returncode==0,(name,r.stderr,r.stdout)
 print('PASS',name,'checks:',r.stdout.count('PASS'))
if args.negatives:
 for name,flag in [('C08/scripts/check_f3_reachable.py','--negative-parent-closure'),('C09/scripts/check_interage_geometry.py','--negative-age-invariance')]:
  r=run([sys.executable,str(ROOT/name),flag],capture_output=True,text=True)
  assert r.returncode==1 and 'INTENDED FAILURE' in (r.stderr+r.stdout),(name,r.returncode,r.stderr)
  print('PASS expected negative control',name)
print('ALL REQUESTED SOURCE/C08/C09 REPLAY CHECKS PASS')
