#!/usr/bin/env python3
"""Direct high-precision analytic six-step map age-sheet separation.
Numerical asymptotic consistency test, not proof of physical birth law.
"""
import mpmath as m
m.mp.dps=85
J=m.matrix([[1,-2],[2,-1]])/m.sqrt(3)
def te(v):
 r,e=v;return m.matrix([r-m.sin(e),e+m.exp(r)-1-m.sin(e)])
def N(s,c):
 a,b,d=te(s),te(-s/2+c),te(-s/2-c)
 return m.mpf(2)/3*a-(b+d)/3,(b-d)/2
def F(s,c):
 for _ in range(6):s,c=N(s,c)
 return s,c
def Q(s):return s[0]**2-s[0]*s[1]+s[1]**2
def C(s,k):return k*Q(s)*J*s
def age(s,k,n):
 c=C(s,k)
 for _ in range(n):s,c=F(s,c)
 return s,c
def match_current_parent(s,k,n):
 def residual(u,v):
  sp,_=age(m.matrix([u,v]),k,n)
  return sp[0]-s[0],sp[1]-s[1]
 u,v=m.findroot(residual,(s[0],s[1]),solver='mdnewton',tol=m.mpf('1e-60'),maxsteps=80)
 return age(m.matrix([u,v]),k,n)[1]
for k in (-m.mpf(1)/2,-2*m.sqrt(3)/3):
 for n in (1,2,3):
  for tt in ('0.035','0.02','0.01'):
   t=m.mpf(tt); s=m.matrix([t,0]); actual=match_current_parent(s,k,n)
   difference=actual-C(s,k)
   expected=-n*m.sqrt(3)*k*m.mpf(1)/6
   ratio=difference[0]/t**5
   print('k',m.nstr(k,8),'n',n,'t',tt,'normal_x/t5',m.nstr(ratio,18),'pred',m.nstr(expected,18),'normal_y/t5',m.nstr(difference[1]/t**5,9))
