#!/usr/bin/env python3
"""Exact conditional-model jet checks for fixed finite birth-age sheets.
Source is recovered Genesis six-step G3/G4 coefficients. No physical model choice.
"""
import json, hashlib, argparse
from pathlib import Path
import sympy as S
ap=argparse.ArgumentParser()
ap.add_argument('--negative-age-invariance',action='store_true')
a=ap.parse_args()
source=Path(__file__).resolve().parents[1]/'source_copy'/'source'/'jet_coefficients.json'
d=json.loads(source.read_text())
r,e,c,h,k,n,m,t=S.symbols('r e c h k n m t', real=True)
X=(r,e,c,h)
def poly(z):
    return S.expand(sum(S.Rational(v)*S.prod(zx**int(ex) for zx,ex in zip(X,mon.split(','))) for mon,v in z.items()))
G3=S.Matrix([poly(z) for z in d['G3']])
G4=S.Matrix([poly(z) for z in d['G4']])
s=S.Matrix([r,e]); Q=r*r-r*e+e*e
J=S.Matrix([[1,-2],[2,-1]])/S.sqrt(3)
C=S.simplify(k*Q*J*s)
f3=S.Matrix([S.expand(v.subs({c:0,h:0})) for v in G3[:2,:]])
f4=S.Matrix([S.expand(v.subs({c:0,h:0})) for v in G4[:2,:]])

def homogeneous(expr, degree):
    return S.expand(sum(coef*r**powers[0]*e**powers[1] for powers,coef in S.Poly(S.expand(expr),r,e).terms() if sum(powers)==degree))

def test_equals(label, left, right):
    ok= S.simplify(S.expand(left-right))==0
    print(('PASS' if ok else 'FAIL')+' '+label)
    if not ok:raise AssertionError(label)

assert all(S.expand(v.subs({c:0,h:0}))==0 for v in G3[2:,:]), 'Source child-free cubic invariant'
assert all(S.expand(v.subs({c:0,h:0}))==0 for v in G4[2:,:]), 'Source child-free quartic invariant'
print('PASS child-free G3/G4 source blocks')
V5=S.Matrix([homogeneous(v.subs({c:C[0],h:C[1]}),5) for v in G3[2:,:]])
DC=C.jacobian(s)
R=S.simplify(V5-DC*f3)
R_expected=-S.sqrt(3)*k*S.Rational(1,6)*Q**2*s
for i in range(2):test_equals(f'R5 component {i}',R[i],R_expected[i])

# In initial-parent coordinates (s0), fixed n finite jet to degree five
# s_n=s+n*f3+n*f4+O(s^5), c_n=C+n*V5+O(s^6)
# C(s_n)=C+n*DC*f3+O(s^6), because C is homogeneous degree 3.
for age in (0,1,2,3,5):
    s_age=s+age*f3+age*f4
    c_age=C+age*V5
    derived=S.Matrix([homogeneous(S.expand(c_age[i]-C[i].subs({r:s_age[0],e:s_age[1]}, simultaneous=True)),5) for i in range(2)])
    for i in range(2): test_equals(f'fixed age {age} graph residual component {i}',derived[i],age*R_expected[i])
# The graph expression in matched CURRENT parent s is the same to degree five.
for i in range(2):test_equals(f'inter-age formula component {i}',(n-m)*R[i],(n-m)*R_expected[i])
# Cross-age observable witness from the normal difference of the same-parent states
G3parent=S.Matrix(G3[:2,:]); normal_next=S.simplify(G3parent.jacobian(S.Matrix([c,h])).subs({c:C[0],h:C[1]})*R_expected)
expected_next=k*k*Q**4*S.Matrix([-r-2*e,2*r-3*e])/18
for i in range(2):test_equals(f'inter-age parent observable component {i}',normal_next[i],expected_next[i])
qdiff=S.expand((2*r-e)*normal_next[0]+(2*e-r)*normal_next[1])
test_equals('general cross-age Q scalar formula',qdiff,-2*k*k*Q**5/9)
test_equals('generic ages cross-age Q scalar formula',(n-m)*qdiff,-(n-m)*2*k*k*Q**5/9)
for name,lhs,rhs in [('ray Q difference degree10',qdiff.subs({r:t,e:0}),-2*k*k*t**10/9),('ray normal defect x',R_expected[0].subs({r:t,e:0}),-S.sqrt(3)*k*t**5/6),('ray normal defect y',R_expected[1].subs({r:t,e:0}),0)]:test_equals(name,lhs,rhs)
# positivity is algebraic: Q positive definite and Q**2*s vanishes iff s=0 (for k neq0).
test_equals('Gram Q completed square',Q,(r-e/2)**2+3*e*e/4)
assert S.simplify((n-m)*R_expected[0] / (n-m) - R_expected[0])==0
print('PASS age difference nonzero for k !=0, n!=m, s!=0 by positive B quadratic form')
if a.negative_age_invariance:
    assert all(S.simplify(v)==0 for v in R),'INTENDED FAILURE: nonzero child birth graph is invariant'
print('SOURCE_SHA256',hashlib.sha256(source.read_bytes()).hexdigest())
print('SUMMARY exact checks PASS')
