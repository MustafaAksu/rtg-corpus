"""Phase B-02 r1 check for receiver finding B02-R1 (SESSION; exact sympy; runs in well under a second).
With B=[[1,-1/2],[-1/2,1]], J_Q=(1/sqrt3)[[1,-2],[2,-1]], Q_s=s^T B s, I=s^T B c, Omega=s^T B J_Q c:
 R1 J_Q^T B J_Q = B, J_Q^2 = -I, and B J_Q is antisymmetric (so s^T B J_Q s = 0 and {s, J_Q s} is B-orthogonal with equal Q).
 R2 the corrected reconstruction c = (I s - Omega J_Q s)/Q_s holds identically for symbolic s, c with Q_s != 0.
 R3 the r0 note's formula c = (I s + Omega J_Q s)/Q_s fails (negative control), e.g. at s=(1,0), c=J_Q s where I=0, Omega=-1.
Exit 0 iff R1, R2 hold and R3 fails as required."""
import sys, sympy as sp
s1, s2, c1, c2 = sp.symbols('s1 s2 c1 c2', real=True)
B = sp.Matrix([[1, sp.Rational(-1, 2)], [sp.Rational(-1, 2), 1]]); JQ = sp.Matrix([[1, -2], [2, -1]]) / sp.sqrt(3)
s = sp.Matrix([s1, s2]); c = sp.Matrix([c1, c2])
Qs = (s.T * B * s)[0]; I = (s.T * B * c)[0]; Om = (s.T * B * JQ * c)[0]
R1 = sp.simplify(JQ.T * B * JQ - B) == sp.zeros(2) and sp.simplify(JQ * JQ + sp.eye(2)) == sp.zeros(2) and sp.simplify((B * JQ) + (B * JQ).T) == sp.zeros(2)
rec_minus = (I * s - Om * JQ * s) / Qs; rec_plus = (I * s + Om * JQ * s) / Qs
R2 = sp.simplify(rec_minus - c) == sp.zeros(2, 1)
sub = {s1: 1, s2: 0}; cJ = JQ * sp.Matrix([1, 0]); sub.update({c1: cJ[0], c2: cJ[1]})
I0, Om0 = sp.simplify(I.subs(sub)), sp.simplify(Om.subs(sub))
R3_fails = sp.simplify(rec_plus.subs(sub) - c.subs(sub)) != sp.zeros(2, 1) and sp.simplify(rec_plus.subs(sub) + cJ) == sp.zeros(2, 1)
print('R1 isometry/involution/antisymmetry:', R1); print('R2 corrected reconstruction identity:', R2)
print('R3 example s=(1,0), c=J_Q s: I =', I0, ', Omega =', Om0, '; plus-sign formula gives -J_Q s:', R3_fails)
sys.exit(0 if (R1 and R2 and R3_fails) else 1)
