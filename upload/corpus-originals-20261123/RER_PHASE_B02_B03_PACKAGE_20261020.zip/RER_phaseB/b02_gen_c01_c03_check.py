"""Phase B-02 preparer re-derivation for RER-GEN-C01..C03 (SESSION; exact sympy; not an owner certificate).
Model exactly as RER r4.6 §3 / GENMODEL §2: N=(P(x)I2) o T_e^{x3} o (E(x)I2), F=N^6, X=(s_rho,s_eta,c_rho,c_eta).
Checks:
 K1 one-step N: DN(0)=A(+)A with A^3=-I; F has no quadratic part (G2=0).
 K2 the cubic jet G3 of F equals the printed G_s, G_c (GENMODEL §3).
 K3 G3 is SO(B)-equivariant: DG3(X) J X - J G3(X) = 0, J=diag(J_Q,J_Q)  (C02 transformation law).
 K4 C01 witness: I(J3(t e1,+t J_Q e1)) - I(J3(t e1,-t J_Q e1)) = sqrt(3)/9 t^4 + O(t^6), with unsigned Gram (Qs,Qc,I) equal.
 K5 C03 witness: Phi(X_t)=Phi(-X_t) and Qs(F(X_t))-Qs(F(-X_t)) = 349/288 t^5 + O(t^7), X_t=(t,0,0,t).
 K6 GENMODEL §4 side value: Qs(F(t,0,0,0))-Qs(F(-t,0,0,0)) = 5/32 t^5 + O(t^7).
 K7 negative control: replacing 349/288 by 349/287 fails.
Exit 0 iff K1..K7 hold."""
import sys, sympy as sp
e = sp.symbols('e')
ORD = 7
def trunc(x, n=ORD): return sp.expand(sp.series(sp.expand(x), e, 0, n + 1).removeO()) if x.has(e) else sp.expand(x)
def tpoly(x, n=ORD):
    p = sp.Poly(sp.expand(x), e); return sp.expand(sum(c * e**k for (k,), c in p.terms() if k <= n))
def ser_sin(u, n=ORD): return tpoly(sum((-1)**k * u**(2*k+1) / sp.factorial(2*k+1) for k in range(n // 2 + 1)), n)
def ser_expm1(u, n=ORD): return tpoly(sum(u**k / sp.factorial(k) for k in range(1, n + 1)), n)
E = sp.Matrix([[1, 0], [sp.Rational(-1, 2), 1], [sp.Rational(-1, 2), -1]]); P = (E.T * E).inv() * E.T
def N(X, n=ORD):
    s, c = sp.Matrix(X[0:2]), sp.Matrix(X[2:4])
    edges = []
    for i in range(3):
        rho = tpoly(E[i, 0] * s[0] + E[i, 1] * c[0], n); eta = tpoly(E[i, 0] * s[1] + E[i, 1] * c[1], n)
        sn = ser_sin(eta, n); edges.append((tpoly(rho - sn, n), tpoly(eta + ser_expm1(rho, n) - sn, n)))
    out = []
    for comp in range(2):
        w = sp.Matrix([edges[i][comp] for i in range(3)]); m = P * w; out.append((m[0], m[1]))
    return [tpoly(out[0][0], n), tpoly(out[1][0], n), tpoly(out[0][1], n), tpoly(out[1][1], n)]
def F(X, n=ORD):
    for _ in range(6): X = N(X, n)
    return X
B = sp.Matrix([[1, sp.Rational(-1, 2)], [sp.Rational(-1, 2), 1]]); JQ = sp.Matrix([[1, -2], [2, -1]]) / sp.sqrt(3)
Qf = lambda a, b: (sp.Matrix(a).T * B * sp.Matrix(b))[0]
Om = lambda a, b: (sp.Matrix(a).T * B * JQ * sp.Matrix(b))[0]
ok = {}
# K1
x = sp.symbols('x1:5'); X = [e * xi for xi in x]
N1 = N(X, 3); A = sp.Matrix([[1, -1], [1, 0]])
L = sp.Matrix([[sp.Poly(N1[i], e).coeff_monomial(e) .diff(x[j]) for j in range(4)] for i in range(4)])
ok['K1a'] = L == sp.diag(A, A) and A**3 == -sp.eye(2)
F3 = F(X, 3)
ok['K1b'] = all(sp.Poly(F3[i], e).coeff_monomial(e**2) == 0 for i in range(4)) and all(sp.expand(sp.Poly(F3[i], e).coeff_monomial(e) - x[i]) == 0 for i in range(4))
G3 = [sp.expand(sp.Poly(F3[i], e).coeff_monomial(e**3)) for i in range(4)]
# K2 printed G3
s = sp.Matrix(x[0:2]); c = sp.Matrix(x[2:4]); Qs, Qc, I = Qf(s, s), Qf(c, c), Qf(s, c); w = s[1]*c[0] - s[0]*c[1]
Gs = (Qs/8 + Qc/2)*s - I*c/3 - sp.sqrt(3)*(Qs/4 + Qc/9)*JQ*s - 2*sp.sqrt(3)*I*JQ*c/9
Gc = Qc*c/6 + (I + w)*s/8 - (4*I + 9*w)*JQ*s/(16*sp.sqrt(3)) - (sp.sqrt(3)*Qs/6 + sp.sqrt(3)*Qc/3)*JQ*c
ok['K2'] = all(sp.simplify(G3[i] - list(Gs) [i] if i < 2 else G3[i] - list(Gc)[i-2]) == 0 for i in range(4))
# K3
Jb = sp.diag(JQ, JQ); Xv = sp.Matrix(x); Gv = sp.Matrix(G3)
ok['K3'] = sp.simplify(Gv.jacobian(x) * Jb * Xv - Jb * Gv) == sp.zeros(4, 1)
# K4 (J3 = Id + G3 exactly, polynomial in t)
t = sp.symbols('t', positive=True)
def J3(Xn): sub = dict(zip(x, Xn)); return [Xn[i] + G3[i].subs(sub) for i in range(4)]
e1 = sp.Matrix([1, 0]); jc = JQ * e1
Xp = [t, 0, t*jc[0], t*jc[1]]; Xm = [t, 0, -t*jc[0], -t*jc[1]]
ug = lambda Z: (Qf(Z[0:2], Z[0:2]), Qf(Z[2:4], Z[2:4]), Qf(Z[0:2], Z[2:4]))
ok['K4a'] = all(sp.simplify(a - b) == 0 for a, b in zip(ug(Xp), ug(Xm)))
d4 = sp.expand(sp.simplify(Qf(J3(Xp)[0:2], J3(Xp)[2:4]) - Qf(J3(Xm)[0:2], J3(Xm)[2:4])))
ok['K4b'] = sp.simplify(sp.Poly(d4, t).coeff_monomial(t**4) - sp.sqrt(3)/9) == 0 and all(sp.Poly(d4, t).coeff_monomial(t**k) == 0 for k in (1, 2, 3, 5))
print('C01 Delta I =', sp.factor(d4))
# K5, K6 along rays (series in e, then t=e)
def Phi(Z): return (Qf(Z[0:2], Z[0:2]), Qf(Z[2:4], Z[2:4]), Qf(Z[0:2], Z[2:4]), Om(Z[0:2], Z[2:4]))
Xt = [e, 0, 0, e]; Xtm = [-e, 0, 0, -e]
ok['K5a'] = all(sp.simplify(a - b) == 0 for a, b in zip(Phi(Xt), Phi(Xtm)))
dq = tpoly(Qf(F(Xt)[0:2], F(Xt)[0:2]) - Qf(F(Xtm)[0:2], F(Xtm)[0:2]))
cq = [sp.nsimplify(sp.Poly(dq, e).coeff_monomial(e**k)) for k in range(8)]
print('C03 Delta Qs coefficients t^0..t^7 =', cq)
ok['K5b'] = cq[5] == sp.Rational(349, 288) and all(cq[k] == 0 for k in (0, 1, 2, 3, 4, 6))
dp = tpoly(Qf(F([e, 0, 0, 0])[0:2], F([e, 0, 0, 0])[0:2]) - Qf(F([-e, 0, 0, 0])[0:2], F([-e, 0, 0, 0])[0:2]))
cp = [sp.Poly(dp, e).coeff_monomial(e**k) for k in range(8)]
print('pure-parent Delta Qs coefficients =', cp)
ok['K6'] = cp[5] == sp.Rational(5, 32) and all(cp[k] == 0 for k in (0, 1, 2, 3, 4, 6))
ok['K7'] = cq[5] != sp.Rational(349, 287)
print(ok); sys.exit(0 if all(ok.values()) else 1)
