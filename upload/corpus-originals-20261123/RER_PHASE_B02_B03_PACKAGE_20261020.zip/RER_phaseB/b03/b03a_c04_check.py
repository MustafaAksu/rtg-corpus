"""Phase B-03 preparer check for RER-GEN-C04 (SESSION; exact sympy; the model is rebuilt from its definition by b03_model, no jet file).
 A1 Theta_2 = sqrt3/(2Qs)(s_rho G3_s,eta - s_eta G3_s,rho) equals the printed Phi-form and the (a,h,k)-form (ANGLE §2).
 A2 on the witness orbit X(theta)=R_theta((1,0),(0,1)): Theta_2 = -sqrt3/3; Theta_3 = N4/Qs has only harmonics +-1,+-3 (no +-5, no constant)
    with the printed coefficients 65sqrt3/1728, -19/192, -199sqrt3/3456, -863/3456.
 A3 Phi=(Qs,Qc,I,Omega) is invariant under the common proper B-isometry R_theta, and the t^4 readout term D Phi . G3 is theta-independent on the orbit.
 A4 Psi_5(theta) = D Phi(X(theta)) . G4(X(theta)) has only harmonics +-1,+-3 and equals the printed 4x4 matrix M; rank M = 3;
    the kernel direction equals the printed v; Im(r conj(q)^3) equals the printed value and is nonzero.
 A5 the two trigonometric identities used in the injectivity proof (chord ratio real; derivative ratio -3).
Exit 0 iff all hold. Runtime: a few seconds."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sympy as sp, b03_model as M
x = M.x; s3 = sp.sqrt(3); z, w = sp.symbols('z w')  # z = e^{i theta}, w = e^{-i theta}; harmonics are read off as (power of z) - (power of w)
J = M.jets(4); G3, G4 = J[3], J[4]
Qs, Qc, I, Om = M.Qs, M.Qc, M.I, M.Om
ok = {}
def lz(expr):
    p = sp.Poly(sp.expand(expr), z, w); out = {}
    for (a, b), c in p.terms(): out[a - b] = sp.expand(out.get(a - b, 0) + c)
    return {k: v for k, v in out.items() if v != 0}
def cs(f, n):  # cos/sin coefficients of harmonic n from the e^{+-in theta} coefficients
    cp, cm = f.get(n, 0), f.get(-n, 0); return sp.expand(cp + cm), sp.expand(sp.I * (cp - cm))
# A1
Th2 = sp.cancel(s3 / (2 * Qs) * (x[0] * G3[1] - x[1] * G3[0]))
Th2_phi = -s3 / 4 * Qs - s3 / 9 * Qc + I * Om / (3 * Qs) - 2 * s3 * I**2 / (9 * Qs)
ok['A1_phi_form'] = sp.cancel(Th2 - Th2_phi) == 0
a, h, k = sp.symbols('a h k', real=True)
Lm = sp.Matrix([[1, sp.Rational(-1, 2)], [0, s3 / 2]]); Li = Lm.inv()   # L_B(rho,eta) = rho - eta/2 + i sqrt3 eta/2 ; Lm^T Lm = B
ok['A1_LtL_is_B'] = sp.expand(Lm.T * Lm - M.Bm) == sp.zeros(2)
sub_ahk = dict(zip(x, list(Li * sp.Matrix([a, 0])) + list(Li * sp.Matrix([h, k]))))   # theta = 0 chart: L_B s = a, L_B c = h + i k
Th2_ahk = -s3 * (a**2 / 4 + h**2 / 3 + k**2 / 9) - h * k / 3
ok['A1_ahk_form'] = sp.cancel(Th2.xreplace(sub_ahk) - Th2_ahk) == 0
ok['A1_h_I_over_a_and_k_minus_Omega_over_a'] = sp.expand(I.xreplace(sub_ahk) - h * a) == 0 and sp.expand(Om.xreplace(sub_ahk) + k * a) == 0
# A2: R_theta = L^{-1} Rot(theta) L acting on s and c
cth, sth = (z + w) / 2, (z - w) / (2 * sp.I)
R = sp.expand(Li * sp.Matrix([[cth, -sth], [sth, cth]]) * Lm)
ok['A2_R_proper_B_isometry'] = lz((R.T * M.Bm * R - M.Bm)[0, 0]) == {} and lz((R.T * M.Bm * R - M.Bm)[0, 1]) == {} and lz((R.T * M.Bm * R - M.Bm)[1, 1]) == {} and lz(R.det() - 1) == {}
ok['A2_JQ_is_quarter_turn'] = sp.expand(Li * sp.Matrix([[0, -1], [1, 0]]) * Lm - M.JQ) == sp.zeros(2)
Xth = list(R * sp.Matrix([1, 0])) + list(R * sp.Matrix([0, 1])); subth = dict(zip(x, Xth))
ok['A2_Theta2_witness'] = lz(Th2.xreplace(subth) + s3 / 3) == {}
Qs_orbit = lz(Qs.xreplace(subth)); ok['A2_Qs_on_orbit_is_1'] = Qs_orbit == {0: 1}
N4 = s3 / 2 * (x[0] * G4[1] - x[1] * G4[0])
Th3 = lz(N4.xreplace(subth))  # Theta_3 = N4 / Qs with Qs = 1 on the orbit
ok['A2_Theta3_harmonics_only_1_3'] = set(Th3) <= {1, -1, 3, -3}
c1, s1 = cs(Th3, 1); c3, s3c = cs(Th3, 3)
ok['A2_Theta3_witness_coeffs'] = [c1, s1, c3, s3c] == [65 * s3 / 1728, sp.Rational(-19, 192), -199 * s3 / 3456, sp.Rational(-863, 3456)]
print('Theta3 witness: cos', c1, ' sin', s1, ' cos3', c3, ' sin3', s3c)
# A3
Phi = [Qs, Qc, I, Om]
subR = dict(zip(x, list(R * M.s) + list(R * M.c)))
ok['A3_Phi_SO_B_invariant'] = all(lz(f.xreplace(subR) - f) == {} for f in Phi)
DPhi = sp.Matrix([[sp.diff(f, xi) for xi in x] for f in Phi])
t4 = (DPhi * sp.Matrix(G3)).xreplace(subth); ok['A3_t4_term_theta_independent'] = all(set(lz(t4[i])) <= {0} for i in range(4))
print('t^4 readout term on the orbit (theta-independent):', [lz(t4[i]).get(0, 0) for i in range(4)])
# A4
Psi5 = (DPhi * sp.Matrix(G4)).xreplace(subth); F5 = [lz(Psi5[i]) for i in range(4)]
ok['A4_Psi5_harmonics_only_1_3'] = all(set(f) <= {1, -1, 3, -3} for f in F5)
Mmat = sp.Matrix([[*cs(f, 1), *cs(f, 3)] for f in F5])
M_print = sp.Matrix([[sp.Rational(65, 288), 161 * s3 / 864, sp.Rational(73, 192), -59 * s3 / 5184],
                     [sp.Rational(-11, 48), -17 * s3 / 144, sp.Rational(17, 48), -13 * s3 / 432],
                     [sp.Rational(-11, 32), -7 * s3 / 27, sp.Rational(-137, 1152), 271 * s3 / 10368],
                     [25 * s3 / 216, sp.Rational(55, 288), -709 * s3 / 3456, sp.Rational(53, 3456)]])
ok['A4_M_equals_printed'] = sp.expand(Mmat - M_print) == sp.zeros(4)
ok['A4_rank_3'] = Mmat.rank(simplify=True) == 3
ker = Mmat.nullspace(simplify=True); v_print = sp.Matrix([-1716859 * s3, 2492295, -160036 * s3, 1413576])
ok['A4_kernel_direction'] = len(ker) == 1 and sp.expand(Mmat * v_print) == sp.zeros(4, 1) and sp.expand(ker[0] * v_print[3] / ker[0][3] - v_print) == sp.zeros(4, 1)
q = v_print[0] + sp.I * v_print[1]; r = v_print[2] + sp.I * v_print[3]
obs = sp.expand(sp.im(sp.expand(r * sp.conjugate(q)**3)))
ok['A4_obstruction_value'] = sp.expand(obs - 31867336191987863672583168 * s3) == 0 and obs != 0
print('Im(r conj(q)^3) =', obs)
# A5 (injectivity-proof identities). Chord ratio: (z^3-y^3)/(z-y)^3 = (z^2+zy+y^2)/(z-y)^2 algebraically; with z=e^{i(m+d)}, y=e^{i(m-d)}
# this is (1+2cos2d)/(2i sin d)^2 = -(1+2cos 2d)/(4 sin^2 d) = -sin3d/(4 sin^3 d), real. Derivative ratio: 3i e^{3i th}/(i e^{i th})^3 = -3.
zz, yy, dd, th = sp.symbols('zz yy delta theta', real=True)
ok['A5_chord_algebraic_step'] = sp.cancel((zz**3 - yy**3) / (zz - yy)**3 - (zz**2 + zz * yy + yy**2) / (zz - yy)**2) == 0
num = sp.expand((sp.exp(2 * sp.I * dd) + 1 + sp.exp(-2 * sp.I * dd)).rewrite(sp.cos)); den = sp.expand(((sp.exp(sp.I * dd) - sp.exp(-sp.I * dd))**2).rewrite(sp.cos))
ok['A5_chord_trig_step'] = sp.simplify(num - (1 + 2 * sp.cos(2 * dd))) == 0 and sp.simplify(den + 4 * sp.sin(dd)**2) == 0 and sp.simplify(sp.expand_trig(sp.sin(3 * dd)) - sp.sin(dd) * (1 + 2 * sp.cos(2 * dd))) == 0
ratio = sp.diff(sp.exp(3 * sp.I * th), th) / sp.diff(sp.exp(sp.I * th), th)**3
ok['A5_derivative_ratio_is_minus_3'] = sp.simplify(ratio + 3) == 0
print(ok); sys.exit(0 if all(ok.values()) else 1)
