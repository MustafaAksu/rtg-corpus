"""Phase B-03 preparer check for RER-GEN-C06 and RER-GEN-C07 (SESSION; exact sympy; model rebuilt from its definition, no jet file).
C06 (F3 §F3-a, F3-b):
 S1 exact invariance of M0={c=0}: with the untruncated T_e (sin, exp), the child row of N vanishes identically on c=0 and the parent row is
    N_s(s) = 2/3 (T_e(s) - T_e(-s/2)); explicit formula of F3-a.
 S2 Q(F_s(s)) - Q(s) = Q^2/4 + P5 + O(6), P5 = Q/64 (5r^3 - 8er^2 - 9e^2 r - 5e^3), with Q = r^2 - re + e^2.
 S3 det D(Q, Q o F_s) = -Q/64 (r^3 + 74er^2 - 11e^2 r - 33e^3) + O(6); at (t,0): -t^5/64.
 S4 Q(F_s(t,0)) - Q(F_s(-t,0)) = 5t^5/32 + O(t^6) (Q alone is not autonomous on M0).
C07 (F3 §F3-c):
 D1 G3_c(s,0) = G4_c(s,0) = 0 (consistent with S1); parent jets even in c, child jets odd in c, through degree 7.
 D2 the defect D_kappa(s) = F_c(s,C) - C(F_s(s,C)), C = kappa Q J_Q s, has degree-5 part -(sqrt3 kappa/6) Q^2 s, computed two ways:
    (a) by the jet formula D_cG3_c(s,0).C - DC.G3_s(s,0); (b) by direct substitution of C into the degree-7 jet of F, truncated at degree 6.
 D3 an analytic correction C + delta5 (delta5 any homogeneous degree-5 polynomial) leaves the degree-5 and degree-6 parts of the defect
    unchanged: the degree<=6 defect is linear in delta5, so the 12 monomial basis corrections are checked.
 D4 negative control: coefficient -sqrt3 kappa/7 is rejected.
Exit 0 iff all hold. Runtime: about 25 s; --fast checks 2 of the 12 D3 basis directions (about 8 s)."""
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sympy as sp, b03_model as M
_T0 = time.time()
def lap(tag): print('  [%5.1fs] %s' % (time.time() - _T0, tag)); sys.stdout.flush()
x = M.x; r, e, t, kap = sp.symbols('r e t kappa', real=True); s3 = sp.sqrt(3); ok = {}
# S1 exact (untruncated) invariance
def Te(rho, eta): return (rho - sp.sin(eta), eta + sp.exp(rho) - 1 - sp.sin(eta))
Em = sp.Matrix([[1, 0], [sp.Rational(-1, 2), 1], [sp.Rational(-1, 2), -1]]); Pm = (Em.T * Em).inv() * Em.T
sv = sp.Matrix([r, e]); cv = sp.zeros(2, 1)
edges = [Te(*(Em[i, 0] * sv + Em[i, 1] * cv)) for i in range(3)]
Nrow = [sp.expand(sum(Pm[k, i] * edges[i][comp] for i in range(3))) for k in range(2) for comp in range(2)]  # [s_rho, s_eta, c_rho, c_eta]
ok['S1_child_row_identically_zero_on_M0'] = Nrow[2] == 0 and Nrow[3] == 0
Ns_formula = [sp.expand(sp.Rational(2, 3) * (Te(r, e)[k] - Te(-r / 2, -e / 2)[k])) for k in range(2)]
ok['S1_parent_row_is_2over3_T(s)-T(-s/2)'] = all(sp.expand(Nrow[k] - Ns_formula[k]) == 0 for k in range(2))
explicit = (r - sp.Rational(2, 3) * (sp.sin(e) + sp.sin(e / 2)), e + sp.Rational(2, 3) * (sp.exp(r) - sp.exp(-r / 2) - sp.sin(e) - sp.sin(e / 2)))
ok['S1_explicit_formula'] = all(sp.expand(Ns_formula[k] - explicit[k]) == 0 for k in range(2))
lap('S1 done')
# truncated substitution helper: evaluate a 4-variable polynomial at (r, e, C0(r,e), C1(r,e)), keeping total degree <= deg in (r,e)
def hom(expr, k, vars_=(r, e)):
    p = sp.Poly(sp.expand(expr), *vars_); return sp.expand(sum(c * sp.prod([v**m for v, m in zip(vars_, mon)]) for mon, c in p.terms() if sum(mon) == k))
def trunc_re(expr, deg):
    p = sp.Poly(sp.expand(expr), r, e); return sp.expand(sum(c * r**m[0] * e**m[1] for m, c in p.terms() if sum(m) <= deg))
def subst_trunc(poly4, C0, C1, deg, cmin=3):
    """poly4: sympy polynomial in x1..x4; C0, C1 polynomials in (r,e) with lowest degree cmin; result truncated at degree deg"""
    p = sp.Poly(poly4, *x); out = 0
    pw0 = {0: sp.Integer(1)}; pw1 = {0: sp.Integer(1)}
    for (a, b, c, d), q in p.terms():
        if a + b + cmin * (c + d) > deg: continue
        for k in range(1, c + 1):
            if k not in pw0: pw0[k] = trunc_re(pw0[k - 1] * C0, deg)
        for k in range(1, d + 1):
            if k not in pw1: pw1[k] = trunc_re(pw1[k - 1] * C1, deg)
        out += q * r**a * e**b * trunc_re(pw0[c] * pw1[d], deg)
    return trunc_re(out, deg)
F7 = [M.to_sympy(p) for p in M.F(M.X0, 7)]
Q = r**2 - r * e + e**2
# S2-S4 on M0 (c = 0)
Fs = [subst_trunc(F7[i], sp.Integer(0), sp.Integer(0), 7, 1) for i in range(2)]
dQ = sp.expand(Fs[0]**2 - Fs[0] * Fs[1] + Fs[1]**2 - Q)
P5 = Q / 64 * (5 * r**3 - 8 * e * r**2 - 9 * e**2 * r - 5 * e**3)
ok['S2_degree4_is_Q2_over_4'] = sp.expand(hom(dQ, 4) - Q**2 / 4) == 0
ok['S2_degree5_is_P5'] = sp.expand(hom(dQ, 5) - P5) == 0
ok['S2_no_lower_degrees'] = all(hom(dQ, k) == 0 for k in range(0, 4))
QF = sp.expand(Q + dQ)
det = sp.expand(sp.Matrix([[sp.diff(Q, r), sp.diff(Q, e)], [sp.diff(QF, r), sp.diff(QF, e)]]).det())
ok['S3_det_degree5'] = sp.expand(hom(det, 5) + Q / 64 * (r**3 + 74 * e * r**2 - 11 * e**2 * r - 33 * e**3)) == 0 and all(hom(det, k) == 0 for k in range(0, 5))
ok['S3_det_at_(t,0)'] = sp.Poly(det.xreplace({r: t, e: 0}), t).coeff_monomial(t**5) == sp.Rational(-1, 64)
d54 = sp.expand(QF.xreplace({r: t, e: 0}) - QF.xreplace({r: -t, e: 0}))
ok['S4_5t5_over_32'] = sp.Poly(d54, t).coeff_monomial(t**5) == sp.Rational(5, 32) and all(sp.Poly(d54, t).coeff_monomial(t**k) == 0 for k in range(5))
lap('S2-S4 done')
# C07
J = M.jets(7)
lap('jets(7) done')
def parity(poly, sign): return sp.expand(poly.xreplace({x[2]: -x[2], x[3]: -x[3]}) - sign * poly) == 0   # sign=+1 even in c, sign=-1 odd in c
ok['D1_child_jets_vanish_on_M0'] = all(J[k][i].xreplace({x[2]: 0, x[3]: 0}) == 0 for k in range(3, 8) for i in (2, 3))
ok['D1_parent_even_child_odd_in_c'] = all(parity(J[k][i], 1) for k in range(1, 8) for i in (0, 1)) and all(parity(J[k][i], -1) for k in range(1, 8) for i in (2, 3))
sJ = sp.Matrix([r, e]); JQ = M.JQ; C = sp.expand(kap * Q * JQ * sJ)
G3 = sp.Matrix(J[3]); subs_s0 = {x[0]: r, x[1]: e, x[2]: 0, x[3]: 0}
DcG3c = sp.Matrix([[sp.diff(G3[i], x[j]) for j in (2, 3)] for i in (2, 3)]).xreplace(subs_s0)
DC = sp.Matrix([[sp.diff(C[i], v) for v in (r, e)] for i in range(2)])
G3s0 = sp.Matrix([G3[0], G3[1]]).xreplace(subs_s0)
Da = sp.expand(DcG3c * C - DC * G3s0)
target = sp.expand(-s3 * kap / 6 * Q**2 * sJ)
ok['D2a_jet_formula'] = sp.expand(Da - target) == sp.zeros(2, 1)
def defect(C0, C1, deg):
    Fc = [subst_trunc(F7[i], C0, C1, deg) for i in (2, 3)]; Fs_ = [subst_trunc(F7[i], C0, C1, deg) for i in (0, 1)]
    Cof = lambda u, v: sp.expand(kap * (u**2 - u * v + v**2) * (JQ * sp.Matrix([u, v])))   # C evaluated at a parent (u,v)
    CF = Cof(Fs_[0], Fs_[1])
    return sp.Matrix([trunc_re(Fc[i] - CF[i], deg) for i in range(2)]), Fs_
Dk, Fs_at_C = defect(C[0], C[1], 6)
def homv(vec, k): return sp.Matrix([hom(vec[i], k) for i in range(2)])
ok['D2b_direct_degree5'] = sp.expand(homv(Dk, 5) - target) == sp.zeros(2, 1) and all(homv(Dk, k) == sp.zeros(2, 1) for k in range(0, 5))
print('defect degree-6 part (not claimed in the record):', list(homv(Dk, 6)))
lap('D2 done')
# D3 generic degree-5 correction. The degree<=6 part of the defect is linear in the correction delta (terms quadratic in delta have
# degree >= 10), so checking the 12 monomial basis corrections with eps = 1 covers every delta5 = sum a_i (monomial) and every eps.
mons = [r**i * e**(5 - i) for i in range(6)]
basis = [sp.Matrix([m, 0]) for m in mons] + [sp.Matrix([0, m]) for m in mons]
Cof = lambda u, v: sp.expand(kap * (u**2 - u * v + v**2) * (JQ * sp.Matrix([u, v])))
FAST = '--fast' in sys.argv
if FAST: basis = basis[:2]; print('D3 in --fast mode: 2 of the 12 basis directions')
d3 = True
for delta5 in basis:
    C2 = sp.expand(C + delta5)
    Fc2 = [subst_trunc(F7[i], C2[0], C2[1], 6) for i in (2, 3)]; Fs2 = [subst_trunc(F7[i], C2[0], C2[1], 6) for i in (0, 1)]
    C2F = Cof(Fs2[0], Fs2[1]) + sp.Matrix([trunc_re(delta5[i].xreplace({r: Fs2[0], e: Fs2[1]}), 6) for i in range(2)])
    Dk2 = sp.Matrix([trunc_re(Fc2[i] - C2F[i], 6) for i in range(2)])
    d3 = d3 and sp.expand(homv(Dk2, 5) - homv(Dk, 5)) == sp.zeros(2, 1) and sp.expand(homv(Dk2, 6) - homv(Dk, 6)) == sp.zeros(2, 1)
ok['D3_degree5_6_unchanged_by_degree5_correction'] = d3
lap('D3 done')
ok['D4_negative_control'] = sp.expand(homv(Dk, 5) + s3 * kap / 7 * Q**2 * sJ) != sp.zeros(2, 1)
print(ok); sys.exit(0 if all(ok.values()) else 1)
