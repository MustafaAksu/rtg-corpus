"""Shared exact model builder for the Phase B-03 checks (preparer SESSION).
Builds the RER r4.6 §3 model from its definition only: E, P=(E^T E)^{-1}E^T, raw T_e(rho,eta)=(rho-sin eta, eta+e^rho-1-sin eta),
reprojection after each primitive step, F=N^6. Exact rational arithmetic on truncated multivariate polynomials in
X=(s_rho,s_eta,c_rho,c_eta) (dict monomial->Fraction). No jet file is read. Conversion to sympy is provided for the checks."""
from fractions import Fraction as Fr
from math import factorial
import sympy as sp
NV = 4
def padd(a, b):
    r = dict(a)
    for m, c in b.items():
        v = r.get(m, 0) + c
        if v == 0: r.pop(m, None)
        else: r[m] = v
    return r
def pscale(a, k): return {m: c * k for m, c in a.items()} if k != 0 else {}
def pmul(a, b, deg):
    r = {}
    for m1, c1 in a.items():
        d1 = sum(m1)
        for m2, c2 in b.items():
            if d1 + sum(m2) > deg: continue
            m = tuple(i + j for i, j in zip(m1, m2)); r[m] = r.get(m, 0) + c1 * c2
    return {m: c for m, c in r.items() if c != 0}
def ppow_series(u, coeffs, deg):
    """sum_k coeffs[k] u^k, truncated at total degree deg"""
    r = {}; uk = {(0,) * NV: Fr(1)}
    for k, ck in enumerate(coeffs):
        if k > 0: uk = pmul(uk, u, deg)
        if ck != 0: r = padd(r, pscale(uk, ck))
    return r
def tsin(u, deg): return ppow_series(u, [Fr(0)] + [Fr((-1) ** ((k - 1) // 2), factorial(k)) if k % 2 else Fr(0) for k in range(1, deg + 1)], deg)
def texpm1(u, deg): return ppow_series(u, [Fr(0)] + [Fr(1, factorial(k)) for k in range(1, deg + 1)], deg)
E = [[Fr(1), Fr(0)], [Fr(-1, 2), Fr(1)], [Fr(-1, 2), Fr(-1)]]
P = [[Fr(2, 3), Fr(-1, 3), Fr(-1, 3)], [Fr(0), Fr(1, 2), Fr(-1, 2)]]  # = (E^T E)^{-1} E^T, see check_P()
def check_P():
    Em = sp.Matrix([[sp.Rational(c.numerator, c.denominator) for c in row] for row in E])
    Pm = sp.Matrix([[sp.Rational(c.numerator, c.denominator) for c in row] for row in P])
    return (Em.T * Em).inv() * Em.T == Pm
def lin(coefs, polys):
    r = {}
    for k, p in zip(coefs, polys): r = padd(r, pscale(p, k))
    return r
def N(X, deg):
    s, c = X[0:2], X[2:4]
    edges = []
    for i in range(3):
        rho = lin([E[i][0], E[i][1]], [s[0], c[0]]); eta = lin([E[i][0], E[i][1]], [s[1], c[1]])
        sn = tsin(eta, deg); edges.append((padd(rho, pscale(sn, -1)), padd(padd(eta, texpm1(rho, deg)), pscale(sn, -1))))
    out = []
    for comp in range(2):
        col = [edges[i][comp] for i in range(3)]
        out.append((lin(P[0], col), lin(P[1], col)))
    return [out[0][0], out[1][0], out[0][1], out[1][1]]
def F(X, deg, steps=6):
    for _ in range(steps): X = N(X, deg)
    return X
def var(i):
    m = [0] * NV; m[i] = 1; return {tuple(m): Fr(1)}
X0 = [var(i) for i in range(NV)]
def homog(p, k): return {m: c for m, c in p.items() if sum(m) == k}
x = sp.symbols('x1:5')
def to_sympy(p): return sp.expand(sum(sp.Rational(c.numerator, c.denominator) * sp.prod([xi ** e for xi, e in zip(x, m)]) for m, c in p.items()))
def jets(deg):
    """dict k -> list of 4 sympy homogeneous degree-k components of F (k=1..deg)"""
    Fx = F(X0, deg)
    return {k: [to_sympy(homog(Fx[i], k)) for i in range(NV)] for k in range(1, deg + 1)}
Bm = sp.Matrix([[1, sp.Rational(-1, 2)], [sp.Rational(-1, 2), 1]]); JQ = sp.Matrix([[1, -2], [2, -1]]) / sp.sqrt(3)
s = sp.Matrix(x[0:2]); c = sp.Matrix(x[2:4])
Qs = (s.T * Bm * s)[0]; Qc = (c.T * Bm * c)[0]; I = (s.T * Bm * c)[0]; Om = (s.T * Bm * JQ * c)[0]
