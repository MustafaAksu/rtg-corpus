"""Phase B-03 preparer check for RER-GEN-C08 and RER-GEN-C09 (SESSION; model rebuilt from its definition by b03_model, no jet file).
Exact part (sympy, jets to degree 7):
 E1 (C08 R1) Qs(F B_k(t,0)) - Qs(F B_k(-t,0)) = 5t^5/32 + O(t^6), the t^5 coefficient independent of kappa.
 E2 (C08 R1) det D_s(Qs(B_k(s)), Qs(F B_k(s))) at s=(t,0) = -t^5/64 + O(t^6).
 E3 (C08 R2 / C09 §4, jet level) with q the c-quadratic part of the cubic parent field and B its bilinear form, 2B(C_k(s), R_k(s)) with
    R_k = -(sqrt3 k/6) Q^2 s equals k^2 Q^4/18 (-r-2e, 2r-3e); its contraction with grad Q is -4Q, giving -(2k^2/9) Q^5.
    This is the degree-9 parent difference and degree-10 Qs difference between fixed ages n and m (times n-m); the other terms are O(10)/O(11)
    because the parent jets are even in c (checked in b03c) and the child difference is O(5).
Numerical part (mpmath, 60 digits; the untruncated sin/exp map with six reprojection steps per F; [NUM] grade, as in the sources):
 N1 (C09 §2) for ages n=1,2,3 the current-parent child offset (c_n(s) - C_k(s))/n approaches R_k(s): ratio -> 1 as t -> 0.
 N2 (C08 R2, C09 §4) for age pairs (1,0),(2,0),(2,1),(3,1): [s(F X_n)-s(F X_m)] / [(n-m) k^2 Q^4/18 (-r-2e,2r-3e)] -> 1 and
    [Qs(F X_n)-Qs(F X_m)] / [-(n-m) 2k^2/9 Q^5] -> 1, for kappa in {-2sqrt3/3, -1/2}, directions s=(t,0) and s=(t,0.4t), t = 2e-2, 1e-2, 5e-3.
    X_n(s) = F^n(B_k(s0)) with s0 solved so that the current parent is exactly s (Newton, 60 digits).
    PASS if every relative error (vector norm) is below 0.15 at the smallest t and shrinks with t.
 N3 negative control: the same ratios against the wrong coefficient 1/17 instead of 1/18 do not approach 1.
Exit 0 iff all hold. Runtime: about 20 s."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sympy as sp, mpmath as mp, b03_model as M
x = M.x; r, e, t, kap = sp.symbols('r e t kappa', real=True); s3 = sp.sqrt(3); ok = {}
F7 = [M.to_sympy(p) for p in M.F(M.X0, 7)]
Q = r**2 - r * e + e**2; sJ = sp.Matrix([r, e]); JQ = M.JQ; C = sp.expand(kap * Q * JQ * sJ)
def trunc_re(expr, deg):
    p = sp.Poly(sp.expand(expr), r, e); return sp.expand(sum(c * r**m[0] * e**m[1] for m, c in p.terms() if sum(m) <= deg))
def hom(expr, k):
    p = sp.Poly(sp.expand(expr), r, e); return sp.expand(sum(c * r**m[0] * e**m[1] for m, c in p.terms() if sum(m) == k))
def subst_trunc(poly4, C0, C1, deg, cmin=3):
    p = sp.Poly(poly4, *x); out = 0; pw0 = {0: sp.Integer(1)}; pw1 = {0: sp.Integer(1)}
    for (a, b, c, d), q in p.terms():
        if a + b + cmin * (c + d) > deg: continue
        for k in range(1, c + 1):
            if k not in pw0: pw0[k] = trunc_re(pw0[k - 1] * C0, deg)
        for k in range(1, d + 1):
            if k not in pw1: pw1[k] = trunc_re(pw1[k - 1] * C1, deg)
        out += q * r**a * e**b * trunc_re(pw0[c] * pw1[d], deg)
    return trunc_re(out, deg)
# E1, E2
FsB = [subst_trunc(F7[i], C[0], C[1], 7) for i in (0, 1)]
QsFB = sp.expand(FsB[0]**2 - FsB[0] * FsB[1] + FsB[1]**2)
d = sp.expand(QsFB.xreplace({r: t, e: 0}) - QsFB.xreplace({r: -t, e: 0}))
cd = {k: sp.expand(sp.Poly(d, t).coeff_monomial(t**k)) for k in range(8)}
ok['E1_5t5_over_32_kappa_independent'] = cd[5] == sp.Rational(5, 32) and all(cd[k] == 0 for k in range(5))
print('E1 coefficients t^5, t^6, t^7:', cd[5], '|', cd[6], '|', cd[7])
det = sp.expand(sp.Matrix([[sp.diff(Q, r), sp.diff(Q, e)], [sp.diff(QsFB, r), sp.diff(QsFB, e)]]).det())
dt = det.xreplace({r: t, e: 0})
ok['E2_det_minus_t5_over_64'] = sp.Poly(dt, t).coeff_monomial(t**5) == sp.Rational(-1, 64) and all(sp.Poly(dt, t).coeff_monomial(t**k) == 0 for k in range(5))
# E3
J3 = M.jets(3)[3]
G3s = sp.Matrix([J3[0], J3[1]])
u1, u2, v1, v2 = sp.symbols('u1 u2 v1 v2')
def c_quadratic_part(poly):  # terms of degree exactly 2 in (x3,x4)
    p = sp.Poly(poly, x[2], x[3]); return sp.expand(sum(c * x[2]**m[0] * x[3]**m[1] for m, c in p.terms() if sum(m) == 2))
G3s_cc = sp.Matrix([c_quadratic_part(G3s[i]) for i in range(2)])
def polar(i, U, V):  # bilinear form of the c-quadratic part: 1/2[q(U+V)-q(U)-q(V)]
    q = lambda W: G3s_cc[i].xreplace({x[0]: r, x[1]: e, x[2]: W[0], x[3]: W[1]})
    return sp.expand((q(U + V) - q(U) - q(V)) / 2)
Rk = sp.expand(-s3 * kap / 6 * Q**2 * sJ)
bil = 2 * sp.Matrix([polar(i, C, Rk) for i in range(2)])   # q(C+R) - q(C) = 2 B(C,R) + q(R), q(R) = O(11)
target = sp.expand(kap**2 * Q**4 / 18 * sp.Matrix([-r - 2 * e, 2 * r - 3 * e]))
ok['E3_bilinear_degree9_vector'] = sp.expand(bil - target) == sp.zeros(2, 1)
gradQ = sp.Matrix([sp.diff(Q, r), sp.diff(Q, e)])
ok['E3_contraction_minus_4Q'] = sp.expand((sp.Matrix([-r - 2 * e, 2 * r - 3 * e]).T * gradQ)[0] + 4 * Q) == 0
ok['E3_Qs_difference_coefficient'] = sp.expand((target.T * gradQ)[0] + sp.Rational(2, 9) * kap**2 * Q**5) == 0
# numerical part
mp.mp.dps = 60
E_ = [[mp.mpf(1), mp.mpf(0)], [mp.mpf(-1) / 2, mp.mpf(1)], [mp.mpf(-1) / 2, mp.mpf(-1)]]
P_ = [[mp.mpf(2) / 3, mp.mpf(-1) / 3, mp.mpf(-1) / 3], [mp.mpf(0), mp.mpf(1) / 2, mp.mpf(-1) / 2]]
def Te(rho, eta): return (rho - mp.sin(eta), eta + mp.expm1(rho) - mp.sin(eta))
def Nmap(X):
    s, c = X[0:2], X[2:4]; ed = [Te(E_[i][0] * s[0] + E_[i][1] * c[0], E_[i][0] * s[1] + E_[i][1] * c[1]) for i in range(3)]
    return [sum(P_[0][i] * ed[i][0] for i in range(3)), sum(P_[0][i] * ed[i][1] for i in range(3)), sum(P_[1][i] * ed[i][0] for i in range(3)), sum(P_[1][i] * ed[i][1] for i in range(3))]
def Fm(X, n=1):
    for _ in range(6 * n): X = Nmap(X)
    return X
sq3 = mp.sqrt(3)
def Qm(a, b): return a * a - a * b + b * b
def Bk(k, s0): q = Qm(*s0); return [s0[0], s0[1], k * q * (s0[0] - 2 * s0[1]) / sq3, k * q * (2 * s0[0] - s0[1]) / sq3]
def X_age(k, n, s):
    """state of age n whose current parent is exactly s: solve s(F^n B_k(s0)) = s by Newton"""
    s0 = [s[0], s[1]]
    for _ in range(40):
        g = Fm(Bk(k, s0), n)[0:2]; res = [g[0] - s[0], g[1] - s[1]]
        if max(abs(res[0]), abs(res[1])) < mp.mpf(10)**(-55): break
        h = mp.mpf(10)**(-20); Jm = mp.matrix(2, 2)
        for j in range(2):
            sp_ = list(s0); sp_[j] += h; gp = Fm(Bk(k, sp_), n)[0:2]
            for i in range(2): Jm[i, j] = (gp[i] - g[i]) / h
        dlt = mp.lu_solve(Jm, mp.matrix(res)); s0 = [s0[0] - dlt[0], s0[1] - dlt[1]]
    return Fm(Bk(k, s0), n)
kappas = {'-2sqrt3/3': -2 * sq3 / 3, '-1/2': mp.mpf(-1) / 2}
dirs = {'(t,0)': (1, 0), '(t,0.4t)': (1, mp.mpf('0.4'))}
ts = [mp.mpf('0.02'), mp.mpf('0.01'), mp.mpf('0.005')]
n1_ok, n2_ok, n3_bad = True, True, True
for kn, k in kappas.items():
    for dn, dv in dirs.items():
        rows = []
        for tt in ts:
            s = (tt * dv[0], tt * dv[1]); q = Qm(*s)
            Rk_num = [-sq3 * k / 6 * q * q * s[0], -sq3 * k / 6 * q * q * s[1]]
            Ck = Bk(k, s)[2:4]
            Xs = {n: X_age(k, n, s) for n in (0, 1, 2, 3)}
            relerr = lambda act, pred: mp.sqrt(sum((a - b)**2 for a, b in zip(act, pred))) / mp.sqrt(sum(b**2 for b in pred))
            rat1 = [relerr([(Xs[n][2 + i] - Ck[i]) / n for i in range(2)], Rk_num) for n in (1, 2, 3)]
            vec = [-s[0] - 2 * s[1], 2 * s[0] - 3 * s[1]]
            rat2, rat3, bad = [], [], []
            for (n, m) in ((1, 0), (2, 0), (2, 1), (3, 1)):
                FXn, FXm = Fm(Xs[n]), Fm(Xs[m])
                act = [FXn[i] - FXm[i] for i in range(2)]
                rat2.append(relerr(act, [(n - m) * k * k * q**4 / 18 * vec[i] for i in range(2)]))
                bad.append(relerr(act, [(n - m) * k * k * q**4 / 17 * vec[i] for i in range(2)]))
                rat3.append(abs((Qm(FXn[0], FXn[1]) - Qm(FXm[0], FXm[1])) / (-(n - m) * 2 * k * k / 9 * q**5) - 1))
            rows.append((tt, max(rat1), max(rat2), max(rat3), min(bad)))
        print('kappa=%s dir=%s' % (kn, dn))
        for tt, a, b, c, bd in rows: print('   t=%s  relative error: N1 %.3e  N2 parent %.3e  N2 Qs %.3e   (control 1/17: min %.3e)' % (mp.nstr(tt, 4), a, b, c, bd))
        n1_ok &= rows[-1][1] < 0.15 and rows[-1][1] < rows[0][1]
        n2_ok &= rows[-1][2] < 0.15 and rows[-1][3] < 0.15 and rows[-1][2] < rows[0][2] and rows[-1][3] < rows[0][3]
        n3_bad &= rows[-1][4] > 0.04
ok['N1_child_offset_linear_in_age'] = n1_ok; ok['N2_cross_age_parent_and_Qs_differences'] = n2_ok; ok['N3_negative_control_1_over_17'] = n3_bad
print(ok); sys.exit(0 if all(ok.values()) else 1)
