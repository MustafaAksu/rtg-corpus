"""Phase B-03 preparer check for RER-GEN-C05 (SESSION; exact arithmetic; model rebuilt from its definition by b03_model, no jet file).
Two independent routes to the degree-17 rank certificate of H3 = (Qs, Qs o F, Qs o F^2, Qs o F^3):
 R1 (RANK §3 reduction): with L_G f = Df.G, A4=L_{G3}Qs, A5=L_{G4}Qs, B6=L_{G3}A4, B7=L_{G4}A4+L_{G3}A5, C8=L_{G3}B6, C9=L_{G4}B6+L_{G3}B7;
    at X0=(1,0,0,1): det[grad Qs; grad A4; grad B6; grad C8] = 0 (degree 16 vanishes) and the degree-17 coefficient
    det[.,A5,.,.]+det[.,.,B7,.]+det[.,.,.,C9] = 1724491/248832 - 337264345/5971968 + 201466337/3981312 = 12645889/11943936.
 R2 (direct): compose the exact truncated map 18 primitive steps, build the 4x4 Jacobian of H3 symbolically, evaluate on the ray t*X0
    and read the t^16 and t^17 coefficients of its determinant: 0 and 12645889/11943936. Also the second witness (1,1,1,0): -57718145/11943936.
 R3 (RANK §2 F1 witnesses, source only, not in the RER record): Qs(F(t(1,0,0,1)))-Qs(F(t(1,0,0,0))) = t^4/2 + O(t^5);
    Omega(F(t(2,0,0,1/2)))-Omega(F(t(1,0,0,1))) = -sqrt3/2 t^4 + O(t^5), with equal inputs.
 R4 negative control: 12645889/11943937 is rejected.
Exit 0 iff all executed checks hold. Runtime: about 45 s; with --fast the direct route R2 (about 35 s) is skipped and reported SKIPPED."""
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sympy as sp, b03_model as M
x = M.x; t = sp.symbols('t', positive=True); ok = {}
J = M.jets(4); G3, G4 = sp.Matrix(J[3]), sp.Matrix(J[4])
Qs = M.Qs
def L(G, f): return sp.expand(sum(sp.diff(f, xi) * G[i] for i, xi in enumerate(x)))
A4, A5 = L(G3, Qs), L(G4, Qs); B6 = L(G3, A4); B7 = sp.expand(L(G4, A4) + L(G3, A5)); C8 = L(G3, B6); C9 = sp.expand(L(G4, B6) + L(G3, B7))
def grad(f): return [sp.diff(f, xi) for xi in x]
def det_at(rows, X0):
    sub = dict(zip(x, X0)); return sp.Matrix([[g.xreplace(sub) for g in grad(f)] for f in rows]).det()
X0 = (1, 0, 0, 1)
d16 = det_at([Qs, A4, B6, C8], X0)
parts = [det_at([Qs, A5, B6, C8], X0), det_at([Qs, A4, B7, C8], X0), det_at([Qs, A4, B6, C9], X0)]
ok['R1_degree16_vanishes'] = d16 == 0
ok['R1_three_parts'] = parts == [sp.Rational(1724491, 248832), sp.Rational(-337264345, 5971968), sp.Rational(201466337, 3981312)]
ok['R1_degree17_sum'] = sum(parts) == sp.Rational(12645889, 11943936)
print('R1 parts', parts, 'sum', sum(parts))
# R2 direct
FAST = '--fast' in sys.argv
if not FAST:
    t0 = time.time()
    H = [M.X0]
    for k in range(3): H.append(M.F(H[-1], 9))   # F^0..F^3 applied to the identity: 18 primitive steps, exact to degree 9
    print('18-step composition to degree 9 in %.1fs' % (time.time() - t0))
    def Qs_of(Xp):  # Qs of a polynomial 4-vector, truncated at degree 10
        s0, s1 = Xp[0], Xp[1]
        return M.padd(M.padd(M.pmul(s0, s0, 10), M.pscale(M.pmul(s0, s1, 10), -1)), M.pmul(s1, s1, 10))
    rows = [M.to_sympy(Qs_of(Xp)) for Xp in H]
    def direct_det(X0):
        Jm = sp.Matrix([[sp.diff(f, xi).xreplace(dict(zip(x, [t * v for v in X0]))) for xi in x] for f in rows])
        d = sp.Poly(sp.expand(Jm.det()), t)
        return {k[0]: c for k, c in d.terms()}
    D1 = direct_det((1, 0, 0, 1)); D2 = direct_det((1, 1, 1, 0))
    ok['R2_direct_t16_zero_t17_value'] = D1.get(16, 0) == 0 and D1.get(17) == sp.Rational(12645889, 11943936) and all(D1.get(k, 0) == 0 for k in range(0, 16))
    ok['R2_second_witness'] = D2.get(16, 0) == 0 and D2.get(17) == sp.Rational(-57718145, 11943936)
    print('direct det coefficients (1,0,0,1): t^16 =', D1.get(16, 0), ' t^17 =', D1.get(17), '; (1,1,1,0): t^17 =', D2.get(17))
else:
    print('R2 direct route SKIPPED (--fast)')
# R3
F4 = sp.Matrix([M.to_sympy(p) for p in M.F(M.X0, 5)])
def ray(X0): return dict(zip(x, [t * v for v in X0]))
dq = sp.expand(Qs.xreplace(dict(zip(x, F4))).xreplace(ray((1, 0, 0, 1))) - Qs.xreplace(dict(zip(x, F4))).xreplace(ray((1, 0, 0, 0))))
dom = sp.expand(M.Om.xreplace(dict(zip(x, F4))).xreplace(ray((2, 0, 0, sp.Rational(1, 2)))) - M.Om.xreplace(dict(zip(x, F4))).xreplace(ray((1, 0, 0, 1))))
ok['R3_F1_Qs_witness'] = sp.Poly(dq, t).coeff_monomial(t**4) == sp.Rational(1, 2) and all(sp.Poly(dq, t).coeff_monomial(t**k) == 0 for k in range(4))
ok['R3_F1_Omega_witness'] = sp.expand(sp.Poly(dom, t).coeff_monomial(t**4) + sp.sqrt(3) / 2) == 0 and all(sp.Poly(dom, t).coeff_monomial(t**k) == 0 for k in range(4))
ok['R3_F1_equal_inputs'] = Qs.xreplace(ray((1, 0, 0, 1))) == Qs.xreplace(ray((1, 0, 0, 0))) and sp.expand(M.Om.xreplace(ray((2, 0, 0, sp.Rational(1, 2)))) - M.Om.xreplace(ray((1, 0, 0, 1)))) == 0
ok['R4_negative_control'] = sum(parts) != sp.Rational(12645889, 11943937)
print(ok); sys.exit(0 if all(ok.values()) else 1)
