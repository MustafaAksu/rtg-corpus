"""Phase B-01 arithmetic check (preparer SESSION). Exact sympy. Inputs are the printed Genesis v2.8.9 coefficients only.
Checks: (1) 6*conj(lam)*n_T = mu_6 (§6.3c C1); (2) §6.3c(c) Lemma-S parameters at mu=mu_6: c=-mu/3, beta=2i mu/3;
(3) comparison with the raw projected-K3 six-step cubic (c_0, beta_*) of §6.3a(d); (4) §6.3b gamma=1 calibration c_1=c_0, beta_1=beta_*.
Exit 0 iff all asserted identities hold; prints the differences."""
import sys, sympy as sp
I, s3 = sp.I, sp.sqrt(3)
lam = sp.Rational(1,2) + I*s3/2
nT = sp.Rational(1,8) - 7*I*s3/72
mu6 = -sp.Rational(1,2) - 2*I*s3/3
c0, bs = sp.Rational(1,6) + I*s3/9, 2*s3/9
g = sp.symbols('g', real=True); n = g**2 - g + 1
cg = (3*g**3 - 7*g**2 + 5*g - 2)/(6*(g-2)*n) + I*s3*(2*g**2 - 3*g + 2)/(9*n)
bg = 2*s3*(2*g**2 - 3*g + 2)/(9*n) - I*2*(g-1)**3/(3*(g-2)*n)
ok = []
ok.append(sp.simplify(6*sp.conjugate(lam)*nT - mu6) == 0)
ct, bt = -mu6/3, 2*I*mu6/3
print('transported (c, beta) =', sp.nsimplify(sp.expand(ct)), ',', sp.nsimplify(sp.expand(bt)))
print('raw         (c, beta) =', c0, ',', bs)
print('difference  c: ', sp.simplify(ct - c0), '  beta:', sp.simplify(bt - bs))
ok.append(sp.simplify(ct - c0) != 0 and sp.simplify(bt - bs) != 0)
ok.append(sp.simplify(cg.subs(g,1) - c0) == 0 and sp.simplify(bg.subs(g,1) - bs) == 0)
ok.append(sp.simplify(ct - I*bt) != 0 and bt != 0)   # adopted Lemma S branch at mu6
print('checks', ok); sys.exit(0 if all(ok) else 1)
