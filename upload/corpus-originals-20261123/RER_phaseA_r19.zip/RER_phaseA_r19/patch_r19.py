"""Phase A r18 -> r19: narrow catalog step (receiving decision of 21 Oct 2026 on OWNER_SECTION_CHECK_r1: ACCEPT SCOPED; r19 authorized as in its §6).
Source unchanged (RER r4.13). r18 outputs kept as history. Catalog delta only:
- Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4: evidence BYTE_VERIFIED — the files are held in sources_available, hashed here (inputs/source_custody_r19.json),
  with the owner section check (inputs/owner_section_check_r1/) and the receiver's review pinned; r17-r18 OWNER_REPORTED state kept as history.
- DYAD6418 and the two RECOG rows: UNCHANGED_VERIFIED (cited blocks byte-identical in the new editions; RECOG on the two checked legs v0.3.20 -> v0.3.21 ->
  v0.3.22, receiver also compared v0.3.20 -> v0.3.22 directly). Pins unchanged.
- RRF083: stays RECHECK_IN_PHASE_B / HISTORICAL; receiver_section_check field records §2.3 IDENTICAL, §2.4b CHANGED (receiver: consumer-compatible at the RER
  use point; not whole-row equality). RRF082: reason corrected (OSC-N2: v0.8.2 -> v0.8.3 changed both §2.4b and §4.2; the adoption-record statement
  "only §2.4c changed" is kept as an earlier report); stays RECHECK_IN_PHASE_B / HISTORICAL, authentication RECEIVER_BYTE_VERIFIED (the recovered v0.8.2 and
  v6.4.13 files are on the receiving side only; not held here). RRF08_ADOPTED rows: v0.8 still not recovered. DYAD6413: receiver direct v6.4.13 -> v6.4.19
  comparison recorded as RECEIVER-REPORTED.
- Gates re-based: A23, A26, A29, A32; A24/A25/A28 re-based on r18; new file/input controls. Expected statuses 31/2/52/6; authentication 60/6/24/1 unchanged.
Args: TARGET_DIR OWNER_DIR (holds DYAD6419_raw.txt, RECOG0322_raw.txt, RRF084_raw.txt) SECTION_CHECK_DIR RECEIVER_REVIEW_MD"""
import sys, os, json, shutil, hashlib
D, OWN, SC, RV = sys.argv[1:5]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
D19 = '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'; D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
G22 = '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'
F84 = '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'; H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
assert not any(x == '__pycache__' for _, ds, _ in os.walk(D) for x in ds)
os.remove(os.path.join(D, 'SHA256SUMS.txt'))
H = os.path.join(D, 'inputs/phaseA_r18_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r18.txt'))
for f in ('RER_PHASE_A_R18_CHANGE_RECORD_20261021.md', 'patch_r18.py'): os.remove(os.path.join(D, f))
# owner files into sources_available
NEW = {'DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md': ('DYAD6419_raw.txt', D19, '6.4.19'), 'RECOG0322__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md': ('RECOG0322_raw.txt', G22, '0.3.22'),
       'RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md': ('RRF084_raw.txt', F84, '0.8.4')}
cust = {}
for fn, (src, h, v) in NEW.items():
    b = open(os.path.join(OWN, src), 'rb').read(); assert sha(b) == h, fn
    open(os.path.join(D, 'sources_available', fn), 'wb').write(b)
    cust[fn] = {'key': fn.split('__')[0], 'sha256': h, 'version': v, 'bytes': len(b),
                'container': ('project folder copy ' + fn.split('__', 1)[1] + ' read through the project tool in the preparer session, 21 Oct 2026' + ('; the text arrived inline and was written back from the session record' if fn.startswith('RRF084') else '; written to a local file by the tool') + '; hash equals the owner record and the receiver\'s identity receipt (r18 review §4; owner-section review §2)')}
open(os.path.join(D, 'inputs/source_custody_r19.json'), 'w').write(dump({'_about': 'Phase A r19 custody for the three current owner files.', 'container_chain_status': 'PREPARER_DECLARED: hashes computed here equal the owner records and the receiver\'s independently computed identities (21 Oct 2026); the project-folder provenance is the preparer\'s declaration.', 'files': cust}))
# owner section check package and the receiver review
scd = os.path.join(D, 'inputs/owner_section_check_r1'); os.makedirs(scd)
for f in ('owner_section_check.py', 'OWNER_SECTION_CHECK_NOTE_20261021.md', 'out/compare_output.txt', 'out/owner_section_check.json', 'out/changed_blocks.diff', 'out/negcontrol_output.txt'):
    shutil.copyfile(os.path.join(SC, f), os.path.join(scd, os.path.basename(f)))
shutil.copyfile(RV, os.path.join(D, 'inputs/receiving_review_owner_section_20261021.md'))
RVH = sha(open(RV, 'rb').read())

# ---- ledger
p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
assert (KV['Dyadic'], KV['RECOG'], KV['RRF']) == ('6.4.19', '0.3.22', '0.8.4')
KV['_catalog_checked'] = '2026-10-21 (Phase A r19, preparer)'
SA = KV['_source_authority']
SA['Dyadic'] = ('owner release record claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md and release verification record; v6.4.19 bytes held and hashed here (sources_available, inputs/source_custody_r19.json), '
                'hash equal to the owner record and to the receiver\'s identity receipt; section check inputs/owner_section_check_r1/ (receiver ACCEPT SCOPED, 21 Oct 2026). Superseded v6.4.18: bytes held and hashed here '
                '(custody r14), receiver-confirmed. Earlier v6.4.17: bytes held (custody r9), receiver-confirmed.')
SA['RECOG'] = ('owner release record claude/RECOG_v0_3_22_RELEASE_RECORD.md; v0.3.22 bytes held and hashed here (sources_available, inputs/source_custody_r19.json), hash equal to the owner record and to the '
               'receiver\'s identity receipt; section check inputs/owner_section_check_r1/ (receiver ACCEPT SCOPED, 21 Oct 2026). Superseded v0.3.21: bytes held (custody r13), receiver-confirmed. Frozen v0.3.20: file '
               'byte-verified here; frozen status owner-reported (v0.3.21 release record; RECOG G3 notice names the freeze record).')
SA['RRF'] = ('adoption record claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md; v0.8.4 bytes held and hashed here (sources_available, inputs/source_custody_r19.json), hash equal to the adoption '
             'record and to the receiver\'s identity receipt; section check inputs/owner_section_check_r1/ (receiver ACCEPT SCOPED, 21 Oct 2026). Superseded v0.8.3: adoption record; receiver-hashed; bytes held here since '
             'Phase A r15 (custody r15).')
open(p, 'w').write(dump(KV))

# ---- catalog
p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p)); OC = CS['owner_current']
SCN = 'inputs/owner_section_check_r1/ (OWNER_SECTION_CHECK_r1.zip 231201a5…7753; receiver review ' + RVH[:8] + '…' + RVH[-4:] + ', ACCEPT SCOPED, 21 Oct 2026)'
dy = OC['Dyadic']; assert dy['version'] == '6.4.19' and dy['sha256'] == D19 and dy['evidence'] == 'OWNER_REPORTED'
dy['history']['phaseA_r17_r18'] = {'version': '6.4.19', 'sha256': D19, 'evidence': 'OWNER_REPORTED', 'note': dy['note']}
dy['evidence'] = 'BYTE_VERIFIED'
dy['note'] = ('adopted 20 Oct 2026 (release record claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md; external release verification per claude/RTG_DYADIC_v6_4_19_RELEASE_VERIFICATION_RECORD.md). Phase A r19: bytes held in '
              'sources_available and hashed here (inputs/source_custody_r19.json), read from the project folder; hash equals the owner record and the receiver\'s identity receipt. Section check ' + SCN + ': v6.4.18 -> v6.4.19 '
              '§2 OPEN 19, §2 OPEN 20, §6.15, §6.16, §6.17 IDENTICAL (OPEN 21 also identical); §6.14 CHANGED (new L-PHASE row A result DYAD-THM-LPHASE-ROWA-REMAINDER, not cited by RER). Per the release record: RIDs 132 -> 136, '
              'no other result, grade or OPEN status changed; OPEN 20 PARTIAL, B-an and B-6 OPEN. Owner proof records not independently reviewed here.')
rc = OC['RECOG']; assert rc['version'] == '0.3.22' and rc['sha256'] == G22 and rc['evidence'] == 'OWNER_REPORTED'
rc['history']['phaseA_r17_r18'] = {'version': '0.3.22', 'sha256': G22, 'evidence': 'OWNER_REPORTED', 'note': rc['note']}
rc['evidence'] = 'BYTE_VERIFIED'
rc['note'] = ('adopted 20 Oct 2026 (release record claude/RECOG_v0_3_22_RELEASE_RECORD.md). Phase A r19: bytes held in sources_available and hashed here (inputs/source_custody_r19.json), read from the project folder; hash equals '
              'the owner record and the receiver\'s identity receipt. Section check ' + SCN + ': v0.3.21 -> v0.3.22 §6.6a and §6.16g IDENTICAL; with the pinned v0.3.20 -> v0.3.21 leg (both IDENTICAL) the two cited blocks are '
              'byte-identical from the frozen v0.3.20 pin through v0.3.22 (two checked legs); the receiver also compared v0.3.20 -> v0.3.22 directly (RECEIVER-REPORTED, identical). Per the release record: eight scientific RIDs '
              'and four artifact IDs added, none lost; every pre-existing RID keeps its statement and grade; not frozen.')
rf = OC['RRF']; assert rf['version'] == '0.8.4' and rf['sha256'] == F84 and rf['evidence'] == 'OWNER_REPORTED'
rf['history']['phaseA_r17_r18'] = {'version': '0.8.4', 'sha256': F84, 'evidence': 'OWNER_REPORTED', 'note': rf['note']}
rf['evidence'] = 'BYTE_VERIFIED'
rf['note'] = ('adopted 20 Oct 2026 as the RRF working representation standard (claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md). Phase A r19: bytes held in sources_available and hashed here '
              '(inputs/source_custody_r19.json), read from the project folder; hash equals the adoption record and the receiver\'s identity receipt. Section check ' + SCN + ': v0.8.3 -> v0.8.4, 22 blocks: 9 IDENTICAL '
              '(§0.1, §0.3, §2.3, §2.4a, §4.2, §4.3, §6.4, §8.1, §10.1), 11 CHANGED (front matter, §0 lead, §0.2, §2.4, §2.4b, §2.4c, §4.2a, §6.2, §6.3, §8, §9), 2 NEW (§6.2a, §10.4); exact diffs in the section-check '
              'package. Receiver reading (21 Oct 2026): the changes reflect DYAD v6.4.18 C∞ existence (B-∞ CLOSED, B-an/B-6 OPEN) and the RECOG same-space W3; §2.4b changed but consumer-compatible at the RER use point; '
              '§6.3 W3 wording equals RECOG §6.16g and RER r4.13; different-space transport an OPEN RRF extension; §6.2a a conditional class-C model contract, not a replacement for G2 §5b. No RRF OPEN-A/B/E closed.')
K = CS['keys']
k = K['DYAD6418']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED'
k['rule'] = 'UNCHANGED_VERIFIED'
k['reason'] += (' Phase A r19: v6.4.19 bytes held and hashed here; the cited §2 OPEN 20 and §6.17 are byte-identical in v6.4.19 (section check ' + SCN + '). Currency UNCHANGED_VERIFIED; the RER pin stays on v6.4.18.')
k['receiver_section_check'] = k.get('receiver_section_check', '') + ' RECEIVER-REPORTED (21 Oct 2026): OWNER_SECTION_CHECK_r1 replayed independently; Dyadic cited blocks v6.4.18 -> v6.4.19 IDENTICAL confirmed; ACCEPT SCOPED.'
k = K['DYAD6413']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r19: v6.4.19 bytes held here; v6.4.18 -> v6.4.19 leaves §2 OPEN 19/20 and §§6.15–6.17 byte-identical. The v6.4.13 file is not held here (the receiver recovered it from TRIAD_RER_RECEIVING_REVIEW_20261019.zip and '
                'compared v6.4.13 -> v6.4.19 directly: OPEN 19, §6.15, §6.16 identical; OPEN 20 and §6.17 changed as wholes with the Lemma F / F1–F3 paragraphs retained — RECEIVER-REPORTED, not replayed here). Rule and pin unchanged.')
k = K['RECOG']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED'
k['rule'] = 'UNCHANGED_VERIFIED'
k['reason'] += (' Phase A r19: v0.3.22 bytes held and hashed here; §6.6a and §6.16g are byte-identical v0.3.21 -> v0.3.22 (section check ' + SCN + '), so with the pinned v0.3.20 -> v0.3.21 leg the cited blocks are unchanged from the frozen '
                'pin through v0.3.22 (two legs; receiver also compared v0.3.20 -> v0.3.22 directly). Currency UNCHANGED_VERIFIED; RER pins stay on v0.3.20; the per-reference audit of G9/0 and G9/1 stays pending.')
k['receiver_section_check'] += ' RECEIVER-REPORTED (21 Oct 2026): OWNER_SECTION_CHECK_r1 replayed independently; §6.6a and §6.16g IDENTICAL v0.3.21 -> v0.3.22 and directly v0.3.20 -> v0.3.22; ACCEPT SCOPED.'
k = K['RRF083']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r19: v0.8.4 bytes held and hashed here; section check ' + SCN + ': the cited §2.3 is byte-identical v0.8.3 -> v0.8.4, the cited §2.4b is CHANGED (B-∞ existence CLOSED by DYAD v6.4.18 recorded; '
                'override paragraph appended). Rule and pin unchanged; whole-row equality is not inferred from the unchanged subsection.')
k['receiver_section_check'] = (k.get('receiver_section_check', '') + ' RECEIVER-REPORTED (21 Oct 2026): §2.3 IDENTICAL, §2.4b CHANGED but consumer-compatible at the RER use point (RER r4.13 DYAD6418 import and non-transfer clauses '
                               'already express the distinctions); keep HISTORICAL / RECHECK_IN_PHASE_B; not whole-row equality.').strip()
k = K['RRF082']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r19 (OSC-N2 correction): the adoption-record statement above ("only §2.4c changed") is kept as an earlier report; the receiver compared the recovered v0.8.2 file with v0.8.3 directly and found both cited '
                'sections changed — §2.4b (smooth clock bridge, flat uniqueness, class-wise existence equivalence added) and §4.2 (N9 receipt added); §4.2 is identical only on the v0.8.3 -> v0.8.4 leg. The v0.8.2 file is not held '
                'here (RECEIVER-REPORTED). Old-to-current equality is not asserted; rule and pin unchanged.')
k['receiver_section_check'] += ' RECEIVER-REPORTED (21 Oct 2026, direct v0.8.2 -> v0.8.3): §2.4b CHANGED and §4.2 CHANGED; §4.2 identical only v0.8.3 -> v0.8.4.'
k = K['RRF08_ADOPTED']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += '; Phase A r19: v0.8.4 bytes held here; the v0.8 original is still not recovered (receiver search, 21 Oct 2026), so the v0.8 line pins and the v0.8 -> v0.8.3 leg stay unverified; the current file hash does not verify an old pin'
CS['_about'] += (' Phase A r19 (21 Oct): Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 BYTE_VERIFIED (files held, custody r19, owner section check receiver-accepted); DYAD6418 and RECOG rows UNCHANGED_VERIFIED; RRF083/RRF082 '
                 'stay RECHECK_IN_PHASE_B with section receipts (RRF082 reason corrected, OSC-N2); no pin changed.')
open(p, 'w').write(dump(CS))

# ---- builder
rp('build_phaseA.py', [
 ('"""RER Phase A r18 builder (deterministic; r18 runs on RER r4.13', '"""RER Phase A r19 builder (deterministic; r19 is a catalog step on the unchanged RER r4.13: Dyadic v6.4.19 / RECOG v0.3.22 / RRF v0.8.4 BYTE_VERIFIED; r18 runs on RER r4.13'),
 ("'RER-REGISTRY-PHASEA/18'", "'RER-REGISTRY-PHASEA/19'"), ("'RER-SOURCE-CURRENCY/18'", "'RER-SOURCE-CURRENCY/19'"), ("'RER-BLOCKED-SOURCES/18'", "'RER-BLOCKED-SOURCES/19'"),
 ("'# RER r4.13 — source-currency matrix (Phase A r18, noncanonical)'", "'# RER r4.13 — source-currency matrix (Phase A r19, noncanonical)'"),
 ("'# RER r4.13 — blocked-source register (Phase A r18, noncanonical)'", "'# RER r4.13 — blocked-source register (Phase A r19, noncanonical)'"),
 ("a byte-evidence update is a separate catalog delta and is not inferred here. G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.']}",
  "a byte-evidence update is a separate catalog delta and is not inferred here. G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.',\n"
  "                          'Phase A r19 (21 Oct 2026): catalog step on the unchanged RER r4.13 (r18 ACCEPT SCOPED). Dyadic v6.4.19 (40c9e63f…6ec9), RECOG v0.3.22 (0dcce9e4…bcd9) and RRF v0.8.4 (2fb0a0fe…afce) are BYTE_VERIFIED: files held and hashed here (custody r19), hashes equal to the owner records and the receiver\\'s identity receipts; the owner section check OWNER_SECTION_CHECK_r1 (231201a5…7753; receiver ACCEPT SCOPED, review " + RVH[:8] + "…" + RVH[-4:] + ") found the cited Dyadic blocks (§2 OPEN 19/20, §§6.15–6.17) and RECOG blocks (§6.6a, §6.16g) byte-identical in the new editions and, for RRF v0.8.3 -> v0.8.4, 9 blocks identical, 11 changed, 2 new (§2.3 identical, §2.4b changed). DYAD6418 and the two RECOG rows UNCHANGED_VERIFIED (pins v6.4.18 / v0.3.20 unchanged); RRF083 and RRF082 stay RECHECK_IN_PHASE_B with section receipts (RRF082 reason corrected: v0.8.2 -> v0.8.3 changed both §2.4b and §4.2 — RECEIVER-REPORTED); the 12 RRF08_ADOPTED rows keep their v0.8 source limit (v0.8 not recovered). The recovered v6.4.13 and v0.8.2 files are held on the receiving side only. No pin, grade, OPEN item, gap audit or sync disposition changed; G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT. Note for later consumer-source maintenance (receiver): RER G10 still carries the dated \"v0.8.3 … governs\" wording while G9 records the v0.8.4 adoption — not a contradiction in the scoped records.']}"),
])

# ---- checker
C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    assert t.count(a) == 1, a[:60]; i = t.index(a); j = t.index(b, i); return t[:i] + new + t[j:]
def one(t, a, b):
    assert t.count(a) == 1, a[:80]; return t.replace(a, b)
NEW_A23 = r'''    D19 = '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'
    hs = dy.get('history', {})
    r13 = [x for x in dyrows if x['key'] == 'DYAD6413']; r18 = [x for x in dyrows if x['key'] == 'DYAD6418']
    FN19 = 'DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md'; P19 = os.path.join(HERE, 'sources_available', FN19)
    f19_ok = FN19 not in withhold and os.path.isfile(P19) and sha(open(P19, 'rb').read()) == D19
    C19 = json.loads(ri('inputs/source_custody_r19.json')); c19 = C19.get('files', {}).get(FN19, {})
    sc19 = ri('inputs/owner_section_check_r1/compare_output.txt').decode('utf-8')
    dy_sc = sc19[sc19.index('== Dyadic'):sc19.index('== RECOG')] if '== Dyadic' in sc19 and '== RECOG' in sc19 else ''
    dy_sc_ok = (f'v6.4.18 {D18} MATCH' in dy_sc and f'v6.4.19 {D19} MATCH' in dy_sc and all(re.search(r'^  ' + re.escape(s) + r' +v6\.4\.18 lines \S+ +v6\.4\.19 lines \S+ +IDENTICAL', dy_sc, re.M) for s in ('§2 OPEN 19', '§2 OPEN 20', '§6.15', '§6.16', '§6.17'))
                and re.search(r'^  §6\.14 \(context\) +v6\.4\.18 lines \S+ +v6\.4\.19 lines \S+ +CHANGED', dy_sc, re.M) and 'inside listed blocks: 1' in dy_sc)
    dy_ok = (dy['version'] == '6.4.19' and dy['sha256'] == D19 and dy['evidence'] == 'BYTE_VERIFIED' and D19 in avail and D18 in avail and D17 in avail and f18_ok and f19_ok
             and c19.get('key') == 'DYAD6419' and c19.get('sha256') == D19 and bool(c19.get('container')) and C19.get('container_chain_status', '').startswith('PREPARER_DECLARED') and dy_sc_ok
             and 'inputs/owner_section_check_r1/' in dy.get('note', '') and 'receiver' in dy.get('note', '') and 'claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md' in dy.get('note', '')
             and f14.get('key') == 'DYAD6418' and f14.get('sha256') == D18 and bool(f14.get('container')) and C14.get('container_chain_status', '').startswith('PREPARER_DECLARED') and s18_ok
             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok
             and hs.get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED' and hs.get('phaseA_r9_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r9_r11'].get('sha256') == D17
             and hs.get('phaseA_r12_r13', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12_r13'].get('sha256') == D18 and hs.get('phaseA_r14_r16', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r14_r16'].get('sha256') == D18
             and hs.get('phaseA_r17_r18', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r17_r18'].get('sha256') == D19 and hs['phaseA_r17_r18'].get('version') == '6.4.19'
             and dy.get('superseded', {}).get('version') == '6.4.18' and dy['superseded'].get('sha256') == D18 and dy['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and len(dyrows) == 2 and len(r13) == 1 and len(r18) == 1
             and all(x['cited_version'] == '6.4.13' and x['cited_sha256'] == '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED'
                     and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' and x['verified_current_hash'] == D19
                     and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['current_owner_version'] == '6.4.19' and 'RECEIVER-REPORTED, not replayed here' in x['currency_reason'] for x in r13)
             and all(x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' and x['row_kind'] == 'RECORD_IMPORT' and x['n'] == 3 and x['cited_version'] == '6.4.18' and x['cited_sha256'] == D18
                     and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['available_file'] == 'sources_available/' + FN18
                     and x['currency'] == 'UNCHANGED_VERIFIED' and x['status'] == 'VERIFIED' and x['verified_current_hash'] == D19 and x['current_owner_evidence'] == 'BYTE_VERIFIED'
                     and x['current_owner_version'] == '6.4.19' and 'Phase A r19' in x['currency_reason'] and 'RECEIVER-REPORTED (21 Oct 2026)' in x.get('receiver_section_check', '') for x in r18))
    g('A23 Dyadic v6.4.19 byte-verified (file, custody r19, section check: cited blocks identical, §6.14 changed); v6.4.18/v6.4.17 identities and r8-r18 history kept; DYAD6413 pin v6.4.13 RECHECK (receiver direct comparison recorded); DYAD6418 pin v6.4.18 UNCHANGED_VERIFIED', dy_ok, f'{len(dyrows)} Dyadic rows')
'''
t = cut(t, "    D19 = '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9'\n    hs = dy.get('history', {})", "    sm = reg['source_markdown']", NEW_A23)
# A24: add r18 record
t = one(t, "    H16 = 'inputs/phaseA_r16_outputs/'; o16 = ri(H16 + 'check_phaseA_output_r16.txt').decode('utf-8'); H17 = 'inputs/phaseA_r17_outputs/'; o17 = ri(H17 + 'check_phaseA_output_r17.txt').decode('utf-8')",
        "    H16 = 'inputs/phaseA_r16_outputs/'; o16 = ri(H16 + 'check_phaseA_output_r16.txt').decode('utf-8'); H17 = 'inputs/phaseA_r17_outputs/'; o17 = ri(H17 + 'check_phaseA_output_r17.txt').decode('utf-8')\n    H18 = 'inputs/phaseA_r18_outputs/'; o18 = ri(H18 + 'check_phaseA_output_r18.txt').decode('utf-8')")
t = one(t, "and '32/32 gates PASS' in o17 and 'BAD' not in o13 + o15 + o16 + o17", "and '32/32 gates PASS' in o17 and '34/34 gates PASS' in o18 and 'BAD' not in o13 + o15 + o16 + o17 + o18")
t = one(t, "r13, r15, r16 and r17 checker records kept', src_ok)", "r13, r15, r16, r17 and r18 checker records kept', src_ok)")
# A25: registry identical to r18 except schema
NEW_A25 = r'''    g18 = json.loads(B.rd(H18 + 'RER_REGISTRY_v0_2_r4_13_PHASEA.json'))
    strip = lambda o: {k: v for k, v in o.items() if k != 'schema'}
    g('A25 r18 registry equality: source unchanged, registry identical to r18 apart from the schema label (records, gap entries, source table, legacy snapshot)', strip(reg) == strip(g18) and g18['schema'] == 'RER-REGISTRY-PHASEA/18' and reg['schema'] == 'RER-REGISTRY-PHASEA/19' and len(reg['records']) == 20)
'''
t = cut(t, "    g17 = json.loads(B.rd(H17 + 'RER_REGISTRY_v0_2_r4_11_PHASEA.json'))", "    rc = oc['RECOG'];", NEW_A25)
NEW_A26 = r'''    rc = oc['RECOG']; G22 = '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9'; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
    G1R = '5c00f66dae7d4de6ccd4a04d642a23edfc861bbd6bd55e432513747fbd679b55'
    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']
    FN21 = 'RECOG0321__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md'; P21 = os.path.join(HERE, 'sources_available', FN21)
    file_ok = FN21 not in withhold and os.path.isfile(P21) and sha(open(P21, 'rb').read()) == G21
    FN22 = 'RECOG0322__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md'; P22 = os.path.join(HERE, 'sources_available', FN22)
    f22_ok = FN22 not in withhold and os.path.isfile(P22) and sha(open(P22, 'rb').read()) == G22
    c22 = C19.get('files', {}).get(FN22, {})
    C13 = json.loads(ri('inputs/source_custody_r13.json')); f13 = C13.get('files', {}).get(FN21, {})
    sc13 = ri('inputs/recog_v0_3_21_section_check/compare_output.txt').decode('utf-8')
    sc13_ok = (f'v0.3.20 {G20} MATCH' in sc13 and f'v0.3.21 {G21} MATCH' in sc13 and sc13.count('IDENTICAL') == 2 and 'DIFFERENT' not in sc13
               and 'hunks inside cited blocks: 0' in sc13 and 'RESULT: PASS' in sc13)
    rc_sc = sc19[sc19.index('== RECOG'):sc19.index('== RRF')] if '== RECOG' in sc19 and '== RRF' in sc19 else ''
    rc_sc_ok = (f'v0.3.21 {G21} MATCH' in rc_sc and f'v0.3.22 {G22} MATCH' in rc_sc and all(re.search(r'^  ' + re.escape(s) + r' +v0\.3\.21 lines \S+ +v0\.3\.22 lines \S+ +IDENTICAL', rc_sc, re.M) for s in ('§6.6a', '§6.16g')) and 'inside listed blocks: 0' in rc_sc)
    rng = {m.group(1): [int(m.group(2)), int(m.group(3))] for m in re.finditer(r'^  (§6\.6a|§6\.16g) +v0\.3\.20 lines (\d+)-(\d+) ', sc13, re.M)}
    rows_rng_ok = len(rr_) == 2 and len(rng) == 2 and all(any(x['section_or_RID'].startswith(s + ' ') and x['lines'] == v for s, v in rng.items()) for x in rr_) and len({tuple(x['lines']) for x in rr_}) == 2
    hs = rc.get('history', {}); fz = rc.get('frozen_edition', {})
    rc_ok = (rc['version'] == '0.3.22' and rc['sha256'] == G22 and rc['evidence'] == 'BYTE_VERIFIED' and G22 in avail and G21 in avail and G20 in avail and file_ok and f22_ok
             and c22.get('key') == 'RECOG0322' and c22.get('sha256') == G22 and bool(c22.get('container')) and rc_sc_ok and 'two checked legs' in rc.get('note', '') and 'inputs/owner_section_check_r1/' in rc.get('note', '')
             and f13.get('key') == 'RECOG0321' and f13.get('sha256') == G21 and bool(f13.get('container')) and C13.get('container_chain_status', '').startswith('PREPARER_DECLARED') and sc13_ok and rows_rng_ok
             and hs.get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r6_r11'].get('sha256') == G20 and hs.get('phaseA_r12', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12'].get('sha256') == G21
             and hs.get('phaseA_r13_r16', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r13_r16'].get('sha256') == G21 and hs.get('phaseA_r17_r18', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r17_r18'].get('sha256') == G22
             and rc.get('superseded', {}).get('version') == '0.3.21' and rc['superseded'].get('sha256') == G21 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and fz.get('version') == '0.3.20' and fz.get('sha256') == G20 and fz.get('evidence', '').startswith('BYTE_VERIFIED') and fz.get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED') and G1R in fz.get('frozen', '')
             and all(x['cited_version'] == '0.3.20' and x['cited_sha256'] == G20 and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE'
                     and x['available_file'] == 'sources_available/RECOG__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md' and x['currency'] == 'UNCHANGED_VERIFIED' and x['status'] == 'VERIFIED'
                     and x['verified_current_hash'] == G22 and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['current_owner_version'] == '0.3.22' and 'Phase A r19' in x['currency_reason'] and 'two legs' in x['currency_reason']
                     and x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' and x['reviewer_disposition'] == 'PENDING' and 'RECEIVER-REPORTED (21 Oct 2026)' in x.get('receiver_section_check', '') for x in rr_))
    g('A26 RECOG v0.3.22 byte-verified (file, custody r19, section check: §6.6a/§6.16g identical; two legs from the frozen v0.3.20 pin); v0.3.21 superseded, v0.3.20 frozen edition kept; RER pins stay v0.3.20; RECOG rows UNCHANGED_VERIFIED; per-reference audit pending', rc_ok, f'{len(rr_)} RECOG rows; ranges {rng}')
'''
t = cut(t, "    rc = oc['RECOG']; G22 = ", "    mdl = md.split('\\n'); W = [w", NEW_A26)
NEW_A28 = r'''    m18 = json.loads(B.rd(H18 + 'SOURCE_CURRENCY_MATRIX.json')); b18 = json.loads(B.rd(H18 + 'BLOCKED_SOURCE_REGISTER.json'))
    NEWO = ('Dyadic', 'RECOG', 'RRF')
    OWNF = {'currency', 'currency_reason', 'current_owner_evidence', 'status', 'verified_current_hash', 'receiver_section_check'}
    dk = [(x['owner'], sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k))) for x, y in zip(cm['rows'], m18['rows'])]
    rows18_ok = (len(cm['rows']) == len(m18['rows']) == 91 and all((x['key'], x['record'], x['n'], x['row_kind'], x['cited_sha256'], x['cited_version'], x['authentication'], x['bytes_status']) == (y['key'], y['record'], y['n'], y['row_kind'], y['cited_sha256'], y['cited_version'], y['authentication'], y['bytes_status']) for x, y in zip(cm['rows'], m18['rows']))
                 and all(d == [] for o, d in dk if o not in NEWO) and all(set(d) <= OWNF and 'verified_current_hash' in d and 'current_owner_evidence' in d for o, d in dk if o in NEWO)
                 and all(x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' for x in cm['rows'] if x['record'] == 'RER-G9'))
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256')}
    sa8, sa9 = m18['owner_catalog']['source_authority'], meta.get('source_authority', {})
    rest18_ok = (stripb(br) == stripb(b18) and set(oc) == set(m18['owner_current']) and all(oc[o] == m18['owner_current'][o] for o in oc if o not in NEWO) and all(oc[o] != m18['owner_current'][o] for o in NEWO)
                 and all(oc[o]['version'] == m18['owner_current'][o]['version'] and oc[o]['sha256'] == m18['owner_current'][o]['sha256'] for o in NEWO)
                 and cm.get('scientific_sync_warnings') == m18.get('scientific_sync_warnings') and cm['watch_items'][:-1] == m18['watch_items'] and cm['watch_items'][-1].startswith('Phase A r19 (21 Oct 2026): catalog step')
                 and meta.get('scope') == m18['owner_catalog']['scope'] and set(sa8) == set(sa9) and sorted(o for o in sa8 if sa8[o] != sa9[o]) == list(NEWO) and meta.get('checked') == '2026-10-21 (Phase A r19, preparer)'
                 and cm['bytes_not_available_to_preparer'] == m18['bytes_not_available_to_preparer'] and m18['schema'] == 'RER-SOURCE-CURRENCY/18' and cm['schema'] == 'RER-SOURCE-CURRENCY/19')
    g('A28 r18 matrix equality: 91 rows; pins, bytes and authentication unchanged everywhere; only Dyadic/RECOG/RRF rows differ, in owner-currency fields; other owners, warning (incl. disposition), blocked register and G9 audits unchanged', rows18_ok and rest18_ok, f'{sum(1 for o, d in dk if (o not in NEWO and d) or (o in NEWO and not set(d) <= OWNF))} row(s) with other differences')
'''
t = cut(t, "    m17 = json.loads(B.rd(H17 + 'SOURCE_CURRENCY_MATRIX.json'))", "    H83 = ", NEW_A28)
NEW_A29 = r'''    H83 = 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'; F84 = '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce'
    FN83 = 'RRF083__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md'; P83 = os.path.join(HERE, 'sources_available', FN83)
    f83_ok = FN83 not in withhold and os.path.isfile(P83) and sha(open(P83, 'rb').read()) == H83
    FN84 = 'RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md'; P84 = os.path.join(HERE, 'sources_available', FN84)
    f84_ok = FN84 not in withhold and os.path.isfile(P84) and sha(open(P84, 'rb').read()) == F84
    c84 = C19.get('files', {}).get(FN84, {})
    C15 = json.loads(ri('inputs/source_custody_r15.json')); f15 = C15.get('files', {}).get(FN83, {})
    rf_sc = sc19[sc19.index('== RRF'):] if '== RRF' in sc19 else ''
    rf_sc_ok = (f'v0.8.3 {H83} MATCH' in rf_sc and f'v0.8.4 {F84} MATCH' in rf_sc and re.search(r'^  §2\.3 +v0\.8\.3 lines \S+ +v0\.8\.4 lines \S+ +IDENTICAL', rf_sc, re.M) and re.search(r'^  §2\.4b +v0\.8\.3 lines \S+ +v0\.8\.4 lines \S+ +CHANGED', rf_sc, re.M)
                and re.search(r'^  §4\.2 +v0\.8\.3 lines \S+ +v0\.8\.4 lines \S+ +IDENTICAL', rf_sc, re.M) and re.search(r'^  §6\.3 +v0\.8\.3 lines \S+ +v0\.8\.4 lines \S+ +CHANGED', rf_sc, re.M)
                and len(re.findall(r' IDENTICAL ', rf_sc)) == 9 and len(re.findall(r' CHANGED ', rf_sc)) == 11 and len(re.findall(r' NEW_IN_v0\.8\.4 ', rf_sc)) == 2)
    rr83 = [x for x in cm['rows'] if x['key'] == 'RRF083']; rr82 = [x for x in cm['rows'] if x['key'] == 'RRF082']; rr8 = [x for x in cm['rows'] if x['key'] == 'RRF08_ADOPTED']; rrf = [x for x in cm['rows'] if x['owner'] == 'RRF']; orr = oc.get('RRF', {})
    a29 = (f83_ok and f84_ok and f15.get('key') == 'RRF083' and f15.get('sha256') == H83 and c84.get('key') == 'RRF084' and c84.get('sha256') == F84 and bool(c84.get('container')) and rf_sc_ok
           and len(rr83) == 1 and all(x['cited_sha256'] == H83 and x['cited_version'] == '0.8.3' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL'
                                      and '§2.3 is byte-identical' in x['currency_reason'] and '§2.4b is CHANGED' in x['currency_reason'] and 'not whole-row equality' in x.get('receiver_section_check', '') for x in rr83)
           and len(rr82) == 1 and all(x['cited_version'] == '0.8.2' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED' and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and 'OSC-N2 correction' in x['currency_reason']
                                      and 'both cited sections changed' in x['currency_reason'] and 'Old-to-current equality is not asserted' in x['currency_reason'] and '§4.2 CHANGED' in x.get('receiver_section_check', '') for x in rr82)
           and len(rr8) == 12 and all(x['cited_version'] == '0.8' and x['authentication'] == 'HASH_PRINTED_UNVERIFIED' and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and 'v0.8 original is still not recovered' in x['currency_reason'] for x in rr8)
           and len(rrf) == 14 and all(x['current_owner_version'] == '0.8.4' and x['verified_current_hash'] == F84 and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['currency'] != 'CURRENT' and x['status'] == 'HISTORICAL' for x in rrf)
           and orr.get('version') == '0.8.4' and orr.get('sha256') == F84 and orr.get('evidence') == 'BYTE_VERIFIED' and F84 in avail and '9 IDENTICAL' in orr.get('note', '') and '11 CHANGED' in orr.get('note', '') and '2 NEW' in orr.get('note', '') and 'No RRF OPEN-A/B/E closed' in orr.get('note', '')
           and orr.get('superseded', {}).get('version') == '0.8.3' and orr['superseded'].get('sha256') == H83 and orr.get('history', {}).get('phaseA_to_r16', {}).get('evidence') == 'HASH_VERIFIED_BY_RECEIVER'
           and orr['history'].get('phaseA_r17_r18', {}).get('evidence') == 'OWNER_REPORTED' and orr['history']['phaseA_r17_r18'].get('sha256') == F84)
    g('A29 RRF v0.8.4 byte-verified (file, custody r19, section check 9/11/2 with §2.3 identical and §2.4b changed); v0.8.3 superseded; RRF083 and RRF082 stay RECHECK_IN_PHASE_B/HISTORICAL with section receipts (RRF082 reason corrected); 12 v0.8 rows keep their source limit; no RRF row CURRENT', a29, f'{len(rrf)} RRF rows')
'''
t = cut(t, "    H83 = ", "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt')\n    sums", NEW_A29)
NEW_A32 = r'''    NV = [('Dyadic', '6.4.19', '40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9', 'claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md', 'DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md'),
          ('RECOG', '0.3.22', '0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9', 'claude/RECOG_v0_3_22_RELEASE_RECORD.md', 'RECOG0322__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md'),
          ('RRF', '0.8.4', '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce', 'claude/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_ADOPTION_RECORD.md', 'RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md')]
    rv = ri('inputs/receiving_review_owner_section_20261021.md').decode('utf-8', 'replace')
    a32 = (all(oc.get(o, {}).get('version') == v and oc[o].get('sha256') == h and oc[o].get('evidence') == 'BYTE_VERIFIED' and fn not in withhold and os.path.isfile(os.path.join(HERE, 'sources_available', fn)) and sha(open(os.path.join(HERE, 'sources_available', fn), 'rb').read()) == h
               and C19.get('files', {}).get(fn, {}).get('sha256') == h and rec in oc[o].get('note', '') and KV.get(o) == v and 'inputs/source_custody_r19.json' in KV['_source_authority'].get(o, '') and 'owner_section_check_r1' in KV['_source_authority'][o]
               and all(x['cited_version'] != v and x['cited_sha256'] != h and x['verified_current_hash'] == h and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['currency'] != 'CURRENT' for x in cm['rows'] if x['owner'] == o)
               and h[:8] in cm['watch_items'][-1] for o, v, h, rec, fn in NV)
           and 'ACCEPT SCOPED' in rv and '231201a558ef47732979ff6de6a658f192ac95984c22c49a501283637b9d7753' in rv and '9 IDENTICAL, 11 CHANGED, 2 NEW' in rv and 'OSC-N2' in rv
           and sum(1 for x in cm['rows'] if x['status'] == 'VERIFIED') == 31 and sum(1 for x in cm['rows'] if x['status'] == 'OWNER_REPORTED') == 2 and sum(1 for x in cm['rows'] if x['status'] == 'HISTORICAL') == 52 and sum(1 for x in cm['rows'] if x['status'] == 'BLOCKED') == 6
           and sum(1 for x in cm['rows'] if x['authentication'] == 'BYTE_VERIFIED_HERE') == 60 and sum(1 for x in cm['rows'] if x['authentication'] == 'RECEIVER_BYTE_VERIFIED') == 6)
    g('A32 three current owner versions BYTE_VERIFIED with held files, custody r19 and the receiver-accepted section check; no pin moved, no row CURRENT; receiver review pinned (ACCEPT SCOPED, 9/11/2, OSC-N2); statuses 31/2/52/6, authentication 60/6 as expected by the receiver', a32)
'''
t = cut(t, "    NV = [('Dyadic', '6.4.19'", "    f8 = next((x for x in reg['records'] if x['id'] == 'RER-F3-N7N8'), {})", NEW_A32)
# ---- controls
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
assert block[0].startswith("    T = [('") and all(l.startswith("         ('") for l in block[1:])
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]; ents[-1] = ents[-1][:-1]
keep = [e.rstrip(',') for e in ents if not any(e.startswith("('" + g + ' ') for g in ('A23', 'A24', 'A25', 'A26', 'A28', 'A29', 'A32'))]
M18 = "json.loads(B.rd('inputs/phaseA_r18_outputs/SOURCE_CURRENCY_MATRIX.json'))"
NEWC = f'''('A23 v6.4.19 evidence left OWNER_REPORTED (r18 state)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='OWNER_REPORTED')))
('A23 v6.4.19 relabelled BYTE_VERIFIED_HERE (not catalog vocabulary)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED_HERE')))
('A23 v6.4.19 hash replaced', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64)))
('A23 Dyadic owner entry left in the r18 state', 22, mut(C, lambda d: d['owner_current'].update(Dyadic={M18}['owner_current']['Dyadic'])))
('A23 r17-r18 OWNER_REPORTED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r17_r18')))
('A23 r14-r16 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r14_r16')))
('A23 superseded v6.4.18 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))
('A23 section-check reference dropped from the note', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(note='adopted 20 Oct 2026 (release record claude/RTG_DYADIC_v6_4_19_RELEASE_RECORD.md); bytes held and hashed here; receiver identity receipt')))
('A23 DYAD6418 row left UNCHANGED_OWNER_REPORTED (r18 state)', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED')))
('A23 DYAD6418 pin silently moved to v6.4.19', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(cited_version='6.4.19', cited_sha256='40c9e63f14baef581db9ef4a362ea8f8ac1f124c9f29a63f6b1c3f8931686ec9')))
('A23 DYAD6418 receiver receipt dropped', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(receiver_section_check='')))
('A23 DYAD6413 promoted to UNCHANGED_VERIFIED/VERIFIED on the receiver report', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='UNCHANGED_VERIFIED', status='VERIFIED')))
('A23 DYAD6413 authentication upgraded without the file', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(authentication='BYTE_VERIFIED_HERE')))
('A24 source recorded as r4.12', 23, mut(R, lambda d: d['source_markdown'].update(sha256='7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9')))
('A24 r4.13 package hash replaced', 23, mut(R, lambda d: d['source_markdown'].update(package_zip_sha256='0' * 64)))
('A25 a record changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED')))
('A25 a gap entry changed', 24, mut(R, lambda d: next(x for x in d['gap_entries'] if x['id'] == 'RER-G9').update(text_sha256='0' * 64)))
('A25 F3-N7N8 claim line changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-F3-N7N8')['claim_lines'].pop()))
('A26 v0.3.22 evidence left OWNER_REPORTED (r18 state)', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='OWNER_REPORTED')))
('A26 v0.3.22 hash replaced', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(sha256='0' * 64)))
('A26 RECOG owner entry left in the r18 state', 25, mut(C, lambda d: d['owner_current'].update(RECOG={M18}['owner_current']['RECOG'])))
('A26 r17-r18 OWNER_REPORTED history dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['history'].pop('phaseA_r17_r18')))
('A26 superseded v0.3.21 identity dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('superseded')))
('A26 v0.3.20 frozen edition dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('frozen_edition')))
('A26 two-leg statement dropped from the note', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(note=d['owner_current']['RECOG']['note'].replace('two checked legs', 'direct equality', 1))))
('A26 RECOG row left UNCHANGED_OWNER_REPORTED (r18 state)', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED')))
('A26 RECOG pin silently moved to v0.3.22', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(cited_version='0.3.22', cited_sha256='0dcce9e44d48fbedbcd5af083283fce12560cc17a3951a7632ff0e50db44bcd9')))
('A26 G9/1 per-reference audit marked done', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG' and x['n'] == 1).update(gap_reference_review='AUDITED')))
('A26 RECOG row given the v0.3.21 hash as verified current hash', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(verified_current_hash='a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3')))
('A28 r18 matrix rows re-used', 27, mut(C, lambda d: d.update(rows={M18}['rows'])))
('A28 a non-owner row changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(status='VERIFIED')))
('A28 an RRF row pin hash changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(cited_sha256='0' * 64)))
('A28 a Dyadic row authentication changed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(authentication='RECEIVER_BYTE_VERIFIED')))
('A28 catalog checked date left at r17', 27, mut(C, lambda d: d['owner_catalog'].update(checked='2026-10-21 (Phase A r17, preparer)')))
('A28 G9/3 audit closed', 27, mut(C, lambda d: next(x for x in d['rows'] if x['record'] == 'RER-G9' and x['n'] == 3).update(gap_reference_review='CLOSED')))
('A28 warning disposition dropped', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].pop('receiving_disposition')))
('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited')))
('A28 r19 watch item dropped', 27, mut(C, lambda d: d['watch_items'].pop()))
('A29 v0.8.4 evidence left OWNER_REPORTED (r18 state)', 28, mut(C, lambda d: d['owner_current']['RRF'].update(evidence='OWNER_REPORTED')))
('A29 v0.8.4 hash replaced', 28, mut(C, lambda d: d['owner_current']['RRF'].update(sha256='0' * 64)))
('A29 RRF083 promoted to UNCHANGED_VERIFIED/VERIFIED (whole-row equality from §2.3)', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='UNCHANGED_VERIFIED', status='VERIFIED')))
('A29 RRF083 promoted to CURRENT/VERIFIED', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='CURRENT', status='VERIFIED')))
('A29 RRF083 §2.4b reported identical', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency_reason=next(x for x in d['rows'] if x['key'] == 'RRF083')['currency_reason'].replace('§2.4b is CHANGED', '§2.4b is byte-identical', 1))))
('A29 RRF083 receiver receipt without the non-equality limit', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(receiver_section_check='RECEIVER-REPORTED: ACCEPT SCOPED')))
('A29 RRF082 OSC-N2 correction dropped', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency_reason=next(x for x in d['rows'] if x['key'] == 'RRF082')['currency_reason'].split(' Phase A r19 (OSC-N2 correction)')[0])))
('A29 RRF082 promoted to UNCHANGED_VERIFIED', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(currency='UNCHANGED_VERIFIED', status='VERIFIED')))
('A29 RRF082 authentication upgraded without the file', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF082').update(authentication='BYTE_VERIFIED_HERE')))
('A29 a v0.8 row given current-file verification as pin verification', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(authentication='BYTE_VERIFIED_HERE', bytes_status='BYTE_VERIFIED_MATCH')))
('A29 a v0.8 row reason without the not-recovered limit', 28, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF08_ADOPTED').update(currency_reason='v0.8 pins')))
('A29 RRF note claims OPEN-A closed', 28, mut(C, lambda d: d['owner_current']['RRF'].update(note=d['owner_current']['RRF']['note'].replace('No RRF OPEN-A/B/E closed', 'RRF OPEN-A closed', 1))))
('A29 RRF note with the wrong block count (10/10/2)', 28, mut(C, lambda d: d['owner_current']['RRF'].update(note=d['owner_current']['RRF']['note'].replace('9 IDENTICAL', '10 IDENTICAL', 1).replace('11 CHANGED', '10 CHANGED', 1))))
('A32 a RECOG row marked CURRENT', 31, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='CURRENT')))
('A32 an RRF pin moved to v0.8.4', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(cited_version='0.8.4', cited_sha256='2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce')))
('A32 a Dyadic row verified current hash cleared', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(verified_current_hash=None)))
('A32 a fourth row promoted to VERIFIED (status count 32)', 31, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'GEN287').update(status='VERIFIED')))'''.split('\n')
t = t[:i] + '    T = [' + (',\n         ').join(keep + NEWC) + ']' + t[j:]
t = one(t, "('A31 watch item without the grade change', 30, mut(C, lambda d: d['watch_items'].__setitem__(-2, d['watch_items'][-2].replace('primary grade [ALG]', 'grade unchanged', 1))))",
        "('A31 watch item without the grade change', 30, mut(C, lambda d: d['watch_items'].__setitem__(next(i for i, w in enumerate(d['watch_items']) if w.startswith('Phase A r17 (21 Oct 2026)')), next(w for w in d['watch_items'] if w.startswith('Phase A r17 (21 Oct 2026)')).replace('primary grade [ALG]', 'grade unchanged', 1))))")
# file / input controls for r19
t = one(t, "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt'); had = os.path.isfile(SUMS)",
        "    for fn, gi, lab in (('DYAD6419__RTG_DYADIC_OSCILLATOR_DSN_v6_4_19.md', 22, 'A23 v6.4.19'), ('RECOG0322__RTG_RELATIONAL_RECOGNITION_DSN_v0_3_22.md', 25, 'A26 v0.3.22'), ('RRF084__RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md', 28, 'A29 v0.8.4')):\n"
        "        _, rr = gates(outs, verbose=False, withhold=(fn,)); good = not rr[gi]; allf &= good\n"
        "        print(f'  file control {lab} file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    sc19b = B.rd('inputs/owner_section_check_r1/compare_output.txt'); c19b = B.rd('inputs/source_custody_r19.json'); rvb = B.rd('inputs/receiving_review_owner_section_20261021.md'); o18b = B.rd('inputs/phaseA_r18_outputs/check_phaseA_output_r18.txt')\n"
        "    for n, p, bb, gi in [('A23 section check reports §6.17 CHANGED', 'inputs/owner_section_check_r1/compare_output.txt', sc19b.replace(b'  \\xc2\\xa76.17                  v6.4.18 lines 954-981      v6.4.19 lines 983-1010     IDENTICAL', b'  \\xc2\\xa76.17                  v6.4.18 lines 954-981      v6.4.19 lines 983-1010     CHANGED  ', 1), 22),\n"
        "                         ('A26 section check reports §6.16g CHANGED', 'inputs/owner_section_check_r1/compare_output.txt', sc19b.replace(b'v0.3.22 lines 1071-1110    IDENTICAL', b'v0.3.22 lines 1071-1110    CHANGED  ', 1), 25),\n"
        "                         ('A29 section check reports §2.4b IDENTICAL', 'inputs/owner_section_check_r1/compare_output.txt', sc19b.replace(b'v0.8.4 lines 205-223      CHANGED', b'v0.8.4 lines 205-223      IDENTICAL', 1), 28),\n"
        "                         ('A23 custody r19 hash altered', 'inputs/source_custody_r19.json', c19b.replace(b'40c9e63f14baef58', b'0000000000000000', 1), 22),\n"
        "                         ('A32 receiver review altered (decision word removed)', 'inputs/receiving_review_owner_section_20261021.md', rvb.replace(b'ACCEPT SCOPED', b'DECISION', ), 31),\n"
        "                         ('A24 r18 checker record altered', 'inputs/phaseA_r18_outputs/check_phaseA_output_r18.txt', o18b.replace(b'34/34 gates PASS', b'33/34 gates PASS', 1), 23)]:\n"
        "        assert bb != B.rd(p), n\n"
        "        _, rr = gates(outs, verbose=False, inp={p: bb}); good = not rr[gi]; allf &= good\n"
        "        print(f'  input control {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
        "    SUMS = os.path.join(HERE, 'SHA256SUMS.txt'); had = os.path.isfile(SUMS)")
a = '"""Phase A r18 gates on RER v0.2 DRAFT r4.13 (r18: source r4.13; catalog unchanged since r17).'; assert t.count(a) == 1
t = t.replace(a, '"""Phase A r19 gates on RER v0.2 DRAFT r4.13 (r19: catalog step; source unchanged).\n'
  'r19: A23/A26/A29 (re-based): Dyadic v6.4.19, RECOG v0.3.22 and RRF v0.8.4 are BYTE_VERIFIED only with the real file in sources_available, the r19 custody\n'
  'entry and the owner section check output (inputs/owner_section_check_r1/) showing the cited Dyadic and RECOG blocks IDENTICAL and the RRF 9/11/2 pattern\n'
  'with §2.3 IDENTICAL and §2.4b CHANGED; the r17-r18 OWNER_REPORTED state is kept as history. DYAD6418 and the RECOG rows UNCHANGED_VERIFIED/VERIFIED with\n'
  'pins unchanged; DYAD6413 stays RECHECK (receiver direct comparison recorded, file not held); RRF083/RRF082 stay RECHECK/HISTORICAL with section receipts and\n'
  'the OSC-N2 correction; the 12 v0.8 rows keep their source limit. A24 adds the r18 checker record; A25 requires registry identity with r18 apart from the\n'
  'schema; A28 compares with the r18 matrix: pins, bytes and authentication unchanged everywhere, only owner-currency fields of Dyadic/RECOG/RRF rows differ;\n'
  'A32 pins the receiver review and checks the receiver-expected counts 31/2/52/6 and 60/6. The r18 A23-A26/A28/A29/A32 controls are retired.\n'
  'Earlier wording, kept as history: Phase A r18 gates on RER v0.2 DRAFT r4.13 (r18: source r4.13; catalog unchanged since r17).', 1)
open(C, 'w', encoding='utf-8').write(t)
p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/source_custody_r19.json', 'inputs/receiving_review_owner_section_20261021.md'] + ['inputs/owner_section_check_r1/' + x for x in sorted(os.listdir(scd))] + ['inputs/phaseA_r18_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs'], f; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched r19')
