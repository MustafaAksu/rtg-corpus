# RER Phase B-08 — neutral review packet

RER Phase B-08 neutral review packet (NONCANONICAL; preparer Claude, RER co-owner). Verbatim quotations of byte-pinned sources, provenance-labelled proof material and questions; no PASS/FAIL, grade or acceptance recommendation is given for any claim.

**Review (receiver decides per record or claim: ACCEPT SCOPED, CORRECTION REQUIRED, INSUFFICIENT EVIDENCE):** `RER-TRIAD-AGE-CURVATURE`, `RER-F3-N7N8`

**Context:** the B-05 inventory (sources/history/) is PREPARER_AUTHORED context; the B-07 decision file is included because it names these two records as the next author-conflicted items.

**Currency note:** Source RER r4.12 (7313647a…f4b9; the two records are byte-identical to r4.11) and Phase A r17 (receiver decision of 21 Oct 2026: `ACCEPT SCOPED`). The records cite study snapshots and evidence artifacts only; no owner-DSN currency question arises for them.

**Support files** (held; not RER imports; each hash is cited in the named held source): `jet_coefficients.json` (`15a7d056…`) — CURVSCRIPT, AGEGEO; `c09_independent_series_check_rev2.py` (`67b2e0e7…`) — CURVSCRIPT, CURVNOTE; `triad_finite_jet_defect_N7_N8.py` (`de367595…`) — CURVNOTE, N7REVIEW; `triad_finite_jet_defect_N7_N8_rev.py` (`5c63c363…`) — CURVNOTE; `check_pointwise_metrics.py` (`61a54f0a…`) — CURVNOTE; `check_second_difference.py` (`fb8907f0…`) — CURVNOTE; `triad_tm_onestep_certificate_v2.py` (`c14c27cd…`) — TM2NOTE; `STAGE2_REPLAY_20261014.zip` (`d782a701…`) — RER12; `STAGE2_REPLAY_README.md` (`02588f55…`) — RER12

## RER-TRIAD-AGE-CURVATURE

RER r4.12 lines 547–581; span SHA-256 `a4e4bf796806866df0e3637f3fab13ce5d98f08e8ae3da7afb54feb95f0dcb0a`. Byte-identical to r4.6 (lines 545–579): yes; B-05 inventory span SHA-256 `f68fa14000297747b6a4f1e48bd34fc74c4386909319a5701c916a9d5b905991`.

### Record text (verbatim)

```
### RER-TRIAD-AGE-CURVATURE — Fixed-parent age-fibre wedge and degree-eight transverse defect
**Primary grade:** [ALG]. **Exactness:** `FINITE_ORDER`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none.

| Field | Contract |
|---|---|
| Carrier | same-current-parent age graphs; s=(r,e); kappa=sqrt(3)*kappa_tilde; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | w=det(c1-c0,c2-c0); B7; R8 |
| Constraints | kappa_tilde fixed nonzero; parent chart and child plane fixed; This wedge is not claimed invariant under arbitrary nonlinear changes of the complete state. |
| Transformation law | A scalar reparameterization of age cannot remove a component transverse to D5; joint nonlinear carrier changes are a separate question. |
| Closure status | FINITE_ORDER_NONAFFINE_AGE_FIBRE: The degree-13 wedge is generically nonzero; affine child fibres at fixed parent do not represent all age sheets through this order. |
| Memory | Transverse separation requires nonaffine age fibres in the fixed parent chart; it does not establish compulsory historical memory or forbid all curved factors. Use the stated observation task and source contract; no memory/age carrier added. |

[ALG] **FINITE_ORDER.** The degree-13 wedge is generically nonzero; affine child fibres at fixed parent do not represent all age sheets through this order.
Formula/witness: `D5 wedge R8=w13; B7=-(Qs/2)D5`.

**Domain / admissibility:** All parent directions as a polynomial identity; exact nonzero wedge for small rays where the leading angular factor is nonzero.

**Map / clock:** `F=N^6`; F=N^6, each primitive step reprojects.

**Factor or parametrization tested:** affine-in-age child fibre (rejected at stated jet order).

**Order / error:** w leading degree 13; transverse residual degree 8; B7 degree 7. w=-(kappa_tilde^2/1024)Qs^5(111r^3-68r^2 e+177r e^2-175e^3)+O(|s|^14). A zero of the leading factor is not exact collinearity.

**Contract type:** `AGE_FIBRE_COLLINEARITY_TEST_NOT_FACTOR`.

**Evidence:** original scientific source pins and earlier verification scopes are retained from r2. R3 checks the changed source/wording interfaces and separate Stage-2 metadata behavior; no historical mathematical certificate is rerun.

**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending. [TRIAD_R2_REVIEW: Triadic contributor review of RER v0.2 DRAFT r2 — record-by-record scope check](sources/current/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md); lines 1–30; RID unavailable; exact section pinned; SHA-256 `d388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab`.
Import/reference: [CURVNOTE: 7. Correction (9 Oct, 17:xx) — the τ-update claim in §6 is withdrawn; invariant replacement](sources/current/RER_C09_INDEPENDENT_VERIFICATION_20261009%20%286%29.md); lines 83–105; RID unavailable; exact section pinned; SHA-256 `d3553fb4ab6965aefba643672920e98998c8c93c737902a6ab2c2f4573f23321`.
Import/reference: [CURVSCRIPT: Complete source/record (bounded note or machine artifact)](sources/current/triad_age_fibre_curvature_check.py); lines 1–108; RID unavailable; exact section pinned; SHA-256 `e56088b0fa57e97aac590b9c92bd1490c2784cb85b9ee9719a26bc99254817f2`.
Import/reference: [AGEGEO: B. [ALG] Universal seventh-degree second age difference](sources/upstream/TRIAD_C09_AGE_GEOMETRY_REVIEW_20261009/notes/C09_AGE_GEOMETRY_RECEIVING_REVIEW.md); lines 13–42; RID unavailable; exact section pinned; SHA-256 `ae3af1922a319ea2474d1c132a04e7e722ee387a64ef43b9c0491b49d8373b2b`.

**Next test:** Use formal curved family; quantitative convergence/defect remains separate.

**Non-transfer:** No new independent state datum, physical emergence, compulsory historical memory, or physical age variable is established. No automatic RRF registration, universal model exclusion or scientific-owner adoption.
```

### Imports (Phase A r17)

| n | Key | Cited | Section / lines | Bytes | Authentication | Currency | Status |
|---|---|---|---|---|---|---|---|
| 0 | `CURVNOTE` | through §11 COR `d3553fb4ab69` | 7. Correction (9 Oct, 17:xx) — the τ-update claim in §6 is withdrawn; invariant replacement [83, 105] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 1 | `CURVSCRIPT` | source upload `e56088b0fa57` | Complete source/record (bounded note or machine artifact) [1, 108] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 2 | `AGEGEO` | 2026-10-09 `ae3af1922a31` | B. [ALG] Universal seventh-degree second age difference [13, 42] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | SNAPSHOT_RECHECK_IN_PHASE_B | HISTORICAL |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| CURVNOTE §7 wedge statement and boxed formula for w | X-CUR-1 | HELD (d3553fb4…3321); the note calls itself an "independent receiving verification"; the r2 reviewer refers to "my C09 note" (X-CUR-6); author not otherwise named |
| symbolic derivation and ray cross-check triad_age_fibre_curvature_check.py | X-CUR-3 | HELD (e56088b0…17f2); needs SymPy, the pinned jet and the rev2 series file |
| pinned G3/G4 jet jet_coefficients.json (15a7d056…2824) | X-CUR-3, X-CUR-4 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in CURVSCRIPT and AGEGEO; not an RER import of this record (Phase A key JET elsewhere) |
| rev2 series file c09_independent_series_check_rev2.py (67b2e0e7…799b) | X-CUR-3 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in CURVSCRIPT and CURVNOTE; the same bytes as SERIES2 of RER-TRIAD-FORMAL-AGE |
| AGEGEO §B: B7 = −(Q_s/2)D5 (universal seventh-degree second age difference) | X-CUR-5 | HELD (ae3af192…3b2b); "Triadic receiving review" (its own header); Phase A r17: SNAPSHOT_RECHECK_IN_PHASE_B |
| second-difference checker check_second_difference.py (fb8907f0…50be) | cited in CURVNOTE §6 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in CURVNOTE |
| contributed series file c09_independent_series_check.py (758d38c7…a613) named in AGEGEO §A | X-CUR-4 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet |
| review receipt: r2 contributor review | X-CUR-6 | HELD (d388d7eb…e1ab); the r2 reviewer refers to "my C09 note"; the receiver lists this record as author-conflicted (B-07 decision file) |

### Questions for the receiver (no answer is implied)

- **Q-CUR-1** (objects): The record's Observables are w = det(c1−c0, c2−c0), B7 and R8; X-CUR-3 defines c_n(s) = C(s) + n D5 + n D6 + n D7 + binom(n,2) B7 + binom(n,2) B8 + … and R8 = B8 + (Q/2) D6. Are w, B7, R8 and "transverse residual degree 8" in the record the objects of X-CUR-1 and X-CUR-3?
- **Q-CUR-2** (B7 = −(Q_s/2) D5): The Formula/witness gives B7 = −(Qs/2) D5. Where is this derived — AGEGEO §B (X-CUR-5) or the script — and for which parent directions and κ̃?
- **Q-CUR-3** (wedge formula): Order/error states w = −(κ̃²/1024) Q_s^5 (111r³ − 68r²e + 177re² − 175e³) + O(|s|^14). X-CUR-1 boxes this formula and X-CUR-3 checks "D5 ^ R8 == W13" symbolically and three rays against untruncated series. Which part establishes the all-direction polynomial identity (Domain: "All parent directions as a polynomial identity") and which part is a cross-check?
- **Q-CUR-4** (inputs of the derivation): The symbolic part uses the pinned jet 15a7d056…2824 (G3/G4) and the ray part the rev2 series file 67b2e0e7…799b. AGEGEO §A (X-CUR-4) records the jet and a different series-file identity (758d38c7…a613, not held). Is the provenance of the jet sufficient for the receiver at the stated jet order?
- **Q-CUR-5** (scope of the closure claim): Closure: "affine child fibres at fixed parent do not represent all age sheets through this order"; Constraints: the wedge "is not claimed invariant under arbitrary nonlinear changes of the complete state"; Memory: "does not … forbid all curved factors". Is every claim line scoped to the fixed parent chart and child plane?
- **Q-CUR-6** ("generically nonzero"): The claim says the degree-13 wedge is "generically nonzero", and Order/error: "A zero of the leading factor is not exact collinearity". Does the record anywhere assert nonvanishing on a set of directions, and is the κ̃-dependence (∝ κ̃², κ̃ fixed nonzero) carried at the point of use?
- **Q-CUR-7** (transformation law): The Transformation-law cell states that a scalar reparameterization of age cannot remove a component transverse to D5. Which held source shows this, and is it a consequence of B7 ∥ D5 (X-CUR-3 docstring) or a separate argument?
- **Q-CUR-8** (withdrawn claim): X-CUR-1 withdraws the τ-update claim of X-CUR-2 and gives the invariant replacement. Does any line of the record rely on the withdrawn §6 statement?
- **Q-CUR-9** (grade and receipt): Record level [ALG], FINITE_ORDER; the Evidence field says no historical certificate is rerun in r3; the only receipt is the r2 contributor review, whose author refers to "my C09 note". What evidence does the receiver need for the [ALG] grade at degree 13?

### Source extracts (verbatim)

#### X-CUR-1 — CURVNOTE §7 (the cited section, lines 83–105): withdrawn τ-update claim and the invariant wedge replacement

`sources/triad/RER_C09_INDEPENDENT_VERIFICATION_20261009 (6).md` lines 83–104; extract SHA-256 `b1a9e82ce65c284bbdc6be1cd86d913253080ed112f36e73eda7a1f5c0699eba`

````
## 7. Correction (9 Oct, 17:xx) — the τ-update claim in §6 is withdrawn; invariant replacement

**[COR] Withdrawn:** "τ⁺ = 1 + (1 − Q_s/2)τ + O(Q_s²τ²), residual starting exactly at order Q_s² (coefficient −Q_s²/4), no odd-order terms." Cause: my probe divided series kept only through t¹² (NT=12), so the quotient had three genuine coefficients and the t³, t⁴ entries were zeros by construction; the "−1/4 at t⁴" was the surviving cross term of a truncated product. Recomputed at NT=15 with a proper series quotient, the convention I used — Euclidean projection of c − C(s) onto d₁(s) truncated at total degree 7 — gives τ₂(t,0) = 2 − t²/2 + (73/3840)t³ + …, and even τ₁ = 1 + (101/960)t³ + …. The co-owner's two conventions give +13/512 (B-metric, full d₁) and −49/256 (Euclidean, full d₁); all three reproduce here. **What survives:** τ⁺ = 1 + (1 − Q_s/2)τ + O(‖s‖³) relative, and nothing beyond that is convention-independent. The co-owner's `check_tau_projection.py` (SHA `fcadd35d…4808`) passes 4/4 against my rev2 series code.

**Invariant replacement — age-fibre curvature as an all-direction polynomial.** Collinearity of the age-0/1/2 child states at a matched parent is measured by w(s) = det[d₁, d₂]. Using d₂ − 2d₁ = B₇ + B₈ + … and B₇ ∥ D₅,

\[
w(s) = D_5\wedge B_8 + D_6\wedge B_7 + O(\|s\|^{14}),
\]

and the degree-8 n² coefficient needs only the pinned G₃/G₄ jet: B₈ = A₃D₆ + A₄D₅ − DD₆·g₃ − DD₅·g₄, with D₆ = [D_cG₄,c(s,0)]C − DC·g₄. Symbolically, for all directions,

\[
\boxed{\,w(s) = -\frac{\tilde\kappa^{2}}{1024}\,Q_s^{5}\,K_3(r,e),\qquad K_3 = 111r^3 - 68r^2e + 177re^2 - 175e^3\,}
\]

(`triad_age_fibre_curvature_check.py`, SHA `e56088b0fa57e97aac590b9c92bd1490c2784cb85b9ee9719a26bc99254817f2`; 13 PASS, negative control exits 1). It reproduces the co-owner's three ray values (−111/1024, −45/1024, 175/1024 at κ̃=1) and three further rays against the untruncated full-map series, including B₈ and D₆ componentwise. Two consequences:

1. The wedge is exactly D₅ ∧ R₈ with R₈ = B₈ + (Q_s/2)D₆ the n² term left after the degree-7 reparametrisation τ = n − (Q_s/4)n(n−1). So no choice of τ(s) can straighten the fibres at degree 8: the transverse part is a coordinate-free obstruction, while any component along D₅ is absorbable. This is the "degree-8 transverse normal defect" the co-owner asked for.
2. K₃ has exactly one real zero direction, e/r ≈ 1.15205 (discriminant −8516860031). On that ray only the t¹³ coefficient of the wedge vanishes; exact collinearity of the three age states in the full analytic model is not shown, and higher orders may separate them [wording narrowed on Triadic review, 9 Oct]. The leading-order bending has opposite senses on either side of that ray. The transverse defect is therefore not a positive multiple of a power of Q_s, unlike D₅ and B₇.

Scope: formal, fixed finite ages 0–2, conditional model; nothing about convergence, uniform domains, physical memory, or a reduced autonomous law. A curved three-parameter description c = C + τD + τ²E + … on the punctured region is not excluded.
````

#### X-CUR-2 — CURVNOTE §6 (context: the addendum whose τ-update claim §7 withdraws)

`sources/triad/RER_C09_INDEPENDENT_VERIFICATION_20261009 (6).md` lines 65–81; extract SHA-256 `0d3d38fd0abca223682d29542bdc9ab0d5e178823a19260752d219517b2d815c`

````
## 6. Addendum (9 Oct, later) — receiving of the co-owner's age-geometry note

Inputs: `C09_AGE_GEOMETRY_RECEIVING_REVIEW.md` and `check_second_difference.py` (SHA-256 `fb8907f07ca285d6031135397b084c0d00fc80b320604f6a2742d696937150be`), run here against the pinned jet `15a7d056…2824`: **13/13 PASS, exit 0; `--negative` exits 1.**

**B₇ derivation (§B) — accepted.** The one-step propagation of a current-parent child perturbation δ is δ⁺ = δ + D₅ + A_c δ − Dδ·g_s + O(8), where the bracket D₅ = G₃,c(s,C) − DC·g_s is exactly the C07 drift. The neglected pieces are all O(8) or higher: the child-induced parent shift is O(7) and enters C(s′) at O(9); the G₄ child contributions carrying n are O(8). So B₇ = A_c D₅ − DD₅·g_s is the complete degree-7 n² coefficient. The symbolic result (κ̃/4)Q³s coincides with my untruncated full-map ray values on all five rays, so the two routes agree: symbolic-in-direction on the jet, exact-in-map on rays.

**[THM] no C¹ embedded 3-fold through the origin containing two age sheets (§D) — accepted, with one hypothesis discharged.** The proof needs both sheets to be graphs over a full s-neighbourhood of 0. That is not an extra assumption: DF(0)=I and DB_κ(0)=(I,0) make g_κ(s)=F_s(B_κ(s)) a local diffeomorphism, so every M_{κ,n} is a graph c=c_n(s) near 0 for fixed n. The argument then only uses C07's drift and C¹ continuity of D_cH at the origin; it is independent of the rest of the dynamics. The decisive feature is that the drift R_κ(s) ∝ s sweeps every direction of the child plane as s turns, which kills every candidate normal a. A drift along a fixed direction would not have this consequence. The same argument covers any pair n≠m.

**Fingerprint singular at 0 (§E) — accepted.** Trivially: distinct per-sheet limits at one accumulation point.

**New: the τ coordinate has a formal autonomous update at the retained order.** Define τ on the state by projecting c − C(s) onto D(s) = D₅+D₆+D₇ (equivalently, c₁(s) − c₀(s) through degree 7). Reading τ from the actual states X_n and F(X_n) on the untruncated map gives, on rays (1,0), (1,1), (2,−1) and κ̃ ∈ {1, −2/3}, ages 0–2:

\[
\tau^+ = 1 + \Big(1-\tfrac{Q_s}{2}\Big)\tau + O(Q_s^2\tau^2),
\]

with the residual starting exactly at order Q_s² (coefficient −Q_s²/4 at age 2) and no odd-order terms. Consistent with τ_n = n − (Q_s/4)n(n−1): τ_{n+1}−τ_n = 1 − nQ_s/2 = 1 − τQ_s/2 + O(Q_s²). So at this order the pair (s, τ) carries a reduced update (s, τ) ↦ (s + g_s(s) + …, 1 + (1 − Q_s/2)τ). Boundaries: formal, fixed-n remainders only; DF(0)=I makes all multipliers 1, so there is no standard convergence theorem for continuing this order by order; the chart degenerates at s=0 (∂_τ c(0,τ)=0), which is the singular 3-fold the THM says is unavoidable — a cone over the sheets with vertex at the origin.
````

#### X-CUR-3 — triad_age_fibre_curvature_check.py, whole file (symbolic all-direction derivation and three ray cross-checks)

`sources/triad/triad_age_fibre_curvature_check.py` lines 1–108; extract SHA-256 `36b9cff5c727d145be7c344923870e58d3f0988ff2e871f8d960f0742bb48ddd`

````
#!/usr/bin/env python3
"""
Age-fibre curvature at degree 13: symbolic all-direction derivation from the pinned G3/G4 jet,
cross-checked against untruncated full-map ray series.

Setting (Genesis->RER conditional analytic modal model, birth contract A, matched current parent s):
   c_n(s) = C(s) + n D5 + n D6 + n D7 + binom(n,2) B7 + binom(n,2) B8 + ... ,  kappa = sqrt3*kt.
Chords d_j(s) = c_j(s) - c_0(s).  Collinearity of the three age states (0,1,2) in the child plane is
measured by  w(s) = det[d_1(s), d_2(s)].  Since d_2 - 2 d_1 = B7 + B8 + ..., and B7 || D5,

   w(s) = D5 ^ B8 + D6 ^ B7 + O(||s||^14)          (degree 13, all directions)

with, from the one-step propagation of a current-parent child perturbation (degree 8 only needs G3,G4):
   D5 = [G3_c(s,C)]_5 - DC g3 ,            D6 = [G4_c(s,C)]_6 - DC g4
   B7 = A3 D5 - DD5 g3 ,                   B8 = A3 D6 + A4 D5 - DD6 g3 - DD5 g4
   A_k = D_c G_{k,c}(s,0),  g_k = G_{k,s}(s,0).

The symbolic part needs SymPy and the pinned jet (SHA-256 15a7d056...2824).  The ray cross-check uses the
contributor's standard-library full-map series code (rev2, SHA-256 67b2e0e7...799b) placed in ../source/.
Usage:  python triad_age_fibre_curvature_check.py [--negative]
"""
import sys, json, hashlib
from pathlib import Path
from fractions import Fraction as Fr
import sympy as S

HERE = Path(__file__).resolve().parent
JET = HERE.parent / 'source' / 'jet_coefficients.json'
SERIES = HERE.parent / 'source' / 'c09_independent_series_check_rev2.py'
assert hashlib.sha256(JET.read_bytes()).hexdigest() == '15a7d0569a1e8ceefe04260ce83e204acb2eeed20b2639eebd810e14ee992824'
assert hashlib.sha256(SERIES.read_bytes()).hexdigest() == '67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b'
NEG = '--negative' in sys.argv

r, e, cr, ce, kt = S.symbols('r e cr ce kt', real=True)
V4 = [r, e, cr, ce]
def poly(d):
    out = 0
    for ex, co in d.items():
        term = S.Rational(co)
        for x, j in zip(V4, map(int, ex.split(','))):
            term *= x**j
        out += term
    return S.expand(out)
src = json.loads(JET.read_text())
G3 = S.Matrix([poly(d) for d in src['G3']]); G4 = S.Matrix([poly(d) for d in src['G4']])
Q = r*r - r*e + e*e
sv = S.Matrix([r, e]); cv = S.Matrix([cr, ce])
C = kt * Q * S.Matrix([[1, -2], [2, -1]]) * sv
at0 = {cr: 0, ce: 0}
def hom(expr, deg):   # homogeneous part of given total degree in (r,e)
    return S.Matrix([sum(t for t in S.Add.make_args(S.expand(x)) if S.Poly(t, r, e).total_degree() == deg) for x in expr])
g3 = G3[0:2, :].subs(at0); g4 = G4[0:2, :].subs(at0)
A3 = G3[2:4, :].jacobian([cr, ce]).subs(at0); A4 = G4[2:4, :].jacobian([cr, ce]).subs(at0)
subC = {cr: C[0], ce: C[1]}
D5 = hom(G3[2:4, :].subs(subC) - C.jacobian([r, e]) * g3, 5)
D6 = hom(G4[2:4, :].subs(subC) - C.jacobian([r, e]) * g4, 6)
B7 = S.expand(A3 * D5 - D5.jacobian([r, e]) * g3)
B8 = S.expand(A3 * D6 + A4 * D5 - D6.jacobian([r, e]) * g3 - D5.jacobian([r, e]) * g4)
if NEG: B8 = B8 * S.Rational(9, 10)   # negative control: a wrong B8 must be caught by the ray cross-check
wedge = lambda a, b: S.expand(a[0]*b[1] - a[1]*b[0])
W13 = wedge(D5, B8) + wedge(D6, B7)

checks = []
def chk(name, ok, detail=''):
    checks.append(ok); print(('PASS ' if ok else 'FAIL '), name, detail)

chk('D5 = -(kt/2) Q^2 s', S.expand(D5 + kt/2*Q**2*sv) == S.zeros(2, 1))
chk('B7 = (kt/4) Q^3 s', S.expand(B7 - kt/4*Q**3*sv) == S.zeros(2, 1))
chk('degrees: D6=6, B8=8, W13=13', all(S.Poly(x, r, e).total_degree() == d for x, d in [(D6[0], 6), (B8[0], 8), (W13, 13)]))
chk('W13 is kt^2 times a kt-free polynomial', S.Poly(W13, kt).degree() == 2 and S.Poly(W13, kt).coeff_monomial(kt) == 0 and S.Poly(W13, kt).coeff_monomial(1) == 0)
P13 = S.factor(S.expand(W13 / kt**2))
print('   W13/kt^2 =', P13)
# parallel/transverse split of the degree-8 residual after the degree-7 tau reparametrisation
R8 = S.expand(B8 + Q/2*D6)               # leftover n^2 term at degree 8 once tau = n - (Q/4) n(n-1) absorbs B7
chk('D5 ^ R8 == W13 (the wedge is exactly the transverse part of the reparametrised degree-8 n^2 term)', S.expand(wedge(D5, R8) - W13) == 0)
# the transverse defect is not a multiple of Q^k: it vanishes on real directions
cubic = S.cancel(S.expand(W13 / kt**2) / (-Q**5 / 1024))
chk('W13 = -(kt^2/1024) Q^5 * K3(r,e) with K3 a cubic form', S.Poly(cubic, r, e).total_degree() == 3 and S.expand(W13 + kt**2*Q**5*cubic/1024) == 0)
print('   K3(r,e) =', S.expand(cubic))
x = S.Symbol('x', real=True)
roots = [float(S.re(z)) for z in S.Poly(S.expand(cubic.subs({r: 1, e: x})), x).nroots() if abs(S.im(z)) < 1e-12]
print('   real zero directions e/r of K3 (hence of W13):', roots)
chk('K3 has exactly one real zero direction, so W13 changes sign across directions', len(roots) == 1)

# ---- cross-check against the untruncated full-map series on rays (standard-library code, no jet) --------
scope = {'__name__': '__probe__'}
exec(SERIES.read_text().split('# ---------------------------------------------------------------- checks')[0], scope)
scope['NT'] = 15
exec('''
def probe(ktv,u):
  tgt=ray(u); c=[]
  for n in (0,1,2):
    s0=initial_for_current_parent(tgt,n,ktv); c.append(Fn(birth(s0,ktv),n)[1])
  d1=[sub(c[1][i],c[0][i]) for i in range(2)]; d2=[sub(c[2][i],c[0][i]) for i in range(2)]
  w=sub(mul(d1[0],d2[1]),mul(d1[1],d2[0]))
  B8=[d2[i][8]-2*d1[i][8] for i in range(2)]; D6=[d1[i][6] for i in range(2)]
  return order(w), w[13], B8, D6
''', scope)
for ktv, u in [(Fr(1), (1, 0)), (Fr(-2, 3), (1, 0)), (Fr(1), (1, 1)), (Fr(1), (0, 1)), (Fr(1), (2, -1)), (Fr(3, 5), (1, 3))]:
    ow, w13, B8ray, D6ray = scope['probe'](ktv, u)
    sub_ = {r: u[0], e: u[1], kt: S.Rational(ktv.numerator, ktv.denominator)}
    okw = ow == 13 and S.Rational(w13.numerator, w13.denominator) == W13.subs(sub_)
    okB = all(S.Rational(x.numerator, x.denominator) == B8.subs(sub_)[i] for i, x in enumerate(B8ray))
    okD = all(S.Rational(x.numerator, x.denominator) == D6.subs(sub_)[i] for i, x in enumerate(D6ray))
    chk(f'ray kt={ktv} u={u}: wedge order 13, W13, B8 and D6 all match full-map series', okw and okB and okD, f'(w13={w13})')

print(f'\n{sum(checks)} PASS, {len(checks)-sum(checks)} FAIL')
sys.exit(0 if all(checks) else 1)
````

#### X-CUR-4 — AGEGEO §A receiving evidence (identities of the series file and the jet)

`sources/triad/C09_AGE_GEOMETRY_RECEIVING_REVIEW.md` lines 7–11; extract SHA-256 `7200c59a298c21ea6a15ed019902a77f591a5a42eef772540f1dbeb18d5604b1`

````
## A. Receiving evidence

The contributed independent file `c09_independent_series_check.py` has SHA-256 `758d38c79074333f98e289ddf0e66da1572014aab4d60ca19f00a48814aaa613`, matching its author's note. Its source declares that it uses no C08/C09 packages and composes the complete analytic sin/exp edge map as exact truncated rational power series, with modal re-projection at every primitive step. The author's full-grid result **511 PASS** and negative run **180 FAIL** are *author-reported*. A fresh full-grid run was attempted in this receiving environment but exceeded the execution limit, so this note does not present it as a completed independent replay. A bounded direct full-map sample (two rays, first three ages, through order 8) reproduced the claimed age-second-difference coefficient.

The archived source `jet_coefficients.json` has SHA-256 `15a7d0569a1e8ceefe04260ce83e204acb2eeed20b2639eebd810e14ee992824`. A separate new checker loads its retained cubic vector jet, reproduces the degree-five normal drift from the source and symbolically proves the new age-quadratic coefficient for *every* parent direction and arbitrary symbolic nonzero \(\kappa\).
````

#### X-CUR-5 — AGEGEO §B (the cited section, lines 13–42): universal seventh-degree second age difference

`sources/triad/C09_AGE_GEOMETRY_RECEIVING_REVIEW.md` lines 13–41; extract SHA-256 `fa2beca9364efcc468f13904586f1f09b6a1bb68df6ae80b983cc2207b0ca046`

````
## B. [ALG] Universal seventh-degree second age difference

Put \(s=(r,e)\), \(Q_s=r^2-re+e^2\), \(\kappa=\sqrt3\tilde\kappa\). At a *matched current parent* the fifth-degree normal drift of the accessible graph is

\[
D_5(s)=-\frac{\tilde\kappa}{2}Q_s^2s.
\]

Let \(G_3=(G_{3,s},G_{3,c})\) be the six-step cubic vector jet, set \(g_s(s)=G_{3,s}(s,0)\), and \(A_c(s)=D_cG_{3,c}(s,0)\). To seventh degree, the variation of graph drift from a prior fifth-degree child perturbation is

\[
B_7(s)=A_c(s)D_5(s)-D_sD_5(s)\,g_s(s).
\]

**Explanation of the formula:** the first term propagates the prior child perturbation through the cubic child update. The second accounts for evaluating the age sheets at the **same current parent** rather than the same birth input. Terms quadratic in the fifth-degree perturbation and higher-degree corrections cannot contribute to degree seven. The quadratic base evolution is absent in the six-step map.

The source jet gives the exact polynomial identity

\[
\boxed{B_7(s)=\frac{\tilde\kappa}{4}Q_s^3s=-\frac{Q_s}{2}D_5(s).}
\]

Consequently, for each fixed finite \(n\), the formal age-sheet graph has the structure

\[
c_n(s)=C_\kappa(s)+nD_5(s)+nD_6(s)+nD_7(s)+\binom n2 B_7(s)+O_n(\|s\|^8),
\]

where \(D_6,D_7\) are the age-*linear* degree-six/seven components. The result proves the contributor's reported \(n^2\) coefficient, not just on sampled rays but as a polynomial identity on the declared conditional source jet.
````

#### X-CUR-6 — r2 contributor review, whole file (the record's only review receipt)

`sources/rer/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md` lines 1–30; extract SHA-256 `681cec8c81f4626a0dab61935e8a0edfcd412dd8c8c1d02cb7d310a438a73abb`

````
# Triadic contributor review of RER v0.2 DRAFT r2 — record-by-record scope check

**14 October 2026 · NONCANONICAL review · no adoption.** Reviewed: `RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r2.md` (SHA-256 `3d346b84d63cc25b8a565bb6407bcd5bd674fb0b811b4165fd41e054f762b163`) and `REGISTRY.json` (`888321b962f03b7dda8a5604e3e5763160f8d4ead6a09363be580d9a3494f0ea`), records that import my results or Triadic-side work. Each statement was compared with the source note it pins, not with memory of it.

## 1. Dispositions

| Record | Disposition | Notes |
|---|---|---|
| RER-GEN-C07 | **ACCEPT SCOPED** | Drift, order, "does not refute event-time initialization" all match C07. |
| RER-GEN-C08 | **ACCEPT SCOPED** | Both witnesses (5t⁵/32; κ²t⁹(−1/18, 1/9)) and the "no exclusion of all 2D reachable factors" boundary are right. |
| RER-GEN-C09 | **ACCEPT SCOPED** | Orders 5/9/10 and the non-uniform-in-age domain are stated correctly. One wording point: "Equal parent states have different future Qs" should read "equal parent states of *unequal fixed ages* …" — as written it could be read as a same-age statement. |
| RER-TRIAD-FORMAL-AGE | **ACCEPT SCOPED** | [THM] + `FORMAL_ONLY`, deg_τ ≤ ⌊(d−3)/2⌋, uniqueness only in the polynomial-coefficient class, typed parameterization i(s,τ) with `F∘i = i∘F_param` as formal series — exactly the agreed scope (§§8–9 of my C09 note). The contract type `FORMAL_PARAMETERIZATION_SEMICONJUGACY_NOT_REDUCTION` is the right name. |
| RER-TRIAD-AGE-CURVATURE | **ACCEPT SCOPED** | w₁₃ polynomial, D₅∧R₈ = w₁₃, "a zero of the leading factor is not exact collinearity" — all correct; the "not invariant under arbitrary nonlinear changes of the complete state" guard is the Triadic caveat I accepted. |
| RER-TRIAD-REGULAR-3FOLD | **ACCEPT SCOPED** | Hypotheses (both sheets graphs over a full parent neighbourhood — which follows from DF(0)=I) and the proof sketch are right. Suggest adding to Constraints: "the argument uses only C07's drift and C¹ continuity of D_cH at 0; the same proof covers any pair n ≠ m". |
| RER-ER2B-T6D | **ACCEPT SCOPED** | Modal ΔQ_T^[4] in producer units and the parity argument are quoted correctly; the "descent from its OWN producer remains open" split is exactly what Triadic and I agreed. Suggest naming the symmetry in Transformation law as "edge-slot swap 2↔3 ⇒ F(s,−c) = (F_s, −F_c) exactly", so a reader sees it is a model identity, not an approximation. |
| RER-F3-N7N8 | **ACCEPT SCOPED, with three corrections on my side** (below) | The record's refusal to accept any global K is right; the Stage-1 v2 table is transcribed correctly; the three-box non-cover statement is right. |

## 2. Corrections and withdrawals on the N7/N8 line (my side)

1. **Pilot finding (v) withdrawn.** I wrote that K_perp/K between 0.98 and 1.19 shows "the defect is not predominantly along D₅". A ratio of two *upper bounds* says nothing about the actual direction of 𝓔; the transverse channel is reported, not interpreted, until a lower bound on the transverse fraction exists. The record's sentence to this effect is correct.
2. **Verifier hardening (record contract).** The delivered `triad_stage2_coverage.py` accepted any PASS record with matching hashes. It now validates every published field against the plan and config: exact rational endpoints equal to the planned square and τ-layer; N ∈ N_LIST; K_deg, dps, κ̃ equal to the config; R_floor equal to the ring's inner radius; R_eff ≥ R_floor (to precision tolerance); R_min < R_max; τ+1 interval exact; six step records with parseable fields and last-step ρ_c, λ consistent with the summary; every published constant upward-rounded to ≤ 4 significant digits with K_up ≥ K_raw; duplicates with differing K_raw rejected. Tamper test: a wrong rounding, a wrong endpoint and a five-step record are each rejected for the named reason while genuine records pass. New SHA `ed19d7139c5a2e96c7a6d526db7692f448398ca1ecfb81fc8f416e3b4b5e1ac5`.
3. **Directed serialisation.** Published decimals were produced by round-to-nearest (`nstr`). Engine v3.1 (`triad_tm_engine_v3_1.py`, SHA `674961ccd19b48653c40f5698668f21d832f1d948a91259eb36d1a639694e17e`; arithmetic unchanged, only the serialisation of step records and τ+1 now exact/directed) and driver v2 (SHA `cb26b2e427e323bbc128f01032c232cfb9c00f3c951379dc01ebc43905a41276`) now convert each interval endpoint exactly (dyadic mpf → Fraction → Decimal) and round upper bounds up and lower bounds down. The config's engine field points to v3.1; the config hash therefore changes and prior records (pilot) do not validate against it, by design.
4. **K = 8 pilot file.** The container was reset between sessions and the background K = 8 run was lost; it is rerunning on engine v3 (its hash is recorded in each line) and the complete `stage2_pilot_K8.jsonl` will be supplied as an informational file, not as records of the governing config.

## 3. Points for the registry editor
- RER-F3-N7N8 "the delivered verifier accepted invalid PASS contracts in the source review" — I have not received `STAGE2_RECEIVING_REVIEW.md` (SHA `c935a4ac…d4e2`) itself; the hardening above addresses the summary in r2. If the review lists further failure modes, send it and I will add them to the tamper test.
- The TM-lemma independent review (product truncation, Lagrange remainders, remainder transport through A⊕A, post-map Lipschitz radius) remains the gate before any `CONTROLLED_APPROXIMATE_CLOSURE` record; nothing here changes that.
- Work-queue item P1 "historical lifted generator → own root diagnostic" is Triadic-internal and I can take it after the pilot; it does not depend on anything in this review.

No owner document, RER record or physical selection is changed by this review.
````

## RER-F3-N7N8

RER r4.12 lines 700–770; span SHA-256 `de6595fede6be33a76f94758eec412635dd9375149cfcdfcfac9976170a489d8`. Byte-identical to r4.6 (lines 698–768): yes; B-05 inventory span SHA-256 `e7f4aec25903d662f10261a52c5563f689fe1710f1092d96d0c9c079cbf9fd89`.

### Record text (verbatim)

```
### RER-F3-N7N8 — Finite-jet defects and separate local/global certificate gates
**Primary grade:** [ALG]. **Exactness:** `FINITE_ORDER`. **Task:** `GLOBAL_CERTIFICATE_PENDING`. **Registry/owner adoption:** pending / none.

| Field | Contract |
|---|---|
| Carrier | (s,tau) on polynomial C_N graph, N=7 or 8; kappa_tilde=1; GEN-CONDITIONAL-MODAL-REPROJECT-EACH-STEP; profile UNREGISTERED_CONDITIONAL_OR_ABSTRACT_NO_PROFILE_CREATED. |
| Observables | E_N child defect in B norm; Qs; Isc; OmegaG; B-orthogonal transverse defect |
| Constraints | Physical kappa/age not selected; 6 primitive modal compositions, not 36 sequential steps; R=\|s\|_2; R^2/2<=Qs<=3R^2/2; tau+1 and all intermediate states must be bounded. |
| Transformation law | Each child defect is evaluated at the same computed s_plus. Delta Qs=0 in that one-step comparison is not multi-step Qs accuracy. |
| Closure status | FINITE_ORDER_VERIFIED_LOCAL_BOUND_REPORTED_INFRASTRUCTURE_REPLAYED_GLOBAL_PENDING: Formal E7/E8 expansions and repaired Stage1 local box reports are retained. The complete Stage2 replay bundle now supplies the current driver, coarse K=4 configuration and 104 worker rows. The unchanged 41-expectation suite passes in an isolated receiving rerun, including one coarse retry test; the workers and pilots are not regenerated. All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N); K=8 remains stopped at 1/8 under its separate config. Independent Taylor-model lemma review and governing full-domain coverage remain OPEN; no global controlled approximate closure is accepted. |
| Memory | Finite-jet approximation error is not a physical forgetting/retention measurement. Zero one-step parent error is a construction artifact, not multi-step accuracy. Use the stated observation task and source contract; no memory/age carrier added. |

**r4.2 current-use overlay (RER-F3-N7N8):** the Closure-status cell of the contract table above is the preserved r3.1 snapshot and is not edited; for current use, a scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026), the per-stage guard a ≤ 1 is to be enforced in the shared record contract, and governing coverage, regional constants and global certification remain OPEN.
[ALG] **FINITE_ORDER.** Formal E7/E8 expansions and repaired Stage1 local box reports are retained. The complete Stage2 replay bundle now supplies the current driver, coarse K=4 configuration and 104 worker rows. The unchanged 41-expectation suite passes in an isolated receiving rerun, including one coarse retry test; the workers and pilots are not regenerated. All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N); K=8 remains stopped at 1/8 under its separate config. A scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026; per-stage guard a ≤ 1 pending installation); governing full-domain coverage remains OPEN; no global controlled approximate closure is accepted.
Formula/witness: `E_N=F_c(s,C_N(s,tau))-C_N(F_s(s,C_N(s,tau)),tau+1)`.

[NUM] **SAMPLED_ONLY.** 24-direction, five-age pointwise defect/|D5| maxima support a limited small-amplitude comparison; no continuous-domain supremum or optimality claim.

**Domain / admissibility:** Proposed full region 0.03<=R<=0.08, 0<=tau<=2, successor age in [1,3]; three source-reported Stage1 boxes are NOT a cover.

**Map / clock:** `source F=N^6 : V2 -> V2`; F=N^6, each primitive step reprojects.

**Factor or parametrization tested:** NOT_PROPOSED_REDUCTION; use typed i_N and F_param,N below.

**Order / error:** E7 starts degree 8; E8 starts degree 9. E7=Delta_tau C8+Delta_tau C9+O(R^10); E8=Delta_tau C9+O(R^10). No certified whole-region K7,2 or K8,2 accepted.

**Contract type:** `APPROXIMATE_PARAMETERIZATION_DEFECT_NOT_EXACT_FACTOR`.

**Typed parameterization:** `i_N(s,tau)=(s,C_N(s,tau))`; `F_param,N(s,tau)=(F_s(s,C_N(s,tau)),tau+1)`.
Compatibility: `F o i_N - i_N o F_param,N = (0,E_N)`. C_N is polynomial; exact F analytic; quantitative full-domain certificate pending.

**Evidence:** original scientific source pins and earlier verification scopes are retained from r2. R3 checks the changed source/wording interfaces and separate Stage-2 metadata behavior; no historical mathematical certificate is rerun.

**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending. [TRIAD_R2_REVIEW: Triadic contributor review of RER v0.2 DRAFT r2 — record-by-record scope check](sources/current/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md); lines 1–30; RID unavailable; exact section pinned; SHA-256 `d388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab`.
Import/reference: [N7REVIEW: 2. [ALG, formal] Correct leading compatibility defect](sources/current/N7_N8_RECEIVING_REVIEW.md); lines 21–31; RID unavailable; exact section pinned; SHA-256 `4fc7edcda7bcef01f255ea97292cda0aab0eb76eeaee53c43247fe3dc0d5e85d`.
Import/reference: [N7REVIEW: 4. [COR] Proper pointwise age-resolution normalization](sources/current/N7_N8_RECEIVING_REVIEW.md); lines 43–58; RID unavailable; exact section pinned; SHA-256 `4fc7edcda7bcef01f255ea97292cda0aab0eb76eeaee53c43247fe3dc0d5e85d`.
Import/reference: [N7REVIEW: 5. [COR] Q_s-error zero is a constructed one-step comparison](sources/current/N7_N8_RECEIVING_REVIEW.md); lines 59–71; RID unavailable; exact section pinned; SHA-256 `4fc7edcda7bcef01f255ea97292cda0aab0eb76eeaee53c43247fe3dc0d5e85d`.
Import/reference: [TM2NOTE: 6. [COR] Proof-contract repair on Triadic receiving audit (13 Oct, afternoon) — governing stage-1 results](sources/current/TRIAD_F3_FINITE_JET_CONTROL_STAGE1_20261013%20%281%29.md); lines 46–65; RID unavailable; exact section pinned; SHA-256 `ed95be3be3b7eb1e36290179b96bf5a2be2d4351a260b0c7246ccba9b2abfef1`.
Import/reference: [TMREVIEW: Complete source/record (bounded note or machine artifact)](sources/current/STAGE2_RECEIVING_REVIEW.md); lines 1–46; RID unavailable; exact section pinned; SHA-256 `c935a4aca063b59099fbc9bf4052b5d50c6a1782ec755b80f5b8594d4876d4e2`.
Import/reference: [POLY: Complete source/record (bounded note or machine artifact)](sources/current/age_family_polynomials_kt1.json); lines 1–364; RID unavailable; exact section pinned; SHA-256 `03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c`.
Import/reference: [S2ENGINE32: !/usr/bin/env python3](sources/current/STAGE2_V32/triad_tm_engine_v3_2.py); lines 1–263; RID unavailable; exact section pinned; SHA-256 `7d4e8ec24e75c35bd8296121425b56e28049efd5846b6a932b7e2f64a6716716`.
Import/reference: [S2CONTRACT: !/usr/bin/env python3](sources/current/STAGE2_V32/triad_stage2_contract.py); lines 1–169; RID unavailable; exact section pinned; SHA-256 `8af038c85241d889b8f50d7e5da18cf8a1b572d6e8f544d3efc1080ab811746c`.
Import/reference: [S2COVERAGE3: !/usr/bin/env python3](sources/current/STAGE2_V32/triad_stage2_coverage.py); lines 1–53; RID unavailable; exact section pinned; SHA-256 `a298cf467799ee1f5bcab726870f0424f6864e1e922ab98ef28f508b6e4e9968`.
Import/reference: [S2REGCODE: !/usr/bin/env python3](sources/current/STAGE2_V32/triad_stage2_regression.py); lines 1–133; RID unavailable; exact section pinned; SHA-256 `2802f97bd28871412bcef6e716cfb1a9bcd7ae251d8b203bcf87912320e44e2a`.
Import/reference: [S2REGREPORT: {](sources/current/STAGE2_V32/stage2_REGRESSION_RESULTS.json); lines 1–213; RID unavailable; exact section pinned; SHA-256 `0babe8b5ba5cee6cb795815246b78e9a5e63b9b0c0865a8e963cecb218a5fd6c`.
Import/reference: [S2CFG32: {](sources/current/STAGE2_V32/stage2_config.json); lines 1–20; RID unavailable; exact section pinned; SHA-256 `dce1d569fb7e5eaa01c49795a4f171f578d055ec6c8f37422e0e8b783b6942fc`.
Import/reference: [S2FOLLOWUP: RER r2 review receipt and Stage-2 follow-up](sources/current/STAGE2_FOLLOWUP_RECEIVING_RESPONSE_20261014.md); lines 1–134; RID unavailable; exact section pinned; SHA-256 `a613f58908eeee1bf5c29a933cf977fcdff0c15332524119b14b6d0c305813b5`.
Import/reference: [R3_REQUEST: Current contributor instructions and reported status — 14 October 2026](sources/current/R3_REQUEST_AND_STATUS_RECEIPT.md); lines 1–11; RID unavailable; exact section pinned; SHA-256 `472f5a38cb52c10f20194c1a1e2b8faceb08e381285129b5d83e66f4f779aaa8`.

**Reported Stage1 v2 local constants, not a region certificate:**
| Box centre (r,e,tau) | K7 | K8 |
|---|---:|---:|
| 0.0325, 0, 0.05 | 3.246 | 56.18 |
| 0.0325, 0, 1.95 | 3.182 | 46.82 |
| -0.023, 0.023, 0.05 | 2.234 | 522.7 |
Half-widths: s coordinates 0.0025; tau 0.05; kappa_tilde=1. Governing status: source-reported repaired-v2 boxes; NOT the withdrawn v1 constants. No global K7,2/K8,2 accepted. Third box straddles the proposed inner-radius boundary; three boxes do not cover the annulus.

**Stage2 gates:** 904 planned boxes per N remain the governing plan. The delivered driver, coarse config and worker files now pass the original 41-suite. K=4 coarse coverage (52/52 per N) has a distinct config identity and is not governing coverage. K=6 pilot: 8/8 validated rows, only 4/904 boxes per N. K=8 pilot: 1/8 received, stopped, separate config. Aggregate pilot checks correctly exit 1 as PARTIAL. The ratio of upper bounds does not identify the actual transverse fraction. The scoped TM lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026); the per-stage guard a ≤ 1, regional and global constants remain OPEN.
[ALG] Infrastructure evidence update only: supplied current-driver/worker replay completed, 41/41 expectations pass. This closes the access qualification, not the Taylor-model proof gate.
[OPEN] Taylor-model regional certificate. The independent lemma review has been performed by the receiving co-owner (19 Oct 2026, `STAGE2_TM_LEMMA_REVIEW_20261019.md`; RECEIVER-REPORTED, not in this package): remainder transport through the six primitive stages, the post-map s^+ enclosure and directed publication are supported under its scoped contract (pinned coefficient table, centred constructor, reviewed precision profile, per-stage enlarged edge bound 0 ≤ a ≤ 1); 9/9 stored centre bounds independently enclosed and 10/10 directed-serialization checks PASS. The derivative-domain guard a ≤ 1 is not enforced by the engine and must be enforced or verified per stage before any regional certificate. Regional K_N and global certification remain OPEN
[OPEN] independent review of a future end-to-end governing-region certificate (distinct from the scoped one-step Taylor-model lemma review, which is reported completed: RECEIVER-REPORTED, 19 Oct 2026) and separately authorized full governing-region work; K=6 pilot subset is complete, K=8 remains stopped
[OPEN] multi-step state and observable errors
[OPEN] actual analytic convergence

**Next test:** (r4.2 current use; first recorded in r4.1) The scoped lemma review is done (receiving co-owner, 19 Oct); next, enforce or verify the per-stage derivative-domain guard a ≤ 1, followed by separately authorized governing full-region work. K=6 pilot subset is complete; K=8 remains stopped. No new series coefficients, physical selections or pilot/sweep restart are requested by this evidence update.

**Non-transfer:** No new independent state datum, physical emergence, compulsory historical memory, or physical age variable is established. No automatic RRF registration, universal model exclusion or scientific-owner adoption.

**R3.1 evidence pins:** [Replay execution](evidence/STAGE2_REPLAY/records/FRESH_REGRESSION_EXECUTION.json), [received-row validation](evidence/STAGE2_REPLAY/records/RECEIVED_RECORD_VALIDATION.json), [source package](sources/current/STAGE2_REPLAY_20261014.zip), [four-record r3 acceptance receipt](data/R3_CONTRIBUTOR_ACCEPTANCE.json). These are implementation replays and receipt checks, not new independent proofs.

**Archive qualification:** All 19 non-manifest payload hashes match. The supplied SHA256SUMS.txt self-entry is stale; the original is preserved with its actual hash in the detached receiving receipt. No source payload is repaired or reidentified.
```

### Imports (Phase A r17)

| n | Key | Cited | Section / lines | Bytes | Authentication | Currency | Status |
|---|---|---|---|---|---|---|---|
| 0 | `N7REVIEW` | 2026-10-10 `4fc7edcda7bc` | 2. [ALG, formal] Correct leading compatibility defect [21, 31] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 1 | `N7REVIEW` | 2026-10-10 `4fc7edcda7bc` | 4. [COR] Proper pointwise age-resolution normalization [43, 58] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 2 | `N7REVIEW` | 2026-10-10 `4fc7edcda7bc` | 5. [COR] Q_s-error zero is a constructed one-step comparison [59, 71] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 3 | `TM2NOTE` | with v2 correction `ed95be3be3b7` | 6. [COR] Proof-contract repair on Triadic receiving audit (13 Oct, afternoon) — governing stage-1 results [46, 65] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 4 | `TMREVIEW` | 2026-10-13 `c935a4aca063` | Complete source/record (bounded note or machine artifact) [1, 46] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 5 | `POLY` | kappa_tilde=1 / through degree 9 `03042f84016a` | Complete source/record (bounded note or machine artifact) [1, 364] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 6 | `S2ENGINE32` | 14 Oct 2026 delivered triad_tm_engine_v3_2.py `7d4e8ec24e75` | !/usr/bin/env python3 [1, 263] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 7 | `S2CONTRACT` | 14 Oct 2026 delivered triad_stage2_contract.py `8af038c85241` | !/usr/bin/env python3 [1, 169] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 8 | `S2COVERAGE3` | 14 Oct 2026 delivered triad_stage2_coverage.py `a298cf467799` | !/usr/bin/env python3 [1, 53] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 9 | `S2REGCODE` | 14 Oct 2026 delivered triad_stage2_regression.py `2802f97bd288` | !/usr/bin/env python3 [1, 133] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 10 | `S2REGREPORT` | 14 Oct 2026 delivered stage2_REGRESSION_RESULTS.json `0babe8b5ba5c` | { [1, 213] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 11 | `S2CFG32` | 14 Oct 2026 delivered stage2_config.json `dce1d569fb7e` | { [1, 20] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 12 | `S2FOLLOWUP` | 14 Oct 2026 earlier receiving review `a613f58908ee` | RER r2 review receipt and Stage-2 follow-up [1, 134] | BYTE_VERIFIED_MATCH | BYTE_VERIFIED_HERE | ARTIFACT_PINNED | VERIFIED |
| 13 | `R3_REQUEST` | 14 Oct 2026 current user communication `472f5a38cb52` | Current contributor instructions and reported status — 14 October 2026 [1, 11] | PRINTED_ONLY | HASH_PRINTED_UNVERIFIED | ARTIFACT_PINNED | HISTORICAL |

### Proof material and provenance

| Item | Where | Provenance |
|---|---|---|
| N7REVIEW §2 (leading compatibility defect), §4 (normalization), §5 (Q_s-error zero) | X-N78-2 | HELD (4fc7edcd…5e85d); "noncanonical receiving audit" (its own header); author not named |
| N = 7/8 jet-defect script (de367595…d9a3) and its revision (5c63c363…7c82) | X-N78-5 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in N7REVIEW / CURVNOTE; numerical grid estimate per its own docstring ("NOT a certified bound") |
| pointwise metric checker check_pointwise_metrics.py (61a54f0a…f0b) | cited in CURVNOTE §11 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in CURVNOTE |
| stage-1 note TM2NOTE §6 (governing v2 local box results) | X-N78-8 | HELD (ed95be3b…fef1); "Triadic contributor deliverable" (its own header) |
| repaired stage-1 engine triad_tm_onestep_certificate_v2.py | X-N78-9 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in TM2NOTE §6; needs mpmath and the polynomial JSON; not rerun by the preparer |
| stage-1 v1 engine (2ce13564…6e5f) and logs | X-N78-6 | NOT_HELD — identity as stated in the record or its source; bytes not in this packet |
| Stage-2 receiving review | X-N78-10 | HELD (c935a4ac…d4e2); "receiving review" (its own header); author not named |
| κ̃ = 1 age-family table | POLY | HELD (03042f84…d83c); the N = 7/8 script regenerates it (preparer run below) |
| Stage-2 engine v3.2, contract, coverage v3, regression code, regression report, governing config | S2* imports | HELD (hashes as in the record); "RECEIVED_INFRASTRUCTURE_NOT_MATHEMATICAL_CERTIFICATE" (RER source table) |
| Stage-2 follow-up receiving review (14 Oct) | X-N78-11 | HELD (a613f589…13b5); "Noncanonical receiving review" (its own header) |
| Stage-2 replay bundle (driver, coarse config, 104 worker rows, K=6/K=8 pilot rows) and README | X-N78-12 | HELD support file (preparer session copy); its SHA-256 equals the hash cited in the RER R3.1 source table (S2REPLAY_ZIP, S2REPLAY_README) |
| R3.1 replay receipts (FRESH_REGRESSION_EXECUTION, RECEIVED_RECORD_VALIDATION, ARCHIVE_VERIFICATION) and R3_CONTRIBUTOR_ACCEPTANCE | R3.1 evidence pins | NOT_HELD — identity as stated in the record or its source; bytes not in this packet; per the record, receiving-side rerun records |
| scoped Taylor-model lemma review STAGE2_TM_LEMMA_REVIEW_20261019.md (19 Oct) | [OPEN] line | RECEIVER-REPORTED as stated in the record; NOT_HELD — identity as stated in the record or its source; bytes not in this packet; it is the receiver's own earlier work |
| R3_REQUEST_AND_STATUS_RECEIPT.md (472f5a38…aaa8) | Import/reference R3_REQUEST | NOT_HELD — identity as stated in the record or its source; bytes not in this packet (Phase A r17: PRINTED_ONLY, HASH_PRINTED_UNVERIFIED; "USER_REPORTED_NOT_ENGINE_RECEIPT" in the RER source table) |
| review receipt: r2 contributor review (record row and §2 "on my side") | X-N78-13 | HELD (d388d7eb…e1ab); the reviewer writes "Corrections and withdrawals on the N7/N8 line (my side)"; the receiver lists this record as author-conflicted (B-07 decision file) |

### Questions for the receiver (no answer is implied)

- **Q-N78-1** (formal leading orders): Order/error: "E7 starts degree 8; E8 starts degree 9. E7=Delta_tau C8+Delta_tau C9+O(R^10); E8=Delta_tau C9+O(R^10)". N7REVIEW §2 (X-N78-2) is titled "[ALG, formal] Correct leading compatibility defect"; the jet-defect script (X-N78-5) reports a numerical grid estimate and a convergence test of E_N against Δ_τ C_{N+1}. Which held source gives the formal derivation, and is the record's [ALG] for the expansions based on it?
- **Q-N78-2** (Q_s range): Constraints: R = |s|_2, R²/2 ≤ Q_s ≤ 3R²/2. N7REVIEW §3 (inside X-N78-2) says the stated Q_s ranges used "an incorrect Euclidean-radius bound". Does the record's inequality match the corrected form there?
- **Q-N78-3** ([NUM] sampled line): The [NUM] SAMPLED_ONLY line cites 24-direction, five-age pointwise defect/|D5| maxima and disclaims any supremum. Compare with N7REVIEW §4 (normalization) and the pointwise checker (cited in CURVNOTE §11). Is the line scoped as the source scopes it?
- **Q-N78-4** (one-step Q_s comparison): Transformation law and Memory say ΔQ_s = 0 in the one-step comparison is a construction artifact, not multi-step accuracy (N7REVIEW §5). Is this kept apart from any accuracy claim in the record?
- **Q-N78-5** (stage-1 local constants): The record's table gives "Reported Stage1 v2 local constants, not a region certificate" for three boxes, with "Governing status: source-reported repaired-v2 boxes". TM2NOTE is titled "certified one-step defect bounds" and its §6 names the repaired engine (X-N78-9, held, not rerun here). Which grade, if any, does the receiver attach to the three local constants, and does the record attach one?
- **Q-N78-6** (Taylor-model lemma and guard): The [OPEN] line reports the receiver's own scoped Taylor-model lemma review (19 Oct; not in this packet) and says the derivative-domain guard a ≤ 1 "is not enforced by the engine". Is the record's statement of that review and of the guard as the receiver intends?
- **Q-N78-7** (Stage-2 infrastructure): The record states: 41/41 infrastructure expectations in an isolated receiving rerun; K=6 pilot 8/8 rows, 4/904 boxes per N; K=8 1/8, stopped; aggregate checks exit 1 as PARTIAL. The held replay bundle reproduces the regression and the K=6 coverage output in the preparer timing runs below (scheduling only). Is the separate [ALG] line "Infrastructure evidence update only …" appropriate as a claim-tagged line, given that it states infrastructure facts?
- **Q-N78-8** (grade attachment of the main claim line): The [ALG] FINITE_ORDER claim line combines (a) formal E7/E8 expansions, (b) retained local box reports, (c) the Stage-2 replay and pilot status and (d) the lemma-review status. Which of (a)–(d) carry the [ALG] grade, and should the others be stated as evidence status rather than graded claims?
- **Q-N78-9** (non-held items): Not in this packet: the R3.1 replay receipts and contributor acceptance, R3_REQUEST (user-reported), the stage-1 v1 engine and logs, the lemma review. Does the receiver need any of them for this decision?
- **Q-N78-10** (receipts and author relation): The r2 review row for this record reads `ACCEPT SCOPED, with three corrections on my side` and the review lists corrections to "the N7/N8 line (my side)" (X-N78-13); several held sources describe themselves as receiving reviews without naming an author. How does the receiver weigh these receipts for this record?

### Source extracts (verbatim)

#### X-N78-1 — N7REVIEW header and §1 (model and independent replay)

`sources/triad/N7_N8_RECEIVING_REVIEW.md` lines 1–19; extract SHA-256 `792010dbbc8078a5cc06076964beb48f9df8754ee3228fbe55e5c14a35daef58`

````
# Triadic / Genesis — F3 finite-jet N=7/8 receiving review

**Status:** noncanonical receiving audit, 2026-10-10. **Sources:** the exact four uploaded files reproduced under `source/`; no adopted Genesis, Triadic, RRF or RER owner document modified. 

## 1. Model and independent replay

The script explicitly builds the Genesis→RER *conditional analytic modal* map by applying `T_e(r,e)=(r-sin(e),e+expm1(r)-sin(e))` to the three incidence edges with projection after each of six primitive steps. It does **not** represent a physically selected standalone K3 birth event. Its series dependency `c09_independent_series_check_rev2.py` has SHA-256 `67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b`, and the supplied finite-jet script has SHA-256 `de3675953013d3a1e83227a46565708b16068314974bf81ad142a3f42034d9a3`.

In a separate source layout, the finite-jet script reproduced `age_family_polynomials_kt1.json` **byte-identically**, SHA-256 `03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c`. Its 4 visible PASS checks and its empirical grid match the uploaded log. The `--negative` mode exits 1 as intended at the N=7 leading-defect control, rather than at a missing dependency. Run logs are preserved under `evidence/`. The script's 4 PASS lines are bookkeeping/model checks, not four independent mathematical proofs.

The exact interpolated homogeneous polynomials verify, in the binomial-age basis at `kt=1`,

\[
[\binom{\tau}{1}]\mathcal C_5=-\tfrac12 Q_s^2s,\qquad
[\binom{\tau}{2}]\mathcal C_7=\tfrac14 Q_s^3s,\qquad
[\binom{\tau}{3}]\mathcal C_9=-\tfrac3{16}Q_s^4s.
\]

These three identities hold as full polynomials in `(r,e)`. Extrapolating them to a general coefficient family remains `[CAND]`; they do not establish convergence or a finite radius.
````

#### X-N78-2 — N7REVIEW §2–§5 (cited: §2 lines 21–31, §4 lines 43–58, §5 lines 59–71; §3 included for the Q_s range)

`sources/triad/N7_N8_RECEIVING_REVIEW.md` lines 21–70; extract SHA-256 `0827e3ac613c1a0d0227c4506739b8ad847b4e82dcb0308c95a63b592582cb68`

````
## 2. [ALG, formal] Correct leading compatibility defect

With `C_N` the age-family truncation and `E_N=F_c(s,C_N(s,tau))-C_N(F_s(s,C_N(s,tau)),tau+1)`, the full formal invariance and `F=id+O(3)` imply for bounded fixed `tau`:

\[
\mathcal E_7=\Delta_\tau\mathcal C_8+\Delta_\tau\mathcal C_9+O(\|s\|^{10}),\qquad
\mathcal E_8=\Delta_\tau\mathcal C_9+O(\|s\|^{10}),
\]

where `Delta_tau f=f(tau+1)-f(tau)`. The omitted coefficient contributes at both the domain and codomain ends; replacing this by `-C_(N+1)(tau+1)` is incorrect. The `O(...)` statements have no explicit numerical constant and are **not** yet certified uniform error bounds.

## 3. [COR] The stated Q_s ranges use an incorrect Euclidean-radius bound

The script samples `s=R(cos(theta),sin(theta))` and computes `Q_s=r^2-re+e^2`. Therefore, **exactly**:

\[
Q_s=R^2\left(1-\tfrac12\sin(2\theta)\right),\qquad
\boxed{\tfrac12R^2\le Q_s\le\tfrac32R^2.}
\]

Both extrema occur on the stated 24-angle grid. The script's printed `Q_s~[0.75R^2,R^2]` is **not** the sampled range. At `R=0.12` the actual range is `[0.0072,0.0216]`; at `R=0.25` it is `[0.03125,0.09375]`. The reports' downstream `Q_s`-threshold language must not be treated as certified or read from the incorrect column.

## 4. [COR] Proper pointwise age-resolution normalization

The code's printed age-resolution ratio `sup|E_N|/(R^5/2)` is **not** `sup |E_N|/|D_5(s)|`, since the exact age-sheet drift is `D_5(s)=-(1/2)Q_s^2s`. Consequently `|D_5(s)|=(1/2)Q_s^2R`, which varies with direction.

An independent grid evaluation against the same *untruncated* analytic map, using the same 24 angles, five ages and radii, gives the following **empirical (not upper-certified)** values:

| Euclidean `R` | `max_grid |E_7|/|D_5|` | `max_grid |E_8|/|D_5|` | `max_grid |E_8|/max_grid |E_7|` (separate maxima) |
|---:|---:|---:|---:|
| 0.03 | 0.0000972 | 0.0000429 | 0.441 |
| 0.08 | 0.00309 | 0.00225 | 0.729 |
| 0.12 | 0.0137 | 0.0118 | 0.863 |
| 0.18 | 0.0621 | 0.0631 | 1.016 |
| 0.25 | 0.216 | 0.252 | 1.168 |

The last column is the ratio of the separate maximal absolute defects, not a pointwise defect ratio. Thus at R=0.12 the true *grid-pointwise* normalisation is about 1.4% and 1.2%, compatible with a rough 1% description but different from the reported nominal 3.1% and 2.7% based on the fixed `R^5/2` divisor. At `R=0.25`, the correct grid-pointwise maxima are about 22% and 25%, not 49% and 57%. The eighth-degree jet improves the measured **absolute** child defect for radii through approximately 0.12, loses its advantage near 0.18, and is worse at 0.25. None of these grid maxima are certified `K_(N,T)` over the full compact domain.

## 5. [COR] Q_s-error zero is a constructed one-step comparison

For the two states compared in the script, the parent `s+ = F_s(s,C_N)` is identical on both sides; only the target child is replaced by `C_N(s+,tau+1)`. Hence the printed `Q_s` difference is **exactly zero by design**. This establishes no direct one-step error for the parent observable only in that particular projected comparison. It is **not** an accuracy result for a reduced parent-only evolution or a multi-step physical trajectory.

Writing `E=F_c(s,C_N)-C_N(s+,tau+1)`, the *true one-step observable differences* in the script satisfy exactly

\[
\Delta I=B(s^+,E),\qquad
\Delta\Omega_G=\frac{\sqrt3}{2}(s^+_\eta E_\rho-s^+_\rho E_\eta),\qquad \Delta Q_s=0.
\]

For the primitive `B=[[1,-1/2],[-1/2,1]]`, this gives `|Delta I| <= (3/2)|s+||E|` and `|Delta Omega_G| <= (sqrt(3)/2)|s+||E|`. Parent prediction errors can emerge after subsequent steps through backreaction; they require a true iterative comparison and separate bounds.
````

#### X-N78-3 — N7REVIEW §6 statements not certified, §7 recommended next gate

`sources/triad/N7_N8_RECEIVING_REVIEW.md` lines 72–86; extract SHA-256 `dcfe8127ba9ebd330e627a2621a8e635b214972010ecd8cf3b6d8f8c86c6e26a`

````
## 6. Statements not certified

- The numeric suprema are grid maxima over `kt=1`, 24 angles, 5 ages in `[0,2]` and 8 Euclidean radii, evaluated with 50-digit `mpmath`. No interval enclosure or analytic majorant over the continuous region was used. 
- `~25x` growth in empirical coefficient sizes is a heuristic diagnostic; two degrees do not establish any positive, zero or finite radius of convergence. A radius `<=0.04` cannot be certified from this evidence.
- There is no uniform bound as the age horizon increases, no proof of model/physical selection, no long-time observable factor certificate and no memory/physical clock selection.

## 7. Recommended next gate

1. Select an explicit compact `R_min<=|s|<=R_max`, `tau in [0,T]`, including the `tau+1` evaluation and all six intermediate primitive states. Keep `kt=1` for the initial certificate and label the parameter scope.
2. Establish **certified** upper bounds on the polynomial contributions `Delta_tau C_8`, `Delta_tau C_9` and on analytic remainders of `sin` and `expm1` in the full six-step map; derive explicit `K_7(T,R)` and `K_8(T,R)`, not only sample maxima.
3. Separately bound the transverse (relative to the B-metric `D_5` direction) component of `C_8`, and distinguish this from the earlier age-fibre `w_13` curvature invariant.
4. Prove an invariance/retention condition on the chosen region before iterating the standard Lipschitz recurrence; track real true-vs-approximate `Q_s,I,Omega_G` errors over steps.
5. Keep the `[THM — formal]` age-family result, C09 geometry and empirical defect study in distinct RER evidence records. No modification to Genesis v2.8.5 or Triadic v1.6.

**Receiving disposition:** `[ALG]` coefficient and asymptotic-defect mathematics ACCEPT; numeric comparison ACCEPT at **sampled-grid** scope; **Q range and age-resolution table NEED CORRECTION**; explicit constant / multi-step / convergence / physical interpretation OPEN.
````

#### X-N78-4 — CURVNOTE §10–§11 (contributor first pass on N = 7/8 and its corrections)

`sources/triad/RER_C09_INDEPENDENT_VERIFICATION_20261009 (6).md` lines 128–182; extract SHA-256 `7f8d1ffcb2b1220ac13534d23e9028df6bdefc74a21f991701f61f3cad167455`

````
## 10. Finite-jet compatibility defect, N = 7 and N = 8 (10 Oct) — first pass at the Triadic error contract

Files: `triad_finite_jet_defect_N7_N8.py` (SHA `de3675953013d3a1e83227a46565708b16068314974bf81ad142a3f42034d9a3`; 4 PASS, exit 0; `--negative` drops 𝒞₇ and exits 1), its log, and `age_family_polynomials_kt1.json` (SHA `03042f84…d83c`). κ̃ = 1 only.

**A. Exact all-direction 𝒞_d, d = 3…9.** Reconstructed from exact ray series of the full map (d+1 rational rays per degree, ages 0…⌊(d−3)/2⌋), checked against an unused ray and against the closed forms of D₅ and B₇. This supplies D₇, D₈, D₉ and all n²/n³ terms without a quintic jet. τ-degrees are exactly ⌊(d−3)/2⌋ at every d.

**B. [COR to my own draft of this study] Leading defect.** Because ∂_cF_c = I + O(‖X‖²), the omitted order enters at both ends of the step, and

\[
\mathcal E_N(s,\tau)=\Delta_\tau\mathcal C_{N+1}(s,\tau)+\Delta_\tau\mathcal C_{N+2}(s,\tau)+O(\|s\|^{N+3}),\qquad \Delta_\tau f(\tau)=f(\tau+1)-f(\tau),
\]

not −𝒞_{N+1}(s,τ+1) as I first wrote. Confirmed against the real map at 50 digits: N=8 deviates 0.28 % from Δ_τ𝒞₉ at |s| = 0.003; N=7 deviates 0.055 % from the two-term prediction. In the binomial basis Δ_τ removes the age-independent part, so Δ_τ𝒞₈ = D₈ + τB₈ and Δ_τ𝒞₉ = D₉ + τB₉⁽²⁾ + C(τ,2)B₉⁽³⁾.

**C. Empirical constants (grid: 24 directions × τ ∈ {0, ½, 1, 3/2, 2} × 8 radii; not certified bounds).**

| |s| | Q_s range | sup|𝓔₇|/|s|⁸ | sup|𝓔₈|/|s|⁹ | sup|𝓔₇|/|D₅| | sup|𝓔₈|/|D₅| |
|---|---|---|---|---|---|
| 0.003 | 7–9 ·10⁻⁶ | 2.51 | 58.4 | 1.4·10⁻⁷ | 7·10⁻⁹ |
| 0.03 | 0.0007–0.0009 | 4.05 | 59.6 | 2.2·10⁻⁴ | 1.0·10⁻⁵ |
| 0.12 | 0.011–0.014 | 8.90 | 64.0 | 0.031 | 0.019 |
| 0.25 | 0.047–0.063 | 15.6 | 72.7 | 0.49 | 0.57 |

Three readings. (i) The N=8 jet is **not** better than N=7 at |s| ≳ 0.2: the degree-9 coefficient (sup ≈ 58) is ≈ 25× the degree-8 one (≈ 2.3), so at |s| ≈ 0.04 successive orders are already comparable; the asymptotic regime for the N=7 contract is |s| ≲ 0.01. (ii) Measured against the inter-age separation |D₅| = ½Q²|s| (the quantity that decides whether the family resolves age at all), the one-step defect is ≈ 1 % at |s| = 0.12 and ≈ 50 % at |s| = 0.25 for both N. So for τ ≤ 2 the finite-jet family is age-resolving only for Q_s ≲ 0.01–0.02 — this is the quantitative content of the "no uniform-in-age control" caveat. (iii) The 25× growth between d = 8 and d = 9 is the first hint on the convergence question; if it persists the formal series has radius ≲ 0.04 in |s|, but two orders are far too few to claim that. More orders (d = 10, 11) with the same reconstruction would settle whether the ratio is stable.

Observables: Q_s error is identically zero by construction (same s⁺ on both sides); I_sc and Ω_G errors are 2–6·10⁻⁵ at |s| = 0.25 and 10⁻¹⁴ at |s| = 0.03.

**D. [CAND] Closed form of the top-age-degree coefficients.** At s-degree 2k+3 the τ-degree-k coefficient is, for k = 1, 2, 3,

\[
P_{2k+3,k}(s) = -\tfrac12\binom{-1/2}{\,k-1\,}\,Q_s^{\,k+1}\,s \qquad(-\tfrac12 Q^2 s,\ \tfrac14 Q^3 s,\ -\tfrac{3}{16} Q^4 s),
\]

all along s, with κ̃ = 1. Three data points only; if it continues, the radial part of the age dependence resums to Σ_k C(τ,k) C(−½,k−1) Q^{k−1}, a hypergeometric-type function of (τ, Q) — which is exactly the regime τQ ~ 1 where fixed-age asymptotics fail. Worth one more order before anyone leans on it.

Scope unchanged: conditional model, formal family, empirical grid; no certified K_{N,T}, no multi-step accumulation, no physical clock or memory.

## 11. [COR] Corrections to §10 on Triadic receiving review (10 Oct, evening)

Receiving review `N7_N8_RECEIVING_REVIEW.md` and `check_pointwise_metrics.py` (SHA `61a54f0a29a786941ee283bc52a7a2274de0d8a4f7101eea03c6f2ef37eadf0b`) reproduced here against the unchanged polynomial table; all five rows agree. Three corrections accepted:

1. **Q_s range.** On the grid s = R(cos θ, sin θ), Q_s = R²(1 − ½ sin 2θ), so **½R² ≤ Q_s ≤ 3/2 R²**, both extremes attained at the sampled angles. The "[0.75R², R²]" label in §10 and in the script was wrong. At R = 0.12 the sampled range is [0.0072, 0.0216]; at R = 0.25 it is [0.031, 0.094]. The Q_s-threshold phrasing in §10 C(ii) is withdrawn with it.
2. **Age-resolution normalisation.** |D₅(s)| = ½Q_s²R varies with direction; §10's "sup|𝓔|/|D₅|" column divided a grid supremum by the fixed ½R⁵ and overstated the ratio. The pointwise statistic max_grid |𝓔_N(s,τ)|/|D₅(s)| is:

   | R | 0.03 | 0.08 | 0.12 | 0.18 | 0.25 |
   |---|---|---|---|---|---|
   | N=7 | 9.7·10⁻⁵ | 3.1·10⁻³ | 1.4 % | 6.2 % | 21.6 % |
   | N=8 | 4.3·10⁻⁵ | 2.3·10⁻³ | 1.2 % | 6.3 % | 25.2 % |

   The script now prints this statistic (rev. SHA `5c63c363d25f30f610e3339363b5fcb261c1e9a31e6a99086767993d0e837c82`; JSON unchanged, log replaced). Consequently §10 C(i) is also narrowed: **N=8 does improve on N=7 for R ≲ 0.12**, loses the advantage near R ≈ 0.18, and is worse at 0.25. The grid maxima all occur at τ = 0 and at the Q_s-maximal angles; at τ = 0 the state is exactly the birth graph, so 𝓔_N(s,0) is simply the age-1 sheet's truncation tail Σ_{d>N} D_d(s⁺).
3. **ΔQ_s = 0** is by construction (identical s⁺ on both sides), as §10 said; it is not a parent-accuracy statement for a multi-step comparison. One-step observable errors are exactly ΔI = B(s⁺, 𝓔), ΔΩ_G = (√3/2)(s⁺_η𝓔_ρ − s⁺_ρ𝓔_η), hence |ΔI| ≤ (3/2)|s⁺||𝓔| and |ΔΩ_G| ≤ (√3/2)|s⁺||𝓔|.

Also withdrawn as over-reaching: the §10 C(iii) remark that a persistent 25× coefficient growth "would mean radius ≲ 0.04" — two degrees determine no radius. Everything in §10 remains sampled-grid evidence at κ̃ = 1; no certified K_{N,T}, no multi-step accumulation, no physical interpretation.

**On the proposed next gate (certified K₇, K₈ on a compact region).** Agreed that this precedes d = 10, 11. The ingredients are: exact majorants for Δ_τ𝒞₈, Δ_τ𝒞₉ on the region (they are explicit polynomials, so this is routine), and a rigorous remainder for the 36 primitive sin/expm1 steps with reprojection — most directly by interval arithmetic (mpmath `iv` or Arb) over the region with τ ∈ [0,T] including τ+1 and all intermediate states, together with an invariance check that the region's image stays inside the domain where the majorants hold. That is a substantial compute piece and belongs on the RTG machine; I can draft the interval-arithmetic checker and the region contract next.
````

#### X-N78-5 — triad_finite_jet_defect_N7_N8.py (de367595), docstring

`sources/support/triad_finite_jet_defect_N7_N8.py` lines 1–21; extract SHA-256 `69893f0bef16095a164a0ccf0e209087513f60d36f1c26bc3415a51880dcd522`

````
#!/usr/bin/env python3
"""
Finite-jet compatibility defect of the formal age family, N = 7 and N = 8, against the real analytic map.

Model: Genesis->RER conditional analytic modal map F = N^6 (reprojection after each primitive step),
trial birth graph C_k(s) = k Q(s) J_Q s, kappa = sqrt3*kt.  Formal age family (Triadic/contributor, 9 Oct):
   C(s,tau) = sum_d C_d(s,tau),  C_d polynomial in tau of degree <= floor((d-3)/2),   F(s,C(s,tau)) = (s+, C(s+,tau+1)).

Part A (exact, standard library): reconstruct C_d(s,tau) for d = 3..DMAX as explicit homogeneous polynomials in
(r,e) with binomial-basis tau coefficients, from exact ray series of the full map (d+1 rational rays per degree,
ages 0..floor((d-3)/2)).  Independent of any jet file; also yields D7, D8, D9 without a quintic jet.
Part B (numeric, mpmath 50 digits): the defect
   E_N(s,tau) = F_c(s, C_N(s,tau)) - C_N( F_s(s, C_N(s,tau)), tau+1 ),
its normalised size |E_N| / |s|^(N+1) over a grid q_min <= Q_s <= q_max, 0 <= tau <= T, compared with the
predicted leading term  Delta_tau C_{N+1}(s,tau) = C_{N+1}(s,tau+1) - C_{N+1}(s,tau)  (because d_c F_c = I + O(2),
the omitted order enters at both ends of the step), and the induced errors in Q_s, I_sc, Omega_G.
Empirical sup over a grid is reported.  It is NOT a certified bound K_{N,T}.

Usage: python triad_finite_jet_defect_N7_N8.py [--negative]   (negative: drop C_7 from C_7 -> leading order must break)
Requires the rev2 series file in ../source/ (SHA-256 67b2e0e7...799b) and mpmath.
"""
````

#### X-N78-6 — TM2NOTE header (files and hashes of the stage-1 engine)

`sources/triad/TRIAD_F3_FINITE_JET_CONTROL_STAGE1_20261013 (1).md` lines 1–5; extract SHA-256 `3ed06b845d0d04007fb4883df798a177c9d1c04169489ac49ab04839b6f18a1b`

````
# F3-FINITE-JET-CONTROL — stage 1: certified one-step defect bounds for N = 7, 8

**13 October 2026 · NONCANONICAL · Triadic contributor deliverable.** Conditional analytic modal map (Genesis→RER contract: E, P, T_e, reprojection after each primitive step, F = 𝒩⁶), trial birth graph with κ = √3 (κ̃ = 1), finite-jet age family 𝒞_N from `age_family_polynomials_kt1.json` (SHA `03042f84…d83c`). Nothing physical is selected; no owner DSN or RER record changes.

Files: `triad_tm_onestep_certificate.py` (SHA-256 `2ce1356463af930d875e393e0cf25bbc91e3de63f9d51cb98fcd3afa62bd6e5f`), log `triad_tm_onestep_certificate_stage1.log` (`aba40c53…71fb`). Needs mpmath and the polynomial JSON.
````

#### X-N78-7 — TM2NOTE §4–§5 (what stage 1 certifies; stage 2 plan)

`sources/triad/TRIAD_F3_FINITE_JET_CONTROL_STAGE1_20261013 (1).md` lines 40–44; extract SHA-256 `988b39db430670db98bfedfa33d7d6885118ffd50593de284b02bf7a82f43618`

````
## 4. What this certifies and what it does not
Certified: on each listed box, for every (s, τ) in it, ‖𝓔_N(s, τ)‖_B ≤ K_N·R_min^{N+1}, against the real sin/exp map with reprojection, including all six intermediate primitive states (they are the models' intermediate stages). Not certified: anything outside the three boxes; a single K over the whole stage-1 region R ∈ [0.03, 0.08], τ ∈ [0, 2]; multi-step accumulation; observable-level errors (follow from §5 of the N7/N8 review once |𝓔| is bounded: |ΔI| ≤ (3/2)|s⁺||𝓔|, |ΔΩ_G| ≤ (√3/2)|s⁺||𝓔|). κ̃ = 1 only.

## 5. Stage 2 — covering the region (for the RTG machine)
The same script is the engine; the sweep is a loop over boxes. Cost estimate: annulus R ∈ [0.03, 0.08] with h = 0.0025 ≈ 700 (r, e)-boxes × τ-boxes. Two savings are available before running it: raise K to 8 and h_τ to 0.25–0.5 (τ enters polynomially at the input, so wide τ-boxes are cheap for the model), and use h = 0.005 for R ≥ 0.05 with K = 8. With those, ≈ 300–500 box-runs per N at 1–3 min each — a day on one core, hours on eight. The output would be a certified table K_N(R-shell, angle sector) and a single K_{N,2} = max over boxes, which is the stage-1 target as Triadic defined it. The B-orthogonal transverse component can be reported from the same models at no extra cost.
````

#### X-N78-8 — TM2NOTE §6 (the cited section, lines 46–65): proof-contract repair, governing stage-1 results

`sources/triad/TRIAD_F3_FINITE_JET_CONTROL_STAGE1_20261013 (1).md` lines 46–65; extract SHA-256 `a9390ed285db5cadedfae2dc421c0c6e9cdb859e42af5a13bdde6acb4defac6b`

````
## 6. [COR] Proof-contract repair on Triadic receiving audit (13 Oct, afternoon) — governing stage-1 results

**Defect accepted.** In `certify_box`, the radius used for the Lipschitz constant L_C of 𝒞_N(·, τ+1) was built from the *input* box, not from the post-map parent s⁺. Triadic's point-interval countercheck (`check_postmap_radius.py`, SHA `40cf772b…3a47`, reproduced here) shows ‖F_s‖₂ = 0.0360712… at the third box's corner against the declared 0.0360624…: the derivative domain did not enclose the image, so the inequality |𝒞_N(s⁺_true) − 𝒞_N(s⁺_poly)| ≤ L_C ρ_s was unsupported. The numbers in §3 are therefore withdrawn as certificates (they stand as reproduced computations of a flawed contract).

**Repair adopted:** the hardened engine `triad_tm_onestep_certificate_v2.py` (SHA `c14c27cd3acf188ee92afc118d24edbdd3864eaa007ec9ca58b41aef06516ca0`, Triadic draft, reviewed line by line against the original: 31 changed lines, all in `certify_box` and the box table). Changes: (i) Rm from the computed s⁺ polynomial bound plus √2·ρ_s per component — this encloses both s⁺_true and s⁺_poly and the segment between them; (ii) exact decimal box endpoints via rational strings with outward-rounded Rmin/Rmax; (iii) constants published only rounded up. Everything else (models, transport, Lagrange remainders) is unchanged. All three boxes rerun for N = 7, 8 (log `triad_tm_onestep_certificate_v2_stage1.log`, SHA `0b4381b2…f7f0`).

**Governing table (K = 6, h = 0.0025, h_τ = 0.05, κ̃ = 1; constants rounded UP):**

| box centre (r, e, τ) | R range (outward) | N | sup_box |𝓔_N|_B ≤ | centre enclosure | **K_N (certified, ≥)** |
|---|---|---|---|---|---|
| (0.0325, 0, 0.05) | [0.0300, 0.0351] | 7 | 2.130·10⁻¹² | 6.363·10⁻¹³ | **3.246** |
| | | 8 | 1.106·10⁻¹² | 3.249·10⁻¹³ | **56.18** |
| (0.0325, 0, 1.95) | [0.0300, 0.0351] | 7 | 2.088·10⁻¹² | 6.921·10⁻¹³ | **3.182** |
| | | 8 | 9.214·10⁻¹³ | 2.809·10⁻¹³ | **46.82** |
| (−0.023, 0.023, 0.05) | [0.0289, 0.0361] | 7 | 1.115·10⁻¹² | 4.635·10⁻¹³ | **2.234** |
| | | 8 | 7.563·10⁻¹² | 2.421·10⁻¹² | **522.7** |

The repair moves the constants in the sixth significant figure (e.g. K₇ on box 3: 2.2339899… → 2.2339901…), as the audit predicted; the §3 three-figure values that had been rounded down (3.18, 46.8, 2.23) are superseded by the rounded-up ones above.

**Also accepted:** the Cartesian box count for stage 2 — ≈ 268 inner (h = 0.0025 on R ∈ [0.03, 0.05]) + 180 outer (h = 0.005 on [0.05, 0.08]) per τ-layer, ≈ 896 box-runs per N with two τ-layers of half-width 0.5 — replaces my 300–500 estimate, which assumed optimisations not yet shown. The stage-2 driver will be written on the v2 engine, with the driver features Triadic listed (exact decimal endpoints, hashes, per-box resumable records for each N, six intermediate-state bounds and the τ+1 interval, upward-rounded constants, B-orthogonal transverse defect reported separately, explicit coverage certificate of the polar annulus by the Cartesian boxes). Pilot on K = 8 / wide τ-boxes at a few corners precedes the full sweep.
````

#### X-N78-9 — triad_tm_onestep_certificate_v2.py (c14c27cd, the repaired stage-1 engine named in TM2NOTE §6), docstring

`sources/support/triad_tm_onestep_certificate_v2.py` lines 1–23; extract SHA-256 `76812f8991e57ebf86ae015490359e6264f82c9564e482f1c0e198fab0bb8299`

````
#!/usr/bin/env python3
"""
F3-FINITE-JET-CONTROL, stage 1: rigorous one-step defect bound for the N=7 / N=8 finite-jet age family
against the real analytic conditional modal map, on a small box, by Taylor models with interval coefficients.

Model: F = N^6, N = (P x I2) o T_e^{x3} o (E x I2), T_e(r,e) = (r - sin e, e + expm1(r) - sin e), kappa = sqrt3 (kt=1).
Finite jet: C_N(s,tau) = sum_{d<=N} C_d(s,tau) from age_family_polynomials_kt1.json (exact rationals).
Defect:     E_N(s,tau) = F_c(s, C_N(s,tau)) - C_N( F_s(s, C_N(s,tau)), tau+1 ).

Method (standard Taylor-model arithmetic, Makino-Berz style, all coefficient arithmetic in mpmath interval
arithmetic, so floating-point rounding is enclosed):
  * variables v = (dr, de, dtau), box |dr|<=h, |de|<=h, |dtau|<=h_tau around a centre (r0,e0,tau0);
  * a Taylor model is (polynomial of total degree <= K with interval coefficients, symmetric remainder bound rho)
    and encloses the function on the whole box: f(v) in P(v) + [-rho, rho];
  * products truncate degrees > K into the remainder via the box bound sum |c_alpha| h^alpha;
  * sin / expm1 of a model use Taylor expansion about the model's constant term with Lagrange remainder
    (|sin^(j)| <= 1 ; |exp^(j)| <= exp(|p0|+|q|)).
Output: a rigorous enclosure of E_N on the box, hence certified  ||E_N||_B <= K_{N} R_min^(N+1)  on that box,
together with the enclosure of E_N at the box centre (to show how tight the bound is).

Usage:  python triad_tm_onestep_certificate.py [--K 8] [--h 0.0025] [--boxes small|stage1]
Needs mpmath and age_family_polynomials_kt1.json in the same directory.
"""
````

#### X-N78-10 — TMREVIEW, whole file (Stage-2 driver/coverage/pilot receiving review)

`sources/triad/STAGE2_RECEIVING_REVIEW.md` lines 1–46; extract SHA-256 `4158193aa5822206da583320fa3f813158e5cfd2714a845dc6e01167d14b54db`

````
# Triadic — Stage 2 driver / coverage / pilot receiving review

**13 October 2026 · NONCANONICAL · NOT A REGION CERTIFICATE.** Source artifacts were read directly from the delivered paths; no Triadic, Genesis, RER, or producer source was modified.

## Source manifest

- `triad_tm_engine_v3.py`: SHA-256 `78a5e434073165b37e9e5457766b6d21edb63e51d076172f4ac92052c63bfd18`.
- `triad_stage2_driver.py`: SHA-256 `5268d037ba15ec7f7787e8cb2b67e6918479283ee12cae8635b33290e1f78e63`.
- `triad_stage2_coverage.py`: SHA-256 `2b5a9ff81f97af068d29f0293f459b58ba3defbc78bd2533a055caacd122555b`.
- `stage2_config.json`: SHA-256 `73389a2b83bac9fd2c55db779c9509c4865edada2d830568f97782a5ec455549` (K=8).
- `stage2_pilot_K6.jsonl`: SHA-256 `f103d1da35e9cc3401cc22f3049280546ea95c8eab877c763fd79fdfdc1490ed` (K=6, separate config hash `ca2619cc…`).
- Handoff note: SHA-256 `b975c5df70e8a53a92ff7adfc7e348be814e74efc7b9e9982362790965b139b1`.

## Confirmed

1. **Exact arithmetic geometry of tiling.** The plan has 272 inner and 180 outer spatial boxes per tau layer, times two tau layers: 904 boxes per N, 1808 (box,N) jobs. The structural covering proof is valid given the input region and the square-selection inequality. A 20,000-point sampled check found zero misses; that check is supplemental, not the proof.
2. **v2 → v3 scope.** The core six-step Taylor-model recurrence, multiplication and analytic remainder formulas are unchanged in source diff. V3 adds configuration, step logs, lower annulus radius, and B-transverse defect calculations. Consequently “no arithmetic change” means *no change to the old core recurrence*, not literal identity of all calculations or all outputs.
3. **K6 pilot.** Eight PASS rows (four boxes × N=7,8), all six step records present. Published `K_up` exceeds each recorded `K_raw`. The file is not a whole-domain certificate. No completed K8 pilot JSONL was attached in this delivery.
4. **Actual incomplete state.** Running the supplied coverage script against the attached K8 config exits 1 with 904 missing boxes for each N, as expected before the sweep.

## Blocking current-use/governance issues before whole-region acceptance

**G1 — [BLOCK] The coverage aggregator trusts unvalidated PASS records.** It checks only `(box_id,N)`, `status=PASS`, and the three hashes. It does not check recorded endpoints, degree K, precision, kt, R_floor, six-step records, or numerical consistency. In an isolated negative test with all 1808 planned IDs, matching hashes, wrong endpoints (`999..1000`), empty step lists, and zero fictitious bounds, the original verifier exited 0 and printed `CERTIFIED ... K_7=K_8=0`. This does not imply the real pilot values are wrong; it means the coverage program must not confer certification. Add strict per-record schema/plan reconciliation, reject conflicting duplicates, enforce finite nonnegative upper values and K_up>=K_raw, and retain engine-proof review as an independent gate.

**G2 — [BLOCK] Parallel output instructions conflict with config hashing.** The proposed process is to alter `results` in two config copies (one per ring), concatenate results and run one verifier. But `results` is part of the SHA-256 of the full config: the inner and outer copies acquire distinct hashes. Neither can be accepted under the other config. Add a CLI `--results` override that selects only the output path *without changing the hashed mathematical config*, or define a canonical semantic config hash excluding output path. Use separate files per worker and merge only records with the same canonical contract.

**G3 — [BLOCK for future extension] Engine ignores the configured poly file and kt selector.** The driver hashes `CFG['poly']` and logs `KT`, but the engine imports the fixed `age_family_polynomials_kt1.json` and contains fixed kappa-tilde=1 mathematics. A config edit could therefore attest to the wrong coefficient set. For now require `KT='1'` and `poly='age_family_polynomials_kt1.json'` with fatal assertions; or make engine load the given file explicitly before evaluating boxes.

**G4 — [SCOPE] Upper-bound ratio is not an actual transverse fraction.** The pilot has independent upper enclosures `K_up` for total defect and `K_perp_up` for transverse defect. Their quotient, even if 0.98–1.19, does not prove the actual defect is predominantly transverse. In fact `K_perp_up > K_up` is possible because the bounds have different slack. Claim only that the independently calculated transverse *upper bounds* are numerically comparable. A positive transverse lower bound would require additional sign/enclosure information.

**G5 — [GUARD] Formatting an interval upper endpoint through `mp.mpf` is not a proven outward decimal conversion.** `upq` first converts an interval endpoint to ordinary floating precision with `mp.nstr`, then rounds that result up. It happened to leave positive headroom in all eight delivered pilot rows, but a rigorous aggregation should round directly from the exact binary endpoint, using directed conversion or a conservative epsilon with proof. The same applies to logs of R_eff and intermediary bounds: preserve outward endpoint semantics when serializing.

**G6 — [SCOPE] Pilot cannot establish K8 optimum.** Only the first pilot box's K=8 comparison is printed in the note, with other K8 jobs marked “running”; a complete K8 pilot file was not supplied. Thus K=6 is a reasonable computational candidate, not yet a domain-optimality theorem.

## Proposed acceptance order

1. Patch G1–G3 before any long sweep; rerun negative controls that wrong endpoints, wrong K, and altered config hashes must be rejected.
2. Record G4–G6 as scope/serialization safeguards; obtain complete K8 short pilot and independent review of Taylor-model remainder lemmas.
3. Retain mathematical config identity across inner/outer worker outputs and generate a separate, exact-rational coverage manifest for all 904 boxes per N.
4. Run only a small fail-fast resume/merge experiment first. Full RTG-machine sweep follows review of that experiment; only then propose K_7,2 / K_8,2 for RER, with the known normal/component distinction.

## Disposition

`MODEL/TM CORE: no new mathematical rejection`; `TILING PLAN: ACCEPT`; `K6 PILOT: source-reported / internally checked`; `COVERAGE/RESUME AS CERTIFIER: REVISE`; `K8 PILOT: INCOMPLETE IN ATTACHED MATERIAL`; `FULL REGION CERTIFICATE: OPEN`.

No physical closure, long-time observable control, physical birth threshold, new owner theorem or memory mechanism is adopted.
````

#### X-N78-11 — S2FOLLOWUP §2–§3 (r2 review acceptance and amendments; source identities)

`sources/triad/STAGE2_FOLLOWUP_RECEIVING_RESPONSE_20261014.md` lines 16–39; extract SHA-256 `6d43f212b55e6816f2c81ea99448927d7bbf221fb57ec353b548080d38ea297c`

````
## 2. RER review acceptance and three bounded amendments

The contribution note, r2 Markdown and machine-registry hashes all match the reported values. Seven Triadic-facing records have `ACCEPT SCOPED`; RER-F3-N7N8 is additionally accepted at its existing source/certificate-limited scope. That is contributor review of the indicated records, not approval of all 32 records or owner adoption. The separate receipt records only what the contributor explicitly supplied.

The following amendments are supported for the next registry revision; they have **not** been applied to the accepted-for-review r2 bytes:

1. **RER-GEN-C09:** write “equal current parent vectors on sheets of unequal fixed finite ages can have different future Qs.” The same-age versus different-age distinction should also appear in the repeated claim summary.
2. **RER-TRIAD-REGULAR-3FOLD:** the age-0/1 proof uses the C07 degree-five drift and continuity of the derivative of a C1 defining function. The same argument extends to **each fixed finite pair n != m using C09's difference expansion**. This is not a uniform-in-age neighborhood and not an abstract-factor impossibility theorem. The original 0/1 statement need not be silently broadened; record the general-pair consequence with its C09 dependency.
3. **RER-ER2B-T6D:** name the exact edge-slot interchange 2↔3 as the source of `F(s,-c)=(F_s(s,c),-F_c(s,c))`. Do not identify it with an already selected physical pole/node exchange.

The withdrawn interpretation of a ratio of upper bounds was already excluded by RER-F3-N7N8. The contributor's withdrawal closes that wording issue, not the analytic or whole-region certificate gate.

## 3. Source identities checked

| Received item | SHA-256 |
|---|---|
| Contributor record review | `d388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab` |
| Engine v3.1 | `674961ccd19b48653c40f5698668f21d832f1d948a91259eb36d1a639694e17e` |
| Driver v2 | `cb26b2e427e323bbc128f01032c232cfb9c00f3c951379dc01ebc43905a41276` |
| Hardened coverage verifier | `ed19d7139c5a2e96c7a6d526db7692f448398ca1ecfb81fc8f416e3b4b5e1ac5` |

The local upload suffix `(1)` was removed only from the copied filenames in this package; their bytes are unchanged. The source manifest records both paths.

The engine v3→v3.1 source diff changes serialization helpers, the serialization calls and exact tau-plus recording; it does not replace the existing Taylor-model recurrence. No complete revalidation of that recurrence is claimed here.
````

#### X-N78-12 — Stage-2 replay bundle README (inside S2ZIP; hash cited in RER R3.1 sources)

`sources/support/STAGE2_REPLAY_README.md` lines 1–17; extract SHA-256 `055bba91aa1335317498bbf60f7101e5b6f345bf3a03b882f94358e2ea360b9c`

````
# Stage-2 replay bundle — 14 Oct 2026 (NONCANONICAL; infrastructure + pilot rows, no region result)

## regression/  — reproduces the reported 41-expectation infrastructure suite
Run in this folder:  `python -I triad_stage2_regression.py`   (≈ 2 min; exit 0 = 41/41)
Inputs are the exact files used for the reported run: current driver v3, shared contract, coverage v3, engine v3.2,
pinned coefficient table, `reg_config.json` (coarse K=4 tiling, 52 boxes/N) and the two GENUINE worker outputs
`W_inner.jsonl` (56 rows) / `W_outer.jsonl` (48 rows) produced by
  `python triad_stage2_driver.py --config reg_config.json --only inner --results W_inner.jsonl` (and `--only outer ... W_outer.jsonl`).
To regenerate the worker files from scratch instead (≈ 7 min wall with two processes), delete them and run those two commands first.
The suite writes scratch files (M_*.jsonl, R_*.jsonl, alt_poly.json, reg_config_*.json) and REGRESSION_RESULTS.json; they can be deleted.

## pilots/  — governing-contract pilot rows (engine v3.2)
- `stage2_config.json` (K=6, governing) + `stage2_pilot_K6_v32.jsonl`: 8/8 rows, all accepted by the shared contract.
  `python -I triad_stage2_coverage.py --config stage2_config.json --results stage2_pilot_K6_v32.jsonl` -> PARTIAL (4 of 904 boxes/N), exit 1 by design.
- `stage2_config_K8.json` (K=8, separate semantic identity) + `stage2_pilot_K8_v32.jsonl`: 1/8 rows (stopped on request). Resume with
  `python triad_stage2_driver.py --config stage2_config_K8.json --pilot --results stage2_pilot_K8_v32.jsonl`.
Pilot rows are engine-reported upper bounds under the stated contract; the Taylor-model lemma review remains a separate open gate.
````

#### X-N78-13 — r2 contributor review: RER-F3-N7N8 row and §2 "Corrections and withdrawals on the N7/N8 line (my side)"

`sources/rer/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md` lines 16–23; extract SHA-256 `4940761efe7be14263faec0151f9154364ebe95493b914fbefa9e3d2a343331c`

````
| RER-F3-N7N8 | **ACCEPT SCOPED, with three corrections on my side** (below) | The record's refusal to accept any global K is right; the Stage-1 v2 table is transcribed correctly; the three-box non-cover statement is right. |

## 2. Corrections and withdrawals on the N7/N8 line (my side)

1. **Pilot finding (v) withdrawn.** I wrote that K_perp/K between 0.98 and 1.19 shows "the defect is not predominantly along D₅". A ratio of two *upper bounds* says nothing about the actual direction of 𝓔; the transverse channel is reported, not interpreted, until a lower bound on the transverse fraction exists. The record's sentence to this effect is correct.
2. **Verifier hardening (record contract).** The delivered `triad_stage2_coverage.py` accepted any PASS record with matching hashes. It now validates every published field against the plan and config: exact rational endpoints equal to the planned square and τ-layer; N ∈ N_LIST; K_deg, dps, κ̃ equal to the config; R_floor equal to the ring's inner radius; R_eff ≥ R_floor (to precision tolerance); R_min < R_max; τ+1 interval exact; six step records with parseable fields and last-step ρ_c, λ consistent with the summary; every published constant upward-rounded to ≤ 4 significant digits with K_up ≥ K_raw; duplicates with differing K_raw rejected. Tamper test: a wrong rounding, a wrong endpoint and a five-step record are each rejected for the named reason while genuine records pass. New SHA `ed19d7139c5a2e96c7a6d526db7692f448398ca1ecfb81fc8f416e3b4b5e1ac5`.
3. **Directed serialisation.** Published decimals were produced by round-to-nearest (`nstr`). Engine v3.1 (`triad_tm_engine_v3_1.py`, SHA `674961ccd19b48653c40f5698668f21d832f1d948a91259eb36d1a639694e17e`; arithmetic unchanged, only the serialisation of step records and τ+1 now exact/directed) and driver v2 (SHA `cb26b2e427e323bbc128f01032c232cfb9c00f3c951379dc01ebc43905a41276`) now convert each interval endpoint exactly (dyadic mpf → Fraction → Decimal) and round upper bounds up and lower bounds down. The config's engine field points to v3.1; the config hash therefore changes and prior records (pilot) do not validate against it, by design.
4. **K = 8 pilot file.** The container was reset between sessions and the background K = 8 run was lost; it is rerunning on engine v3 (its hash is recorded in each line) and the complete `stage2_pilot_K8.jsonl` will be supplied as an informational file, not as records of the governing config.
````

## Preparer runs (timing only — not receiver evidence)

| Script | Wall time | Normal mode | Negative mode |
|---|---|---|---|
| triad_age_fibre_curvature_check.py (layout checker/ + source/jet_coefficients.json + source/c09_independent_series_check_rev2.py; SymPy 1.14.0) | ≈9 s | exit 0, "13 PASS, 0 FAIL" | --negative: exit 1, "7 PASS, 6 FAIL" |
| triad_finite_jet_defect_N7_N8.py (de367595; mpmath 1.3.0; layout scripts/ + source/) | ≈21 s | exit 0; the regenerated age_family_polynomials_kt1.json has SHA-256 03042f84…d83c | --negative: exit 1 |
| check_pointwise_metrics.py (61a54f0a) | ≈4 s | exit 0 | — |
| Stage-2 replay: triad_stage2_regression.py in regression/ of S2ZIP | ≈19 s | exit 0, "41/41 regression expectations hold (infrastructure only; no mathematical certification)" | — |
| Stage-2 replay: triad_stage2_coverage.py on the K=6 pilot rows (pilots/ of S2ZIP) | ≈8 s | exit 1 by design, "PARTIAL — not a region result" | — |
