"""RER Phase B-08 neutral review packet (preparer: Claude, RER co-owner; NONCANONICAL).
Scope (receiver suggestion of 21 Oct 2026 after B-07; PI decision of 21 Oct 2026 "B-08'e başlayalım"): the remaining author-conflicted records
RER-TRIAD-AGE-CURVATURE and RER-F3-N7N8, on RER r4.12 and Phase A r17 (the two records are byte-identical in r4.11 and r4.12).
The packet quotes byte-pinned sources, lists proof material with its provenance and states questions. It gives no PASS/FAIL, grade or
acceptance recommendation for any claim; the receiver decides ACCEPT SCOPED / CORRECTION REQUIRED / INSUFFICIENT EVIDENCE per record or claim.
Usage: python -I -B b08_packet.py              -> verify inputs, build, write B08_REVIEW_PACKET.json/.md; exit 0 iff all gates pass
       python -I -B b08_packet.py --check      -> verify and compare with the stored outputs byte for byte (no write)
       python -I -B b08_packet.py --negcontrol -> negative controls (each must make its gate fail); exit 0 iff all do"""
import sys, re, json, hashlib, copy
from pathlib import Path
HERE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
T = 'sources/triad/'; U = 'sources/support/'
FILES = {
 'RER12': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_12.md', '7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9'),
 'RER6': ('sources/rer/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_6.md', '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'),
 'MATRIX17': ('sources/rer/PHASEA_r17_SOURCE_CURRENCY_MATRIX.json', '4ff673cf6967b57463e2b36f611047a44d6eb9b2ed54bd2f5a80918fce08c9d0'),
 'R2REV': ('sources/rer/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md', 'd388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab'),
 'CURVNOTE': (T + 'RER_C09_INDEPENDENT_VERIFICATION_20261009 (6).md', 'd3553fb4ab6965aefba643672920e98998c8c93c737902a6ab2c2f4573f23321'),
 'CURVSCRIPT': (T + 'triad_age_fibre_curvature_check.py', 'e56088b0fa57e97aac590b9c92bd1490c2784cb85b9ee9719a26bc99254817f2'),
 'AGEGEO': (T + 'C09_AGE_GEOMETRY_RECEIVING_REVIEW.md', 'ae3af1922a319ea2474d1c132a04e7e722ee387a64ef43b9c0491b49d8373b2b'),
 'N7REVIEW': (T + 'N7_N8_RECEIVING_REVIEW.md', '4fc7edcda7bcef01f255ea97292cda0aab0eb76eeaee53c43247fe3dc0d5e85d'),
 'TM2NOTE': (T + 'TRIAD_F3_FINITE_JET_CONTROL_STAGE1_20261013 (1).md', 'ed95be3be3b7eb1e36290179b96bf5a2be2d4351a260b0c7246ccba9b2abfef1'),
 'TMREVIEW': (T + 'STAGE2_RECEIVING_REVIEW.md', 'c935a4aca063b59099fbc9bf4052b5d50c6a1782ec755b80f5b8594d4876d4e2'),
 'POLY': (T + 'age_family_polynomials_kt1.json', '03042f84016aa2128ca7ac425a0782d84a617e4b74c490d4f0c7b912c300d83c'),
 'S2ENGINE32': (T + 'triad_tm_engine_v3_2.py', '7d4e8ec24e75c35bd8296121425b56e28049efd5846b6a932b7e2f64a6716716'),
 'S2CONTRACT': (T + 'triad_stage2_contract.py', '8af038c85241d889b8f50d7e5da18cf8a1b572d6e8f544d3efc1080ab811746c'),
 'S2COVERAGE3': (T + 'triad_stage2_coverage.py', 'a298cf467799ee1f5bcab726870f0424f6864e1e922ab98ef28f508b6e4e9968'),
 'S2REGCODE': (T + 'triad_stage2_regression.py', '2802f97bd28871412bcef6e716cfb1a9bcd7ae251d8b203bcf87912320e44e2a'),
 'S2REGREPORT': (T + 'stage2_REGRESSION_RESULTS.json', '0babe8b5ba5cee6cb795815246b78e9a5e63b9b0c0865a8e963cecb218a5fd6c'),
 'S2CFG32': (T + 'stage2_config.json', 'dce1d569fb7e5eaa01c49795a4f171f578d055ec6c8f37422e0e8b783b6942fc'),
 'S2FOLLOWUP': (T + 'STAGE2_FOLLOWUP_RECEIVING_RESPONSE_20261014.md', 'a613f58908eeee1bf5c29a933cf977fcdff0c15332524119b14b6d0c305813b5'),
 'JET': (U + 'jet_coefficients.json', '15a7d0569a1e8ceefe04260ce83e204acb2eeed20b2639eebd810e14ee992824'),
 'SERIES2': (U + 'c09_independent_series_check_rev2.py', '67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b'),
 'N78PY': (U + 'triad_finite_jet_defect_N7_N8.py', 'de3675953013d3a1e83227a46565708b16068314974bf81ad142a3f42034d9a3'),
 'N78PYREV': (U + 'triad_finite_jet_defect_N7_N8_rev.py', '5c63c363d25f30f610e3339363b5fcb261c1e9a31e6a99086767993d0e837c82'),
 'PWCHECK': (U + 'check_pointwise_metrics.py', '61a54f0a29a786941ee283bc52a7a2274de0d8a4f7101eea03c6f2ef37eadf0b'),
 'SDCHECK': (U + 'check_second_difference.py', 'fb8907f07ca285d6031135397b084c0d00fc80b320604f6a2742d696937150be'),
 'TMV2': (U + 'triad_tm_onestep_certificate_v2.py', 'c14c27cd3acf188ee92afc118d24edbdd3864eaa007ec9ca58b41aef06516ca0'),
 'S2ZIP': (U + 'STAGE2_REPLAY_20261014.zip', 'd782a7018ed7a9405d6dd04f48ca036f01d14dbcfbc6ea8e7d1b2dd02aae9be8'),
 'S2README': (U + 'STAGE2_REPLAY_README.md', '02588f55098bd732bd45bf70d2288451c9268a1b483b5015e894b4aae4d02a61'),
 'B05INV': ('sources/history/RER_PHASE_B05_NEUTRAL_SOURCE_INVENTORY_20261020.json', 'b9a978dad834f7a0c21344ac4088e89ae6a779312b43dd417facbdd7fb0aa5e7'),
 'B05INVMD': ('sources/history/RER_PHASE_B05_NEUTRAL_SOURCE_INVENTORY_20261020.md', 'fcf7a081658f22a221f3cadf17e708476a494f81aa40a3911673beee5f04ebf4'),
 'B07DEC': ('sources/history/B07_RECEIVING_REVIEW_20261021.md', '845c47562df5afea8e09270b63deaefbedc85f4e53f51c3b2d925d0b0ba07141'),
}
# support files are not RER imports; each is held because a held source names its hash (B10 checks the citation)
SUPPORT_CITED_IN = {'JET': ['CURVSCRIPT', 'AGEGEO'], 'SERIES2': ['CURVSCRIPT', 'CURVNOTE'], 'N78PY': ['CURVNOTE', 'N7REVIEW'], 'N78PYREV': ['CURVNOTE'],
                    'PWCHECK': ['CURVNOTE'], 'SDCHECK': ['CURVNOTE'], 'TMV2': ['TM2NOTE'], 'S2ZIP': ['RER12'], 'S2README': ['RER12']}
REVIEW = ['RER-TRIAD-AGE-CURVATURE', 'RER-F3-N7N8']
EXTRACTS = [
 ('X-CUR-1', 'RER-TRIAD-AGE-CURVATURE', 'CURVNOTE', '## 7. Correction', ('prefix', '## 8. '), 'CURVNOTE §7 (the cited section, lines 83–105): withdrawn τ-update claim and the invariant wedge replacement'),
 ('X-CUR-2', 'RER-TRIAD-AGE-CURVATURE', 'CURVNOTE', '## 6. Addendum', ('prefix', '## 7. '), 'CURVNOTE §6 (context: the addendum whose τ-update claim §7 withdraws)'),
 ('X-CUR-3', 'RER-TRIAD-AGE-CURVATURE', 'CURVSCRIPT', '#!/usr/bin/env python3', ('end',), 'triad_age_fibre_curvature_check.py, whole file (symbolic all-direction derivation and three ray cross-checks)'),
 ('X-CUR-4', 'RER-TRIAD-AGE-CURVATURE', 'AGEGEO', '## A. ', ('prefix', '## B. '), 'AGEGEO §A receiving evidence (identities of the series file and the jet)'),
 ('X-CUR-5', 'RER-TRIAD-AGE-CURVATURE', 'AGEGEO', '## B. ', ('prefix', '## C. '), 'AGEGEO §B (the cited section, lines 13–42): universal seventh-degree second age difference'),
 ('X-CUR-6', 'RER-TRIAD-AGE-CURVATURE', 'R2REV', '# Triadic contributor review', ('end',), 'r2 contributor review, whole file (the record\'s only review receipt)'),
 ('X-N78-1', 'RER-F3-N7N8', 'N7REVIEW', '# Triadic / Genesis', ('prefix', '## 2. '), 'N7REVIEW header and §1 (model and independent replay)'),
 ('X-N78-2', 'RER-F3-N7N8', 'N7REVIEW', '## 2. ', ('prefix', '## 6. '), 'N7REVIEW §2–§5 (cited: §2 lines 21–31, §4 lines 43–58, §5 lines 59–71; §3 included for the Q_s range)'),
 ('X-N78-3', 'RER-F3-N7N8', 'N7REVIEW', '## 6. ', ('end',), 'N7REVIEW §6 statements not certified, §7 recommended next gate'),
 ('X-N78-4', 'RER-F3-N7N8', 'CURVNOTE', '## 10. ', ('end',), 'CURVNOTE §10–§11 (contributor first pass on N = 7/8 and its corrections)'),
 ('X-N78-5', 'RER-F3-N7N8', 'N78PY', '#!/usr/bin/env python3', ('prefix', 'import sys'), 'triad_finite_jet_defect_N7_N8.py (de367595), docstring'),
 ('X-N78-6', 'RER-F3-N7N8', 'TM2NOTE', '# F3-FINITE-JET-CONTROL', ('prefix', '## 1. '), 'TM2NOTE header (files and hashes of the stage-1 engine)'),
 ('X-N78-7', 'RER-F3-N7N8', 'TM2NOTE', '## 4. ', ('prefix', '## 6. '), 'TM2NOTE §4–§5 (what stage 1 certifies; stage 2 plan)'),
 ('X-N78-8', 'RER-F3-N7N8', 'TM2NOTE', '## 6. ', ('end',), 'TM2NOTE §6 (the cited section, lines 46–65): proof-contract repair, governing stage-1 results'),
 ('X-N78-9', 'RER-F3-N7N8', 'TMV2', '#!/usr/bin/env python3', ('prefix', 'import '), 'triad_tm_onestep_certificate_v2.py (c14c27cd, the repaired stage-1 engine named in TM2NOTE §6), docstring'),
 ('X-N78-10', 'RER-F3-N7N8', 'TMREVIEW', '# Triadic — Stage 2', ('end',), 'TMREVIEW, whole file (Stage-2 driver/coverage/pilot receiving review)'),
 ('X-N78-11', 'RER-F3-N7N8', 'S2FOLLOWUP', '## 2. ', ('prefix', '## 4. '), 'S2FOLLOWUP §2–§3 (r2 review acceptance and amendments; source identities)'),
 ('X-N78-12', 'RER-F3-N7N8', 'S2README', '# Stage-2 replay bundle', ('end',), 'Stage-2 replay bundle README (inside S2ZIP; hash cited in RER R3.1 sources)'),
 ('X-N78-13', 'RER-F3-N7N8', 'R2REV', '| RER-F3-N7N8 |', ('prefix', '## 3. '), 'r2 contributor review: RER-F3-N7N8 row and §2 "Corrections and withdrawals on the N7/N8 line (my side)"'),
]
NOT_HELD = 'NOT_HELD — identity as stated in the record or its source; bytes not in this packet'
HELD_SUPPORT = 'HELD support file (preparer session copy); its SHA-256 equals the hash cited in '
PROOF = {
 'RER-TRIAD-AGE-CURVATURE': [
  ('CURVNOTE §7 wedge statement and boxed formula for w', 'X-CUR-1', 'HELD (d3553fb4…3321); the note calls itself an "independent receiving verification"; the r2 reviewer refers to "my C09 note" (X-CUR-6); author not otherwise named', ['CURVNOTE']),
  ('symbolic derivation and ray cross-check triad_age_fibre_curvature_check.py', 'X-CUR-3', 'HELD (e56088b0…17f2); needs SymPy, the pinned jet and the rev2 series file', ['CURVSCRIPT']),
  ('pinned G3/G4 jet jet_coefficients.json (15a7d056…2824)', 'X-CUR-3, X-CUR-4', HELD_SUPPORT + 'CURVSCRIPT and AGEGEO; not an RER import of this record (Phase A key JET elsewhere)', []),
  ('rev2 series file c09_independent_series_check_rev2.py (67b2e0e7…799b)', 'X-CUR-3', HELD_SUPPORT + 'CURVSCRIPT and CURVNOTE; the same bytes as SERIES2 of RER-TRIAD-FORMAL-AGE', []),
  ('AGEGEO §B: B7 = −(Q_s/2)D5 (universal seventh-degree second age difference)', 'X-CUR-5', 'HELD (ae3af192…3b2b); "Triadic receiving review" (its own header); Phase A r17: SNAPSHOT_RECHECK_IN_PHASE_B', ['AGEGEO']),
  ('second-difference checker check_second_difference.py (fb8907f0…50be)', 'cited in CURVNOTE §6', HELD_SUPPORT + 'CURVNOTE', []),
  ('contributed series file c09_independent_series_check.py (758d38c7…a613) named in AGEGEO §A', 'X-CUR-4', NOT_HELD, []),
  ('review receipt: r2 contributor review', 'X-CUR-6', 'HELD (d388d7eb…e1ab); the r2 reviewer refers to "my C09 note"; the receiver lists this record as author-conflicted (B-07 decision file)', []),
 ],
 'RER-F3-N7N8': [
  ('N7REVIEW §2 (leading compatibility defect), §4 (normalization), §5 (Q_s-error zero)', 'X-N78-2', 'HELD (4fc7edcd…5e85d); "noncanonical receiving audit" (its own header); author not named', ['N7REVIEW', 'N7REVIEW', 'N7REVIEW']),
  ('N = 7/8 jet-defect script (de367595…d9a3) and its revision (5c63c363…7c82)', 'X-N78-5', HELD_SUPPORT + 'N7REVIEW / CURVNOTE; numerical grid estimate per its own docstring ("NOT a certified bound")', []),
  ('pointwise metric checker check_pointwise_metrics.py (61a54f0a…f0b)', 'cited in CURVNOTE §11', HELD_SUPPORT + 'CURVNOTE', []),
  ('stage-1 note TM2NOTE §6 (governing v2 local box results)', 'X-N78-8', 'HELD (ed95be3b…fef1); "Triadic contributor deliverable" (its own header)', ['TM2NOTE']),
  ('repaired stage-1 engine triad_tm_onestep_certificate_v2.py', 'X-N78-9', HELD_SUPPORT + 'TM2NOTE §6; needs mpmath and the polynomial JSON; not rerun by the preparer', []),
  ('stage-1 v1 engine (2ce13564…6e5f) and logs', 'X-N78-6', NOT_HELD, []),
  ('Stage-2 receiving review', 'X-N78-10', 'HELD (c935a4ac…d4e2); "receiving review" (its own header); author not named', ['TMREVIEW']),
  ('κ̃ = 1 age-family table', 'POLY', 'HELD (03042f84…d83c); the N = 7/8 script regenerates it (preparer run below)', ['POLY']),
  ('Stage-2 engine v3.2, contract, coverage v3, regression code, regression report, governing config', 'S2* imports', 'HELD (hashes as in the record); "RECEIVED_INFRASTRUCTURE_NOT_MATHEMATICAL_CERTIFICATE" (RER source table)', ['S2ENGINE32', 'S2CONTRACT', 'S2COVERAGE3', 'S2REGCODE', 'S2REGREPORT', 'S2CFG32']),
  ('Stage-2 follow-up receiving review (14 Oct)', 'X-N78-11', 'HELD (a613f589…13b5); "Noncanonical receiving review" (its own header)', ['S2FOLLOWUP']),
  ('Stage-2 replay bundle (driver, coarse config, 104 worker rows, K=6/K=8 pilot rows) and README', 'X-N78-12', HELD_SUPPORT + 'the RER R3.1 source table (S2REPLAY_ZIP, S2REPLAY_README)', []),
  ('R3.1 replay receipts (FRESH_REGRESSION_EXECUTION, RECEIVED_RECORD_VALIDATION, ARCHIVE_VERIFICATION) and R3_CONTRIBUTOR_ACCEPTANCE', 'R3.1 evidence pins', NOT_HELD + '; per the record, receiving-side rerun records', []),
  ('scoped Taylor-model lemma review STAGE2_TM_LEMMA_REVIEW_20261019.md (19 Oct)', '[OPEN] line', 'RECEIVER-REPORTED as stated in the record; ' + NOT_HELD + '; it is the receiver\'s own earlier work', []),
  ('R3_REQUEST_AND_STATUS_RECEIPT.md (472f5a38…aaa8)', 'Import/reference R3_REQUEST', NOT_HELD + ' (Phase A r17: PRINTED_ONLY, HASH_PRINTED_UNVERIFIED; "USER_REPORTED_NOT_ENGINE_RECEIPT" in the RER source table)', ['R3_REQUEST']),
  ('review receipt: r2 contributor review (record row and §2 "on my side")', 'X-N78-13', 'HELD (d388d7eb…e1ab); the reviewer writes "Corrections and withdrawals on the N7/N8 line (my side)"; the receiver lists this record as author-conflicted (B-07 decision file)', []),
 ],
}
TIMING = [  # preparer runs on the session machine, 21 Oct 2026; scheduling information only; NOT receiver evidence
 ('triad_age_fibre_curvature_check.py (layout checker/ + source/jet_coefficients.json + source/c09_independent_series_check_rev2.py; SymPy 1.14.0)', '≈9 s', 'exit 0, "13 PASS, 0 FAIL"', '--negative: exit 1, "7 PASS, 6 FAIL"'),
 ('triad_finite_jet_defect_N7_N8.py (de367595; mpmath 1.3.0; layout scripts/ + source/)', '≈21 s', 'exit 0; the regenerated age_family_polynomials_kt1.json has SHA-256 03042f84…d83c', '--negative: exit 1'),
 ('check_pointwise_metrics.py (61a54f0a)', '≈4 s', 'exit 0', '—'),
 ('Stage-2 replay: triad_stage2_regression.py in regression/ of S2ZIP', '≈19 s', 'exit 0, "41/41 regression expectations hold (infrastructure only; no mathematical certification)"', '—'),
 ('Stage-2 replay: triad_stage2_coverage.py on the K=6 pilot rows (pilots/ of S2ZIP)', '≈8 s', 'exit 1 by design, "PARTIAL — not a region result"', '—'),
]
QUESTIONS = {
 'RER-TRIAD-AGE-CURVATURE': [
  ('Q-CUR-1', 'objects', 'The record\'s Observables are w = det(c1−c0, c2−c0), B7 and R8; X-CUR-3 defines c_n(s) = C(s) + n D5 + n D6 + n D7 + binom(n,2) B7 + binom(n,2) B8 + … and R8 = B8 + (Q/2) D6. Are w, B7, R8 and "transverse residual degree 8" in the record the objects of X-CUR-1 and X-CUR-3?'),
  ('Q-CUR-2', 'B7 = −(Q_s/2) D5', 'The Formula/witness gives B7 = −(Qs/2) D5. Where is this derived — AGEGEO §B (X-CUR-5) or the script — and for which parent directions and κ̃?'),
  ('Q-CUR-3', 'wedge formula', 'Order/error states w = −(κ̃²/1024) Q_s^5 (111r³ − 68r²e + 177re² − 175e³) + O(|s|^14). X-CUR-1 boxes this formula and X-CUR-3 checks "D5 ^ R8 == W13" symbolically and three rays against untruncated series. Which part establishes the all-direction polynomial identity (Domain: "All parent directions as a polynomial identity") and which part is a cross-check?'),
  ('Q-CUR-4', 'inputs of the derivation', 'The symbolic part uses the pinned jet 15a7d056…2824 (G3/G4) and the ray part the rev2 series file 67b2e0e7…799b. AGEGEO §A (X-CUR-4) records the jet and a different series-file identity (758d38c7…a613, not held). Is the provenance of the jet sufficient for the receiver at the stated jet order?'),
  ('Q-CUR-5', 'scope of the closure claim', 'Closure: "affine child fibres at fixed parent do not represent all age sheets through this order"; Constraints: the wedge "is not claimed invariant under arbitrary nonlinear changes of the complete state"; Memory: "does not … forbid all curved factors". Is every claim line scoped to the fixed parent chart and child plane?'),
  ('Q-CUR-6', '"generically nonzero"', 'The claim says the degree-13 wedge is "generically nonzero", and Order/error: "A zero of the leading factor is not exact collinearity". Does the record anywhere assert nonvanishing on a set of directions, and is the κ̃-dependence (∝ κ̃², κ̃ fixed nonzero) carried at the point of use?'),
  ('Q-CUR-7', 'transformation law', 'The Transformation-law cell states that a scalar reparameterization of age cannot remove a component transverse to D5. Which held source shows this, and is it a consequence of B7 ∥ D5 (X-CUR-3 docstring) or a separate argument?'),
  ('Q-CUR-8', 'withdrawn claim', 'X-CUR-1 withdraws the τ-update claim of X-CUR-2 and gives the invariant replacement. Does any line of the record rely on the withdrawn §6 statement?'),
  ('Q-CUR-9', 'grade and receipt', 'Record level [ALG], FINITE_ORDER; the Evidence field says no historical certificate is rerun in r3; the only receipt is the r2 contributor review, whose author refers to "my C09 note". What evidence does the receiver need for the [ALG] grade at degree 13?'),
 ],
 'RER-F3-N7N8': [
  ('Q-N78-1', 'formal leading orders', 'Order/error: "E7 starts degree 8; E8 starts degree 9. E7=Delta_tau C8+Delta_tau C9+O(R^10); E8=Delta_tau C9+O(R^10)". N7REVIEW §2 (X-N78-2) is titled "[ALG, formal] Correct leading compatibility defect"; the jet-defect script (X-N78-5) reports a numerical grid estimate and a convergence test of E_N against Δ_τ C_{N+1}. Which held source gives the formal derivation, and is the record\'s [ALG] for the expansions based on it?'),
  ('Q-N78-2', 'Q_s range', 'Constraints: R = |s|_2, R²/2 ≤ Q_s ≤ 3R²/2. N7REVIEW §3 (inside X-N78-2) says the stated Q_s ranges used "an incorrect Euclidean-radius bound". Does the record\'s inequality match the corrected form there?'),
  ('Q-N78-3', '[NUM] sampled line', 'The [NUM] SAMPLED_ONLY line cites 24-direction, five-age pointwise defect/|D5| maxima and disclaims any supremum. Compare with N7REVIEW §4 (normalization) and the pointwise checker (cited in CURVNOTE §11). Is the line scoped as the source scopes it?'),
  ('Q-N78-4', 'one-step Q_s comparison', 'Transformation law and Memory say ΔQ_s = 0 in the one-step comparison is a construction artifact, not multi-step accuracy (N7REVIEW §5). Is this kept apart from any accuracy claim in the record?'),
  ('Q-N78-5', 'stage-1 local constants', 'The record\'s table gives "Reported Stage1 v2 local constants, not a region certificate" for three boxes, with "Governing status: source-reported repaired-v2 boxes". TM2NOTE is titled "certified one-step defect bounds" and its §6 names the repaired engine (X-N78-9, held, not rerun here). Which grade, if any, does the receiver attach to the three local constants, and does the record attach one?'),
  ('Q-N78-6', 'Taylor-model lemma and guard', 'The [OPEN] line reports the receiver\'s own scoped Taylor-model lemma review (19 Oct; not in this packet) and says the derivative-domain guard a ≤ 1 "is not enforced by the engine". Is the record\'s statement of that review and of the guard as the receiver intends?'),
  ('Q-N78-7', 'Stage-2 infrastructure', 'The record states: 41/41 infrastructure expectations in an isolated receiving rerun; K=6 pilot 8/8 rows, 4/904 boxes per N; K=8 1/8, stopped; aggregate checks exit 1 as PARTIAL. The held replay bundle reproduces the regression and the K=6 coverage output in the preparer timing runs below (scheduling only). Is the separate [ALG] line "Infrastructure evidence update only …" appropriate as a claim-tagged line, given that it states infrastructure facts?'),
  ('Q-N78-8', 'grade attachment of the main claim line', 'The [ALG] FINITE_ORDER claim line combines (a) formal E7/E8 expansions, (b) retained local box reports, (c) the Stage-2 replay and pilot status and (d) the lemma-review status. Which of (a)–(d) carry the [ALG] grade, and should the others be stated as evidence status rather than graded claims?'),
  ('Q-N78-9', 'non-held items', 'Not in this packet: the R3.1 replay receipts and contributor acceptance, R3_REQUEST (user-reported), the stage-1 v1 engine and logs, the lemma review. Does the receiver need any of them for this decision?'),
  ('Q-N78-10', 'receipts and author relation', 'The r2 review row for this record reads `ACCEPT SCOPED, with three corrections on my side` and the review lists corrections to "the N7/N8 line (my side)" (X-N78-13); several held sources describe themselves as receiving reviews without naming an author. How does the receiver weigh these receipts for this record?'),
 ],
}
VERDICT = re.compile(r'\b(PASS|PASSES|FAIL|ACCEPT|ACCEPTED|REJECT|REJECTED|CORRECT|INCORRECT|VALID|INVALID|recommend|recommended|verdict|we conclude|is proved|is wrong|sound|unsound)\b', re.I)

def load(): return {k: (HERE / p).read_bytes() for k, (p, h) in FILES.items()}
def span(md, rid):
    L = md.split('\n'); i = [n for n, l in enumerate(L) if l.startswith('### ' + rid + ' — ')]
    if len(i) != 1: return None
    i = i[0]; j = next((k for k in range(i + 1, len(L)) if L[k].startswith('### RER-') or L[k].startswith('<a id=') or L[k].startswith('## ')), len(L))
    while j > i and not L[j - 1].strip(): j -= 1
    return i + 1, j, '\n'.join(L[i:j])
def classify(text):
    L = text.split('\n'); out = {'heading': L[0], 'primary_grade_line': None, 'contract_rows': [], 'claim_lines': [], 'open_lines': [], 'import_lines': [], 'fields': [], 'other_lines': []}
    for l in L[1:]:
        if not l.strip() or l in ('| Field | Contract |', '|---|---|'): continue
        if l.startswith('**Primary grade:**'): out['primary_grade_line'] = l
        elif l.startswith('| '): out['contract_rows'].append(l)
        elif re.match(r'^\[(THM|ALG|NUM|DEF)\]', l): out['claim_lines'].append(l)
        elif l.startswith('[OPEN] '): out['open_lines'].append(l)
        elif l.startswith('Import/reference:'): out['import_lines'].append(l)
        elif re.match(r'^\*\*[^*]+:\*\*', l): out['fields'].append(l)
        else: out['other_lines'].append(l)
    return out
def extract(B, fk, start, end):
    t = B[fk].decode('utf-8'); L = t.split('\n'); i = [n for n, l in enumerate(L) if l.startswith(start)]
    if len(i) != 1: return None
    i = i[0]
    if end[0] == 'end': j = len(L)
    else: j = next((k for k in range(i + 1, len(L)) if L[k].startswith(end[1])), None)
    if j is None: return None
    while j > i + 1 and not L[j - 1].strip(): j -= 1
    return i + 1, j, '\n'.join(L[i:j])
def build(B):
    md = B['RER12'].decode('utf-8'); md6 = B['RER6'].decode('utf-8'); M = json.loads(B['MATRIX17']); INV = json.loads(B['B05INV'])
    recs = {}
    for rid in REVIEW:
        s = span(md, rid)
        if s is None: recs[rid] = None; continue
        i, j, t = s; s6 = span(md6, rid); inv = next((x for x in INV['items'] if x['record'] == rid), {})
        rows = [{k: x.get(k) for k in ('n', 'key', 'cited_path', 'section_or_RID', 'lines', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash')} for x in M['rows'] if x['record'] == rid]
        r = {'id': rid, 'role': 'REVIEW', 'rer_r4_12_lines': [i, j], 'span_sha256': sha(t.encode('utf-8')), 'text': t, 'parts': classify(t), 'phaseA_r17_rows': rows,
             'trail': {'r4_6_lines': None if s6 is None else [s6[0], s6[1]], 'r4_6_span_sha256': None if s6 is None else sha(s6[2].encode('utf-8')),
                       'b05_inventory_span_sha256': inv.get('record_sha256_of_span'), 'b05_inventory_md_lines': inv.get('md_lines'),
                       'b05_convention_r4_6_sha256': sha('\n'.join(md6.split('\n')[inv['md_lines'][0] - 1:inv['md_lines'][1]]).encode('utf-8')) if inv.get('md_lines') else None,
                       'b05_convention_note': 'the B-05 inventory hashes r4.6 lines md_lines[0]..md_lines[1] inclusive, i.e. the record span plus its trailing blank line',
                       'unchanged_since_r4_6': s6 is not None and s6[2] == t}}
        r['extracts'] = []
        for xid, rec, fk, st, en, label in EXTRACTS:
            if rec != rid: continue
            e = extract(B, fk, st, en)
            r['extracts'].append({'id': xid, 'file': FILES[fk][0], 'file_sha256': FILES[fk][1], 'label': label, 'lines': None if e is None else [e[0], e[1]],
                                  'sha256': None if e is None else sha(e[2].encode('utf-8')), 'text': None if e is None else e[2]})
        r['proof_material'] = [{'item': a, 'where': b, 'provenance': c, 'import_keys': k} for a, b, c, k in PROOF[rid]]
        r['questions'] = [{'id': q, 'topic': tp, 'question': qt} for q, tp, qt in QUESTIONS[rid]]
        recs[rid] = r
    return {'_about': 'RER Phase B-08 neutral review packet (NONCANONICAL; preparer Claude, RER co-owner). Verbatim quotations of byte-pinned sources, provenance-labelled proof material and questions; no PASS/FAIL, grade or acceptance recommendation is given for any claim.',
            'scope': {'review': REVIEW, 'decision_options_of_the_receiver': ['ACCEPT SCOPED', 'CORRECTION REQUIRED', 'INSUFFICIENT EVIDENCE'],
                      'context_inventories': 'the B-05 inventory (sources/history/) is PREPARER_AUTHORED context; the B-07 decision file is included because it names these two records as the next author-conflicted items'},
            'files': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()},
            'support_files_cited_in': SUPPORT_CITED_IN,
            'records': recs,
            'preparer_runs_timing_only': [{'script': a, 'wall_time': b, 'normal_mode': c, 'negative_mode': d, 'label': 'PREPARER_RUN — scheduling information, not receiver evidence'} for a, b, c, d in TIMING],
            'currency_note': 'Source RER r4.12 (7313647a…f4b9; the two records are byte-identical to r4.11) and Phase A r17 (receiver decision of 21 Oct 2026: `ACCEPT SCOPED`). The records cite study snapshots and evidence artifacts only; no owner-DSN currency question arises for them.'}
def render(P):
    J = (json.dumps(P, ensure_ascii=False, indent=1) + '\n').encode('utf-8')
    L = ['# RER Phase B-08 — neutral review packet', '', P['_about'], '',
         f"**Review (receiver decides per record or claim: {', '.join(P['scope']['decision_options_of_the_receiver'])}):** " + ', '.join(f'`{r}`' for r in P['scope']['review']), '',
         '**Context:** ' + P['scope']['context_inventories'] + '.', '', '**Currency note:** ' + P['currency_note'], '',
         '**Support files** (held; not RER imports; each hash is cited in the named held source): ' + '; '.join(f"`{P['files'][k]['path'].split('/')[-1]}` (`{P['files'][k]['sha256'][:8]}…`) — {', '.join(v)}" for k, v in P['support_files_cited_in'].items()), '']
    for rid in P['scope']['review']:
        r = P['records'][rid]; tr = r['trail']
        L += [f'## {rid}', '', f"RER r4.12 lines {r['rer_r4_12_lines'][0]}–{r['rer_r4_12_lines'][1]}; span SHA-256 `{r['span_sha256']}`. Byte-identical to r4.6 (lines {tr['r4_6_lines'][0]}–{tr['r4_6_lines'][1]}): {'yes' if tr['unchanged_since_r4_6'] else 'no'}; B-05 inventory span SHA-256 `{tr['b05_inventory_span_sha256']}`.", '',
              '### Record text (verbatim)', '', '```', r['text'], '```', '',
              '### Imports (Phase A r17)', '', '| n | Key | Cited | Section / lines | Bytes | Authentication | Currency | Status |', '|---|---|---|---|---|---|---|---|']
        L += [f"| {x['n']} | `{x['key']}` | {x['cited_version']} `{(x['cited_sha256'] or '—')[:12]}` | {x['section_or_RID']} {x['lines'] or ''} | {x['bytes_status']} | {x['authentication']} | {x['currency']} | {x['status']} |" for x in r['phaseA_r17_rows']]
        L += ['', '### Proof material and provenance', '', '| Item | Where | Provenance |', '|---|---|---|'] + [f"| {p['item']} | {p['where']} | {p['provenance']} |" for p in r['proof_material']]
        L += ['', '### Questions for the receiver (no answer is implied)', ''] + [f"- **{q['id']}** ({q['topic']}): {q['question']}" for q in r['questions']]
        L += ['', '### Source extracts (verbatim)', '']
        for x in r['extracts']:
            L += [f"#### {x['id']} — {x['label']}", '', f"`{x['file']}` lines {x['lines'][0]}–{x['lines'][1]}; extract SHA-256 `{x['sha256']}`", '', '````', x['text'], '````', '']
    L += ['## Preparer runs (timing only — not receiver evidence)', '', '| Script | Wall time | Normal mode | Negative mode |', '|---|---|---|---|'] + [f"| {t['script']} | {t['wall_time']} | {t['normal_mode']} | {t['negative_mode']} |" for t in P['preparer_runs_timing_only']]
    return J, ('\n'.join(L) + '\n').encode('utf-8')
def gates(B, P, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    on_disk = sorted(str(f.relative_to(HERE)) for f in (HERE / 'sources').rglob('*') if f.is_file())
    g('B1 input pins: every file under sources/ is pinned, every pin is present with its hash', on_disk == sorted(p for p, h in FILES.values()) and all(sha(B[k]) == h for k, (p, h) in FILES.items()), f'{len(FILES)} files')
    R = P['records']; md = B['RER12'].decode('utf-8')
    ok2 = all(R.get(r) and span(md, r) and R[r]['text'] == span(md, r)[2] and R[r]['span_sha256'] == sha(R[r]['text'].encode('utf-8')) and R[r]['text'] in md for r in REVIEW)
    g('B2 record spans: each record found once in r4.12, text verbatim, span hash recomputes', ok2)
    M = json.loads(B['MATRIX17'])
    ok3 = all(R[r] and [x['key'] for x in R[r]['phaseA_r17_rows']] == [x['key'] for x in M['rows'] if x['record'] == r]
              and len(R[r]['phaseA_r17_rows']) == len(R[r]['parts']['import_lines']) for r in REVIEW)
    g('B3 Phase A r17 rows match the pinned matrix and the record\'s Import/reference lines', ok3)
    X = [x for r in REVIEW for x in (R[r] or {}).get('extracts', [])]
    ok4 = len(X) == len(EXTRACTS) and all(x['text'] and x['sha256'] == sha(x['text'].encode('utf-8')) and x['text'] in B[next(k for k, (p, h) in FILES.items() if p == x['file'])].decode('utf-8') for x in X)
    g('B4 source extracts: anchors unique, non-empty, verbatim, hashes recompute', ok4, f'{len(X)} extracts')
    md6 = B['RER6'].decode('utf-8').split('\n'); INV = {x['record']: x for x in json.loads(B['B05INV'])['items']}
    def b05(r):
        a, z = INV[r]['md_lines']; return md6[a - 1:z]
    ok5 = all(R[r]['trail']['unchanged_since_r4_6'] and R[r]['trail']['r4_6_span_sha256'] == R[r]['span_sha256'] and r in INV
              and R[r]['trail']['b05_convention_r4_6_sha256'] == sha('\n'.join(b05(r)).encode('utf-8')) == INV[r]['record_sha256_of_span'] == R[r]['trail']['b05_inventory_span_sha256']
              and '\n'.join(b05(r)) == R[r]['text'] + '\n' for r in REVIEW)
    g('B5 trail: both records byte-identical in r4.6 and r4.12; the B-05 inventory span (record + trailing blank line) recomputes on r4.6', ok5)
    texts = [q['question'] for r in REVIEW for q in R[r]['questions']] + [p['provenance'] for r in REVIEW for p in R[r]['proof_material']] + [p['item'] for r in REVIEW for p in R[r]['proof_material']] \
            + [P['_about'], P['currency_note'], P['scope']['context_inventories']]
    unq = lambda t: re.sub(r'`[^`]*`', '', re.sub(r'"[^"]*"', '', t)).replace('no PASS/FAIL', '')  # quoted source text is not preparer judgement
    hits = [t[:50] for t in texts if VERDICT.search(unq(t))]
    g('B6 neutrality: no verdict word in the preparer-written questions, provenance and notes', not hits, f'{len(hits)} hit(s) {hits[:1]}')
    ok7 = P['scope']['review'] == REVIEW and len(REVIEW) == 2 and set(R) == set(REVIEW) and all(R[r]['role'] == 'REVIEW' and R[r]['questions'] and R[r]['extracts'] for r in REVIEW)
    g('B7 scope: exactly the two review records, each with questions and extracts', ok7)
    pm = [p for r in REVIEW for p in R[r]['proof_material']]
    ok8 = all(('RECEIVER' not in p['provenance'] or 'Phase A r17: RECEIVER_BYTE_VERIFIED' in p['provenance'] or 'as stated in the record' in p['provenance']) for p in pm) \
          and all('PREPARER_ROLE' in p['provenance'] for p in pm if 'RER editor' in p['provenance'] or 'RER editor' in p['item']) \
          and all(t['label'].startswith('PREPARER_RUN') and 'not receiver evidence' in t['label'] for t in P['preparer_runs_timing_only'])
    g('B8 provenance: receiver items only as stated in the record, preparer runs labelled; nothing preparer-made is receiver evidence', ok8)
    ok9 = all(sorted(k for p in R[r]['proof_material'] for k in p['import_keys']) == sorted(x['key'] for x in R[r]['phaseA_r17_rows']) for r in REVIEW)
    g('B9 coverage: every Import/reference row of each record covered exactly once in its proof-material table', ok9)
    SC = P['support_files_cited_in']
    ok10 = set(SC) == set(SUPPORT_CITED_IN) and all(FILES[k][0].startswith(U) for k in SC) and {k for k, (p, h) in FILES.items() if p.startswith(U)} == set(SC) \
           and all(SC[k] and all(FILES[k][1] in B[s].decode('utf-8', 'replace') for s in SC[k]) for k in SC)
    g('B10 support files: each held support file\'s full SHA-256 occurs in every held source named for it', ok10, f'{len(SC)} support files')
    return all(res), res
if __name__ == '__main__':
    B = load(); a = sys.argv[1:]
    if a and a[0] == '--negcontrol':
        P0 = build(B); allf = True
        def run(n, BB, PP, gi):
            global allf
            _, rr = gates(BB, PP, verbose=False); good = not rr[gi]; allf &= good
            print(f'  negative control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
        fl = lambda b: b[:100] + bytes([b[100] ^ 1]) + b[101:]
        T1, T2 = REVIEW
        run('B1 one byte flipped in the Stage-2 replay zip', dict(B, S2ZIP=fl(B['S2ZIP'])), P0, 0)
        P1 = copy.deepcopy(P0); P1['records'][T1]['text'] = P1['records'][T1]['text'].replace('generically nonzero', 'nonzero', 1); run('B2 record text paraphrased', B, P1, 1)
        P2 = copy.deepcopy(P0); P2['records'][T2]['phaseA_r17_rows'].pop(); run('B3 an import row dropped', B, P2, 2)
        P3 = copy.deepcopy(P0); P3['records'][T1]['extracts'][0]['text'] = P3['records'][T1]['extracts'][0]['text'].replace('1024', '1000', 1); run('B4 the wedge formula extract altered', B, P3, 3)
        P4 = copy.deepcopy(P0); P4['records'][T2]['trail']['b05_inventory_span_sha256'] = '0' * 64; run('B5 B-05 span hash forged', B, P4, 4)
        P5 = copy.deepcopy(P0); P5['records'][T2]['questions'][0]['question'] += ' The expansion is proved.'; run('B6 verdict inserted in a question', B, P5, 5)
        P6 = copy.deepcopy(P0); P6['records'][T1]['proof_material'][1]['provenance'] += ' — valid'; run('B6 judgement word in provenance', B, P6, 5)
        P7 = copy.deepcopy(P0); P7['scope']['review'] = REVIEW + ['RER-TRIAD-REGULAR-3FOLD']; run('B7 a third record added to the scope', B, P7, 6)
        P8 = copy.deepcopy(P0); P8['records'][T2]['proof_material'][12]['provenance'] = 'RECEIVER-VERIFIED lemma review'; run('B8 lemma review relabelled as verified', B, P8, 7)
        P9 = copy.deepcopy(P0); P9['preparer_runs_timing_only'][3]['label'] = 'RECEIVER_RUN'; run('B8 preparer run labelled receiver run', B, P9, 7)
        P10 = copy.deepcopy(P0); P10['records'][T2]['proof_material'][0]['import_keys'] = ['N7REVIEW']; run('B9 two N7REVIEW rows dropped from the proof-material table', B, P10, 8)
        P11 = copy.deepcopy(P0); P11['support_files_cited_in'] = dict(P11['support_files_cited_in'], TMV2=['TMREVIEW']); run('B10 support file attributed to a source that does not cite it', B, P11, 9)
        sys.exit(0 if allf else 1)
    P = build(B); ok, res = gates(B, P); J, Md = render(P)
    if a and a[0] == '--check':
        same = (HERE / 'B08_REVIEW_PACKET.json').read_bytes() == J and (HERE / 'B08_REVIEW_PACKET.md').read_bytes() == Md
        print(f'{sum(res)}/{len(res)} gates PASS; stored outputs byte-identical: {same}'); sys.exit(0 if ok and same else 1)
    (HERE / 'B08_REVIEW_PACKET.json').write_bytes(J); (HERE / 'B08_REVIEW_PACKET.md').write_bytes(Md)
    print(f'{sum(res)}/{len(res)} gates PASS; B08_REVIEW_PACKET.json {sha(J)[:16]}, B08_REVIEW_PACKET.md {sha(Md)[:16]}'); sys.exit(0 if ok else 1)
