import json, mpmath as mp
from fractions import Fraction
p=json.load(open(__import__('pathlib').Path(__file__).resolve().parent / 'age_family_polynomials_kt1.json'))
mp.mp.dps=50
C={int(key[1:]):{int(m[5:]):[[mp.mpf(Fraction(v).numerator)/Fraction(v).denominator for v in values] for values in arr] for m,arr in rows.items()} for key,rows in p.items()}
half=mp.mpf('0.5')
def te(v):
 r,e=v; return (r-mp.sin(e),e+mp.expm1(r)-mp.sin(e))
def fn(s,c):
 for _ in range(6):
  a=te(s); b=te((-half*s[0]+c[0],-half*s[1]+c[1])); d=te((-half*s[0]-c[0],-half*s[1]-c[1]));
  s=((2*a[0]-b[0]-d[0])/3,(2*a[1]-b[1]-d[1])/3); c=((b[0]-d[0])/2,(b[1]-d[1])/2)
 return s,c
def cmb(t,k):
 x=mp.mpf(1)
 for v in range(k): x*=t-v
 return x/mp.factorial(k)
def ca(N,s,t):
 r,e=s;out=[mp.mpf(0),mp.mpf(0)]
 for d in range(3,N+1):
  for m,arr in C[d].items():
   w=cmb(t,m)
   for i in range(2):out[i]+=w*sum(v*r**(d-k)*e**k for k,v in enumerate(arr[i]))
 return tuple(out)
def norm(v):return mp.sqrt(sum(a*a for a in v))
for R0 in (0.03,0.08,0.12,0.18,0.25):
 R=mp.mpf(str(R0)); worst={7:(mp.mpf(0),None),8:(mp.mpf(0),None)}
 for a in range(24):
  th=mp.pi*a/12; s=(R*mp.cos(th),R*mp.sin(th)); q=s[0]*s[0]-s[0]*s[1]+s[1]*s[1];d5=half*q*q*R
  for t2 in range(5):
   t=mp.mpf(t2)/2
   for N in (7,8):
    c=ca(N,s,t);sp,cp=fn(s,c); ct=ca(N,sp,t+1)
    err=norm((cp[0]-ct[0],cp[1]-ct[1]))/d5
    if err>worst[N][0]:worst[N]=(err,(a,t2,mp.nstr(q,9)))
 print('R=',R0,'sup_pointwise_E/D5(N7)=',mp.nstr(worst[7][0],7),'at',worst[7][1],'N8=',mp.nstr(worst[8][0],7),'at',worst[8][1])
