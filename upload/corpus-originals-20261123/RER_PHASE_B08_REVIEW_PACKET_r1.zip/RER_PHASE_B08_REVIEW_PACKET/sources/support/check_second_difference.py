#!/usr/bin/env python3
"""Exact cubic-jet proof of C09 age-second-difference at degree seven.
This does not execute the author's full 511-case checker, nor prove
existence of a convergent physical/analytic time interpolation.
"""
from pathlib import Path
import json, sys
import sympy as S
root = Path(__file__).resolve().parents[1]
source = json.loads((root / 'source' / 'jet_coefficients.json').read_text())
r,e,cr,ce,kt = S.symbols('r e cr ce kt', real=True)
vars4 = [r,e,cr,ce]
def polynomial(data):
    out = 0
    for exp,co in data.items():
        term = S.Rational(co)
        for x,j in zip(vars4, map(int,exp.split(','))):
            term *= x**j
        out += term
    return S.expand(out)
g3 = S.Matrix([polynomial(d) for d in source['G3']])
Q = r*r-r*e+e*e
D5 = -(kt/S.Integer(2))*Q**2*S.Matrix([r,e])
C3 = kt*Q*S.Matrix([[1,-2],[2,-1]])*S.Matrix([r,e])
gs = S.Matrix([g3[i].subs({cr:0,ce:0}) for i in range(2)])
Ac = g3[2:4,:].jacobian([cr,ce]).subs({cr:0,ce:0})
D5_from_source = S.simplify(Ac*C3 - C3.jacobian([r,e])*gs)
B7 = S.simplify(Ac*D5-D5.jacobian([r,e])*gs)
expected = kt/S.Integer(4)*Q**3*S.Matrix([r,e])
checks = [
    ('source identity cubic terms', len(g3)==4),
    ('cubic source zero at origin', all(gi.subs({r:0,e:0,cr:0,ce:0})==0 for gi in g3)),
    ('degree five drift', all(S.Poly(di, r,e).total_degree()==5 for di in D5)),
    ('degree five drift derived from source', all(S.expand(z)==0 for z in D5_from_source-D5)),
    ('degree seven predicted difference', all(S.Poly(bi,r,e).total_degree()==7 for bi in B7)),
    ('vector coefficient all directions', all(S.expand(z)==0 for z in B7-expected)),
    ('parallel to D5', all(S.expand(z)==0 for z in B7+Q*D5/2)),
    ('nonzero for nonzero kappa', any(S.expand(x)!=0 for x in B7)),
]
for u in [(1,0),(0,1),(1,1),(2,-1),(1,3)]:
    residual=B7-expected
    checks.append((f'ray {u}', all(S.expand(z.subs({r:u[0],e:u[1]}))==0 for z in residual)))
wrong = kt/S.Integer(6)*Q**3*S.Matrix([r,e])
if '--negative' in sys.argv:
    checks.append(('wrong B7 coefficient must be rejected', all(S.expand(z)==0 for z in B7-wrong)))
failed=[]
for label,good in checks:
    print(('PASS' if good else 'FAIL'),label)
    if not good: failed.append(label)
print(f'checks={len(checks)}, failures={len(failed)}')
print('B7=',[S.factor(t) for t in B7])
print('D5=',[S.factor(t) for t in D5])
sys.exit(1 if failed else 0)
