#!/usr/bin/env python3
"""
Finite-jet compatibility defect of the formal age family, N = 7 and N = 8, against the real analytic map.

Model: Genesis->RER conditional analytic modal map F = N^6 (reprojection after each primitive step),
trial birth graph C_k(s) = k Q(s) J_Q s, kappa = sqrt3*kt.  Formal age family (Triadic/contributor, 9 Oct):
   C(s,tau) = sum_d C_d(s,tau),  C_d polynomial in tau of degree <= floor((d-3)/2),   F(s,C(s,tau)) = (s+, C(s+,tau+1)).

Part A (exact, standard library): reconstruct C_d(s,tau) for d = 3..DMAX as explicit homogeneous polynomials in
(r,e) with binomial-basis tau coefficients, from exact ray series of the full map (d+1 rational rays per degree,
ages 0..floor((d-3)/2)).  Independent of any jet file; also yields D7, D8, D9 without a quintic jet.
Part B (numeric, mpmath 50 digits): the defect
   E_N(s,tau) = F_c(s, C_N(s,tau)) - C_N( F_s(s, C_N(s,tau)), tau+1 ),
its normalised size |E_N| / |s|^(N+1) over a grid q_min <= Q_s <= q_max, 0 <= tau <= T, compared with the
predicted leading term  Delta_tau C_{N+1}(s,tau) = C_{N+1}(s,tau+1) - C_{N+1}(s,tau)  (because d_c F_c = I + O(2),
the omitted order enters at both ends of the step), and the induced errors in Q_s, I_sc, Omega_G.
Empirical sup over a grid is reported.  It is NOT a certified bound K_{N,T}.

Usage: python triad_finite_jet_defect_N7_N8.py [--negative]   (negative: drop C_7 from C_7 -> leading order must break)
Requires the rev2 series file in ../source/ (SHA-256 67b2e0e7...799b) and mpmath.
"""
import sys, hashlib, json, time
from pathlib import Path
from fractions import Fraction as Fr
import mpmath as mp

SERIES = Path(__file__).resolve().parent.parent / 'source' / 'c09_independent_series_check_rev2.py'
assert hashlib.sha256(SERIES.read_bytes()).hexdigest() == '67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b'
NEG = '--negative' in sys.argv
DMAX = 9
KT = Fr(1)                      # kappa = sqrt3
mp.mp.dps = 50
t0 = time.time()

g = {'__name__': '__probe__'}
exec(SERIES.read_text().split('# ---------------------------------------------------------------- checks')[0], g)
g['NT'] = DMAX
ray, Fn, birth, inv_parent, order = g['ray'], g['Fn'], g['birth'], g['initial_for_current_parent'], g['order']

# ---------------- Part A: exact polynomial reconstruction ---------------------------------------------------------
def binom_coeffs(vals):
    """values at n=0..M -> coefficients in basis binom(n,m), m=0..M (forward differences at 0)."""
    out, d = [], vals[:]
    while d:
        out.append(d[0]); d = [d[i+1]-d[i] for i in range(len(d)-1)]
    return out
def solve_vandermonde(xs, ys):
    """exact solve sum_k a_k x^k = y."""
    n = len(xs); A = [[Fr(x)**k for k in range(n)] + [Fr(y)] for x, y in zip(xs, ys)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0); A[c], A[p] = A[p], A[c]
        A[c] = [v / A[c][c] for v in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0: A[r] = [a - A[r][c]*b for a, b in zip(A[r], A[c])]
    return [A[k][n] for k in range(n)]

# C_d(s,tau) = sum_m binom(tau,m) * sum_k a[d][m][k] r^(d-k) e^k
C = {d: {} for d in range(3, DMAX+1)}
rays = [(1, j) for j in range(DMAX+1)]           # (1,j): t^d coefficient = sum_k a_k j^k
MAXAGE = (DMAX-3)//2
sheet = {}
for u in rays:
    tgt = ray(u)
    sheet[u] = [Fn(birth(inv_parent(tgt, n, KT), KT), n)[1] for n in range(MAXAGE+1)]
for d in range(3, DMAX+1):
    M = (d-3)//2
    for i in range(2):
        per_ray_binom = {u: binom_coeffs([sheet[u][n][i][d] for n in range(M+1)]) for u in rays}
        # also verify the degree bound: higher finite differences must vanish when extra ages available
        for m in range(M+1):
            ys = [per_ray_binom[u][m] for u in rays[:d+1]]
            C[d].setdefault(m, [None, None])[i] = solve_vandermonde([u[1] for u in rays[:d+1]], ys)
# consistency: reconstructed polynomials reproduce the ray (2,-1) sheets (not used in the fit)
def eval_C_exact(d, m, i, r, e):
    return sum(a * Fr(r)**(d-k) * Fr(e)**k for k, a in enumerate(C[d][m][i]))
chk_u = (2, -1); tgt = ray(chk_u)
test = [Fn(birth(inv_parent(tgt, n, KT), KT), n)[1] for n in range(MAXAGE+1)]
ok_recon = True
from math import comb
for d in range(3, DMAX+1):
    for n in range(MAXAGE+1):
        for i in range(2):
            pred = sum(comb(n, m) * eval_C_exact(d, m, i, *chk_u) for m in C[d])
            ok_recon &= (pred == test[n][i][d])
print('PASS' if ok_recon else 'FAIL', f'reconstructed C_d (d=3..{DMAX}) reproduce an independent ray (2,-1), ages 0..{MAXAGE}')
Q = lambda r, e: r*r - r*e + e*e
# sanity against known closed forms
D5 = C[5][1]; B7 = C[7][2]
ok5 = all(eval_C_exact(5, 1, i, r, e) == -KT/2*Q(r, e)**2*(r, e)[i] for (r, e) in [(1, 0), (2, 3), (-1, 5)] for i in range(2))
ok7 = all(eval_C_exact(7, 2, i, r, e) == KT/4*Q(r, e)**3*(r, e)[i] for (r, e) in [(1, 0), (2, 3), (-1, 5)] for i in range(2))
print('PASS' if ok5 and ok7 else 'FAIL', 'D5 = -(kt/2)Q^2 s and B7 = (kt/4)Q^3 s recovered from the reconstruction')
print(f'   tau-degrees by s-degree: {[(d, max(C[d])) for d in range(3, DMAX+1)]}   [{time.time()-t0:.0f}s]')
json.dump({f'd{d}': {f'binom{m}': [[str(x) for x in C[d][m][i]] for i in range(2)] for m in C[d]} for d in C},
          open(Path(__file__).resolve().parent / 'age_family_polynomials_kt1.json', 'w'), indent=1)

# ---------------- Part B: numeric defect against the real map ------------------------------------------------------
HALF = mp.mpf(1)/2
def Te(v):
    r, e = v; return (r - mp.sin(e), e + mp.expm1(r) - mp.sin(e))
def Nstep(s, c):
    a = Te(s); b = Te((-HALF*s[0]+c[0], -HALF*s[1]+c[1])); d = Te((-HALF*s[0]-c[0], -HALF*s[1]-c[1]))
    return ((2*a[0]-b[0]-d[0])/3, (2*a[1]-b[1]-d[1])/3), ((b[0]-d[0])/2, (b[1]-d[1])/2)
def Fmap(s, c):
    for _ in range(6): s, c = Nstep(s, c)
    return s, c
def binom_mp(tau, m):
    out = mp.mpf(1)
    for j in range(m): out *= (tau - j)
    return out / mp.factorial(m)
def C_N(N, s, tau, drop=None):
    r, e = s; out = [mp.mpf(0), mp.mpf(0)]
    for d in range(3, N+1):
        if d == drop: continue
        for m, coef in C[d].items():
            w = binom_mp(tau, m)
            for i in range(2):
                out[i] += w * sum(mp.mpf(a.numerator)/a.denominator * r**(d-k) * e**k for k, a in enumerate(coef[i]))
    return tuple(out)
def C_d_only(d, s, tau):
    r, e = s; out = [mp.mpf(0), mp.mpf(0)]
    for m, coef in C[d].items():
        w = binom_mp(tau, m)
        for i in range(2): out[i] += w * sum(mp.mpf(a.numerator)/a.denominator * r**(d-k) * e**k for k, a in enumerate(coef[i]))
    return tuple(out)
Bq = lambda u, v: u[0]*v[0] + u[1]*v[1] - HALF*(u[0]*v[1] + u[1]*v[0])
def obs(s, c):
    return (Bq(s, s), Bq(s, c), mp.sqrt(3)/2*(s[1]*c[0] - s[0]*c[1]))     # Q_s, I_sc, Omega_G

norm = lambda v: mp.sqrt(v[0]**2 + v[1]**2)
rad = [mp.mpf(x)/1000 for x in (3, 10, 30, 50, 80, 120, 180, 250)]       # |s| ; Q_s ranges ~ |s|^2 * [0.75,1] in these coords
angs = [mp.pi*k/12 for k in range(24)]
taus = [mp.mpf(x)/2 for x in range(0, 5)]                     # 0 .. 2
results = {}
for N in (7, 8):
    drop = 7 if (NEG and N == 7) else None
    sup_ratio, sup_lead, sup_obs = {}, {}, {}
    rows = []
    for R in rad:
        worst = mp.mpf(0); worst_pred = mp.mpf(0); worst_rel = mp.mpf(0); wobs = [mp.mpf(0)]*3
        for th in angs:
            s = (R*mp.cos(th), R*mp.sin(th))
            for tau in taus:
                c = C_N(N, s, tau, drop)
                sp, cp = Fmap(s, c)
                cpred = C_N(N, sp, tau+1, drop)
                E = (cp[0]-cpred[0], cp[1]-cpred[1])
                lead = [mp.mpf(0), mp.mpf(0)]                        # E_N ~ Delta_tau (C_{N+1} + C_{N+2}) ; stored negated
                for dd in range(N+1, min(N+2, DMAX)+1):
                    l1 = C_d_only(dd, s, tau+1); l0 = C_d_only(dd, s, tau)
                    lead[0] += l0[0]-l1[0]; lead[1] += l0[1]-l1[1]
                ratio = norm(E)/R**(N+1)
                rel = norm((E[0]+lead[0], E[1]+lead[1]))/max(norm(lead), mp.mpf('1e-60'))
                o_true = obs(sp, cp); o_pred = obs(sp, cpred)
                worst = max(worst, ratio); worst_pred = max(worst_pred, norm(lead)/R**(N+1)); worst_rel = max(worst_rel, rel)
                wobs = [max(wobs[i], abs(o_true[i]-o_pred[i])) for i in range(3)]
        rows.append((R, worst, worst_pred, worst_rel, wobs))
        print(f'N={N} |s|={mp.nstr(R,3)} Q_s~[{mp.nstr(0.75*R*R,2)},{mp.nstr(R*R,2)}] tau in[0,2]:  sup|E_N|/|s|^{N+1} = {mp.nstr(worst,5)}'
              f'   sup|pred|/|s|^{N+1} = {mp.nstr(worst_pred,5)}   sup|E_N - pred|/|pred| = {mp.nstr(worst_rel,3)}'
              f'   sup err (Q_s,I_sc,Omega_G) = ({mp.nstr(wobs[0],3)},{mp.nstr(wobs[1],3)},{mp.nstr(wobs[2],3)})')
    results[N] = rows
    OKLEAD = globals().setdefault('OKLEAD', True)
    # leading-term test: relative deviation from -C_{N+1} must shrink like |s|^2 as |s| -> 0
    rels = [row[3] for row in rows]
    ok_lead = rels[0] < mp.mpf('0.01') and rels[0] < rels[1] < rels[-1]   # asymptotic regime at the smallest radii
    globals()['OKLEAD'] = globals().get('OKLEAD', True) and ok_lead
    print('PASS' if ok_lead else 'FAIL', f'N={N}: E_N -> Delta_tau C_(N+1)(s,tau) [+Delta_tau C_(N+2) if available] as |s|->0 (relative deviation {mp.nstr(rels[0],3)} at |s|={mp.nstr(rad[0],3)}, monotone in |s|)')
    # age-resolution figure: defect vs fibre separation |D5| ~ (kt/2) Q^2 |s|
    R = rad[-1]; print(f'   at |s|={mp.nstr(R,3)}: sup|E_{N}| ~ {mp.nstr(rows[-1][1]*R**(N+1),3)} vs |D5|~{mp.nstr(mp.mpf(KT.numerator)/KT.denominator/2*R**5,3)}  (ratio {mp.nstr(rows[-1][1]*R**(N+1)/(mp.mpf(1)/2*R**5),3)})')
print(f'[{time.time()-t0:.0f}s]')
sys.exit(0 if (ok_recon and ok5 and ok7 and OKLEAD and not NEG) else 1)
