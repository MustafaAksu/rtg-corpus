# Stage-2 replay bundle — 14 Oct 2026 (NONCANONICAL; infrastructure + pilot rows, no region result)

## regression/  — reproduces the reported 41-expectation infrastructure suite
Run in this folder:  `python -I triad_stage2_regression.py`   (≈ 2 min; exit 0 = 41/41)
Inputs are the exact files used for the reported run: current driver v3, shared contract, coverage v3, engine v3.2,
pinned coefficient table, `reg_config.json` (coarse K=4 tiling, 52 boxes/N) and the two GENUINE worker outputs
`W_inner.jsonl` (56 rows) / `W_outer.jsonl` (48 rows) produced by
  `python triad_stage2_driver.py --config reg_config.json --only inner --results W_inner.jsonl` (and `--only outer ... W_outer.jsonl`).
To regenerate the worker files from scratch instead (≈ 7 min wall with two processes), delete them and run those two commands first.
The suite writes scratch files (M_*.jsonl, R_*.jsonl, alt_poly.json, reg_config_*.json) and REGRESSION_RESULTS.json; they can be deleted.

## pilots/  — governing-contract pilot rows (engine v3.2)
- `stage2_config.json` (K=6, governing) + `stage2_pilot_K6_v32.jsonl`: 8/8 rows, all accepted by the shared contract.
  `python -I triad_stage2_coverage.py --config stage2_config.json --results stage2_pilot_K6_v32.jsonl` -> PARTIAL (4 of 904 boxes/N), exit 1 by design.
- `stage2_config_K8.json` (K=8, separate semantic identity) + `stage2_pilot_K8_v32.jsonl`: 1/8 rows (stopped on request). Resume with
  `python triad_stage2_driver.py --config stage2_config_K8.json --pilot --results stage2_pilot_K8_v32.jsonl`.
Pilot rows are engine-reported upper bounds under the stated contract; the Taylor-model lemma review remains a separate open gate.
