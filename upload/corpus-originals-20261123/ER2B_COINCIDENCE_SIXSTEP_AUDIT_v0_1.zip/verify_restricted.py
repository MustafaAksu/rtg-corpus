from pathlib import Path
s=Path(__file__).with_name('check_iterate_family.py').read_text().split('# n=2:')[0]
exec(s)
x=(V[0],V[1],{}, {})
for j in range(6): x=step(x,4)
for i in [2,3]:
 print('r2 component',i-2)
 for d in (2,3,4):print('degree',d,fmt(deg(x[i],d)))
