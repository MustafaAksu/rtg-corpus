"""Edit list RER v0.2 DRAFT r4.10 -> r4.11 (PI decision of 21 Oct 2026 after the B-06 receiving review and the RECOG G3 notice to RER):
A  RER-TRIAD-FORMAL-AGE (B-06: CORRECTION REQUIRED, grade/provenance): grade aligned to the FORMAL receiving review `[ALG, formal]`;
   A1 primary-grade line [THM] -> [ALG]; A2 one grade-provenance note line below it; A3 claim line [THM] -> [ALG] (statement unchanged);
   A4 Evidence: degree bound vs finite checker tests; hash 67b2e0e7 belongs to the series script, archive identity unverified;
   A5 Review receipt: r2 contributor acceptance (byte-verified now) is the result author's review; B-06 dispositions; PI decision.
B  RER-G9 (RECOG G3 notice to RER, 53341b9a…14b5): B1 W3 quoted verbatim from RECOG §6.16g and W1 fixed-graph requirement added;
   B2 W3 source note: RRF v0.8.4 since adopted (owner-reported), still not a pin; B3 overlay: v0.3.20 frozen with G1 record, current RECOG editions.
C  RECOG lifecycle labels outside G9: C1 source-table row RECOG; C2 the §9 pins sentence. Pins, hashes and line ranges unchanged.
Plus metadata (M1-M3), one [ALG] §9 history entry (H1) and one release-boundary sentence (H2). No other record, grade, OPEN item or pin changes."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_10.md').read_text(encoding='utf-8')
BASE_SHA = '5b1d06544952682317354c49341328a67aa099a74918066d7ed66ed7e5fab53c'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
FORMAL = 'b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899'; R2REV = 'd388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab'
G3 = '53341b9a85d9073d7ec22a2ef280b4fe206fbc5f7597256362fa5b880ca414b5'; G1 = '5c00f66dae7d4de6ccd4a04d642a23edfc861bbd6bd55e432513747fbd679b55'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix, within=None):
    t = B if within is None else within
    ls = [l for l in t.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]
AGE = B.split('### RER-TRIAD-FORMAL-AGE — ')[1].split('\n<a id=')[0]
G9 = B.split('### RER-G9 — ')[1].split('\n### RER-G10')[0]

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.10\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.11\n')
ed('M2', 'metadata', '**Date:** 20 October 2026 (r4.10, r4.9, r4.8, r4.7);', '**Date:** 21 October 2026 (r4.11); 20 October 2026 (r4.10, r4.9, r4.8, r4.7);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.10 — narrow W3 source-fidelity revision',
   f'**Document status:** DRAFT r4.11 — narrow correction revision (PI decision of 21 Oct 2026): RER-TRIAD-FORMAL-AGE grade aligned to its source review `[ALG, formal]` (B-06 CORRECTION REQUIRED); RER-G9 W1/W3 quoted from RECOG §6.16g and RECOG lifecycle labels updated (RECOG G3 notice to RER); built deterministically on the exact r4.10 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_11_draft.py`; no pin, OPEN item or other record changes. r4.10 was: narrow W3 source-fidelity revision')

g = line('**Primary grade:** [THM]. **Exactness:** `FORMAL_ONLY`. **Task:** `SOURCE_SCOPED_RESULT_RECORDED`. **Registry/owner adoption:** pending / none.', AGE)
note = ('**Grade provenance** (r4.11): the source review FORMAL_AGE_FAMILY_REVIEW.md (SHA-256 `' + FORMAL + '`) grades the result `[ALG, formal — accepted with scope corrections]`; '
        'r2–r4.10 carried a theorem grade, whose only receipt is the r2 contributor review TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md (SHA-256 `' + R2REV + '`), written by the author of the result; '
        'B-06 receiving review (21 Oct 2026): formal construction and uniqueness in the polynomial-age class ACCEPT SCOPED, grade/provenance CORRECTION REQUIRED; PI decision (21 Oct 2026): grade aligned to the source review. The mathematical statement, scope and exactness are unchanged.')
ed('A1', 'grade', g, g.replace('**Primary grade:** [THM].', '**Primary grade:** [ALG] (formal; source grade, r4.11).', 1) + '\n' + note)
c = line('[THM] **FORMAL_ONLY.** There is a unique polynomial-in-tau coefficient family', AGE)
ed('A3', 'grade', c, c.replace('[THM] **FORMAL_ONLY.**', '[ALG] **FORMAL_ONLY.**', 1))
ev = line('**Evidence:** original scientific source pins and earlier verification scopes are retained from r2.', AGE)
ev_new = ev + (' r4.11: the bound deg_tau C_d<=floor((d-3)/2) is the corrected bound of the source review; the checker FORMALSCRIPT states the weaker bound "<= d-4" (not meaningful at d=3) and, with SERIES2, runs finite-order sampled tests '
               '(three ray/kappa combinations, tau = 1/2, -1/3, 5/2, through t^12); neither is an all-orders proof, which is the structural proof in the source review. '
               'SHA-256 `67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b` is the hash of the series script (SERIES2; asserted by FORMALSCRIPT for source/c09_independent_series_check_rev2.py); '
               'the source review writes it after the archive name TRIAD_C09_TAU_RECEIVING_20261009.zip, whose own bytes are not held, so the archive identity is not verified.')
assert B.count(ev) == 1 or True
# the Evidence line text is shared with other records; edit it only inside RER-TRIAD-FORMAL-AGE by anchoring on the record's own neighbours
ctx_old = ev + '\n\n**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending. [TRIAD_R2_REVIEW:'
rr = line('**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending. [TRIAD_R2_REVIEW:', AGE)
ctx_old = ev + '\n\n' + rr + '\nImport/reference: [FORMAL:'
assert B.count(ctx_old) == 1
rr_new = rr + (' r4.11: that r2 review (bytes now held, SHA-256 matches) accepted the record with a theorem grade; it is the result author\'s own review. '
               'B-06 (21 Oct 2026, receiving co-owner): ACCEPT SCOPED for the formal construction, CORRECTION REQUIRED for grade/provenance, applied here.')
ed('A4', 'evidence', ctx_old, ev_new + '\n\n' + rr_new + '\nImport/reference: [FORMAL:')

s6 = line('[DEF] Cross-model T_k/T_-k conjugacy, a within-chart involution,', G9)
w1o = 'W1 carrier/graph,'
w3o = s6[s6.index('W3 event-indexed cochains a^- and a^+'):s6.index(', W4 independence')]
assert s6.count(w1o) == 1
w1n = 'W1 carrier/graph — "a fixed directed graph, coefficient module and edge cochain $a$ with a registered realization" (RECOG §6.16g, verbatim; r4.11),'
w3n = ('W3 "event-indexed cochains $a^-$, $a^+$ in the **same** cohomology space, so that $\\Delta[a]=[a^+]-[a^-]$ is defined" (RECOG v0.3.21 §6.16g, verbatim, byte-identical to the v0.3.20 pin; '
       'r4.11 per the RECOG G3 notice to RER; the r4.10 plain-text rendering and the earlier summary "a shared pre/post comparison space" are superseded)')
ed('B1', 'G9', s6, s6.replace(w1o, w1n, 1).replace(w3o, w3n, 1))
wn = line('[DEF] **r4.10 W3 source note**', G9)
tail = 'the non-adopted RRF v0.8.4 review candidate is neither a source nor a pin here.'
assert wn.endswith(tail)
ed('B2', 'G9', wn, wn + ' r4.11: RRF v0.8.4 has since been adopted (20 Oct 2026, SHA-256 `2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce`, owner-reported by its adoption record; bytes not held here); '
   'per that record its §6.3 states W3 at owner scope and keeps different-space transport as an explicitly OPEN additional RRF interface. RER pins are unchanged (RRF v0.8 / v0.8.3); v0.8.4 is not a pin here.')
ov = line('[DEF] **r4.6 current-use overlay (RRF editor Q2: SAME-SCOPE, owner-first).**', G9)
assert ov.count('(freeze candidate)') == 1
ed('B3', 'G9', ov, ov.replace('(freeze candidate)', '(frozen 19 Oct 2026, G1 record `RECOG_v0_3_20_FREEZE_DECISION_PROVENANCE.md`, SHA-256 `' + G1 + '`; r4.11, was "freeze candidate")', 1)
   + ' r4.11 (RECOG G3 notice to RER, SHA-256 `' + G3 + '`, received by the RER preparer via the PI on 21 Oct 2026): current RECOG authority v0.3.21 (`a3459522…0ae3`, adopted 20 Oct 2026, byte-verified in Phase A r13; the cited §6.6a and §6.16g are byte-identical to v0.3.20, at lines 521–546 and 1006–1046), '
   'and later v0.3.22 (`0dcce9e4…bcd9`, adopted 20 Oct 2026, owner-reported; its release changes no RID consumed by RER); the v0.3.20 pins, line ranges and hashes below are kept.')
st = line('| `RECOG` | 0.3.20; V0_3_20_FREEZE_CANDIDATE_IN_HEADER; no separate release authentication claimed |')
ed('C1', 'lifecycle', st, st.replace('V0_3_20_FREEZE_CANDIDATE_IN_HEADER; no separate release authentication claimed', 'V0_3_20_FREEZE_CANDIDATE_IN_HEADER (historical header label); frozen 19 Oct 2026 per the G1 record `' + G1[:8] + '…' + G1[-4:] + '` (r4.11); no separate release authentication claimed', 1))
ps = '`RECOG` v0.3.20 (freeze candidate; no later release assumed — Dyadic v6.4.12.1 cites v0.3.20)'
ed('C2', 'lifecycle', ps, '`RECOG` v0.3.20 (frozen 19 Oct 2026, G1 record; r4.11, was: freeze candidate, no later release assumed — Dyadic v6.4.12.1 cites v0.3.20; later releases v0.3.21 and v0.3.22, see the RER-G9 overlay)')

h = line('[ALG] R4.10 (20 Oct 2026) is a narrow W3 source-fidelity revision')
ed('H1', 'history', h, '[ALG] R4.11 (21 Oct 2026) is a narrow correction revision on the exact r4.10 bytes. (a) RER-TRIAD-FORMAL-AGE: following the B-06 receiving review (grade/provenance CORRECTION REQUIRED) and the PI decision of 21 Oct 2026, '
   'the primary grade and the claim line are aligned to the source review\'s `[ALG, formal]`; a grade-provenance line, an Evidence addition (degree bound vs finite checker tests; hash 67b2e0e7 is the series script\'s, archive identity unverified) '
   'and a Review-receipt addition (the r2 theorem-grade acceptance was the result author\'s own review) record why; statement, scope, exactness and imports are unchanged. '
   '(b) RER-G9, per the RECOG G3 notice to RER: W1 and W3 quoted verbatim from RECOG §6.16g; v0.3.20 marked frozen with its G1 record; current RECOG editions recorded; RRF v0.8.4 adoption recorded as owner-reported, not a pin. '
   '(c) RECOG lifecycle labels in the source table and the §9 pins sentence updated. No pin, line range, OPEN item or other record changes.\n' + h)
rb = '**Release boundary (r4.10):** r4.10 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.11):** r4.11 is a noncanonical review draft; it adopts, freezes and accepts nothing; its grade change records a source-review grade and is not a new scientific acceptance. ' + rb)
t = B
for e in E: assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_10_to_r4_11_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
