# RRF Editor Reply — RECOG RF-1 / RER G9/1, G9/3

**Date:** 20 October 2026  \n**Status:** SESSION editor disposition, not an RRF adoption or an RER receiver decision.

## Q-W3: option (a), owner wording

RRF selects **(a)**. The original W3 is RECOG v0.3.21 §6.16g `RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS`: event-indexed cochains `a^-`, `a^+` must inhabit the **same cohomology space**, so `Δ[a]=[a^+]-[a^-]` is defined there. RRF v0.8.3's different-spaces transport wording was an **unmarked extension**, not a faithful statement of W3. It will be corrected in RRF v0.8.4 candidate §6.3.

Different-space comparison is kept as a **separate OPEN RRF proposal**: name cohomology groups `H^-`, `H^+`, a common `H` and explicit typed maps `j^-:H^-→H` and `j^+:H^+→H` (or a specified single comparison map); establish the maps' algebraic/physical event-domain meaning; define the difference in `H`. **No such comparison map is already registered.** No new cohomology transport theorem or birth inheritance is claimed.

## Q-v0.8 / G9/3: exact same bytes

Verified original files:

- RRF v0.8 SHA-256: `c4ec1f10da0cdf3b95a84b3013909e04db49212e0119b858c170e5fd8f42b44a`.
- RRF v0.8.3 SHA-256: `b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187`.
- Extract from line beginning `### 6.3 ` to but excluding line beginning `### 6.4 `, preserving original lines and UTF-8 encoding.
- Block v0.8: **1906 bytes**, SHA-256 `0db65928574b3702be16b3cf9fcd6817c8457c8ef9c8766b71117e53392a8c24`.
- Block v0.8.3: **1906 bytes**, SHA-256 `0db65928574b3702be16b3cf9fcd6817c8457c8ef9c8766b71117e53392a8c24`.
- **Result: byte-identical, no differing lines.**

**Newline reconciliation:** The RER request digest `588f37a0adcacd1a3150846a98e067a12713c63f59c4657712ab34c3191105a3` and length **1,905 bytes** are **also correct**: both original 1,906-byte blocks end in one additional `\n`, and removing exactly that one last byte produces the RER digest on both files. The span is byte-identical in either normalization. The RER receiver may keep its original digest if it documents dropping that final separator newline; no G9/3 byte discrepancy remains.

## Adoption boundary

RRF v0.8.3 remains adopted and unchanged. The corrected §6.3 appears only in the **non-adopted** `RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_REVIEW_CANDIDATE.md`. RER r4.9 G9/1 and G9/3 remain subject to receiver per-reference audit.
