"""Gates for RER v0.2 DRAFT r4.11 (on the exact r4.10 bytes). Exit 0 iff all pass; --tamper runs negative controls.
 M1 r4.10 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.10 byte-exactly.
 L1 locality: changed r4.10 lines only at header 1/4/7; in RER-TRIAD-FORMAL-AGE the grade line (+1 note line), the claim line, Evidence and Review receipt;
    in RER-G9 the W1-W5 line, the W3 source note and the overlay; the RECOG source-table row; the §9 pins sentence; the §9 R4.10 anchor; the release boundary.
 L2 the other 22 record spans, the 24 headings and 15 r3.1 contract tables byte-identical; the RER-TRIAD-FORMAL-AGE r3.1 table differs only in its grade line;
    inside the two edited records every other line is byte-identical (G9 Reference lines included).
 L3 claim tags: raw [THM] -2, [ALG] +3, others unchanged.
 P1 unchanged Phase A parser: RER-TRIAD-FORMAL-AGE parses to grade tags ['ALG'] with FORMAL_ONLY, and task, adoption, contract, imports, OPEN items unchanged;
    its claim line differs only by [THM] -> [ALG]; every other record and every gap Reference line parse identically; the source table differs only in the RECOG description.
 A1 grade provenance: the note directly below the grade line cites the source review hash and grade, the r2 review hash and that it is the result author's review,
    the B-06 dispositions and "statement, scope and exactness are unchanged"; no theorem tag remains in the record.
 A2 Evidence and Review receipt additions: corrected bound vs the checker's "<= d-4", finite-order sampled tests, no all-orders proof by the checks,
    hash 67b2e0e7 belongs to the series script, archive identity not verified; the r2 review is the result author's own review.
 B1 RER-G9 W1 and W3 are verbatim substrings of the RECOG v0.3.21 §6.16g W1-W5 line (pinned input) and W3 equals the string quoted by the G3 notice;
    the r4.10 plain-text rendering is no longer live.
 B2 the W3 note records RRF v0.8.4 adopted (owner-reported, hash) and "not a pin"; no Reference / Import / source-table line cites v0.8.4.
 B3 lifecycle: v0.3.20 frozen with the G1 record hash in the overlay, the source table and the §9 pins sentence; "freeze candidate" survives only as a quoted
    former label; the overlay cites the G3 notice hash and the v0.3.21 / v0.3.22 editions; every RECOG Reference line and pin hash is unchanged.
 E1 inputs pinned: r2 contributor review, RECOG G3 notice, source review FORMAL, RECOG v0.3.21.
 K1 the 22 cited evidence pins (carried)."""
import sys, re, hashlib, difflib, json, importlib.util
from pathlib import Path
from urllib.parse import unquote
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_11_draft as B
PARSER = HERE / 'tools/rer_parse_phaseA_r10.py'; PARSER_SHA = '7b6b98aa1417c6bab99b6447f9f5756a04d3fc74f5b9f7d767cb75b55138a7b7'
spec = importlib.util.spec_from_file_location('rer_parse_r10', PARSER); P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
PINS_FILE = HERE / 'CITED_EVIDENCE_PINS_r4_9.json'
INPUTS = {'inputs/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md': 'd388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab',
          'inputs/RECOG_G3_NOTICE_TO_RER_20261020.md': '53341b9a85d9073d7ec22a2ef280b4fe206fbc5f7597256362fa5b880ca414b5',
          'inputs/FORMAL_AGE_FAMILY_REVIEW.md': 'b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899',
          'inputs/RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md': 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'}
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
AGE, G9 = 'RER-TRIAD-FORMAL-AGE', 'RER-G9'
PA = {'grade': '**Primary grade:** ', 'claim': '[THM] **FORMAL_ONLY.** There is a unique polynomial-in-tau', 'ev': '**Evidence:** original scientific source pins', 'rr': '**Review receipt:** r2 contributor ACCEPT SCOPED'}
PG = {'s6': '[DEF] Cross-model T_k/T_-k conjugacy', 'wn': '[DEF] **r4.10 W3 source note**', 'ov': '[DEF] **r4.6 current-use overlay'}
NOTE = '**Grade provenance** (r4.11):'
W1Q = 'a fixed directed graph, coefficient module and edge cochain $a$ with a registered realization'
W3Q = 'event-indexed cochains $a^-$, $a^+$ in the **same** cohomology space, so that $\\Delta[a]=[a^+]-[a^-]$ is defined'
G1, G3H = '5c00f66dae7d4de6ccd4a04d642a23edfc861bbd6bd55e432513747fbd679b55', '53341b9a85d9073d7ec22a2ef280b4fe206fbc5f7597256362fa5b880ca414b5'
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]; out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def parsed(t):
    return {rid: (P.parse_record(rid, ti, bo) if rid not in P.GAPS else [l for l in bo.splitlines() if l.startswith('Reference:')]) for rid, ti, bo in P.blocks(t)}
def gates(d, verbose=True, inputs=None):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.10 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.10 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    ai, aj = Sb[AGE][0], Sb[AGE][1]; gi, gj = Sb[G9][0], Sb[G9][1]
    allowed = {0, 3, 6} | {k for k in range(ai, aj) if any(Lb[k].startswith(p) for p in PA.values())} | {k for k in range(gi, gj) if any(Lb[k].startswith(p) for p in PG.values())} \
              | {k for k, l in enumerate(Lb) if l.startswith('| `RECOG` | 0.3.20;') or l.startswith('Superseded as governing pins, kept as history:') or l.startswith('[ALG] R4.10 (20 Oct 2026)') or l.startswith('**Release boundary (r4.10):**')}
    def in_scope(a1, a2): return set(range(a1, a2)) <= allowed if a2 > a1 else bool({a1 - 1, a1} & allowed)
    bad = [(t, a1, a2) for t, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes() if t != 'equal' and not in_scope(a1, a2)]
    g('L1 locality: header, four FORMAL-AGE lines (+1 note), three G9 lines, RECOG table row, §9 pins sentence, §9 anchor, release boundary', not bad, f'{len(bad)} out-of-scope hunks')
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    tab_age = [t for t in tables if t.startswith('### ' + AGE + ' — ')]; others_t = [t for t in tables if t not in tab_age]
    tl = tab_age[0].split('\n') if tab_age else []
    age_tab_ok = len(tab_age) == 1 and all(t in d for t in others_t) and len(others_t) == 15 and tl[0] in d and '\n'.join(tl[2:]) in d and tl[1] not in d
    keep = lambda L, pre: [l for l in L if not any(l.startswith(p) for p in pre)]
    ab, ad = Sb[AGE][2].split('\n'), Sd.get(AGE, (0, 0, ''))[2].split('\n'); gb, gd = Sb[G9][2].split('\n'), Sd.get(G9, (0, 0, ''))[2].split('\n')
    PAd = list(PA.values()) + ['[ALG] **FORMAL_ONLY.** There is a unique polynomial-in-tau', NOTE]
    g('L2 other spans, headings and r3.1 tables byte-identical (FORMAL-AGE table: grade line only); other lines of the two records unchanged',
      set(Sb) == set(Sd) and len(Sb) == 24 and all(Sb[k][2] == Sd[k][2] for k in Sb if k not in (AGE, G9)) and age_tab_ok
      and keep(ab, PA.values()) == keep(ad, PAd) and keep(gb, PG.values()) == keep(gd, PG.values()) and [l for l in gd if l.startswith('Reference:')] == [l for l in gb if l.startswith('Reference:')])
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    g('L3 claim tags: [THM] -2, [ALG] +3', all(d.count(t) == b.count(t) + {'[THM]': -2, '[ALG]': 3}.get(t, 0) for t in tags))
    pb, pd = parsed(b), parsed(d); x0, x1 = pb[AGE], pd.get(AGE, {})
    stb, std = P.source_table(b), P.source_table(d)
    g('P1 parser: FORMAL-AGE tags [ALG], FORMAL_ONLY, other fields unchanged; claim prefix only; other records, gap references and source table (except RECOG description) unchanged',
      hashlib.sha256(PARSER.read_bytes()).hexdigest() == PARSER_SHA and x1.get('grade_tags') == ['ALG'] and x0['grade_tags'] == ['THM'] and x1.get('exactness_codes') == ['FORMAL_ONLY']
      and all(x1.get(f) == x0[f] for f in ('exactness_text', 'task', 'registry_owner_adoption', 'contract', 'imports', 'open_items'))
      and len(x1.get('claim_lines', [])) == 1 and x1['claim_lines'][0].startswith('[ALG] **FORMAL_ONLY.**') and [l.replace('[ALG] **FORMAL_ONLY.**', '[THM] **FORMAL_ONLY.**', 1) for l in x1['claim_lines']] == x0['claim_lines']
      and all(pb[r] == pd.get(r) for r in pb if r != AGE) and set(stb) == set(std) and all(stb[k] == std[k] for k in stb if k != 'RECOG') and stb['RECOG']['sha256'] == std['RECOG']['sha256'])
    gl = next((l for l in ad if l.startswith('**Primary grade:**')), ''); i = ad.index(gl) if gl in ad else -1; note = ad[i + 1] if 0 <= i < len(ad) - 1 else ''
    needA1 = ['b170dbff5ebdc553e478d926c2ec5823c05c59ea52896dbc936fabad576d3899', '`[ALG, formal — accepted with scope corrections]`', 'd388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab',
              'written by the author of the result', 'ACCEPT SCOPED, grade/provenance CORRECTION REQUIRED', 'The mathematical statement, scope and exactness are unchanged.']
    g('A1 grade provenance note below the grade line; no theorem tag left in the record', gl.startswith('**Primary grade:** [ALG] (formal; source grade, r4.11).') and note.startswith(NOTE)
      and all(s in note for s in needA1) and '[THM]' not in Sd.get(AGE, (0, 0, ''))[2], f'missing {[s for s in needA1 if s not in note][:2]}')
    ev = next((l for l in ad if l.startswith(PA['ev'])), ''); rr = next((l for l in ad if l.startswith(PA['rr'])), '')
    needA2 = ['deg_tau C_d<=floor((d-3)/2) is the corrected bound of the source review', '"<= d-4" (not meaningful at d=3)', 'finite-order sampled tests', 'neither is an all-orders proof',
              '67b2e0e785dd30a1bd637c79db2a7210d93516b79f5a00d5fb8233da04f6799b` is the hash of the series script', 'the archive identity is not verified']
    g('A2 Evidence and Review receipt additions', all(s in ev for s in needA2) and "it is the result author's own review" in rr and 'CORRECTION REQUIRED for grade/provenance, applied here' in rr, f'missing {[s for s in needA2 if s not in ev][:2]}')
    INP = inputs if inputs is not None else {p: (HERE / p).read_bytes() for p in INPUTS}
    recog = INP['inputs/RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md'].decode('utf-8'); wline = next((l for l in recog.split('\n') if '**(W3)**' in l), '')
    s6 = next((l for l in gd if l.startswith(PG['s6'])), '')
    g('B1 G9 W1 and W3 verbatim from RECOG §6.16g (and W3 as quoted by the G3 notice); r4.10 rendering not live',
      W1Q in wline and W3Q in wline and ('"' + W1Q + '"') in s6 and ('W3 "' + W3Q + '"') in s6 and W3Q in INP['inputs/RECOG_G3_NOTICE_TO_RER_20261020.md'].decode('utf-8')
      and 'W3 event-indexed cochains a^- and a^+ in the same cohomology space' not in d and 'verbatim' in s6)
    wn = next((l for l in gd if l.startswith(PG['wn'])), '')
    bad84 = [l for l in Ld if ('v0_8_4' in l or 'v0.8.4' in l) and (l.startswith('Reference:') or l.startswith('Import/reference:') or l.startswith('| `'))]
    g('B2 W3 note: RRF v0.8.4 adopted (owner-reported, hash), not a pin; v0.8.4 cited by no Reference/Import/source-table line',
      'RRF v0.8.4 has since been adopted' in wn and '2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce' in wn and 'owner-reported' in wn and 'v0.8.4 is not a pin here.' in wn and not bad84)
    ov = next((l for l in gd if l.startswith(PG['ov'])), ''); st = next((l for l in Ld if l.startswith('| `RECOG` | 0.3.20;')), ''); ps = next((l for l in Ld if l.startswith('Superseded as governing pins, kept as history:')), '')
    live_fc = [m.start() for m in re.finditer('freeze candidate', d) if not (d[max(0, m.start() - 6):m.start()].endswith('was "') or d[max(0, m.start() - 6):m.start()].endswith('was: '))]
    recog_refs_b = [l for l in Lb if l.startswith('Reference: [RECOG:') or l.startswith('Import/reference: [RECOG')]; recog_refs_d = [l for l in Ld if l.startswith('Reference: [RECOG:') or l.startswith('Import/reference: [RECOG')]
    g('B3 lifecycle: v0.3.20 frozen (G1 hash) in overlay, table and pins sentence; "freeze candidate" only as former label; G3 notice and current editions cited; RECOG references and pins unchanged',
      ('frozen 19 Oct 2026, G1 record `RECOG_v0_3_20_FREEZE_DECISION_PROVENANCE.md`, SHA-256 `' + G1 + '`') in ov and G3H in ov and 'a3459522…0ae3' in ov and '0dcce9e4…bcd9' in ov
      and 'the v0.3.20 pins, line ranges and hashes below are kept' in ov and 'frozen 19 Oct 2026 per the G1 record' in st and 'frozen 19 Oct 2026, G1 record' in ps
      and not live_fc and recog_refs_b == recog_refs_d and len(recog_refs_d) >= 2, f'{len(live_fc)} live "freeze candidate"')
    g('E1 inputs pinned (r2 review, G3 notice, source review, RECOG v0.3.21)', all(hashlib.sha256(INP[p]).hexdigest() == h for p, h in INPUTS.items()))
    pins = json.loads(PINS_FILE.read_text(encoding='utf-8'))
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 22 cited evidence pins carried', not miss and len(pins) == 22, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    L0 = d0.split('\n'); S6 = next(l for l in L0 if l.startswith(PG['s6']))
    T = [('L1 edit outside the scope', 3, d0.replace('### RER-GEN-C01 — ', '### RER-GEN-C01 — (r4.11) ', 1)),
         ('L2 a G9 Reference line altered', 4, d0.replace('lines 1002–1042; RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS', 'lines 1006–1046; RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS', 1)),
         ('L2 a FORMAL-AGE contract cell altered', 4, d0.replace('| Closure status | FORMAL_ONLY: There is a unique polynomial-in-tau', '| Closure status | FORMAL_ONLY (ALG): There is a unique polynomial-in-tau', 1)),
         ('L3 grade line left [THM]', 5, d0.replace('**Primary grade:** [ALG] (formal; source grade, r4.11).', '**Primary grade:** [THM].', 1)),
         ('P1 claim line left [THM]', 6, d0.replace('[ALG] **FORMAL_ONLY.** There is a unique polynomial-in-tau', '[THM] **FORMAL_ONLY.** There is a unique polynomial-in-tau', 1)),
         ('A1 author status of the r2 review dropped', 7, d0.replace(', written by the author of the result;', ';', 1)),
         ('A1 grade note claims a theorem source grade', 7, d0.replace('`[ALG, formal — accepted with scope corrections]`', '`[THM]`', 1)),
         ('A2 Evidence claims an all-orders proof by the checks', 8, d0.replace('neither is an all-orders proof, which is the structural proof in the source review.', 'together they prove all orders.', 1)),
         ('A2 archive identity claimed verified', 8, d0.replace('so the archive identity is not verified.', 'so the archive identity is verified.', 1)),
         ('B1 W3 back to the r4.10 plain-text rendering', 9, d0.replace(S6, S6.replace('W3 "' + W3Q + '"', 'W3 event-indexed cochains a^- and a^+ in the same cohomology space, so that Δ[a] = [a^+] − [a^-] is defined there', 1), 1)),
         ('B1 W3 quotation altered ("same" dropped)', 9, d0.replace('$a^+$ in the **same** cohomology space, so that $\\Delta[a]', '$a^+$ in the cohomology space, so that $\\Delta[a]', 1)),
         ('B1 W1 quotation dropped', 9, d0.replace(' — "' + W1Q + '" (RECOG §6.16g, verbatim; r4.11),', ',', 1)),
         ('B2 v0.8.4 pinned as a Reference', 10, d0.replace(L0[next(i for i, l in enumerate(L0) if l.startswith('Reference: [RRF08_ADOPTED: 6.3 Token'))], L0[next(i for i, l in enumerate(L0) if l.startswith('Reference: [RRF08_ADOPTED: 6.3 Token'))] + '\nReference: [RRF084: 6.3](sources/current/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4.md); SHA-256 `2fb0a0fe9d998be91618cb731e2dee7301952ffdbe374f4889dd5e61c5cbafce`.', 1)),
         ('B3 overlay keeps "freeze candidate" live', 11, d0.replace('(frozen 19 Oct 2026, G1 record `RECOG_v0_3_20_FREEZE_DECISION_PROVENANCE.md`, SHA-256 `' + G1 + '`; r4.11, was "freeze candidate")', '(freeze candidate)', 1)),
         ('B3 RECOG pin silently moved to v0.3.21', 11, d0.replace('(sources/RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md); lines 1002–1042', '(sources/RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md); lines 1002–1042', 1)),
         ('B3 G1 record hash dropped from the source table', 11, d0.replace('frozen 19 Oct 2026 per the G1 record `5c00f66d…9b55` (r4.11)', 'frozen 19 Oct 2026 (r4.11)', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, r10 = gates(b, verbose=False); good = not r10[7] and not r10[9]; allf &= good
    print(f'  r4.10 bytes: A1, B1 = {[r10[7], r10[9]]} (expected both False)')
    inp = {p: (HERE / p).read_bytes() for p in INPUTS}
    for n, p, gi in [('E1 r2 review altered', 'inputs/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md', 12), ('B1 RECOG v0.3.21 W3 line altered', 'inputs/RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md', 9)]:
        bad = dict(inp); bad[p] = inp[p].replace(W3Q.encode('utf-8'), W3Q.replace('**same**', '**shared**').encode('utf-8'), 1) if 'RECOG' in p else inp[p] + b'x'
        assert bad[p] != inp[p]
        _, rr = gates(d0, verbose=False, inputs=bad); good = not rr[gi]; allf &= good
        print(f'  input control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    keep_p = PARSER.read_bytes(); PARSER.write_bytes(keep_p + b'\n# changed\n')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[6]; allf &= good
        print(f'  tamper P1 parser file changed: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        PARSER.write_bytes(keep_p)
    ok = ok and allf
sys.exit(0 if ok else 1)
