"""Edit list RER v0.2 DRAFT r4.9 -> r4.10 (receiving decision of 20 Oct 2026 on the RRF editor's RF-1 reply: ACCEPT SCOPED; r4.10 authorized).
Changes RER-G9 only (W3 source fidelity), plus metadata, one [ALG] §9 history entry and one release-boundary sentence.
W1 the G9 [DEF] line: the W3 clause "W3 a shared pre/post comparison space" is replaced by the owner's same-space condition (RECOG §6.16g);
   the earlier summary survives only as a quotation. W1, W2, W4, W5 clauses unchanged.
W2 one new [DEF] source note directly below: RRF v0.8.3 §6.3 W3 wording is an unmarked extension (RRF editor reply); different-space
   comparison (H^-, H^+, common H, j^-, j^+) is a separate OPEN RRF proposal, not a registered mechanism; v0.8.4 candidate is not a source or pin.
W3 the r4.6 overlay line: appended EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED byte identity of v0.8 / v0.8.3 §6.3 (1 906-byte raw block and the
   1 905-byte block without the final separator) and the note that the identical text carries the unmarked extension; G9/1 and G9/3 audits stay open.
Not changed: the four G9 Reference lines and their pins, every other record and gap entry, the source tables, all grades, pins and OPEN items."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_9.md').read_text(encoding='utf-8')
BASE_SHA = '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
REPLY = '3092fd5a808c023869319fb991d5e87f89dab95096ddfeeb3911d81f24196053'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix):
    ls = [l for l in B.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]
ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.9\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.10\n')
ed('M2', 'metadata', '**Date:** 20 October 2026 (r4.9, r4.8, r4.7);', '**Date:** 20 October 2026 (r4.10, r4.9, r4.8, r4.7);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.9 — narrow owner-synchronization revision',
   f'**Document status:** DRAFT r4.10 — narrow W3 source-fidelity revision of RER-G9 (RRF editor reply to RECOG RF-1, `{REPLY[:8]}…{REPLY[-4:]}`, receiver ACCEPT SCOPED 20 Oct 2026), built deterministically on the exact r4.9 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_10_draft.py`; the G9 Reference lines, all pins, grades, OPEN items and the other records are unchanged. r4.9 was: narrow owner-synchronization revision')
s6 = line('[DEF] Cross-model T_k/T_-k conjugacy, a within-chart involution,')
OLD = 'W3 a shared pre/post comparison space'
NEW = ('W3 event-indexed cochains a^- and a^+ in the same cohomology space, so that Δ[a] = [a^+] − [a^-] is defined there '
       '(RECOG v0.3.21 §6.16g owner condition, byte-identical to the v0.3.20 pin; r4.10, replacing the earlier summary "a shared pre/post comparison space")')
assert s6.count(OLD) == 1
note = ('[DEF] **r4.10 W3 source note** (RRF editor reply to RECOG RF-1, 20 Oct 2026, SHA-256 `' + REPLY + '`; receiver ACCEPT SCOPED). '
        'RRF v0.8.3 §6.3 states W3 as "comparison/transport between *pre- and post-birth* cohomology spaces before forming `\\Delta[a]`"; the RRF editor classifies this wording as an unmarked extension, not a faithful statement of W3 (RF-1 option (a)). '
        'RER reads W3 only as the owner\'s same-space condition above. Comparison between different spaces — cohomology groups H^-, H^+, a common H and typed maps j^-: H^- → H, j^+: H^+ → H (or one specified comparison map) — is a separate OPEN RRF proposal: no such comparison map is registered, and RER does not treat it as a registered mechanism or as part of W3. '
        'RRF v0.8.3 remains the adopted text and is not changed by this note; the non-adopted RRF v0.8.4 review candidate is neither a source nor a pin here.')
ed('W1', 'content', s6, s6.replace(OLD, NEW) + '\n' + note)
ov = line('[DEF] **r4.6 current-use overlay (RRF editor Q2: SAME-SCOPE, owner-first).**')
ed('W3', 'content', ov, ov + ' r4.10: the byte identity of RRF v0.8 §6.3 and v0.8.3 §6.3 is recorded as EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED (RRF editor reply `' + REPLY[:8] + '…' + REPLY[-4:] + '`): '
   'the block from the line beginning "### 6.3 " up to the line beginning "### 6.4 " is 1 906 bytes with SHA-256 `0db65928574b3702be16b3cf9fcd6817c8457c8ef9c8766b71117e53392a8c24` in both files, and without its final separator newline 1 905 bytes with SHA-256 `588f37a0adcacd1a3150846a98e067a12713c63f59c4657712ab34c3191105a3` in both; '
   'the RER preparer and the receiver reproduced both values on the v0.8.3 bytes (`b393657e…a187`); the v0.8 bytes are not held by RER. The identical text still carries the W3 wording that the editor classifies as an unmarked extension (W3 source note above). This does not close the per-reference audit of G9/1 or G9/3.')
h49 = line('[ALG] R4.9 (20 Oct 2026) is a narrow owner-synchronization revision')
ed('H1', 'history', h49, '[ALG] R4.10 (20 Oct 2026) is a narrow W3 source-fidelity revision on the exact r4.9 bytes, limited to RER-G9, after the receiving acceptance of the RRF editor\'s reply to RECOG RF-1. '
   'The G9 W3 clause now states the owner\'s same-space condition (RECOG §6.16g); a new source note records that RRF v0.8.3 §6.3 words W3 as an unmarked extension and that different-space comparison (H^-, H^+, common H, j^-, j^+) is a separate OPEN RRF proposal, not a registered mechanism; '
   'the overlay records the v0.8 / v0.8.3 §6.3 byte identity as EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED. No Reference line, pin, grade, OPEN item or other record changes; the RRF v0.8.4 candidate is not cited as a source; G9/1 and G9/3 stay PENDING_PER_REFERENCE_AUDIT.\n' + h49)
rb = '**Release boundary (r4.9):** r4.9 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.10):** r4.10 is a noncanonical review draft; it adopts, freezes and accepts nothing, and it records no RRF interface decision beyond the editor\'s reply. ' + rb)
t = B
for e in E: assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_9_to_r4_10_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
