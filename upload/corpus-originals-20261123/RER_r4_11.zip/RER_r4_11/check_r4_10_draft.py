"""Gates for RER v0.2 DRAFT r4.10 (on the exact r4.9 bytes). Exit 0 iff all pass; --tamper runs negative controls.
 M1 r4.9 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.9 byte-exactly.
 L1 locality: changed r4.9 lines only at header 1/4/7, the RER-G9 [DEF] W1-W5 line (one line inserted after it), the G9 r4.6 overlay line,
    the §9 R4.9 anchor (one entry inserted before it) and the release-boundary line.
 L2 the other 23 heading spans, 24 headings and 16 r3.1 contract tables byte-identical; in RER-G9 the four Reference lines and every other line
    byte-identical; the G9 [DEF] line differs only in its W3 clause.
 L3 claim tags: raw counts change by exactly [DEF] +1, [ALG] +1; G9 line-leading [DEF] +1.
 P1 with the unchanged Phase A parser all 20 records, all four gap entries' Reference lines and the source tables parse identically to r4.9.
 W1 the W3 clause states the owner condition (same cohomology space, Δ[a] = [a^+] − [a^-]); the earlier summary occurs once, only as the quoted
    replaced text.
 W2 the source note directly below: unmarked extension (RRF editor), same-space reading only, different-space comparison (H^-, H^+, common H, j^-, j^+)
    a separate OPEN RRF proposal with no registered map, v0.8.3 unchanged, the v0.8.4 candidate neither source nor pin; the reply hash cited.
 W3 the overlay keeps its r4.6 text and adds EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED with both block hashes and sizes, the unmarked-extension
    remark and "does not close the per-reference audit of G9/1 or G9/3"; no text claims either audit closed.
 E1 no Reference, Import/reference or source-table line cites v0.8.4; the RRF editor reply is pinned in inputs/ with the cited hash.
 K1 the 22 cited evidence pins (carried from r4.9)."""
import sys, re, hashlib, difflib, json, importlib.util
from pathlib import Path
from urllib.parse import unquote
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_10_draft as B
PARSER = HERE / 'tools/rer_parse_phaseA_r10.py'; PARSER_SHA = '7b6b98aa1417c6bab99b6447f9f5756a04d3fc74f5b9f7d767cb75b55138a7b7'
spec = importlib.util.spec_from_file_location('rer_parse_r10', PARSER); P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
PINS_FILE = HERE / 'CITED_EVIDENCE_PINS_r4_9.json'; REPLY_FILE = HERE / 'inputs/RRF_EDITOR_REPLY_RER_W3_RF1_G9_3_20261020.md'
REPLY = '3092fd5a808c023869319fb991d5e87f89dab95096ddfeeb3911d81f24196053'
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
KEY = 'RER-G9'; S6P = '[DEF] Cross-model T_k/T_-k conjugacy, a within-chart involution,'; OVP = '[DEF] **r4.6 current-use overlay (RRF editor Q2: SAME-SCOPE, owner-first).**'
NOTEP = '[DEF] **r4.10 W3 source note**'; OLD = 'a shared pre/post comparison space'
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]; out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def parsed(t):
    out = {}
    for rid, title, body in P.blocks(t):
        out[rid] = P.parse_record(rid, title, body) if rid not in P.GAPS else [l for l in body.splitlines() if l.startswith('Reference:')]
    return out
def gates(d, verbose=True, reply_bytes=None):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.9 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.9 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    allowed = {0, 3, 6} | {i for i, l in enumerate(Lb) if l.startswith(S6P) or l.startswith(OVP) or l.startswith('[ALG] R4.9 (20 Oct 2026)') or l.startswith('**Release boundary (r4.9):**')}
    def in_scope(a1, a2): return set(range(a1, a2)) <= allowed if a2 > a1 else bool({a1 - 1, a1} & allowed)
    bad = [(t, a1, a2) for t, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes() if t != 'equal' and not in_scope(a1, a2)]
    g('L1 locality: header 1/4/7, G9 W1-W5 line (+1 note), G9 overlay, §9 R4.9 anchor, release boundary', not bad, f'{len(bad)} out-of-scope hunks')
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    gb = Sb[KEY][2].split('\n'); gd = Sd.get(KEY, (0, 0, ''))[2].split('\n')
    keep_b = [l for l in gb if not (l.startswith(S6P) or l.startswith(OVP))]; keep_d = [l for l in gd if not (l.startswith(S6P) or l.startswith(OVP) or l.startswith(NOTEP))]
    s6b = next(l for l in gb if l.startswith(S6P)); s6d = next((l for l in gd if l.startswith(S6P)), '')
    pre, post = s6b.split('W3 ' + OLD)
    g('L2 other spans, headings, r3.1 tables, G9 Reference lines and other G9 lines byte-identical; W1-W5 line differs only in W3',
      set(Sb) == set(Sd) and len(Sb) == 24 and all(Sb[k][2] == Sd[k][2] for k in Sb if k != KEY) and len(tables) == 16 and all(t in d for t in tables)
      and keep_b == keep_d and s6d.startswith(pre) and s6d.endswith(post) and [l for l in gd if l.startswith('Reference:')] == [l for l in gb if l.startswith('Reference:')])
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    lead = lambda ls, t: sum(1 for l in ls if l.startswith(t))
    g('L3 claim tags: raw [DEF] +1, [ALG] +1; G9 line-leading [DEF] +1', all(d.count(t) == b.count(t) + {'[DEF]': 1, '[ALG]': 1}.get(t, 0) for t in tags)
      and lead(gd, '[DEF]') == lead(gb, '[DEF]') + 1 and all(lead(gd, t) == lead(gb, t) for t in ('[THM]', '[ALG]', '[OPEN]', '[NUM]')))
    pb, pd = parsed(b), parsed(d)
    g('P1 unchanged parser: all records, gap Reference lines and source tables parse identically to r4.9',
      hashlib.sha256(PARSER.read_bytes()).hexdigest() == PARSER_SHA and pb == pd and P.source_table(b) == P.source_table(d))
    w3 = s6d[len(pre):len(s6d) - len(post)] if s6d.startswith(pre) and s6d.endswith(post) else ''
    g('W1 W3 clause states the owner same-space condition; the earlier summary only as quoted replaced text',
      w3.startswith('W3 event-indexed cochains a^- and a^+ in the same cohomology space, so that Δ[a] = [a^+] − [a^-] is defined there') and 'RECOG v0.3.21 §6.16g owner condition' in w3
      and d.count(OLD) == 1 and w3.count('replacing the earlier summary "' + OLD + '"') == 1, w3[:40])
    i6 = next((k for k, l in enumerate(gd) if l.startswith(S6P)), -1); note = gd[i6 + 1] if 0 <= i6 < len(gd) - 1 else ''
    need = ['unmarked extension, not a faithful statement of W3', "RER reads W3 only as the owner's same-space condition above", 'H^-, H^+, a common H', 'j^-: H^- → H, j^+: H^+ → H',
            'is a separate OPEN RRF proposal', 'no such comparison map is registered', 'does not treat it as a registered mechanism or as part of W3',
            'RRF v0.8.3 remains the adopted text', 'v0.8.4 review candidate is neither a source nor a pin', REPLY]
    g('W2 source note directly below with the scope boundaries', note.startswith(NOTEP) and all(s in note for s in need) and d.count(NOTEP) == 1, f'missing {[s for s in need if s not in note][:2]}')
    ovb = next(l for l in gb if l.startswith(OVP)); ovd = next((l for l in gd if l.startswith(OVP)), '')
    need3 = ['EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED', '1 906 bytes', '0db65928574b3702be16b3cf9fcd6817c8457c8ef9c8766b71117e53392a8c24', '1 905 bytes',
             '588f37a0adcacd1a3150846a98e067a12713c63f59c4657712ab34c3191105a3', 'the v0.8 bytes are not held by RER', 'unmarked extension', 'This does not close the per-reference audit of G9/1 or G9/3.']
    closed = re.search(r'G9/[13][^.\n]{0,40}\b(CLOSED|closed|accepted|ACCEPTED)\b', d.replace('does not close the per-reference audit of G9/1 or G9/3', ''))
    g('W3 overlay keeps r4.6 text; adds EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED identity, extension remark, audits open; no closure claimed',
      ovd.startswith(ovb + ' r4.10: ') and all(s in ovd for s in need3) and 'RECEIVER_BYTE_VERIFIED' not in ovd and not closed, f'missing {[s for s in need3 if s not in ovd][:2]}')
    rb_ = REPLY_FILE.read_bytes() if reply_bytes is None else reply_bytes
    bad84 = [l for l in Ld if ('v0_8_4' in l or 'v0.8.4' in l) and (l.startswith('Reference:') or l.startswith('Import/reference:') or l.startswith('| `'))]
    g('E1 v0.8.4 candidate not cited as source or pin; editor reply pinned with the cited hash', not bad84 and hashlib.sha256(rb_).hexdigest() == REPLY and REPLY in d)
    pins = json.loads(PINS_FILE.read_text(encoding='utf-8'))
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 22 cited evidence pins carried', not miss and len(pins) == 22, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    L0 = d0.split('\n'); N0 = next(l for l in L0 if l.startswith(NOTEP)); S0 = next(l for l in L0 if l.startswith(S6P))
    T = [('L1 edit outside G9', 3, d0.replace('### RER-G10 — ', '### RER-G10 — (r4.10) ', 1)),
         ('L2 a G9 Reference line altered', 4, d0.replace('lines 350–365; RID unavailable', 'lines 412–427; RID unavailable', 1)),
         ('L2 W5 clause altered', 4, d0.replace('W5 conditioning/common-driver control.', 'W5 conditioning control.', 1)),
         ('L3 extra [DEF] line', 5, d0.replace(N0, N0 + '\n[DEF] extra.', 1)),
         ('W1 earlier summary left live', 7, d0.replace(S0, S0.split('W3 event-indexed')[0] + 'W3 a shared pre/post comparison space, W4' + S0.split(', W4', 1)[1], 1)),
         ('W1 extension presented as the RECOG condition', 7, d0.replace('in the same cohomology space, so that Δ[a] = [a^+] − [a^-] is defined there', 'compared by transport between pre- and post-birth cohomology spaces', 1)),
         ('W2 extension relabelled as faithful', 8, d0.replace('unmarked extension, not a faithful statement of W3', 'faithful restatement of W3', 1)),
         ('W2 comparison map presented as registered', 8, d0.replace('no such comparison map is registered, and RER does not treat it as a registered mechanism or as part of W3', 'the comparison map j is registered and RER uses it for W3', 1)),
         ('W2 v0.8.4 boundary dropped', 8, d0.replace(' the non-adopted RRF v0.8.4 review candidate is neither a source nor a pin here.', '', 1)),
         ('W3 identity relabelled RECEIVER_BYTE_VERIFIED', 9, d0.replace('EDITOR_VERIFIED — RECEIVER_NOT_REPLAYED (RRF editor reply', 'RECEIVER_BYTE_VERIFIED (RRF editor reply', 1)),
         ('W3 G9/3 audit claimed closed', 9, d0.replace('This does not close the per-reference audit of G9/1 or G9/3.', 'The per-reference audit of G9/3 is CLOSED.', 1)),
         ('W3 1 905-byte reconciliation dropped', 9, d0.replace(', and without its final separator newline 1 905 bytes with SHA-256 `588f37a0adcacd1a3150846a98e067a12713c63f59c4657712ab34c3191105a3` in both', '', 1)),
         ('E1 v0.8.4 candidate pinned as a Reference', 10, d0.replace(L0[next(i for i, l in enumerate(L0) if l.startswith('Reference: [RRF08_ADOPTED: 6.3 Token'))],
             L0[next(i for i, l in enumerate(L0) if l.startswith('Reference: [RRF08_ADOPTED: 6.3 Token'))] + '\nReference: [RRF084: 6.3](sources/current/RTG_RRF_REPRESENTATION_REGISTRY_v0_8_4_REVIEW_CANDIDATE.md); SHA-256 `' + '0' * 64 + '`.', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, r9 = gates(b, verbose=False); good = not r9[7] and not r9[8]; allf &= good
    print(f'  r4.9 bytes: W1, W2 = {[r9[7], r9[8]]} (expected both False)')
    _, rr = gates(d0, verbose=False, reply_bytes=REPLY_FILE.read_bytes() + b'x'); good = not rr[10]; allf &= good
    print(f'  input control E1 editor reply altered: {"FAILS (good)" if good else "still passes (BAD)"}')
    keep = PARSER.read_bytes(); PARSER.write_bytes(keep + b'\n# changed\n')
    try:
        _, rr = gates(d0, verbose=False); good = not rr[6]; allf &= good
        print(f'  tamper P1 parser file changed: {"FAILS (good)" if good else "still passes (BAD)"}')
    finally:
        PARSER.write_bytes(keep)
    ok = ok and allf
sys.exit(0 if ok else 1)
