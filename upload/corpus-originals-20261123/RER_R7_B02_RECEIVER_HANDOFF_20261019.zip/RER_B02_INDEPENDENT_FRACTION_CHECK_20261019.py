"""Receiver-built B02 exact ray check; no use of preparer's script/jet table."""
from fractions import Fraction as F
from math import factorial
N=7
Z=(F(0),)*(N+1)
def const(x): return (F(x),)+Z[1:]
def xpoly(x): return (F(0),F(x))+(F(0),)*(N-1)
def plus(a,b): return tuple(x+y for x,y in zip(a,b))
def neg(a): return tuple(-x for x in a)
def sub(a,b): return plus(a,neg(b))
def mul(a,b):
 v=[F(0)]*(N+1)
 for i,ai in enumerate(a):
  if not ai: continue
  for j,bj in enumerate(b[:N+1-i]):
   if bj: v[i+j]+=ai*bj
 return tuple(v)
def scale(a,c): return tuple(c*x for x in a)
def power(a,k):
 out=const(1)
 for _ in range(k): out=mul(out,a)
 return out
def sin(a):
 out=Z
 for k in range((N-1)//2+1): out=plus(out,scale(power(a,2*k+1),F((-1)**k,factorial(2*k+1))))
 return out
def expm1(a):
 out=Z
 for k in range(1,N+1): out=plus(out,scale(power(a,k),F(1,factorial(k))))
 return out
def edge(rho,eta):
 se=sin(eta)
 return (sub(rho,se),plus(plus(eta,expm1(rho)),neg(se)))
def step(X):
 sr,se,cr,ce=X
 edges=[]
 for p,q in ((F(1),F(0)),(F(-1,2),F(1)),(F(-1,2),F(-1))):
  r=plus(scale(sr,p),scale(cr,q)); e=plus(scale(se,p),scale(ce,q))
  edges.append(edge(r,e))
 out=[]
 for j in (0,1):
  w=[z[j] for z in edges]
  out.append(plus(scale(w[0],F(2,3)),scale(plus(w[1],w[2]),F(-1,3))))
  out.append(scale(sub(w[1],w[2]),F(1,2)))
 return (out[0],out[2],out[1],out[3])
def six(v):
 for _ in range(6): v=step(v)
 return v
def Qs(v):
 r,e=v[:2]
 return plus(sub(mul(r,r),mul(r,e)),mul(e,e))
def compare(v):
 a=six(tuple(xpoly(x) for x in v)); b=six(tuple(xpoly(-x) for x in v))
 return sub(Qs(a),Qs(b))
for name, ray in [('C03', (1,0,0,1)),('pure_parent',(1,0,0,0))]:
 delta=compare(ray)
 print(name, 'coefficients t^0..t^7', [str(x) for x in delta])
assert compare((1,0,0,1))[5] == F(349,288)
assert compare((1,0,0,1))[7] == F(911,576)
assert compare((1,0,0,0))[5] == F(5,32)
assert compare((1,0,0,0))[7] == F(11,60)
print('independent exact rational ray check: PASS')
