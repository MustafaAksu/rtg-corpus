import sympy as S,json
p='/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/results.json';D=json.load(open(p))
alpha,beta,gamma,delta,epsilon,zeta=S.symbols('alpha beta gamma delta epsilon zeta');a1,a2,b1,b2=S.symbols('a1 a2 b1 b2')
pars=(alpha,beta,gamma,delta,epsilon,zeta);vars=(a1,a2,b1,b2)
local={str(t):t for t in pars+vars}
omegas={key:[S.sympify(x,locals=local) for x in vals] for key,vals in D['omega'].items()}
U=S.expand(omegas['11'][0]).coeff(a2)
V=S.expand(omegas['11'][1]).coeff(a2)
W=S.expand(omegas['12'][1]).coeff(a2)
# normalized invariants: U V W are quadratic coefficient polynomials. compare Genesis values.
print('U = ',S.factor(U));print('V = ',S.factor(V));print('W = ',S.factor(W))
mbase=[U,V,W]
monoms=[alpha**2,alpha*beta,alpha*gamma,alpha*delta,alpha*epsilon,alpha*zeta,beta**2,beta*gamma,beta*delta,beta*epsilon,beta*zeta,gamma**2,gamma*delta,gamma*epsilon,gamma*zeta,delta**2,delta*epsilon,delta*zeta,epsilon**2,epsilon*zeta,zeta**2]
mat=S.Matrix([[S.Poly(q,*pars).coeff_monomial(m) for q in mbase] for m in monoms]);print('independent quad invariant rank',mat.rank())
out={}
for key,fs in omegas.items():
   for k,f in enumerate(fs):
      expr=0
      for v in vars:
        c=S.expand(f).coeff(v)
        rhs=S.Matrix([S.Poly(c,*pars).coeff_monomial(m) for m in monoms])
        cv=mat.gauss_jordan_solve(rhs)[0]
        if any(S.simplify(mat*cv-rhs)):raise Exception('not in span')
        expr+=sum(cv[j]*S.Symbol(['U','V','W'][j]) for j in range(3))*v
      out[key+('rho' if k==0 else 'eta')]=str(S.expand(expr))
      print(key,k, S.factor(expr))
print('ncoeff=',len(out)); open('/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/compact.json','w').write(json.dumps({'invariants':{'U':str(U),'V':str(V),'W':str(W)},'omega_invariants':out},indent=2))
# Explore simple explicit nonzero q in zero locus (pick some tiny integer coefficients).
import itertools
solutions=[]
for vals in itertools.product([-1,0,1],repeat=6):
 if not any(vals):continue
 sb=dict(zip(pars,vals))
 if all(expr.subs(sb)==0 for expr in mbase):solutions.append(vals)
print('nonzero 0/+-1 solutions',len(solutions),'examples',solutions[:25])
# Calculate Jacobian rank of three quadratic conditions at selected integer solution if exists
for vals in solutions[:2]:
 jac=S.Matrix(mbase).jacobian(pars).subs(dict(zip(pars,vals)))
 print('example',vals,'jacrank',jac.rank())
# Verify Genesis q
sg=dict(zip(pars,[0,0,0,S.Rational(1,2),0,0]));print('Genesis U,V,W',tuple(S.factor(x.subs(sg)) for x in mbase))
