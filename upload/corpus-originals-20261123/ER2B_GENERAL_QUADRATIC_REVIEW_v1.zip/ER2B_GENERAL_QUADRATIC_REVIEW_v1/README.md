# ER-2B: General quadratic jet classification

Start with `ER2B_GENERAL_Q_THEOREM.md`. This is a noncanonical finite-algebra review of the declared Genesis/triadic zero-sum model, not an adoption or a physical resonance theorem.

Reproduce the concise 23 exact checks:

```bash
python check_closed_form.py
```

The longer exploration `check_general_q.py` reconstructs the full polynomial tensor and writes `results.json`; `compact.py`, `two_forms.py`, and `complex_basis.py` provide separate exact simplifications. Their outputs are included. The source scientific input is the primitive matrix A and the zero-sum projection as specified in the note. Historical owner/extractor certificates were not rerun.
