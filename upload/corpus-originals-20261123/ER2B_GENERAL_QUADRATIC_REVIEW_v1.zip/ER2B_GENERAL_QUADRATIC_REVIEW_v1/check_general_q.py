#!/usr/bin/env python3
import sympy as S
import json
from pathlib import Path
W=S.symbols('a1 a2 b1 b2');a1,a2,b1,b2=W
alpha,beta,gamma,delta,epsilon,zeta=S.symbols('alpha beta gamma delta epsilon zeta'); coefs=[alpha,beta,gamma,delta,epsilon,zeta]
A=S.Matrix([[1,-1],[1,0]])

def q(x):
 u,v=x;return S.Matrix([alpha*u*u+beta*u*v+gamma*v*v,delta*u*u+epsilon*u*v+zeta*v*v])

def n2(x):
 p=S.Matrix(x[:2]);r=S.Matrix(x[2:]);mean=(q(p)+q(r)+q(p+r))/3
 return S.Matrix.vstack(q(p)-mean,q(r)-mean).applyfunc(S.expand)

def linear(x):
 p=S.Matrix(x[:2]);r=S.Matrix(x[2:]);return S.Matrix.vstack(A*p,A*r)

x0=S.Matrix(W); L=x0;B=S.zeros(4,1);C=S.zeros(4,1)
J=n2(x0).jacobian(W)
for iteration in range(6):
    # recurrence for N(X)=A_4 X+ N2(X) (zero cubic)
    Bnew=linear(B)+n2(L)
    Cnew=linear(C)+J.subs(dict(zip(W,L)), simultaneous=True)*B
    Lnew=linear(L)
    L=Lnew.applyfunc(S.expand)
    B=Bnew.applyfunc(S.expand)
    C=Cnew.applyfunc(S.expand)
    print('iter',iteration+1,'B_terms',sum(len(S.Poly(v,*W).terms()) for v in B),'C_terms',sum(len(S.Poly(v,*W).terms()) for v in C),flush=True)
assert L==x0
assert B==S.zeros(4,1)
# G3 = C. Omega mixed derivatives of edge 1 minus 2, 4 outputs (k=0,1). Determine linear form coefficients.
diff=(C[:2,0]-C[2:,0]) if False else S.Matrix([C[i]-C[i+2] for i in range(2)])
om={}
polys=[]
for i in range(2):
 for j in range(2):
  pair=[]
  for k in range(2):
   d=S.expand(S.diff(diff[k],W[i],W[j+2])); pair.append(d)
  om[f'{i+1}{j+1}']=pair
  polys+=pair
  print('Omega',i+1,j+1,': computed',flush=True)
# Collect polynomial coefficient constraints: each Omega component is a linear form in four input variables; coefficient quadratic in 6 q coefficients
relations=[]
for f in polys:
 for x in W:
  expr=S.factor(S.expand(f).coeff(x))
  if expr and expr not in relations:relations.append(expr)
print('Unique conditions',len(relations),flush=True)
for i,r in enumerate(relations):print(i,S.factor(r),flush=True)
# test Genesis q=(0,rho²/2)
original={alpha:0,beta:0,gamma:0,delta:S.Rational(1,2),epsilon:0,zeta:0}
print('original Omegas:',{key:[S.factor(v.subs(original)) for v in values] for key,values in om.items()},flush=True)
# calculate quadratic polynomial forms factoring, find ideal simple structure
print('matrix rank of q-coefficient quadratic form span:',len(relations),flush=True)
Path('/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/results.json').write_text(json.dumps({'omega':{k:[str(x) for x in v] for k,v in om.items()},'conditions':[str(r) for r in relations],'source_coefficient_names':[str(u) for u in coefs],'G3':[str(v) for v in C]},indent=2))
