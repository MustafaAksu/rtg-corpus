import sympy as S,json,itertools
D=json.load(open('/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/results.json'))
alpha,beta,gamma,delta,epsilon,zeta=S.symbols('alpha beta gamma delta epsilon zeta')
a1,a2,b1,b2=S.symbols('a1 a2 b1 b2')
pars=(alpha,beta,gamma,delta,epsilon,zeta);vars=(a1,a2,b1,b2)
local={str(t):t for t in pars+vars}
omegas={key:[S.sympify(x,locals=local) for x in vals] for key,vals in D['omega'].items()}
U=S.expand(omegas['11'][0]).coeff(a2); V=S.expand(omegas['11'][1]).coeff(a2)
basis=[U,V]
monoms=[x*y for i,x in enumerate(pars) for y in pars[i:]]
mat=S.Matrix([[S.Poly(q,*pars).coeff_monomial(m) for q in basis] for m in monoms])
print('rank',mat.rank())
out={}
for key,fs in omegas.items():
  for k,f in enumerate(fs):
    expr=0
    for v in vars:
      c=S.expand(f).coeff(v)
      rhs=S.Matrix([S.Poly(c,*pars).coeff_monomial(m) for m in monoms]);cv=mat.gauss_jordan_solve(rhs)[0]
      assert mat*cv==rhs
      expr += sum(cv[j]*S.Symbol(['U','V'][j]) for j in range(2))*v
    out[key+('rho' if k==0 else 'eta')]=str(S.expand(expr))
    print(key,'rho' if k==0 else 'eta',S.factor(expr))
# confirm compact forms match source Genesis
G={alpha:0,beta:0,gamma:0,delta:S.Rational(1,2),epsilon:0,zeta:0}
print('original U,V',S.factor(U.subs(G)),S.factor(V.subs(G)))
# quick assess joint zero locus rank structure for real q
for v in [(0,0,0,0,0,0),(0,0,1,1,0,0),(0,1,0,0,0,0),(0,0,0,1,0,0),(0,0,1,0,0,0), (1,0,0,0,0,0)]:
 sv=dict(zip(pars,v));print('values',v,'U',U.subs(sv),'V',V.subs(sv))
# choose linear change based on q holomorphic decomposition: real q coefficient space rotate isotropic terms may reveal factorization
open('/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/two_forms.json','w').write(json.dumps({'U':str(U),'V':str(V),'omega_compact':out,'rank':mat.rank()},indent=2))
