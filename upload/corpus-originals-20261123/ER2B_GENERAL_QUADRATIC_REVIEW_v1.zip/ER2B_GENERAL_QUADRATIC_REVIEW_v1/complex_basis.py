import json,sympy as s
D=json.load(open('/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/two_forms.json'))
alpha,beta,gamma,delta,epsilon,zeta=s.symbols('alpha beta gamma delta epsilon zeta',real=True)
names=(alpha,beta,gamma,delta,epsilon,zeta);local={str(c):c for c in names}
U=s.sympify(D['U'],locals=local);V=s.sympify(D['V'],locals=local)
Z,Zb=s.symbols('Z Zb');rt=s.sqrt(3);I=s.I
eta=(Z-Zb)/(I*rt);rho=(Z+Zb)/2+eta/2
Qr=alpha*rho**2+beta*rho*eta+gamma*eta**2
Qe=delta*rho**2+epsilon*rho*eta+zeta*eta**2
Qw=s.expand(Qr+(-s.Rational(1,2)+I*rt/2)*Qe)
cz=[s.simplify(Qw.coeff(Z,2)),s.simplify(Qw.coeff(Z,1).coeff(Zb,1)),s.simplify(Qw.coeff(Zb,2))]
print('complex coefficients:');print(*cz,sep='\n')
# express 6 real q coefs in 6 coords (A_real,A_imag, ...)
ar,ai,br,bi,cr,ci=s.symbols('ar ai br bi cr ci',real=True)
Y=[ar,ai,br,bi,cr,ci]
coords=sum(([s.re(s.expand_complex(c)),s.im(s.expand_complex(c))] for c in cz),[])
M=s.Matrix(coords).jacobian(names)
print('rank M',M.rank(),'det=',s.simplify(M.det()))
vec=s.simplify(M.inv()*s.Matrix(Y));subs=dict(zip(names,vec))
print('q(coeff) in complex coefficients:')
for q,v in zip(names,vec):print(q,s.factor(v))
UU=s.factor(U.subs(subs, simultaneous=True)); VV=s.factor(V.subs(subs, simultaneous=True))
print('U in complex coeff: ', UU);print('V in complex coeff: ', VV)
print('rank U, rank V',s.hessian(UU,Y).rank(),s.hessian(VV,Y).rank())
for name,expr in [('U',UU),('V',VV)]:
  P=s.Poly(expr,*Y)
  print(name,'terms',len(P.terms()))
print('complex U+iV factor (complex domain): ',s.factor(UU+I*VV,extension=[I,rt]))
print('complex U-iV factor (complex domain): ',s.factor(UU-I*VV,extension=[I,rt]))
open('/mnt/data/ER2B_GENERAL_QUADRATIC_REVIEW_v1/complex_basis.json','w').write(json.dumps({'Qw_coefficients':[str(c) for c in cz], 'U':str(UU),'V':str(VV)},indent=2))
