#!/usr/bin/env python3
"""Exact rational/surd audit of six-step separation obstruction.

Q is an arbitrary homogeneous real quadratic R^2->R^2 (six real parameters).
No primitive RTG owner theorem or analytic enclosure is installed or altered.
Requires SymPy; no network or hidden source files.
"""
from pathlib import Path
import json
import sympy as s

root=Path(__file__).parent
a1,a2,b1,b2=s.symbols('a1 a2 b1 b2')
alpha,beta,gamma,delta,epsilon,zeta=s.symbols('alpha beta gamma delta epsilon zeta',real=True)
qq=(alpha,beta,gamma,delta,epsilon,zeta)
x=s.Matrix([a1,a2,b1,b2]);rr=[s.Matrix([a1,a2]),s.Matrix([b1,b2]),s.Matrix([-a1-b1,-a2-b2])]
A=s.Matrix([[1,-1],[1,0]])
checks=[]
def check(label,diff):
    if isinstance(diff,s.MatrixBase):
        fail=[s.expand(y) for y in diff]
        ok=all(y==0 for y in fail)
    else:
        fail=s.expand(diff);ok=fail==0
    checks.append({'name':label,'pass':bool(ok)})
    if not ok:raise AssertionError((label,fail))

def q(r):
    u,v=r
    return s.Matrix([alpha*u*u+beta*u*v+gamma*v*v,
                     delta*u*u+epsilon*u*v+zeta*v*v])

def p3(r):
    u,v=r
    return s.Matrix([u**3+u*v*v,2*u*u*v-v**3])

def proj_first_two(vals):
    mean=(vals[0]+vals[1]+vals[2])/3
    return s.Matrix.vstack(vals[0]-mean,vals[1]-mean)

def N2(v):
    a=s.Matrix(v[:2]);b=s.Matrix(v[2:]);return proj_first_two([q(a),q(b),q(-a-b)])

def L4(v):
    return s.Matrix.vstack(A*s.Matrix(v[:2]),A*s.Matrix(v[2:]))

L=x;B=s.zeros(4,1);C=s.zeros(4,1)
J=N2(x).jacobian(x)
for step in range(6):
    C=(L4(C)+J.subs(dict(zip(x,L)),simultaneous=True)*B).applyfunc(s.expand)
    B=(L4(B)+N2(L)).applyfunc(s.expand)
    L=L4(L)
check('A4 sixth power is identity',L-x)
check('No quadratic term in six-step return',B)
G=C
edge_diff=s.Matrix([G[0]-G[2],G[1]-G[3]])
omegas={(i+1,j+1):s.Matrix([s.expand(s.diff(edge_diff[k],x[i],x[j+2])) for k in range(2)]) for i in range(2) for j in range(2)}
U=s.expand(omegas[(1,1)][0]).coeff(a2)
V=s.expand(omegas[(1,1)][1]).coeff(a2)
check('Omega 11 rho compact',omegas[(1,1)][0]-U*(a2-b2))
check('Omega 11 eta compact',omegas[(1,1)][1]-V*(a2-b2))
expected={
(1,2):s.Matrix([
-U*(2*a1+b1)+V*(a2+2*b2),
-U*(a2+2*b2)+V*(-2*a1+a2-b1+2*b2)]),
(2,1):s.Matrix([
U*(a1+2*b1)-V*(2*a2+b2),
U*(2*a2+b2)+V*(a1-2*a2+2*b1-b2)]),
(2,2):s.Matrix([
V*(a1-b1),(V-U)*(a1-b1)])}
for k,m in expected.items():check(f'Omega {k} two-invariant formula',omegas[k]-m)

# Direct source cubic jets give an edge-local separable contribution to G3,
# so every mixed derivative of edge1-edge2 must be zero.
G3pure=s.zeros(4,1)
for j in range(6):
    Lj=L4(x) if False else x
    for _ in range(j):Lj=L4(Lj)
    rsj=[s.Matrix(Lj[:2]),s.Matrix(Lj[2:]),-s.Matrix(Lj[:2])-s.Matrix(Lj[2:])]
    nj=proj_first_two([p3(w) for w in rsj])
    for _ in range(5-j):nj=L4(nj)
    G3pure+=nj
pure_diff=s.Matrix([G3pure[0]-G3pure[2],G3pure[1]-G3pure[3]])
for i in range(2):
    for j in range(2):
        check(f'Arbitrary cubic source example has no Omega_{i+1}{j+1}',pure_diff.diff(x[i]).diff(x[j+2]))

# User's double-sum nonseparable representative, modulo separable and common means.
ms=[]
for i in range(6):
    Ai=A**i
    ms.append((q(Ai*rr[0])+q(Ai*rr[1])+q(Ai*rr[2]))/3)
qjac=q(s.Matrix(s.symbols('u v'))).jacobian(s.Matrix(s.symbols('u v')))
Non=[]
for e in [0,1]:
    tot=s.zeros(2,1)
    for j in range(6):
        dj=qjac.subs({s.Symbol('u'):(A**j*rr[e])[0],s.Symbol('v'):(A**j*rr[e])[1]},simultaneous=True)
        for i in range(j):
            tot-=(A**(5-j))*dj*(A**(j-1-i))*ms[i]
    Non.append(tot.applyfunc(s.expand))
obs=s.Matrix([Non[0][i]-Non[1][i] for i in range(2)])
for i in range(2):
    for j in range(2):
        check(f'Double-sum equals Omega_{i+1}{j+1}',obs.diff(x[i]).diff(x[j+2])-omegas[(i+1,j+1)])

# Determine quadratic coefficient forms in the complex lambda-eigenframe.
Z,Zb=s.symbols('Z Zb')
rt=s.sqrt(3);ii=s.I
eta=(Z-Zb)/(ii*rt)
rho=(Z+Zb+eta)/2
qcomplex=s.expand((q(s.Matrix([rho,eta]))[0]+(-s.Rational(1,2)+ii*rt/2)*q(s.Matrix([rho,eta]))[1]))
coeffs=[s.simplify(qcomplex.coeff(Z,2)),s.simplify(qcomplex.coeff(Z,1).coeff(Zb,1)),s.simplify(qcomplex.coeff(Zb,2))]
realcoords=[]
for z in coeffs:
    realcoords += [s.re(s.expand_complex(z)),s.im(s.expand_complex(z))]
M=s.Matrix(realcoords).jacobian(qq)
ar,ai,br,bi,cr,ci=s.symbols('ar ai br bi cr ci',real=True)
new=s.Matrix([ar,ai,br,bi,cr,ci]);inv=s.simplify(M.inv()*new)
sub=dict(zip(qq,inv))
Unew=s.factor(U.subs(sub,simultaneous=True));Vnew=s.factor(V.subs(sub,simultaneous=True))
zA=ar+ii*ai;zB=br+ii*bi;zC=cr+ii*ci
check('U in complex eigenframe',Unew-(-12*s.re(zA*zB)+4*rt*s.im(zA*zB)-2*s.Abs(zB)**2-4*s.Abs(zC)**2))
check('V in complex eigenframe',Vnew-(-12*s.re(zA*zB)-4*rt*s.im(zA*zB)+2*s.Abs(zB)**2-8*s.Abs(zC)**2))
check('U+V zero iff first quad condition',Unew+Vnew+12*(2*s.re(zA*zB)+s.Abs(zC)**2))
check('U-V zero iff second quad condition',Unew-Vnew-4*(2*rt*s.im(zA*zB)-s.Abs(zB)**2+s.Abs(zC)**2))

original={alpha:0,beta:0,gamma:0,delta:s.Rational(1,2),epsilon:0,zeta:0}
check('Genesis U=1/3',U.subs(original)-s.Rational(1,3))
check('Genesis V=2/3',V.subs(original)-s.Rational(2,3))
check('Nonzero zero-obstruction quadratic example U',U.subs({alpha:0,beta:0,gamma:1,delta:1,epsilon:0,zeta:0}))
check('Nonzero zero-obstruction quadratic example V',V.subs({alpha:0,beta:0,gamma:1,delta:1,epsilon:0,zeta:0}))

payload={'status':'PASS','checked_count':len(checks),'checks':checks,
  'source':'generic quadratic q on V=R2; A=[[1,-1],[1,0]]; P zero-sum; six iterations',
  'q_real':{'rho':'alpha*rho**2+beta*rho*eta+gamma*eta**2','eta':'delta*rho**2+epsilon*rho*eta+zeta*eta**2'},
  'U_real_coefficients':str(s.factor(U)), 'V_real_coefficients':str(s.factor(V)),
  'U_eigenframe':str(Unew),'V_eigenframe':str(Vnew),
  'omega_compact':{'11':["U*(a2-b2)","V*(a2-b2)"],
                  '12':[str(v) for v in expected[(1,2)]],
                  '21':[str(v) for v in expected[(2,1)]],
                  '22':[str(v) for v in expected[(2,2)]]},
  'Genesis_UV':['1/3','2/3'],
  'scope':'finite exact polynomial calculation; no original owner theorem rewritten; original certificate not rerun'}
(root/'closed_form_checks.json').write_text(json.dumps(payload,indent=2)+'\n')
print(len(checks),'exact symbolic checks PASS')
print('Genesis U,V=',U.subs(original),V.subs(original))
print('Zero example q=(eta^2,rho^2): U,V=',U.subs({alpha:0,beta:0,gamma:1,delta:1,epsilon:0,zeta:0}),V.subs({alpha:0,beta:0,gamma:1,delta:1,epsilon:0,zeta:0}))
