#!/usr/bin/env python3
"""
F3-FINITE-JET-CONTROL stage 2 — resumable box-sweep driver (v3) on engine v3.2 and the shared contract module.
Usage:  python triad_stage2_driver.py --config CONFIG.json [--results OUT.jsonl] [--pilot] [--max-boxes M] [--only inner|outer]
  --results   operational output path (default: config 'results'); does NOT change the config identity hash.
Resume: a (box, N) job is skipped only if triad_stage2_contract.collect() accepts it from the output file; quarantined
keys (conflicting valid payloads) are reported and NOT rerun until resolved explicitly.
"""
import sys, json, time, importlib.util, traceback, math
from pathlib import Path
from decimal import Decimal, ROUND_CEILING
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); import triad_stage2_contract as C
args = sys.argv[1:]
def opt(name, default, cast=str):
    return cast(args[args.index(name)+1]) if name in args else default
CFG_PATH = Path(opt('--config', str(HERE / 'stage2_config.json')))
PILOT = '--pilot' in args; MAXB = opt('--max-boxes', 0, int); ONLY = opt('--only', '', str)
CFG, IDENT, CDIR = C.load_config(CFG_PATH)
RES = Path(opt('--results', str(CDIR / CFG.get('results', 'stage2_results.jsonl'))))
spec = importlib.util.spec_from_file_location('engine', CDIR / CFG['engine']); eng = importlib.util.module_from_spec(spec); spec.loader.exec_module(eng)
eng.configure(int(CFG['K']), CDIR / CFG['poly'], CFG['KT'])
assert eng.LOADED_POLY_SHA256 == IDENT['poly_sha256'] == C.PINNED_POLY_SHA256
eng.mp.mp.dps = int(CFG['DPS']); eng.iv.dps = int(CFG['DPS'])
P = C.plan(CFG)
def dec(x):   return eng.dec_up(x.b if isinstance(x, eng.iv.mpf) else x)
def decdn(x): return eng.dec_down(x.a if isinstance(x, eng.iv.mpf) else x)
def upq(x, places=4):
    d = Decimal(dec(x))
    if d == 0: return '0'
    q = d.quantize(Decimal(f'1E{d.adjusted() - places + 1}'), rounding=ROUND_CEILING)   # exponent set explicitly
    return str(q)   # e.g. '3.246', '522.7', '1.235E+4' — significant digits explicit
def run_box(b, N):
    sq = b['sq']; ta, tb = b['tau']; t0 = time.time(); t_c = (ta + tb) / 2; ht = (tb - ta) / 2
    res = eng.certify_box(N, str(sq['cx']), str(sq['cy']), str(t_c), str(sq['h']), str(ht), R_floor=str(b['R_floor']))
    return dict(box_id=b['id'], ring=b['ring'], N=N, status='PASS', K_deg=int(CFG['K']), dps=int(CFG['DPS']), kt=C.SUPPORTED_KT,
                engine_sha256=IDENT['engine_sha256'], poly_sha256=IDENT['poly_sha256'], config_sha256=IDENT['config_semantic_sha256'],
                endpoints=dict(r=[str(sq['x0']), str(sq['x1'])], e=[str(sq['y0']), str(sq['y1'])], tau=[str(ta), str(tb)]),
                R_floor=str(b['R_floor']), Rmin=decdn(res['Rmin']), Rmax=dec(res['Rmax']), R_eff=decdn(res['R_eff']),
                bound_B_up=upq(res['bound_B'].b), centre_abs_up=upq(res['centre_abs'].b), K_up=upq(res['K'].b), K_raw=dec(res['K'].b),
                trans_B_up=upq(res['trans_B'].b), K_perp_up=upq(res['K_perp'].b),
                rho_s=dec(res['rem'][0]), rho_c=dec(res['rem'][1]), lam_last=dec(res['lam']), L_C=dec(res['L_C']),
                Rm_postmap=dec(res['Rm_postmap']), tau_plus=res['tau_plus'], steps=res['steps'], seconds=round(time.time()-t0, 1))
accepted, quarantined, rejected, fails = C.collect([RES], P, CFG, IDENT)
boxes = [b for b in P.values() if not ONLY or b['ring'] == ONLY]
if PILOT:
    lay = C.tau_layers(CFG)
    def pick(ring, ang, rr, ti):
        tx, ty = rr*math.cos(ang), rr*math.sin(ang)
        cands = [b for b in boxes if b['ring'] == ring and b['tau'] == lay[ti]]
        return min(cands, key=lambda b: (float(b['sq']['cx'])-tx)**2 + (float(b['sq']['cy'])-ty)**2)
    boxes = [pick('inner', 0, 0.03, 0), pick('inner', 3*math.pi/4, 0.03, 0), pick('outer', 3*math.pi/4, 0.08, 0), pick('inner', 3*math.pi/4, 0.03, len(lay)-1)]
print(f"config {CFG_PATH.name}: semantic sha {IDENT['config_semantic_sha256'][:12]}; engine {CFG['engine']} {IDENT['engine_sha256'][:12]}; poly {IDENT['poly_sha256'][:12]}; K={CFG['K']} dps={CFG['DPS']}; output {RES.name}")
print(f"jobs in plan: {len(boxes)*len(CFG['N_LIST'])}; accepted already: {len(accepted)}; quarantined: {len(quarantined)}; invalid rows: {len(rejected)}; FAIL rows: {len(fails)}")
for k in quarantined: print('QUARANTINED (not rerun until resolved):', k)
count = 0
with open(RES, 'a') as f:
    for b in boxes:
        for N in CFG['N_LIST']:
            key = (b['id'], N)
            if key in accepted or key in quarantined: continue
            if MAXB and count >= MAXB: break
            try:
                rec = run_box(b, N)
                why = C.validate(rec, P, CFG, IDENT)          # self-check before writing
                if why: raise RuntimeError(f'self-validation failed: {why}')
                print(f"PASS {b['id']} N={N} K_up={rec['K_up']} K_perp_up={rec['K_perp_up']} rho_c={float(rec['rho_c']):.1e} [{rec['seconds']}s]")
            except Exception as ex:
                rec = dict(box_id=b['id'], N=N, status='FAIL', error=repr(ex), trace=traceback.format_exc()[-800:], **{k: IDENT[k] for k in ('engine_sha256', 'poly_sha256')}, config_sha256=IDENT['config_semantic_sha256'])
                print(f"FAIL {b['id']} N={N}: {ex!r}")
            f.write(json.dumps(rec) + '\n'); f.flush(); count += 1
print('done', count, 'runs this session')
