"""Gates for RER v0.2 DRAFT r4.1 (on r4 bytes). Exit 0 iff all pass; --tamper runs negative controls.
M1 r4 base SHA; M2 rebuild; M3 reverse recovers r4 byte-exactly; M4 all 20 r4 record headings and the 16 r3.1 contract tables
byte-identical; M5 no tag-count decrease, no [RETRACTED]/[FAIL] added; M6 the four r4 records still 'Registry/owner adoption:** pending'.
S1 no live v6.4.12.1 pin except explicit r4-pin/supersession records; S2 OPEN 20 split (no OPEN B-inf flat-uniqueness line; B-inf existence,
B-an, B-6 OPEN; flat uniqueness imported at C^inf scope with existence disclaimer); S3 no Lemma-F/flat-centralizer RID inside any RER-TRIAD record;
S4 G5 closure lines carry C^3 (r4 S4); S5 mean-feedback theorem always with H_spec (r4 S3); S6 cited Triadic r2 file exists at the cited path with
the cited hash; S7 receiving kernel evidence labelled as an alternative certificate, not an identical replay; TM review labelled RECEIVER-REPORTED with
the open per-stage guard."""
import sys, re, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_1_draft as B
r4, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
TR2 = 'dd67907fc21e457e413c3d6ee924617bc7818c1c200a9bde04fb67649d79b3e7'
def gates(d, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4 base SHA', hashlib.sha256(r4.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(r4, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4 byte-exactly', ok and rev == r4)
    heads = re.findall(r'^### RER-[A-Z0-9-]+ — .*$', r4, re.M)
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    g('M4 r4 headings and r3.1 contract tables byte-identical', len(heads) == 24 and all(h in d for h in heads) and len(tables) == 16 and all(t in d for t in tables), f'{len(heads)} headings, {len(tables)} tables')
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    c0 = {t: r4.count(t) for t in tags}; c1 = {t: d.count(t) for t in tags}
    g('M5 no tag decrease; no RETRACTED/FAIL added', all(c1[t] >= c0[t] for t in tags) and c1['[RETRACTED]'] == c0['[RETRACTED]'] and c1['[FAIL]'] == c0['[FAIL]'], ' '.join(f'{t}{c1[t]-c0[t]:+d}' for t in tags if c1[t] != c0[t]))
    new = ['RER-GEN-K3-MODAL', 'RER-DYAD-FORMAL-INVOLUTION', 'RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION']
    g('M6 four r4 records still owner-adoption pending', all(re.search(re.escape(k) + r' — [^\n]*\n\*\*Primary grade:\*\*[^\n]*Registry/owner adoption:\*\* pending', d) for k in new))
    bad = [l for l in d.splitlines() if 'v6.4.12.1' in l and not re.search(r'r4 pin|r4 pinned|superseded|current pin v6\.4\.13|R4\.1 \(19 Oct 2026\)|released as v6\.4\.12\.1|R4 \(18 Oct 2026\)|Dyadic v6\.4\.12\.1 cites', l)]
    g('S1 no live Dyadic v6.4.12.1 pin', not bad, f'{len(bad)} stale')
    rec = d.split('### RER-DYAD-FORMAL-INVOLUTION')[1].split('\n### ')[0]
    g('S2 OPEN 20 split recorded', '[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness.' not in rec and all(k in rec for k in ['[OPEN] OPEN 20 B-an', '[OPEN] OPEN 20 B-6', '[OPEN] OPEN 20 B-∞ existence', 'DYAD-CAND-FLAT-CENTRALIZER', 'No existence is asserted']))
    triad = ''.join(d.split('### ' + k)[1].split('\n### ')[0] for k in ['RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION'])
    g('S3 no Lemma-F / flat-centralizer RID inside RER-TRIAD records', not re.search(r'DYAD-CAND-FLAT-CENTRALIZER|DYAD-CAND-SMOOTH|DYAD-THM-FORMAL-Z6', triad))
    g5 = [l for l in d.splitlines() if 'CLOSED_AT_OWNER_GRADE' in l and 'C^3' not in l]
    g('S4 G5 closure always with C^3', 'CLOSED_AT_OWNER_GRADE' in d and not g5, f'{len(g5)} unguarded')
    mf = [l for l in d.splitlines() if 'GEN-THM-MEANFEEDBACK-SIXSTEP-NOGO' in l and 'H_spec' not in l]
    g('S5 mean-feedback theorem always with (H_spec)', not mf)
    p = HERE / 'sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r2.md'
    g('S6 cited Triadic r2 present at cited path with cited hash', TR2 in d and 'sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r2.md' in d and p.exists() and hashlib.sha256(p.read_bytes()).hexdigest() == TR2)
    g('S7 receiving evidence labelled (alternative exact certificate; TM review RECEIVER-REPORTED with open guard)',
      'no identical-script replay exists' in d and 'independent alternative exact certificate' in d and 'RECEIVER-REPORTED, not in this package' in d and 'must be enforced or verified per stage' in d)
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    T = [('S1', 6, d0.replace('`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.16', '`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.12.1 §6.16', 1)),
         ('S2', 7, d0.replace('[OPEN] OPEN 20 B-6 (v6.4.13)', '[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness.\n[OPEN] OPEN 20 B-6 (v6.4.13)', 1)),
         ('S3', 8, d0.replace('[OPEN] G6: six-step-only uniqueness', '[THM] DYAD-CAND-FLAT-CENTRALIZER gives triad uniqueness. [OPEN] G6: six-step-only uniqueness', 1)),
         ('S7', 12, d0.replace('no identical-script replay exists', 'the replay passed', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); print(f'  tamper {n}: gate {"FAILS (good)" if not rr[i] else "still passes (BAD)"}'); allf &= not rr[i]
    ok = ok and allf
sys.exit(0 if ok else 1)
