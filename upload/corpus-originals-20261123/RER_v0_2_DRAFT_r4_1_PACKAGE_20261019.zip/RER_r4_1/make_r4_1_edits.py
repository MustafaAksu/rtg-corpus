"""Edit list RER v0.2 DRAFT r4 -> r4.1 (E1 Dyadic v6.4.13, Triadic v1.6.1 DRAFT r2 pointer, receiving-side evidence receipts,
r4 source-path erratum). Every old string is copied from the exact r4 bytes and must occur exactly once."""
import json, hashlib
from pathlib import Path
R4P = Path('../RER_r4/RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4.md')
R4 = R4P.read_text(encoding='utf-8')
assert hashlib.sha256(R4.encode()).hexdigest() == '93a63c49131d665f258dccf16ffcc6ccfb6af9a60035073ebd710dd4d80c8eff'
TR2 = 'dd67907fc21e457e413c3d6ee924617bc7818c1c200a9bde04fb67649d79b3e7'
E = []
def ed(eid, kind, old, new):
    assert R4.count(old) == 1, (eid, R4.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.1\n')
ed('M2', 'metadata', '**Date:** 18 October 2026 (r4); r3.1 dated 14 October 2026', '**Date:** 19 October 2026 (r4.1); r4 18 October 2026; r3.1 dated 14 October 2026')
ed('M3', 'metadata', '**Document status:** DRAFT r4 — source synchronization and record integration on the exact r3.1 bytes',
   '**Document status:** DRAFT r4.1 — source erratum E1 (Dyadic v6.4.13), Triadic v1.6.1 DRAFT r2 pointer and receiving-review evidence receipts, built deterministically on the exact r4 bytes (SHA-256 `93a63c49131d665f258dccf16ffcc6ccfb6af9a60035073ebd710dd4d80c8eff`) by `build_r4_1_draft.py`; no new record, no grade change. r4 was: source synchronization and record integration on the exact r3.1 bytes')
ed('M4', 'pointer (E1/T)', 'Dyadic v6.4.12.1 (released 17 Oct 2026); Triadic v1.6 (adopted) and Triadic v1.6.1 DRAFT r1 (separate draft source object, not adopted)',
   'Dyadic v6.4.13 (adopted 18 Oct 2026; the v6.4.12.1 pin of r4 is superseded); Triadic v1.6 (adopted) and Triadic v1.6.1 DRAFT r2 (separate draft source object, not adopted; DRAFT r1 superseded as a draft)')

# ---- E1 inside RER-DYAD-FORMAL-INVOLUTION
ed('E1a', 'pointer (E1)', 'pending / owner theorems adopted in Dyadic v6.4.12 (released as v6.4.12.1).',
   'pending / owner theorems adopted in Dyadic v6.4.12 (released as v6.4.12.1; retained unchanged in adopted v6.4.13).')
ed('E1b', 'pointer (E1)', '`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.12.1 §6.16 | RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE',
   '`[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.16 | RID: DYAD-THM-FORMAL-INVOLUTION-UNIQUE')
ed('E1c', 'pointer (E1)',
   'Import/reference: [DYAD6412_1: §6.15, §6.16, §2 OPEN 19/20] (sources/current/RTG_DYADIC_OSCILLATOR_DSN_v6_4_12_1.md); SHA-256 `36e7ef58c952f19cd48683c601957f6a01d90c2e2c6f548b28c1707764c5f107` (owner-reported; v6.4.12 `c2f00eb0…38e8`).',
   'Import/reference: [DYAD6413: §6.15, §6.16, §6.17, §2 OPEN 19/20] (project copy `RTG_DYADIC_OSCILLATOR_DSN_v6_4_13.md`; not in this package); SHA-256 `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` (owner-verified, as recorded in the Genesis v2.8.8 owner-pass manifest). r4 pinned [DYAD6412_1] v6.4.12.1 `36e7ef58c952f19cd48683c601957f6a01d90c2e2c6f548b28c1707764c5f107`; the four imported RIDs are unchanged in v6.4.13.')
ed('E1d', 'scope (E1)', '[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness.\n',
   '[OPEN] OPEN 20 B-6 (v6.4.13): convergence of F^{1/6}, equivalently of the formal Z_6 generator J = T∘F^{-1/6} or of an exactly λ-equivariant analytic chart; B-6 ⇒ B-an.\n'
   '[OPEN] OPEN 20 B-∞ existence: a C^∞ local involution with DR(0) = −I commuting with T (equivalently a C^∞ tangent-to-identity square root of F).\n'
   '[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 | RID: DYAD-CAND-FLAT-CENTRALIZER, DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES]` (r4.1, erratum E1) OPEN 20 B-∞ flat uniqueness is CLOSED at the C^∞ scope for existing objects: Lemma F [THM]; F1–F3 [THM — conditional] on Lemma F and on existence. An existing C^∞ involution with DR(0) = −I commuting with F commutes with T and is unique. No existence is asserted; the RID word CAND is an identifier, not a status. r4\'s line "[OPEN] OPEN 20 B-∞: C^∞ flat uniqueness" is superseded. Not transferred to the triad: Lemma F uses the isolated-dyad contraction DYAD-THM-PRIM-CTR; G6 is OPEN and no triad contraction theorem exists.\n')


ed('E1g', 'pointer (E1)', 'the Dyadic formal-involution import (owner theorems, v6.4.12.1);', 'the Dyadic formal-involution import (owner theorems, v6.4.12.1; current pin v6.4.13 with the same RIDs);')
ed('E1h', 'pointer (E1)', 'The Dyadic unique formal involution R_0 (v6.4.12.1) is imported at owner grade.', 'The Dyadic unique formal involution R_0 (v6.4.12.1; current pin v6.4.13, RIDs unchanged) is imported at owner grade.')
# ---- Triadic draft object r1 -> r2 (and r4 path erratum)
ed('T1', 'pointer (Triadic r2)',
   'Import/reference: [TRIAD161_DRAFT: Triadic v1.6.1 DRAFT r1, §6.1/§6.17.2/§7.2 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r1.md); DRAFT, not adopted; SHA-256 `31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea`.',
   f'Import/reference: [TRIAD161_DRAFT_R2: Triadic v1.6.1 DRAFT r2, §6.1/§6.15/§6.17.2/§7.2/§7.4 CN-02 D3 entries] (sources/current/TRIAD_R4/RTG_TRIADIC_BIRTH_LIFT_DSN_v1_6_1_DRAFT_r2.md); DRAFT, not adopted; SHA-256 `{TR2}`. r4 cited DRAFT r1 (`31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea`) at sources/current/TRIAD_R4/, while the r4 package held that file at sources/current/ (path erratum); r4.1 places both drafts under sources/current/TRIAD_R4/. Record (d) is independent of the Triadic D3 decision (receiving review, 19 Oct).')
ed('T2', 'pointer (Triadic r2)',
   '| `TRIAD161_DRAFT` | Triadic v1.6.1 DRAFT r1 (18 Oct; D3 scope correction + D1–D10 hygiene; NOT ADOPTED; separate source object) | `31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea` | BYTE-VERIFIED by its preparer; receiving review pending |',
   '| `TRIAD161_DRAFT` | Triadic v1.6.1 DRAFT r1 (18 Oct; D3 scope correction + D1–D10 hygiene; NOT ADOPTED; separate source object) | `31b87c3edc90a2ec54f97d5b63ac043ab0d2b3bcd495ddb35b05f3a9cb4630ea` | BYTE-VERIFIED by its preparer; receiving review 19 Oct: D3 core ACCEPT SCOPED, draft REQUEST CHANGES (D3-R1, H-R1); superseded as a draft by r2 |\n'
   f'| `TRIAD161_DRAFT_R2` | Triadic v1.6.1 DRAFT r2 (19 Oct; D3-R1 point-of-use remainder conditions at §6.15 and CN-02, H-R1 scoped receipts, H-R2 point-of-use Genesis repins, E1 Dyadic v6.4.13; NOT ADOPTED) | `{TR2}` | BYTE-VERIFIED by its preparer (12/12 gates; exact reversal to r1); receiving review pending |')

# ---- Dyadic source table / supersession list
ed('E1e', 'pointer (E1)',
   '| `DYAD6412_1` | Dyadic v6.4.12.1 released 17 Oct (metadata-only over adopted v6.4.12 `c2f00eb0…38e8`) | `36e7ef58c952f19cd48683c601957f6a01d90c2e2c6f548b28c1707764c5f107` | OWNER-REPORTED; §§1, 2, 6.15, 6.16, 7 SOURCE-READ |',
   '| `DYAD6412_1` | Dyadic v6.4.12.1 released 17 Oct (metadata-only over adopted v6.4.12 `c2f00eb0…38e8`) | `36e7ef58c952f19cd48683c601957f6a01d90c2e2c6f548b28c1707764c5f107` | OWNER-REPORTED; §§1, 2, 6.15, 6.16, 7 SOURCE-READ; r4 pin, superseded by `DYAD6413` in r4.1 |\n'
   '| `DYAD6413` | Dyadic v6.4.13 adopted 18 Oct (canonical Z_6 generator, Lemma F and F1–F3, OPEN 20 restructured, M2c) | `5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542` | OWNER-VERIFIED (Genesis v2.8.8 owner-pass manifest); §§1, 2, 6.15–6.17, 7 SOURCE-READ from the project copy; not byte-verified here |')
ed('E1f', 'pointer (E1)', '`DYAD` (v6.4.10 archived pin) by `DYAD6412_1`;',
   '`DYAD` (v6.4.10 archived pin) by `DYAD6412_1` (r4), itself superseded by `DYAD6413` (r4.1);')

# ---- kernel evidence (receiving side)
ed('K1', 'evidence receipt', 'Kernel: exact-rational `TRIAD_CK_PY` source-executed (≈90 s), receiving exact replay pending;',
   'Kernel: exact-rational `TRIAD_CK_PY` source-executed (≈90 s); on the receiving side its run timed out after degrees 2–5, so no identical-script replay exists; the receiving co-owner built an independent alternative exact certificate (exact rank lower bounds in two prime fields matched by exact rational null vectors at k = 3), PASS (0,2,0,0,0,0) for k = 2–7, with its zero-cubic negative control failing as expected (19 Oct 2026; RECEIVER-REPORTED, files not in this package);')
ed('K2', 'evidence receipt', 'the [ALG] grade of the kernel dimensions rests on the exact script.',
   'the [ALG] grade of the kernel dimensions rests on the source exact script and the independent receiving-side exact certificate.')
ed('K3', 'evidence receipt', '| BYTE-VERIFIED; EXECUTED by the contributor only (receiving exact replay pending) |',
   '| BYTE-VERIFIED; EXECUTED by the contributor; receiving run timed out (k = 2–5 only); independent receiving-side alternative exact certificate PASS (RECEIVER-REPORTED, 19 Oct) |')
ed('K4', 'queue', '; exact replay of `TRIAD_CK_PY` (≈90 s) on the receiving side |',
   '; kernel: independent alternative exact certificate PASS on the receiving side (19 Oct); a full identical-script replay of `TRIAD_CK_PY` remains optional (RTG machine) |')

# ---- Taylor-model lemma review (receiving side)
ed('TM1', 'evidence receipt', '[OPEN] independent Taylor-model arithmetic/domain/rounding lemma review',
   '[OPEN] Taylor-model regional certificate. The independent lemma review has been performed by the receiving co-owner (19 Oct 2026, `STAGE2_TM_LEMMA_REVIEW_20261019.md`; RECEIVER-REPORTED, not in this package): remainder transport through the six primitive stages, the post-map s^+ enclosure and directed publication are supported under its scoped contract (pinned coefficient table, centred constructor, reviewed precision profile, per-stage enlarged edge bound 0 ≤ a ≤ 1); 9/9 stored centre bounds independently enclosed and 10/10 directed-serialization checks PASS. The derivative-domain guard a ≤ 1 is not enforced by the engine and must be enforced or verified per stage before any regional certificate. Regional K_N and global certification remain OPEN')
ed('TM2', 'queue', 'Independently review TM lemmas; separately authorize any governing full-region execution.',
   'TM lemma review performed by the receiving co-owner (19 Oct; scoped support; per-stage a ≤ 1 guard still to be enforced or verified); separately authorize any governing full-region execution.')
ed('TM3', 'queue', '**Next test:** Independent Taylor-model arithmetic/domain/rounding lemma review, followed by separately authorized governing full-region work.',
   '**Next test:** (r4.1) The lemma review is done (receiving co-owner, 19 Oct); next, enforce or verify the per-stage derivative-domain guard a ≤ 1, followed by separately authorized governing full-region work.')

# ---- D3 queue row
ed('D1', 'queue', '| P0 (r4) | Triadic owners | D3: adopt or revise Triadic v1.6.1 DRAFT r1 (birth-remainder scope narrowing per Genesis GCL-06) through the Triadic review/release gate;',
   '| P0 (r4) | Triadic owners | D3: receiving review 19 Oct — core ACCEPT SCOPED, DRAFT r1 REQUEST CHANGES; DRAFT r2 answers D3-R1/H-R1 (+E1); next, receiving review of r2, then the Triadic release gate (birth-remainder scope narrowing per Genesis GCL-06);')

# ---- §9 history and release boundary
R4H = '[ALG] R4 (18 Oct 2026) synchronizes sources'
ed('H1', 'metadata', R4H,
   '[ALG] R4.1 (19 Oct 2026) is a narrow rebuild on the exact r4 bytes. (i) Erratum E1: Dyadic v6.4.13 (adopted 18 Oct, after r4 was built) replaces the v6.4.12.1 pin; in RER-DYAD-FORMAL-INVOLUTION the OPEN 20 lines are split — B-∞ flat uniqueness CLOSED at the C^∞ scope for existing objects (Lemma F, F1–F3), B-∞ existence, B-an and the new B-6 OPEN; the imported formal RIDs are unchanged; nothing transfers to the triad. (ii) Triadic v1.6.1 DRAFT r2 replaces DRAFT r1 as the cited draft object after the 19 Oct receiving review (D3 core ACCEPT SCOPED; r1 REQUEST CHANGES); r4\'s r1 path erratum is corrected. (iii) Receiving-side evidence is recorded as RECEIVER-REPORTED: an independent alternative exact kernel certificate PASS (not an identical-script replay; G6 stays OPEN) and a scoped Taylor-model lemma review with an open per-stage domain guard (no regional or global certificate). No record is added, no grade changes, no record is accepted by its author. Genesis v2.8.8 is a draft and is not pinned.\n' + R4H)
ed('H2', 'metadata', '**Release boundary (r4):** This r4 document remains a noncanonical review draft;',
   '**Release boundary (r4.1):** r4.1 is a noncanonical review draft like r4; it adopts, freezes and accepts nothing. **Release boundary (r4):** This r4 document remains a noncanonical review draft;')

Path('r4_to_r4_1_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1), encoding='utf-8')
print(len(E), 'edits')
