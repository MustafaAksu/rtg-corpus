import numpy as np, itertools
rng=np.random.default_rng(0)
def obs(w):
    z=w[0]; d=w[1]+w[0]/2
    Qs=abs(z)**2; Qc=abs(d)**2; I=(z*np.conj(d)).real; S=(z*np.conj(d)).imag
    N=1.5*Qs+2*Qc
    return np.array([(1.5*Qs-2*Qc)/N, np.sqrt(12)*I/N, np.sqrt(12)*S/N]), N, S
def field(w,nu,chi):
    S=(w[0]*np.conj(w[1])).imag
    c=w*abs(w)**2; dn=nu*(c-c.mean())
    dc=(2j*chi/3)*(np.roll(w,-1)-np.roll(w,1))*S
    return dn+dc
def deriv(w,nu,chi,eps=1e-7):
    f=field(w,nu,chi); o0,N,_=obs(w); o1,_,_=obs(w+eps*f); o2,_,_=obs(w-eps*f)
    return (o1-o2)/(2*eps)/N, o0
# basis monomials in (u,v,sig) up to degree 3
mons=[m for m in itertools.product(range(4),repeat=3) if sum(m)<=3]
def fit(nu,chi):
    A=[];B=[]
    for _ in range(400):
        z=rng.normal()+1j*rng.normal(); y=rng.normal()+1j*rng.normal(); w=np.array([z,y,-z-y])
        dd,o=deriv(w,nu,chi); A.append([o[0]**m[0]*o[1]**m[1]*o[2]**m[2] for m in mons]); B.append(dd)
    A=np.array(A);B=np.array(B); X,res,_,_=np.linalg.lstsq(A,B,rcond=None)
    print("nu",nu,"chi",chi,"max fit err",abs(A@X-B).max())
    for k,name in enumerate(["du/N","dv/N","dsig/N"]):
        print("  ",name,"=", " + ".join("%.4f*%s"%(X[i,k],"u^%d v^%d sg^%d"%m) for i,m in enumerate(mons) if abs(X[i,k])>1e-6))
for nu,chi in [(1,0),(1j,0),(0,1),(0,1j)]: fit(nu,chi)
