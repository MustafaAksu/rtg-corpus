# Exact symbolic check of the leading-order shape-sphere map from the ER-2B C10 cubic representative.
from sympy import *
x1,x2,y1,y2,nr,ni,cr,ci,eps=symbols('x1 x2 y1 y2 nu_r nu_i chi_r chi_i eps',real=True)
z=x1+I*x2; d=y1+I*y2
w=[z,-z/2+d,-z/2-d]
nu=nr+I*ni; chi=cr+I*ci
S0=im(expand(w[0]*conjugate(w[1])))
cub=[wi*expand(wi*conjugate(wi)) for wi in w]; mean=sum(cub)/3
f=[nu*(cub[e]-mean)+(2*I*chi/3)*(w[(e+1)%3]-w[(e-1)%3])*S0 for e in range(3)]
assert simplify(expand(sum(f)))==0            # zero-sum representative
def obs(W):
    Z=W[0]; Dd=W[1]+W[0]/2
    Qs=expand(Z*conjugate(Z)); Qc=expand(Dd*conjugate(Dd)); P=expand(Z*conjugate(Dd))
    N=Rational(3,2)*Qs+2*Qc
    return (Rational(3,2)*Qs-2*Qc)/N, sqrt(12)*re(P)/N, sqrt(12)*im(P)/N, N
u,v,sg,N=obs(w)
W1=[expand(w[e]+eps*f[e]) for e in range(3)]
u1,v1,s1,N1=obs(W1)
D=lambda q: diff(q,eps).subs(eps,0)
du,dv,ds,dN=D(u1),D(v1),D(s1),D(N1)
c_re=2*cr-nr; c_im=2*ci-ni
checks={
 "du":   du+(N*sg/3)*(sg*c_re*u+c_im*v),
 "dv":   dv+(N*sg/3)*(sg*c_re*v-c_im*u),
 "dsig": ds-(N/3)*c_re*sg*(1-sg**2),
 "dN":   dN-(nr*N**2+(8*cr-4*nr)*(sg**2/12)*N**2),
 "sphere": u**2+v**2+sg**2-1,
}
ok=True
for k,e in checks.items():
    r=simplify(together(expand(e)))
    print(k,"residual:",r); ok&=(r==0)
print("ALL EXACT CHECKS PASS" if ok else "FAILURE")
