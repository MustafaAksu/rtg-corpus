"""One-time collection (not part of the deterministic build): copy every locally available cited source whose bytes match
the hash printed in RER r4.4 into sources_available/<KEY>__<basename>. Mismatching files are NOT copied (reported)."""
import sys, os, re, hashlib, shutil, urllib.parse
sys.path.insert(0, os.path.dirname(__file__)); import rer_parse as P
ROOT = '/mnt/user-data/outputs'; HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
md = open(os.path.join(HERE, 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_4.md'), encoding='utf-8').read()
st = P.source_table(md)
idx = {}
for root, dirs, files in os.walk(ROOT):
    if root.startswith(HERE): continue
    for f in files: idx.setdefault(f, []).append(os.path.join(root, f))
norm = lambda b: re.sub(r' \(\d+\)(?=\.[A-Za-z0-9]+$)', '', b)
dst = os.path.join(HERE, 'sources_available'); os.makedirs(dst, exist_ok=True)
done = set()
for b in P.blocks(md):
    if b[0] in P.GAPS: continue
    for i in P.parse_record(*b)['imports']:
        k = i['key']
        if k in done: continue
        done.add(k)
        cited = i['cited_sha256'] or (st.get(k) or {}).get('sha256')
        base = norm(urllib.parse.unquote(os.path.basename(i['path'])))
        for h in idx.get(base, []):
            s = hashlib.sha256(open(h, 'rb').read()).hexdigest()
            if cited and s == cited:
                shutil.copyfile(h, os.path.join(dst, f'{k}__{base}')); print('copied', k, base); break
        else:
            if idx.get(base): print('NO MATCH', k, base)
