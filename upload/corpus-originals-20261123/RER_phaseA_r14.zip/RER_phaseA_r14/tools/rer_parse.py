"""Deterministic parser for RER v0.2 Markdown (r4.4 layout). Pure functions; no I/O except the caller's."""
import re
REC_HEAD = re.compile(r'^### (RER-[A-Z0-9-]+) — (.*)$', re.M)
GAPS = {'RER-G7', 'RER-G8', 'RER-G9', 'RER-G10'}
FIELDS = ['Domain / admissibility', 'Map / clock', 'Factor or parametrization tested', 'Order / error', 'Contract type',
          'Evidence', 'Review receipt', 'Next test', 'Non-transfer']
TABLE_ROWS = ['Carrier', 'Observables', 'Constraints', 'Transformation law', 'Closure status', 'Memory']
IMP_A = re.compile(r'^Import/reference: \[(?P<key>[A-Za-z0-9_]+): (?P<sec>.*?)\]\((?P<path>[^)]*)\); (?P<rest>.*)$')
IMP_B = re.compile(r'^Import/reference: \[(?P<key>[A-Za-z0-9_]+): (?P<sec>.*?)\] \((?P<path>[^)]*)\)(?P<rest>.*)$')
SHA = re.compile(r'SHA-256 `([0-9a-f]{64})`')
SHA_SHORT = re.compile(r'SHA-256 `([0-9a-f]{6,63})')

def blocks(md):
    """Ordered (id, title, body) for every ### RER- heading; body runs to the next ### / ## heading or anchor line."""
    hs = list(REC_HEAD.finditer(md)); out = []
    for i, h in enumerate(hs):
        end = hs[i + 1].start() if i + 1 < len(hs) else len(md)
        body = md[h.end():end]
        m = re.search(r'\n## ', body)
        if m: body = body[:m.start()]
        out.append((h.group(1), h.group(2).strip(), body))
    return out

def parse_record(rid, title, body):
    r = {'id': rid, 'title': title}
    m = re.search(r'\*\*Primary grade:\*\* (.*?)\. \*\*Exactness:\*\* (.*?)\. \*\*Task:\*\* `([^`]*)`\. \*\*Registry/owner adoption:\*\* ([^\n]*)', body)
    r['primary_grade'], r['exactness_text'], r['task'], r['registry_owner_adoption'] = (m.groups() if m else (None,) * 4)
    r['exactness_codes'] = re.findall(r'`([A-Z_0-9]+)`', r['exactness_text'] or '')
    r['grade_tags'] = sorted(set(re.findall(r'\[(THM|ALG|NUM|DEF|OPEN)\]', r['primary_grade'] or '')))
    r['contract'] = {}
    for row in TABLE_ROWS:
        mm = re.search(r'^\| ' + re.escape(row) + r' \| (.*) \|$', body, re.M)
        r['contract'][row] = mm.group(1) if mm else None
    r['fields'] = {}
    for f in FIELDS:
        mm = re.search(r'^\*\*' + re.escape(f) + r':\*\* (.*)$', body, re.M)
        r['fields'][f] = mm.group(1) if mm else None
    r['claim_lines'] = [l for l in body.splitlines() if re.match(r'^\[(THM|ALG|NUM|DEF)\]', l)]
    r['open_items'] = [l[len('[OPEN] '):] for l in body.splitlines() if l.startswith('[OPEN] ')]
    r['missing_primary_inputs'] = re.findall(r'^\*\*Missing primary input:\*\* `([^`]*)`', body, re.M)
    r['imports'] = [parse_import(l) for l in body.splitlines() if l.startswith('Import/reference:')]
    return r

def parse_import(line):
    m = IMP_A.match(line) or IMP_B.match(line)
    if not m:
        return {'raw': line, 'parse': 'UNPARSED'}
    rest = m.group('rest')
    full = SHA.search(rest); short = None if full else SHA_SHORT.search(rest)
    lines = re.search(r'lines (\d+)[–-](\d+)', rest)
    rid = re.search(r'RID: ([A-Z0-9-]+(?:, [A-Z0-9-]+)*)', rest)
    return {'key': m.group('key'), 'section': m.group('sec'), 'path': m.group('path'),
            'lines': [int(lines.group(1)), int(lines.group(2))] if lines else None,
            'rid': rid.group(1) if rid else ('unavailable' if 'RID unavailable' in rest else None),
            'cited_sha256': full.group(1) if full else None,
            'cited_sha256_prefix': short.group(1) if short else None,
            'format': 'A' if IMP_A.match(line) else 'B', 'raw': line}

def source_table(md):
    """Key -> (description, path, sha) from the §7 source tables (two row layouts)."""
    sec = md.split('\n## 7.', 1)[1].split('\n## 8.', 1)[0]
    out = {}
    for l in sec.splitlines():
        m = re.match(r'^\| `([A-Za-z0-9_]+)` \| (.*?) \| (?:\[[^\]]*\]\(([^)]*)\))?(.*)$', l)
        if not m: continue
        key, desc, path, rest = m.groups()
        sha = re.search(r'`([0-9a-f]{64})`', l)
        out.setdefault(key, {'description': desc, 'path': path, 'sha256': sha.group(1) if sha else None, 'row': l})
    return out

def legacy_entries(md):
    sec = md.split('## 4.', 1)[1].split('\n## 5.', 1)[0]
    return [{'key': k, 'title_grade': t, 'current_use': u} for k, t, u in re.findall(r'^\| `(RER-[A-Z0-9]+)` \| (.*?) \| (.*?) \|$', sec, re.M)]
