"""Phase A r13 -> r14: Phase A pass on the exact RER r4.9 bytes (receiving decision of 20 Oct 2026: RER r4.9 ACCEPT SCOPED; Phase A r14 authorized).
- Source Markdown: RER r4.9 (9c0f43fc...cc84; package 7fa00ac1...100d) replaces r4.8; r4.9 package manifest added; rows carry path_in_r4_9_package.
- Dyadic v6.4.18 bytes added (sources_available/DYAD6418__..., custody inputs/source_custody_r14.json, section check inputs/dyad_v6_4_18_section_check/).
  Dyadic evidence BYTE_VERIFIED; r12-r13 OWNER_REPORTED state kept as history; v6.4.17 kept as superseded. Catalog key DYAD6418 (CURRENT).
- SYNC-DYAD-OPEN20-BINF: the builder now distinguishes a live record line from a quotation; with both listed r4.8 lines gone as lines (the OPEN
  line survives only as a quotation inside the superseding [THM] line) and both replacement lines present, the status is CHECK (record corrected),
  never CLOSED; closure needs the independent receiving check of this pass.
- Gates: A23, A24, A25, A27 re-based; A28 compares with the pinned r13 outputs. The r9/r10 regression gates of r10-r13 are retired to history (their
  results stay in the pinned r13 checker output). r13 outputs kept under inputs/phaseA_r13_outputs/.
Args: TARGET_DIR R49_PACKAGE_DIR V6418_FILE DYAD_SECTION_CHECK_DIR. Run once on a fresh copy of r13."""
import sys, os, json, shutil, hashlib
D, P49, F18, SCD = sys.argv[1:5]
sha = lambda b: hashlib.sha256(b).hexdigest()
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:100]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'; D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
R49 = '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84'; R49Z = '7fa00ac168b74550bff999f0b0d4c49b12255155d8b64f2ee2344facbf2a100d'
R48 = '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'
SCP = '02d16047…f21b'
MD9 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_9.md'; MD8 = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md'
FN = 'DYAD6418__RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md'
b18 = open(F18, 'rb').read(); assert sha(b18) == D18
m9 = open(os.path.join(P49, MD9), 'rb').read(); assert sha(m9) == R49
md9 = m9.decode('utf-8'); L9 = md9.split('\n')

# r13 outputs -> history
H = os.path.join(D, 'inputs/phaseA_r13_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r13.txt'))
# source swap (r4.8 is pinned through the r4.9 package manifest and the r13 outputs)
os.remove(os.path.join(D, MD8)); open(os.path.join(D, MD9), 'wb').write(m9)
shutil.copyfile(os.path.join(P49, 'SHA256SUMS.txt'), os.path.join(D, 'inputs/r4_9_package_SHA256SUMS.txt'))
# Dyadic v6.4.18 bytes, section check, custody
open(os.path.join(D, 'sources_available', FN), 'wb').write(b18)
SC = os.path.join(D, 'inputs/dyad_v6_4_18_section_check'); os.makedirs(SC)
SCF = ['dyad_v6_4_17_v6_4_18_section_identity_check.py', 'compare_output.txt', 'single_v6_4_18_output.txt', 'negcontrol_output.txt', 'DYAD_v6_4_18_SOURCE_READING_NOTE_20261020.md']
for f in SCF: shutil.copyfile(os.path.join(SCD, f), os.path.join(SC, f))
open(os.path.join(D, 'inputs/source_custody_r14.json'), 'w').write(dump({
    '_about': 'Phase A r14 custody for the Dyadic v6.4.18 owner file.',
    'container_chain_status': 'PREPARER_DECLARED: the file hash was computed here and matches the release record; the receiver independently confirmed the same hash on 20 Oct 2026 (section-check review and RER r4.9 review). The upload path is the preparer\'s declaration.',
    'files': {FN: {'key': 'DYAD6418', 'version': '6.4.18', 'sha256': D18,
                   'container': 'PI upload to the preparer session, 20 Oct 2026 (RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md, 256933 bytes, 1539 lines); hash equals the v6.4.18 release record (claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md); the same bytes are carried in the RER r4.9 package at sources/current/'}},
    'section_check': {'package_r1': 'DYAD_v6_4_18_SECTION_CHECK_r1.zip ' + SCP + ' (receiver-run: manifest 7/7, both hashes MATCH, 5/5 expected results, negative control detected)',
                      'files': 'inputs/dyad_v6_4_18_section_check/', 'blocks': ['§2 OPEN 19', '§2 OPEN 20', '§6.15', '§6.16', '§6.17'],
                      'v6_4_17_sha256': D17, 'v6_4_18_sha256': D18,
                      'result': 'PASS: both file hashes MATCH; OPEN 19, §6.15, §6.16 IDENTICAL; OPEN 20 and §6.17 CHANGED, as the release record implies (preparer run and independent receiver run)',
                      'receiver_decision': 'source reading note ACCEPT SCOPED (20 Oct 2026); owner-grade import, not an independent proof certification'}}))

p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p)); assert KV['Dyadic'] == '6.4.18'
KV['_catalog_checked'] = '2026-10-20 (Phase A r14, preparer)'
KV['_source_authority']['Dyadic'] = ('owner release record claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md; v6.4.18 bytes held and hashed here (sources_available, inputs/source_custody_r14.json), hash independently confirmed by the receiver. '
                                     'Superseded v6.4.17: bytes held and hashed here (sources_available, inputs/source_custody_r9.json), hash independently confirmed by the receiver.')
open(p, 'w').write(dump(KV))

p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
dy = CS['owner_current']['Dyadic']; assert dy['version'] == '6.4.18' and dy['evidence'] == 'OWNER_REPORTED'
hist = dict(dy['history']); hist['phaseA_r12_r13'] = {'version': '6.4.18', 'sha256': D18, 'evidence': 'OWNER_REPORTED', 'note': dy['note']}
CS['owner_current']['Dyadic'] = {'version': '6.4.18', 'sha256': D18, 'evidence': 'BYTE_VERIFIED', 'history': hist, 'superseded': dy['superseded'],
    'note': 'adopted 20 Oct 2026 (release record claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md). Phase A r14: bytes held in sources_available and hashed here (inputs/source_custody_r14.json); hash independently confirmed by the receiver. Per the owner text (SOURCE-READ, receiver-accepted reading): DYAD-THM-SMOOTH-EMBEDDING [THM] at C^∞ germ scope (E1–E4; E2 only for generators with DX\'(0) = 0; qualitative radius); OPEN 20 B-∞ existence CLOSED, B-an and B-6 OPEN; F1–F3 grades unchanged, existence condition discharged for K_m, J, R. Owner proof records not independently reviewed.'}
k = CS['keys']['DYAD6413']; assert k['rule'] == 'RECHECK_IN_PHASE_B'
k['reason'] += (' Phase A r14: in RER r4.9 the changed OPEN 20 content is cited through the separate key DYAD6418 (v6.4.18, byte-verified); DYAD6413 stays the pin for §6.15, §6.16, Lemma F and F1–F3. '
                'v6.4.17 → v6.4.18 leaves §6.15, §6.16 and the Lemma F / F1–F3 text byte-identical; the v6.4.13 → v6.4.15 step is not byte-checked here, so the row stays RECHECK_IN_PHASE_B.')
CS['keys']['DYAD6418'] = {'cited_version': '6.4.18', 'family': 'OWNER_DSN', 'owner': 'Dyadic', 'rule': 'CURRENT',
    'reason': 'Phase A r14: RER r4.9 pin for DYAD-THM-SMOOTH-EMBEDDING and the OPEN 20 status (v6.4.18 §2 OPEN 20, §6.17); cited hash equals the current owner file held here.',
    'receiver_section_check': 'RECEIVER-REPORTED (20 Oct 2026): DYAD_v6_4_18_SECTION_CHECK_r1.zip ' + SCP + ' re-run independently; manifest 7/7; both hashes MATCH; 5/5 expected results; negative control detected; source reading ACCEPT SCOPED.'}
w = CS['scientific_sync_warnings'][0]; assert w['id'] == 'SYNC-DYAD-OPEN20-BINF'
new_thm = [l for l in L9 if l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18 §6.17, §2 OPEN 20 | RID: DYAD-THM-SMOOTH-EMBEDDING]`')]
new_flat = [l for l in L9 if l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 |')]
assert len(new_thm) == 1 and len(new_flat) == 1 and w['rer_lines'][0] in md9 and w['rer_lines'][0] not in L9 and w['rer_lines'][1] not in L9
w['owner_evidence'] = 'BYTE_VERIFIED'
w['replacement_lines'] = [new_thm[0], new_flat[0]]
w['rer_correction'] = 'RER r4.9 (9c0f43fc…cc84; package 7fa00ac1…100d), receiver ACCEPT SCOPED 20 Oct 2026 (draft; owner-grade import, no independent proof certification)'
CS['_about'] += ' Phase A r14 (20 Oct): source RER r4.9; Dyadic v6.4.18 bytes added (inputs/source_custody_r14.json), evidence BYTE_VERIFIED; key DYAD6418; SYNC-DYAD-OPEN20-BINF recomputed (live line vs quotation).'
open(p, 'w').write(dump(CS))

rp('build_phaseA.py', [
 ('"""RER Phase A r13 builder (deterministic; r12 changed only the owner-currency catalog and added scientific sync warnings; r13 byte-verifies the RECOG current version). Inputs: exact r4.8 Markdown (r4.7 with the R10-F1 layout edit;',
  '"""RER Phase A r14 builder (deterministic; r12 changed only the owner-currency catalog and added scientific sync warnings; r13 byte-verifies the RECOG current version; r14 runs on RER r4.9 and byte-verifies Dyadic v6.4.18). Inputs: exact r4.9 Markdown (r4.8 + the narrow Dyadic v6.4.18 synchronization of RER-DYAD-FORMAL-INVOLUTION; r4.8 = r4.7 with the R10-F1 layout edit;'),
 ("MD = 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md'\nMD_SHA = '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e'\nR48_ZIP_SHA = '26efafc9efd3c3c5208c4e7238d99162bc99fd755357b436fa89f6d2db654a9f'\n",
  f"MD = '{MD9}'\nMD_SHA = '{R49}'\nR49_ZIP_SHA = '{R49Z}'\nBASE_R48_SHA = '{R48}'\nR48_ZIP_SHA = '26efafc9efd3c3c5208c4e7238d99162bc99fd755357b436fa89f6d2db654a9f'\n"),
 ("    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.8 hash mismatch'", "    mdb = rd(MD); assert sha(mdb) == MD_SHA, 'r4.9 hash mismatch'"),
 ("pkg48 = man('inputs/r4_8_package_SHA256SUMS.txt')\n", "pkg48 = man('inputs/r4_8_package_SHA256SUMS.txt'); pkg49 = man('inputs/r4_9_package_SHA256SUMS.txt')\n"),
 ("'path_in_r4_8_package': path in pkg48, 'cited_path': path,", "'path_in_r4_8_package': path in pkg48, 'path_in_r4_9_package': path in pkg49, 'cited_path': path,"),
 ("'RER-REGISTRY-PHASEA/13'", "'RER-REGISTRY-PHASEA/14'"), ("'RER-SOURCE-CURRENCY/13'", "'RER-SOURCE-CURRENCY/14'"), ("'RER-BLOCKED-SOURCES/13'", "'RER-BLOCKED-SOURCES/14'"),
 ("'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R48_ZIP_SHA, 'base_r4_7_sha256': BASE_R47_SHA,",
  "'source_markdown': {'file': MD, 'sha256': MD_SHA, 'package_zip_sha256': R49_ZIP_SHA, 'base_r4_8_sha256': BASE_R48_SHA, 'base_r4_8_package_zip_sha256': R48_ZIP_SHA, 'base_r4_7_sha256': BASE_R47_SHA,"),
 ("The r12 OWNER_REPORTED line above is kept as history.']}",
  "The r12 OWNER_REPORTED line above is kept as history.',\n"
  "                          'Phase A r14 (20 Oct 2026): source is RER r4.9 (9c0f43fc…cc84; package 7fa00ac1…100d), accepted ACCEPT SCOPED as a DRAFT: RER-DYAD-FORMAL-INVOLUTION imports DYAD-THM-SMOOTH-EMBEDDING (owner grade, C^∞ germ scope) through the new key DYAD6418 and records OPEN 20 B-∞ existence CLOSED; B-an, B-6 and physical exchange OPEN; record-level grade and FORMAL_ONLY unchanged; DYAD6413 pins kept. Dyadic v6.4.18 bytes held and hashed here (f70308f1…458d), hash receiver-confirmed; Dyadic evidence BYTE_VERIFIED. SYNC-DYAD-OPEN20-BINF is CHECK (record corrected; the old OPEN line survives only as a quotation), not CLOSED; closure needs the independent receiving check of this pass. The r12 OWNER_REPORTED Dyadic line above is kept as history.']}"),
 ("    cm['scientific_sync_warnings'] = [dict(w, rer_lines_present=[l in mdl for l in w['rer_lines']],\n"
  "        status=('OPEN — record correction required' if all(l in mdl for l in w['rer_lines']) else 'CHECK — a listed line is no longer present; re-review before closing'))\n"
  "        for w in CS.get('scientific_sync_warnings', [])]\n",
  "    def sync_status(w):\n"
  "        live = [l in mdl for l in w['rer_lines']]; repl = [l in mdl for l in w.get('replacement_lines', [])]\n"
  "        if all(live): return 'OPEN — record correction required'\n"
  "        if not any(live) and repl and all(repl): return 'CHECK — record corrected (listed lines no longer live record lines; a quoted old line is history, not a live OPEN); closure pending the independent receiving check of this Phase A pass'\n"
  "        return 'CHECK — a listed line is no longer present; re-review before closing'\n"
  "    cm['scientific_sync_warnings'] = [dict(w, rer_lines_present=[l in mdl for l in w['rer_lines']], rer_lines_quoted_only=[(l not in mdl) and (l in md) for l in w['rer_lines']],\n"
  "        replacement_lines_present=[l in mdl for l in w.get('replacement_lines', [])], status=sync_status(w))  # r14: a live line is a whole Markdown line; a quotation inside another line is not live\n"
  "        for w in CS.get('scientific_sync_warnings', [])]\n"),
 ("    return {'out/RER_REGISTRY_v0_2_r4_8_PHASEA.json': dump(reg),", "    return {'out/RER_REGISTRY_v0_2_r4_9_PHASEA.json': dump(reg),"),
 ("'# RER r4.8 — source-currency matrix (Phase A r13, noncanonical)'", "'# RER r4.9 — source-currency matrix (Phase A r14, noncanonical)'"),
 ("'# RER r4.8 — blocked-source register (Phase A r13, noncanonical)'", "'# RER r4.9 — blocked-source register (Phase A r14, noncanonical)'"),
 ("| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 pkg |", "| In r4 / r4.4 / r4.5 / r4.6 / r4.7 / r4.8 / r4.9 pkg |"),
 ("{yn(x['path_in_r4_8_package'])} |", "{yn(x['path_in_r4_8_package'])} / {yn(x['path_in_r4_9_package'])} |"),
])

C = os.path.join(D, 'check_phaseA.py'); t = open(C, encoding='utf-8').read()
def cut(t, a, b, new):
    i = t.index(a); j = t.index(b, i); assert t.count(a) == 1; return t[:i] + new + t[j:]
NEW_A23_25 = r'''    dy = oc['Dyadic']; D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'; D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
    dyrows = [x for x in cm['rows'] if x['owner'] == 'Dyadic']
    C9 = json.loads(B.rd('inputs/source_custody_r9.json')); f9 = C9['files'].get('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md', {})
    sc = B.rd('inputs/dyad_v6_4_17_section_check/compare_output.txt').decode('utf-8')
    sc_ok = (sc.count('IDENTICAL') == 5 and 'RESULT: PASS' in sc and 'DIFFERENT' not in sc and 'v6.4.16 33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0 MATCH' in sc
             and f'v6.4.17 {D17} MATCH' in sc)
    FN18 = 'DYAD6418__RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md'; P18 = os.path.join(HERE, 'sources_available', FN18)
    f18_ok = FN18 not in withhold and os.path.isfile(P18) and sha(open(P18, 'rb').read()) == D18
    C14 = json.loads(ri('inputs/source_custody_r14.json')); f14 = C14.get('files', {}).get(FN18, {})
    s18 = ri('inputs/dyad_v6_4_18_section_check/compare_output.txt').decode('utf-8')
    s18_ok = (f'v6.4.17 {D17} MATCH' in s18 and f'v6.4.18 {D18} MATCH' in s18 and s18.count(' IDENTICAL ') == 3 and s18.count(' CHANGED ') == 2 and 'RESULT: PASS' in s18
              and 'release-record expectation (OPEN 19, §6.15, §6.16 identical; OPEN 20, §6.17 changed): True' in s18)
    hs = dy.get('history', {})
    r13 = [x for x in dyrows if x['key'] == 'DYAD6413']; r18 = [x for x in dyrows if x['key'] == 'DYAD6418']
    dy_ok = (dy['version'] == '6.4.18' and dy['sha256'] == D18 and dy['evidence'] == 'BYTE_VERIFIED' and D18 in avail and D17 in avail and f18_ok
             and f14.get('key') == 'DYAD6418' and f14.get('sha256') == D18 and bool(f14.get('container')) and C14.get('container_chain_status', '').startswith('PREPARER_DECLARED') and s18_ok
             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok
             and hs.get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED' and hs.get('phaseA_r9_r11', {}).get('evidence') == 'BYTE_VERIFIED' and hs['phaseA_r9_r11'].get('sha256') == D17
             and hs.get('phaseA_r12_r13', {}).get('evidence') == 'OWNER_REPORTED' and hs['phaseA_r12_r13'].get('sha256') == D18 and hs['phaseA_r12_r13'].get('version') == '6.4.18'
             and dy.get('superseded', {}).get('version') == '6.4.17' and dy['superseded'].get('sha256') == D17 and dy['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and len(dyrows) == 2 and len(r13) == 1 and len(r18) == 1
             and all(x['cited_version'] == '6.4.13' and x['cited_sha256'] == '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED'
                     and x['currency'] == 'RECHECK_IN_PHASE_B' and x['status'] == 'HISTORICAL' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' and x['verified_current_hash'] == D18 and x['current_owner_evidence'] == 'BYTE_VERIFIED' for x in r13)
             and all(x['record'] == 'RER-DYAD-FORMAL-INVOLUTION' and x['row_kind'] == 'RECORD_IMPORT' and x['n'] == 3 and x['cited_version'] == '6.4.18' and x['cited_sha256'] == D18
                     and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['available_file'] == 'sources_available/' + FN18 and x['currency'] == 'CURRENT' and x['status'] == 'VERIFIED'
                     and x['verified_current_hash'] == D18 and x['path_in_r4_9_package'] is True and x.get('receiver_section_check', '').startswith('RECEIVER-REPORTED') for x in r18))
    g('A23 Dyadic v6.4.18 byte-verified (file, custody r14, section check 3 identical / 2 changed); v6.4.17 identity and r8, r9-r11, r12-r13 history kept; DYAD6413 pin v6.4.13 kept; DYAD6418 row CURRENT/VERIFIED', dy_ok, f'{len(dyrows)} Dyadic rows')
    sm = reg['source_markdown']
    H13 = 'inputs/phaseA_r13_outputs/'; o13 = ri(H13 + 'check_phaseA_output_r13.txt').decode('utf-8')
    src_ok = (sm['file'].endswith('_r4_9.md') and sm['sha256'] == B.MD_SHA == '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84' and sm['package_zip_sha256'] == '7fa00ac168b74550bff999f0b0d4c49b12255155d8b64f2ee2344facbf2a100d'
              and sm.get('base_r4_8_sha256') == '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e' and sm.get('base_r4_8_package_zip_sha256') == '26efafc9efd3c3c5208c4e7238d99162bc99fd755357b436fa89f6d2db654a9f'
              and sm.get('base_r4_7_sha256') == '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d' and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA
              and all('path_in_r4_9_package' in x for x in cm['rows']) and '28/28 gates PASS' in o13 and 'BAD' not in o13
              and '  ' + 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md\n' in B.rd('inputs/r4_9_package_SHA256SUMS.txt').decode() and '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e  RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md' in B.rd('inputs/r4_9_package_SHA256SUMS.txt').decode())
    g('A24 r4.9 source pass: r4.9, package and r4.8/r4.7 bases pinned; every row carries path_in_r4_9_package; r13 outputs and their 28/28 checker record kept as history', src_ok)
    g13 = json.loads(B.rd(H13 + 'RER_REGISTRY_v0_2_r4_8_PHASEA.json'))
    KEYR = 'RER-DYAD-FORMAL-INVOLUTION'; A13 = {x['id']: x for x in g13['records']}; A14 = {x['id']: x for x in reg['records']}
    a, c = A13.get(KEYR, {}), A14.get(KEYR, {})
    diff = sorted(k for k in set(a) | set(c) if a.get(k) != c.get(k))
    ua, uc = a.get('unclassified_lines', []), c.get('unclassified_lines', [])
    ud = [(x, y) for x, y in zip(ua, uc) if x != y]
    strip = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'records', 'source_markdown', 'source_table')}
    r_ok = (set(A13) == set(A14) and len(A14) == 20 and all(A13[k] == A14[k] for k in A13 if k != KEYR) and strip(reg) == strip(g13)
            and set(diff) <= {'claim_lines', 'open_items', 'imports', 'fields', 'unclassified_lines'} and {'open_items', 'imports', 'claim_lines'} <= set(diff)
            and c.get('primary_grade') == '[THM] (owner grade)' and c.get('grade_tags') == ['THM'] and c.get('exactness_codes') == ['FORMAL_ONLY']
            and c.get('open_items') == [o for o in a.get('open_items', []) if not o.startswith('OPEN 20 B-∞ existence:')] and len(c['open_items']) == len(a['open_items']) - 1
            and c.get('imports', [])[:len(a.get('imports', []))] == a.get('imports') and [i['key'] for i in c['imports'][len(a['imports']):]] == ['DYAD6418']
            and len(c.get('claim_lines', [])) == len(a.get('claim_lines', [])) + 1 and sum('RID: DYAD-THM-SMOOTH-EMBEDDING]' in l for l in c['claim_lines']) == 1
            and sorted(k for k in set(a['fields']) | set(c['fields']) if a['fields'].get(k) != c['fields'].get(k)) == ['Evidence', 'Non-transfer', 'Order / error']
            and len(ua) == len(uc) and len(ud) == 1 and ud[0][1].startswith(ud[0][0]) and '`DYAD-ALG-CENT-KERNEL` [ALG]' in ud[0][1] and 'DYAD-THM-SMOOTH-EMBEDDING' in ud[0][1]
            and {k: v for k, v in reg['source_table'].items() if k != 'DYAD6418'} == g13['source_table'] and reg['source_table'].get('DYAD6418', {}).get('sha256') == D18)
    g('A25 r13 registry equality: other 19 records and registry sections unchanged; the DYAD record differs only in its r4.9 synchronization (B-∞ OPEN item removed, DYAD6418 import, one [THM] claim, three fields, source note); grade, tags and FORMAL_ONLY kept', r_ok, f'DYAD fields differing from r13: {diff}')
'''
t = cut(t, "    dy = oc['Dyadic']; D17", "    rc = oc['RECOG'];", NEW_A23_25)
NEW_A27_28 = r'''    mdl = md.split('\n'); W = [w for w in cm.get('scientific_sync_warnings', []) if w.get('id') == 'SYNC-DYAD-OPEN20-BINF']
    w = W[0] if len(W) == 1 else {}
    m13 = json.loads(B.rd(H13 + 'SOURCE_CURRENCY_MATRIX.json')); w13 = (m13.get('scientific_sync_warnings') or [{}])[0]
    rl, rp_ = w.get('rer_lines', []), w.get('replacement_lines', [])
    dyr = next((x for x in reg['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION'), {})
    w_ok = (len(W) == 1 and w.get('record') == 'RER-DYAD-FORMAL-INVOLUTION' and w.get('key') == 'DYAD6413' and w.get('owner_version') == '6.4.18' and w.get('owner_evidence') == 'BYTE_VERIFIED'
            and rl == w13.get('rer_lines') and len(rl) == 2 and rl[0].startswith('[OPEN] OPEN 20 B-∞ existence:')
            and w.get('rer_lines_present') == [l in mdl for l in rl] == [False, False] and w.get('rer_lines_quoted_only') == [(l not in mdl) and (l in md) for l in rl] and w['rer_lines_quoted_only'][0] is True
            and len(rp_) == 2 and rp_[0].startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.18 §6.17, §2 OPEN 20 | RID: DYAD-THM-SMOOTH-EMBEDDING]`') and rp_[1].startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17 |')
            and w.get('replacement_lines_present') == [l in mdl for l in rp_] == [True, True] and rp_[0] in dyr.get('claim_lines', []) and rp_[1] in dyr.get('claim_lines', [])
            and not any(o.startswith('OPEN 20 B-∞ existence') for o in dyr.get('open_items', []))
            and w.get('status', '').startswith('CHECK — record corrected') and 'CLOSED' not in w.get('status', '') and 'catalog change alone does not close it' in w.get('closes_only_when', '')
            and w.get('rer_correction', '').startswith('RER r4.9 (9c0f43fc')
            and all(x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' for x in cm['rows'] if x['key'] == 'DYAD6413'))
    g('A27 SYNC-DYAD-OPEN20-BINF recomputed on r4.9: listed lines no longer live (the OPEN line only quoted), replacement lines live, B-∞ not an OPEN item; status CHECK, never CLOSED by Phase A', w_ok, w.get('status', 'missing')[:60])
    k13 = lambda x: (x['record'], x['row_kind'], x['n'], x['key'])
    M14 = {k13(x): x for x in cm['rows']}; extra = [x for x in cm['rows'] if k13(x) not in {k13(y) for y in m13['rows']}]
    DYF = {'current_owner_evidence', 'verified_current_hash', 'currency_reason'}
    dk = {k13(y): sorted(k for k in set(y) | set(M14.get(k13(y), {})) if y.get(k) != M14.get(k13(y), {}).get(k)) for y in m13['rows']}
    rows13_ok = (len(m13['rows']) == 90 and len(cm['rows']) == 91 and len(extra) == 1 and extra[0]['key'] == 'DYAD6418'
                 and [x for x in cm['rows'] if x['key'] != 'DYAD6418'] == [M14[k13(y)] for y in m13['rows']]
                 and all(set(d) <= ({'path_in_r4_9_package'} | (DYF if k[3] == 'DYAD6413' else set())) and 'path_in_r4_9_package' in d for k, d in dk.items()))
    wf = {'owner_evidence', 'status', 'rer_lines_present', 'rer_lines_quoted_only', 'replacement_lines', 'replacement_lines_present', 'rer_correction'}
    stripb = lambda o: {k: v for k, v in o.items() if k not in ('schema', 'source_markdown_sha256')}
    b13 = json.loads(B.rd(H13 + 'BLOCKED_SOURCE_REGISTER.json'))
    rest13_ok = (stripb(br) == stripb(b13) and {k: v for k, v in oc.items() if k != 'Dyadic'} == {k: v for k, v in m13['owner_current'].items() if k != 'Dyadic'}
                 and {k: v for k, v in w.items() if k not in wf} == {k: v for k, v in w13.items() if k not in wf}
                 and cm['watch_items'][:-1] == m13['watch_items'] and cm['watch_items'][-1].startswith('Phase A r14 (20 Oct 2026): source is RER r4.9')
                 and {k: v for k, v in meta.get('source_authority', {}).items() if k != 'Dyadic'} == {k: v for k, v in m13['owner_catalog']['source_authority'].items() if k != 'Dyadic'}
                 and cm['bytes_not_available_to_preparer'] == m13['bytes_not_available_to_preparer'] and m13['schema'] == 'RER-SOURCE-CURRENCY/13' and cm['schema'] == 'RER-SOURCE-CURRENCY/14')
    g('A28 r13 matrix equality: 90 rows unchanged except path_in_r4_9_package and the DYAD6413 owner-evidence fields; one new DYAD6418 row; blocked register, other owners and the warning text unchanged', rows13_ok and rest13_ok, f'{len(cm["rows"])} rows, {len(extra)} new')
'''
t = cut(t, "    mdl = md.split('\\n'); W = ", "    return all(res), res\n\nouts =", NEW_A27_28)
t = t.replace("'out/RER_REGISTRY_v0_2_r4_8_PHASEA.json'", "'out/RER_REGISTRY_v0_2_r4_9_PHASEA.json'")
for x, y in [("pkg48 = B.rd('inputs/r4_8_package_SHA256SUMS.txt').decode()\n", "pkg48 = B.rd('inputs/r4_8_package_SHA256SUMS.txt').decode(); pkg49 = B.rd('inputs/r4_9_package_SHA256SUMS.txt').decode()\n"),
             ("        if x.get('path_in_r4_8_package') and ('  ' + x['cited_path'] + '\\n') not in pkg48: bb.append(x['key'] + ':pkg48')\n",
              "        if x.get('path_in_r4_8_package') and ('  ' + x['cited_path'] + '\\n') not in pkg48: bb.append(x['key'] + ':pkg48')\n        if x.get('path_in_r4_9_package') and ('  ' + x['cited_path'] + '\\n') not in pkg49: bb.append(x['key'] + ':pkg49')\n")]:
    assert t.count(x) == 1, x[:60]; t = t.replace(x, y)
# controls
i = t.index('    T = ['); j = t.index('\n    allf = True', i); block = t[i:j].split('\n')
assert block[0].startswith("    T = [('") and all(l.startswith("         ('") for l in block[1:])
ents = [block[0][len('    T = ['):]] + [l.strip() for l in block[1:]]
ents[-1] = ents[-1][:-1] if ents[-1].endswith(']') else ents[-1]
keep = [e.rstrip(',') for e in ents if not any(e.startswith("('" + g + ' ') for g in ('A23', 'A24', 'A25', 'A27', 'A28'))]
NEWC = r'''('A23 v6.4.18 evidence back to OWNER_REPORTED (r12-r13 state)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='OWNER_REPORTED')))
('A23 Dyadic evidence relabelled BYTE_VERIFIED_HERE (not catalog vocabulary)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED_HERE')))
('A23 v6.4.18 hash replaced', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64)))
('A23 r12-r13 OWNER_REPORTED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r12_r13')))
('A23 r9-r11 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r9_r11')))
('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r8')))
('A23 superseded v6.4.17 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))
('A23 DYAD6413 pin silently moved to v6.4.18', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(cited_version='6.4.18', cited_sha256='f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d')))
('A23 DYAD6413 promoted to CURRENT/VERIFIED', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='CURRENT', status='VERIFIED')))
('A23 DYAD6418 row demoted to RECHECK_IN_PHASE_B', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(currency='RECHECK_IN_PHASE_B', status='HISTORICAL')))
('A23 DYAD6418 row verified hash removed', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').update(verified_current_hash=None)))
('A23 DYAD6418 receiver section-check receipt dropped', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6418').pop('receiver_section_check')))
('A24 source recorded as r4.8', 23, mut(R, lambda d: d['source_markdown'].update(sha256='2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e')))
('A24 r4.9 package hash replaced', 23, mut(R, lambda d: d['source_markdown'].update(package_zip_sha256='0' * 64)))
('A24 a row without path_in_r4_9_package', 23, mut(C, lambda d: d['rows'][0].pop('path_in_r4_9_package')))
('A25 r13 registry records re-used (r4.8 parse)', 24, mut(R, lambda d: d.update(records=json.loads(B.rd('inputs/phaseA_r13_outputs/RER_REGISTRY_v0_2_r4_8_PHASEA.json'))['records'])))
('A25 another record silently changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED')))
('A25 DYAD grade changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(primary_grade='[THM] (owner grade; formal and C^∞)')))
('A25 DYAD exactness widened', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(exactness_codes=['FORMAL_ONLY', 'C_INFTY'])))
('A25 B-an OPEN item dropped', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['open_items'].pop(0)))
('A25 DYAD6418 import dropped from the registry', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['imports'].pop()))
('A25 contract cell changed', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['contract'].__setitem__('Closure status', 'C_INFTY_UNIQUE')))
('A27 sync warning removed', 26, mut(C, lambda d: d.update(scientific_sync_warnings=[])))
('A27 sync warning marked CLOSED by Phase A', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='CLOSED — record corrected')))
('A27 sync warning left OPEN (quotation read as a live OPEN)', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='OPEN — record correction required', rer_lines_present=[True, False])))
('A27 quoted-only flag forged', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(rer_lines_quoted_only=[False, False])))
('A27 replacement line altered', 26, mut(C, lambda d: d['scientific_sync_warnings'][0]['replacement_lines'].__setitem__(0, d['scientific_sync_warnings'][0]['replacement_lines'][0].replace("DX'(0) = 0", 'DX(0) = 0', 1))))
('A27 listed r4.8 lines altered', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(rer_lines=['[OPEN] OPEN 20 B-∞ existence: (paraphrased)', d['scientific_sync_warnings'][0]['rer_lines'][1]])))
('A27 B-∞ existence re-added as a live OPEN item', 26, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['open_items'].append('OPEN 20 B-∞ existence: a C^∞ local involution')))
('A27 DYAD6413 row loses its sync_warning link', 26, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').pop('sync_warning')))
('A28 r13 matrix rows re-used', 27, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r13_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows'])))
('A28 non-Dyadic row reason edited', 27, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(currency_reason='edited')))
('A28 DYAD6418 row duplicated', 27, mut(C, lambda d: d['rows'].append(dict(next(x for x in d['rows'] if x['key'] == 'DYAD6418'), n=9))))
('A28 blocked register changed', 27, mut(K, lambda d: d['blocked'][0].update(note='edited')))
('A28 RECOG catalog entry changed', 27, mut(C, lambda d: d['owner_current']['RECOG'].update(note='edited')))
('A28 sync warning action edited', 27, mut(C, lambda d: d['scientific_sync_warnings'][0].update(required_action='none')))'''.split('\n')
allc = keep + NEWC
newblock = '    T = [' + (',\n         ').join(allc) + ']'
t = t[:i] + newblock + t[j:]
# file / input controls
t = t.replace("    sc = B.rd('inputs/recog_v0_3_21_section_check/compare_output.txt'); cu = B.rd('inputs/source_custody_r13.json')\n",
  "    _, rr = gates(outs, verbose=False, withhold=('DYAD6418__RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md',)); good = not rr[22]; allf &= good\n"
  "    print(f'  file control A23 v6.4.18 file withheld from sources_available: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    s18 = B.rd('inputs/dyad_v6_4_18_section_check/compare_output.txt'); c14 = B.rd('inputs/source_custody_r14.json'); o13 = B.rd('inputs/phaseA_r13_outputs/check_phaseA_output_r13.txt')\n"
  "    for n, p, bb, gi in [('A23 v6.4.18 section-check pattern not as expected', 'inputs/dyad_v6_4_18_section_check/compare_output.txt', s18.replace(b'): True', b'): False', 1), 22),\n"
  "                         ('A23 custody r14 hash altered', 'inputs/source_custody_r14.json', c14.replace(b'f70308f19f5955c0', b'0000000000000000', 1), 22),\n"
  "                         ('A24 r13 checker record altered', 'inputs/phaseA_r13_outputs/check_phaseA_output_r13.txt', o13.replace(b'28/28 gates PASS', b'27/28 gates PASS', 1), 23)]:\n"
  "        _, rr = gates(outs, verbose=False, inp={p: bb}); good = not rr[gi]; allf &= good\n"
  "        print(f'  input control {n}: {\"FAILS (good)\" if good else \"still passes (BAD)\"}')\n"
  "    sc = B.rd('inputs/recog_v0_3_21_section_check/compare_output.txt'); cu = B.rd('inputs/source_custody_r13.json')\n")
assert t.count("file control A23 v6.4.18 file withheld") == 1
# docstring
t = t.replace('"""Phase A r13 gates on RER v0.2 DRAFT r4.8 (r12: owner-currency catalog update; r13: RECOG v0.3.21 byte verification; source unchanged).',
  '"""Phase A r14 gates on RER v0.2 DRAFT r4.9 (r12: owner-currency catalog update; r13: RECOG v0.3.21 byte verification; r14: source r4.9, Dyadic v6.4.18 byte verification).\n'
  'r14 (replaces the A23/A24/A25/A27/A28 wording below, which is kept as history): A23 Dyadic v6.4.18 BYTE_VERIFIED only with the real file, custody r14 and the\n'
  'v6.4.17 -> v6.4.18 section check (3 identical, 2 changed, pattern as expected); v6.4.17 identity and r8, r9-r11, r12-r13 history kept; DYAD6413 row: pin v6.4.13,\n'
  'RECHECK_IN_PHASE_B, sync link; DYAD6418 row: CURRENT, VERIFIED, bytes matched. A24 r4.9 source and bases pinned; path_in_r4_9_package on every row; the r13 outputs\n'
  'and their 28/28 checker record kept (the r9/r10 regression gates of r10-r13 are retired; their results stay in that record). A25 registry equality with r13 except the\n'
  'r4.9 synchronization of the DYAD record. A27 SYNC-DYAD-OPEN20-BINF recomputed: a live line is a whole Markdown line; the old OPEN line is only quoted; replacement lines\n'
  'live; status CHECK, never CLOSED. A28 matrix equality with r13 (90 rows; only path_in_r4_9_package and the DYAD6413 owner-evidence fields change) plus one DYAD6418 row.', 1)
open(C, 'w', encoding='utf-8').write(t)

# pins
p = os.path.join(D, 'PINS.json'); PN = json.load(open(p))
for f in ['catalog_sources.json', 'inputs/owner_versions_known.json']: PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
for f in ['inputs/r4_9_package_SHA256SUMS.txt', 'inputs/source_custody_r14.json'] + ['inputs/dyad_v6_4_18_section_check/' + x for x in SCF] + ['inputs/phaseA_r13_outputs/' + x for x in sorted(os.listdir(H))]:
    assert f not in PN['inputs']; PN['inputs'][f] = sha(open(os.path.join(D, f), 'rb').read())
open(p, 'w').write(json.dumps(PN, indent=1) + '\n')
print('patched')
