#!/usr/bin/env python3
"""Exact homogeneous kernel of ad_{X3} for the TRIAD six-step return F = N^6 of the conditional modal map
(N from triad_formal_involution_birth_jet.py, which must sit alongside). X3 = cubic part of F (= cubic of log F).
Real vector fields on R^4 = (s_r, s_e, c_r, c_e), degrees k = 2..7, exact rationals. Exit 0 iff dims = (0,2,0,0,0,0).
Contrast: for the isolated dyad, DYAD-ALG-CENT-KERNEL gives dim 1 at k = 3 (R X3 only)."""
from pathlib import Path
from fractions import Fraction as Fr
from itertools import combinations_with_replacement
src = (Path(__file__).resolve().parent / 'triad_formal_involution_birth_jet.py').read_text()
exec(src.split('# --------------------------------------------------------------- birth graph')[0].split('ok_all = True')[0])
X3 = [homog(F[i], 3) for i in range(4)]
def dpart(p, j):
    o = {}
    for m, v in p.items():
        if m[j]:
            mm = list(m); mm[j] -= 1; o[tuple(mm)] = o.get(tuple(mm), 0) + v*m[j]
    return o
def pm(a, b):  # untruncated product
    o = {}
    for m1, v1 in a.items():
        for m2, v2 in b.items():
            m = tuple(p+q for p, q in zip(m1, m2)); o[m] = o.get(m, 0) + v1*v2
    return {m: v for m, v in o.items() if v}
dX = [[dpart(X3[i], j) for j in range(4)] for i in range(4)]
def bracket(Y):  # [X3, Y]_i = sum_j X3_j d_j Y_i - Y_j d_j X3_i
    out = []
    for i in range(4):
        acc = {}
        for j in range(4):
            for t in (pm(X3[j], dpart(Y[i], j)),):
                for m, v in t.items(): acc[m] = acc.get(m, 0) + v
            for m, v in pm(Y[j], dX[i][j]).items(): acc[m] = acc.get(m, 0) - v
        out.append({m: v for m, v in acc.items() if v})
    return out
def rank(rows):
    rows = [dict(r) for r in rows if r]; r = 0; piv = {}
    basis = []
    for row in rows:
        row = dict(row)
        for c, (brow) in list(piv.items()):
            pass
        # reduce against basis
        changed = True
        for (pc, b) in basis:
            if pc in row:
                f = row[pc]
                for c, v in b.items():
                    row[c] = row.get(c, 0) - f*v
                    if row[c] == 0: del row[c]
        if row:
            pc = min(row); f = row[pc]; row = {c: v/f for c, v in row.items()}
            # back-reduce existing
            nb = []
            for (qc, b) in basis:
                if pc in b:
                    g = b[pc]; b = dict(b)
                    for c, v in row.items():
                        b[c] = b.get(c, 0) - g*v
                        if b[c] == 0: del b[c]
                nb.append((qc, b))
            basis = nb + [(pc, row)]
    return len(basis), basis
def mon(k):
    out = []
    for c in combinations_with_replacement(range(4), k):
        m = [0]*4
        for i in c: m[i] += 1
        out.append(tuple(m))
    return out
dims = {}
for k in (2, 3, 4, 5, 6, 7):
    ms = mon(k); n = 4*len(ms)
    # columns = unknown index; build the linear map: for each unknown, its bracket image; rank of image vectors
    cols = []
    for i in range(4):
        for m in ms:
            Y = [{} for _ in range(4)]; Y[i] = {m: Fr(1)}
            img = bracket(Y)
            cols.append({(ii, mm): v for ii in range(4) for mm, v in img[ii].items()})
    rk, _ = rank(cols)
    dims[k] = n - rk
    print(f'k={k}: dim X_k = {n}, kernel dim = {n-rk}', flush=True)
import sys
ok = dims == {2: 0, 3: 2, 4: 0, 5: 0, 6: 0, 7: 0}
print('expected kernel dimensions (0,2,0,0,0,0):', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)

