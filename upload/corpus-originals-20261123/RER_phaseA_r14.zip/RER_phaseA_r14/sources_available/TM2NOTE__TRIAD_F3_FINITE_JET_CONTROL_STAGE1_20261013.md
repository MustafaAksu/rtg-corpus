# F3-FINITE-JET-CONTROL — stage 1: certified one-step defect bounds for N = 7, 8

**13 October 2026 · NONCANONICAL · Triadic contributor deliverable.** Conditional analytic modal map (Genesis→RER contract: E, P, T_e, reprojection after each primitive step, F = 𝒩⁶), trial birth graph with κ = √3 (κ̃ = 1), finite-jet age family 𝒞_N from `age_family_polynomials_kt1.json` (SHA `03042f84…d83c`). Nothing physical is selected; no owner DSN or RER record changes.

Files: `triad_tm_onestep_certificate.py` (SHA-256 `2ce1356463af930d875e393e0cf25bbc91e3de63f9d51cb98fcd3afa62bd6e5f`), log `triad_tm_onestep_certificate_stage1.log` (`aba40c53…71fb`). Needs mpmath and the polynomial JSON.

## 1. Why the first two routes fail, and what works

- **Global majorant (exact jet + analytic tail).** Even with the linear part handled exactly (A is a B-isometry, PE = I), the norm-majorant of 𝒩⁶ has coefficient ratio m_{d+1}/m_d ≈ 11, i.e. it converges only for x ≲ 0.09 and at R = 0.03 would need jet degree ≈ 70 to reach a 10⁻¹³ tail. Not viable. (The naive entrywise majorant is worse: M₁ ≈ 6255.)
- **Interval propagation of a scalar remainder.** Grows ×4–5 per modal step (wrapping): 10⁻¹² → 2·10⁻⁹ over six steps, swamping the defect. This is the blow-up Triadic reported.
- **What works: Taylor models with remainder transport through the exact linear part.** The input is a polynomial in only three variables (dr, de, dτ) on a box around a centre, so degree-6 models have 84 monomials. Each modal step is computed on the polynomial parts (interval coefficients; truncation and Lagrange remainders collected as "fresh" error), while the previous deviation is transported as a B-norm bound through the step's exact linear part A⊕A — an isometry — with only the nonlinear Lipschitz part charged to growth:

  ρ_s′ ≤ (1+λ)ρ_s + (2λ/3)ρ_c, ρ_c′ ≤ (1+λ)ρ_c + (λ/2)ρ_s, λ = √3·‖Dn‖_F on the enlarged region, n = T_e − A.

  On the stage-1 boxes λ ≈ 0.066, so six steps cost a factor ≈ 1.5 instead of ≈ 8000. Transported remainders end at ≈ 10⁻¹⁵ against polynomial parts ≈ 10⁻¹².

## 2. Rigour checklist (what the enclosure relies on)
1. All coefficient arithmetic in mpmath interval arithmetic (`iv`, 30 digits); rationals from the JSON converted exactly.
2. Products truncate degrees > K into the remainder via Σ|c_α|h^α (valid on the whole box).
3. sin / expm1 of a model: Taylor expansion about the constant term to order K, Lagrange remainder |q|^{K+1}/(K+1)! (|sin^{(j)}| ≤ 1) and e^{|p₀|+|q|}|q|^{K+1}/(K+1)!.
4. Remainder transport: B-norm conversions |x|_E ≤ √2|x|_B, |y|_B ≤ √(3/2)|y|_E; edge remainders β₁ = ρ_s, β₂,₃ ≤ ρ_s/2 + ρ_c; Dn = [[0, 1−cos η],[e^ρ−1, 1−cos η]] bounded on the enlarged region.
5. Final defect: 𝓔 = c⁺ − 𝒞_N(s⁺, τ+1) with |𝓔|_B ≤ √(3/2)·‖poly part + fresh‖_E + ρ_c + L_C·ρ_s, where L_C is an explicit Lipschitz bound of 𝒞_N(·, τ+1) on the region.
6. K_N := sup_box|𝓔_N|_B / R_min^{N+1}, R_min the box's minimum distance to the origin.

## 3. Results (K = 6, box half-widths h = 0.0025 in (r, e), h_τ = 0.05)

| box centre (r, e, τ) | R range | N | certified sup_box |𝓔_N|_B | |𝓔_N(centre)| | **certified K_N** |
|---|---|---|---|---|---|
| (0.0325, 0, 0.05) | [0.0300, 0.0351] | 7 | 2.13·10⁻¹² | 6.36·10⁻¹³ | **3.25** |
| | | 8 | 1.11·10⁻¹² | 3.25·10⁻¹³ | **56.2** |
| (0.0325, 0, 1.95) | [0.0300, 0.0351] | 7 | — | 6.92·10⁻¹³ | **3.18** |
| | | 8 | — | 2.81·10⁻¹³ | **46.8** |
| (−0.023, 0.023, 0.05) — Q_s-maximal direction | [0.0290, 0.0361] | 7 | — | 4.63·10⁻¹³ | **2.23** |
| | | 8 | — | 2.42·10⁻¹² | **523** |

Reading: (i) these are the first certified K₇, K₈ values; they bracket the empirical grid suprema of §10–11 of the C09 note (4.05 and 59.6 at R = 0.03 over 24 angles) — the box-based K is inflated by the R-spread inside the box (the defect scales like R^{N+1}, so a box spanning R ∈ [0.029, 0.036] costs up to (0.036/0.029)⁹ ≈ 7 for N = 8); narrower radial boxes tighten this at linear cost. (ii) The direction dependence of N = 8 is real: at the Q_s-maximal angle the degree-9 term is an order of magnitude larger, exactly as the grid showed. (iii) τ-dependence over [0, 2] is mild at this radius.

Runtime: ≈ 60 s (N = 7) and ≈ 130 s (N = 8) per box here.

## 4. What this certifies and what it does not
Certified: on each listed box, for every (s, τ) in it, ‖𝓔_N(s, τ)‖_B ≤ K_N·R_min^{N+1}, against the real sin/exp map with reprojection, including all six intermediate primitive states (they are the models' intermediate stages). Not certified: anything outside the three boxes; a single K over the whole stage-1 region R ∈ [0.03, 0.08], τ ∈ [0, 2]; multi-step accumulation; observable-level errors (follow from §5 of the N7/N8 review once |𝓔| is bounded: |ΔI| ≤ (3/2)|s⁺||𝓔|, |ΔΩ_G| ≤ (√3/2)|s⁺||𝓔|). κ̃ = 1 only.

## 5. Stage 2 — covering the region (for the RTG machine)
The same script is the engine; the sweep is a loop over boxes. Cost estimate: annulus R ∈ [0.03, 0.08] with h = 0.0025 ≈ 700 (r, e)-boxes × τ-boxes. Two savings are available before running it: raise K to 8 and h_τ to 0.25–0.5 (τ enters polynomially at the input, so wide τ-boxes are cheap for the model), and use h = 0.005 for R ≥ 0.05 with K = 8. With those, ≈ 300–500 box-runs per N at 1–3 min each — a day on one core, hours on eight. The output would be a certified table K_N(R-shell, angle sector) and a single K_{N,2} = max over boxes, which is the stage-1 target as Triadic defined it. The B-orthogonal transverse component can be reported from the same models at no extra cost.

## 6. [COR] Proof-contract repair on Triadic receiving audit (13 Oct, afternoon) — governing stage-1 results

**Defect accepted.** In `certify_box`, the radius used for the Lipschitz constant L_C of 𝒞_N(·, τ+1) was built from the *input* box, not from the post-map parent s⁺. Triadic's point-interval countercheck (`check_postmap_radius.py`, SHA `40cf772b…3a47`, reproduced here) shows ‖F_s‖₂ = 0.0360712… at the third box's corner against the declared 0.0360624…: the derivative domain did not enclose the image, so the inequality |𝒞_N(s⁺_true) − 𝒞_N(s⁺_poly)| ≤ L_C ρ_s was unsupported. The numbers in §3 are therefore withdrawn as certificates (they stand as reproduced computations of a flawed contract).

**Repair adopted:** the hardened engine `triad_tm_onestep_certificate_v2.py` (SHA `c14c27cd3acf188ee92afc118d24edbdd3864eaa007ec9ca58b41aef06516ca0`, Triadic draft, reviewed line by line against the original: 31 changed lines, all in `certify_box` and the box table). Changes: (i) Rm from the computed s⁺ polynomial bound plus √2·ρ_s per component — this encloses both s⁺_true and s⁺_poly and the segment between them; (ii) exact decimal box endpoints via rational strings with outward-rounded Rmin/Rmax; (iii) constants published only rounded up. Everything else (models, transport, Lagrange remainders) is unchanged. All three boxes rerun for N = 7, 8 (log `triad_tm_onestep_certificate_v2_stage1.log`, SHA `0b4381b2…f7f0`).

**Governing table (K = 6, h = 0.0025, h_τ = 0.05, κ̃ = 1; constants rounded UP):**

| box centre (r, e, τ) | R range (outward) | N | sup_box |𝓔_N|_B ≤ | centre enclosure | **K_N (certified, ≥)** |
|---|---|---|---|---|---|
| (0.0325, 0, 0.05) | [0.0300, 0.0351] | 7 | 2.130·10⁻¹² | 6.363·10⁻¹³ | **3.246** |
| | | 8 | 1.106·10⁻¹² | 3.249·10⁻¹³ | **56.18** |
| (0.0325, 0, 1.95) | [0.0300, 0.0351] | 7 | 2.088·10⁻¹² | 6.921·10⁻¹³ | **3.182** |
| | | 8 | 9.214·10⁻¹³ | 2.809·10⁻¹³ | **46.82** |
| (−0.023, 0.023, 0.05) | [0.0289, 0.0361] | 7 | 1.115·10⁻¹² | 4.635·10⁻¹³ | **2.234** |
| | | 8 | 7.563·10⁻¹² | 2.421·10⁻¹² | **522.7** |

The repair moves the constants in the sixth significant figure (e.g. K₇ on box 3: 2.2339899… → 2.2339901…), as the audit predicted; the §3 three-figure values that had been rounded down (3.18, 46.8, 2.23) are superseded by the rounded-up ones above.

**Also accepted:** the Cartesian box count for stage 2 — ≈ 268 inner (h = 0.0025 on R ∈ [0.03, 0.05]) + 180 outer (h = 0.005 on [0.05, 0.08]) per τ-layer, ≈ 896 box-runs per N with two τ-layers of half-width 0.5 — replaces my 300–500 estimate, which assumed optimisations not yet shown. The stage-2 driver will be written on the v2 engine, with the driver features Triadic listed (exact decimal endpoints, hashes, per-box resumable records for each N, six intermediate-state bounds and the τ+1 interval, upward-rounded constants, B-orthogonal transverse defect reported separately, explicit coverage certificate of the polar annulus by the Cartesian boxes). Pilot on K = 8 / wide τ-boxes at a few corners precedes the full sweep.
