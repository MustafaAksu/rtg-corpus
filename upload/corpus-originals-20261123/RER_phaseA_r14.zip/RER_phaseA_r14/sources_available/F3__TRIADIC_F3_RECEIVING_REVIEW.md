# Triadic receiving review — Genesis F3 invariant stratum and observable factors

**8 October 2026** · NONCANONICAL · source-owner: Genesis · effective-factor review: Triadic · recording: RER · no owner DSN amendment.

## Source contract

Named analytic, **conditional** standalone modal model only:

\[
E=\begin{pmatrix}1&0\\-1/2&1\\-1/2&-1\end{pmatrix},\quad
P=\begin{pmatrix}2/3&-1/3&-1/3\\0&1/2&-1/2\end{pmatrix},\quad
T_e(\rho,\eta)=(\rho-\sin\eta,\eta+e^\rho-1-\sin\eta),
\]
\[
\mathcal N=(P\otimes I_2)T_e^{\times3}(E\otimes I_2),\qquad\mathcal F=\mathcal N^6.
\]
Reprojection occurs **after every step**. The source jet `jet_coefficients.json` is byte copied from the archived `TRIAD_MINIMAL_OBSERVABLE_FACTOR_STUDY_v0_1_20261008.zip` package's `sources` folder. Source-owner and physically selected standalone K3 do not coincide. The physical target remains `NO_TARGET_VECTOR_LAW_SELECTED`.

## F3-a: exact child-free invariant stratum — ACCEPT [ALG]

With `s=(r,e)`, `c=(c_r,c_e)`, incidence edges are `s, -s/2+c, -s/2-c`. On
\[
M_0=\{c=0\},
\]
last two edges agree, so the common analytic edge map preserves equality. The projection `P` has child row `(0,1/2,-1/2)`. Thus `N(M0)⊂M0` exactly and therefore `F(M0)⊂M0`, not only to finite jet order. The exact reduced primitive map is
\[
\mathcal N_s(s,0)=\frac23\big[T_e(s)-T_e(-s/2)\big].
\]
Writing explicitly,
\[
\mathcal N_s(r,e)=\left(r-\frac23(\sin e+\sin(e/2)),\ e+\frac23[e^r-e^{-r/2}-\sin e-\sin(e/2)]\right).
\]
This is an exact **two-dimensional** autonomous restriction, with no child birth event.

## F3-b: minimal local Qs-preserving state on M0 — ACCEPT [ALG/conditional theorem]

Let `Q=r²-re+e²`; the retrieved full-modal six-step jet restricted to `c=0` yields
\[
Q(\mathcal F_s(s))-Q(s)=\tfrac14Q^2 + P_5(r,e)+O(\|s\|^6),
\quad
P_5=\frac Q{64}(5r^3-8er^2-9e^2r-5e^3).
\]
For two present-state delays `H1(s)=(Q(s), Q(F_s(s)))`, exact symbolic differentiation gives
\[
\det D\mathcal H_1(r,e)
=-\frac Q{64}(r^3+74er^2-11e^2r-33e^3)+O(\|s\|^6).
\]
At `s=(t,0)`, this is `-t⁵/64+O(t⁶)`, nonzero for all sufficiently small `t>0`. Any local `C1` factor preserving `Q` and intertwining the **full analytic map** has dimension at least two near such a point; the identity factor on invariant `M0` attains two. Thus local minimal dimension **equals two on M0**, whereas the prior unrestricted ambient calculation provides a local lower bound of four on its certified 4D domain. These are different state spaces and not competing conclusions.

`Q` alone is not autonomous on `M0`: `s=(t,0)` and `s=(-t,0)` share `Q=t²`, but differ at next measurement by `5t⁵/32+O(t⁶)` (in the order positive minus negative). This failure is quintic on `M0`; the earlier F1 failure at quartic order involves unrestricted child coordinates.

## F3-c: new optional model-specific trial — leading nonzero-child birth graph is NOT invariant

**This is an inference from the retrieved jet, not a Genesis owner claim.** Consider the formal graph `Cκ(s)=κ Q(s) J_Qs`, `J_Q=[[1,-2],[2,-1]]/sqrt(3)` in the *same conditional modal model*. With `κ` constant and `κ≠0`, define
\[
\mathcal D_κ(s)
:=\mathcal F_c(s,C_κ(s))-C_κ(\mathcal F_s(s,C_κ(s))).
\]
Using the exact cubic six-step vector jet, its first possible nonzero homogeneous component is
\[
\boxed{\mathcal D_κ(s)=-\frac{\sqrt3\,κ}{6}Q(s)^2s+O(\|s\|^6).}
\]
The coefficient is nonzero for nonzero `κ,s`, hence this leading nonzero-child graph is not an exactly invariant graph of the **named conditional modal map** on a punctured neighborhood of the origin. For an analytic correction `Cκ(s)+O(‖s‖⁵)` the order-five term is unchanged (assuming the usual matching derivative-order control); fifth-order amendments cannot fix this leading tangency defect. The attached high-precision **full analytic 6-step evaluation** independently approaches the same coefficient for both historical reference `κ` values.

**Scope:** The original Genesis leading birth theorem is an initial-state admissibility claim in its declared construction, not a theorem that the above graph is a post-birth invariant manifold of this optional reprojected modal model. The present trial establishes **no failure of Genesis birth mathematics** and does not settle physical `K3` birth/restriction; incidence and clock/model bridges are not selected. The physical/nonzero-child F3 target remains **OPEN**.

## RER disposition and action

* `RER-GEN-C06` PROPOSED: `M0` exactly invariant; minimal local `Qs`-preserving dimension two.
* `RER-GEN-C07` PROPOSED: formal nonzero-child leading graph fails invariance in the named model; source-admitted physically relevant birth manifold and factor remain OPEN.
* `RER-GEN-C01`–`C05`, main registry v0.1 and all adopted owner DSNs remain untouched. RRF receives **no** new profile and **no** physical emergence conclusion follows.

Next request to Genesis: independent physical/event/domain admissibility conditions for any nonzero-child invariant manifold of the selected target. Do not retrofit an event condition to obtain a desired factor. Triadic can test candidates once source-admitted.

## Verification boundary

`check_f3.py` and `check_birth_graph_jet.py` recompute algebra from the byte-copied archived polynomial jet. `check_analytic_f3.py` evaluates the actual sine/exponential and six-reprojection-step formula with mpmath at 90 digits. This is a **local model recheck**, not authenticated rerun of the original Genesis historical producer, not a full domain/cascade certificate.
