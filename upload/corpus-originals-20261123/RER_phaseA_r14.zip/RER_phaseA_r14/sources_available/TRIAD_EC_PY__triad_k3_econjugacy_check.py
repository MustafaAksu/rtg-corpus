#!/usr/bin/env python3
"""E-conjugacy of the RER conditional modal map N and the Genesis projected-K3 map F1 = P_C o T^{x3}.
Exact part (Fractions): P E = I_2 and E P = I_3 - J/3 (mean subtraction; J = all-ones), so E: R^2 -> C={sum=0} is a
linear iso with inverse P|_C.  Hence E o N = (EP (x) I2) o T^{x3} o (E (x) I2) = F1 o E on R^4.
Numeric part (mpmath 50 dps): E(N(x)) - F1(E x) at random points; and F1 maps C to C.  Exit 0 iff all hold."""
import sys, random
from fractions import Fraction as Fr
import mpmath as mp
mp.mp.dps = 50
E = [[Fr(1), Fr(0)], [Fr(-1, 2), Fr(1)], [Fr(-1, 2), Fr(-1)]]
P = [[Fr(2, 3), Fr(-1, 3), Fr(-1, 3)], [Fr(0), Fr(1, 2), Fr(-1, 2)]]
PE = [[sum(P[i][k]*E[k][j] for k in range(3)) for j in range(2)] for i in range(2)]
EP = [[sum(E[i][k]*P[k][j] for k in range(2)) for j in range(3)] for i in range(3)]
ok1 = PE == [[1, 0], [0, 1]]
ok2 = EP == [[Fr(1 if i == j else 0) - Fr(1, 3) for j in range(3)] for i in range(3)]
print('P E = I_2:', ok1, '| E P = I - J/3:', ok2)
def T(r):
    rho, eta = r
    return (rho - mp.sin(eta), eta + mp.e**rho - 1 - mp.sin(eta))
def Emap(x):  # x=(s_rho,s_eta,c_rho,c_eta) -> three edge vectors
    s, c = (x[0], x[1]), (x[2], x[3])
    return [tuple(mp.mpf(E[e][0].numerator)/E[e][0].denominator*s[i] + mp.mpf(E[e][1].numerator)/E[e][1].denominator*c[i] for i in range(2)) for e in range(3)]
def N(x):
    r = [T(re) for re in Emap(x)]
    return tuple(sum(mp.mpf(P[a][e].numerator)/P[a][e].denominator*r[e][i] for e in range(3)) for a in range(2) for i in range(2))
def F1(edges):
    t = [T(re) for re in edges]; m = [sum(t[e][i] for e in range(3))/3 for i in range(2)]
    return [tuple(t[e][i] - m[i] for i in range(2)) for e in range(3)]
random.seed(7); worst = mp.mpf(0); worst_c = mp.mpf(0)
for _ in range(50):
    x = tuple(mp.mpf(random.uniform(-0.3, 0.3)) for _ in range(4))
    y = N(x); Nx = (y[0], y[1], y[2], y[3])
    lhs = Emap(Nx); rhs = F1(Emap(x))
    worst = max(worst, max(abs(lhs[e][i] - rhs[e][i]) for e in range(3) for i in range(2)))
    worst_c = max(worst_c, max(abs(sum(rhs[e][i] for e in range(3))) for i in range(2)))
ok3 = worst < mp.mpf(10)**-45 and worst_c < mp.mpf(10)**-45
print('max |E N(x) - F1(E x)| =', mp.nstr(worst, 3), '| max |sum_e F1_e| =', mp.nstr(worst_c, 3))
ok = ok1 and ok2 and ok3
print('E-conjugacy E o N = F1 o E:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
