#!/usr/bin/env python3
"""
Independent reproduction of RER-GEN-C09 (and the C07 / C08 inputs it uses).

Model (Genesis->RER conditional analytic modal contract, 8-9 Oct 2026):
  E = [[1,0],[-1/2,1],[-1/2,-1]],  P = (E^T E)^{-1} E^T = [[2/3,-1/3,-1/3],[0,1/2,-1/2]]
  T_e(r,e) = (r - sin e, e + exp(r) - 1 - sin e)
  N = (P (x) I2) o T_e^{x3} o (E (x) I2),   F = N^6   (reprojection after every primitive step)
  Birth graph (contract A): B_k(s) = (s, k Q(s) J_Q s),  Q(r,e) = r^2 - r e + e^2,
                            J_Q = (1/sqrt3) [[1,-2],[2,-1]].

Independence: this script imports nothing from the RER/C08/C09 packages and does not
read jet_coefficients.json.  It never truncates the map to a G3/G4 jet: it composes the
full analytic sin/exp map as exact power series in a scale parameter t along a ray
s = t*u, truncated only in t (order NT).  Coefficients are exact Fractions.

sqrt(3) bookkeeping: write kappa = sqrt(3)*kt (kt rational).  Then
   C_k(s)      = kt Q(s) M s,          M = [[1,-2],[2,-1]]
   R_k(s)      = -(sqrt3 k/6) Q^2 s    = -(kt/2) Q^2 s
   2k^2/9      = 2 kt^2/3,  k^2/18 = kt^2/6
   Omega_G     = (sqrt3/2) w,  w = s_e c_r - s_r c_e;  claim Omega_G,n = -k Q^2  <=>  w_n = -2 kt Q^2
   age fingerprint 2 sqrt3 I/(Omega_G Q_s) = 4 I/(w Q_s)
so every asserted identity is checked over Q.

Usage:  python c09_independent_series_check.py            (exit 0 iff all checks pass)
        python c09_independent_series_check.py --negative (perturbs the claimed C09 coefficient; must exit 1)
        python c09_independent_series_check.py --quick    (1 kappa, 2 rays, ages 0-2, t^11; for slow environments)
"""
import sys
from fractions import Fraction as Fr
from math import factorial

NEG   = "--negative" in sys.argv
QUICK = "--quick" in sys.argv       # reduced grid for slow environments (~2 s instead of ~18 s)
NT = 11 if QUICK else 12            # series truncation: keep t^0..t^NT

# ---------------------------------------------------------------- series algebra
def z():            return [Fr(0)] * (NT + 1)
def add(a, b):      return [x + y for x, y in zip(a, b)]
def sub(a, b):      return [x - y for x, y in zip(a, b)]
def scl(c, a):      return [c * x for x in a]
def mul(a, b):
    out = z()
    for i, x in enumerate(a):
        if x == 0: continue
        for j in range(NT + 1 - i):
            y = b[j]
            if y: out[i + j] += x * y
    return out
def ser_sin(a):
    assert a[0] == 0
    out, p, a2 = z(), a[:], mul(a, a)
    k = 0
    while any(p):
        out = add(out, scl(Fr((-1) ** k, factorial(2 * k + 1)), p))
        p = mul(p, a2); k += 1
    return out
def ser_expm1(a):
    assert a[0] == 0
    out, p, k = z(), a[:], 1
    while any(p):
        out = add(out, scl(Fr(1, factorial(k)), p))
        p = mul(p, a); k += 1
    return out
def order(a):
    for i, x in enumerate(a):
        if x != 0: return i
    return None   # zero to truncation order
def mono(c, k):
    o = z(); o[k] = Fr(c); return o

# ---------------------------------------------------------------- model
HALF = Fr(1, 2)
def Te(v):
    r, e = v
    se = ser_sin(e)
    return (sub(r, se), sub(add(e, ser_expm1(r)), se))
def N_step(X):
    s, c = X
    # E (x) I2 : edges AB = s, BC = -1/2 s + c, CA = -1/2 s - c
    eAB = s
    eBC = (add(scl(-HALF, s[0]), c[0]), add(scl(-HALF, s[1]), c[1]))
    eCA = (sub(scl(-HALF, s[0]), c[0]), sub(scl(-HALF, s[1]), c[1]))
    a, b, d = Te(eAB), Te(eBC), Te(eCA)
    # P (x) I2
    s2 = tuple(sub(sub(scl(Fr(2, 3), a[i]), scl(Fr(1, 3), b[i])), scl(Fr(1, 3), d[i])) for i in range(2))
    c2 = tuple(sub(scl(HALF, b[i]), scl(HALF, d[i])) for i in range(2))
    return (s2, c2)
def F(X):
    for _ in range(6): X = N_step(X)
    return X
def Fn(X, n):
    for _ in range(n): X = F(X)
    return X

def Qf(v):         # r^2 - r e + e^2
    r, e = v
    return add(sub(mul(r, r), mul(r, e)), mul(e, e))
def Bdot(u, v):    # u^T B v, B=[[1,-1/2],[-1/2,1]]
    return add(sub(add(mul(u[0], v[0]), mul(u[1], v[1])), scl(HALF, mul(u[0], v[1]))), scl(-HALF, mul(u[1], v[0])))
def wraw(s, c):    # s_e c_r - s_r c_e
    return sub(mul(s[1], c[0]), mul(s[0], c[1]))
def Cgraph(s, kt): # kt Q(s) M s
    q = Qf(s)
    Ms = (sub(s[0], scl(2, s[1])), sub(scl(2, s[0]), s[1]))
    return (scl(kt, mul(q, Ms[0])), scl(kt, mul(q, Ms[1])))
def birth(s, kt):  return (s, Cgraph(s, kt))
def ray(u):        return (mono(u[0], 1), mono(u[1], 1))

def initial_for_current_parent(target_s, n, kt):
    """Solve s_n(s0) = target_s (formal series in t). D F(0)=I, so Newton-free iteration converges t-adically."""
    s0 = target_s
    for _ in range(NT + 2):
        sn = Fn(birth(s0, kt), n)[0]
        corr = (sub(target_s[0], sn[0]), sub(target_s[1], sn[1]))
        if order(corr[0]) is None and order(corr[1]) is None: break
        s0 = (add(s0[0], corr[0]), add(s0[1], corr[1]))
    sn = Fn(birth(s0, kt), n)[0]
    assert order(sub(sn[0], target_s[0])) is None and order(sub(sn[1], target_s[1])) is None
    return s0

# ---------------------------------------------------------------- checks
PASS, FAIL = [0], [0]
def check(name, ok, detail=""):
    if ok: PASS[0] += 1; print(f"PASS  {name}" + (f"   [{detail}]" if detail else ""))
    else:  FAIL[0] += 1; print(f"FAIL  {name}" + (f"   [{detail}]" if detail else ""))
def at_least(a, k):   # series a = O(t^k)
    o = order(a); return o is None or o >= k

KTS  = [Fr(1)] if QUICK else [Fr(1), Fr(-2, 3), Fr(3, 5)]
DIRS = [(1, 0), (2, -1)] if QUICK else [(1, 0), (0, 1), (1, 1), (2, -1), (1, 3)]
AGES = [0, 1, 2] if QUICK else [0, 1, 2, 3]
coefC09 = Fr(1, 2) if not NEG else Fr(1, 3)     # claimed sqrt3 k/6 -> kt/2

# 0. sanity: P is the left inverse of E, F(0)=0, DF(0)=I, no quadratic part
X = Fn(((mono(1, 1), z()), (z(), z())), 1)
check("DF(0)=I and no t^2 term on (1,0,0,0) ray",
      X[0][0][1] == 1 and X[0][1][1] == 0 and X[0][0][2] == 0 and X[0][1][2] == 0)

# 1. C07/C09 in INITIAL chart -> current-parent identity, no inversion:
#    c_n - C(s_n) - n R(s_n) = O(t^6)
for kt in KTS:
    for u in DIRS:
        for n in AGES:
            Xn = Fn(birth(ray(u), kt), n)
            s, c = Xn
            q = Qf(s)
            R = (scl(-coefC09 * kt, mul(mul(q, q), s[0])), scl(-coefC09 * kt, mul(mul(q, q), s[1])))
            C = Cgraph(s, kt)
            res = [sub(sub(c[i], C[i]), scl(n, R[i])) for i in range(2)]
            ok = at_least(res[0], 6) and at_least(res[1], 6)
            if not ok or (kt == 1 and u == (1, 0)):
                check(f"c_n=C(s)+nR(s)+O(6) kt={kt} u={u} n={n}", ok, f"residual orders {order(res[0])},{order(res[1])}")
            else:
                PASS[0] += 1

# 2-5. matched current parent s = t u, ages n=0..3
for kt in KTS:
    for u in DIRS:
        tgt = ray(u)
        q = Qf(tgt); q2 = mul(q, q); q3 = mul(q2, q); q4 = mul(q2, q2); q5 = mul(q4, q)
        r, e = tgt
        states, succ = {}, {}
        for n in AGES:
            s0 = initial_for_current_parent(tgt, n, kt)
            states[n] = Fn(birth(s0, kt), n)
            succ[n] = F(states[n])
        for n in AGES:
            for m in AGES:
                if m >= n: continue
                d = n - m
                # 2. graph difference
                dc = [sub(states[n][1][i], states[m][1][i]) for i in range(2)]
                pred = [scl(-coefC09 * kt * d, mul(q2, tgt[i])) for i in range(2)]
                ok2 = all(at_least(sub(dc[i], pred[i]), 6) for i in range(2)) and order(dc[0]) is not None
                # 3. parent successor difference: (n-m) kt^2 Q^4/6 (-r-2e, 2r-3e)
                ds = [sub(succ[n][0][i], succ[m][0][i]) for i in range(2)]
                v = (sub(scl(-1, r), scl(2, e)), sub(scl(2, r), scl(3, e)))
                pred3 = [scl(kt * kt * d / 6, mul(q4, v[i])) for i in range(2)]
                ok3 = all(at_least(sub(ds[i], pred3[i]), 10) for i in range(2))
                # 4. Q_s successor difference: -(n-m)(2 kt^2/3) Q^5
                dq = sub(Qf(succ[n][0]), Qf(succ[m][0]))
                ok4 = at_least(sub(dq, scl(-Fr(2, 3) * kt * kt * d, q5)), 11) and order(dq) == 10
                for nm, ok in (("graph diff c_n-c_m", ok2), ("parent successor diff (deg 9)", ok3), ("Q_s successor diff (deg 10)", ok4)):
                    if not ok or (kt == 1 and u == (1, 1) and (n, m) == (3, 1)):
                        check(f"{nm} kt={kt} u={u} (n,m)=({n},{m})", ok)
                    else:
                        PASS[0] += 1
        # 5. I_sc, Omega and the age fingerprint
        for n in AGES:
            s, c = states[n]
            I = Bdot(s, c); w = wraw(s, c)
            okI = at_least(sub(I, scl(-coefC09 * kt * n, q3)), 7)
            okW = at_least(sub(w, scl(-2 * kt, q2)), 7)
            # fingerprint 4 I/(w Q) = n + O(t): leading coefficients
            num_lead = I[6] * 4; den_lead = (w[4] * q[2])
            okFP = den_lead != 0 and num_lead / den_lead == n
            for nm, ok in (("I_sc,n = -n(sqrt3 k/6)Q^3+O(7)", okI), ("Omega_G,n = -k Q^2 + O(7)", okW), ("age fingerprint leading value = n", okFP)):
                if not ok or (kt == Fr(-2, 3) and u == (2, -1) and n == 2):
                    check(f"{nm} kt={kt} u={u} n={n}", ok)
                else:
                    PASS[0] += 1

# 6. exact orders recorded for the summary (kt=1, u=(1,0)): does the O(6) graph remainder start at 6 or 7?
tgt = ray((1, 0)); kt = Fr(1)
s0 = initial_for_current_parent(tgt, 1, kt); X1 = Fn(birth(s0, kt), 1)
q = Qf(tgt)
res = [sub(sub(X1[1][i], Cgraph(tgt, kt)[i]), scl(-Fr(1, 2) * kt, mul(mul(q, q), tgt[i]))) for i in range(2)]
print(f"INFO  age-1 graph remainder on (t,0), kt=1: first orders {order(res[0])},{order(res[1])}; "
      f"t^{order(res[0])} coeffs ({res[0][order(res[0])]}, {res[1][order(res[0])]})")

print(f"\n{PASS[0]} PASS, {FAIL[0]} FAIL  (NT={NT}; kt in {[str(k) for k in KTS]}; dirs {DIRS}; ages {AGES})")
sys.exit(0 if FAIL[0] == 0 else 1)
