# RTG_TRIADIC_BIRTH_LIFT_DSN_v1.6

**Title:** RTG Triadic Birth-Lift Study — Scientific Ledger  
**Date:** 5 October 2026  
**Scope:** Integrate the accepted T-6s/t/u successor scope with the recovered T-6 orientation-normalization correction, explicit phase-model contracts, narrowed historical diagnostics and consumer reconciliation notices.  
**Document class:** Technical scientific ledger  
**Document status:** ADOPTED — v1.6 owner release issued on 5 October 2026 at the user/project owner's instruction to update this DSN. Scientific content is the revision-editor-accepted r4.2 candidate; only release-state metadata is changed. Consumer reconciliation remains pending.  
**Supersedes:** `RTG_TRIADIC_BIRTH_LIFT_DSN_v1_5.md` as the designated Triadic owner. Its exact bytes remain preserved as historical evidence.  
**Companion documents:** `RTG_PROGRAMME_OVERVIEW_v1_2.md`; `RTG_ONTOLOGICAL_FOUNDATIONS_v0_8.md`; `RTG_DYADIC_OSCILLATOR_DSN_v6_4_10.md`; `RTG_GENESIS_GEOMETRY_DSN_v2_8_4.md`; `RTG_OPEN_M_DSN_v0_6.md`; `RTG_DISCRETE_GENESIS_DSN_v2_12_13.md`; `RTG_RRF_REPRESENTATION_REGISTRY_v0_6.md` (convention/reference only). Proof imports are identified separately in §7.  
**DSN Methodology:** Adopted `DSN_METHODOLOGY_v1_3.md`, bounded migration: revised blocks use its grammar and claim lifecycle; unchanged v1.2-era blocks retain their former forms and grades. Full-document migration is not asserted.  
**Status summary:** T-6s/t/u successor mathematics remains unchanged from reviewed r3. The recovered T-6c2/T-6e producers establish an orientation-output normalization correction: T-6d's root variable is retained, T-6e's raw-determinant extraction is retained, and downstream uses that treated the raw increment as the normalized orientation rate are narrowed to historical executed-model records. The former safety-wedge/no-basin/phase-steering obstruction chain is not a current corrected-model result. T-6j2 is PARTIAL with only its historical root-closed torsional excursion retained; T-6m retains its exact reference quarter-turn and producer-frame forcing polynomial, not the wedge obstruction. The 96:1 coefficient comparison is bookkeeping until source/model correspondence is proved.  
**Release base:** revision-editor-accepted r4.2 candidate, SHA-256 `420eaf3e0b98ee150d4a44de805480ae05764f6bdcac753a9c73e14e0e5a9bf0`. Prior adopted owner: `RTG_TRIADIC_BIRTH_LIFT_DSN_v1_5.md`, SHA-256 `07e9f00b818950c70d3e51e8f3b65fd1e79922074211d0f0b20d400f8c45b735`. Intermediate drafts remain in the preserved evidence/history.  
**Maintaining co-owner:** ChatGPT. Exact r4.2 revision-editor acceptance and peer concurrence are recorded in the preserved review-closure receipt. The user's subsequent instruction to update Triadic authorizes this owner release; the separate adoption/release record identifies that instruction and both hashes.  
**Adoption record:** `records/OWNER_ADOPTION.json`; human-readable release record: `records/RELEASE_RECORD.md`. Consumer acceptance is not implied.  
**Evidence location:** the complete accepted package is preserved under `evidence/accepted_r4_2/`; inherited relative script/input/evidence paths in §8 are resolved from that package root unless another archive is explicitly named. Historical package statuses retain their original dates and are not the current owner-selection record.  
**Programme tier:** Tier 3 — Continuous Programme, conditional on the selected generator; no maturity regrade.  
**Preservation boundary:** The accepted r4.2 scientific statements, equations, coefficients, proof grades, all 49 RIDs and their replacement relations, CN-01–CN-05 content, primary certificate and other accepted evidence are unchanged. Release-state metadata is currentized, with a new release-history entry; all pre-existing version-history bodies remain immutable. No mathematical result, numerical campaign, physical selection or completed consumer reconciliation is added by publication.  

## Local Tag Aliases

| Local alias | Expands to | Used for |
|---|---|---|
| `[ALG diagnostic]` | `[ALG]` `[scope: diagnostic]` | algebraic extraction used as a diagnostic, not a standalone theorem |
| `[NUM diagnostic]` | `[NUM]` `[scope: diagnostic]` | numerical result used as a diagnostic sweep |
| `[ALG/NUM synthesis]` | `[ALG]` co-interpreted with `[NUM]` | combined algebraic/numerical synthesis result |

`[DEF]` Revised imports/exports in this release use canonical forms from `DSN_METHODOLOGY_v1.3`. The table above documents retained v1.5 aliases, not a new proof-grade system; inherited mixed-tag blocks await their separate migration.
`[DEF]` `[COR]` records a correction, not its replacement proof grade. Revised conclusions carry their own status; source availability, execution, review and adoption remain separate metadata.

---

## §1. Current Canonical State {#sec-1-canonical-state}

`[DEF]` The study concerns the continuous $2\to3$ birth family, scoped $K_3/K_4$ return models, and diagnostic phase/escape constructions. This release does not select a complete physical birth law, an independent-orientation physical carrier, or a discrete TDR-G bridge.

`[ALG]` `[scope: coefficient bookkeeping; correspondence OPEN]` T-1 retains the isolated quartic pump coefficient $+Q_s^2/4$ and the historical full-return records retain $-24Q_s^2,-24Q_c^2$. The numerical ratio $24/(1/4)=96$ is exact, but same-generator/mode/observable/time-block/extraction correspondence has not been established. The global-explosiveness inference from T-1 alone is withdrawn; the 96:1 comparison is not used as a current same-system dominance theorem (§6.1, SG-1).

`[COR]` `[ALG]` `[scope: diagnostic orientation convention]` Recovered T-6c2/T-6e producers establish
$$Q_sQ_c-I_{sc}^2=\Omega^2,\qquad \omega_{\rm raw}=-\frac{\Omega}{\sqrt3},\qquad \Delta\Omega=-\sqrt3\,\Delta\omega_{\rm raw}.$$
T-6d's root convention is retained. T-6e's raw-determinant extraction is retained. T-6f/h/i/i2/k/k2/l/j results that used the determinant increment as the normalized orientation rate are historical records of that executed model, not current corrected-model sector/wedge/basin results (§§6.4–6.11, §6.18, SG-18).

`[ALG]` `[scope: corrected leading orientation model]` For the corrected coefficient extension, $K=1$ is tangent and the historical leading torsion root $x_*$ has no real corrected replacement at that order. The old $x_*$ polynomial remains historical algebra of the executed mis-scaled diagnostic; no corrected finite-$u$, $r$-dependent or global basin theorem is asserted.

`[NUM]` `[scope: historical author-reported root-closed session]` T-6j2's prior $0/120$ safe/fatal classification is withdrawn. The surviving observation is a root-closed torsional excursion from the tested initial wedge to reported maxima near $99^\circ$–$101^\circ$; the terminal event identity is unresolved because the session script/log is unavailable. This does not bound an interior $K<1$ model (§6.13).

`[ALG]` `[scope: fixed-direction reference]` T-6m retains $\Phi_{sc}(0)=-\pi/2$ and the producer-frame turn polynomial/root under its recorded ansatz. Its wedge/$\sim15\times$ obstruction and physical-route closure are withdrawn. T-6s/t/u successor statements remain as in §§6.15–6.17.

`[OPEN]` The physical residual, retention law, source-operator bridge, corrected independent-orientation carrier, 96:1 model correspondence and complete post-birth dynamics remain unresolved. Consumer notices CN-01–CN-05 require Genesis/OPEN-M scientific reconciliation against this adopted release; consumer acceptance remains pending.

`[DEF]` The active queue is T-6r (corrected orientation-model/domain completion), T-6q, T-6m2, T-6n and the remaining T-6o question. No new numerical sweep is required for this r4 model-contract correction.

## §2. Active Frontier / OPEN Registry {#sec-2-open-registry}

### Priority ordering

**Seam/correction state.** T-6s/t/u retain the r3 successor statements. The orientation-normalization subtask is closed at `[ALG]` diagnostic scope by the recovered producer convention and fresh extraction outputs. This does not close the corrected independent-orientation dynamics, physical $K<1$ carrier, 96:1 correspondence or consumer acceptance.

**Non-blocking triadic completion queue:**
1. **T-6r — Corrected orientation-model/domain completion.** Specify the admissible carrier for any $K<1$ independent-orientation diagnostic, the corrected $\dot\Omega$, finite-$u/r$ dynamics, event taxonomy and any new basin test before restoring sector/safety claims.
2. **T-6q — Phase-convention and sign-sector table.** Complete sign-sector and branch-extension bookkeeping across the now-separated root and independent-orientation models.
3. **T-6m2 — Race-A correction to the producer-frame birth-torsion turn.** Retain as a local robustness calculation; it no longer controls a validated safety-wedge obstruction.
4. **T-6n / T-6o —** continue their separately scoped continuation/global-geometry obligations.

**Handoff queue** — owner release issued; consumer reconciliation pending:
1. Send CN-01–CN-05 to Genesis/OPEN M; CN-05 withdraws obsolete sector/wedge/no-basin/obstruction imports rather than rescaling them.
2. Send the typed planar convention proposal to RRF: $B_T^{\rm plane}=2B_G$, $Q_T=2Q_G$, $I_T=2I_G$, $\Omega_T=-\sqrt3\,\omega_{\rm raw}$ for identified planar vectors only. No birth/generator/apex bridge is implied.
3. Programme/OFN pass two follows technical consumer reconciliation.

---

**T-6s — In-plane conjugate-pair result** [RID: TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY]

Source v1.5 status: CLOSED `[ALG]`; the reviewed v1.6 scope correction is now adopted.  
The exact operator formula is $\|H_{\rm total}\|_B=|1-g_2|$. The no-gain statement requires $0\le g_2\le2$ and the declared source construction. The unit-direction identity is $W(J_Qs)/W(s)=i$; it is not $W(c_0)/W(s)=i$. No energy-level, incoherent or UV conclusion is added. See §6.15.

---

**T-6t — Mode-chirality count / Thread-4** [RID: TRIAD-ALG-T6T-JACOBI-MODE-SIGNS]

Source v1.5 status: CLOSED `[ALG]`; the reviewed v1.6 label/carrier clarification is now adopted.  
The three mode labels have independent sign choices in the stated node-mediated Jacobi construction. The result is not a physical transverse-carrier embedding or an independently specified source normalization. T-6u's explicit diagnostic is evaluated in §6.17; an operator-source bridge remains OPEN.

---

**T-6u — Policy-parametric primitive apex diagnostic** [RID: TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC]

Source v1.5 status: CLOSED `[ALG]` [scope: diagnostic]. Revised v1.6 statement: ADOPTED at the reviewed diagnostic scope.  
For the two reference policies and two typed leading numerator readings in §6.17, the largest diagnostic ratio is $\sqrt{14}/16$ and the least shortfall against $\sqrt2$ is $16/\sqrt7>6$. Vector and increment readings are not interchangeable seeded states.  
Custody: Triadic owns this ratio/diagnostic statement; Genesis owns the cited source polynomial and seeding records. `apex_ratio_setup.py`, if recovered, is consumer-side verification, not a transfer of the result owner. OPEN M remains a consumer.  
Evidence: `triad_t6u_apex_source_v1_6.py`, 47 exact assertions in the reviewed primary suite, plus the separate r2 point-use checks; exact execution records in §8. The recovered original eight-check script was also rerun unchanged as historical evidence, not as proof of the successor scope. The reviewed result/artifact identities are registered by this owner release; no new identity is added beyond the accepted candidate.  
Remaining: physical source-amplitude identification, finite-domain/remainder control if a finite-amplitude verdict is desired, and consumer synchronization. Exact-candidate review and owner publication are complete; no scientific OPEN is closed merely by publication.

---

**PARTIAL T-6m — Fixed-direction reference birth audit** [RID: TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN]

`Replaces:` `TRIAD-ALG-T6M-BIRTH-OBSTRUCTION` for current use. The module-level historical RID `TRIAD-OPEN-T6M` remains preserved in the base/history.

Status: **PARTIAL** `[ALG diagnostic]` `[scope: fixed-direction reference initialization $\Phi_{sc}(0)=-\pi/2$]`  
Retained: the exact reference quarter-turn, $(\mu_0,\nu_0)=(0,-1)$ in the T-6d normalized root convention, and the recorded producer-frame $r=0$ forcing polynomial/root under its stated ansatz.  
Withdrawn: the current safety-wedge comparison, the approximately $15\times$ separation, and any claim that phase steering closes the physical continuous birth route. Those deductions depended on the downstream orientation-rate mismatch corrected in §6.18.  
Open: physical residual/retention/event identification, corrected finite-$u/r$ orientation dynamics, and T-6m2's local apex correction.

---

**PARTIAL T-6j2 — Historical root-closed torsional excursion** [RID: TRIAD-NUM-T6J2-ROOT-CLOSED-EXCURSION]

`Replaces:` `TRIAD-NUM-T6J2-NO-BASIN` for current use. The historical no-basin proposition and `TRIAD-OPEN-T6J2` record remain preserved in Appendix B/history.

Status: **PARTIAL** `[NUM]` `[scope: author-reported historical root-closed session; normalization-conditional; terminal event unresolved]`  
Retained observation: the original operator reports torsional excursions from the tested initial wedge to $\theta_{\max}\approx99^\circ$–$101^\circ$ in the root-reclosed $K\equiv1$ session model.  
Withdrawn: $0/120$ safe/fatal classification, no-safe-basin conclusion, interpretation as a $K=1$ proxy for interior $K<1$ dynamics, and the reported $59^\circ$–$60^\circ$ terminal angle as a certified Plücker impact. The session script/event log was never archived, so the terminal event cannot be reconstructed.  
Scope: historical diagnostic evidence only; no monotone bound, basin theorem or current export permission.

---

**OPEN T-6m2 — Race-A apex correction to the producer-frame turn polynomial** [RID: TRIAD-OPEN-T6M2]

Status: ACTIVE | low-priority local robustness check downstream of T-6m  
Question: How do the recorded $r^1/r^2$ apex terms shift the producer-frame $\Delta I_{sc}$ turn under the same declared ansatz?  
Current state: At $r=0$, the retained producer-frame polynomial has $Q_s^{\rm turn}=(2\sqrt7-1)/6\approx0.71525$. Race-A has $r_0=\sqrt{7/1024}Q_s^{3/2}$ and $\varrho_0=\sqrt{7/1024}Q_s$. This is no longer a safety-wedge or physical-route obstruction test.  
Closure criterion: compute and record the corrected local turn in its own producer/model convention, with no automatic comparison to historical $x_*$, no-basin, or route-closure claims.

---

**OPEN T-6n — Branch-switching continuation** [RID: TRIAD-OPEN-T6N]

Status: ACTIVE  
Question: Can a branch-switched continuation from the root-contact representation ($\Omega\to-\Omega$) generate an admissible trajectory, and how does any independent-orientation model define its own continuation?  
Current state: T-6d2 shows $\dot W^2 < 0$ at contact — naive flip is rejected. A complete branch-switching theorem remains `[OPEN]`. Annihilation may not be promoted until this is resolved.

---

**OPEN T-6o — Full-system stability of the isolated $r^2$ equilibrium** [RID: TRIAD-OPEN-T6O]

Status: ACTIVE after r4 correction  
Retained: the isolated $r^2$ equilibrium exists algebraically in the root-normalized channel.  
`[COR]` The former closed sub-item—excluding full-system stability because $\nu^*/\mu^*$ lay outside the historical $x_*$ wedge—is reopened. That exclusion depended on the mis-scaled torsion threshold.  
Question: Does any nearby attracting continuation exist in a correctly specified full orientation/amplitude model?  
Closure criterion: analyze the equilibrium in a model whose orientation variable, carrier, rate and finite-$u/r$ dynamics are explicitly typed. No conclusion follows from the historical $x_*$ comparison.

---

**CLOSED T-6p — Consumer export protocol, historical form superseded** [RID: TRIAD-EXPORT-PROTOCOL-2]

`Replaces:` `TRIAD-EXPORT-PROTOCOL-1` for current use.  
Status: **CLOSED** `[DEF]` `[scope: export protocol]`  
Current rule: consumers may import only adopted, currently scoped Triadic claims. Historical safety-wedge, phase-steering, no-basin and route-obstruction exports are withdrawn from current use and require CN-05 reconciliation. See §6.14/§7.  
The historical protocol remains in the version record; no consumer acceptance is implied by this replacement.

---

**OPEN T-6r — Corrected orientation-model/domain completion** [RID: TRIAD-OPEN-T6R]

Status: ACTIVE  
Question: What state carrier and full corrected evolution, if any, support an independent-orientation $K<1$ diagnostic after the T-6e output-type correction?  
Current state: the normalization blocker is closed (§6.18). In the corrected coefficient extension $K=1$ is tangent, so the historical inward/outward sector map and no-basin programme are not current-model evidence. Two actual planar vectors satisfy the Gram identity and hence $K=1$ in the normalized convention; a physical or diagnostic $K<1$ carrier requires explicit enlargement/relaxation.  
Closure criterion: specify the carrier, corrected $\dot\Omega$, finite-$u/r$ vector field or exact map, event guards and model/observable transport. Only then decide whether a new basin/escape calculation is scientifically meaningful. No rescaling of historical trajectories is permitted.

---

**OPEN T-6q — Sign-sector and model-action table after normalization** [RID: TRIAD-OPEN-T6Q]

Status: ACTIVE  
Question: How do branch sign, folded/unfolded angle and any independent-orientation extension transform after distinguishing $\Omega$ from $\omega_{\rm raw}$ and separating $M_{\rm root}$ from $M_{\rm orient}$?  
Current state: the old mirrored-$x_*$ heuristic is historical and is not a current threshold. T-6m's reference angle remains exact, but no corrected $\sigma=-1$ full-flow theorem is installed.  
Closure criterion: produce a typed sign/action table for the chosen corrected model, including the state carrier, $\dot\Omega$, boundary definition, and comparison observables. Do not reuse historical sector maps by reflection alone.

---

Module records (current use versus historical evidence):

- **T-1** :: `[ALG]` `[scope: limited]` ✓ — quartic secular pump channel identified; inference to global explosiveness withdrawn/not established; 96:1 same-object correspondence OPEN.
- **T-2b** :: `[ALG]` `[scope: rigid diagonal birth gauge / implemented loading family]` ✓ — diagonal birth gauge initial lift positive; Healing Valley obstruction removed at the initial-lift level.
- **T-4h** :: `[NUM]` ✓ — escape threshold $Q_{s,*}^{\rm escape} \approx 0.6594477844$.
- **T-6a0** :: `[ALG diagnostic]` ✓ — one-step diagonal coordinate audit; $O(r)$ parity-breaking channel exposed.
- **T-6a1** :: `[ALG diagnostic]` ✓ — six-step diagonal return; $r^1$ channel survives full cycle.
- **T-6a2** :: `[ALG diagnostic]` ✓ — orthogonal Race-A axis reduction.
- **T-6b** :: `[NUM diagnostic]` ✓ — orthogonal ODE; boundary decay; no positive fixed point.
- **T-6c** :: `[ALG diagnostic]` ✓ — generalized planar reduction preserving $I_{sc}, \omega_{sc}$.
- **T-6c2** :: `[ALG diagnostic]` ✓ — cross-phase synchronous extraction $\Delta I_{sc}$.
- **T-6d** :: `[NUM diagnostic]` ✓ — retained root-closed generalized ODE; all tested fixed-branch seeds reached the root/radicand guard. No independent-orientation sector claim is implied.
- **T-6d2** :: `[NUM diagnostic]` ✓ — $\dot W^2 < 0$ at contact; naive branch flip rejected.
- **T-6e** :: `[ALG diagnostic]` ✓ — raw determinant extraction retained; downstream identification of its output with the normalized $\Omega$ rate corrected by `TRIAD-ALG-T6E-ORIENTATION-NORMALIZATION`.
- **T-6f_v2** :: `[NUM]` `[scope: historical executed mis-scaled model]` — trajectory record retained; current runaway interpretation withdrawn.
- **T-6g** :: `[ALG diagnostic]` ✓ — free-$Q_c$ leading large-$u$ squares $A_2 \le 0$, $B_1 \le 0$.
- **T-6h_v2** :: `[NUM]` `[scope: historical executed mis-scaled model]` — run record retained; not current corrected-model boundary evidence.
- **T-6i/T-6i2** :: `[NUM]` `[scope: historical executed mis-scaled model]` — old inward/outward sectors and radial arc retained only as executed-model records; current interpretation withdrawn.
- **T-6j** :: `[NUM]` `[scope: historical executed mis-scaled model]` — basin-search output retained as provenance; no current basin conclusion.
- **T-6k/T-6k2** :: `[NUM]` `[scope: historical executed mis-scaled model]` — steering percentages retained only as historical outputs.
- **T-6l** :: historical algebra retained; old $x_*$ threshold withdrawn from current use. Current corrected leading result: [RID: TRIAD-ALG-T6L-NORMALIZED-TORSION-SIGN].
- **T-6s** :: `[ALG]` [scope: adopted successor; original scientific restrictions retained] [RID: TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY] — exact coherent norm $|1-g_2|$, no gain only on $0\le g_2\le2$; signed child is not the unit direction. Historical predecessor verdict retained in Appendix B.
- **T-6t** :: `[ALG]` [scope: adopted successor; original scientific restrictions retained] [RID: TRIAD-ALG-T6T-JACOBI-MODE-SIGNS] — three independently signable mode labels; no physical transverse embedding established. Historical predecessor verdict retained in Appendix B.
- **T-6u** :: `[ALG]` [scope: adopted successor; original scientific restrictions retained] [RID: TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC] — four typed leading diagnostics, minimum shortfall $16/\sqrt7>6$; not a HINDEX bound. Historical predecessor verdict retained in Appendix B.

---

## §3. Scope Guards {#sec-3-scope-guards}

**[SG-1]** T-1's $+Q_s^2/4$ pump coefficient and the historical $-24Q_s^2$ return coefficient are retained as scoped calculations. The arithmetic ratio 96 is coefficient bookkeeping; common-generator/mode/observable/time-block/extraction correspondence remains OPEN.  
Violation: using 96:1 as a proved same-system stability/healing theorem or as the reason global explosiveness is false.

**[SG-2]** $Q_{s,*}^{\rm escape}\approx0.6594477844$ belongs to the reduced Race-A model and is not a simple algebraic pump/healing crossing.  
Violation: deriving escape from coefficient signs alone.

**[SG-3]** Distinguish phase models. `M_root` derives $\Omega=\sigma\sqrt{Q_sQ_c-I^2}$ and therefore has $K\equiv1$. `M_orient` treats orientation as an independent diagnostic coordinate and requires its own typed $\dot\Omega$ and carrier. `M_{j2}^{\rm hist}` is the historical root-reclosed session model. Results may not be moved between them without an explicit transport.  
Violation: describing $K<1$ trajectories as trajectories of the root-closed four-variable state.

**[SG-4]** T-6f/h/i/i2/k/k2/l/j are preserved as records of the executed model that used the T-6e raw determinant increment as the normalized orientation rate. They are not evidence for the normalization-corrected orientation dynamics.  
Violation: rescaling their trajectories, sectors, wedge widths or basin outcomes into the corrected model.

**[SG-5]** T-6d2's $\dot W^2<0$ contact diagnostic rejects only its naive branch flip; it is not a complete branch-switching or annihilation theorem.  
Violation: promoting contact to annihilation without T-6n.

**[SG-6]** The isolated $r^2$ cross-phase equilibrium is retained algebraically. The old argument against full-system stability through $x_*$ is historical-model reasoning and is not a current corrected-dynamics proof.  
Violation: claiming either stability or instability of the corrected full system from that isolated equilibrium alone.

**[SG-7]** The historical $22^\circ$ radial arc, $5.5^\circ$ wedge and $x_*$ threshold are properties/algebra of the executed mis-scaled diagnostic. They are not current corrected-model safety boundaries.  
Violation: exporting them as current necessary/sufficient escape criteria.

**[SG-8]** T-6j/T-6j2 historical trajectory records do not establish a current no-safe-basin theorem. T-6j2's terminal event identity is unresolved.  
Violation: citing $0/120$ or fatal/impact labels as current evidence for a corrected or interior model.

**[SG-9]** T-6m retains the convention-independent reference quarter-turn $\Phi_{sc}(0)=-\pi/2$ and its producer-frame forcing polynomial. It no longer carries the historical wedge obstruction or a physical-route closure.  
Violation: using the exact angle to restore the withdrawn wedge/$\sim15\times$ argument.

**[SG-10]** Dyadic/Genesis birth imports retain their source premises and programme generator-selection firewall.  
Violation: treating imported coefficients or reference policies as unconditional physical laws.

**[SG-11]** Plücker/root contact is model-specific and is not annihilation. Branch continuation remains OPEN under T-6n.  
Violation: identifying a diagnostic boundary with a physical endpoint.

**[SG-12]** Orientation symbols are typed. In the recovered Triadic planar convention, $Q_sQ_c-I^2=\Omega^2$ and $\omega_{\rm raw}=-\Omega/\sqrt3$. The T-6e output is $\Delta\omega_{\rm raw}$; the normalized rate is $\Delta\Omega=-\sqrt3\Delta\omega_{\rm raw}$.  
Violation: feeding the raw determinant increment directly into the normalized orientation equation or silently rescaling old numerical outputs.

**[SG-13]** Consumer exports follow the current successor/correction claims only. The historical safety wedge, no-basin result and phase-steering obstruction are not current Genesis constraints.  
Violation: using T-6p's historical export table after the r4 correction.

**[SG-14]** T-6j2's current proposition is the scoped historical root-closed torsional excursion, not no-safe-basin. Its session code/log is unavailable.  
Violation: inferring the terminating event, safe/fatal classification or interior-basin statement from the surviving observation.

**[SG-15]** T-6s uses a chosen coherent source construction and real weight; $\|H_{\rm total}\|_B=|1-g_2|$ and the no-gain bound assumes $0\le g_2\le2$. A unit quarter-turn is not the policy-scaled child.  
Violation: unrestricted-weight or universal physical-source use.

**[SG-16]** T-6t is a Jacobi mode-label/sign statement, not a physical third-direction theorem. The distinct $d$-mode block is retained, but a physical transverse/UV embedding requires its own map and metric.  
Violation: converting row orthogonality into a physical source direction.

**[SG-17]** T-6u compares four specified leading diagnostics. The vector seed and increment-channel diagnostic are different objects; the $>6$ shortfall is not a finite-amplitude, HINDEX, arbitrary-$\kappa$ or universal-source bound.  
Violation: promoting the table beyond its stated leading diagnostic scope.

**[SG-18]** A six-step block composes the declared update; it is not an exact nonlinear recurrence or a reset operation. Passive reference changes transport state, dynamics, observables and comparison links. Projection, averaging and algebraic reclosure are separate operations. Genesis's admissible $O(\|s\|^5)$ child family is not automatically the raw Dyadic residual.  
Violation: interpreting healing as phase erasure, reclosure as a lossless coordinate change, or a reference change/residual alone as a birth/correction impulse.

---

## §4. Layer Routing {#sec-4-layer-routing}

$$\text{Dyadic fracture state} \xrightarrow{\Phi_{2\to3}} K_3\text{ birth} \xrightarrow{K_4\text{ back-reaction}} \text{typed diagnostic models} \xrightarrow{\text{phase/source analysis}} \text{consumer constraints}$$

| Layer | Object | Current tool / status |
|---|---|---|
| Birth kinematics | $Q_c(0),\kappa$, signed reference child | Leading $\Phi_{2\to3}$ family; physical residual/event/retention OPEN |
| $K_3$ dynamics | T-1 pump coefficient; historical return coefficients | Separate scoped calculations; 96 common-model correspondence OPEN |
| $M_{\rm root}$ | $(Q_s,Q_c,I,r)$ with $\Omega=\sigma\sqrt{Q_sQ_c-I^2}$ | T-6d root model; $K\equiv1$ by definition |
| $M_{\rm orient}^{\rm hist}$ | independent orientation with determinant increment used as normalized rate | Historical T-6f/h/i/k/l/j executed model; current interpretations withdrawn |
| $M_{\rm orient}^{\rm corr}$ | independent normalized $\Omega$ with $\dot\Omega=-\sqrt3\dot\omega_{\rm raw}$ | algebraic corrected coefficient extension only; no current numerical campaign or physical $K<1$ carrier |
| $M_{\rm j2}^{\rm hist}$ | root-reclosed $K=1$ session sweep | historical torsional excursion only; event log absent |
| Consumers | Genesis / OPEN M / Programme / OFN / RRF | CN-01–CN-05 scientific reconciliation against adopted v1.6; consumer acceptance pending |

Boundary notation:
- $\mathcal B_{\rm root}: Q_sQ_c-I^2=0$ — root singularity/contact condition of the root-closed representation.
- $\mathcal B_K: K=1$ — ambient boundary of an independent-orientation disk model; it is not identical to $\mathcal B_{\rm root}$ as a set in an enlarged diagnostic state space. In the corrected coefficient extension the vector field is tangent to $\mathcal B_K$.

Routing rules:
- Do not infer current corrected dynamics from T-6f/h/i/k/l/j trajectory records (SG-4, SG-12).
- Do not export the historical safety wedge/no-basin/phase-steering verdict (SG-7, SG-13, SG-14).
- T-6m exports only its fixed-direction reference facts, not the wedge obstruction (SG-9).
- Birth imports and T-6u retain SG-10/SG-17.
- No layer implies annihilation without T-6n (SG-11).
- Reference changes and projections obey SG-18.

<!-- AI_CONTEXT_CORE_END -->

---

## §5. High-Risk Claims Ledger {#sec-5-high-risk}

| Claim | Valid current form | Forbidden overclaim | Section |
|---|---|---|---|
| $K_3$ pump / 96 ratio | pump and historical return coefficients retained; 96 is exact coefficient bookkeeping, common-model correspondence OPEN | same-system healing dominance or global-stability theorem | §6.1, SG-1 |
| Race-A escape threshold | $Q_{s,*}^{\rm escape}\approx0.6594477844$ in its reduced model | transferring it to another return/state contract without bridge | §6.1, SG-2 |
| Root model | $\Omega=\sigma\sqrt{Q_sQ_c-I^2}$, hence $K\equiv1$ | calling $K<1$ trajectories root-model trajectories | §6.4, SG-3 |
| T-6e output | raw determinant $\omega_{\rm raw}$ and its increment | treating $\Delta\omega_{\rm raw}$ as $\Delta\Omega$ | §§6.7, 6.18, SG-12 |
| Historical sector/wedge results | records of the executed mis-scaled diagnostic only | current corrected-model sector, wedge, basin or obstruction theorem | §§6.7–6.11, SG-4/7 |
| Corrected $K=1$ boundary | $\dot K=0$ on $K=1$ in the corrected coefficient extension | global stability/escape or physical-$K<1$ theorem | §6.18 |
| Corrected leading torsion | sign-definite leading large-$u$, $r=0$ coefficient; no real root at that order | finite-$u/r$ global phase-flow theorem | §§6.9, 6.18 |
| T-6j2 | historical root-closed torsional excursion, terminal event unresolved | no-safe-basin, fatal/impact classification or interior bound | §6.13, SG-14 |
| T-6m | exact reference quarter-turn and producer-frame forcing polynomial/root | current wedge/$\sim15\times$ obstruction or physical-route closure | §6.12, SG-9 |
| T-6g | fixed-expression radial square identities | unchanged interpretation inside corrected full orientation dynamics | §6.8 |
| T-6s | $|1-g_2|$ and bounded no-gain interval under the chosen coherent construction | arbitrary-weight/universal source claim | §6.15, SG-15 |
| T-6t | three mode-label signs | physical third-direction/UV-source inference | §6.16, SG-16 |
| T-6u | four typed leading seed diagnostics | HINDEX, finite-amplitude, arbitrary-source or cascade theorem | §6.17, SG-17 |
| Annihilation | OPEN; contact is not sufficient | promotion from any diagnostic boundary alone | SG-11 |

---

## §6. Main Scientific Ledger {#sec-6-ledger}

### §6.1 Birth Kinematics and $K_3$ Order Separation `[ALG / mixed]` {#sec-6-1-birth}

`[DEF]` **Birth map.** $\Phi_{2\to3}$ denotes the declared continuous birth family; the complete physical event remains OPEN.

`[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.3 #sec-6-3-triad | RID unavailable] **Leading birth kinematics:**
$$Q_c(0)=\kappa^2Q_s^3+O(Q_s^4),\qquad u(0)=\kappa^2Q_s^2+O(Q_s^3).$$

`[ALG]` [scope: structure] Shear reference $\kappa=-2\sqrt3/3$; recoil reference $\kappa=-1/2$. No physical policy preference is selected.

`[ALG]` `[scope: limited]` **T-1 — isolated quartic pump coefficient.** The scoped extraction contains
$$+\frac14Q_s^2.$$
This does not establish global $K_3$ explosiveness.

`[ALG]` `[scope: historical return coefficient record]` A separate recorded return calculation contains
$$-24Q_s^2,\qquad -24Q_c^2,$$
so the coefficient magnitude ratio $24/(1/4)=96$ is exact.

`[COR]` **Correspondence status.** The ledger no longer uses 96:1 as proof that one common system's healing dominates its pump. A passive near-identity chart with identity linear part cannot reverse the cubic-return sign by itself; the missing correspondence could instead involve a different generator, lift, projection, mode or observable. Until that map is supplied, the coefficient comparison is bookkeeping and the global-explosiveness inference from T-1 is simply withdrawn/not established.

`[ALG]` `[scope: rigid diagonal birth gauge / implemented loading family]` **T-2b — Diagonal birth gauge.** Under its stated gauge,
$$d_\rho=-\frac r{\sqrt{21}},\quad d_\eta=\frac{2r}{\sqrt{21}},\quad d_z=\frac r{\sqrt3},\quad Q_d=r^2.$$
Its source/embedding interpretation remains separate from T-6t/CN-01.

`[NUM]` **T-4h — Finite-$Q_d$ escape threshold.** $Q_{s,*}^{\rm escape}\approx0.6594477844$ in the reduced Race-A model.

### §6.2 Vertical and Diagonal Apex Back-Reaction `[ALG diagnostic / mixed]` {#sec-6-2-backreaction}

`[ALG diagnostic]` **Vertical apex checksum** (under $d_\rho=d_\eta=0$, $d_z=z$):
$$\Delta Q_s^{(d^2)} = -Q_s Q_d, \qquad \Delta Q_c^{(d^2)} = -Q_c Q_d.$$

`[ALG diagnostic]` **Diagonal apex back-reaction** (Race-A diagonal representative):
$$\Delta Q_s^{(d^2)} = -Q_s Q_d - 2I_{sd}^2, \qquad \Delta Q_c^{(d^2)} = -Q_c Q_d - 2I_{cd}^2.$$

`[ALG diagnostic]` **Phase-mapped fracture closure** (using $r=\sqrt{Q_d}$):
$$\Delta Q_s^{(d^2)} = -Q_s Q_d(1+2\cos^2\Phi_{ds}), \qquad \Delta Q_c^{(d^2)} = -Q_c Q_d(1+2\cos^2\Phi_{dc}).$$

`[NUM diagnostic]` **Hybrid C4 dominance threshold.** $K_3$ pump $+$ C3 phase-mapped fracture sinks: $Q_{s,\rm dom}^{C4} \approx 0.767427063$. Diagnostic of the stitched hybrid model; not a final $K_4$ theorem.

### §6.3 Six-Step $K_4$ Return Map `[ALG diagnostic / mixed]` {#sec-6-3-return}

`[ALG diagnostic]` **T-6a1 — Six-step diagonal return.** Planar returns decompose as
$$\Delta Q_i=\Delta Q_i^{(0)}+r\Delta Q_i^{(1)}+r^2\Delta Q_i^{(2)}.$$
The $r^1$ parity-breaking channel survives the full six-step cycle. Apex return begins at $r^2$:
$$\Delta Q_d=r^2D_2+r^3D_3+r^4D_4.$$

`[ALG]` **Apex governor coefficient:**
$$\boxed{D_4=-32},\qquad \boxed{r^4D_4=-32r^4}.$$
`[COR]` An inherited point-of-use line wrote the complete term as though it were the coefficient. The numerical governor itself is unchanged.

`[ALG diagnostic]` **Apex $r^3$ sign threshold.** The $r^3$ coefficient is positive when $u=Q_c/Q_s>961/75\approx12.8133$; this is necessary, not sufficient, for positive apex forcing.

`[ALG diagnostic]` **T-6a2 — Orthogonal Race-A axis reduction** ($I_{sc}=0$):
$$\Delta Q_s=6\sqrt3\sqrt{Q_c}Q_s^{3/2}-6Q_cQ_s-24Q_s^2-\frac{6\sqrt{42}}7Q_s^{3/2}r-\frac{26}7Q_sr^2,$$
$$\Delta Q_c=-6\sqrt3Q_c^{3/2}\sqrt{Q_s}-24Q_c^2-6Q_cQ_s+\frac{30\sqrt{14}}7Q_c^{3/2}r-\frac{114}7Q_cr^2,$$
$$\Delta Q_d=-\frac87(4Q_c+17Q_s)r^2+\frac2{21}(15\sqrt{14}\sqrt{Q_c}-31\sqrt{42}\sqrt{Q_s})r^3-32r^4.$$

`[NUM diagnostic]` **T-6b — Orthogonal-axis ODE.** Historical tested trajectories decayed toward the near-origin boundary; no positive finite fixed point was found in this slice. This does not resolve the orientation-normalization correction downstream.

### §6.4 Generalized T-6d Root-Model Ledger `[ALG diagnostic / mixed]` {#sec-6-4-ode}

> **[SG-3 applies]** **[SG-9 applies]** **[SG-12 applies]**

`[DEF]` **$M_{\rm root}$ state contract.** State $(Q_s,Q_c,I_{sc},r)$ with branch sign $\sigma\in\{\pm1\}$ and **derived normalized orientation**
$$\Omega=\sigma\sqrt{Q_sQ_c-I_{sc}^2}.$$
For $Q_sQ_c>0$ define $\mu=I_{sc}/\sqrt{Q_sQ_c}$, $\nu=\Omega/\sqrt{Q_sQ_c}$; then $K=\mu^2+\nu^2\equiv1$. This model therefore has amplitude dynamics but no independent radial motion in the $(\mu,\nu)$ disk.

`[DEF]` **Root-model event guards:** $Q_s=0$, $Q_c=0$, $r=0$, and
$$\mathcal B_{\rm root}:\ Q_sQ_c-I_{sc}^2=0.$$
This root singularity is not the same object as the ambient $K=1$ boundary of an independent-orientation model.

`[ALG diagnostic]` **Generalized $\Delta Q_s$: **
$$\Delta Q_s^{(0)}=-18I_{sc}^2+18I_{sc}Q_s-12\sqrt3I_{sc}\Omega-24Q_s^2+6\sqrt3Q_s\Omega-6\Omega^2,$$
$$\Delta Q_s^{(1)}=-\frac{6\sqrt{42}}7Q_s^{3/2},\qquad \Delta Q_s^{(2)}=-\frac{26}7Q_s.$$

`[ALG diagnostic]` **Generalized $\Delta Q_c$: **
$$\Delta Q_c^{(0)}=\frac6{Q_s^2}\left[-4I_{sc}^4-8I_{sc}^2\Omega^2+Q_s^2(-3I_{sc}^2+2\sqrt3I_{sc}\Omega-\Omega^2)\right.$$
$$\left.+Q_s(3I_{sc}^3-\sqrt3I_{sc}^2\Omega+3I_{sc}\Omega^2-\sqrt3\Omega^3)-4\Omega^4\right],$$
$$\Delta Q_c^{(1)}=\frac{6Q_c}{7\sqrt{Q_s}}(5\sqrt{14}\Omega-\sqrt{42}I_{sc}),$$
$$\Delta Q_c^{(2)}=\frac2{7Q_s}(-13I_{sc}^2+20\sqrt3I_{sc}\Omega-57\Omega^2).$$

`[ALG diagnostic]` **Generalized $\Delta I_{sc}$** (T-6c2 extraction in the normalized producer variable $\Omega$):
$$\Delta I_{sc}^{(0)}=\frac3{Q_s}\left[-7I_{sc}^3-3\sqrt3I_{sc}^2\Omega-7I_{sc}\Omega^2+Q_s(6I_{sc}^2-7I_{sc}Q_s+3\sqrt3Q_s\Omega+2\Omega^2)-3\sqrt3\Omega^3\right],$$
$$\Delta I_{sc}^{(1)}=\frac{-3\sqrt{42}I_{sc}^2-6\sqrt{14}I_{sc}\Omega+3Q_s(-\sqrt{42}I_{sc}+7\sqrt{14}\Omega)+7\sqrt{42}\Omega^2}{7\sqrt{Q_s}},$$
$$\Delta I_{sc}^{(2)}=-\frac{26}7I_{sc}+\frac{20\sqrt3}7\Omega.$$

`[ALG diagnostic]` **Generalized $\Delta Q_d$: **
$$\Delta Q_d^{(2)}=\frac8{7Q_s}(-17I_{sc}^2+3\sqrt3I_{sc}\Omega-17Q_s^2-4\Omega^2),$$
$$\Delta Q_d^{(3)}=\frac2{21\sqrt{Q_s}}(-31\sqrt{42}I_{sc}-31\sqrt{42}Q_s+15\sqrt{14}\Omega),$$
$$D_4=-32.$$

`[DEF]` **T-6d ODE:**
$$\dot Q_s=\Delta Q_s,\quad \dot Q_c=\Delta Q_c,\quad \dot I_{sc}=\Delta I_{sc},\quad \dot r=\frac{\Delta Q_d}{2r},$$
with $\Omega$ reclosed from the root relation at the state-evaluation step. `[COR]` This four-variable root model does not have an independent $\dot\Omega$ and must not be merged with $K<1$ independent-orientation diagnostics.

### §6.5 Cross-Phase Algebra and Isolated $r^2$ Equilibrium `[ALG diagnostic]` {#sec-6-5-isc}

`[FAIL]` **Orthogonal slice not invariant in $M_{\rm root}$.** At $I_{sc}=0$,
$$\Delta I_{sc}^{(2)}=\frac{20\sqrt3}{7}\Omega\ne0$$
for $\Omega>0$.

`[ALG diagnostic]` **Tunable chiral motor.** The $r^1$ footprint term remains
$$\Delta Q_c^{(1)}=\frac{6Q_c}{7\sqrt{Q_s}}(5\sqrt{14}\Omega-\sqrt{42}I_{sc}).$$

`[ALG diagnostic]` **Isolated $r^2$ equilibrium.** Solving $\Delta I_{sc}^{(2)}=0$ in the root-normalized algebra gives the recorded ratio and positive motor value. This is an equilibrium of one isolated channel only.

`[COR]` The previous argument that this equilibrium is $7.8\times$ outside the current torsion-safe wedge is withdrawn because the historical $x_*$ threshold belongs to the mis-scaled downstream orientation model. No full-system stability or instability conclusion follows from this equilibrium alone.

`[DEF]` **Root contact.** $\mathcal B_{\rm root}:Q_sQ_c-I_{sc}^2=0$ is a square-root/branch event in the root representation, not automatically annihilation and not identical to the ambient $K=1$ boundary of an enlarged orientation state.

### §6.6 Generalized T-6d Seed Classes `[NUM diagnostic]` {#sec-6-6-seeds}

| Class | Condition | Notes |
|---|---|---|
| Ia — perturbative orthogonal | $u \ll 3/4$, $I_{sc}=0$ | |
| Ib — perturbative nonorthogonal | $u \ll 3/4$, $I_{sc}\neq 0$ | |
| II — post-valley, $r^3$-drained | $3/4 < u < 961/75$, $I_{sc}$ varied | |
| III — $r^3$-apex-pumped | $u > 961/75$, $I_{sc}$ varied | Genesis-relevant |

`[NUM diagnostic]` **Recommended sensitive Class III seeds:**
$$(Q_s, Q_c, r) = (0.7, 9.0, 0.3), \quad (Q_s, Q_c, r) = (0.7, 15.0, 0.5).$$
Supplement, but do not replace, high-$Q_c$ stress tests. The prior chiral-heavy T-6b seeds $(u=50, 62.5)$ have $-24Q_c^2$ healing dominant — not sensitive probes of the Class III transition near $u_{r^3}$.

`[COR]` The Class labels are historical loading labels. Any interpretation involving $K<1$ orientation-disk traversal belongs to an independently specified orientation model, not $M_{\rm root}$ merely by using the same $(Q_s,Q_c,I,r)$ amplitudes.

### §6.7 Root Contact, T-6e Raw Orientation Extraction, and Historical Downstream Runs `[ALG/NUM diagnostic / mixed]` {#sec-6-7-plucker}

`[NUM diagnostic]` **T-6d root-model record.** Historical fixed-branch $M_{\rm root}$ runs reached the radicand guard with positive amplitudes. This is a record of the root-reclosed model, not an independent-orientation sector result.

`[NUM diagnostic]` **T-6d2 record.** $\dot W^2<0$ at the root contact for the tested seeds; this rejects only the tested naive branch flip.

`[ALG diagnostic]` **T-6e — raw determinant extraction.** The recovered producer defines
$$\omega_{\rm raw}=s_\eta c_\rho-s_\rho c_\eta$$
and extracts its six-step increment. The producer metric audit establishes
$$Q_sQ_c-I_{sc}^2=\Omega^2,\qquad \omega_{\rm raw}=-\frac{\Omega}{\sqrt3},$$
so the normalized orientation rate is
$$\boxed{\Delta\Omega=-\sqrt3\,\Delta\omega_{\rm raw}}.$$
The extraction itself is retained; the historical downstream identification of $\Delta\omega_{\rm raw}$ with $\Delta\Omega$ is corrected in §6.18.

`[NUM]` `[scope: historical executed mis-scaled orientation model]` **T-6i/T-6i2, T-6h and T-6j records.** Their stored sector, impact and basin outputs used the determinant increment as the normalized orientation rate. They remain evidence of the model actually executed, but their inward/outward $K=1$ sectors, approximately $22^\circ$ arc, impact classifications and basin interpretation are withdrawn as statements about the corrected orientation field. They must not be rescaled into that field.

`[OPEN]` No corrected finite-$u/r$ numerical trajectory campaign is installed by this correction.

### §6.8 Dimensionless Identities and Historical Independent-Orientation Flow `[ALG/NUM diagnostic / mixed]` {#sec-6-8-dimensionless}

`[DEF]` For an independent-orientation description define
$$u=\frac{Q_c}{Q_s},\quad \mu=\frac{I_{sc}}{\sqrt{Q_sQ_c}},\quad \nu=\frac{\Omega}{\sqrt{Q_sQ_c}},\quad \varrho=\frac r{\sqrt{Q_s}},\quad K=\mu^2+\nu^2.$$
In the primitive two-vector/root realization $K=1$ identically. A $K<1$ diagnostic therefore requires an explicit enlarged/relaxed carrier rather than mere reuse of two planar vectors.

`[ALG diagnostic]` **T-6g — fixed-expression radial square identities:**
$$A_2=-6(\mu-\sqrt3\nu)^2\le0,\qquad B_1=-6(\sqrt3\mu+\nu)^2\le0.$$
These identities are retained. No conclusion is drawn here about their role inside the normalization-corrected full orientation dynamics.

`[NUM]` `[scope: historical executed mis-scaled model]` **T-6h_v2.** The recorded near-boundary flow is retained only as a historical run of the former orientation-rate model. It is not a corrected-model trajectory or a proxy for $M_{\rm root}$.

### §6.9 Historical Phase-Steering Algebra and Corrected Leading Torsion `[ALG/NUM diagnostic / mixed]` {#sec-6-9-steering}

`[NUM]` `[scope: historical executed mis-scaled model]` **T-6k/T-6k2.** The reported positive-rotation percentages are preserved as outputs of the model that used $\Delta\omega_{\rm raw}$ as $\Delta\Omega$. They are not current corrected-model phase-steering results.

`[ALG]` `[scope: historical executed mis-scaled model]` **Historical T-6l algebra.** The old coefficient
$$-3\mu^2+(21+5\sqrt3)\mu\nu+9\sqrt3\nu^2$$
produces the archived polynomial $9\sqrt3x^2+(21+5\sqrt3)x-3$ and $x_*\approx0.0962741296$. This remains exact historical algebra of the executed mis-scaled diagnostic, not a current safety threshold.

`[ALG]` [RID: TRIAD-ALG-T6L-NORMALIZED-TORSION-SIGN] `[scope: corrected leading orientation model]` **Corrected leading torsion sign.** Apply $\Delta\Omega=-\sqrt3\Delta\omega_{\rm raw}$ in the $r=0$ producer expressions, with $Q_s>0$, $u>0$. The leading $u$ coefficient of the scaled torsion numerator is
$$\boxed{B_\theta^{\rm corr}:=[u^1]\frac{\mu\Delta\Omega-\nu\Delta I_{sc}}{Q_s^2\sqrt u}=3K\left(\sqrt3\mu^2+2\mu\nu+3\sqrt3\nu^2\right).}$$
Here $[u^1]$ extracts the $u$ coefficient after expansion in $\sqrt u$. The angular rate obeys $\dot\theta/Q_s=(\mu\Delta\Omega-\nu\Delta I_{sc})/(KQ_s^2\sqrt u)$. Since $K=\mu^2+\nu^2>0$ is an identity of this diagnostic, not a restriction to the root-closed boundary, division by $K$ gives the coefficient in the same normalization as the historical $A_\theta$:
$$\boxed{A_\theta^{\rm corr}=3\sqrt3\mu^2+6\mu\nu+9\sqrt3\nu^2=3\sqrt3\left(\mu+\frac\nu{\sqrt3}\right)^2+8\sqrt3\nu^2>0.}$$
This holds for $(\mu,\nu)\ne(0,0)$ without imposing $K=1$; the angular-rate definition is singular at $K=0$. For $\mu\ne0$, $x=\nu/\mu$ gives the same zero-condition polynomial $9\sqrt3x^2+6x+3\sqrt3$, with discriminant $-288$. At $\mu=0$, $\nu\ne0$, the coefficient is $9\sqrt3\nu^2>0$. There is no real replacement for $x_*$ at this leading order.

`[DEF]` This is not a finite-$u$, $r$-dependent, global phase-flow or basin theorem. It does not by itself define a physical $K<1$ carrier.

### §6.10 Historical Protocol Reference `[NUM diagnostic]` {#sec-6-10-protocol}

| Record | Model/status after r4 |
|---|---|
| T-6d / T-6d2 | $M_{\rm root}$; retained historical root-model runs |
| T-6f / T-6h / T-6i / T-6j / T-6k / T-6l | historical executed mis-scaled independent-orientation diagnostics; interpretations narrowed/withdrawn |
| T-6j2 | historical root-reclosed session model; terminal event log absent |
| Corrected $M_{\rm orient}$ | coefficient-level extension only; no numerical trajectory campaign for this release |

`[DEF]` Historical solver tolerances, seeds and output files remain provenance of the executed models. They are not silently reused as corrected-model evidence.

### §6.11 Current Continuous-Branch Status `[COR / mixed]` {#sec-6-11-verdict}

`[COR]` **Historical phase-steering verdict withdrawn as current evidence.** The prior synthesis—dominant steering into fatal Plücker sectors, a $22^\circ$ radial arc, a $5.5^\circ$ necessary wedge, and no-safe-basin support—depended on the downstream use of the raw determinant increment as the normalized orientation rate. Those outputs remain historical records of the executed model but are not evidence about the corrected orientation dynamics.

`[RESULT]` `[from: ALG]` `[scope: diagnostic; corrected orientation model]` The corrected coefficient extension is tangent to $K=1$ and has sign-definite leading large-$u$, $r=0$ torsion (§§6.9, 6.18). These facts do **not** establish stability, escape, a safe basin, a physical obstruction, or any physical $K<1$ carrier. Finite-$u$, $r$-dependent and global corrected dynamics are uncomputed.

`[OPEN]` **Continuous-cascade disposition.** The question returns to unresolved amplitude dynamics and model correspondence in the retained root-model diagnostic; it is settled neither for nor against. The 96:1 same-object correspondence remains independently OPEN. T-6n continuation and the remaining T-6o/global questions retain their own scopes.

Revoked current-use overclaims:
- Historical sector/wedge geometry as corrected-model geometry.
- Historical T-6j/T-6j2 fatal/no-basin classifications.
- Continuous-route closure by phase steering.
- Global stability or escape inferred from $K=1$ tangency.

### §6.12 T-6m — Fixed-Direction Reference Birth Audit `[ALG diagnostic / mixed]` {#sec-6-12-birth-angle}

`[ALG]` [RID: TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN] `[scope: declared reference initialization]` **Reference quarter-turn.** The diagnostic assumes
$$\Phi_{sc}(0)=-\frac\pi2,$$
so the signed reference angle is $-90^\circ$ independently of positive orientation-variable normalization. In the T-6d normalized root convention this corresponds to $(\mu_0,\nu_0,K_0)=(0,-1,1)$. The leading signed child motivates this reference angle; a complete physical birth law need not preserve it exactly.

`[ALG]` `[scope: producer-frame ansatz]` **Recorded $r=0$ forcing polynomial.** Under the reference shear ansatz used by the historical producer,
$$\Delta I_{sc}^{(0)}\big|_{\rm birth}=Q_s^3(24Q_s^2+8Q_s-18),$$
with positive turn root
$$Q_s^{\rm turn}=\frac{2\sqrt7-1}{6}\approx0.71525.$$
This algebra is retained in its producer-frame convention. The alternative $0.6194$ sensitivity reading is withdrawn as a current correction because a coherent convention conversion also transforms coefficient arguments.

`[COR]` **Wedge/obstruction withdrawal.** The historical $x_*$/$5.5^\circ$ wedge, $\sim15\times$ comparison, and statement that this reference input closes the continuous physical birth route are withdrawn. The orientation-normalization correction removes the basis for that comparison. No corrected finite-$u/r$ obstruction is installed here.

`[OPEN]` T-6m2 may still test the apex correction to the producer-frame turn polynomial, but it no longer gates a validated safety-wedge obstruction. Physical residual, retention, event and model correspondence remain open.

### §6.13 T-6j2 — Historical Root-Closed Torsional Excursion `[NUM / PARTIAL]` {#sec-6-13-t6j2}

`[NUM]` [RID: TRIAD-NUM-T6J2-ROOT-CLOSED-EXCURSION] `[scope: author-reported historical root-closed session; normalization-conditional]` The original operator reports that the T-6j2 session recomputed the root orientation each step, so $K\equiv1$ by construction. Across the tested initial wedge, the surviving historical observation is torsional excursion to
$$\theta_{\max}\approx99^\circ\text{--}101^\circ.$$
The session script/event log was never archived.

`[RETRACTED]` **No-safe-basin/fatal classification.** The recorded $0/120$ safe, $120/120$ fatal labels, `\dot K` impact classification and the terminal-angle label as a certified Plücker impact are not supported under the corrected model/state audit. The reported terminal angle remains provenance only; which event fired is unresolved.

`[DEF]` This module is PARTIAL. It is not a proxy for an interior $K<1$ independent-orientation model, not a basin theorem, and not a consumer obstruction export.

### §6.14 Genesis Export Protocol `[DEF]` {#sec-6-14-t6p}

`[DEF]` [RID: TRIAD-EXPORT-PROTOCOL-2] `Replaces: TRIAD-EXPORT-PROTOCOL-1` **T-6p current protocol.** Consumer synchronization follows adopted current claims; historical safety-wedge, phase-steering, no-basin and continuous-route-obstruction exports are removed.

Permitted current Triadic-to-Genesis items from this phase chain:

| Export RID / notice | Current content | Scope |
|---|---|---|
| `TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN` | exact fixed reference angle and producer-frame turn polynomial | reference initialization only; no wedge/route obstruction |
| `TRIAD-ALG-T6E-ORIENTATION-NORMALIZATION` | typed relation $\Omega=-\sqrt3\omega_{\rm raw}$ and rate conversion | diagnostic convention correction |
| `TRIAD-ALG-T6L-NORMALIZED-TORSION-SIGN` | corrected leading sign-definite torsion, no real $x_*$ root at that order | local leading algebra only |
| CN-05 | required re-review of old T-6 sector/wedge/basin/obstruction imports | consumer action OPEN |

`[DEF]` Not exported as current constraints: the historical $5.5^\circ$ wedge, $x_*$ threshold, T-6i sectors, T-6j/T-6j2 no-basin/fatal conclusions, T-6k steering percentages, or a continuous-route closure by phase steering.

`[DEF]` Genesis OPEN 1T and dependent consumers must re-review prior imports under CN-05. T-6r now concerns corrected model/domain completion, not theorem-completion of the historical proxy sweep.

### §6.15 T-6s — In-plane chirality and the bounded coherent-source family {#sec-6-15-t6s}

`[ALG]` [RID: TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY] [scope: stated conditional family] **Adopted successor claim; scientific scope unchanged from accepted r4.2.**  
**Replaces:** `TRIAD-ALG-T6S-INPLANE-CHIRALITY` in the adopted v1.6 ledger; its original statement/verdict remains in Appendix B.  
**Depends on:** the source convention/inputs identified in §7.2 and the explicit local construction below.  
**Evidence:** recovered historical algebra at its narrowed scope; new 47-check bundle plus the point-of-use checks under `TRIAD-ART-T6U-APEX-SEED-DIAGNOSTIC-V16`. A passing historical script does not reinstate its withdrawn interpretations.

> **[Local guard SG-15]** A unit direction, a policy-scaled child and a source operator are distinct. The no-gain inequality below assumes the stated real-weight interval and source construction.

`[ALG]` [scope: the stated real $B$-orthogonal quarter-turn] $J_Q^2=-I$, $J_Q^{-1}=-J_Q$, and the complexified eigenvalues are $\{+i,-i\}$. There is no third eigenvalue or real invariant line of this operator. This is a statement about this operator, not a classification of arbitrary in-plane source laws.

`[COR]` The v1.5 equality $W_{\rm child}/W_{\rm parent}=+i$ omitted the signed birth amplitude. The corrected two statements follow.

`[ALG]` [scope: unit direction versus leading birth family]
$$\frac{W(J_Qs)}{W(s)}=i,\qquad
\frac{W(c_0)}{W(s_*)}=i\kappa Q_s+O(Q_s^2),\qquad s_*\ne0.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; chosen linear $B$-eigenframe; no isolated-dyad/network RRF bridge asserted)
`[ALG]` [scope: fixed negative reference $\kappa$, leading birth term] Both recorded policies have leading child phase $-\pi/2$. Only the unit direction has phase $+\pi/2$. For the full asymptotic family the phase is $-\pi/2+O(Q_s)$ absent a separate higher-order directional statement. This does not change T-6m's declared fixed-direction diagnostic input or extend its dynamics to every birth completion.

`[DEF]` [assuming: chosen 9B/HINDEX lowering, coherent real weight $g_2$] Define
$$H_+=BJ_Q,\qquad H_-=-BJ_Q,\qquad H_{\rm total}=(1-g_2)BJ_Q.$$
(rep: [UNREGISTERED-TRIADIC-SOURCE]; covariant operator construction, not a seed vector)
`[DEF]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §2 OPEN-GEN-II-HINDEX, displayed source-amplitude norm and status-table row | RID unavailable] Use the owner's norm-definition component for $H:V\to V^*$:
$$\|H\|_B^2=\lambda_{\max}(B^{-1}H^\top B^{-1}H).$$
(rep: [UNREGISTERED-TRIADIC-SOURCE]; input metric $B$, output covector metric $B^{-1}$)
Source status: the inspected norm row is `[DEF/ALG]`; this import uses its definition, not a new Triadic norm or the owner's broader source-selection inference. Owner RID: no theorem-specific identifier for this definition; `GEN-OPEN-HINDEX` is a module locator, not borrowed as its RID. Request REQ-T16-HINDEX is recorded in §7.2. Depends on: the stipulated covector-valued construction and its two metric contractions. Physical identification of a seed with $H$ is not imported.

`[ALG]` [scope: this chosen coherent operator family] It follows that
$$\|H_{\rm total}\|_B=|1-g_2|.$$
(rep: [UNREGISTERED-TRIADIC-SOURCE]; derived norm identity, not a seed-to-operator bridge)
`[ALG]` [assuming: $g_2\in\mathbb R$] Consequently
$$\|H_{\rm total}\|_B\le1\quad\Longleftrightarrow\quad0\le g_2\le2.$$
(rep: [UNREGISTERED-TRIADIC-SOURCE]; bounded coherent family only)
`[COR]` The v1.5 phrase “any coherent source cannot raise the norm” lacked this coefficient condition. Equal weights cancel at $g_2=1$; the maximum in this interval is one, reached at both endpoints. Neither the interval's physical selection nor the source lowering is proved by these identities.

`[DEF]` **Reference-only Genesis note.** Genesis v2.8.4 §2 `GEN-OPEN-WPHASE-GSPLIT` records its in-plane gap-functional audit. It is cited for interface consistency, not imported here to select a source magnitude, an energy/amplitude relation, or an apex embedding. The earlier v2.8.3 live pointer and “apex ratio unevaluated” summary are superseded: the T-6u leading seed diagnostic is evaluated in §6.17; the source-operator identification is not. The distinct Dyadic SU(2) energy candidate remains outside T-6s.

### §6.16 T-6t — Mode-sign count, not a physical transverse embedding {#sec-6-16-t6t}

`[ALG]` [RID: TRIAD-ALG-T6T-JACOBI-MODE-SIGNS] [scope: stated conditional family] **Adopted successor claim; scientific scope unchanged from accepted r4.2.**  
**Replaces:** `TRIAD-ALG-T6T-CHIRALITY-COUNT` in the adopted v1.6 ledger; its original statement/verdict remains in Appendix B.  
**Depends on:** the source convention/inputs identified in §7.2 and the explicit local construction below.  
**Evidence:** recovered historical algebra at its narrowed scope; new 47-check bundle plus the point-of-use checks under `TRIAD-ART-T6U-APEX-SEED-DIAGNOSTIC-V16`. A passing historical script does not reinstate its withdrawn interpretations.

> **[Local guard SG-16]** Label-space mode orthogonality does not establish a physical carrier dimension or source normalization.

`[ALG]` [scope: supplied node-mediated additive edge realization] The relation $\Delta_{AB}+\Delta_{BC}+\Delta_{CA}=0$ telescopes and is independent of the fourth node variable. This is the stated branch's incidence identity, not a theorem for arbitrary independent edge fields.

`[ALG]` Sequential Jacobi coefficient rows $(1,-1,0,0)$, $(1/2,1/2,-1,0)$ and $(1/3,1/3,1/3,-1)$ have
$$G_{\rm seq}=\operatorname{diag}(2,3/2,4/3),\quad
R=\operatorname{diag}(1,4/3,3/2),\quad
RG_{\rm seq}R=\operatorname{diag}(2,8/3,3).$$
(rep: [UNREGISTERED-TRIADIC-JACOBI]; row inner products in node-label coefficient space)
`[ALG]` The stated $K_4$ graph has $E-V+1=3$ independent cycles and $F-1=3$ independent face constraints. In its node-mediated reduction, three relative mode labels remain. Their sign changes can be made independently with the associated edge reconstruction. These coordinate sign choices are not automatically dynamical or physical gauge symmetries.

`[COR]` T-6t's former “apex lies outside the $(s,c)$ plane” wording mixed label-space rows with state-carrier vectors. The replacement common-carrier statement is as follows.

`[ALG]` [scope: stated two-dimensional $B$-carrier]
$$\det[s,J_Qs]=\frac{2\sqrt3}{3}Q_s\ne0\quad(s\ne0),$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; fixed $J_Q$ and $B>0$)
so $s$ and $J_Qs$ already span that two-dimensional carrier. A distinct $d$-mode label and its seeding equations are retained. Identifying it with a separate physical transverse direction requires an explicit enlarged carrier, embedding and metric.

`[DEF]` **Ratio status.** T-6u now evaluates the specified seed diagnostics; they are not an unevaluated extension of the chirality count. Physical source realization, metric embedding, and a HINDEX numerator/denominator identification remain separate OPEN obligations. `GEN-OPEN-APEX-SLOT` is a reference-only record of that interface question and its later review; it is not imported as a Triadic proof premise. RRF v0.6 is likewise cited for convention/transport discipline only, not for an already registered primitive-mode profile or a new physical relabel action.

### §6.17 T-6u — Policy-parametric primitive apex diagnostic {#sec-6-17-t6u}

> **[Local guard SG-17]** The calculation below is exact for named leading coefficients. It is not a finite-amplitude bound, a HINDEX source ratio, or a physical cascade/OPEN-M verdict. The vector-state and increment-channel numerator readings have different meanings.

`[ALG]` [RID: TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC] [scope: leading primitive diagnostics] **Adopted successor claim; scientific scope unchanged from accepted r4.2.**  
**Replaces:** `TRIAD-ALG-T6U-APEX-SOURCE`. The original shear/vector arithmetic is retained; the overbroad source-amplitude interpretation is not the successor proposition. Appendix B preserves the original identity and verdict.
**Custody:** Triadic owns the ratio and its diagnostic interpretation. Genesis owns the lower-level polynomial and seeding records cited below. No ownership transfer follows from independent consumer verification.  
**Proof evidence:** [RID: TRIAD-ART-T6U-APEX-SEED-DIAGNOSTIC-V16], `triad_t6u_apex_source_v1_6.py`: 47 exact executable assertions, including two reference-policy sign checks and one domain counterexample; these are not 47 independent theorems. The arithmetic/assertion bodies are unchanged from reviewed r1. A separate `triad_v1_6_r2_point_use_checks.py` supports the consumer sign/GSPLIT/turn statements. Recovered historical scripts and fresh reruns have separate byte identities and limitations in §8; review findings through r4.1 remain historical; exact r4.2 sign-off is accepted and owner publication is recorded separately. Consumer acceptance remains pending.

#### §6.17.1 Source model, time index and the two numerator objects

`[DEF]` [family: primitive $K_4$ six-step seeding model] Let $Q_s=s^TBs>0$, $Q_c=c^TBc$ and use the real primitive source conventions
$$B=\begin{pmatrix}1&-1/2\\-1/2&1\end{pmatrix},\qquad
J_Q=\frac1{\sqrt3}\begin{pmatrix}1&-2\\2&-1\end{pmatrix},\qquad
\omega_{ab}=a_2b_1-a_1b_2.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; source $B$-mode carrier; not the T-6d orientation normalization or a claimed RRF bridge)
The `UNREGISTERED-TRIADIC-*` strings are local typing sentinels, not assigned RRF profile identifiers. The index “1” below is the **first six-step return block** applied at zero apex, not an additional microscopic tick or the diagonal-lift ODE step. The same source parent $s$ and quadratic form are used in both leading coefficients; a physical retention/change-of-state map is not supplied by this comparison.

`[ALG]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.5 #sec-6-5-quartic | RID unavailable] The source's zero-apex $s^3$ and $c^3$ vector channels give
$$V_s=-\frac{Q_s}{16}s-\frac{\sqrt3Q_s}{32}J_Qs,\qquad
V_c=-\frac{Q_c}{54}c+\frac{7Q_c}{108\sqrt3}J_Qc,$$
$$Q(V_s)=\frac7{1024}Q_s^3,\qquad Q(V_c)=\frac{61}{34992}Q_c^3.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; homogeneous cubic vector channels and their squared norms)
The certificate derives these formulas from $V_d=\tfrac12B^{-1}\nabla_d\mathcal P_4|_{d=0}$ under the source's $G_2=0$ and $\mathcal P_4=2d^TBG_{3,d}$ premises. Depends on: the separately imported `[THM]` chronological-protection and radial-polynomial statements in §7.2; this `[ALG]` consequence does not re-own those source theorems. It does not reconstruct the microscopic coupled map. The relevant source artifact locator is `GEN-ART-G3D-SEED`; it is **not** borrowed as a theorem-specific RID. A dedicated source result RID is requested rather than invented.

`[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.6 #sec-6-6-phase, Birth symmetry theorem | RID unavailable] The source birth-symmetry theorem gives
$$I_{V_s,s}=\omega_{V_s,s}=-\frac1{16}Q_s^2.$$
Depends on: the stated source birth gauge and fixed $B,J_Q,\omega$ convention; exact source/RID exception in §7.2.

`[ALG]` Consequently the source's $s^3$ **radial channel evaluated at the seeded vector** is
$$D_{\rm birth}^{[s^3]}:=
-\frac18Q_sI_{V_s,s}-\frac3{32}Q_s\omega_{V_s,s}
=\frac7{512}Q_s^3=2Q(V_s).$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; seeded-state radial increment-channel evaluation)
`[COR]` This explains why v1.5 used $7/1024$ for a seeded state amplitude. The $7/512$ object is the differently typed increment diagnostic; it is not an alternative value of the same $Q_{d,1}$, nor a demonstrated complete next-block increment. In particular $\mathcal P_4(s,c,0)=0$ although $V_d(s,c,0)$ can be nonzero. Taking the square root of $D_{\rm birth}^{[s^3]}$ below defines an **increment-equivalent** comparison, not a second initial state.

#### §6.17.2 Leading policy family and higher-order scope

`[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.3 #sec-6-3-triad, one-dimensional birth theorem | RID unavailable] The source admissible pure-transverse birth family is
$$c_0=\kappa Q_sJ_Qs+O(\|s\|^5),\qquad
Q_c^{[\rm lead]}=\kappa^2Q_s^3,\qquad
\kappa\in\mathbb R\setminus\{0\}.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; leading birth input, physical policy not selected)
`[ALG]` [scope: source reference-policy structure, not physical selection] The four-case test uses only $\kappa_{\rm shear}=-2\sqrt3/3$ and $\kappa_{\rm recoil}=-1/2$, separately imported in §6.1/§7.2. Depends on: the source pure-transverse family and fixed-policy leading limit; $Q_c^{[\rm lead]}$ denotes only its leading coefficient. Neither the physical residual nor retention is selected, and T-6m retains its own fixed-direction calculation.

`[ALG]` The leading generated numerator $Q_{d,1}^{[s^3]}=7Q_s^3/1024$ is independent of fixed $\kappa$. The isolated squared $c^3$ channel is
$$Q_{d,1}^{[c^3]}=\frac{61}{34992}\kappa^6Q_s^9,$$
which is $O(Q_s^6)$ **relative to** the leading $O(Q_s^3)$ numerator, not an absolute $O(Q_s^6)$ term.
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; channel-specific birth scaling, fixed $\kappa$)

`[COR]` The $c^3$ channel is not the only policy-dependent contribution beyond leading order. The source also contains $s^2c$ and $sc^2$ vector channels, and squared-vector interference is not a sum of isolated channel norms. The complete homogeneous cubic source supplies the following independent subleading check.

`[ALG]` [scope: exact trial $c=\kappa Q_sJ_Qs$; homogeneous cubic vector only]
$$Q\!\left(G_{3,d}(s,c,0)\right)
=\frac7{1024}Q_s^3-\frac{5\sqrt3\kappa}{1728}Q_s^4+O(Q_s^5).$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; substitution into the cubic vector polynomial only)
This additional calculation confirms the unchanged leading coefficient while preventing misuse of the $c^3$ suppression as a bound on every correction. The unknown full-return remainder has not been bounded here; no uniform finite-amplitude sixfold result is claimed.

#### §6.17.3 Four typed diagnostic cases

`[DEF]` Define ratios of the named leading coefficients:
$$R_{\rm vec}(\kappa):=
\sqrt{\frac{Q_{d,1}^{[s^3]}}{Q_c^{[\rm lead]}}},\qquad
R_\Delta(\kappa):=
\sqrt{\frac{D_{\rm birth}^{[s^3]}}{Q_c^{[\rm lead]}}}.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; vector-seed versus increment-equivalent diagnostics)
`[ALG]` For fixed real nonzero $\kappa$,
$$\boxed{R_{\rm vec}(\kappa)=\frac{\sqrt7}{32|\kappa|},\qquad
R_\Delta(\kappa)=\sqrt2\,R_{\rm vec}(\kappa).}$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; exact leading coefficient ratios)

`[ALG]` [horizon: two reference policies × two defined numerator readings] The exact specializations and benchmark shortfalls are:

| Policy | Numerator reading | Leading ratio $R$ | Display value | Shortfall $\sqrt2/R$ |
|---|---|---|---:|---:|
| Shear, $-2\sqrt3/3$ | Vector seed $Q_{d,1}^{[s^3]}$ | $\sqrt{21}/64$ | 0.0716027452 | 19.7508288 |
| Shear, $-2\sqrt3/3$ | Increment-equivalent $D_{\rm birth}^{[s^3]}$ | $\sqrt{42}/64$ | 0.1012615734 | 13.9659450 |
| Recoil, $-1/2$ | Vector seed $Q_{d,1}^{[s^3]}$ | $\sqrt7/16$ | 0.1653594569 | 8.5523597 |
| Recoil, $-1/2$ | Increment-equivalent $D_{\rm birth}^{[s^3]}$ | $\sqrt{14}/16$ | 0.2338535867 | 6.0474316 |

`[ALG]` [scope: exactly the four listed leading diagnostics]
$$\boxed{\max R=\frac{\sqrt{14}}{16},\qquad
\min\frac{\sqrt2}{R}=\frac{16}{\sqrt7}>6.}$$
The strict inequality is certified without rounded displays:
$$\left(\frac{16}{\sqrt7}\right)^2-6^2=\frac47>0.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; four-case arithmetic with conditional benchmark)
`[COR]` The former headline “approximately 20 times short” is only the shear/vector specialization. The robust four-case headline is **more than six times below the conditional $\sqrt2$ benchmark**, with numerator types retained. This does not assert the same finite-amplitude result for the complete dynamics or all possible birth policies.

#### §6.17.4 Programme questions and physical boundary

`[DEF]` Programme v1.2 §6.3's questions are answered at the scope actually tested. Its numerical “two times short” headline is not adopted as a programme-certified deficit; $\sqrt2$ here is a stipulated diagnostic comparator, not a newly validated calibration:

| Review question | This revision's answer |
|---|---|
| Model identity | The primitive $\mathcal P_4$ / cubic seeding coefficient model from Genesis §§6.4–6.6. It is not the diagonal-lift generalized ODE of Triadic §§6.3–6.14, nor a newly specified UV operator. |
| Constraints and domain | Fixed nonzero $\kappa$, leading $Q_s\to0$ coefficient regime; four-case extrema use only the registered shear/recoil references and the two explicit numerator diagnostics. No finite-radius remainder or complete birth event is supplied. |
| Sign conventions | Source $B,J_Q,\omega_{ab}$ are specified. Norm ratios depend on $|\kappa|$; signed birth direction and the T-6m branch convention remain separate questions. Row-space signs are not a physical embedding. |
| Source-amplitude interpretation | $Q_c^{[\rm lead]}$ is an input imposed by the selected birth policy. $Q_{d,1}^{[s^3]}$ is a generated output of one six-step primitive return block. $D_{\rm birth}^{[s^3]}$ is an increment-channel diagnostic at that output. None is an operator norm merely by taking a square root. |

`[HEUR]` [assuming: an independently justified source-amplitude identification and the stated OPEN-M benchmark] The four-case values would remain below the stipulated conditional $\sqrt2$ comparison target. That observation is only a conditional diagnostic; no map from these seed data to $H_{\rm apex}$ and $H_{\rm in}$ has been established. In particular,
$$R_{\rm seed}\ \not\equiv\ \frac{\|H_{\rm apex}\|_B}{\|H_{\rm in}\|_B}$$
(rep: [ABSTRACT]; non-identification absent a declared source map; no theorem that every possible map fails)
The distinction includes the input/output mismatch, but goes beyond it: state/increment objects, operator domains/codomains, coupling and normalization are different data. A physical source map could be studied; it has not been selected by this ratio.

`[COR]` The prior $B_3$-isometric number $\sqrt{(4+\sqrt7)/3}\approx1.488$ remains excluded as an **established physical source estimate**. This certificate checks its algebraic distinction from the seed ratios, not a universal refutation of every enlarged-carrier or UV model. Likewise the source self-sink $[\Delta Q_d^{(4)}]_{d^4}=-Q_d^2$ and isolated saturation record do not, without their own full model, establish the fate of every weak seed or network.

`[OPEN]` Physical event/residual selection, the state/torque-to-HINDEX source map, the enlarged-carrier embedding, finite-amplitude control and the non-$\mathcal P_4$ source remain outside this result. T-6u does not close OPEN M and does not license a global no-cascade verdict. Programme and OFN synchronization follow technical consumer review of this adopted release.

### §6.18 T-6 Orientation-Normalization Correction `[COR / ALG]` {#sec-6-18-orientation-correction}

[RID: TRIAD-ALG-T6E-ORIENTATION-NORMALIZATION]  
Evidence artifact: [RID: TRIAD-ART-T6-ORIENTATION-NORMALIZATION-V16]

`[COR]` **What was wrong.** The independent-orientation diagnostics T-6f, T-6h, T-6i, T-6i2, T-6k, T-6k2, T-6l and T-6j integrated the T-6e output as the rate of the state variable `omega_sc`. That output is the increment of a different quantity. The error is a factor $-\sqrt3$ (sign and scale) in the orientation equation. It is an error in the downstream consumers, not in the T-6e measurement and not in the T-6d root model.

`[ALG]` **Producer conventions** (recovered T-6c2/T-6e source; producer metric $B_T=\begin{pmatrix}2&-1\\-1&2\end{pmatrix}$ on the planar components). With the T-6c2 axis representative $s_\eta=0$, $s_\rho=\sqrt{Q_s/2}$, $c_\eta=\Omega/(\sqrt3\,s_\rho)$, $c_\rho=\tfrac12(c_\eta+I_{sc}/s_\rho)$:
$$Q_sQ_c-I_{sc}^2=\Omega^2,\qquad \omega_{\rm raw}:=s_\eta c_\rho-s_\rho c_\eta=-\frac{\Omega}{\sqrt3}.$$
(rep: recovered T-6 lifted-model planar metric; Ω is the T-6c2 input and the T-6d root variable)

`[ALG]` **Correct rate.** If $H_j$ are the T-6e polynomials returned at order $r^j$, then
$$\Delta\Omega=-\sqrt3\sum_{j=0}^{2}r^jH_j(Q_s,I_{sc},\Omega),\qquad\text{not}\quad \Delta\Omega=\sum_j r^jH_j.$$
(rep: degree-four invariant increment, producer Ω convention retained in the arguments)
Evidence: (i) source reading of the T-6c2 substitution and the T-6e `omega_inv`; (ii) the planar Gram identity $2\Omega\Delta\Omega=Q_c\Delta Q_s+Q_s\Delta Q_c-2I_{sc}\Delta I_{sc}$ forces the factor $-\sqrt3$ exactly at $r^0$, $r^1$ and $r^2$, while the factor 1 violates it at every order; this identity test uses the archived T-6a2/T-6c radial ledgers for $\Delta Q_s,\Delta Q_c$, not regenerated in the named evidence here; (iii) fresh PI runs of T-6c2 and T-6e reproduce the mixed/orientation ledger strings exactly. These named executions do not regenerate the radial ledgers or certify a corrected trajectory. Any separate receiving-side cubic reconstruction retains its own scope and is not an unpinned evidence leg of this paragraph.

`[ALG]` **Retained: T-6d root convention.** The T-6d closure $\Omega=\sigma\sqrt{Q_sQ_c-I_{sc}^2}$ is the correct closure for the T-6c2 variable. T-6d never used the T-6e rate. Its derived equations are retained. The 0.6194 "raw-reading" sensitivity row is not the convention of the recovered bytes and is withdrawn as a candidate reading.

`[ALG]` **Corrected diagnostic consequences** (formal five-variable extension used by the downstream code, $Q_c$ independent, reduced coefficient formulas retained):
1. **Boundary tangency.** With $\mathcal G=Q_sQ_c-I_{sc}^2-\Omega^2$ and $K=(I_{sc}^2+\Omega^2)/(Q_sQ_c)$, the corrected field gives $\dot{\mathcal G}=(f_s/Q_s)\,\mathcal G$ and $\dot K=(1-K)\,f_c/Q_c$. Hence $\dot K=0$ on $K=1$, at all retained $r$-orders. The corrected field has no outward or inward $K=1$ sectors.
2. **Large-$u$ torsion** ($r=0$, $I_{sc}=\mu\sqrt u\,Q_s$, $\Omega=\nu\sqrt u\,Q_s$). The leading $u$ coefficient of $\dot\theta/Q_s$ is $A_\theta^{\rm corr}=3\sqrt3\mu^2+6\mu\nu+9\sqrt3\nu^2>0$ for $K=\mu^2+\nu^2>0$, not only at $K=1$. The corresponding scaled-numerator coefficient is $B_\theta^{\rm corr}=K A_\theta^{\rm corr}=3K(\sqrt3\mu^2+2\mu\nu+3\sqrt3\nu^2)$. N4a of the unchanged normalization audit certifies this numerator coefficient; §6.9 displays the angular division. The ratio polynomial $9\sqrt3x^2+6x+3\sqrt3$ and its discriminant $-288$ are unchanged. There is no real replacement for $x_*$ at this order.

`[ALG]` **Historical algebra preserved.** Under the mismatched assignment, the old ratio polynomial $9\sqrt3x^2+(21+5\sqrt3)x-3$ and its root $x_*=0.0962741296\ldots$ are reproduced exactly from the recovered producers. They remain valid historical algebra of the executed (mis-scaled) model. They are not a current safety threshold.

`[RESULT]` `[from: ALG]` `[scope: diagnostic; corrected orientation model]` **Scope of the correction.** Numerical sector maps, safe arcs, wedge widths, basin searches and fatal/impact classifications produced with the factor 1 are records of the executed model only. They are not evidence about the corrected model, and they must not be rescaled into it. The corrected statements above do not establish stability, escape, a safe basin, a physical obstruction, or any physical K<1 carrier (two actual planar vectors always have K=1). Finite-$u$, $r$-dependent and global corrected dynamics are not computed here.

`[OPEN]` **Unaffected and still open: 96:1.** Resolving the Ω/ω_raw normalization does not show that the isolated pump coefficient and the full-return healing coefficients belong to the same transported dynamical object. The recovered graph-force generator differs from the primitive sine/exponential map. The 96:1 identification stays OPEN as before.

`[OPEN]` **Metric-unit identification.** For the same planar vectors, $B_T=2B_G$, so $Q_T=2Q_G$, $I_T=2I_G$, $\Omega_T=-\sqrt3\,\omega_{\rm raw}$. This is a typed planar-metric convention, not a generator, mode or event bridge, and it does not cover the lifted apex z-component. Under same-vector transport a Genesis law $Q_c^G=\kappa^2(Q_s^G)^3$ becomes $Q_c^T=\tfrac{\kappa^2}{4}(Q_s^T)^3$ (shear: $\tfrac13$, not the copied $\tfrac43$). No reference birth law is changed by this block; the birth/mode identification is recorded as unresolved.

### Per-module dispositions (summary; point-of-use text in §§6.4–6.14)

| Module | Adopted v1.6 disposition (accepted r4.2 scope) |
|---|---|
| T-6c2 | Polynomial and input convention verified. Attach recovered producer and fresh output to the existing artifact identity. |
| T-6e | Current correction: `TRIAD-ALG-T6E-ORIENTATION-NORMALIZATION`; raw-determinant extraction retained, normalized-rate identification corrected. |
| T-6d / T-6d2 | Root convention consistent; retained. No campaign rerun; no physical event-law status implied. |
| T-6f, T-6h | Orientation forks and free-$Q_c$ results: records of the mis-scaled model; current interpretations withdrawn. |
| T-6i, T-6i2 | Transpiercing/reflecting sectors and the ~22° radial arc: artifacts of the factor; withdrawn. Corrected field is tangent at $K=1$. |
| T-6k, T-6k2 | "Positive rotation on 92–94% of the disk, funnelling into fatal sectors": withdrawn as current; corrected leading torsion is sign-definite. |
| T-6l | $x_*$ retained as historical algebra only; current corrected result: `TRIAD-ALG-T6L-NORMALIZED-TORSION-SIGN`. |
| Safety-window synthesis | Withdrawn (both components were mis-scaled). |
| T-6j | Basin-search outputs: records of the mis-scaled model; interpretation withdrawn. |
| T-6j2 | Current: `TRIAD-NUM-T6J2-ROOT-CLOSED-EXCURSION` (PARTIAL); classifications withdrawn; original code/log unrecoverable. |
| T-6m | Current narrowed successor: `TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN`; exact quarter-turn and the recorded root-model forcing polynomial (root $(2\sqrt7-1)/6$ under its stated producer-frame ansatz) retained. Wedge comparison and "~15×" withdrawn; physical birth-route closure unsupported; module PARTIAL. |
| T-6p | Current protocol: `TRIAD-EXPORT-PROTOCOL-2`; obstruction, no-basin and wedge exports removed. |
| T-6r | Normalization blocker closed; replace with the remaining corrected state/carrier/test contract. |
| §6.11 canonical verdict | "Obstructed by dominant phase steering into fatal Plücker sectors": withdrawn. |
| T-6g | The fixed-expression radial square identities are retained. No conclusion is drawn here about their role inside the normalization-corrected full orientation dynamics; any such interpretation remains subject to the corrected state/model contract. |
| T-6s/t/u, GSPLIT, OPEN 1C | Not affected within their scopes. No rerun. |


---

## §7. Import Ledger {#sec-7-imports}

### §7.1 Retained dyadic import block — historical source pins

These existing v1.5 import records remain pinned to `RTG_DYADIC_OSCILLATOR_DSN_v6.4.8.1` via `dyad_triad_antisymmetric_bridge_v1_1.md`. The intermediary artifact is not available in this package; its full scientific migration is not silently performed by updating the companion header. Current Dyadic v6.4.10/SG-19 is a source of normalization discipline, not permission to identify raw, archival, projected and conjugate objects.

- [RID: DYAD-THM-C21] :: $\mu_6 = -\frac{1}{2}-i\tau$, $\tau=2\sqrt{3}/3$ :: birth kinematics source condition
- [RID: DYAD-ALG-BRIDGE-LEMMA] :: one-step to $p$-step bridge lemma :: $\kappa_{\rm shear} = -2\sqrt{3}/3$ reference policy
- [RID: DYAD-ALG-LIEGAUGE-NORM] :: Birkhoff frame and protection matrix :: fracture-state kinematics in §6.1

Cross-convention warning for T-6m:
- `[conv: T-6d orientation-variable convention]` T-6m values $\nu_0=-1$ and $K_{\rm birth}=1$ use $\omega_{sc}^{(\mathrm{T6d})}=\sqrt{Q_sQ_c}\sin\Phi_{sc}$.
- `[conv: RTG canonical B-metric]` The canonical normalization uses $\omega_{sc}^{(\mathrm{RTG})}=(2/\sqrt3)\sqrt{Q_sQ_c}\sin\Phi_{sc}$ and boundary condition $I_{sc}^2+\frac34(\omega_{sc}^{(\mathrm{RTG})})^2=Q_sQ_c$. The angle $\theta_{\rm birth}=-90°$ is convention-independent.

Inherited scope on all dyadic imports:
- `[scope: conditional on postulated continuous generator T]` until OPEN-P0 is resolved.
- `[scope: local p=6, K=1 dyadic module]` — no global topological content transferred.
- `[conv: Lie strict-kernel gauge]` where normalization/projection quantities depend on that convention.
- Not imported: Genesis lift scale $\beta$, UV parameters, or any global topological completion.

Programme-context references (not scientific imports):
- `RTG_PROGRAMME_OVERVIEW_v1_2.md` §6.3 and SG-PROG-1 — current owner-review questions and cross-branch firewall; no global no-cascade endorsement.
- `RTG_ONTOLOGICAL_FOUNDATIONS_v0_8.md` — relational event interpretation; not proof of this birth law, added independent substance, or added physical dimension.
- `RTG_RRF_REPRESENTATION_REGISTRY_v0_6.md` — convention/transport reference only. This ledger's $s,c,d$ are explicitly primitive $B$-mode coordinates; no $z_{\rm NF}$ is substituted into network closure. A reference does not register a missing profile or close OPEN-A/OPEN-B-E1.
- Genesis v2.8.4 `GEN-OPEN-APEX-SLOT` — reference-only interface/history item, **not a load-bearing import back into its source result T-6u**. Its physical embedding remains unproved.
- `RTG_DISCRETE_GENESIS_DSN_v2_12_13.md` §2 `TDRG-OPEN-CHI-SCALING` — reference-only. TDR-24B's $\chi$ is not an independent scaling field on the stated corpus, but TDR-24B retains the clean-star-count-collapse derivation target (approximately $N^{-0.73}$ in that recorded scan). It is not absorbed into TDR-24A or closed by this update; no fit or discrete policy is imported into the continuous proof.

### §7.2 Revised source inputs and claim-level custody

The entries below identify the exact inspected source statements; no module or artifact identifier is borrowed as a theorem-specific RID. Requests beginning `REQ-T16-` are local governance tracking keys, not newly assigned Genesis RIDs. All uses remain conditional on the source model; this consumer does not promote its physical premises.

- `[DEF]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.1 #sec-6-1-primitive, Quadratic form | RID unavailable] **Metric definition.** $B$ and $Q(v)=v^TBv$ are the fixed primitive convention used in §§6.1/6.15–6.17. Source status: `[DEF]`. Depends on: the stated real two-component carrier. Verification: source-read; matrix properties rechecked in the new certificate. Governance: REQ-T16-METRIC; owner assignment pending.
- `[ALG]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.6 #sec-6-6-phase, Symplectic phase-drift operator | RID unavailable] **Oriented quarter-turn.** The stated $J_Q$, $J_Q^2=-I$ and $a^TBJ_Qb=(\sqrt3/2)\omega_{ab}$, with $\omega_{ab}=a_2b_1-a_1b_2$. Source status: `[ALG]`. Depends on: that $B$ and ordered wedge convention, not the differently normalized T-6d variable. Verification: source-read and exact algebra rerun. Governance: REQ-T16-JQ; owner assignment pending.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.3 #sec-6-3-triad, one-dimensional birth theorem | RID unavailable] **Leading admissible birth family.** $c_0=\kappa Q_sJ_Qs_*+O(\|s_*\|^5)$ and $Q_c=\kappa^2Q_s^3+O(Q_s^4)$. Source status: `[THM]`. Depends on: the source admissible pure-transverse family and fixed nonzero real $\kappa$; physical event/residual/retention selection is not part of this import. Verification: source-read; leading algebra checked, historical microscopic proof not rerun. Governance: REQ-T16-BIRTH; owner assignment pending; `GEN-ART-PHI-2TO3` is an artifact locator only.
- `[ALG]` [scope: structure] [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.3 #sec-6-3-triad, Shear policy | RID unavailable] **Shear reference.** $\kappa=-2\sqrt3/3$, $Q_c^{[\rm lead]}=4Q_s^3/3$. Source status: `[ALG structure]`, rendered canonically above without a grade change. Depends on: the chosen shear prescription and leading birth family. Verification: source-read and specialization checked. Governance: REQ-T16-SHEAR; no physical preference assigned.
- `[ALG]` [scope: structure] [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.3 #sec-6-3-triad, Recoil policy | RID unavailable] **Recoil reference.** $\kappa=-1/2$, $Q_c^{[\rm lead]}=Q_s^3/4$. Source status: `[ALG structure]`. Depends on: the chosen recoil prescription and leading birth family. Verification: source-read and specialization checked. Governance: REQ-T16-RECOIL; no physical preference assigned.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.4 #sec-6-4-tetrahedral, Tetrahedral chronological protection | RID unavailable] **Block order.** $G_2=0$ for the specified primitive six-step block; radial amplitude starts at quartic order. Source status: `[THM]`. Depends on: the source common linear block and chronological/parity construction, not an arbitrary post-birth map. Verification: source-read, not microscopically regenerated. Governance: REQ-T16-CHRONO.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.5 #sec-6-5-quartic, Full primitive quartic drift | RID unavailable] **Radial polynomial.** The printed $\mathcal P_4=2d^TBG_{3,d}$ is the input to the zero-apex derivative calculation. Source status: `[THM]`. Depends on: that six-step block, chronological protection, $B$ and wedge convention. Verification: complete polynomial inspected/transcribed, not a rerun of `genesis_k4_route_census.py`. Governance: REQ-T16-P4.
- `[ALG]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.5 #sec-6-5-quartic, Vector apex seeding | RID unavailable] **Generated vector seeds.** $Q(V_s)=7Q_s^3/1024$ and $Q(V_c)=61Q_c^3/34992$. Source status: `[ALG]`. Depends on: the preceding polynomial/block and its zero-apex derivative. Verification: source-read and independently re-extracted from those printed premises; `GEN-ART-G3D-SEED` is an artifact locator, not a result RID. Governance: REQ-T16-VSEED.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.6 #sec-6-6-phase, Birth symmetry theorem | RID unavailable] **Seeded cross-invariants.** $I_{V_s,s}=\omega_{V_s,s}=-Q_s^2/16$. Source status: `[THM]`. Depends on: the stated birth gauge and oriented source carrier. Verification: source-read; both identities and the local $D_{\rm birth}$ evaluation rechecked. Governance: REQ-T16-BSYMM; `GEN-ART-JQ-PHASEDRIFT` remains only an artifact locator.
- `[DEF]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §2 OPEN-GEN-II-HINDEX, displayed norm and status-table definition row | RID unavailable] **HINDEX norm definition.** $\|H\|_B^2=\lambda_{\max}(B^{-1}H^TB^{-1}H)$ for the stipulated covector-valued source block. Source status: the definition row is `[DEF/ALG]`; only that definition is imported, while local consequences have their own `[ALG]` statements. Depends on: input metric $B$ and output covector metric $B^{-1}$. Verification: exact source row inspected; local coherent-family calculation rerun. Governance: REQ-T16-HINDEX; `GEN-OPEN-HINDEX` is a module locator, not a substitute claim RID. No proof that a physical child seed equals this source operator is imported.
- `[THM]` [import: RTG_GENESIS_GEOMETRY_DSN_v2.8.4 §6.5 #sec-6-5-quartic, standalone chiral admissibility polynomial | GEN-THM-DELTA-QC] **Standalone radial input for consistency notice CN-03.** $P_c=Q_c^2/3+(I_{sc}+\omega_{sc})^2/4+5\omega_{sc}^2/16$. Source status: `[THM]`. Depends on: the stated standalone branch and primitive wedge convention. Verification: source-read; the $I_{sc}=0$ sign-even specialization is checked locally. This does not import the downstream GSPLIT interpretation back into Triadic.

**Claim-level proof direction:** Genesis primitive definitions/theorems → Triadic successor algebra → Genesis/OPEN-M consumer applications. The frame-map, GSPLIT interface conclusion and RRF are reference-only pointers. `apex_ratio_setup.py` is consumer-side verification if recovered, not a source of ownership; it and the microscopic route census are not present in the supplied package. The three historical Triadic certificates, in contrast, have been recovered and rerun with their original bytes (§8).

### §7.3 Exports — adopted v1.6; consumer synchronization pending

Current adopted exports available to Genesis/OPEN M; local consumer acceptance remains pending:
- [RID: TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN] :: fixed-direction reference angle and producer-frame turn polynomial; **not** a current wedge or route obstruction.
- [RID: TRIAD-ALG-T6E-ORIENTATION-NORMALIZATION] :: recovered producer convention and rate conversion; diagnostic correction only.
- [RID: TRIAD-ALG-T6L-NORMALIZED-TORSION-SIGN] :: corrected leading sign-definite torsion; finite-$u/r$/global dynamics OPEN.
- [RID: TRIAD-EXPORT-PROTOCOL-2] :: current export protocol, replacing historical obstruction exports.
- [RID: TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY], [RID: TRIAD-ALG-T6T-JACOBI-MODE-SIGNS], [RID: TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC] :: adopted successor exports at their r3 scopes.

Historical export RIDs `TRIAD-ALG-SAFETY-WEDGE`, `TRIAD-ALG-VERDICT`, `TRIAD-ALG-T6M-BIRTH-OBSTRUCTION`, `TRIAD-NUM-T6J2-NO-BASIN` and `TRIAD-EXPORT-PROTOCOL-1` remain retrievable in the base/history but are not current export permissions.

### §7.4 Consumer correction notices — scientific reconciliation pending

`[DEF]` These notices are outbound review obligations, not amendments of another owner's records. Consumer acceptance remains OPEN until each owner records disposition against the adopted Triadic version/hash.

**CN-01 — Genesis apex-slot identification.** Target: Genesis v2.8.4 §2 / §8 `GEN-OPEN-APEX-SLOT`, its summary and the inference that the residual source deficit is localized to that transverse slot. Each of $s,c,d$ takes values in the same two-dimensional $B$-carrier $V\cong\mathbb R^2$, while the three Jacobi mode blocks form $V^3\cong(\mathbb R^2)^3$ (§6.4). For $s\ne0$, $s,J_Qs$ span one copy of $V$, not the six-dimensional product state. No nonzero vector in that single carrier is $B$-orthogonal to both. Jacobi coefficient-row orthogonality is in node-label space and cannot by itself establish a third geometric direction in $V$. The distinct $d$-mode block and its certified primitive seed remain intact. Identifying that block with a physical transverse/out-of-plane SG-7/UV direction requires an explicit enlarged embedding, metric and source map. Review withdrawal/narrowing of the unsupported slot identity and dependent localization claims, not removal of the $d$ block. This is reference-only notification: no `GEN-OPEN-APEX-SLOT` claim is imported as proof. **Consumer status: OPEN; scientific review, not a pointer-only update.**

**CN-02 — Genesis WPHASE and dependent OPEN-M uses.** Targets: Genesis v2.8.4 §2 / §8 `GEN-OPEN-WPHASE` and `GEN-ART-WPHASE` (§8, source line 907); OPEN M v0.6 AUDIT-1-DIMENSIONAL/R-CHIRALITY-CLOSURE and summaries using the old unit ratio as a physical child ratio. Let $\mu_6=-1/2-2i\sqrt3/3$ as in the inherited cubic record (§7.1), and distinguish the face-phase diagnostic $F_{\rm face}$ below from the return map also denoted $F_W$ in other studies:
$$F_{\rm unit}=\frac\pi2+\arg\mu_6\approx-0.4086378551,$$
$$F_{\rm face}^{(0)}=-\frac\pi2+\arg\mu_6\approx-3.5502305087\equiv2.7329547985\pmod{2\pi}\qquad(\kappa<0).$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; fixed eigenframe; leading signed-child phase diagnostic)
`[ALG]` The leading signed factor has constant phase for fixed sign of $\kappa$; both registered policies are negative. A positive-$\kappa$ policy shifts this phase by $\pi$. The full family obeys $F_{\rm face}=F_{\rm face}^{(0)}+O(Q_s)$, unless higher-order directional preservation is separately established. Thus leading phase-amplitude independence survives, but the amplitude ratio $i\kappa Q_s+O(Q_s^2)$ is not amplitude-sterile, and exact full-phase independence is not proved. This sign correction agrees with the declared T-6m reference angle; it does not rederive its flow or select a physical energy-to-source relation. Genesis should rename its face-phase symbol to $F_{\rm face}$, or annotate it unambiguously at every live use, to distinguish it from the six-step return $F_W$ in Dyadic/RECOG/RRF. The `GEN-ART-WPHASE` entry still lists the retracted $F_W(\eta_*)$ target as `[OPEN]`; reconcile that artifact description with the withdrawn parametrization while retaining its history. A convention-only notation entry may be proposed to RRF; no RRF profile or claim is registered here. **Consumer status: OPEN; update sign, extent, symbol and artifact interpretation at each use.**

**CN-03 — Positive GSPLIT consistency, without reverse proof dependency.** Reference target: Genesis v2.8.4 `GEN-OPEN-WPHASE-GSPLIT`. The load-bearing input is the upstream standalone polynomial `GEN-THM-DELTA-QC` imported in §7.2, not the downstream interpretation. At $I_{sc}=0$, the primitive Gram identity gives $\omega_{sc}^2=4Q_sQ_c/3$ and hence
$$\left.P_c\right|_{I_{sc}=0}
=\frac13Q_c^2+\frac9{16}\omega_{sc}^2
=\frac13Q_c^2+\frac34Q_sQ_c.$$
(rep: [UNREGISTERED-TRIADIC-PRIMITIVE]; sign-even algebraic specialization of the imported standalone polynomial)
`[ALG]` This expression is unchanged by the child sign reversal $\omega_{sc}\mapsto-\omega_{sc}$. It supports retaining the GSPLIT polynomial across the directional correction; it does not determine any other amplitude interpretation. This check requires the exact $I_{sc}=0$ diagnostic, not every higher-order birth completion. **Consumer status: positive consistency notice; no Genesis record altered.**

**CN-04 — OPEN-M reliance on the withdrawn T-6t physical reading.** Targets: OPEN M v0.6 HYP-M-PREFRACTURE's premise “mechanism present (T-6t apex independent)” and the “3-for-3” R-CHIRALITY-CLOSURE summary, together with its T-6s/T-6u imports. The successor T-6t supports freely signable mode labels within the stated incidence reduction, not a physically independent transverse source mechanism. Review that premise and narrow “free-not-constrained chirality” accordingly. Keep the seed table distinct from HINDEX, restrict the coherent no-gain statement to its declared interval, and apply CN-02 to WPHASE-based reasoning. This neither falsifies nor validates the broader pre-fracture hypothesis; it withdraws the claimed support supplied by the old reading. No OPEN-M deficit, SU(2) amplitude bridge, physical source realization or target is newly certified here. **Consumer status: OPEN, scientific reconciliation required.**



**CN-05 — T-6 orientation-normalization correction: sector, wedge, basin and obstruction imports**

**From:** Triadic v1.6, adopted owner release of accepted r4.2 science; exact source identity is in `records/OWNER_ADOPTION.json`. **To:** Genesis Geometry (OPEN 1T, phase-moment restrictions, OPEN K, any cascade-exclusion inference), OPEN M, Programme Overview and OFN (pass two), RRF (convention record only). CN-01–CN-04 remain in force; CN-05 adds a separate source correction.

**What changed.** The recovered producers show that the T-6 independent-orientation diagnostics used the raw-determinant increment as the rate of the normalized orientation Ω. The correct rate is $\Delta\Omega=-\sqrt3\,\Delta\omega_{\rm raw}$. In the corrected field, $K=1$ is tangent ($\dot K=0$), and the leading large-$u$ torsion is sign-definite with no real wedge root.

**What did not change.** The T-6d root-closed model is consistent and retained. CN-05 does not invalidate T-6d, the T-6m quarter-turn, T-6s/t/u, Genesis primitive $\mathcal P_4$, GSPLIT or OPEN 1C.

**Required review by consumers.** Every live import of the following must be re-reviewed and replaced, narrowed or retained with a declared scope:
1. the $K=1$ inward/outward sector classification, the ~22° radial arc and any fatal-impact test;
2. the 5.5° safety wedge, $x_*$ as a current threshold, and the safety-window/phase-steering synthesis;
3. T-6j/T-6j2 no-safe-basin, 0/120-safe and fatal/impact classifications;
4. T-6m's wedge comparison, the ~15× argument, and any closure of the continuous birth route based on it;
5. T-6p obstruction exports, including the statement that the continuous branch is closed as a cascade route by phase steering.

**Specific notes.**
- *Genesis OPEN 1T:* the imported "obstruction verdict" and "necessary safety window" no longer have current support. Do not substitute a rescaled wedge or rescaled trajectories.
- *OPEN M:* any statement that orientation steering has already excluded the continuous phase/source route must be reconciled. The corrected tangency is not a new proof of stability, escape, source adequacy or gauge. T-6u's primitive apex-seed weakness is unaffected and independent. CN-01's apex-slot review remains separately required.
- *Programme / OFN:* distinguish corrected local algebra, numerical outcomes of the former mis-scaled model, and physical interpretation. No programme-level cascade verdict, source deficit or ontology selection follows from this correction alone. The continuous-cascade question returns to unresolved amplitude dynamics and model correspondence in the retained root-model diagnostic; it is settled neither for nor against.
- *RRF (convention proposal only):* record $B_T^{\rm plane}=2B_G$, $Q_T=2Q_G$, $I_T=2I_G$, $\Omega_T=-\sqrt3\,\omega_{\rm raw}$ for identical planar vectors, as a typed metric convention. Not a generator, mode, event or apex bridge. Same-vector transport would change birth coefficients ($Q_c^T=\tfrac{\kappa^2}{4}(Q_s^T)^3$); record this as an obligation, do not apply it.
- *Unchanged and separate:* the 96:1 same-object identification remains OPEN.

**Acknowledgment fields** (each consumer): source version/hash and adopted correction RID; affected local claims and locations; disposition per claim; remaining gates; accepting owner and date. This notice records no consumer decision.

### Export protocol

`[DEF]` **Two-pass handoff.** Exact r4.2 revision-editor review is accepted and this owner release is issued at the user's instruction. Next synchronize Genesis and OPEN M against this release's version/hash and route the convention-only items to RRF; Programme/OFN pass two follows. No consumer file or RRF profile is changed by this release.

`[DEF]` Genesis may import only the current items in §6.14/§7.3. Historical safety-wedge/no-basin/phase-steering obstruction exports are withdrawn from current use pending consumer reconciliation.

`[DEF]` No Triadic result selects a TDR-G policy without a named discrete-continuous bridge theorem.

---

## §8. Artifact Registry {#sec-8-artifacts}

**Closed-module proof-source placeholders** (proof-source reference required for archival):
- [RID: TRIAD-ART-T1-K3-PUMP] :: T-1 quartic secular pump extraction and full-return healing comparison :: `[ALG]` `[scope: limited]` — proof-source reference required
- [RID: TRIAD-ART-T2B-DIAG-BIRTH] :: T-2b rigid diagonal birth-gauge lift audit :: `[ALG]` `[scope: rigid diagonal birth gauge / implemented loading family]` — proof-source reference required
- [RID: TRIAD-ART-T4H-ESCAPE] :: T-4h reduced Race-A finite-$Q_d$ escape-threshold computation :: `[NUM]` — proof-source reference required
- [RID: TRIAD-ART-T6A-RETURN] :: T-6a0/T-6a1/T-6a2 six-step diagonal return and orthogonal Race-A reduction :: `[ALG]` `[scope: diagnostic]` — proof-source reference required
- [RID: TRIAD-ART-T6C-CROSSPHASE] :: `tetrahedral_six_step_cross_phase_t6c2_patched.py` :: recovered bytes SHA-256 `afb4525ccc2f459964fc3e9acade004f2aa61c03be2366f125cef63fc466d80e`; T-6c2 $\Delta I_{sc}$ extraction in normalized producer variable $\Omega$ :: `[ALG]` `[scope: diagnostic]`
- [RID: TRIAD-ART-T6E-OMEGA] :: `tetrahedral_six_step_omega_t6e.py` :: recovered bytes SHA-256 `98e4b0b033c2592b6a084006ab51283092238f291f5b455f1aa2e23b7af82d59`; raw determinant extraction retained, downstream normalized-rate interpretation corrected :: `[ALG]` `[scope: diagnostic]`
- [RID: TRIAD-ART-T6G-SQUARES] :: T-6g large-$u$ self-limiting square identities $A_2\le0$, $B_1\le0$ :: `[ALG]` `[scope: diagnostic]` — proof-source reference required

**Numerical ODE artifacts:**
- [RID: TRIAD-ART-T6B-ODE] :: `t6b_orthogonal_ode.py` :: Radau ODE for orthogonal Race-A axis-reduced system; T-6b protocol :: `[NUM]` `[scope: diagnostic]`
- [RID: TRIAD-ART-T6D-ODE] :: `t6d_generalized_ode.py` :: Radau ODE for generalized four-variable system with event guards; T-6d/T-6d2 protocol :: `[NUM]` `[scope: diagnostic]`
- [RID: TRIAD-ART-T6F-ODE] :: `triad_direct_orientation_ode_t6f_v2.py` :: recovered historical executed-model orientation chart; current corrected-model interpretation withdrawn :: `[NUM]` `[scope: historical diagnostic]`
- [RID: TRIAD-ART-T6H-ODE] :: `triad_free_qc_dimensionless_ode_t6h_v2.py` :: recovered historical executed-model independent-orientation flow; current corrected-model interpretation withdrawn :: `[NUM]` `[scope: historical diagnostic]`
- [RID: TRIAD-ART-T6I-MAP] :: recovered T-6i/T-6i2 sector-map producers :: historical mis-scaled $K=1$ sector artifact; not current corrected-model evidence :: `[NUM]` `[scope: historical diagnostic]`
- [RID: TRIAD-ART-T6J-BASIN] :: `triad_safe_arc_basin_search_t6j.py` :: recovered historical executed-model basin search, SHA-256 `5b75db2d7c4663402a7bd068d141e49ae49aac705e1c3d29024f75af29bbf697`; current interpretation withdrawn :: `[NUM]` `[scope: historical diagnostic]`
- [RID: TRIAD-ART-T6K-STEER] :: recovered T-6k/T-6k2 phase-steering producers :: historical mis-scaled orientation model; current interpretation withdrawn :: `[NUM]` `[scope: historical diagnostic]`
- [RID: TRIAD-ART-T6L-TORSION] :: `triad_analytic_phase_steering_t6l_patched.py` :: recovered historical algebra, SHA-256 `2e0317bf90332d1fe0ab7489710a3c8c67b772e3031dd7ef95b3163f7d7a11cd`; old $x_*$ retained as historical mis-scaled algebra only :: `[ALG]` `[scope: historical diagnostic]`
- [RID: TRIAD-ART-T6M-BIRTH] :: session-certified T-6m computation (no standalone script; canonical computation in session log) :: Birth angle, branch assignment, finite-$u$ torsion turn; T-6m :: `[ALG+NUM diagnostic]`
- [RID: TRIAD-ART-T6J2-PROXY] :: historical session-only T-6j2 record; script/event log unavailable :: retained torsional-excursion provenance only; safe/fatal/impact classification withdrawn :: `[NUM]` `[scope: historical root-closed session]`
- [RID: TRIAD-ART-T6-ORIENTATION-NORMALIZATION-V16] :: `triad_t6_producers.zip` SHA-256 `8ad574ff97938b3dac8f79f68bca0458bc0e768b3fdf5a12c46a28fafd98de69`; 25 producer scripts verified against `SHA256_MANIFEST.csv`; fresh `t6c2_out.json` SHA-256 `82451781d45e2af2bff311656b2046b02fad767ed1c2e2f5901766bd507aa414`; fresh `t6e_out.json` SHA-256 `288cd77da617a12022350f7902c01a1f4d02565298b84e101becb108f6e241db`; `triad_orientation_normalization_audit.py` SHA-256 `d5c0f698232cca6c2fe5d8321249e5d93f9bfe2c5288c7f918c3ef55d89a0e29`, 15/15 PASS, exit 0. Scope: recovered producer convention/output-type correction and corrected leading algebra; no historical trajectory rerun or physical model selection. Evidence-object clarification: N4a certifies the leading numerator coefficient (the scaled $K\dot\theta$ numerator), not $A_\theta=[u^1](\dot\theta/Q_s)$. The pinned audit bytes remain unchanged. Its Gram test consumes the archived T-6a2/T-6c radial ledgers; the named fresh T-6c2/T-6e executions do not regenerate those radial ledgers. The separate `scripts/triad_torsion_object_check_r4_2.py` (SHA-256 `bd9ae5d5bf8ecc598b99a12f1a061d04715e5abe7a971e7ff96aa0b6930b773e`; exact count/command/exit in `evidence/EXECUTION_MANIFEST_R4_2.json`) checks numerator versus angular-rate coefficient from the recovered T-6l coefficient assignments. It is a subfile of this evidence bundle, not a new scientific RID, microscopic extraction or numerical campaign.

**Recovered historical seam artifacts and new successor evidence:**

- [RID: TRIAD-ART-T6S-CHIRALITY] :: `triad_t6s_chirality.py` :: recovered original bytes, SHA-256 `0eb2fd1bf5ff3d44612b42428ee3285637ed09fbedc0585621daa55b69f325dc`; **11 executed checks, 11 PASS, exit 0**, rerun 30 September 2026. Original upload name `triad_t6s_chirality (2).py`; the archival basename copy is byte-identical. Bundle: `inputs/historical/triad_t6s_chirality.py`; command `python -B inputs/historical/triad_t6s_chirality.py`; separate logs and `RECOVERED_HISTORICAL_RUNS.json` in `evidence/`. **Historical evidence only:** Its $+i$ calculation tests the unit quarter-turn, not the scaled child. The code derives $(1-g_2)^2$ but does not prove an unrestricted no-gain inequality.
- [RID: TRIAD-ART-T6T-CHIRALITY] :: `triad_thread4_chirality_count.py` :: recovered original bytes, SHA-256 `e0718a25fa8d18338cb55d8fd84b13b17d72ecf6d1f5bd06a79b4b36a7afc909`; **13 executed checks, 13 PASS, exit 0**, rerun 30 September 2026. Original upload name `triad_thread4_chirality_count (2).py`; the archival basename copy is byte-identical. Bundle: `inputs/historical/triad_thread4_chirality_count.py`; command `python -B inputs/historical/triad_thread4_chirality_count.py`; separate logs and `RECOVERED_HISTORICAL_RUNS.json` in `evidence/`. **Historical evidence only:** The Gram rows are node-label coefficient rows. The historical physical-source/three-direction narrative is not reinstated. The prior 14-count was a reporting error: the concluding PROOF PASSED line is not a check.
- [RID: TRIAD-ART-T6U-APEX-SOURCE] :: `triad_t6u_apex_source.py` :: recovered original bytes, SHA-256 `435cf09964850626b08c6d7c59f6f93401cced554eff0cb023ce8f27cc96762f`; **8 executed checks, 8 PASS, exit 0**, rerun 30 September 2026. Original upload name `triad_t6u_apex_source (2).py`; the archival basename copy is byte-identical. Bundle: `inputs/historical/triad_t6u_apex_source.py`; command `python -B inputs/historical/triad_t6u_apex_source.py`; separate logs and `RECOVERED_HISTORICAL_RUNS.json` in `evidence/`. **Historical evidence only:** The shear/vector specialization is retained. U5/U6 contain numerical comparisons; this historical run is not relabeled an all-exact general certificate. Source-norm and universal-deficit narration is superseded by the typed successor diagnostic.
- [RID: TRIAD-ART-T6U-APEX-SEED-DIAGNOSTIC-V16] :: `triad_t6u_apex_source_v1_6.py` plus `triad_v1_6_r2_point_use_checks.py` and the written derivation :: **new v1.6 evidence bundle**, distinct from the three recovered historical artifacts. The primary checker retains its 47 mathematical assertions unchanged from reviewed r1; only docstring/evidence metadata are revised. Two assertions check reference-policy signs; another is an explicit domain counterexample. The companion checks the changed phase/GSPLIT/turn statements separately; exact measured counts and hashes are in `evidence/EXECUTION_MANIFEST.json` and `evidence/FILE_IDENTITIES.json`.
  - Custody and target: Triadic; successor claims `TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY`, `TRIAD-ALG-T6T-JACOBI-MODE-SIGNS`, `TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC` and the explicitly scoped consistency notices. No other study acquires ownership through verification.
  - Inputs: byte-pinned Genesis v2.8.4 source definitions and polynomial, Triadic v1.5 base, preserved r1 and recovered artifacts. New primary code is not a rerun or overwrite of the old eight-check implementation.
  - Arithmetic: rational/algebraic SymPy; exact acceptance identities and inequalities, displayed decimals excluded from acceptance. Fixed nonzero real $\kappa$ and positive leading $Q_s$.
  - Execution: `python -B scripts/triad_t6u_apex_source_v1_6.py --output evidence/t6u_certificate.json`; separate companion and historic runs via `scripts/run_all.py`; environment recorded in `environment.json`.
  - Negative controls: conflate the vector-state and increment-channel objects; deny the mixed-channel $Q_s^4$ coefficient. Each must fail at its named assertion with exit 1. Failure-gate tests do not count as extra positive checks.
  - Limits: no microscopic route-census rerun, physical lowering or seed-to-HINDEX identification, finite-amplitude error bound, exact all-order child direction, full next-block increment, source/gauge selection or cascade closure.
  - Review state: r1–r4 reviews and the supplied r4.1 review reports remain recorded at their scopes. R4.2 corrects the subsequently identified torsion object label and evidence limitation; exact r4.2 sign-off is accepted and owner adoption/publication is recorded separately; consumer acceptance remains pending. T-6u mathematics and pinned evidence are unchanged.


---

`[DEF]` **R3 verification addendum.** The primary T-6u script and `T6U_PROOF_AND_SCOPE.md` are preserved byte-for-byte from reviewed r2; the primary report's older review-status text is historical metadata, not the present adoption decision. The separate `triad_v1_6_r3_scope_checks.py` checks the carrier/product distinction and both quarter-turn orientations; `validate_r3.py` checks declared edits and live-use scope. The unchanged r2 16-check companion, 55-check validator, asserted-edit record, recovered historical-run manifest and r1→r2 diff are all included under `inputs/r2/` in the r3 package. Fresh r3 execution and integrity manifests are separate. No numerical trajectory or microscopic coupled map is certified by these additions.

`[DEF]` **R4.2 review-closure and owner-release addendum.** The supplied r4.1 sign-off and the subsequent numerator/angular-rate objection are preserved as review history. The recovered T-6l producer confirms division by $K$ before defining its angular-rate coefficient. R4.2 resolves that object-label conflict, clarifies N4a and the radial-ledger dependency, and preserves the existing result identities, sign conclusion and T-6u content. Exact r4.2 sign-off is accepted. The subsequent user-directed owner release is recorded in `records/OWNER_ADOPTION.json`; original candidate and packaging-time pending records are preserved unchanged. Consumer acceptance remains pending.

## §9. Collaboration and Provenance {#sec-9-provenance}

**Principal investigator:** Mustafa  
**AI / collaborator roles:** Claude · ChatGPT · Gemini · Grok  
**This release:** ChatGPT maintains the adopted v1.6 owner ledger and its evidence package. The accepted r4.2 scientific body is retained; only the metadata/lifecycle changes in `records/METADATA_EDITS.json` and the new release-history entry distinguish this file from the reviewed candidate. The user's immediate-update instruction is the release authorization recorded separately; no additional reviewer signature or consumer decision is inferred.  
**Source custody:** Triadic owns T-6u's diagnostic; Genesis owns its raw polynomial/seeding inputs and may verify the ratio as a consumer. OPEN M consumes only the adopted scoped diagnostic. References to the Genesis frame-map and RRF are not new proof imports.  
**Evidence history:** The three original T-6s/T-6t/T-6u scripts were recovered in the supplied review and rerun unchanged: 11/13/8 checks. Their full hashes and historic interpretation limits are in §8. The r1 availability claim is corrected as a former local-access limitation, not a claim that those artifacts never existed. `apex_ratio_setup.py` and the microscopic route census remain unavailable in this package. The new v1.6 code is separately identified; no historical output sentence is silently adopted as the revised theorem. The peer explicitly accepted responsibility for the former unit/child, label/carrier and mixed-channel overstatements and the 13-to-14 count error; the received review is preserved in the evidence packet.
**Archive:** Historical project pointer inherited from v1.5: Zenodo DOI 10.5281/zenodo.17568897. No new archive deposit for this release is claimed.  
**Repository:** `rtg-resonance-2025`

---

`[COR]` **R4 recovered-producer provenance.** The orientation correction uses recovered disk bytes with recorded SHA-256 and last-write timestamps, fresh T-6c2/T-6e outputs, and an exit-gated 15-check audit. The fresh outputs are UTF-16LE text containing progress messages followed by JSON. Timestamp timezone was not recorded, so timestamps are provenance hints rather than authenticated execution identity. Historical T-6j2 session bytes/event log remain unavailable.

## Appendix A — Version History {#appendix-a}

### v1.6 owner release — 5 October 2026

- **Authorization:** the user directed immediate project-DSN updates beginning with Triadic. The recorded action publishes the revision-editor-accepted r4.2 content; the exact instruction, candidate hash and release hash are in the separate `records/OWNER_ADOPTION.json`.
- **Review:** exact candidate SHA-256 `420eaf3e0b98ee150d4a44de805480ae05764f6bdcac753a9c73e14e0e5a9bf0` was accepted by the reported revision editor with peer concurrence before this release. No new scientific review or candidate revision is claimed.
- **Delta:** release metadata and the already accepted owner-side RID/replacement lifecycle are currentized. All mathematical displays, all 49 RIDs, scientific grades, accepted scope qualifications, and certificate bytes remain unchanged. Earlier draft history and pending-at-packaging status records remain immutable.
- **Owner selection:** v1.6 supersedes v1.5 as the Triadic source in the supplied release records; the v1.5 file is retained byte-for-byte as history. This local file release does not claim a remote repository commit or an archive deposit.
- **Consumers:** CN-01–CN-05 initiate the existing reconciliation queue; no consumer approval, Genesis/OPEN-M/RRF amendment, or Programme/OFN pass-two completion is recorded.

### v1.6 DRAFT r4.2 — 5 October 2026 — torsion-object and evidence-scope repair

- **[COR] Object definition:** r4.1 labeled the $K$-weighted numerator coefficient as the angular-rate coefficient and called the $K$-free expression a boundary specialization. The recovered T-6l producer divides by $K=\mu^2+\nu^2$ before its angular-rate extraction. R4.2 distinguishes $B_\theta^{\rm corr}=K A_\theta^{\rm corr}$ from $A_\theta^{\rm corr}$ at current use; the sign, ratio polynomial and discriminant are unchanged.
- **Evidence scope:** N4a's pinned bytes certify the numerator; its output label is clarified externally. The Gram identity uses archived T-6a2/T-6c radial ledgers, not regenerated by the named extraction evidence. A separately identified numerator/rate checker is added to the existing artifact bundle without assigning a new RID.
- **Preservation:** all r4.1 RIDs, T-6u mathematics and primary/normalization audit bytes remain unchanged. All earlier version-history bodies remain immutable. No microscopic extraction, phase sweep or corrected trajectory campaign was performed for this repair.
- **Review/adoption:** exact r4.2 revision-editor review and PI/authorized-owner adoption remain pending. No prior review report is rewritten or treated as adoption.

### v1.6 DRAFT r4.1 — 1 October 2026 — final-candidate current-use/evidence repair

- **[COR] Torsion coefficient:** restore the positive factor $K=\mu^2+\nu^2$ in the unrestricted corrected leading coefficient; retain the $K=1$ specialization, ratio polynomial and no-real-root conclusion.
- **[COR] T-1 status:** replace the stale global-explosiveness `[FAIL]` summary by the current statement that the inference is withdrawn/not established and the 96:1 same-object correspondence remains OPEN.
- **Lifecycle/current-use:** align the §6.18 per-module summary with already proposed successor RIDs and remove obsolete drafting leftovers.
- **Evidence:** remove the unnamed receiving-side cubic-jet clause from the load-bearing §6.18 evidence paragraph; recovered producers, fresh extraction outputs and the pinned 15-check normalization audit remain the named evidence.
- **Review metadata:** update §6.17, §8 and the footer to the completed r4 revision-editor state; T-6u scientific/mathematical content remains unchanged from r3.

### v1.6 DRAFT r4 — 1 October 2026 — model/state-contract and orientation-normalization correction

- **Recovered-source `[COR]`:** T-6c2 normalized orientation $\Omega$ and T-6e raw determinant $\omega_{\rm raw}$ distinguished; $\Delta\Omega=-\sqrt3\Delta\omega_{\rm raw}$ installed at current use.
- **Model contracts:** root-closed, historical independent-orientation, corrected coefficient extension and historical T-6j2 session model are separated; $\mathcal B_{\rm root}$ and $\mathcal B_K$ no longer share one name.
- **Current-result narrowing:** historical T-6f/h/i/j/k/l sector/wedge/basin interpretations withdrawn for the corrected model; T-6j2 becomes a PARTIAL historical excursion result; T-6m wedge/route obstruction withdrawn while quarter-turn and producer-frame polynomial survive.
- **New algebra:** corrected $K=1$ tangency and positive-definite leading torsion recorded; historical $x_*$ retained only as executed-model algebra.
- **T-1/96:** exact coefficient ratio retained, same-system dominance correspondence left OPEN.
- **T-6p/CN-05:** obsolete obstruction exports removed; Genesis/OPEN-M/Programme/OFN/RRF reconciliation expanded.
- **Notation:** apex governor coefficient repaired to $D_4=-32$; reference-transport/source-operation guard SG-18 added.
- **Preservation:** T-6s/t/u successor mathematics, primary T-6u certificate and §§6.15–6.17 remain unchanged from r3.

### v1.6 DRAFT r3 — 30 September 2026 — focused review response
- **[COR] CN-01:** distinguish one two-dimensional $B$-carrier from the six-dimensional three-mode product; preserve the $d$-mode block and its seed while retaining the scientific review of unsupported UV-slot identification.
- **[COR] T-6m:** remove the physical-birth-route interpretation from current module, guard, risk, body and export uses. Retain the same conditional RID and numerical/algebraic diagnostic, with exact reference input $\Phi_{sc}(0)=-\pi/2$; no physical residual, $\kappa$, retention or higher-order directional preservation is selected.
- **[COR] Orientation:** replace the erroneous anti-$J_Q$ route description by near-collinear/near-aligned orientation; neither quarter-turn sign meets the low-$|\omega|$ condition. Existing equations and numerical values are unchanged.
- **[COR] Summary grade:** restore the combined necessary safety window to `[RESULT]` `[from: NUM]` with diagnostic/necessary-only scope, reflecting the numerical radial component plus algebraic torsion boundary. The revised T-6m consequence uses the same canonical source-status rendering for its retained algebraic/numerical synthesis, not a new numerical campaign or a new claim RID.
- **Consumer follow-through:** CN-02 now requests the Genesis face-phase symbol distinction and reconciliation of the stale `GEN-ART-WPHASE` parametrization; any RRF entry remains convention-only and proposed.
- **Evidence and preservation:** the 47-assertion primary certificate and T-6u proof note are byte-identical to r2; the original r2 16-check companion and 55-check validator are preserved with the complete r2 package. New r3 scope/point-of-use checks and an r2→r3 edit manifest are separate. All old history bodies, predecessor RIDs and successor identities remain unchanged. No owner adoption has occurred.

### v1.6 DRAFT r2 — 30 September 2026
- **State:** successor proposal for revision-editor review, not adopted. V1.5 remains the owner file. Revised blocks follow Methodology v1.3 with the explicit bounded-migration declaration; no scientific retagging of unrelated modules.
- **RID lifecycle:** propose `TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY`, `TRIAD-ALG-T6T-JACOBI-MODE-SIGNS`, `TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC` as distinct successors. Original claims and all original RIDs remain in the historical record; replacement is effective only after adoption. The new evidence bundle has `TRIAD-ART-T6U-APEX-SEED-DIAGNOSTIC-V16`, alongside the recovered original artifacts.
- **[COR] Evidence:** original T-6s/T-6t/T-6u bytes recovered, hashed, inspected and rerun (11/13/8 checks). The v1.4 and r1 report of 14 Thread-4 checks counted the final status line; the true count is 13. The historical v1.4 sentence below is preserved as erroneous history, not a live count.
- **[COR] Current uses:** restore the established exact T-6m root; replace obsolete T-6j2/T-6m waiting language. §§6.2–6.14 are preserved except these three declared text repairs; no model, ODE or numerical campaign was rerun.
- **Imports:** split the Genesis birth-family, policy, chronology, radial, vector, birth-symmetry and norm records by their actual source status; exact missing-RID exceptions remain pending owner assignment. HINDEX is imported as a convention, not re-owned or inferred from a seed.
- **Consumer notices:** §7.4 requests scientific review of Genesis apex-slot localization and WPHASE sign/extent; records GSPLIT sign-even consistency; flags OPEN-M pre-fracture/3-for-3 reliance. These are not mere pointer updates and no consumer file is changed.
- **[COR] Phase extent:** the signed leading face phase differs by $\pi$ from the unit-direction reading for the two negative policies. The full asymptotic phase retains $O(Q_s)$ uncertainty without a directional theorem; exact all-order amplitude-sterility is not imported.
- **Preserved r1 science:** the typed vector/increment distinction, four leading ratios, strict $>6$ shortfall and mixed-channel coefficient remain unchanged. The 47 primary assertions are retained; evidence metadata and a separate point-use checker are updated.

### v1.6 DRAFT r1 — 30 September 2026 — draft history
- The original r1 and its exact diff/change record are preserved in `inputs/r1/`. It proposed the policy-parametric seed diagnostic, direction/carrier corrections and bounded migration.
- Revision-editor review accepted the mathematical core but required successor identities, canonical header/import grammar, current-use corrections and a shorter §1. The peer then recovered historical scripts and identified the count error and four consumer notices. This r2 incorporates those requirements; r1 acceptance is not adoption of r2.

`[COR]` **Historical count notice (r2):** the v1.4 entry below is retained verbatim. Its claimed correction from 13 to 14 was itself erroneous: the recovered script executes 13 checks, excluding the final PROOF PASSED line. The peer reviewer attributes that miscount to their v1.4 edit. The active artifact record in §8 is corrected.

### v1.5 — June 2026
- **§1/§2/§6.17/§7/§8 [NEW]:** T-6u — certified apex source ratio added and closed `[ALG diagnostic]` using `triad_t6u_apex_source.py` (8 checks, exit 0). From certified $\mathcal{P}_4$ seeds $Q_c^{\rm seed}=\frac43 Q_s^3$, $Q_d^{\rm seed}=\frac{7}{1024}Q_s^3$, the apex/in-plane seed-amplitude ratio is $\sqrt{21}/64\approx0.0716$, $\sim20\times$ below $\sqrt2$.
- **§6.17 [COR]:** the $B_3$-isometric apex-lift model ($\|H_{\rm apex}\|_B\approx1.488$) is **rejected** as a physical source estimate; the certified apex channel is a weakly seeded, self-damped torque channel, not a norm-preserving isometry.
- **§3/§5 [NEW]:** SG-17 and high-risk row added to prevent phrasing T-6u as "OPEN M closed," reusing the rejected model value, or bounding the non-$\mathcal{P}_4$ $\sigma_f$/UV source.
- **Net:** the apex (independent by T-6t) is too weak in the certified primitive channel to close the OPEN-M $\times2$ gap; reinforces that cascade requires a non-$\mathcal{P}_4$ OPEN-M $\sigma_f$ source (consistent with the isolated-$K_4$ saturation ceiling).

### v1.4 — June 2026
- **§6.15/§7/§8 [NEW]:** T-6s in-plane chirality-count certificate added and promoted to `[ALG, exact]` using `triad_t6s_chirality.py`; coherent in-plane source norm bounded by single-channel value.
- **§6.16/§7/§8 [NEW]:** T-6t Thread-4 mode-chirality count added and certified using `triad_thread4_chirality_count.py` (14 checks, includes canonical Gram reconciliation $RG_{\rm seq}R=\operatorname{diag}(2,\frac83,3)$); apex chirality is free and tetrad/apex ratio is well-posed but unevaluated.
- **§6.15 [NEW]:** consistency cross-reference to Genesis OPEN 5/2B-a (`GEN-OPEN-WPHASE-GSPLIT`) added — in-plane birth gap $\frac13 Q_c^2+\frac34 Q_sQ_c$ is coherent/amplitude-level, no additive $\times4$ channel; both route $\times4$ rescue to apex/incoherent.
- **§3/§5 [NEW]:** SG-15 and SG-16 added to prevent applying T-6s to incoherent/energy-level channels or T-6t independence to apex sufficiency. (SG-15 is Triadic-local, distinct from Genesis SG-15 which governs the Dyadic SU(2) import.)
- **[COR] encoding repair:** corrected control-character corruption (literal tab/CR/FF substituted for LaTeX `\to`, `\rm`, `\frac`, `\theta`, `\top`, `\times`, `\right` escapes) throughout §1, §5, §6.15, §6.16, §8; all math expressions re-verified well-formed and display-math delimiters balanced.

### v1.3 — June 2026
- **Header/§1/§2 [NEW]:** T-6j2 closed as `[NUM diagnostic]` under the $K=1$ Plücker-circle proxy; T-6p closed as export protocol; active triadic queue reduced to non-blocking completions T-6r/T-6q/T-6m2.
- **§3/§5 [NEW]:** SG-14 and high-risk row added to prevent overclaiming T-6j2 as a monotone bound on $K_{\rm init}=0.25$ interior seeds.
- **§6.13 [NEW]:** T-6j2 result recorded: $0/120$ safe, torsional ejection from $[0°,5.5°]$ to fatal impact sectors.
- **§6.14/§7 [NEW]:** T-6p export protocol recorded: Genesis may import obstruction verdicts only, not a sufficient escape basin.

### v1.2 — June 2026
- **§6.12 [COR]:** Added explicit T-6d vs RTG canonical $\omega_{sc}$ convention annotation. The values $\nu_0=-1$ and $K_{\rm birth}=1$ are now scoped to the T-6d convention; $\theta_{\rm birth}=-90°$ is recorded as convention-independent.
- **§6.12 [ALG]:** Replaced numerical torsion-turn value with exact root $Q_s^{\rm turn}=(2\sqrt7-1)/6\approx0.71525$.
- **§6.4/§6.7/§8 [COR]:** Removed ambiguous additive notation in $\Delta Q_d^{(2)}$, added T-6j2 expectation note, and corrected the T-6m artifact entry to session-certified/no standalone script.
- **§3/§7 [COR]:** Added cross-convention warning to SG-12 and the import ledger.

### v1.1 — June 2026

- **Header/§1 [NEW]:** T-6m birth-policy phase-angle audit incorporated; active frontier updated from T-6m/T-6j2 to T-6j2/T-6m2/T-6p.
- **§2 [CLOSED]:** T-6m moved from ACTIVE to CLOSED `[ALG+NUM diagnostic]`; T-6m2 added as low-priority Race-A apex correction check.
- **§3/§5 [COR]:** Scope guards and high-risk claims updated to distinguish certified $J_Q$ birth obstruction from global sign-sector or alternative-birth-policy claims.
- **§6.12 [NEW]:** Birth state $(\mu_0,\nu_0)=(0,-1)$, $K_{\rm birth}=1$, $\theta_{\rm birth}=-90°$, $Q_s^{\rm turn}\approx0.715$, and certified continuous $J_Q$ route obstruction recorded.
- **§7/§8 [NEW]:** T-6m export and artifact entries added.

### v1.0 — June 2026

Full refactor to DSN_METHODOLOGY_v1.2 architecture. Active scientific ledger content preserved; structure changed throughout.

Errata applied before canonical freeze:
- **Header/§1/§6.11 [COR]:** "effective escape wedge" renamed to "necessary continuous safety wedge"; sufficiency caveat added throughout.
- **Scope header [COR]:** "torsion-safe escape geometry" → "torsion-safe window geometry".
- **Local Tag Aliases [COR]:** `[COR]` row removed; canonical-tag DEF note added; diagnostic aliases clarified as permitted inside document.
- **§1 [COR]:** T-2b retagged `[scope: rigid diagonal birth gauge / implemented loading family]`; "tested loading ratios" → "implemented loading family".
- **§1 [COR]:** T-6l entry reworded with folded first-quadrant phase-convention guard for $x_*$.
- **§1 [COR]:** Cascade-obstruction claim retagged `[ALG/NUM synthesis]`; scoped as diagnostic verdict.
- **§2 [COR]:** T-6m question and required items reworded with folded-convention qualifier; Connection changed from "direct bridge" to "candidate bridge target".
- **§2 [COR]:** T-6o changed from ACTIVE to PARTIAL; closed/active sub-items added.
- **§2 [NEW]:** OPEN T-6p (Genesis export sufficiency criterion) added.
- **§2 [NEW]:** OPEN T-6q (phase-convention and sign-sector extension) added.
- **§3 [NEW]:** SG-12 added — $x_*$ valid only in folded first-quadrant convention with $\mu>0$.
- **§4 [COR]:** Escape geometry layer row and routing rules updated with SG-12 reference.
- **§5 [COR]:** High-risk table wedge row renamed; $x_*$ phase-convention row added; section references corrected.
- **§6.1 [COR]:** T-2b scope qualifier and wording updated.
- **§6.9 [COR]:** T-6l $x_*$ derivation adds folded first-quadrant convention guard.
- **§7 [COR]:** Inherited scope block added; export RID renamed TRIAD-ALG-SAFETY-WEDGE.
- **§8 [COR]:** Artifact registry tags converted to canonical `[NUM]` / `[ALG]` `[scope: diagnostic]` forms.
- **AI Context Core marker:** Inserted at end of §4.

Final errata applied before freeze:
- **Status summary [COR]:** "closed at diagnostic grade" → "closed as a diagnostic evidence chain, not as a global escape/annihilation theorem."
- **§1 [COR]:** Decorative box removed from cascade obstruction claim; replaced with prose verdict scoped to continuous branch.
- **§2 OPEN T-6m [COR]:** Status line changed from "BLOCKS...TDR-G policy bridge" to "pre-bridge input to possible TDR-G policy bridge."
- **§2 OPEN T-6j2 [NEW]:** "Safe arc" definition added locally (folded first-quadrant $\dot K < 0$ sector).
- **§2 closed modules [COR]:** T-2b scope qualifier added.
- **§3 [NEW]:** SG-13 added — Genesis may import Triadic outputs only as diagnostic constraints until T-6m/T-6j2/T-6p close.
- **§6.2/§6.3/§6.4/§6.7/§6.8/§6.9 [COR]:** Section headings marked `/ mixed`.
- **§6.5 [NEW]:** Exact algebraic chiral motor value at $I_{sc}^*$ equilibrium added: $5\sqrt{14}\omega_{sc}^* - \sqrt{42}I_{sc}^* = \frac{35\sqrt{2}}{\sqrt{67}}\sqrt{Q_sQ_c} > 0$.
- **§7 [NEW]:** Export protocol block added (three `[DEF]` entries).
- **§8 [NEW]:** Proof-source placeholder RIDs added for T-1, T-2b, T-4h, T-6a, T-6c, T-6e, T-6g.
- **Appendix B [COR]:** `[COR]` retired-claim entries converted to `[RETRACTED]` with reason format.

### v0.15 — May 2026

- Incorporated T-6d through T-6l.
- "Orientation avalanche" and "universal annihilation" readings replaced by refined mechanism.
- Large-$u$ chiral loading confirmed as leading-order self-limiting ($A_2 \le 0$).
- Plücker boundary confirmed sectoral; safe arcs narrow to $\theta \lesssim 22°$.
- Leading torsion wedge $x_* \approx 0.0963$ algebraically extracted (T-6l).
- Necessary continuous safety wedge narrowed to $\theta \in [0°, 5.5°]$ as intersection of radial and torsional safety; sufficiency remains open under T-6j2.
- Safe-wedge coverage clarification for T-6j $\theta_0=0.01$ seed.
- Full-torsion caveat added to $r^2$-channel $I_{sc}^*$ equilibrium.
- T-6m and T-6j2 registered as immediate frontier.

### v0.14 and earlier

- T-6a through T-6k incorporated progressively.
- Global $K_3$ explosiveness overclaim introduced and revoked.
- Orientation-avalanche interpretation introduced and revoked.
- T-6f constrained-chart runaway scope clarified.
- Orthogonal-slice non-invariance established.

---

## Appendix B — Retired and Rejected Claims {#appendix-b}

### Adopted v1.6 successor lifecycle

`[DEF]` The following reviewed replacements are adopted in v1.6; they are not renamings or reuses of old identities. V1.5 is preserved as the superseded owner history. Old proposition text and original verdicts remain retrievable in the immutable base; the short descriptions below identify the changed scope. The original scripts remain byte-identical in §8, even where their printed narratives overstate what their checks prove.

| Historical RID | Original recorded verdict / proposition | Adopted successor and status | Reason |
|---|---|---|---|
| [RID: TRIAD-ALG-T6S-INPLANE-CHIRALITY] | CLOSED, `[ALG]` with historical exact/conjugate-family wording; unit $+i$ described as the child and unrestricted no-gain inferred | `TRIAD-ALG-T6S-COHERENT-CONJUGATE-FAMILY`, `[ALG]`, adopted | Physical child scaling/sign and coherent-weight domain materially narrow the assertion; conjugate-pair algebra survives. |
| [RID: TRIAD-ALG-T6T-CHIRALITY-COUNT] | CLOSED, `[ALG]` with historical 3D chirality/apex-independence wording | `TRIAD-ALG-T6T-JACOBI-MODE-SIGNS`, `[ALG]`, adopted | Three label-sign choices do not establish an independent physical transverse source direction. |
| [RID: TRIAD-ALG-T6U-APEX-SOURCE] | CLOSED, `[ALG]` diagnostic; shear/vector $\sqrt{21}/64$ used as certified apex source ratio | `TRIAD-ALG-T6U-APEX-SEED-DIAGNOSTIC`, `[ALG]`, adopted | Four typed leading diagnostics replace the single-source/deficit interpretation; no HINDEX identity. |

`[COR]` **Thread-4 evidence count:** 13 executable assertions, not 14. The terminal status message is not an assertion. This repairs a count, not the preserved Jacobi algebra; the stronger physical interpretation is addressed by the distinct successor above.

### Adopted v1.6 corrections

`[COR]` **T-6u specialization and extent.** V1.5 used “certified apex ratio $\sqrt{21}/64$, approximately 20 times short” as the general headline. Retain it as shear/vector only; the adopted family/table is §6.17. The exact four-case bound is a leading diagnostic, not a full-return or physical source theorem.

`[COR]` **Numerator objects.** The factor-two source relation is retained but does not give two readings of one initial state norm. The vector seed and increment-channel diagnostic are different objects. The upgraded certificate distinguishes them at their definitions.

`[COR]` **Source interpretation.** The old “primitive apex cannot supply the missing amplitude” and “cascade requires a non-$\mathcal P_4$ source” conclusions exceeded what this seed comparison alone establishes. Their replacement is the conditional diagnostic of §6.17.4, not a universal OPEN-M or cascade verdict. The 1.488 isometric number is not restored as an established physical source estimate; neither is every possible enlarged-carrier model refuted.

`[COR]` **T-6s direction/weight.** The unit quarter-turn equality is not the child/parent amplitude ratio. The coherent operator identity needs $0\le g_2\le2$ for the no-gain inequality. The explicit source construction and its physical selection remain separate.

`[COR]` **T-6t label/carrier distinction.** Three orthogonal Jacobi rows are not a proof of three orthogonal directions in the common two-dimensional state carrier. Mode labels and primitive seed results are retained; physical embedding/HINDEX inference is not.

`[COR]` **R3 reference-event and carrier scope.** R2's CN-01 incorrectly let two vectors in $V\cong\mathbb R^2$ stand for a basis of the full $V^3$ mode product; the current notice preserves all three mode blocks. The retained live T-6m text also called its fixed-direction diagnostic a closure of the physical birth route. That inference is withdrawn: the exact reference angle and model/mirror premises remain conditions, while the complete birth law is unselected. The earlier anti-$J_Q$ wording is replaced because both quarter-turn signs are transverse rather than near-collinear. The necessary-window summary's unintended `[from: HEUR]` rendering is corrected to `[from: NUM]`. The existing T-6m RID is retained because these repairs restore its explicit conditional scope; no new theorem is asserted.

### Adopted v1.6 orientation-chain lifecycle (reviewed r4–r4.2 dispositions)

| Historical/current-use RID | Adopted successor / disposition | Reason |
|---|---|---|
| [RID: TRIAD-ALG-T6M-BIRTH-OBSTRUCTION] | `TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN` `[ALG diagnostic]` | Wedge/route obstruction depended on corrected orientation chain; exact reference angle and producer-frame polynomial survive. |
| [RID: TRIAD-NUM-T6J2-NO-BASIN] | `TRIAD-NUM-T6J2-ROOT-CLOSED-EXCURSION` `[NUM historical]` | Safe/fatal/no-basin proposition withdrawn; only normalization-conditional excursion remains, terminal event unresolved. |
| historical T-6l current use (no result RID) | `TRIAD-ALG-T6L-NORMALIZED-TORSION-SIGN` `[ALG]` | Corrected rate removes the old real root and gives sign-definite leading torsion. |
| [RID: TRIAD-EXPORT-PROTOCOL-1] | `TRIAD-EXPORT-PROTOCOL-2` `[DEF]` | Historical obstruction/no-basin exports removed; current correction/reference items replace them. |
| T-6e downstream interpretation | `TRIAD-ALG-T6E-ORIENTATION-NORMALIZATION` `[ALG diagnostic]` | Raw determinant extraction retained; normalized-rate identification corrected. |

`[DEF]` **Historical r3 identities retained for traceability.** The following identities remain records of their predecessor propositions/statuses and are not current permissions or current corrected-model conclusions:

- [RID: TRIAD-OPEN-T6M] — historical module-level T-6m record; current narrowed successor proposition is `TRIAD-ALG-T6M-REFERENCE-QUARTER-TURN`.
- [RID: TRIAD-OPEN-T6J2] — historical module-level T-6j2 record; current narrowed successor proposition is `TRIAD-NUM-T6J2-ROOT-CLOSED-EXCURSION`.
- [RID: TRIAD-ALG-SAFETY-WEDGE] — historical necessary-window synthesis for the executed mis-scaled orientation model; not a current corrected-model safety threshold.
- [RID: TRIAD-ALG-ISC-ATTRACTOR] — historical cross-phase-attractor proposition; retained as historical/scoped evidence only pending corrected-model reconciliation.
- [RID: TRIAD-ALG-VERDICT] — historical synthesis “dominant phase steering into fatal Plücker sectors”; withdrawn from current corrected-model use.

`[COR]` **Orientation normalization.** The recovered T-6c2 producer uses $\Omega$ satisfying $Q_sQ_c-I^2=\Omega^2$; T-6e differentiates $\omega_{\rm raw}=-\Omega/\sqrt3$. Downstream factor-1 rate use is withdrawn; historical outputs remain provenance of the executed model.

`[COR]` **Historical phase chain.** T-6f/h/i/i2/j/k/k2/l numerical/algebraic records are retained as records of the executed mis-scaled orientation model. Their former current-use sector/wedge/basin/obstruction interpretations are withdrawn, not numerically rescaled.

`[COR]` **96:1 interpretation.** The coefficient ratio remains exact, but the statement that one common system's healing dominates its pump is no longer current without a typed correspondence between source calculations. The global-explosiveness inference from T-1 remains withdrawn for lack of proof; the old 96:1 explanation is historical only.

### Preserved v1.5 rejected-claim record

- `[RETRACTED]` Global $K_3$ explosiveness. Historical v1.5 reason: quartic pump versus recorded 96:1 healing comparison. **Current r4 note:** the inference remains withdrawn/not established, but the same-system 96:1 dominance correspondence is OPEN and is no longer used as its proof.
- `[RETRACTED]` Universal smooth $K_4$ explosion. Reason: leading large-$u$ chiral loading is self-limiting and phase steering drives toward fatal Plücker sectors.
- `[RETRACTED]` Stable smooth $K_4$ self-limitation. Reason: does not follow from $A_2 \le 0$ alone; torsional dynamics drive states out of any putative stable region.
- `[RETRACTED]` Total topological annihilation from Plücker contact alone. Reason: contact is a coordinate singularity; branch-switching remains `[OPEN]` (T-6n).
- `[RETRACTED]` Theorem-grade completion from constrained T-6f orientation chart. Reason: $Q_c$ is algebraically enslaved in that chart; scoped to Plücker-constrained chart only.
- `[FAIL]` Orthogonal slice $I_{sc}=0$ as dynamically invariant — $\Delta I_{sc}^{(2)} \neq 0$ at $I_{sc}=0$.
- `[FAIL]` $I_{sc}^*$ as full-system stable attractor — lies $7.8\times$ outside torsion-safe wedge.
- `[FAIL]` Naive $\sigma=+1 \to \sigma=-1$ branch flip at Plücker contact — $\dot W^2 < 0$ rejects it.
- `[FAIL]` T-6f runaway as free-$Q_c$ theorem — $Q_c$ algebraically enslaved in that chart.
- `[FAIL]` Neutral ray ($\theta=30°$) as safety criterion — lies $5\times$ outside torsion-safe wedge.
- `[FAIL]` Wider radial arc ($\theta \lesssim 22°$) as sufficient escape criterion — torsional safety binds at $5.5°$; sufficiency of even the $5.5°$ window is unproven.

---

*END OF DOCUMENT — RTG_TRIADIC_BIRTH_LIFT_DSN_v1.6 — ADOPTED OWNER RELEASE*  
*Owner release of the revision-editor-accepted r4.2 scientific content. Release authorization, accepted-candidate identity and this file's distinct release identity are recorded in `records/OWNER_ADOPTION.json`. Triadic v1.5, the accepted candidate, previous review receipts and packaging-time status records remain unchanged as history. Genesis/OPEN-M/RRF consumer reconciliation and Programme/OFN pass two remain pending. Revised blocks use Methodology v1.3; inherited v1.2 forms remain explicitly unmigrated.*
