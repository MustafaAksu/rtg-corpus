"""Byte-equality check of the RECOG sections cited by RER-G9 (gap references n0, n1; key RECOG; pin v0.3.20)
between frozen RECOG v0.3.20 and adopted RECOG v0.3.21.
Usage: python -I this.py V20 V21               -> compare; exit 0 iff both file hashes match and both blocks are byte-identical.
       python -I this.py --single V21          -> hash the blocks of one file (exit 0 iff the file hash matches v0.3.21).
       python -I this.py --negcontrol K V20 V21 -> flip one byte inside block K (1 = §6.6a, 2 = §6.16g) of the v0.3.21 copy in memory;
                                                  must report a mismatch (exit 0 iff it does).
Blocks are cut by literal anchor lines (no parser): §6.6a = '### §6.6a' up to '### §6.7'; §6.16g = '#### §6.16g' up to '## §7.'.
The compare mode also lists every whole-file change hunk (difflib, line level) with its v0.3.20 line range,
and checks that none falls inside a cited block."""
import sys, hashlib, difflib
H20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
H21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'
sha = lambda b: hashlib.sha256(b).hexdigest()
ANCH = [('§6.6a', '### §6.6a', '### §6.7'), ('§6.16g', '#### §6.16g', '## §7.')]
def blocks(b):
    L = b.split(b'\n'); out = {}
    for k, s, e in ANCH:
        i = next(n for n in range(len(L)) if L[n].startswith(s.encode()))
        j = next(n for n in range(i + 1, len(L)) if L[n].startswith(e.encode()))
        out[k] = (i + 1, j, b'\n'.join(L[i:j]))
    return out
a = sys.argv[1:]
if a[0] == '--single':
    b = open(a[1], 'rb').read(); print('file', sha(b), 'MATCH v0.3.21' if sha(b) == H21 else 'NO MATCH')
    for k, (i, j, t) in blocks(b).items(): print(f'  {k:7s} lines {i}-{j}  {sha(t)}')
    sys.exit(0 if sha(b) == H21 else 1)
neg = None
if a[0] == '--negcontrol': neg = ANCH[int(a[1]) - 1][0]; a = a[2:]
b20, b21 = open(a[0], 'rb').read(), open(a[1], 'rb').read()
if neg:
    T = blocks(b21)[neg][2]; p = b21.index(T) + len(T) // 2; b21 = b21[:p] + bytes([b21[p] ^ 1]) + b21[p + 1:]
ok20, ok21 = sha(b20) == H20, sha(b21) == H21
print('v0.3.20', sha(b20), 'MATCH' if ok20 else 'NO MATCH')
print('v0.3.21', sha(b21), 'MATCH' if ok21 else ('MUTATED (negative control)' if neg else 'NO MATCH'))
B20, B21 = blocks(b20), blocks(b21); same = True
for k in B20:
    e = B20[k][2] == B21[k][2]; same &= e
    print(f'  {k:7s} v0.3.20 lines {B20[k][0]}-{B20[k][1]}  v0.3.21 lines {B21[k][0]}-{B21[k][1]}  {"IDENTICAL" if e else "DIFFERENT"}  {sha(B21[k][2])}')
if neg: print('negative control', neg + ':', 'mismatch detected (good)' if not same else 'NOT detected (BAD)'); sys.exit(0 if not same else 1)
L20, L21 = b20.split(b'\n'), b21.split(b'\n'); inside = 0
print('whole-file change hunks (v0.3.20 lines -> v0.3.21 lines):')
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, L20, L21, autojunk=False).get_opcodes():
    if tag == 'equal': continue
    hit = [k for k in B20 if i1 < B20[k][1] and max(i2, i1 + 1) > B20[k][0] - 1]; inside += bool(hit)
    print(f'  {tag:7s} {i1+1}-{i2}  ->  {j1+1}-{j2}' + (f'  INSIDE {hit}' if hit else ''))
print('hunks inside cited blocks:', inside)
ok = ok20 and ok21 and same and inside == 0
print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
