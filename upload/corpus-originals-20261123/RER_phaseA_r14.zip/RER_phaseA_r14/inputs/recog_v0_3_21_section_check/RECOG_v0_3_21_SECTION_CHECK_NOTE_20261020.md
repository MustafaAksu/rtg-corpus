# RECOG v0.3.20 → v0.3.21: section identity check for RER-G9

**Date:** 20 Oct 2026. **From:** Claude, RER co-owner (preparer). **Status:** NONCANONICAL check record; no RER text, catalog or Phase A output is changed. The preparer does not accept his own work.

## 1. Identity (BYTE_VERIFIED_HERE)

| File | SHA-256 | Against |
|---|---|---|
| `RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md` (PI upload, 301 292 bytes, 1 493 lines) | `a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3` | MATCH: release record `claude/RECOG_v0_3_21_RELEASE_RECORD.md` and Phase A r12 catalog |
| `RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md` (Phase A r12 `sources_available`) | `fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df` | MATCH: RER-G9 cited pin |

## 2. Cited blocks (RER-G9, key RECOG, rows n0 and n1)

Cut by literal anchors, no parser. The v0.3.20 line ranges equal the `lines` fields of the two Phase A r12 matrix rows.

| Block | v0.3.20 lines | v0.3.21 lines | Result | SHA-256 of block |
|---|---|---|---|---|
| §6.6a CELL-G1 (`### §6.6a` … `### §6.7`) | 517–542 | 521–546 | IDENTICAL | `0d109828…0480` |
| §6.16g CELL-F4 (`#### §6.16g` … `## §7.`) | 1002–1042 | 1006–1046 | IDENTICAL | `be1614c9…b429` |

Whole-file diff: 19 change hunks (header, status summary, freeze status, §2 R1/R3/R5 lines, SG-R14 reference import, §7 synchronization note and rows, new §7.2 and §7.3, §8 artifact rows, §9 v0.3.21 entry, footer). None falls inside a cited block. This is consistent with the release record's "synchronization-only" statement for the cited text; it does not by itself verify the rest of that statement.

Negative controls: one byte flipped inside each block of the v0.3.21 copy (in memory) is reported DIFFERENT (2/2). Clean-extraction replay with `python -I`: outputs byte-identical to the stored ones.

## 3. Points in v0.3.21 that touch RER (read, not judged)

1. **§7.3 Downstream Dependents Register** names RER as a consumer twice: the three shear RIDs (`RECOG-ALG-SHEAR-*`, "RER v0.2 r4.6 G9 (owner-first citation)") and `RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS (W1–W5)` ("RER v0.2 r4.6 G9", interface prerequisites). The register names r4.6; the current RER DRAFT is r4.8, whose G9 record is unchanged from r4.6. Under the §7.3 notification rule, RECOG notifies RER of any change to those RIDs before its release.
2. **RF-1 (outbound notice to RRF, §7.2):** RRF v0.8.3 §6.3 restates W3 as comparison or transport between pre- and post-birth cohomology spaces; §6.16g W3 requires $a^-, a^+$ in the same space. This bears on the RER-G9 n1 gap reference (§6.16g), whose per-reference audit against RRF v0.8.3 is still `PENDING_PER_REFERENCE_AUDIT`. It is input for that audit, not a finding of this check.
3. **G3 notice to RER:** "G1 freeze record and the hash of this release on adoption." The release record lists it as not yet sent; this check does not replace it.
4. **v0.3.20 frozen status:** now also stated in owner DSN bytes (v0.3.21 Supersedes line: "frozen 19 Oct 2026, sha256 `fdb8c9a7…b8df`"). The external freeze record `RECOG_v0_3_20_FREEZE_DECISION_PROVENANCE.md` (registered as RECOG-ART-FREEZE-0320, `5c00f66d…9b55`) is not held here.

## 4. What this would allow (not done; needs receiving authorization)

A Phase A r13 could move the RECOG current version to BYTE_VERIFIED (file added to `sources_available` with a custody entry and this check under `inputs/`), give the two RER-G9 rows `verified_current_hash = a3459522…0ae3` with the cited blocks recorded as identical, and keep the RER pins on v0.3.20. The `PENDING_PER_REFERENCE_AUDIT` status of both rows would stay unchanged. The r12 state would be kept as history.
