"""Byte-equality check of the DYAD sections cited by RER-DYAD-FORMAL-INVOLUTION (pin DYAD6413: §6.15, §6.16, §6.17, §2 OPEN 19/20)
between adopted Dyadic v6.4.16 and v6.4.17.
Usage: python -I this.py V16 V17      -> compares; exit 0 iff both file hashes match the adopted identities and every block is byte-identical.
       python -I this.py --single V17 -> hashes the blocks of one file only (no comparison; exit 0 iff the file hash matches v6.4.17).
       python -I this.py --negcontrol V16 V17 -> flips one byte inside §6.16 of the v6.4.17 copy in memory; must report a mismatch (exit 0 iff it does).
Blocks are cut by literal anchor lines (no parser): §6.15 = '### §6.15' up to '### §6.16'; §6.16 up to '### §6.17'; §6.17 up to '## §7.';
OPEN 19 = '**OPEN 19 —' up to the next line equal to '---'; OPEN 20 = '**OPEN 20 —' up to the next line equal to '---'."""
import sys, hashlib
H16 = '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'
H17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
sha = lambda b: hashlib.sha256(b).hexdigest()
def blocks(b):
    L = b.split(b'\n'); idx = lambda pre, start=0: next(i for i in range(start, len(L)) if L[i].startswith(pre))
    def upto_rule(i): return next(j for j in range(i + 1, len(L)) if L[j] == b'---')
    a15, a16, a17, a7 = idx('### §6.15'.encode()), idx('### §6.16'.encode()), idx('### §6.17'.encode()), idx('## §7.'.encode())
    o19 = idx('**OPEN 19 —'.encode()); o20 = idx('**OPEN 20 —'.encode())
    J = lambda i, j: b'\n'.join(L[i:j])
    return {'§2 OPEN 19': (o19 + 1, upto_rule(o19), J(o19, upto_rule(o19))), '§2 OPEN 20': (o20 + 1, upto_rule(o20), J(o20, upto_rule(o20))),
            '§6.15': (a15 + 1, a16, J(a15, a16)), '§6.16': (a16 + 1, a17, J(a16, a17)), '§6.17': (a17 + 1, a7, J(a17, a7))}
args = sys.argv[1:]
if args[0] == '--single':
    b = open(args[1], 'rb').read(); print('file', sha(b), 'MATCH v6.4.17' if sha(b) == H17 else 'NO MATCH')
    for k, (i, j, t) in blocks(b).items(): print(f'  {k:11s} lines {i}-{j}  {sha(t)}')
    sys.exit(0 if sha(b) == H17 else 1)
neg = args[0] == '--negcontrol'
if neg: args = args[1:]
b16, b17 = open(args[0], 'rb').read(), open(args[1], 'rb').read()
if neg:
    B = blocks(b17)['§6.16'][2]; k = b17.index(B) + len(B) // 2; b17 = b17[:k] + bytes([b17[k] ^ 1]) + b17[k + 1:]
ok16, ok17 = sha(b16) == H16, (sha(b17) == H17) or neg
print('v6.4.16', sha(b16), 'MATCH' if ok16 else 'NO MATCH'); print('v6.4.17', sha(b17), 'MATCH' if sha(b17) == H17 else ('MUTATED (negative control)' if neg else 'NO MATCH'))
B16, B17 = blocks(b16), blocks(b17); same = True
for k in B16:
    e = B16[k][2] == B17[k][2]; same &= e
    print(f'  {k:11s} v6.4.16 lines {B16[k][0]}-{B16[k][1]}  v6.4.17 lines {B17[k][0]}-{B17[k][1]}  {"IDENTICAL" if e else "DIFFERENT"}  {sha(B17[k][2])[:16]}')
if neg: print('negative control:', 'mismatch detected (good)' if not same else 'NOT detected (BAD)'); sys.exit(0 if not same else 1)
print('RESULT:', 'PASS' if (ok16 and ok17 and same) else 'FAIL'); sys.exit(0 if (ok16 and ok17 and same) else 1)
