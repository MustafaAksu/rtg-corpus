"""Section comparison of the DYAD blocks cited by RER-DYAD-FORMAL-INVOLUTION (pin DYAD6413: §6.15, §6.16, §6.17, §2 OPEN 19/20)
between adopted Dyadic v6.4.17 and adopted Dyadic v6.4.18.
Expected from the v6.4.18 release record: OPEN 19, §6.15 and §6.16 identical; OPEN 20 and §6.17 changed.
Usage: python -I this.py V17 V18      -> compares; prints a unified diff (0 context lines) of every changed block; exit 0 iff both
                                         file hashes match the adopted identities and the identical/changed pattern equals the expected one.
       python -I this.py --single V18 -> hashes the blocks of one file only (exit 0 iff the file hash matches v6.4.18).
       python -I this.py --negcontrol V17 V18 -> flips one byte inside §6.16 of the v6.4.18 copy in memory; the pattern must then
                                         differ from the expected one (exit 0 iff it does).
Blocks are cut by literal anchor lines (no parser): §6.15 = '### §6.15' up to '### §6.16'; §6.16 up to '### §6.17'; §6.17 up to '## §7.';
OPEN 19 = '**OPEN 19 —' up to the next line equal to '---'; OPEN 20 = '**OPEN 20 —' up to the next line equal to '---'."""
import sys, hashlib, difflib
H17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
H18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
EXPECTED = {'§2 OPEN 19': True, '§2 OPEN 20': False, '§6.15': True, '§6.16': True, '§6.17': False}  # True = identical
sha = lambda b: hashlib.sha256(b).hexdigest()
def blocks(b):
    L = b.split(b'\n'); idx = lambda pre: next(i for i in range(len(L)) if L[i].startswith(pre.encode()))
    rule = lambda i: next(j for j in range(i + 1, len(L)) if L[j] == b'---')
    a15, a16, a17, a7, o19, o20 = idx('### §6.15'), idx('### §6.16'), idx('### §6.17'), idx('## §7.'), idx('**OPEN 19 —'), idx('**OPEN 20 —')
    J = lambda i, j: (i + 1, j, b'\n'.join(L[i:j]))
    return {'§2 OPEN 19': J(o19, rule(o19)), '§2 OPEN 20': J(o20, rule(o20)), '§6.15': J(a15, a16), '§6.16': J(a16, a17), '§6.17': J(a17, a7)}
a = sys.argv[1:]
if a[0] == '--single':
    b = open(a[1], 'rb').read(); print('file', sha(b), 'MATCH v6.4.18' if sha(b) == H18 else 'NO MATCH')
    for k, (i, j, t) in blocks(b).items(): print(f'  {k:11s} lines {i}-{j}  {sha(t)}')
    sys.exit(0 if sha(b) == H18 else 1)
neg = a[0] == '--negcontrol'
if neg: a = a[1:]
b17, b18 = open(a[0], 'rb').read(), open(a[1], 'rb').read()
if neg:
    T = blocks(b18)['§6.16'][2]; p = b18.index(T) + len(T) // 2; b18 = b18[:p] + bytes([b18[p] ^ 1]) + b18[p + 1:]
ok17, ok18 = sha(b17) == H17, sha(b18) == H18
print('v6.4.17', sha(b17), 'MATCH' if ok17 else 'NO MATCH')
print('v6.4.18', sha(b18), 'MATCH' if ok18 else ('MUTATED (negative control)' if neg else 'NO MATCH'))
B17, B18 = blocks(b17), blocks(b18); got = {}
for k in B17:
    got[k] = B17[k][2] == B18[k][2]
    print(f'  {k:11s} v6.4.17 lines {B17[k][0]}-{B17[k][1]}  v6.4.18 lines {B18[k][0]}-{B18[k][1]}  {"IDENTICAL" if got[k] else "CHANGED"}  {sha(B18[k][2])}')
match = got == EXPECTED
print('identical/changed pattern equals the release-record expectation (OPEN 19, §6.15, §6.16 identical; OPEN 20, §6.17 changed):', match)
if neg: print('negative control:', 'deviation detected (good)' if not match else 'NOT detected (BAD)'); sys.exit(0 if not match else 1)
for k in B17:
    if not got[k]:
        print(f'--- diff {k} (v6.4.17 -> v6.4.18) ---')
        for l in difflib.unified_diff(B17[k][2].decode('utf-8').split('\n'), B18[k][2].decode('utf-8').split('\n'), 'v6.4.17', 'v6.4.18', n=0, lineterm=''): print(l)
ok = ok17 and ok18 and match
print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
