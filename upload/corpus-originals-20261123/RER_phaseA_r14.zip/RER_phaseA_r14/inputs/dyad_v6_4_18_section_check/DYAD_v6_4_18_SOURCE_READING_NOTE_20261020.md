# Dyadic v6.4.18: source verification and reading note for RER-DYAD-FORMAL-INVOLUTION

**Date:** 20 Oct 2026. **From:** Claude, RER co-owner (preparer). **Status:** NONCANONICAL source-reading record. It reports what the owner text says; it is not a scientific review of the new theorem or of its proof records, and it changes no RER text, catalog or Phase A output. The preparer does not accept his own work.
**Answers:** the receiving decision on Phase A r12, step 1 ("Dyadic v6.4.18'in orijinal baytlarını edinip §2 OPEN 20, §6.17 ve `DYAD-THM-SMOOTH-EMBEDDING` teoremini incelemek").

## 1. Identity (BYTE_VERIFIED_HERE)

| File | SHA-256 | Against |
|---|---|---|
| `RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` (PI upload, 256 933 bytes, 1 539 lines) | `f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d` | MATCH: release record `claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md`; Phase A r12/r13 catalog |
| `RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md` (Phase A `sources_available`) | `e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc` | MATCH: Phase A r9 identity (receiver-confirmed) |

Also uploaded in the same message: `RTG_ER2B_CONSOLIDATED_STUDY_v0_3_NONCANONICAL.md`, SHA-256 `80669c69ada042230c36883f5f1de7a0738e637793a4d1cf4b590990da57a134`, 60 351 bytes. It matches the v0.3 identity in the Phase A catalog. Per receiver decision D-2, v0.3 is background only and does not unblock the two ER-2B records; they still need the v0.2 package bytes. It is recorded here only as an identity check and is not included in this package.

## 2. Section comparison v6.4.17 → v6.4.18 (cited blocks of DYAD6413)

Literal anchors as in the r1 check of v6.4.16 → v6.4.17.

| Block | v6.4.17 lines | v6.4.18 lines | Result |
|---|---|---|---|
| §2 OPEN 19 | 234–241 | 238–245 | IDENTICAL |
| §2 OPEN 20 | 244–252 | 248–257 | CHANGED |
| §6.15 | 858–898 | 864–904 | IDENTICAL |
| §6.16 | 899–947 | 905–953 | IDENTICAL |
| §6.17 | 948–966 | 954–982 | CHANGED |

This pattern equals the one implied by the release record. The negative control (one byte flipped in §6.16) is detected. Both changes are additive:
- **OPEN 20:** the status line is replaced; the v6.4.17 status is retained in it as history. One new line is added: B-∞ existence CLOSED.
- **§6.17:** the v6.4.17 `[OPEN] Not established` line is kept and tagged `[v6.4.17]`. Ten lines are added: a source paragraph, the new `[THM]`, a `[DEF]` of recorded distinctions, and a new `[OPEN]`.
- **Unchanged in §6.17:** Lemma F (`DYAD-CAND-FLAT-CENTRALIZER` `[THM]`), F1–F3 (`DYAD-CAND-SMOOTH-CENTRALIZER-COROLLARIES` `[THM — conditional]`, including its bracket "no existence is asserted") and the section header.

Whole-file changes outside the cited blocks: header and status lines, §1 canonical-state entry and table row, notice N14 (addressed to FMS, RRF, OFN), §8 artifacts `DYAD-ART-OPEN20-BINF-RECORDS` and `-CHECKS`, Appendix A, footer.

## 3. What the owner states (v6.4.18 §6.17, read here)

**`DYAD-THM-SMOOTH-EMBEDDING` `[THM]` `[v6.4.18]`.** Scope: C^∞ local germs at P1, raw frame W, lifted chart.
- **E1.** There are a ball U* = B(0, r″) and a C^∞ vector field X with j^∞X = log F and F = φ¹_X on U*.
- **E2.** Uniqueness of X holds only among C^∞ generators X′ with DX′(0) = 0. The owner records that exp(DX′(0)) = I does not force this.
- **E3.** For each m ≥ 1, K_m = φ_X^{1/m} is the unique C^∞ tangent-to-identity root with K_m^m = F, and it commutes with T (F3).
- **E4.** J = T∘K₆⁻¹ satisfies J⁶ = id, DJ(0) = A and JT = TJ. R = T³∘K₂⁻¹ is a C^∞ local involution with DR(0) = −I and RT = TR, unique by F2, and satisfies the §6.15 domain convention with V = B ∩ R⁻¹(B).

**Recorded distinctions (`[DEF]`):**
1. G_∞ is the Borel time-one map, unrelated to G = J² of §6.16.
2. The proof route is Φ_∞ = lim G_∞^{-n} F^n; the earlier §6.17 route F^{-n} R_∞ F^n remains unproved.
3. E2 scope as above.
4. **F1–F3 grades are unchanged (`[THM — conditional]`); their existence condition is discharged for K_m, J and R by E1.**
5. r″ is qualitative; no numerical radius or finite-C^k constant is claimed.
6. C^∞ existence says nothing about analyticity; B-an and B-6 are untouched.
7. SG-14/15: no physical exchange, G2 realization or EF=TE / EF=T⁶E identification.

**New `[OPEN]` `[v6.4.18]`:**
- convergence of log F, F^{1/2}, F^{1/6} (B-an, B-6);
- uniqueness among all C^∞ generators;
- quantitative radii and finite-C^k versions;
- convergence of F^{-n} R_∞ F^n;
- physical exchange and G2 realization.

**OPEN 20 status (§2):** PARTIAL. B-∞ existence CLOSED (v6.4.18); B-∞ flat uniqueness CLOSED (v6.4.13); B-an and B-6 ACTIVE.

**Evidence level of this reading.** The theorem statement and its scope labels are SOURCE-READ from verified bytes. The proof is given in the owner text only as an outline. The proof records (DYAD-ART-OPEN20-BINF-RECORDS, seven SESSION files with hashes) and the check scripts were not read or re-run for this note. The owner reports external review of DRAFT r1 with checker reruns. Whether RER needs more than an owner-grade import is a receiving decision.

## 4. Consequences for RER r4.8 (inventory for r4.9; not applied)

Line numbers refer to r4.8 (`2dfebebf…0e3e`).

| r4.8 line | Current text (short) | Status against v6.4.18 | Proposed r4.9 handling |
|---|---|---|---|
| 894 | `[OPEN] OPEN 20 B-∞ existence: a C^∞ local involution …` | **contradicts** owner (CLOSED) | Replace with a `[THM]` import line for `DYAD-THM-SMOOTH-EMBEDDING` at C^∞ germ scope. It states E1–E4 with E2 limited to DX′(0) = 0, a qualitative radius, the route distinction, and "no analyticity". It records that the r4.8 line is superseded (r4.1 practice). |
| 895 | Lemma F / F1–F3 line ending "No existence is asserted" | **scope outdated**: the owner grade text is unchanged, but the existence condition is discharged by E1 (owner `[DEF]` (iv)) | Keep the line, grades and hypotheses. Replace only "No existence is asserted" with the owner's discharge statement, and keep "conditional on Lemma F". Keep the CAND/identifier sentence and the triad non-transfer. |
| 892, 893 | B-an, B-6 `[OPEN]` | unchanged (owner ACTIVE) | unchanged |
| 896 | Physical exchange `[OPEN]` | unchanged (SG-14/15) | unchanged |
| 882 | "Convergence: OPEN 20 (…)" | still true for convergence (analytic) | Optional clarification: "analytic convergence OPEN 20 B-an/B-6; C^∞ existence CLOSED (v6.4.18)". |
| 862 | per-RID owner-grade source note | missing the new RID | Optional: add `DYAD-THM-SMOOTH-EMBEDDING` [THM] (C^∞ germ scope). |
| 889 | Import/reference DYAD6413 (v6.4.13) | still the pin for §6.15, §6.16 and Lemma F/F1–F3 | Keep. Add a new key **DYAD6418** (v6.4.18, `f70308f1…458d`) for §2 OPEN 20 and the new §6.17 entries, with a source-table row. Its evidence label needs Phase A custody; until then the RER line can say "byte-hashed by the RER preparer; Phase A custody pending". |
| 900 | Non-transfer to the triad | still applies | Extend to E1–E4: the proof uses the isolated-dyad contraction DYAD-THM-PRIM-CTR. Nothing transfers to RER-TRIAD-FORMAL-INVOLUTION, which mentions neither B-∞ nor OPEN 20. |
| 861 / contract | `[THM]`; `FORMAL_ONLY`; Closure `FORMAL_UNIQUE` | record-level framing | **Receiver decision D-A** below. |

**Decisions for the receiver before r4.9:**
- **D-A, record framing.** The record is a formal classification (`FORMAL_ONLY`, `FORMAL_SYMMETRY_CLASSIFICATION`). The new import is a C^∞ existence result. Option 1 (preparer's lean): keep the record-level grade, exactness, contract and closure cells unchanged. The C^∞ result becomes an explicitly scoped import line, as the analytic bridge already is. Option 2: extend the Exactness field (e.g. `FORMAL_ONLY; C^∞ existence imported (owner)`). Option 2 changes a parsed field, so Phase A gates on that record would change.
- **D-B, pin key.** A new DYAD6418 key with the DYAD6413 pin kept (preparer's lean), or a repin of the whole record. A repin would need v6.4.13 → v6.4.18 identity of §6.15, §6.16 and Lemma F/F1–F3, which is byte-checked here only from v6.4.15/16 on (v6.4.16 → v6.4.17 and v6.4.17 → v6.4.18). The v6.4.13 → v6.4.15 step is not byte-checked by the preparer.
- **D-C, import depth.** An owner-grade import from SOURCE-READ statement text, or a requirement that the proof records be read first.

**Not affected:** the other 19 records, the gap references, the r3.1 tables.

**After an accepted r4.9:** a Phase A step would add the v6.4.18 bytes (Dyadic evidence BYTE_VERIFIED). The rebuilt warning SYNC-DYAD-OPEN20-BINF moves to CHECK, because its listed lines are no longer present. It is closed only by an explicit receiving decision.

## 5. Observations (not findings)

- N14 is addressed to FMS, RRF and OFN, not to RER. RER consumes OPEN 20 and §6.17 through DYAD6413. This is relevant to the owner's notice list and is not an RER defect.
- §6.17 now carries the v6.4.17 `[OPEN] Not established` line as history. A future reading must not cite it as current.
