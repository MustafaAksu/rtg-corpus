# RER Phase A r14: change record (Phase A pass on RER r4.9; Dyadic v6.4.18 byte verification)

**Date:** 20 Oct 2026.
**From:** Claude, RER co-owner (preparer). The preparer does not accept his own work.
**Status:** NONCANONICAL Phase A candidate, revision 14. Nothing is adopted, frozen or published.
**Answers:** the receiving decision on RER r4.9 of 20 Oct 2026 (ACCEPT SCOPED, draft only). That decision authorized a Phase A pass on the actual r4.9 bytes with the DYAD6418 source and its custody, the r13 outputs kept as history, and closure of SYNC-DYAD-OPEN20-BINF left to the independent check of this pass.

## 1. Source and base

- **Source Markdown:** RER v0.2 DRAFT r4.9 (`9c0f43fc…cc84`; package `7fa00ac1…100d`; base r4.8 `2dfebebf…0e3e`). It replaces r4.8 in the package. The r4.9 package manifest (`inputs/r4_9_package_SHA256SUMS.txt`, which pins r4.8) is added, and every row carries `path_in_r4_9_package`.
- **Base package:** Phase A r13 (`1bf24cc4…6eb1`, accepted), extracted fresh.
- **Patch:** `patch_r14.py`, at the package root.
- **r13 history:** the five r13 outputs and the r13 checker output are kept byte-unchanged under `inputs/phaseA_r13_outputs/` and pinned in `PINS.json`. The registry output is now `RER_REGISTRY_v0_2_r4_9_PHASEA.json`.

## 2. Inputs added

| Path | Content |
|---|---|
| `sources_available/DYAD6418__RTG_DYADIC_OSCILLATOR_DSN_v6_4_18.md` | Dyadic v6.4.18, `f70308f1…458d` (PI upload; equals the release record; receiver confirmed the same hash; the same bytes are in the r4.9 package) |
| `inputs/source_custody_r14.json` | custody entry; container chain PREPARER_DECLARED |
| `inputs/dyad_v6_4_18_section_check/` | the accepted section check and source reading note (package `02d16047…f21b`) |

## 3. Catalog changes (Dyadic only)

| Field | r13 | r14 |
|---|---|---|
| Dyadic evidence | OWNER_REPORTED | BYTE_VERIFIED |
| History | `phaseA_r8`, `phaseA_r9_r11` | kept, plus `phaseA_r12_r13` (OWNER_REPORTED v6.4.18) |
| Superseded v6.4.17 | BYTE_VERIFIED, with file, custody r9 and section check | unchanged |
| Key `DYAD6413` | RECHECK_IN_PHASE_B, sync link | unchanged rule; the reason adds that DYAD6418 now carries the OPEN 20 content and that v6.4.13 → v6.4.15 is not byte-checked here |
| Key `DYAD6418` | — | new: v6.4.18, OWNER_DSN, Dyadic, CURRENT; receiver section-check receipt |

**SYNC-DYAD-OPEN20-BINF.** The warning's owner evidence is now BYTE_VERIFIED. It gains `replacement_lines` (the two r4.9 lines) and `rer_correction` (r4.9, receiver-accepted). The listed r4.8 lines, roles, action and closing condition are unchanged.

## 4. Builder change: live line vs quotation

The receiver asked that a historical quotation of the old OPEN line not be read as a live OPEN.
- **Live line.** A listed line counts as live only if it is a whole Markdown line. The builder records `rer_lines_present` (live), `rer_lines_quoted_only` (absent as a line but present inside another line) and `replacement_lines_present`.
- **Status rules:**
  - OPEN while every listed line is live;
  - **CHECK — record corrected** when no listed line is live and every replacement line is live;
  - otherwise the generic CHECK.

  Phase A never sets CLOSED.

On r4.9: live `[False, False]`, quoted-only `[True, False]` (the OPEN line survives only inside the superseding `[THM]` line), replacement lines `[True, True]`. Status: `CHECK — record corrected …; closure pending the independent receiving check of this Phase A pass`. The registry parse confirms that B-∞ existence is not an OPEN item of the record.

## 5. Result

**Matrix.** 91 rows (78 record imports + 13 gap references). The 90 r13 rows are unchanged except for:
- `path_in_r4_9_package`, added on every row;
- the DYAD6413 row: `current_owner_evidence` (→ BYTE_VERIFIED), `verified_current_hash` (→ `f70308f1…`) and `currency_reason`. Its status stays HISTORICAL and its pin stays v6.4.13.

One new row, RER-DYAD-FORMAL-INVOLUTION / `DYAD6418` (n = 3): cited v6.4.18 with the held hash, BYTE_VERIFIED_MATCH, BYTE_VERIFIED_HERE, CURRENT, **VERIFIED**.

| Measure | r13 | r14 |
|---|---|---|
| VERIFIED / OWNER_REPORTED / HISTORICAL / BLOCKED | 30 / 4 / 50 / 6 | 31 / 4 / 50 / 6 |
| Authentication BYTE_VERIFIED_HERE / RECEIVER / PRINTED / NONE | 58 / 7 / 24 / 1 | 59 / 7 / 24 / 1 |

**Registry.** The other 19 records and the gap, legacy and count sections equal r13. The source table equals r13 plus `DYAD6418`. RER-DYAD-FORMAL-INVOLUTION differs only in its r4.9 synchronization:
- `open_items` minus B-∞ existence;
- `imports` plus DYAD6418;
- `claim_lines` plus the new `[THM]` (and the revised F1–F3 line);
- the fields Order / error, Evidence and Non-transfer;
- the source note.

Its primary grade `[THM] (owner grade)`, grade tags `['THM']` and `FORMAL_ONLY` are unchanged.

**Blocked register.** Equal to r13 apart from schema and source hash.

## 6. Gates: 28/28 PASS; controls 85/85 fail as required

| Gate | r14 requirement |
|---|---|
| A6 | also checks `path_in_r4_9_package` against the r4.9 manifest |
| A23 (re-based) | v6.4.18 BYTE_VERIFIED only with the real file, custody r14 and the section check (3 identical, 2 changed, expected pattern). v6.4.17 identity and r8, r9–r11, r12–r13 history. DYAD6413: pin v6.4.13, RECHECK_IN_PHASE_B, HISTORICAL, sync link. DYAD6418: CURRENT, VERIFIED, bytes matched, receiver receipt. |
| A24 (re-based) | r4.9, package, r4.8 and r4.7 bases pinned; r4.8 identity in the r4.9 manifest; `path_in_r4_9_package` on every row; the r13 outputs and their 28/28 checker record kept |
| A25 (re-based) | registry equality with r13 except the DYAD synchronization fields above |
| A27 (re-based) | the warning recomputed from the r4.9 bytes as in §4: CHECK, never CLOSED; the listed lines equal r13; the replacement lines are live claim lines; B-∞ is not an OPEN item |
| A28 (re-based) | matrix equality with r13 as in §5; blocked register, other owners and the warning text unchanged; one r14 watch item |

The r9/r10 regression gates used in r10–r13 are retired. Their results stay in the pinned r13 checker record, which A24 requires.

**Controls (85).**
- 40 output controls carried from r13.
- 36 new or re-targeted output controls:
  - A23 (12): evidence back to OWNER_REPORTED, relabelled, hash replaced, each history entry dropped, superseded entry dropped, the DYAD6413 pin moved to v6.4.18 or promoted, the DYAD6418 row demoted, its verified hash removed, its receipt dropped;
  - A24 (3): source recorded as r4.8, package hash replaced, a row without the r4.9 path flag;
  - A25 (7): r13 records re-used, another record changed, DYAD grade changed, exactness widened, B-an dropped, DYAD6418 import dropped, contract cell changed;
  - A27 (8): warning removed, marked CLOSED, left OPEN (quotation read as live), quoted flag forged, replacement line altered, listed lines altered, B-∞ re-added as a live OPEN item, DYAD6413 link removed;
  - A28 (6): r13 rows re-used, a non-Dyadic row edited, the DYAD6418 row duplicated, the blocked register changed, the RECOG entry changed, the warning action edited.
- 3 file controls: the v6.4.17 file (A23, carried), the v6.4.18 file (A23, new) and the v0.3.21 file (A26, carried) withheld from `sources_available`.
- 6 input controls: three new (the A23 section-check pattern false, the custody r14 hash altered, the A24 r13 checker record altered) and the three carried A26 RECOG controls.

Total: 76 output + 3 file + 6 input = 85.

**Clean extraction.** Re-extracted into an empty directory and run with `python -I`: output byte-identical to the stored checker output.

## 7. Not changed

- RER text, grades, OPEN boundaries (B-an, B-6, physical exchange) and the DYAD6413 pins.
- SYNC-DYAD-OPEN20-BINF is CHECK, not closed. Closing it is a receiving decision on this pass.
- ER-2B blocked (the v0.3 hash match does not replace the v0.2 package); G2 §5b pending; the 13 gap references `PENDING_PER_REFERENCE_AUDIT`, with G9/1 waiting for the RRF editor's RF-1 answer; the author-conflicted Phase B reviews are with the receiver.
