# RER-G9 W3 quotation packet: cover note

**Date:** 20 Oct 2026. **From:** Claude, RER co-owner (preparer). **Status:** NONCANONICAL input for the per-reference audit of RER-G9 (row G9/1, RECOG §6.16g; related row G9/3, RRF §6.3) and for the RRF editor's answer to RECOG notice RF-1. It quotes; it does not judge. It changes no RER, RRF, RECOG or Phase A file.

## 1. Identities (BYTE_VERIFIED_HERE)

| File | SHA-256 | Against |
|---|---|---|
| RRF v0.8.3 (PI upload, 97 717 bytes, 563 lines) | `b393657e…a187` | **MATCH** with the hash in the RRF v0.8.3 adoption record (as carried in RER r4.9 and the Phase A catalog). These bytes were not held by the preparer before; Phase A lists RRF083 as RECEIVER_BYTE_VERIFIED. |
| RECOG v0.3.21 | `a3459522…0ae3` | Phase A r13/r14 |
| RECOG v0.3.20 | `fdb8c9a7…b8df` | RER pin |
| RER r4.9 | `9c0f43fc…cc84` | accepted DRAFT |

RRF v0.8 (`c4ec1f10…2b44a`, the G9/3 pin) is **not** held here.

## 2. What the packet contains

`w3_quote_packet.py` cuts nine verbatim spans by literal anchors and writes `w3_quotes.json` (authoritative) and `w3_quotes.md`.

**Spans:**
- **S1, S2:** RECOG §6.16g W3, from v0.3.21 and v0.3.20. They are byte-identical (gate Q3).
- **S3:** RECOG §7.2 RF-1.
- **S4, S5:** RRF v0.8.3 §6.3, the W3 row and its import line. It is the only W3 row in RRF v0.8.3 (gate Q4).
- **S6–S9:** RER r4.9 RER-G9:
  - S6: the record's own W1–W5 line;
  - S7: reference n=1;
  - S8: reference n=3 (RRF v0.8);
  - S9: the r4.6 overlay line, which states RRF v0.8.3 §6.3 to be byte-identical with v0.8 §6.3.

**Table 2** records which of 14 listed strings occur in which span. It reports string occurrence only, not meaning.

**Gates and controls:** 6/6 gates PASS. 6/6 negative controls fail as required:
- one byte flipped in the RRF row;
- "same" removed from RECOG W3;
- a duplicate W3 row;
- a paraphrased span;
- a forged span hash;
- a removed anchor.

`--check` reproduces the stored outputs byte for byte.

## 3. The three formulations, verbatim (from the spans)

- **RECOG §6.16g W3 (S1):** "event-indexed cochains $a^-$, $a^+$ in the **same** cohomology space, so that $\Delta[a]=[a^+]-[a^-]$ is defined"
- **RRF v0.8.3 §6.3 W3 (S4):** "comparison/transport between *pre- and post-birth* cohomology spaces before forming `\Delta[a]`"
- **RER r4.9 G9 own line (S6):** "W3 a shared pre/post comparison space"

The RECOG owner's own request (S3) asks RRF "to quote W3 verbatim or to label its version an extension carrying an explicit map between the spaces as an additional obligation".

## 4. Points for the audit (questions, not findings)

1. **RRF editor (RF-1):** which of the two options in S3 applies to RRF v0.8.3 §6.3, and does the answer change the RRF row's status for the G9/3 reference?
2. **RER text (S6) is RER-authored**, so its fidelity check is for the receiver. Does "a shared pre/post comparison space" carry the same obligation as S1? Or does it need the owner wording or an explicit note?
3. **G9/3 pin:** RER cites RRF v0.8 §6.3 (lines 350–365), and the overlay (S9) states byte identity with v0.8.3 §6.3 (lines 412–427 here). Without the v0.8 bytes this identity is not checked by the preparer. The receiver's r3.1 package may hold them.
4. Phase A could now raise RRF083 from RECEIVER_BYTE_VERIFIED to BYTE_VERIFIED_HERE by adding these bytes with custody. That is a catalog step and needs authorization.
