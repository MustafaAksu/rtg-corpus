"""Neutral W3 quotation packet for the RER-G9 per-reference audit (row G9/1, RECOG §6.16g; related row G9/3, RRF §6.3).
Extracts verbatim spans from four byte-pinned files by literal anchors (no parser, no paraphrase) and writes
w3_quotes.json + w3_quotes.md. It states which words occur in which span; it makes no scientific judgement.
Usage: python -I this.py            -> verify, extract, write outputs; exit 0 iff all gates pass
       python -I this.py --check    -> verify and compare with the stored outputs byte for byte (no write)
       python -I this.py --negcontrol -> run the negative controls (each must make a gate fail); exit 0 iff all do
Gates: Q1 four file hashes; Q2 every anchor occurs exactly once in its file and every span is non-empty;
       Q3 the RECOG §6.16g W1-W5 line (incl. W3) is byte-identical in v0.3.20 and v0.3.21; Q4 the RRF W3 table row is the
       only W3 row in RRF v0.8.3 and sits inside §6.3 (between '### 6.3' and '### 6.4'); Q5 every span hash recomputes and
       each span is a substring of its file; Q6 the word inventory (Table 2) is recomputed from the spans."""
import sys, json, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent; SRC = HERE / 'sources'
sha = lambda b: hashlib.sha256(b).hexdigest()
FILES = {'RECOG_0320': ('RTG_RELATIONAL_RECOGNITION_DSN_v0_3_20.md', 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'),
         'RECOG_0321': ('RTG_RELATIONAL_RECOGNITION_DSN_v0_3_21.md', 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'),
         'RRF_083':    ('RTG_RRF_REPRESENTATION_REGISTRY_v0_8_3.md', 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'),
         'RER_r4_9':   ('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_9.md', '9c0f43fce597f6c51f834dcdb25d4bdb07087f12f37e70c5457a005b9a44cc84')}
# (id, file key, start anchor, end anchor or None = end of line, include end anchor?, role)
SPANS = [
 ('S1', 'RECOG_0321', '**(W3)**', '**(W4)**', False, 'RECOG v0.3.21 §6.16g, RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS: the W3 condition (owner text)'),
 ('S2', 'RECOG_0320', '**(W3)**', '**(W4)**', False, 'RECOG v0.3.20 §6.16g: the same W3 condition at the RER pin'),
 ('S3', 'RECOG_0321', 'RF-1 — ', ' To OFN and RER:', False, 'RECOG v0.3.21 §7.2 outbound notice RF-1 to RRF (owner text)'),
 ('S4', 'RRF_083', '| **W3** |', None, False, 'RRF v0.8.3 §6.3: the W3 row of the CELL-F4 gate table'),
 ('S5', 'RRF_083', '`[OPEN] [import: RECOG v0.3.20 §6.16g; RID: RECOG-RESULT-F4-NETWORK-WELLPOSEDNESS]', None, False, 'RRF v0.8.3 §6.3: the import line introducing the gate table'),
 ('S6', 'RER_r4_9', '[DEF] Cross-model T_k/T_-k conjugacy, a within-chart involution,', None, False, 'RER r4.9 RER-G9: the record line restating W1-W5'),
 ('S7', 'RER_r4_9', 'Reference: [RECOG: §6.16g CELL-F4', None, False, 'RER r4.9 RER-G9 reference n=1 (row G9/1)'),
 ('S8', 'RER_r4_9', 'Reference: [RRF08_ADOPTED: 6.3 Token, history and network inheritance', None, False, 'RER r4.9 RER-G9 reference n=3 (row G9/3; pinned to RRF v0.8, bytes not held here)'),
 ('S9', 'RER_r4_9', '[DEF] **r4.6 current-use overlay (RRF editor Q2: SAME-SCOPE, owner-first).**', None, False, 'RER r4.9 RER-G9 overlay line (states RRF v0.8.3 §6.3 byte-identical with v0.8 §6.3; v0.8 bytes not held here, so not checked)'),
]
TERMS = ['same', 'cohomology space', 'cohomology spaces', 'transport', 'comparison', 'pre- and post-birth', 'pre/post', 'event-indexed', 'a^-', 'a^+', '\\Delta[a]', 'map', 'extension', 'verbatim']
def load():
    return {k: (SRC / f).read_bytes() for k, (f, h) in FILES.items()}
def lineno(t, pos): return t.count('\n', 0, pos) + 1
def extract(B):
    out = []; probs = []
    for sid, fk, a, e, inc, role in SPANS:
        t = B[fk].decode('utf-8'); n = t.count(a)
        if n != 1: probs.append(f'{sid}: anchor occurs {n} times'); continue
        i = t.index(a); j = t.index('\n', i) if e is None else t.find(e, i)
        if j < 0: probs.append(f'{sid}: end anchor missing'); continue
        if e is not None and inc: j += len(e)
        s = t[i:j].rstrip()
        if not s: probs.append(f'{sid}: empty'); continue
        out.append({'id': sid, 'file': FILES[fk][0], 'file_sha256': FILES[fk][1], 'line': lineno(t, i), 'role': role, 'text': s, 'span_sha256': sha(s.encode('utf-8'))})
    return out, probs
def inventory(spans):
    return {s['id']: [w for w in TERMS if w in s['text']] for s in spans if s['id'] in ('S1', 'S3', 'S4', 'S6')}
def gates(B, spans=None, verbose=True):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('Q1 file hashes (RECOG v0.3.20, v0.3.21, RRF v0.8.3, RER r4.9)', all(sha(B[k]) == h for k, (f, h) in FILES.items()), ', '.join(f'{k} {sha(B[k])[:8]}' for k in FILES))
    sp, probs = extract(B)
    g('Q2 anchors unique, spans non-empty', not probs and len(sp) == len(SPANS), '; '.join(probs))
    if spans is None: spans = sp
    S = {s['id']: s for s in spans}
    t20, t21 = B['RECOG_0320'].decode('utf-8'), B['RECOG_0321'].decode('utf-8')
    li = lambda t: next((l for l in t.split('\n') if '**(W3)**' in l), None)
    g('Q3 RECOG §6.16g W1-W5 line byte-identical in v0.3.20 and v0.3.21', li(t20) is not None and li(t20) == li(t21) and S.get('S1', {}).get('text') == S.get('S2', {}).get('text'))
    r = B['RRF_083'].decode('utf-8'); a63, a64 = r.find('### 6.3 '), r.find('### 6.4 '); w = [i for i in range(len(r)) if r.startswith('| **W3** |', i)]
    g('Q4 RRF W3 row unique and inside §6.3', len(w) == 1 and a63 < w[0] < a64 and r.count('W3') == 1)
    ok5 = all(s['span_sha256'] == sha(s['text'].encode('utf-8')) and s['text'] in B[next(k for k, (f, h) in FILES.items() if f == s['file'])].decode('utf-8') for s in spans) and len(spans) == len(SPANS)
    g('Q5 span hashes recompute; each span occurs in its file', ok5)
    g('Q6 word inventory recomputed from the spans', inventory(spans) == inventory(sp))
    return all(res), res, sp
def render(spans):
    inv = inventory(spans)
    J = {'_about': 'Neutral W3 quotation packet for the RER-G9 per-reference audit. Verbatim spans only; no scientific judgement. Prepared by the RER preparer (Claude), 20 Oct 2026; NONCANONICAL.',
         'files': {k: {'file': f, 'sha256': h} for k, (f, h) in FILES.items()}, 'spans': spans, 'word_inventory': inv, 'terms_checked': TERMS}
    js = (json.dumps(J, ensure_ascii=False, indent=1) + '\n').encode('utf-8')
    S = {s['id']: s for s in spans}
    L = ['# RER-G9 W3 quotation packet (neutral; verbatim spans)', '',
         'Generated by `w3_quote_packet.py`; the JSON is authoritative. Spans are cut by literal anchors from byte-pinned files. Nothing here judges which formulation is correct.', '',
         '## Files', '', '| Key | File | SHA-256 |', '|---|---|---|'] + [f'| {k} | `{f}` | `{h}` |' for k, (f, h) in FILES.items()]
    L += ['', '## Table 1 — spans', '']
    for s in spans:
        L += [f"### {s['id']} — {s['role']}", '', f"`{s['file']}` line {s['line']}; span SHA-256 `{s['span_sha256']}`", '', '> ' + s['text'].replace('\n', '\n> '), '']
    L += ['## Table 2 — which checked words occur in which span (string occurrence only)', '', '| Term | S1 RECOG W3 | S3 RECOG RF-1 | S4 RRF W3 row | S6 RER G9 line |', '|---|---|---|---|---|']
    for w in TERMS:
        L.append(f"| `{w}` | {'yes' if w in inv.get('S1', []) else '—'} | {'yes' if w in inv.get('S3', []) else '—'} | {'yes' if w in inv.get('S4', []) else '—'} | {'yes' if w in inv.get('S6', []) else '—'} |")
    L += ['', 'String occurrence is not meaning: e.g. `cohomology space` also matches inside `cohomology spaces`.', '']
    return js, ('\n'.join(L) + '\n').encode('utf-8')
if __name__ == '__main__':
    B = load(); a = sys.argv[1:]
    if a and a[0] == '--negcontrol':
        allf = True
        def run(name, BB, gi, spans=None):
            global allf
            _, rr, _ = gates(BB, spans, verbose=False); good = not rr[gi]; allf &= good
            print(f'  negative control {name}: {"FAILS (good)" if good else "still passes (BAD)"}')
        flip = lambda b, k: b[:k] + bytes([b[k] ^ 1]) + b[k + 1:]
        r = B['RRF_083']; k = r.index(b'| **W3** |') + 12; run('Q1 one byte flipped in the RRF W3 row', dict(B, RRF_083=flip(r, k)), 0)
        t = B['RECOG_0321'].decode('utf-8'); run('Q3 W3 wording changed in v0.3.21 ("same" removed)', dict(B, RECOG_0321=t.replace('in the **same** cohomology space', 'in the cohomology space', 1).encode('utf-8')), 2)
        r2 = B['RRF_083'].decode('utf-8'); run('Q4 a second W3 row added to RRF', dict(B, RRF_083=r2.replace('| **W4** |', '| **W3** | duplicate |\n| **W4** |', 1).encode('utf-8')), 3)
        sp, _ = extract(B); sp2 = [dict(s) for s in sp]; sp2[3]['text'] = sp2[3]['text'].replace('transport', 'map', 1)
        run('Q5 a span paraphrased (S4 "transport" -> "map")', B, 4, sp2)
        sp3 = [dict(s) for s in sp]; sp3[0]['span_sha256'] = '0' * 64; run('Q5 a span hash forged', B, 4, sp3)
        t3 = B['RER_r4_9'].decode('utf-8'); run('Q2 RER G9 reference anchor removed', dict(B, RER_r4_9=t3.replace('Reference: [RECOG: §6.16g CELL-F4', 'Reference: [RECOG: §6.16g CELL F4', 1).encode('utf-8')), 1)
        sys.exit(0 if allf else 1)
    ok, res, sp = gates(B)
    js, md = render(sp)
    if a and a[0] == '--check':
        same = (HERE / 'w3_quotes.json').read_bytes() == js and (HERE / 'w3_quotes.md').read_bytes() == md
        print('stored outputs byte-identical:', same); sys.exit(0 if ok and same else 1)
    (HERE / 'w3_quotes.json').write_bytes(js); (HERE / 'w3_quotes.md').write_bytes(md)
    print(f'{sum(res)}/{len(res)} gates PASS; w3_quotes.json {sha(js)[:16]}, w3_quotes.md {sha(md)[:16]}')
    sys.exit(0 if ok else 1)
