"""Edit list RER v0.2 DRAFT r4.11 -> r4.12 (PI decision of 21 Oct 2026: record the B-07 receiving decisions now).
T1 RER-TRIAD-FORMAL-INVOLUTION and T2 RER-TRIAD-BIRTH-GRAPH-INVOLUTION: one sentence block appended to each Review receipt line, recording the
B-07 independent receiving review (inputs/B07_RECEIVING_REVIEW_20261021.md) claim by claim with its scope limits and evidence boundaries.
Plus metadata (M1-M3), one §9 history entry (H1) and one release-boundary sentence (H2). No grade, claim line, contract cell, import, OPEN item,
pin or other record changes; the receiver found no mandatory text correction for these two records."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_11.md').read_text(encoding='utf-8')
BASE_SHA = '2cd3f0e9f9847417785d2c2997c6344764c67e28b6e24106ce08840dda024dd8'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
B07 = '845c47562df5afea8e09270b63deaefbedc85f4e53f51c3b2d925d0b0ba07141'; PKT = 'e9ead8a0b9fe3e110be7e22d23134ad0c6be2213bdc96bef03ba5ad65c35c48c'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix, within=None):
    t = B if within is None else within
    ls = [l for l in t.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]
TFI = B.split('### RER-TRIAD-FORMAL-INVOLUTION — ')[1].split('\n### RER-')[0]
BGI = B.split('### RER-TRIAD-BIRTH-GRAPH-INVOLUTION — ')[1].split('\n### RER-')[0]

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.11\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.12\n')
ed('M2', 'metadata', '**Date:** 21 October 2026 (r4.11);', '**Date:** 21 October 2026 (r4.12, r4.11);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.11 — narrow correction revision',
   f'**Document status:** DRAFT r4.12 — receipt-only revision (PI decision of 21 Oct 2026): the B-07 receiving decisions on RER-TRIAD-FORMAL-INVOLUTION and RER-TRIAD-BIRTH-GRAPH-INVOLUTION are recorded in their Review receipts; built deterministically on the exact r4.11 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_12_draft.py`; no grade, claim, pin, OPEN item or other record changes. r4.11 was: narrow correction revision')

r1 = line('**Review receipt:** Triadic reviewer ACCEPT (formal, 15 Oct); RER editor ACCEPT SCOPED with the primitive-clock / -I_4 scope (17 Oct).', TFI)
ed('T1', 'receipt', r1, r1 + (
   f' r4.12: B-07 independent receiving review by the receiving co-owner (21 Oct 2026; decision file SHA-256 `{B07}`, on the neutral packet RER_PHASE_B07_REVIEW_PACKET_r1.zip `{PKT[:8]}…{PKT[-4:]}`): '
   '(i) ACCEPT SCOPED — independent formal derivation of S^2 = id, SN = NS, DS(0) = -I_4 and of the uniqueness proof; the hypothesis "commutes with N" is indispensable, and uniqueness among involutions commuting with F only is not obtained; '
   'the jet identities through degree 5, incl. the four slot actions and S != -I, were independently executed. '
   '(ii)(a) ACCEPT SCOPED. (ii)(b) the [ALG] kernel dimensions are kept as ACCEPT SCOPED — prior receiver certificate (19 Oct 2026), not fully replayed here: the float64 replay was independently executed for k = 2–7 with its negative control; '
   'the exact-rational replay was independently completed for k = 2–6 only (k = 7 reached the time limit); the certificate files are not in the RER package. '
   'The [NUM] kernel-basis line (A, B; fit residual 1e-14) stays [NUM] and was not independently computed. '
   'Record decision: ACCEPT SCOPED; G6, the all-order centralizer structure, convergence and physical exchange stay OPEN. '
   'This is the independent review called for above; the "RER editor" receipt of 17 Oct is the RER preparer\'s own. Owner adoption remains a separate decision.'))
r2 = line('**Review receipt:** RER editor ACCEPT SCOPED (17 Oct) with the explicit child contract in (d).', BGI)
ed('T2', 'receipt', r2, r2 + (
   f' r4.12: B-07 independent receiving review by the receiving co-owner (21 Oct 2026; decision file SHA-256 `{B07}`; jet and completion scripts independently executed; the degree-4 entries of POLY inspected directly): '
   '(a) ACCEPT SCOPED (G_2 = G_3 = 0, G_4 != 0, coefficients as recorded; covariance and graph-invariance defects kept apart); '
   '(b) ACCEPT SCOPED — C_4 = G_4[C_3]/2 is forced and unique and the degree-5 defect vanishes for kappa~ = 1, 2; no all-order completion is implied; '
   '(c) ACCEPT SCOPED — for kappa~ = 1, a statement about formal-germ equality, not a pointwise geometric disjointness theorem; '
   '(d) ACCEPT SCOPED — conditional on the stated child contract; it selects no physical child functional and does not refute the Genesis fifth-order branch. '
   'Record decision: ACCEPT SCOPED; all-order completion, the physical child contract and branch selection stay OPEN. The two historical logs pinned in TRIAD_BGJ §6 are not held. '
   'This is the independent review called for above; the "RER editor" receipt of 17 Oct is the RER preparer\'s own. Owner adoption remains a separate decision.'))

h = line('[ALG] R4.11 (21 Oct 2026) is a narrow correction revision')
ed('H1', 'history', h, '[ALG] R4.12 (21 Oct 2026) is a receipt-only revision on the exact r4.11 bytes: the B-07 independent receiving decisions on RER-TRIAD-FORMAL-INVOLUTION '
   '(ACCEPT SCOPED; (ii)(b) on the prior receiver certificate, not fully replayed; the [NUM] basis line stays [NUM]) and RER-TRIAD-BIRTH-GRAPH-INVOLUTION (ACCEPT SCOPED; (d) conditional) '
   'are appended to their Review receipts. The receiver found no mandatory text correction; no grade, claim line, contract cell, import, OPEN item or pin changes.\n' + h)
rb = '**Release boundary (r4.11):** r4.11 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.12):** r4.12 is a noncanonical review draft; it adopts, freezes and publishes nothing; the receipts it records are receiving decisions with their stated scope, not owner adoption. ' + rb)
t = B
for e in E: assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_11_to_r4_12_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
