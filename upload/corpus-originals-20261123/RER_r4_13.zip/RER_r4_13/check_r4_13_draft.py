"""Gates for RER v0.2 DRAFT r4.13 (on the exact r4.12 bytes). Exit 0 iff all pass; --tamper runs negative controls.
 M1 r4.12 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.12 byte-exactly.
 L1 locality: changed lines only at header 1/4/7; in RER-F3-N7N8 the first [ALG] line (+1 field line), the tagged infrastructure line, the Stage1 table
    heading, the overlay line (+1 boundary line), Evidence and Review receipt; in RER-TRIAD-AGE-CURVATURE the Review receipt; §9 R4.12 anchor; release boundary.
 L2 the other 22 record spans and all headings byte-identical; the 15 r3.1 contract tables (incl. F3-N7N8's) byte-identical; in the two records every
    other line byte-identical, and the Evidence / Review receipt lines are append-only.
 L3 line-initial claim tags: [ALG] net 0 (F3-N7N8 -1 tagged infrastructure line, +1 §9 history entry), others unchanged; no line-initial [ENG] (the tag name is mentioned in the history entry only).
 P1 unchanged Phase A parser: every record identical except the two records' Review receipt (append) and, for F3-N7N8, Evidence (append) and claim_lines
    (3 -> 2: the first [ALG] line rewritten, the [NUM] line identical, the tagged infrastructure line gone); grades, grade tags, exactness, task,
    adoption, contract, imports, OPEN items unchanged; gap references and source table unchanged.
 F1 the new [ALG] line states only the formal E7/E8 leading orders and the no-numerical-bound clause and points to the untagged field; the field line
    directly follows it, starts with the untagged heading, contains every sentence of the old [ALG] line's non-formal content and the B-08 classification.
 F2 no line-initial claim tag precedes "Infrastructure evidence update"; the Stage1 heading says source-reported, not a graded claim.
 F3 the boundary sentence directly follows the overlay line and directly precedes the [ALG] line; it names the r3.1 snapshot and the three current-status places.
 F4 Evidence (F3-N7N8): the Q_s bound confirmed, cell unchanged, reporting-layer attribution; the Constraints cell is byte-identical to r4.12.
 T1 / T2 receipt contents (F3-N7N8 / AGE-CURVATURE) incl. decision-file hash, per-claim decisions, INSUFFICIENT EVIDENCE items, no raise/lowering, scope.
 T3 receiver wordings relied on occur in the pinned B-08 decision file. E1 the decision file pinned. K1 the 22 cited evidence pins (carried)."""
import sys, re, hashlib, difflib, json, importlib.util
from pathlib import Path
from urllib.parse import unquote
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_13_draft as B
PARSER = HERE / 'tools/rer_parse_phaseA_r10.py'; PARSER_SHA = '7b6b98aa1417c6bab99b6447f9f5756a04d3fc74f5b9f7d767cb75b55138a7b7'
spec = importlib.util.spec_from_file_location('rer_parse_r10', PARSER); P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
PINS_FILE = HERE / 'CITED_EVIDENCE_PINS_r4_9.json'
DEC = 'inputs/B08_RECEIVING_REVIEW_20261021.md'; DEC_SHA = '6c33a39ab15c80ac35bfe02dfec36f94c50c7bf9ca726e157ad554d59c5cb9b5'
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
r31 = (HERE / 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r3_1.md').read_text(encoding='utf-8')
F3, CUR = 'RER-F3-N7N8', 'RER-TRIAD-AGE-CURVATURE'
RR, EV = '**Review receipt:**', '**Evidence:**'
OLD_ALG = '[ALG] **FINITE_ORDER.** Formal E7/E8 expansions and repaired Stage1 local box reports are retained.'
OLD_UPD = '[ALG] Infrastructure evidence update only:'
OLD_TBL = '**Reported Stage1 v2 local constants, not a region certificate:**'
OVL = '**r4.2 current-use overlay (RER-F3-N7N8):**'
FIELD = '**Infrastructure and evidence status (not a graded claim; r4.13, B-08 F3-01):**'
BOUND = '**Historical/current boundary (r4.13, B-08 F3-02):**'
NEW_ALG = '[ALG] **FINITE_ORDER.** Formal leading-order compatibility defects of the finite-jet age family:'
PF3 = [OLD_ALG, OLD_UPD, OLD_TBL, OVL, EV, RR]; PF3d = [NEW_ALG, FIELD, 'Infrastructure evidence update (r3.1/r4.2; untagged since r4.13', OLD_TBL[:-3], OVL, BOUND, EV, RR]
NEED_T1 = [DEC_SHA, 'formal E7/E8 leading orders ACCEPT SCOPED [ALG, formal]', 'finite-jet polynomials ACCEPT SCOPED', '24-direction sampling ACCEPT SCOPED [NUM, SAMPLED_ONLY]',
           'Stage-1 local box constants ACCEPT SCOPED as source-reported bounded boxes', '41/41 Stage-2 regression ACCEPT SCOPED as engineering evidence',
           'regional adequacy of the K=6 pilot, whole-region K_{7,2}/K_{8,2} certificates, multi-step error control and physical age/factor realization INSUFFICIENT EVIDENCE',
           'Record decision: CORRECTION REQUIRED', 'applied here', 'the primary grade [ALG] is neither raised nor lowered', 'The repaired Stage-1 Taylor-model engine was not rerun by the receiver',
           'no new receiver certificate is given for its results']
NEED_T2 = [DEC_SHA, 'ACCEPT SCOPED [ALG], FINITE_ORDER', 'w_13 = -(kappa_tilde^2/1024) Q_s^5 (111r^3 - 68r^2 e + 177r e^2 - 175e^3)', 'D5 wedge R8 = w_13', 'B7 parallel to D5',
           'at zero directions only the leading term vanishes and no exact collinearity follows', 'Scope: fixed parent chart and child plane', 'no statement on general nonlinear carrier changes, physical age, memory or all-order curved families',
           'refers to the C09 note as their own']
DECQ = ['RER r4.12 kararı: ACCEPT SCOPED', 'Bilimsel karar: ACCEPT SCOPED — `[ALG]`, `FINITE_ORDER`', 'ACCEPT SCOPED `[ALG, formal]`', 'ACCEPT SCOPED `[NUM, SAMPLED_ONLY]`',
        'kaynakta bildirilen sınırlı kutular', 'INSUFFICIENT EVIDENCE', 'RER-F3-N7N8: CORRECTION REQUIRED', 'otomatik yükseltilmesine veya düşürülmesine gerek yok',
        'RER\'nin Constraints hücresi doğru sınırı içeriyor', 'Onarılmış Stage-1 Taylor-model motorunu bu incelemede yeniden çalıştırmadım', 'Hiçbir adoption, freeze veya yayın yapılmadı']
NONFORMAL = ['The complete Stage2 replay bundle', '41-expectation suite passes in an isolated receiving rerun', 'All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N)', 'K=8 remains stopped at 1/8',
             'scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026', 'governing full-domain coverage remains OPEN; no global controlled approximate closure is accepted']
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]; out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def parsed(t):
    return {rid: (P.parse_record(rid, ti, bo) if rid not in P.GAPS else [l for l in bo.splitlines() if l.startswith('Reference:')]) for rid, ti, bo in P.blocks(t)}
def gates(d, verbose=True, dec=None):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.12 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.12 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    fi, fj = Sb[F3][0], Sb[F3][1]; ci, cj = Sb[CUR][0], Sb[CUR][1]
    allowed = {0, 3, 6} | {k for k in range(fi, fj) if any(Lb[k].startswith(p) for p in PF3)} | {k for k in range(ci, cj) if Lb[k].startswith(RR)} \
              | {k for k, l in enumerate(Lb) if l.startswith('[ALG] R4.12 (21 Oct 2026)') or l.startswith('**Release boundary (r4.12):**')}
    def in_scope(a1, a2): return set(range(a1, a2)) <= allowed if a2 > a1 else bool({a1 - 1, a1} & allowed)
    bad = [(t, a1, a2) for t, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes() if t != 'equal' and not in_scope(a1, a2)]
    g('L1 locality: header, six F3-N7N8 lines (+2 new), AGE-CURVATURE receipt, §9 anchor, release boundary', not bad, f'{len(bad)} out-of-scope hunks')
    tables = re.findall(r'(### RER-[A-Z0-9-]+ — [^\n]*\n\*\*Primary grade:\*\*[^\n]*\n\n\| Field \| Contract \|\n\|---\|---\|\n(?:\|[^\n]*\n){6})', r31)
    tab_age = [x for x in tables if x.startswith('### RER-TRIAD-FORMAL-AGE — ')]; others_t = [x for x in tables if x not in tab_age]
    tl = tab_age[0].split('\n') if tab_age else []
    age_tab_ok = len(tab_age) == 1 and tl[0] in d and '\n'.join(tl[2:]) in d  # its grade line changed in r4.11 (accepted); the rest of the table must be intact
    keep = lambda L, pre: [l for l in L if not any(l.startswith(p) for p in pre)]
    fb, fd = Sb[F3][2].split('\n'), Sd.get(F3, (0, 0, ''))[2].split('\n'); cb, cd = Sb[CUR][2].split('\n'), Sd.get(CUR, (0, 0, ''))[2].split('\n')
    app = lambda Lx, Ly, pre: [l for l in Ly if l.startswith(pre)] and [l for l in Lx if l.startswith(pre)] and [l for l in Ly if l.startswith(pre)][0].startswith([l for l in Lx if l.startswith(pre)][0] + ' r4.13')
    g('L2 other spans, headings and the r3.1 tables byte-identical (FORMAL-AGE table: grade line changed in r4.11, rest intact); other lines of the two records unchanged; Evidence/receipt append-only',
      set(Sb) == set(Sd) and len(Sb) == 24 and all(Sb[k][2] == Sd[k][2] for k in Sb if k not in (F3, CUR)) and len(others_t) == 15 and all(x in d for x in others_t) and age_tab_ok
      and keep(fb, PF3) == keep(fd, PF3d) and keep(cb, [RR]) == keep(cd, [RR]) and app(fb, fd, EV) and app(fb, fd, RR) and app(cb, cd, RR))
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    lc = lambda s, t: sum(1 for l in s.split('\n') if l.startswith(t))
    g('L3 line-initial claim tags: all counts unchanged (F3-N7N8 -1 [ALG], history +1 [ALG]); no [ENG] anywhere', all(lc(d, t) == lc(b, t) for t in tags) and lc(d, '[ENG]') == 0 and lc(Sd.get(F3, (0, 0, ''))[2], '[ALG]') == lc(Sb[F3][2], '[ALG]') - 1,
      str({t: lc(d, t) - lc(b, t) for t in tags if lc(d, t) != lc(b, t)}))
    pb, pd = parsed(b), parsed(d)
    def strip(x, fs): y = dict(x); y['fields'] = {k: v for k, v in x['fields'].items() if k not in fs}; y.pop('claim_lines'); return y
    xf0, xf1 = pb[F3], pd.get(F3, {'fields': {}, 'claim_lines': []})
    okp = hashlib.sha256(PARSER.read_bytes()).hexdigest() == PARSER_SHA and set(pb) == set(pd) and all(pb[r] == pd[r] for r in pb if r not in (F3, CUR)) \
          and strip(xf0, ('Evidence', 'Review receipt')) == strip(xf1, ('Evidence', 'Review receipt')) \
          and len(xf0['claim_lines']) == 3 and len(xf1['claim_lines']) == 2 and xf1['claim_lines'][1] == xf0['claim_lines'][1] and xf0['claim_lines'][1].startswith('[NUM] **SAMPLED_ONLY.**') \
          and xf0['claim_lines'][0] == OLD_ALG[:len(OLD_ALG)] + xf0['claim_lines'][0][len(OLD_ALG):] and xf1['claim_lines'][0].startswith(NEW_ALG) and xf0['claim_lines'][2].startswith(OLD_UPD) \
          and xf1['fields']['Evidence'].startswith(xf0['fields']['Evidence'] + ' r4.13') and xf1['fields']['Review receipt'].startswith(xf0['fields']['Review receipt'] + ' r4.13') \
          and xf1['grade_tags'] == xf0['grade_tags'] == ['ALG'] and xf1['primary_grade'] == xf0['primary_grade'] and xf1['task'] == xf0['task'] == 'GLOBAL_CERTIFICATE_PENDING' \
          and {k: v for k, v in pd[CUR].items() if k != 'fields'} == {k: v for k, v in pb[CUR].items() if k != 'fields'} and {k: v for k, v in pd[CUR]['fields'].items() if k != 'Review receipt'} == {k: v for k, v in pb[CUR]['fields'].items() if k != 'Review receipt'} \
          and pd[CUR]['fields']['Review receipt'].startswith(pb[CUR]['fields']['Review receipt'] + ' r4.13') and P.source_table(b) == P.source_table(d)
    g('P1 parser: all records identical except F3-N7N8 (claim lines 3 -> 2, [NUM] identical, Evidence/receipt append) and AGE-CURVATURE receipt (append); grades/tasks/contracts/imports/OPEN unchanged', okp)
    i_alg = next((k for k, l in enumerate(fd) if l.startswith(NEW_ALG)), -1); alg = fd[i_alg] if i_alg >= 0 else ''; fld = fd[i_alg + 1] if 0 <= i_alg < len(fd) - 1 else ''
    f1 = (i_alg >= 0 and 'E7 = Delta_tau C8 + Delta_tau C9 + O(R^10) and E8 = Delta_tau C9 + O(R^10)' in alg and 'gives no numerical upper bound on the proposed region' in alg
          and 'is evidence status, not a graded claim, and is recorded in the untagged field below' in alg and not any(s in alg for s in NONFORMAL)
          and fld.startswith(FIELD) and all(s in fld for s in NONFORMAL) and 'INSUFFICIENT EVIDENCE for regional coverage' in fld and 'engineering evidence' in fld and not re.match(r'^\[(THM|ALG|NUM|DEF)\]', fld))
    g('F1 formal [ALG] line and the untagged status field directly below it (all non-formal sentences moved, none left in the claim)', f1)
    f2 = (not any(re.match(r'^\[(THM|ALG|NUM|DEF)\]', l) and 'Infrastructure evidence update' in l for l in fd) and any(l.startswith('Infrastructure evidence update (r3.1/r4.2; untagged since r4.13') for l in fd)
          and any(l.startswith(OLD_TBL[:-3] + ' (source-reported evidence; not a graded claim of this record; r4.13):**') for l in fd))
    g('F2 no claim tag on the infrastructure update; Stage1 heading says source-reported, not a graded claim', f2)
    i_ov = next((k for k, l in enumerate(fd) if l.startswith(OVL)), -1)
    f3 = i_ov >= 0 and i_ov + 2 < len(fd) and fd[i_ov + 1].startswith(BOUND) and fd[i_ov + 2].startswith(NEW_ALG) and 'preserved r3.1 snapshot and is not edited' in fd[i_ov + 1] \
         and 'r4.2 overlay above' in fd[i_ov + 1] and 'Infrastructure and evidence status' in fd[i_ov + 1] and '[OPEN] lines below' in fd[i_ov + 1]
    g('F3 boundary sentence between the overlay and the [ALG] line, naming the snapshot and the three current-status places', f3)
    ev1 = next((l for l in fd if l.startswith(EV)), ''); con_b = next((l for l in fb if l.startswith('| Constraints |')), ''); con_d = next((l for l in fd if l.startswith('| Constraints |')), '')
    f4 = 'R^2/2 <= Q_s <= 3R^2/2' in ev1 and "confirmed by the receiver's independent algebra" in ev1 and "source script's reporting layer, not this cell, which is unchanged" in ev1 and con_b == con_d and 'R^2/2<=Qs<=3R^2/2' in con_d
    g('F4 Evidence: Q_s bound confirmed and attributed; Constraints cell byte-identical', f4)
    rr1 = next((l for l in fd if l.startswith(RR)), ''); rr2 = next((l for l in cd if l.startswith(RR)), '')
    g('T1 F3-N7N8 receipt content', all(s in rr1 for s in NEED_T1), f'missing {[s[:40] for s in NEED_T1 if s not in rr1][:2]}')
    g('T2 AGE-CURVATURE receipt content', all(s in rr2 for s in NEED_T2), f'missing {[s[:40] for s in NEED_T2 if s not in rr2][:2]}')
    D = dec if dec is not None else (HERE / DEC).read_bytes(); Dt = D.decode('utf-8')
    g('T3 receiver wordings present in the pinned B-08 decision file', all(q in Dt for q in DECQ), f'missing {[q[:40] for q in DECQ if q not in Dt][:2]}')
    g('E1 B-08 decision file pinned', hashlib.sha256(D).hexdigest() == DEC_SHA)
    pins = json.loads(PINS_FILE.read_text(encoding='utf-8'))
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 22 cited evidence pins carried', not miss and len(pins) == 22, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    L0 = d0.split('\n'); FLD = next(l for l in L0 if l.startswith(FIELD)); ALG = next(l for l in L0 if l.startswith(NEW_ALG))
    T = [('L1 edit outside the scope', 3, d0.replace('### RER-GEN-C01 — ', '### RER-GEN-C01 — (r4.13) ', 1)),
         ('L2 F3-N7N8 Closure cell edited', 4, d0.replace('| Closure status | FINITE_ORDER_VERIFIED_LOCAL_BOUND_REPORTED_INFRASTRUCTURE_REPLAYED_GLOBAL_PENDING:', '| Closure status | FINITE_ORDER (r4.13):', 1)),
         ('L2 receipt rewritten instead of appended', 4, d0.replace('**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending. [TRIAD_R2_REVIEW: Triadic contributor review of RER v0.2 DRAFT r2 — record-by-record scope check](sources/current/TRIAD_RER_v0_2_r2_RECORD_REVIEW_20261014.md); lines 1–30; RID unavailable; exact section pinned; SHA-256 `d388d7eb0e0855051d0a783383b69254be17f64102e6568fdc37c5d3e907e1ab`. r4.13: B-08 independent receiving review by the receiving co-owner (21 Oct 2026; decision file SHA-256 `6c33a39a', '**Review receipt:** B-08 independent receiving review by the receiving co-owner (21 Oct 2026; decision file SHA-256 `6c33a39a', 1)),
         ('L3 [ENG] tag introduced', 5, d0.replace(FIELD, '[ENG] ' + FIELD, 1)),
         ('L3 the [NUM] line promoted to [ALG]', 5, d0.replace('[NUM] **SAMPLED_ONLY.** 24-direction', '[ALG] **SAMPLED_ONLY.** 24-direction', 1)),
         ('P1 F3-N7N8 primary grade changed', 6, d0.replace('**Primary grade:** [ALG]. **Exactness:** `FINITE_ORDER`. **Task:** `GLOBAL_CERTIFICATE_PENDING`.', '**Primary grade:** [THM]. **Exactness:** `FINITE_ORDER`. **Task:** `GLOBAL_CERTIFICATE_PENDING`.', 1)),
         ('P1 the [NUM] line altered', 6, d0.replace('no continuous-domain supremum or optimality claim.', 'a continuous-domain supremum.', 1)),
         ('P1 an OPEN item of F3-N7N8 dropped', 6, d0.replace('[OPEN] multi-step state and observable errors\n', '', 1)),
         ('F1 infrastructure sentence left inside the [ALG] claim', 7, d0.replace(ALG, ALG + ' All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N).', 1)),
         ('F1 status field tagged as a claim', 7, d0.replace(FIELD, '[DEF] ' + FIELD, 1)),
         ('F1 K=6 pilot presented as regional coverage', 7, d0.replace('is INSUFFICIENT EVIDENCE for regional coverage', 'certifies regional coverage', 1)),
         ('F1 no-numerical-bound clause dropped', 7, d0.replace('; the O(R^10) term gives no numerical upper bound on the proposed region', '', 1)),
         ('F2 infrastructure update line re-tagged [ALG]', 8, d0.replace('Infrastructure evidence update (r3.1/r4.2; untagged since r4.13', '[ALG] Infrastructure evidence update (r3.1/r4.2; untagged since r4.13', 1)),
         ('F2 Stage1 heading without the source-reported label', 8, d0.replace(' (source-reported evidence; not a graded claim of this record; r4.13):**', ':**', 1)),
         ('F3 boundary sentence removed', 9, d0.replace(next(l for l in L0 if l.startswith(BOUND)) + '\n', '', 1)),
         ('F3 boundary sentence claims the snapshot cell is current', 9, d0.replace(next(l for l in L0 if l.startswith(BOUND)), next(l for l in L0 if l.startswith(BOUND)).replace('is the preserved r3.1 snapshot and is not edited', 'is the current status', 1), 1)),
         ('F4 Constraints bound edited', 10, d0.replace('R^2/2<=Qs<=3R^2/2;', 'Qs<=R^2;', 1)),
         ('F4 reporting-layer attribution dropped', 10, d0.replace("concerns the source script's reporting layer, not this cell, which is unchanged", 'applies to this cell', 1)),
         ('T1 INSUFFICIENT EVIDENCE items dropped', 11, d0.replace(' and physical age/factor realization INSUFFICIENT EVIDENCE', ' and physical age/factor realization ACCEPT SCOPED', 1)),
         ('T1 grade stated as raised', 11, d0.replace('the primary grade [ALG] is neither raised nor lowered', 'the primary grade is raised to [THM]', 1)),
         ('T1 Taylor-model engine claimed rerun by the receiver', 11, d0.replace('The repaired Stage-1 Taylor-model engine was not rerun by the receiver', 'The repaired Stage-1 Taylor-model engine was rerun by the receiver', 1)),
         ('T2 zero-direction limit dropped', 12, d0.replace('; at zero directions only the leading term vanishes and no exact collinearity follows', '', 1)),
         ('T2 scope widened to physical age', 12, d0.replace('no statement on general nonlinear carrier changes, physical age, memory or all-order curved families', 'a statement on physical age', 1))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, r12 = gates(b, verbose=False); good = not r12[7] and not r12[9] and not r12[11]; allf &= good
    print(f'  r4.12 bytes: F1, F3, T1 = {[r12[7], r12[9], r12[11]]} (expected all False)')
    D = (HERE / DEC).read_bytes()
    for n, bb, gi in [('E1 decision file altered', D + b'x', 14), ('T3 decision file without the CORRECTION REQUIRED wording', D.replace('RER-F3-N7N8: CORRECTION REQUIRED'.encode(), 'RER-F3-N7N8: ACCEPT SCOPED'.encode(), 1), 13)]:
        assert bb != D
        _, rr = gates(d0, verbose=False, dec=bb); good = not rr[gi]; allf &= good
        print(f'  input control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    ok = ok and allf
sys.exit(0 if ok else 1)
