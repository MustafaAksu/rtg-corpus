"""Gates for RER v0.2 DRAFT r4.12 (on the exact r4.11 bytes). Exit 0 iff all pass; --tamper runs negative controls.
 M1 r4.11 base SHA; M2 deterministic rebuild; M3 reverse edits recover r4.11 byte-exactly.
 L1 locality: changed r4.11 lines only at header 1/4/7, the two Review receipt lines, the §9 R4.11 anchor and the release boundary.
 L2 the other 22 record spans and all headings byte-identical; inside the two records every line except Review receipt byte-identical, and each new
    receipt line starts with the old one (append only).
 L3 line-initial claim tags: [ALG] +1 (the §9 history entry), all others unchanged (tags quoted inside the receipt prose are not claim tags).
 P1 unchanged Phase A parser: every record and gap Reference parses identically except the Review receipt field of the two records (new = old + " r4.12: ...");
    grades, grade tags, claim lines, contract, imports, OPEN items unchanged; source table unchanged.
 T1 FORMAL-INVOLUTION receipt: decision-file hash; (i) ACCEPT SCOPED with the N-commutation limit; (ii)(a); (ii)(b) "prior receiver certificate, not fully
    replayed here" with the k = 2–6 exact / k = 2–7 float64 boundary and certificate files not in the package; [NUM] line stays [NUM]; OPEN items named;
    the 17 Oct "RER editor" receipt marked as the preparer's own; adoption separate.
 T2 BIRTH-GRAPH receipt: decision-file hash; (a)-(d) with their scope limits; (d) conditional, no physical selection, no refutation of the Genesis
    fifth-order branch; OPEN items; logs not held; the 17 Oct receipt marked as the preparer's own; adoption separate.
 T3 every receiver wording quoted in T1/T2 that the gates require occurs in the pinned B-07 decision file.
 E1 inputs pinned: B-07 decision file. K1 the 22 cited evidence pins (carried)."""
import sys, re, hashlib, difflib, json, importlib.util
from pathlib import Path
from urllib.parse import unquote
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import build_r4_12_draft as B
PARSER = HERE / 'tools/rer_parse_phaseA_r10.py'; PARSER_SHA = '7b6b98aa1417c6bab99b6447f9f5756a04d3fc74f5b9f7d767cb75b55138a7b7'
spec = importlib.util.spec_from_file_location('rer_parse_r10', PARSER); P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
PINS_FILE = HERE / 'CITED_EVIDENCE_PINS_r4_9.json'
DEC = 'inputs/B07_RECEIVING_REVIEW_20261021.md'; DEC_SHA = '845c47562df5afea8e09270b63deaefbedc85f4e53f51c3b2d925d0b0ba07141'
b, E = B.load(); d0 = B.OUT.read_text(encoding='utf-8')
TFI, BGI = 'RER-TRIAD-FORMAL-INVOLUTION', 'RER-TRIAD-BIRTH-GRAPH-INVOLUTION'
RR = '**Review receipt:**'
NEED1 = [DEC_SHA, '(i) ACCEPT SCOPED', 'the hypothesis "commutes with N" is indispensable', 'uniqueness among involutions commuting with F only is not obtained',
         '(ii)(a) ACCEPT SCOPED', 'ACCEPT SCOPED — prior receiver certificate (19 Oct 2026), not fully replayed here', 'independently executed for k = 2–7',
         'independently completed for k = 2–6 only (k = 7 reached the time limit)', 'the certificate files are not in the RER package',
         'The [NUM] kernel-basis line (A, B; fit residual 1e-14) stays [NUM] and was not independently computed', 'Record decision: ACCEPT SCOPED; G6',
         'the "RER editor" receipt of 17 Oct is the RER preparer\'s own', 'Owner adoption remains a separate decision.']
NEED2 = [DEC_SHA, '(a) ACCEPT SCOPED', '(b) ACCEPT SCOPED', 'no all-order completion is implied', '(c) ACCEPT SCOPED — for kappa~ = 1', 'not a pointwise geometric disjointness theorem',
         '(d) ACCEPT SCOPED — conditional on the stated child contract', 'selects no physical child functional', 'does not refute the Genesis fifth-order branch',
         'Record decision: ACCEPT SCOPED; all-order completion', 'two historical logs', 'are not held', 'the "RER editor" receipt of 17 Oct is the RER preparer\'s own', 'Owner adoption remains a separate decision.']
# receiver wording that must be present in the pinned decision file (T3)
DECQ = ['ACCEPT SCOPED — prior receiver certificate, not fully replayed here', '\\\\(k=2,\\ldots,6\\\\) sonuçlarını elde ettim', '\\\\(k=7\\\\) tamamlanmadan çalıştırma zaman sınırına ulaştı',
        'o satır `[NUM]` olarak kalmalı', 'ACCEPT SCOPED — conditional', 'bütün uzayda noktasal geometrik ayrıklık teoremi değildir', 'Genesis\'in beşinci-mertebe dalını da çürütmez',
        'Bu karar, mevcut RER r4.11 metninin bu iki kayıt için zorunlu bir düzeltme gerektirdiğini göstermiyor', 'Hiçbir adoption, freeze veya yayın kararı verilmedi']
def spans(t):
    L = t.split('\n'); heads = [i for i, l in enumerate(L) if re.match(r'^### RER-[A-Z0-9-]+ — ', l)]; out = {}
    for i in heads:
        j = next((k for k in range(i + 1, len(L)) if L[k].startswith('<a id=') or L[k].startswith('## ') or L[k].startswith('### RER-')), len(L))
        out[re.match(r'^### (RER-[A-Z0-9-]+) — ', L[i]).group(1)] = (i, j, '\n'.join(L[i:j]))
    return out
def parsed(t):
    return {rid: (P.parse_record(rid, ti, bo) if rid not in P.GAPS else [l for l in bo.splitlines() if l.startswith('Reference:')]) for rid, ti, bo in P.blocks(t)}
def gates(d, verbose=True, dec=None):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    g('M1 r4.11 base SHA', hashlib.sha256(b.encode()).hexdigest() == B.BASE_SHA)
    g('M2 deterministic rebuild', B.apply(b, E) == d, hashlib.sha256(d.encode()).hexdigest()[:16])
    rev, ok = d, True
    for e in reversed(E):
        if rev.count(e['new']) != 1: ok = False; break
        rev = rev.replace(e['new'], e['old'])
    g('M3 reverse edits recover r4.11 byte-exactly', ok and rev == b)
    Lb, Ld = b.split('\n'), d.split('\n'); Sb, Sd = spans(b), spans(d)
    allowed = {0, 3, 6} | {k for r in (TFI, BGI) for k in range(Sb[r][0], Sb[r][1]) if Lb[k].startswith(RR)} \
              | {k for k, l in enumerate(Lb) if l.startswith('[ALG] R4.11 (21 Oct 2026)') or l.startswith('**Release boundary (r4.11):**')}
    def in_scope(a1, a2): return set(range(a1, a2)) <= allowed if a2 > a1 else bool({a1 - 1, a1} & allowed)
    bad = [(t, a1, a2) for t, a1, a2, c1, c2 in difflib.SequenceMatcher(None, Lb, Ld, autojunk=False).get_opcodes() if t != 'equal' and not in_scope(a1, a2)]
    g('L1 locality: header, the two Review receipt lines, §9 anchor, release boundary', not bad, f'{len(bad)} out-of-scope hunks')
    def split_rr(s): L = s.split('\n'); return [l for l in L if not l.startswith(RR)], [l for l in L if l.startswith(RR)]
    ok2 = set(Sb) == set(Sd) and len(Sb) == 24 and all(Sb[k][2] == Sd[k][2] for k in Sb if k not in (TFI, BGI))
    for r in (TFI, BGI):
        ob, rb = split_rr(Sb[r][2]); od, rd = split_rr(Sd.get(r, (0, 0, ''))[2])
        ok2 = ok2 and ob == od and len(rb) == len(rd) == 1 and rd[0].startswith(rb[0] + ' r4.12: ') and rd[0] != rb[0]
    g('L2 other spans byte-identical; in the two records only the Review receipt changes, by appending', ok2)
    tags = ['[THM]', '[ALG]', '[DEF]', '[NUM]', '[COR]', '[OPEN]', '[HEUR]', '[RETRACTED]', '[FAIL]']
    lc = lambda s, t: sum(1 for l in s.split('\n') if l.startswith(t))  # line-initial claim tags; tags quoted inside receipt prose are not claims
    g('L3 line-initial claim tags: [ALG] +1 (history entry), others unchanged', all(lc(d, t) == lc(b, t) + {'[ALG]': 1}.get(t, 0) for t in tags), str({t: lc(d, t) - lc(b, t) for t in tags if lc(d, t) != lc(b, t)}))
    pb, pd = parsed(b), parsed(d)
    def strip(x): y = dict(x); y['fields'] = {k: v for k, v in x['fields'].items() if k != 'Review receipt'}; return y
    okp = hashlib.sha256(PARSER.read_bytes()).hexdigest() == PARSER_SHA and set(pb) == set(pd) and all(pb[r] == pd[r] for r in pb if r not in (TFI, BGI)) \
          and all(strip(pb[r]) == strip(pd[r]) and pd[r]['fields']['Review receipt'].startswith(pb[r]['fields']['Review receipt'] + ' r4.12: ') for r in (TFI, BGI)) \
          and P.source_table(b) == P.source_table(d)
    g('P1 parser: all records, gap references and source table identical except the two Review receipt fields (append only)', okp)
    r1 = next((l for l in Sd.get(TFI, (0, 0, ''))[2].split('\n') if l.startswith(RR)), ''); r2 = next((l for l in Sd.get(BGI, (0, 0, ''))[2].split('\n') if l.startswith(RR)), '')
    g('T1 FORMAL-INVOLUTION receipt content', all(s in r1 for s in NEED1), f'missing {[s[:40] for s in NEED1 if s not in r1][:2]}')
    g('T2 BIRTH-GRAPH receipt content', all(s in r2 for s in NEED2), f'missing {[s[:40] for s in NEED2 if s not in r2][:2]}')
    D = dec if dec is not None else (HERE / DEC).read_bytes(); Dt = D.decode('utf-8')
    g('T3 receiver wordings present in the pinned B-07 decision file', all(q in Dt for q in DECQ), f'missing {[q[:40] for q in DECQ if q not in Dt][:2]}')
    g('E1 B-07 decision file pinned', hashlib.sha256(D).hexdigest() == DEC_SHA)
    pins = json.loads(PINS_FILE.read_text(encoding='utf-8'))
    miss = [p for p, v in pins.items() if not (HERE / p).is_file() or hashlib.sha256((HERE / p).read_bytes()).hexdigest() != v['sha256'] or ('(' + p + ')') not in unquote(d).replace('](', '(').replace('] (', '(')]
    g('K1 22 cited evidence pins carried', not miss and len(pins) == 22, f'{len(pins)} pins, {len(miss)} bad')
    return all(res), res
ok, res = gates(d0); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    T = [('L1 edit outside the scope', 3, d0.replace('### RER-GEN-C01 — ', '### RER-GEN-C01 — (r4.12) ', 1)),
         ('L2 a claim line of FORMAL-INVOLUTION altered', 4, d0.replace('is the unique formal involution that both commutes with N and has linear part -I_4', 'is the unique formal involution that commutes with N', 1)),
         ('L2 receipt rewritten instead of appended', 4, d0.replace('**Review receipt:** RER editor ACCEPT SCOPED (17 Oct) with the explicit child contract in (d).', '**Review receipt:** with the explicit child contract in (d).', 1)),
         ('L3 claim (ii) promoted ([ALG] -> [THM])', 5, d0.replace('[ALG] **(ii) FINITE_ORDER.**', '[THM] **(ii) FINITE_ORDER.**', 1)),
         ('P1 FORMAL-INVOLUTION grade line changed', 6, d0.replace('**Primary grade:** [THM] for (i); [ALG] for (ii).', '**Primary grade:** [THM] for (i) and (ii).', 1)),
         ('T1 prior-certificate limit dropped', 7, d0.replace('ACCEPT SCOPED — prior receiver certificate (19 Oct 2026), not fully replayed here', 'ACCEPT SCOPED', 1)),
         ('T1 exact replay claimed through k = 7', 7, d0.replace('independently completed for k = 2–6 only (k = 7 reached the time limit)', 'independently completed for k = 2–7', 1)),
         ('T1 [NUM] basis line promoted', 7, d0.replace('stays [NUM] and was not independently computed', 'is confirmed', 1)),
         ('T1 N-commutation limit dropped', 7, d0.replace('; the hypothesis "commutes with N" is indispensable, and uniqueness among involutions commuting with F only is not obtained', '', 1)),
         ('T1 preparer receipt presented as independent', 7, d0.replace('the "RER editor" receipt of 17 Oct is the RER preparer\'s own', 'the RER editor receipt of 17 Oct is independent', 1)),
         ('T2 (d) stated unconditionally', 8, d0.replace('(d) ACCEPT SCOPED — conditional on the stated child contract', '(d) ACCEPT SCOPED', 1)),
         ('T2 (c) widened to a pointwise theorem', 8, d0.replace(', not a pointwise geometric disjointness theorem', '', 1)),
         ('T2 Genesis branch claimed refuted', 8, d0.replace('does not refute the Genesis fifth-order branch', 'refutes the Genesis fifth-order branch', 1)),
         ('T2 all-order completion implied', 8, d0.replace('; no all-order completion is implied', '', 1)),
         ('T2 adoption implied', 8, d0.replace('Owner adoption remains a separate decision.', 'Owner adoption follows.', 2))]
    allf = True
    for n, i, t in T:
        assert t != d0, n
        _, rr = gates(t, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, r11 = gates(b, verbose=False); good = not r11[7] and not r11[8]; allf &= good
    print(f'  r4.11 bytes: T1, T2 = {[r11[7], r11[8]]} (expected both False)')
    D = (HERE / DEC).read_bytes()
    for n, bb, gi in [('E1 decision file altered', D + b'x', 10), ('T3 decision file without the prior-certificate wording', D.replace('ACCEPT SCOPED — prior receiver certificate, not fully replayed here'.encode(), b'ACCEPT SCOPED', 1), 9)]:
        assert bb != D
        _, rr = gates(d0, verbose=False, dec=bb); good = not rr[gi]; allf &= good
        print(f'  input control {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    ok = ok and allf
sys.exit(0 if ok else 1)
