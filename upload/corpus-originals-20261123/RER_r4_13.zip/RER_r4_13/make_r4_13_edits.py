"""Edit list RER v0.2 DRAFT r4.12 -> r4.13 (B-08 receiving review of 21 Oct 2026; PI decision of 21 Oct 2026: untagged infrastructure field, proceed).
F  RER-F3-N7N8 (B-08: CORRECTION REQUIRED, evidence classification and record clarity):
   F1 (F3-01) the mixed `[ALG] FINITE_ORDER` claim line keeps only the formal content (E7/E8 leading orders; no numerical region bound); the
      infrastructure, pilot and review-status sentences move to a new untagged field `**Infrastructure and evidence status (not a graded claim):**`.
   F2 (F3-01) the second `[ALG] Infrastructure evidence update only ...` line loses its tag and is folded into that field (no claim tag for an
      infrastructure fact). The `[NUM] SAMPLED_ONLY` line is unchanged.
   F3 (F3-01) the Stage-1 table heading states that the constants are source-reported evidence, not a graded claim.
   F4 (F3-02) one boundary sentence before the r3.1 contract table: the Closure cell is a historical snapshot, current status is in the overlay and
      the new field.
   F5 (F3-03) Evidence: the receiver's independent algebra confirms the Constraints bound R^2/2 <= Q_s <= 3R^2/2; the N7REVIEW §3 critique concerns the
      source script's reporting layer; the Constraints cell is not changed.
   F6 Review receipt: B-08 decisions per claim (incl. INSUFFICIENT EVIDENCE items) and the record decision CORRECTION REQUIRED, applied here.
C  RER-TRIAD-AGE-CURVATURE: C1 Review receipt: B-08 ACCEPT SCOPED with its stated scope.
Plus metadata (M1-M3), one §9 history entry (H1) recording also the r4.12 acceptance, and one release-boundary sentence (H2).
No grade, exactness, task, contract cell, import, OPEN item, pin or other record changes; the primary grade [ALG] of F3-N7N8 stays (receiver: no
automatic raise or lowering). No new claim tag vocabulary is introduced (PI decision: untagged field, not [ENG])."""
import json, hashlib
from pathlib import Path
B = Path('RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_12.md').read_text(encoding='utf-8')
BASE_SHA = '7313647ae14a5e4f757b4afadf76995b6c3408a27b3e0e538ac3291842e2f4b9'
assert hashlib.sha256(B.encode()).hexdigest() == BASE_SHA
B08 = '6c33a39ab15c80ac35bfe02dfec36f94c50c7bf9ca726e157ad554d59c5cb9b5'; PKT = '672ccb94c03a36cff13dd790bbe1916f498845b9ad9930e60a210e0ed464edaa'
E = []
def ed(eid, kind, old, new):
    assert B.count(old) == 1, (eid, B.count(old)); E.append({'id': eid, 'kind': kind, 'old': old, 'new': new})
def line(prefix, within=None):
    t = B if within is None else within
    ls = [l for l in t.split('\n') if l.startswith(prefix)]; assert len(ls) == 1, (prefix, len(ls)); return ls[0]
F3 = B.split('### RER-F3-N7N8 — ')[1].split('\n### RER-')[0]
CUR = B.split('### RER-TRIAD-AGE-CURVATURE — ')[1].split('\n### RER-')[0]

ed('M1', 'metadata', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.12\n', '# RTG — Relational Emergence Registry v0.2 DRAFT r4.13\n')
ed('M2', 'metadata', '**Date:** 21 October 2026 (r4.12, r4.11);', '**Date:** 21 October 2026 (r4.13, r4.12, r4.11);')
ed('M3', 'metadata', '**Document status:** DRAFT r4.12 — receipt-only revision',
   f'**Document status:** DRAFT r4.13 — narrow correction revision (B-08 receiving review and PI decision of 21 Oct 2026): in RER-F3-N7N8 the formal `[ALG]` claim is separated from infrastructure, pilot and review-status text, which moves to an untagged evidence-status field; a historical/current boundary sentence is added; the B-08 receipts are recorded on RER-F3-N7N8 and RER-TRIAD-AGE-CURVATURE; built deterministically on the exact r4.12 bytes (SHA-256 `{BASE_SHA}`) by `build_r4_13_draft.py`; no grade, exactness, task, contract cell, import, OPEN item or pin changes. r4.12 was: receipt-only revision')

# ---- F3-N7N8
alg = line('[ALG] **FINITE_ORDER.** Formal E7/E8 expansions and repaired Stage1 local box reports are retained.', F3)
alg_new = ('[ALG] **FINITE_ORDER.** Formal leading-order compatibility defects of the finite-jet age family: E7 = Delta_tau C8 + Delta_tau C9 + O(R^10) and E8 = Delta_tau C9 + O(R^10) '
           '(E7 starts at degree 8, E8 at degree 9), as formal coefficient identities; the O(R^10) term gives no numerical upper bound on the proposed region. '
           'Everything else formerly stated in this line (local box reports, Stage-2 infrastructure and pilot status, lemma-review status) is evidence status, not a graded claim, and is recorded in the untagged field below (r4.13, B-08 F3-01).')
infra = ('**Infrastructure and evidence status (not a graded claim; r4.13, B-08 F3-01):** Formal E7/E8 expansions and repaired Stage1 local box reports are retained. The complete Stage2 replay bundle supplies the current driver, coarse K=4 configuration and 104 worker rows. '
         'The unchanged 41-expectation suite passes in an isolated receiving rerun, including one coarse retry test; the workers and pilots are not regenerated. All 8/8 K=6 pilot rows pass the governing contract (4/904 boxes per N); K=8 remains stopped at 1/8 under its separate config. '
         'A scoped independent Taylor-model lemma review is reported completed (RECEIVER-REPORTED, 19 Oct 2026; per-stage guard a ≤ 1 pending installation); governing full-domain coverage remains OPEN; no global controlled approximate closure is accepted. '
         'Infrastructure evidence update (r3.1/r4.2): the supplied current-driver/worker replay completed, 41/41 expectations pass; this closes the access qualification, not the Taylor-model proof gate. '
         'B-08 receiving review (21 Oct 2026): the 41/41 regression is engineering evidence; the K=6 pilot (4/904 boxes per N) is INSUFFICIENT EVIDENCE for regional coverage; the three Stage1 boxes are source-reported local constants.')
ed('F1', 'claim', alg, alg_new + '\n' + infra)
upd = line('[ALG] Infrastructure evidence update only: supplied current-driver/worker replay completed, 41/41 expectations pass.', F3)
assert upd.endswith('This closes the access qualification, not the Taylor-model proof gate.')
# F2: remove the tagged infrastructure line (its content is now in the untagged field); keep the position with a pointer line without a claim tag
ed('F2', 'claim', upd, 'Infrastructure evidence update (r3.1/r4.2; untagged since r4.13, B-08 F3-01): see the field "Infrastructure and evidence status" above; 41/41 expectations pass; access qualification only, not the Taylor-model proof gate.')
tbl = line('**Reported Stage1 v2 local constants, not a region certificate:**', F3)
ed('F3', 'table', tbl, '**Reported Stage1 v2 local constants, not a region certificate (source-reported evidence; not a graded claim of this record; r4.13):**')
ov = line('**r4.2 current-use overlay (RER-F3-N7N8):**', F3)
tab_head = ov + '\n[ALG] **FINITE_ORDER.**'
assert B.count(tab_head) == 1
bound = ('**Historical/current boundary (r4.13, B-08 F3-02):** the contract table above, including its Closure-status cell, is the preserved r3.1 snapshot and is not edited; '
         'the current status of this record is stated only in the r4.2 overlay above, in the field "Infrastructure and evidence status" and in the [OPEN] lines below. A reader of the snapshot cell alone does not see the current status.')
ed('F4', 'boundary', tab_head, ov + '\n' + bound + '\n[ALG] **FINITE_ORDER.**')
ev = line('**Evidence:** original scientific source pins and earlier verification scopes are retained from r2.', F3)
rr = line('**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending.', F3)
ctx = ev + '\n\n' + rr + '\nImport/reference: [N7REVIEW: 2.'
assert B.count(ctx) == 1
ev_new = ev + (' r4.13 (B-08 F3-03): the Constraints bound R^2/2 <= Q_s <= 3R^2/2 (R = |s|_2) is confirmed by the receiver\'s independent algebra (Q_s = R^2 (1 - (1/2) sin 2θ) for s = (R cos θ, R sin θ)); '
               'the N7REVIEW §3 critique of an incorrect Euclidean-radius bound concerns the source script\'s reporting layer, not this cell, which is unchanged. Historical source numbers are not used as a regional certificate.')
rr_new = rr + (f' r4.13: B-08 independent receiving review by the receiving co-owner (21 Oct 2026; decision file SHA-256 `{B08}`, on the neutral packet RER_PHASE_B08_REVIEW_PACKET_r1.zip `{PKT[:8]}…{PKT[-4:]}`; '
               'jet-defect script, Stage-2 regression and K=6 coverage independently executed): formal E7/E8 leading orders ACCEPT SCOPED [ALG, formal]; finite-jet polynomials ACCEPT SCOPED; 24-direction sampling ACCEPT SCOPED [NUM, SAMPLED_ONLY]; '
               'Stage-1 local box constants ACCEPT SCOPED as source-reported bounded boxes; 41/41 Stage-2 regression ACCEPT SCOPED as engineering evidence; regional adequacy of the K=6 pilot, whole-region K_{7,2}/K_{8,2} certificates, multi-step error control and physical age/factor realization INSUFFICIENT EVIDENCE. '
               'Record decision: CORRECTION REQUIRED (evidence classification and record clarity: F3-01 grade separation, F3-02 historical/current boundary, F3-03 Q_s range confirmed, cell unchanged), applied here; the primary grade [ALG] is neither raised nor lowered. '
               'The repaired Stage-1 Taylor-model engine was not rerun by the receiver, and the 19 Oct lemma-review file is not in the packet; no new receiver certificate is given for its results.')
ed('F5', 'evidence', ctx, ev_new + '\n\n' + rr_new + '\nImport/reference: [N7REVIEW: 2.')

# ---- AGE-CURVATURE
evc = line('**Evidence:** original scientific source pins and earlier verification scopes are retained from r2.', CUR)
rrc = line('**Review receipt:** r2 contributor ACCEPT SCOPED; exact r3 acceptance remains pending.', CUR)
ctxc = evc + '\n\n' + rrc + '\nImport/reference: [CURVNOTE:'
assert B.count(ctxc) == 1
rrc_new = rrc + (f' r4.13: B-08 independent receiving review by the receiving co-owner (21 Oct 2026; decision file SHA-256 `{B08}`; curvature script replayed with its source dependencies, 13/13, negative control fails as expected): '
                 'ACCEPT SCOPED [ALG], FINITE_ORDER — the polynomial identity w_13 = -(kappa_tilde^2/1024) Q_s^5 (111r^3 - 68r^2 e + 177r e^2 - 175e^3), D5 wedge R8 = w_13 and B7 parallel to D5 independently confirmed; for kappa_tilde != 0 and directions where the leading factor is nonzero, '
                 'the age fibres are not affine-linear through degree 13; at zero directions only the leading term vanishes and no exact collinearity follows. Scope: fixed parent chart and child plane; no statement on general nonlinear carrier changes, physical age, memory or all-order curved families. '
                 'This is the independent review called for by the r2 receipt, whose author refers to the C09 note as their own.')
ed('C1', 'receipt', ctxc, evc + '\n\n' + rrc_new + '\nImport/reference: [CURVNOTE:')

h = line('[ALG] R4.12 (21 Oct 2026) is a receipt-only revision')
ed('H1', 'history', h, '[ALG] R4.13 (21 Oct 2026) is a narrow correction revision on the exact r4.12 bytes (r4.12 was accepted ACCEPT SCOPED by the receiving co-owner on 21 Oct 2026 as a receipt integration). B-08 receiving review: '
   'RER-TRIAD-AGE-CURVATURE ACCEPT SCOPED (receipt recorded); RER-F3-N7N8 CORRECTION REQUIRED for evidence classification and record clarity, applied here: the formal E7/E8 content stays the only `[ALG]` claim of that line; '
   'infrastructure, pilot and review-status text moves to an untagged field "Infrastructure and evidence status (not a graded claim)" (PI decision: no new claim tag such as [ENG] is introduced); the former tagged infrastructure-update line is untagged; '
   'a historical/current boundary sentence precedes the r3.1 table; the Q_s bound is confirmed and unchanged. Grades, exactness, tasks, contract cells, imports, OPEN items and pins are unchanged.\n' + h)
rb = '**Release boundary (r4.12):** r4.12 is a noncanonical review draft;'
ed('H2', 'history', rb, '**Release boundary (r4.13):** r4.13 is a noncanonical review draft; it adopts, freezes and publishes nothing; moving text from a tagged claim line to an untagged evidence-status field changes no scientific statement and is not a new acceptance. ' + rb)
t = B
for e in E: assert t.count(e['old']) == 1, e['id']; t = t.replace(e['old'], e['new'])
Path('r4_12_to_r4_13_edits.json').write_text(json.dumps(E, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(len(E), 'edits written')
