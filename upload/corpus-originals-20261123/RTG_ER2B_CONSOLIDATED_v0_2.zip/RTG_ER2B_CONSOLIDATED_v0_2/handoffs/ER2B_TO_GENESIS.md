# ER-2B v0.2 handoff — Genesis Geometry

**Noncanonical technical decision request; source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`.

**Blocking question:** Does Genesis Geometry v2.8.5 **derive** additive closure in raw \((\rho,\eta)\), or postulate it as part of a conditional projected K3 model?

**Core carrier boundary:** Closing edges linearly in \((\rho,\eta)\) is a *model assumption* until derived from the chosen relational carrier. A formal six-real-dimensional chart choice exists at quadratic order; under the \(\sigma\) chart family, uniform outward drift ceases at 0.133975; uniform inward drift begins only above 0.292893. Passive nonlinear recharting cannot reverse the original model's stability.

**Scoped context:** Conditional K3 \(\Delta_4N=N^2/6+2S^2\) expands for the chosen raw carrier; this is not a property of every carrier. The full sign-regime diagram is C20.

**Evidence to inspect, *not* a bulk import authorization:** C01–C06, C10–C15B, C19–C20.

**Reply requested:** `ACCEPT SCOPED` / `REQUEST RECHECK` / `REJECT`, with source DSN version, carrier decision, primitive clock and observable mapping. No owner file has been changed by this handoff.
