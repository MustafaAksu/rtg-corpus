# ER-2B v0.2 handoff — Pre-Legacy

**Noncanonical technical decision request; source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`.

**Blocking question:** Can Pre-Legacy supply an **independently defined finite-step** node or edge resonance generator and a stated strobe for comparison with \(F_6\)?

**Core carrier boundary:** Closing edges linearly in \((\rho,\eta)\) is a *model assumption* until derived from the chosen relational carrier. A formal six-real-dimensional chart choice exists at quadratic order; under the \(\sigma\) chart family, uniform outward drift ceases at 0.133975; uniform inward drift begins only above 0.292893. Passive nonlinear recharting cannot reverse the original model's stability.

**Scoped context:** Historical \(\phi,\omega,s\) are not primitive DYAD node properties by default; do not equate node-flow and edge-map or assume chirality = spin.

**Evidence to inspect, *not* a bulk import authorization:** C01–C03, C17A–C18, C19.

**Reply requested:** `ACCEPT SCOPED` / `REQUEST RECHECK` / `REJECT`, with source DSN version, carrier decision, primitive clock and observable mapping. No owner file has been changed by this handoff.
