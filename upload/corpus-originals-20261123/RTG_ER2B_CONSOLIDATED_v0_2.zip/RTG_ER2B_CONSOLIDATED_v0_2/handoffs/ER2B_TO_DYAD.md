# ER-2B v0.2 handoff — DYAD

**Noncanonical technical decision request; source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`.

**Blocking question:** Does the adopted DYAD allow any additive edge chart beyond raw \((\rho,\eta)\), or does its primitive construction constrain the carrier?

**Core carrier boundary:** Closing edges linearly in \((\rho,\eta)\) is a *model assumption* until derived from the chosen relational carrier. A formal six-real-dimensional chart choice exists at quadratic order; under the \(\sigma\) chart family, uniform outward drift ceases at 0.133975; uniform inward drift begins only above 0.292893. Passive nonlinear recharting cannot reverse the original model's stability.

**Scoped context:** DYAD v6.4.10 [RID: DYAD-THM-PRIM-CTR] §6.12 has certified \(Q\le1/400\) bounds and an invariant tube; C13 triad instability has existence-only radius. Their strength is not symmetrical.

**Evidence to inspect, *not* a bulk import authorization:** C04, C13–C15B, C19–C20.

**Reply requested:** `ACCEPT SCOPED` / `REQUEST RECHECK` / `REJECT`, with source DSN version, carrier decision, primitive clock and observable mapping. No owner file has been changed by this handoff.
