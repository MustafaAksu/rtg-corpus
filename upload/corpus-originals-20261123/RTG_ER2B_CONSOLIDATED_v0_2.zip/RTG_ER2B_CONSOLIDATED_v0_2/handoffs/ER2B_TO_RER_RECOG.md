# ER-2B v0.2 handoff — RER / RECOG

**Noncanonical technical decision request; source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`.

**Blocking question:** Which signed-Gram / observable registry can accept the **order-limited** C11–C12 updates, while preserving the higher-order nonclosure counterexample?

**Core carrier boundary:** Closing edges linearly in \((\rho,\eta)\) is a *model assumption* until derived from the chosen relational carrier. A formal six-real-dimensional chart choice exists at quadratic order; under the \(\sigma\) chart family, uniform outward drift ceases at 0.133975; uniform inward drift begins only above 0.292893. Passive nonlinear recharting cannot reverse the original model's stability.

**Scoped context:** \(N=3Q_s/2+2Q_c\), \(S=\Omega_G\). Update of Gram at quartic order is not a global autonomous Gram factor.

**Evidence to inspect, *not* a bulk import authorization:** C09, C11–C12, C15A–C16.

**Reply requested:** `ACCEPT SCOPED` / `REQUEST RECHECK` / `REJECT`, with source DSN version, carrier decision, primitive clock and observable mapping. No owner file has been changed by this handoff.
