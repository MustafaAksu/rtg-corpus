# ER-2B v0.2 handoff — RRF

**Noncanonical technical decision request; source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`.

**Blocking question:** Which allowed rechartings **transport additive incidence**, and which operations are registered as a genuine replacement of the additive carrier?

**Core carrier boundary:** Closing edges linearly in \((\rho,\eta)\) is a *model assumption* until derived from the chosen relational carrier. A formal six-real-dimensional chart choice exists at quadratic order; under the \(\sigma\) chart family, uniform outward drift ceases at 0.133975; uniform inward drift begins only above 0.292893. Passive nonlinear recharting cannot reverse the original model's stability.

**Scoped context:** \(G_3\) transports as the first nonzero jet; \(\Omega_{\rm sep}\) additionally needs the oriented edge-slot structure. Record the six-dimensional quadratic chart choice only if admitted.

**Evidence to inspect, *not* a bulk import authorization:** C04, C07, C09, C15A–C16, C19–C20.

**Reply requested:** `ACCEPT SCOPED` / `REQUEST RECHECK` / `REJECT`, with source DSN version, carrier decision, primitive clock and observable mapping. No owner file has been changed by this handoff.
