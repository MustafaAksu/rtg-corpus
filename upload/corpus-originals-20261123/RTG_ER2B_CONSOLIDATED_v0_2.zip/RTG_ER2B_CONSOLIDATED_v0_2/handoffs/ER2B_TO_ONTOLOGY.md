# ER-2B v0.2 handoff — Ontological Foundations

**Noncanonical technical decision request; source:** `RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md`.

**Blocking question:** Is the primitive relational carrier **node-first affine differences**, **dyad-first with additional additive postulate**, or neither? Which closure operation is ontologically admissible?

**Core carrier boundary:** Closing edges linearly in \((\rho,\eta)\) is a *model assumption* until derived from the chosen relational carrier. A formal six-real-dimensional chart choice exists at quadratic order; under the \(\sigma\) chart family, uniform outward drift ceases at 0.133975; uniform inward drift begins only above 0.292893. Passive nonlinear recharting cannot reverse the original model's stability.

**Scoped context:** The onset of loss of uniform outward behavior at ~13.4% of the normalizer interpolation illustrates why choosing a carrier matters; contraction is uniform only beyond ~29.3%.

**Evidence to inspect, *not* a bulk import authorization:** C15A–C16, C19–C20.

**Reply requested:** `ACCEPT SCOPED` / `REQUEST RECHECK` / `REJECT`, with source DSN version, carrier decision, primitive clock and observable mapping. No owner file has been changed by this handoff.
