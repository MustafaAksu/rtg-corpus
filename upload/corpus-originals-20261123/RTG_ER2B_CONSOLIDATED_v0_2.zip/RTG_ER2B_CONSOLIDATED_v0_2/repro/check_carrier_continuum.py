#!/usr/bin/env python3
"""Exact v0.2 additive-carrier quadratic-jet audit (SymPy).
Local algebra for fixed A, not a physical carrier selection or full global conjugacy proof.
"""
import json
from pathlib import Path
import sympy as S
I=S.I; rt=S.sqrt(3); lam=(1+I*rt)/2
w,wb=S.symbols('w wb'); s=S.symbols('s',real=True)
u,v,t=S.symbols('u v t', complex=True)
# Normalizer is source h2 for Genesis, W-frame
h2=-(1+I*rt)*w**2/12-w*wb/3+(1-I*rt)*wb**2/24
qG=(lam/6)*w**2+(lam**2/3)*w*wb-wb**2/6
sub=lambda f: f.subs({w:lam*w,wb:S.conjugate(lam)*wb},simultaneous=True)
assert S.simplify(S.expand_complex(qG+lam*h2-sub(h2)))==0
# conjugation by H_s = id+s h2: q_s = q+s(Ah2-h2 A)
qS=S.expand(qG+s*(lam*h2-sub(h2)))
assert S.simplify(S.expand_complex(qS-(1-s)*qG))==0
# Independent quadratic-composition recurrence for isolated six-step coefficient.
# w_j=lam^j w + b20_j*w^2 + b11_j*w*wb + b02_j*wb^2 + ...
b20=b11=b02=S.Integer(0); coeff=S.Integer(0)
for j in range(6):
    # Jac(q) delta: (2u*w+v*wb)b + (v*w+2t*wb)conj(b)
    term=2*u*lam**j*b11+v*lam**(-j)*b20+v*lam**j*S.conjugate(b11)+2*t*lam**(-j)*S.conjugate(b02)
    coeff=S.expand(lam*coeff+term)
    b20=S.expand(lam*b20+u*lam**(2*j))
    b11=S.expand(lam*b11+v)
    b02=S.expand(lam*b02+t*lam**(-2*j))
    b20,b11,b02=[S.simplify(S.expand_complex(x)) for x in (b20,b11,b02)]
    coeff=S.simplify(S.expand_complex(coeff))
mu22=(9+3*I*rt)*u*v-(3+3*I*rt)*v*S.conjugate(v)-6*t*S.conjugate(t)
assert S.simplify(S.expand_complex(coeff-mu22))==0
chi=(-6+2*I*rt)*u*v+(1+I*rt)*v*S.conjugate(v)-4*t*S.conjugate(t)
uG=lam/6; vG=lam**2/3; tG=-S.Rational(1,6)
val={u:uG,v:vG,t:tG}
assert S.simplify(S.expand_complex(mu22.subs(val)+1+I*rt/2))==0
assert S.simplify(S.expand_complex(chi.subs(val)-S.Rational(1,3)))==0
k=1-s
mu=-S.Rational(1,2)-2*I*rt/3
nu=mu-2*k**2*mu22.subs(val)/3
ch= k**2*chi.subs(val)
a=S.simplify(S.re(S.expand_complex(nu))); b=S.simplify(S.re(S.expand_complex(ch)))
assert S.simplify(a-(-S.Rational(1,2)+2*k**2/3))==0
assert S.simplify(b-k**2/3)==0
assert S.simplify(a+b-(-S.Rational(1,2)+k**2))==0
# quartic radial and chirality coefficient
N,Sarea=S.symbols('N S_area', real=True)
dN=S.expand(a*N**2+(8*b-4*a)*Sarea**2)
dS=S.expand(S.Rational(2,3)*(a+b)*N*Sarea)
assert S.simplify(dN-((-S.Rational(1,2)+2*k**2/3)*N**2+2*Sarea**2))==0
assert S.simplify(dS-S.Rational(2,3)*(-S.Rational(1,2)+k**2)*N*Sarea)==0
th_out=1-rt/2
th_in=1-1/S.sqrt(2)
assert S.simplify(a.subs(s,th_out))==0
assert S.simplify((a+b).subs(s,th_in))==0
assert a.subs(s,0)>0 and a.subs(s,1)<0
assert a.subs(s,S.Rational(1,5))<0 and (a+b).subs(s,S.Rational(1,5))>0
assert (a+b).subs(s,S.Rational(3,10))<0
# full strict radial positivity requires a>0 and a+b>0;
# full strict negativity requires a<0 and a+b<0.
result={
 'status':'PASS', 'date':'2026-10-10', 'scope':'formal two-jet carrier family; isolated six-step quadratic recurrence, no owner physical selection',
 'mu22_general':'(9+3*i*sqrt(3))*u*v-(3+3*i*sqrt(3))*abs(v)^2-6*abs(t)^2',
 'chi_general':'(-6+2*i*sqrt(3))*u*v+(1+i*sqrt(3))*abs(v)^2-4*abs(t)^2',
 'q_s':'(1-s)*q_G',
 'mu_G':'-1/2-2*i*sqrt(3)/3',
 'nu_s':'mu_G-(2/3)*(1-s)^2*mu22_G',
 'Re_nu_s':'-1/2+(2/3)*(1-s)^2',
 'Re_chi_s':'(1/3)*(1-s)^2',
 'delta4N_s':'(-1/2+(2/3)*(1-s)^2)*N^2+2*S^2',
 'delta4S_s':'(2/3)*(-1/2+(1-s)^2)*N*S',
 'loss_uniform_expansion_s':'1-sqrt(3)/2',
 'onset_uniform_contraction_s':'1-1/sqrt(2)',
 'notes':['Signs at critical values are semidefinite at quartic order; higher-order outcome unspecified.', 'Changing the additive chart defines a new projected triad model, not a passive rechart.', 'General q freedom is a formal local two-jet freedom before admissibility constraints.']}
if __name__=='__main__':
    out=Path(__file__).resolve().parents[1]/'evidence'/'carrier_continuum_checks.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print('PASS carrier continuum; mu22(q) exact, q_s scaling, 2 thresholds, deltaN and deltaS')
