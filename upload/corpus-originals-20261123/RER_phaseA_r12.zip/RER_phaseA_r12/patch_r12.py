"""Phase A r11 -> r12: owner-currency catalog update (receiver authorization, 20 Oct 2026). Source Markdown unchanged (RER r4.8).
- Dyadic current v6.4.18 OWNER_REPORTED (release record hash f70308f1...458d); v6.4.17 kept as superseded with its BYTE_VERIFIED identity
  (file, custody and section check stay); verified current hash empty for Dyadic rows. History keeps the r8 and r9-r11 states.
- RECOG current v0.3.21 OWNER_REPORTED (a3459522...0ae3); v0.3.20 kept as superseded with its BYTE_VERIFIED bytes; its frozen status is
  recorded OWNER_REPORTED because the v0.3.21 release record states it ("frozen 19 Oct 2026"). RECOG rows: UNCHANGED_OWNER_REPORTED
  (synchronization-only release per its record), verified current hash empty.
- Scientific synchronization warning SYNC-DYAD-OPEN20-BINF: RER-DYAD-FORMAL-INVOLUTION still states OPEN 20 B-inf existence OPEN, which the
  owner reports CLOSED in v6.4.18. The warning stays OPEN while the listed r4.8 lines are present; it is not closed by this catalog change.
  DYAD6413 currency -> RECHECK_IN_PHASE_B (cited §2 OPEN 20 changed at the owner).
- Gates: A19 rejects Dyadic v6.4.17 as current; A23 re-based; A24/A25 identity comparisons neutralize the owner-currency fields of Dyadic and
  RECOG rows only (checked exactly by A23/A26); new A26 (RECOG currency) and A27 (sync warning). New negative controls.
Exact-once text replacements; catalog JSON edits by key. Arg: TARGET_DIR. Run once on a fresh copy of r11."""
import sys, os, json, shutil
D = sys.argv[1]
def rp(f, pairs):
    p = os.path.join(D, f); t = open(p, encoding='utf-8').read()
    for a, b in pairs:
        n = t.count(a); assert n == 1, (f, n, a[:90]); t = t.replace(a, b)
    open(p, 'w', encoding='utf-8').write(t)
def dump(o): return json.dumps(o, ensure_ascii=False, indent=1, sort_keys=True) + '\n'
D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'
G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
md = open(os.path.join(D, 'RTG_RELATIONAL_EMERGENCE_REGISTRY_v0_2_DRAFT_r4_8.md'), encoding='utf-8').read()
L = md.split('\n')
binf = [l for l in L if l.startswith('[OPEN] OPEN 20 B-∞ existence:')]
flat = [l for l in L if l.startswith('[THM] `[import: RTG_DYADIC_OSCILLATOR_DSN_v6.4.13 §6.17')]
assert len(binf) == 1 and len(flat) == 1

# keep r11 outputs as history
H = os.path.join(D, 'inputs/phaseA_r11_outputs'); os.makedirs(H)
for f in os.listdir(os.path.join(D, 'out')): shutil.move(os.path.join(D, 'out', f), os.path.join(H, f))
shutil.copyfile(os.path.join(D, 'check_phaseA_output.txt'), os.path.join(H, 'check_phaseA_output_r11.txt'))

p = os.path.join(D, 'inputs/owner_versions_known.json'); KV = json.load(open(p))
assert KV['Dyadic'] == '6.4.17' and KV['RECOG'] == '0.3.20'
KV['Dyadic'] = '6.4.18'; KV['RECOG'] = '0.3.21'; KV['_catalog_checked'] = '2026-10-20 (Phase A r12, preparer)'
KV['_source_authority']['Dyadic'] = ('owner release record claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md (owner-reported; v6.4.18 bytes not held here; release verification by the reviewer pending). '
                                     'Superseded v6.4.17: bytes held and hashed here (sources_available, inputs/source_custody_r9.json), hash independently confirmed by the receiver.')
KV['_source_authority']['RECOG'] = ('owner release record claude/RECOG_v0_3_21_RELEASE_RECORD.md (owner-reported; v0.3.21 bytes not held here). '
                                    'Superseded v0.3.20: file byte-verified here (sources_available); its frozen status (19 Oct 2026) is owner-reported by the v0.3.21 release record.')
open(p, 'w').write(dump(KV))

p = os.path.join(D, 'catalog_sources.json'); CS = json.load(open(p))
dy = CS['owner_current']['Dyadic']; assert dy['version'] == '6.4.17' and dy['evidence'] == 'BYTE_VERIFIED'
hist = dict(dy['history']); hist['phaseA_r9_r11'] = {'version': '6.4.17', 'sha256': D17, 'evidence': 'BYTE_VERIFIED', 'note': dy['note']}
CS['owner_current']['Dyadic'] = {
    'version': '6.4.18', 'sha256': D18, 'evidence': 'OWNER_REPORTED', 'history': hist,
    'note': 'adopted 20 Oct 2026 per its release record (claude/RTG_DYADIC_v6_4_18_RELEASE_RECORD.md); the hash is the one stated there and was not computed in this package; release verification by the reviewer pending. Per the release record: new DYAD-THM-SMOOTH-EMBEDDING [THM] (C^∞ germ scope: E1 F = T^6 = time-one map of a C^∞ X with j^∞X = log F; E2 uniqueness of X among C^∞ generators with DX\'(0) = 0; E3 unique C^∞ tangent-to-identity roots K_m commuting with T; E4 C^∞ J and R); OPEN 20 B-∞ existence CLOSED, B-an and B-6 OPEN; F1–F3 existence condition discharged for K_m, J, R; no other RID or grade changed.',
    'superseded': {'version': '6.4.17', 'sha256': D17, 'evidence': 'BYTE_VERIFIED (Phase A r9: file held, custody r9, section check; hash receiver-confirmed)'}}
rc = CS['owner_current']['RECOG']; assert rc['version'] == '0.3.20' and rc['sha256'] == G20 and rc['evidence'] == 'BYTE_VERIFIED'
CS['owner_current']['RECOG'] = {
    'version': '0.3.21', 'sha256': G21, 'evidence': 'OWNER_REPORTED',
    'history': {'phaseA_r6_r11': {'version': '0.3.20', 'sha256': G20, 'evidence': 'BYTE_VERIFIED', 'note': rc['note']}},
    'note': 'adopted 20 Oct 2026 per its release record (claude/RECOG_v0_3_21_RELEASE_RECORD.md); hash stated there, not computed here. Per the record: synchronization-only release; no scientific RID, result grade or OPEN status changed; three new artifact IDs; not frozen. The RECOG G3 notice to RER (freeze record and adopted hash) is recorded there as not yet sent.',
    'superseded': {'version': '0.3.20', 'sha256': G20, 'evidence': 'BYTE_VERIFIED (Phase A r6; file in sources_available)',
                   'frozen': 'FROZEN 19 Oct 2026 — OWNER_REPORTED (stated in the v0.3.21 release record: "v0.3.20 (frozen 19 Oct 2026)"; no separate freeze record inspected here)'}}
k = CS['keys']['RECOG']; assert k['rule'] == 'CURRENT' and k['cited_version'] == '0.3.20'
k['rule'] = 'UNCHANGED_OWNER_REPORTED'
k['reason'] = 'Phase A r12: current RECOG is v0.3.21 (owner-reported). Its release record states a synchronization-only release with no scientific RID, grade or OPEN status change. The cited v0.3.20 §6.6a bytes are held and verified here; section equality in v0.3.21 is not checked (v0.3.21 bytes not held). RER pins stay on v0.3.20.'
k = CS['keys']['DYAD6413']; assert k['rule'] == 'UNCHANGED_OWNER_REPORTED'
k['rule'] = 'RECHECK_IN_PHASE_B'
k['sync_warning'] = 'SYNC-DYAD-OPEN20-BINF'
k['reason'] += (' Phase A r12: current Dyadic is v6.4.18 (owner-reported). Per its release record the cited §2 OPEN 20 changed at the owner (B-∞ existence CLOSED by DYAD-THM-SMOOTH-EMBEDDING) and the F1–F3 existence condition is discharged for K_m, J, R. '
                'The r4.8 record still states B-∞ existence OPEN: scientific synchronization warning SYNC-DYAD-OPEN20-BINF (open until the record is corrected and the correction is receiver-accepted). Currency set to RECHECK_IN_PHASE_B; RER pins stay on v6.4.13.')
CS['scientific_sync_warnings'] = [{
    'id': 'SYNC-DYAD-OPEN20-BINF', 'record': 'RER-DYAD-FORMAL-INVOLUTION', 'key': 'DYAD6413', 'owner': 'Dyadic', 'owner_version': '6.4.18', 'owner_evidence': 'OWNER_REPORTED',
    'owner_change': 'OPEN 20 B-∞ existence CLOSED by DYAD-THM-SMOOTH-EMBEDDING [THM] (C^∞ germ scope); F1–F3 existence condition discharged for K_m, J, R; B-an and B-6 OPEN; analytic convergence not asserted (release record).',
    'rer_lines': [binf[0], flat[0]],
    'rer_line_roles': ['states B-∞ existence OPEN — contradicts the reported owner status', 'states F1–F3 conditional on existence and that no existence is asserted — scope to be re-checked against v6.4.18 §6.17'],
    'required_action': 'source reading of Dyadic v6.4.18 §2 OPEN 20, §6.17 and the new embedding theorem (original bytes needed), then a narrow RER r4.9 for receiving review; B-an, B-6 and physical exchange unchanged; no transfer to the Triadic records.',
    'closes_only_when': 'the listed lines are corrected in an RER revision and that revision is receiver-accepted; a catalog change alone does not close it'}]
CS['_about'] += ' Phase A r12 (20 Oct): Dyadic current v6.4.18 and RECOG current v0.3.21 (both OWNER_REPORTED); v6.4.17 and v0.3.20 kept as superseded byte-verified identities; scientific sync warning SYNC-DYAD-OPEN20-BINF.'
open(p, 'w').write(dump(CS))

rp('build_phaseA.py', [
 ('"""RER Phase A r11 builder (deterministic).', '"""RER Phase A r12 builder (deterministic; r12 changes only the owner-currency catalog and adds scientific sync warnings).'),
 ("'RER-REGISTRY-PHASEA/11'", "'RER-REGISTRY-PHASEA/12'"), ("'RER-SOURCE-CURRENCY/11'", "'RER-SOURCE-CURRENCY/12'"), ("'RER-BLOCKED-SOURCES/11'", "'RER-BLOCKED-SOURCES/12'"),
 ("            for f in ('receiver_note', 'receiver_section_check'):", "            for f in ('receiver_note', 'receiver_section_check', 'sync_warning'):"),
 ("    lost = sorted(set(x['key'] for x in rows if x['path_in_r4_package'] and not x['path_in_r4_4_package']))\n",
  "    mdl = md.split('\\n')\n"
  "    cm['scientific_sync_warnings'] = [dict(w, rer_lines_present=[l in mdl for l in w['rer_lines']],\n"
  "        status=('OPEN — record correction required' if all(l in mdl for l in w['rer_lines']) else 'CHECK — a listed line is no longer present; re-review before closing'))\n"
  "        for w in CS.get('scientific_sync_warnings', [])]\n"
  "    lost = sorted(set(x['key'] for x in rows if x['path_in_r4_package'] and not x['path_in_r4_4_package']))\n"),
 ("'# RER r4.8 — source-currency matrix (Phase A r11, noncanonical)'", "'# RER r4.8 — source-currency matrix (Phase A r12, noncanonical)'"),
 ("'# RER r4.8 — blocked-source register (Phase A r11, noncanonical)'", "'# RER r4.8 — blocked-source register (Phase A r12, noncanonical)'"),
 ("    L += ['', '## Summary', '', ",
  "    L += ['', '## Scientific synchronization warnings', ''] + [f\"- **{w['id']}** ({w['record']}, `{w['key']}`): {w['status']}. Owner {w['owner']} v{w['owner_version']} ({w['owner_evidence']}): {w['owner_change']} Action: {w['required_action']} Closes only when: {w['closes_only_when']}\" for w in cm.get('scientific_sync_warnings', [])]\n"
  "    L += ['', '## Summary', '', "),
 ("The r10 outputs (on r4.7, grade tags ALG and THM) are kept unchanged as historical evidence.']}",
  "The r10 outputs (on r4.7, grade tags ALG and THM) are kept unchanged as historical evidence.',\n"
  "                          'Phase A r12 (20 Oct 2026): Dyadic v6.4.18 ADOPTED 20 Oct (f70308f1…458d, owner-reported; release verification pending): DYAD-THM-SMOOTH-EMBEDDING [THM], OPEN 20 B-∞ existence CLOSED, B-an/B-6 OPEN. RECOG v0.3.21 ADOPTED 20 Oct (a3459522…0ae3, owner-reported; synchronization-only; v0.3.20 frozen 19 Oct, owner-reported). Byte-verified v6.4.17 and v0.3.20 identities kept as superseded. Scientific sync warning SYNC-DYAD-OPEN20-BINF is OPEN: RER-DYAD-FORMAL-INVOLUTION still states B-∞ existence OPEN.']}"),
])

rp('check_phaseA.py', [
 ('"""Phase A r11 gates on RER v0.2 DRAFT r4.8.', '"""Phase A r12 gates on RER v0.2 DRAFT r4.8 (r12: owner-currency catalog update; source unchanged).'),
 ("carrying DYAD-ALG-CENT-KERNEL [ALG]; the r10 outputs are present unchanged under inputs/phaseA_r10_outputs/.\n",
  "carrying DYAD-ALG-CENT-KERNEL [ALG]; the r10 outputs are present unchanged under inputs/phaseA_r10_outputs/.\n"
  "r12: in A24/A25 the owner-currency fields (currency, status, current_owner_version, verified_current_hash) of Dyadic and RECOG rows are excluded\n"
  "from the identity comparison; they are checked exactly by A23 (Dyadic) and A26 (RECOG). A23 (r12): Dyadic current v6.4.18 OWNER_REPORTED with the\n"
  "release-record hash and no held file; v6.4.17 superseded with its BYTE_VERIFIED identity (file, custody r9, section check still required); r8 and\n"
  "r9-r11 states in history; Dyadic rows: no verified current hash, OWNER_REPORTED, currency RECHECK_IN_PHASE_B, sync_warning set; DYAD6413 pin v6.4.13.\n"
  "A26 RECOG currency: v0.3.21 OWNER_REPORTED, no held file; v0.3.20 superseded BYTE_VERIFIED with its file held and its frozen status OWNER_REPORTED;\n"
  "RECOG rows UNCHANGED_OWNER_REPORTED / OWNER_REPORTED, bytes still matched, no verified current hash. A27 scientific sync warning\n"
  "SYNC-DYAD-OPEN20-BINF: present, tied to RER-DYAD-FORMAL-INVOLUTION/DYAD6413, owner v6.4.18 OWNER_REPORTED; status recomputed from the source:\n"
  "OPEN while every listed line is present in the Markdown, and never CLOSED by Phase A.\n"),
 ("and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16') and oc['OFN']['version'] == '0.10'", "and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16', '6.4.17') and oc['RECOG']['version'] == '0.3.21' and oc['OFN']['version'] == '0.10'"),
 ("    ident = lambda x: tuple(x.get(k) for k in ('record', 'row_kind', 'n', 'key', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash'))\n",
  "    ident = lambda x: tuple((None if (x.get('owner') in ('Dyadic', 'RECOG') and k in ('currency', 'status', 'current_owner_version', 'verified_current_hash')) else x.get(k)) for k in ('record', 'row_kind', 'n', 'key', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash'))  # r12: owner-currency fields of Dyadic/RECOG rows are checked by A23/A26\n"),
 ("    dy_ok = (dy['version'] == '6.4.17' and dy['sha256'] == D17 and dy['evidence'] == 'BYTE_VERIFIED' and D17 in avail\n"
  "             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok\n"
  "             and dy.get('history', {}).get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED'\n"
  "             and dy.get('superseded', {}).get('version') == '6.4.16' and dy['superseded'].get('sha256') == '33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0'\n"
  "             and len(dyrows) >= 1 and all(x['verified_current_hash'] == D17 and x['current_owner_evidence'] == 'BYTE_VERIFIED' and x['currency'] != 'CURRENT' for x in dyrows)\n",
  "    D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'\n"
  "    dy_ok = (dy['version'] == '6.4.18' and dy['sha256'] == D18 and dy['evidence'] == 'OWNER_REPORTED' and D18 not in avail and D17 in avail\n"
  "             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok\n"
  "             and dy.get('history', {}).get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED' and dy['history'].get('phaseA_r9_r11', {}).get('evidence') == 'BYTE_VERIFIED' and dy['history']['phaseA_r9_r11'].get('sha256') == D17\n"
  "             and dy.get('superseded', {}).get('version') == '6.4.17' and dy['superseded'].get('sha256') == D17 and dy['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')\n"
  "             and len(dyrows) >= 1 and all(x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['current_owner_version'] == '6.4.18' and x['currency'] == 'RECHECK_IN_PHASE_B' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' for x in dyrows)\n"),
 ("    g('A23 Dyadic v6.4.17 byte-verified with file, custody and section check; r8 state as history; RER pins stay v6.4.13', dy_ok, f'{len(dyrows)} Dyadic row(s)')",
  "    g('A23 Dyadic v6.4.18 owner-reported; v6.4.17 byte-verified identity kept as superseded (file, custody, section check); history kept; RER pins stay v6.4.13', dy_ok, f'{len(dyrows)} Dyadic row(s)')"),
 ("    return all(res), res\n\nouts =",
  "    rc = oc['RECOG']; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'\n"
  "    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']\n"
  "    rc_ok = (rc['version'] == '0.3.21' and rc['sha256'] == G21 and rc['evidence'] == 'OWNER_REPORTED' and G21 not in avail and G20 in avail\n"
  "             and rc.get('superseded', {}).get('version') == '0.3.20' and rc['superseded'].get('sha256') == G20 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')\n"
  "             and rc['superseded'].get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED') and rc.get('history', {}).get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED'\n"
  "             and len(rr_) == 2 and all(x['cited_version'] == '0.3.20' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['currency'] == 'UNCHANGED_OWNER_REPORTED'\n"
  "                                       and x['status'] == 'OWNER_REPORTED' and x['verified_current_hash'] is None and x['current_owner_version'] == '0.3.21' for x in rr_))\n"
  "    g('A26 RECOG v0.3.21 owner-reported; v0.3.20 byte-verified bytes kept, frozen status owner-reported; RECOG rows not CURRENT', rc_ok, f'{len(rr_)} RECOG rows')\n"
  "    mdl = md.split('\\n'); W = [w for w in cm.get('scientific_sync_warnings', []) if w.get('id') == 'SYNC-DYAD-OPEN20-BINF']\n"
  "    w = W[0] if len(W) == 1 else {}\n"
  "    present = bool(w.get('rer_lines')) and all(l in mdl for l in w['rer_lines'])\n"
  "    w_ok = (len(W) == 1 and w.get('record') == 'RER-DYAD-FORMAL-INVOLUTION' and w.get('key') == 'DYAD6413' and w.get('owner_version') == '6.4.18' and w.get('owner_evidence') == 'OWNER_REPORTED'\n"
  "            and len(w.get('rer_lines', [])) == 2 and w['rer_lines'][0].startswith('[OPEN] OPEN 20 B-∞ existence:') and present and w.get('rer_lines_present') == [True, True]\n"
  "            and w.get('status', '').startswith('OPEN') and 'CLOSED' not in w.get('status', '') and 'catalog change alone does not close it' in w.get('closes_only_when', '')\n"
  "            and all(x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' for x in cm['rows'] if x['key'] == 'DYAD6413'))\n"
  "    g('A27 scientific sync warning SYNC-DYAD-OPEN20-BINF open while the r4.8 B-∞ lines are present; not closed by Phase A', w_ok, w.get('status', 'missing'))\n"
  "    return all(res), res\n\nouts ="),
 ("         ('A23 Dyadic evidence back to OWNER_REPORTED (r8 state)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='OWNER_REPORTED'))),\n",
  "         ('A23 v6.4.18 promoted to BYTE_VERIFIED without bytes', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED'))),\n"),
 ("         ('A23 BYTE_VERIFIED with a hash that no held file has', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64))),\n",
  "         ('A23 v6.4.18 hash replaced', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64))),\n"),
 ("         ('A23 Dyadic row verified hash removed', 22, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'Dyadic').update(verified_current_hash=None))),\n",
  "         ('A23 Dyadic row given the v6.4.18 hash as verified', 22, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'Dyadic').update(verified_current_hash='f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'))),\n"
  "         ('A23 DYAD6413 currency left UNCHANGED_OWNER_REPORTED', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED'))),\n"
  "         ('A23 r9-r11 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r9_r11'))),\n"
  "         ('A19 Dyadic v6.4.17 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.17'))),\n"
  "         ('A19 RECOG v0.3.20 claimed current', 18, mut(C, lambda d: d['owner_current']['RECOG'].update(version='0.3.20'))),\n"
  "         ('A26 RECOG v0.3.21 promoted to BYTE_VERIFIED without bytes', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED'))),\n"
  "         ('A26 RECOG row left CURRENT/VERIFIED', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='CURRENT', status='VERIFIED'))),\n"
  "         ('A26 RECOG row given a verified current hash', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(verified_current_hash='fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'))),\n"
  "         ('A26 v0.3.20 frozen statement dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['superseded'].pop('frozen'))),\n"
  "         ('A26 v0.3.20 byte-verified identity dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('superseded'))),\n"
  "         ('A27 sync warning removed', 26, mut(C, lambda d: d.update(scientific_sync_warnings=[]))),\n"
  "         ('A27 sync warning marked CLOSED while the B-∞ line is present', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='CLOSED — catalog updated'))),\n"
  "         ('A27 sync warning lines altered (no longer tied to the source)', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(rer_lines=['[OPEN] OPEN 20 B-∞ existence: (paraphrased)', d['scientific_sync_warnings'][0]['rer_lines'][1]]))),\n"
  "         ('A27 DYAD6413 row loses its sync_warning link', 26, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').pop('sync_warning'))),\n"),
 ("         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('history'))),\n",
  "         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r8'))),\n"),
 ("         ('A23 superseded v6.4.16 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))]",
  "         ('A23 superseded v6.4.17 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))]"),
])
print('patched')
