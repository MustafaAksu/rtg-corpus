"""Phase A r12 gates on RER v0.2 DRAFT r4.8 (r12: owner-currency catalog update; source unchanged). Markdown is re-read by plain line scanning, independent of tools/rer_parse.py.
Exit 0 iff all pass; --tamper runs negative controls (each must fail its named gate).
A1 r4.6 source SHA and input pins. A2 determinism: a fresh build equals the stored outputs byte for byte (same parser; not a second
independent parser). A3 record set: Markdown headings vs JSON ids, same order, 20, no duplicates, gaps separate.
A4 literal field mirror: every line reproduced by a structured JSON field (grade line, six contract cells, claim lines, named fields,
each import line and each OPEN line, imports/OPENs/claims in order) is re-found verbatim in the record's Markdown span; every non-blank
span line is either such a line or listed verbatim in unclassified_lines (no line dropped). Line order across different fields is
not reconstructed, and the meaning of a line is not checked.
A5 one matrix row per record import and per gap reference; required fields. A6 byte and package-path claims (r4.4 and r4.5
manifests). A7 stale owner pins carry a non-CURRENT status and a reason. A8 ER-2B firewall. A9 no promotion. A10 RRF-CND01
provenance split. A11 legacy snapshot separate. A12 blocked register complete. A13 packaging finding complete and repaired in r4.5.
A14 receiver status vocabulary. A15 gap-reference coverage (13 G7-G10 Reference lines, equal to the receiver crosswalk; each records the received
editor disposition and a pending per-reference audit as two separate fields). A16 authentication vocabulary (BYTE_VERIFIED_HERE iff bytes matched here; RECEIVER_BYTE_VERIFIED only for
receiver-reported keys; no hash => UNAUTHENTICATED_NO_HASH). A17 13/13 gap-reference cited_path non-null and equal to the
link target of the reference line (bracket-aware). A18 blocked register records the RRF-editor hashes exactly where r4.6 states them
(Q7), the coincidence ZIP keeps no hash, and both ER-2B records stay blocked. A19 owner currency: owner_current equals the pinned latest adopted versions
(inputs/owner_versions_known.json); in particular Dyadic v6.4.15, Dyadic v6.4.16 and OFN v0.9 are rejected as current; the frozen catalog carries its check
date, scope (not live discovery) and per-owner source authority, mirrored in the matrix. A20 the editor response is pinned by hash.
A21 owner-current evidence discipline: evidence is in the catalog vocabulary; BYTE_VERIFIED only with matching bytes in sources_available;
OFN v0.10 stays OWNER_REPORTED with the release-record hash, v0.9 recorded as superseded, and no OFN row carries a verified current hash.
A22 source custody: every sources_available file added in r6 has a custody entry (key, sha256, container) whose hash equals the file
and the cited hash; the container chain is marked preparer-declared. ER01 record-import rows stay BLOCKED although ER01 bytes are present;
the ER01 gap reference (G8/0) is HISTORICAL with verified bytes and a pending per-reference audit (r7, A6-G8-01).
A23 Dyadic currency (r9): v6.4.17 is current with evidence BYTE_VERIFIED, which requires the real file in sources_available with the expected
hash and a matching custody entry (inputs/source_custody_r9.json); the r8 OWNER_REPORTED state is kept as history; v6.4.16 recorded as superseded;
the section-check record shows both file hashes MATCH and 5/5 blocks IDENTICAL; every Dyadic row carries the v6.4.17 hash as verified current hash,
owner evidence BYTE_VERIFIED and a non-CURRENT currency; the DYAD6413 pin stays v6.4.13 with its cited hash and receiver authentication.
--tamper also runs a file-level control: the checker is re-run with the v6.4.17 file withheld from sources_available, and A23 must fail.
A24 r4.7 source pass (r10): the outputs record the r4.7 source and package hashes and the r4.6 base; the matrix equals the pinned r9 matrix
row for row (identity, cited hash, bytes, authentication, currency, status) except exactly one added RECORD_IMPORT row RRF083 in
RER-DYAD-FORMAL-INVOLUTION (n=2; cited v0.8.3 with the adopted hash; CURRENT; RECEIVER_BYTE_VERIFIED; OWNER_REPORTED); every row carries
path_in_r4_7_package; the registry equals the pinned r9 registry for the other 19 records, and for RER-DYAD-FORMAL-INVOLUTION differs only in
text fields (r11, on r4.8: primary_grade '[THM] (owner grade)' and grade_tags ['THM'] as in r9; exactness, task, adoption and OPEN items unchanged).
A25 equality with the r10 outputs (r11): the 90 matrix rows equal the pinned r10 rows in every identity/evidence field and carry path_in_r4_8_package;
the other 19 registry records equal r10; RER-DYAD-FORMAL-INVOLUTION differs from r10 only in primary_grade, primary_grade_line, grade_tags and
unclassified_lines (the source-note line), with primary_grade '[THM] (owner grade)', grade_tags ['THM'] and exactly one unclassified source-note line
carrying DYAD-ALG-CENT-KERNEL [ALG]; the r10 outputs are present unchanged under inputs/phaseA_r10_outputs/.
r12: in A24/A25 the owner-currency fields (currency, status, current_owner_version, verified_current_hash) of Dyadic and RECOG rows are excluded
from the identity comparison; they are checked exactly by A23 (Dyadic) and A26 (RECOG). A23 (r12): Dyadic current v6.4.18 OWNER_REPORTED with the
release-record hash and no held file; v6.4.17 superseded with its BYTE_VERIFIED identity (file, custody r9, section check still required); r8 and
r9-r11 states in history; Dyadic rows: no verified current hash, OWNER_REPORTED, currency RECHECK_IN_PHASE_B, sync_warning set; DYAD6413 pin v6.4.13.
A26 RECOG currency: v0.3.21 OWNER_REPORTED, no held file; v0.3.20 superseded BYTE_VERIFIED with its file held and its frozen status OWNER_REPORTED;
RECOG rows UNCHANGED_OWNER_REPORTED / OWNER_REPORTED, bytes still matched, no verified current hash. A27 scientific sync warning
SYNC-DYAD-OPEN20-BINF: present, tied to RER-DYAD-FORMAL-INVOLUTION/DYAD6413, owner v6.4.18 OWNER_REPORTED; status recomputed from the source:
OPEN while every listed line is present in the Markdown, and never CLOSED by Phase A.
r10 wording kept as history: (r10, on r4.7: exactness, task, adoption and OPEN items unchanged; primary_grade starts with the r9 value '[THM] (owner grade)' and, because the
parser reads up to '. **Exactness', now also holds the O3 per-RID labels, so grade_tags is ['ALG', 'THM'] - finding R10-F1, recorded, not repaired)."""
import sys, os, re, json, hashlib, copy
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); import build_phaseA as B
sha = lambda b: hashlib.sha256(b).hexdigest()
CAT_PINS = {'catalog_sources.json': None, 'catalog_records.json': None}  # filled from PINS file
PINS = json.load(open(os.path.join(HERE, 'PINS.json')))
md = open(os.path.join(HERE, B.MD), encoding='utf-8').read()
L = md.split('\n')

def md_records():
    out, cur = [], None
    for ln in L:
        m = re.match(r'^### (RER-[A-Z0-9-]+) — ', ln)
        if m or ln.startswith('## ') or ln.startswith('<a id='):
            if cur: out.append(cur); cur = None
        if m: cur = {'id': m.group(1), 'lines': []}
        elif cur is not None: cur['lines'].append(ln)
    if cur: out.append(cur)
    return out

def gates(outs, verbose=True, withhold=()):
    res = []
    def g(n, ok, info=''):
        res.append(ok)
        if verbose: print(('PASS ' if ok else 'FAIL ') + n + (f'  [{info}]' if info else ''))
    reg = json.loads(outs['out/RER_REGISTRY_v0_2_r4_8_PHASEA.json']); cm = json.loads(outs['out/SOURCE_CURRENCY_MATRIX.json']); br = json.loads(outs['out/BLOCKED_SOURCE_REGISTER.json'])
    g('A1 source and catalog pins', sha(md.encode()) == B.MD_SHA and all(sha(open(os.path.join(HERE, f), 'rb').read()) == h for f, h in PINS['inputs'].items()))
    fresh = B.build()
    g('A2 deterministic rebuild equals stored outputs', all(fresh[p] == outs[p] for p in fresh) and set(fresh) == set(outs))
    mr = md_records(); gaps = {'RER-G7', 'RER-G8', 'RER-G9', 'RER-G10'}
    mids = [r['id'] for r in mr if r['id'] not in gaps]; jids = [r['id'] for r in reg['records']]
    g('A3 record set mirrors Markdown', mids == jids and len(set(jids)) == len(jids) == 20 and sorted(x['id'] for x in reg['gap_entries']) == sorted(gaps), f'{len(jids)} records')
    bad = []; nlines = 0; nuncl = 0
    for r in mr:
        if r['id'] in gaps: continue
        j = next((x for x in reg['records'] if x['id'] == r['id']), None)
        if j is None: bad.append((r['id'], 'missing')); continue
        span = r['lines']; spanset = set(span)
        gl = next((l for l in span if l.startswith('**Primary grade:**')), '')
        if j['primary_grade'] is None or j['primary_grade'] not in gl or ('`' + j['task'] + '`') not in gl or j.get('primary_grade_line') != gl: bad.append((r['id'], 'grade/task'))
        struct = {gl, '| Field | Contract |', '|---|---|'}
        for row in ['Carrier', 'Observables', 'Constraints', 'Transformation law', 'Closure status', 'Memory']:
            cell = next((l for l in span if l.startswith('| ' + row + ' | ')), None)
            if cell is None or cell != f"| {row} | {j['contract'][row]} |": bad.append((r['id'], row))
            struct.add(f"| {row} | {j['contract'][row]} |")
        if [l for l in span if l.startswith('Import/reference:')] != [i['line'] for i in j['imports']]: bad.append((r['id'], 'import lines'))
        if [l for l in span if l.startswith('[OPEN] ')] != ['[OPEN] ' + o for o in j['open_items']]: bad.append((r['id'], 'OPEN lines'))
        if [l for l in span if re.match(r'^\[(THM|ALG|NUM|DEF)\]', l)] != j['claim_lines']: bad.append((r['id'], 'claim lines'))
        for k, v in j['fields'].items():
            if v is not None:
                if f"**{k}:** {v}" not in spanset: bad.append((r['id'], k))
                struct.add(f"**{k}:** {v}")
        struct |= set(j['claim_lines']) | {'[OPEN] ' + o for o in j['open_items']} | {i['line'] for i in j['imports']}
        if any(u not in spanset for u in j['unclassified_lines']): bad.append((r['id'], 'unclassified not in span'))
        left = [l for l in span if l.strip() and l not in struct and l not in set(j['unclassified_lines'])]
        if left: bad.append((r['id'], f'{len(left)} lines unaccounted'))
        nlines += sum(1 for l in span if l.strip()); nuncl += len(j['unclassified_lines'])
    g('A4 literal field mirror; every record line accounted for', not bad, f'{len(bad)} mismatches {bad[:2]}; {nlines} lines, {nuncl} unclassified (verbatim)')
    need = ['record', 'key', 'source_doc', 'cited_version', 'cited_sha256', 'current_owner_version', 'current_owner_sha256', 'section_or_RID', 'inspection_extent', 'currency', 'reviewer_disposition', 'bytes_status']
    gaprefs = [l for r in mr if r['id'] in gaps for l in r['lines'] if l.startswith('Reference:')]
    occ = sum(len(x['imports']) for x in reg['records']) + len(gaprefs)
    keys_ok = all(all(k in x for k in need) for x in cm['rows'])
    g('A5 one currency row per record import and per gap reference, required fields present', len(cm['rows']) == occ and keys_ok and all(x['reviewer_disposition'] == 'PENDING' for x in cm['rows']), f'{len(cm["rows"])} rows')
    bb = []
    pkg = B.rd('inputs/r4_4_package_SHA256SUMS.txt').decode(); pkg45 = B.rd('inputs/r4_5_package_SHA256SUMS.txt').decode(); pkg46 = B.rd('inputs/r4_6_package_SHA256SUMS.txt').decode(); pkg47 = B.rd('inputs/r4_7_package_SHA256SUMS.txt').decode(); pkg48 = B.rd('inputs/r4_8_package_SHA256SUMS.txt').decode()
    for x in cm['rows']:
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH':
            f = os.path.join(HERE, x['available_file'] or '')
            if not os.path.isfile(f) or sha(open(f, 'rb').read()) != x['cited_sha256']: bb.append(x['key'])
        elif x['available_file']: bb.append(x['key'])
        if x['path_in_r4_4_package'] and ('  ' + x['cited_path'] + '\n') not in pkg: bb.append(x['key'] + ':pkg')
        if x['path_in_r4_5_package'] and ('  ' + x['cited_path'] + '\n') not in pkg45: bb.append(x['key'] + ':pkg45')
        if x['path_in_r4_6_package'] and ('  ' + x['cited_path'] + '\n') not in pkg46: bb.append(x['key'] + ':pkg46')
        if x.get('path_in_r4_7_package') and ('  ' + x['cited_path'] + '\n') not in pkg47: bb.append(x['key'] + ':pkg47')
        if x.get('path_in_r4_8_package') and ('  ' + x['cited_path'] + '\n') not in pkg48: bb.append(x['key'] + ':pkg48')
    g('A6 byte and package-path claims are true', not bb, f'{bb[:3]}')
    st = [x for x in cm['rows'] if x['source_family'] == 'OWNER_DSN' and x['current_owner_version'] and x['cited_version'] != x['current_owner_version']
          and (x['currency'] in ('CURRENT',) or not x['currency_reason'])]
    g('A7 stale owner pins carry a non-CURRENT status and a reason', not st, f'{len(st)} stale')
    er = [x for x in reg['records'] if x['id'] in ('RER-ER2B-T6D', 'RER-ER2B-CARRIER')]
    g('A8 ER-2B firewall', len(er) == 2 and all(x['phaseA_status'] == 'BLOCKED_SOURCE_UNVERIFIED' and x['accepted_cohort_eligible'] is False and x['grade_status'] == 'SOURCE_CLAIMED_NOT_RER_ADOPTED' for x in er)
      and all(x['accepted_cohort_eligible'] for x in reg['records'] if x not in er))
    g('A9 no promotion: adoption PENDING everywhere', all(x['adoption_status'] == 'PENDING' and x['registry_owner_adoption'].startswith('pending') for x in reg['records']))
    c = next(x for x in reg['records'] if x['id'] == 'RER-RRF-CND01')
    g('A10 RRF-CND01 provenance split', c['claim_provenance'] == 'RER_NATIVE_STANDARD_MATH' and '[DEF] proposed interface' in c.get('provenance_note', '') and 'NOT the source of the [THM]' in c.get('provenance_note', ''))
    lg = reg['legacy_v0_1_snapshot']
    g('A11 legacy v0.1 snapshot separate', lg['label'] == 'HISTORICAL_SNAPSHOT_NOT_AN_ADOPTION_COHORT' and len(lg['entries']) == 16 and not set(e['key'] for e in lg['entries']) & set(jids))
    srcs = {b['source'] for b in br['blocked']}
    mpi = {m for x in reg['records'] for m in x['missing_primary_inputs']}
    dna = {re.findall(r'`([^`]+)`', l)[1] for l in L if l.startswith('| `') and 'Direct source not available' in l}
    erb = next((b for b in br['blocked'] if b['source'] == 'RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'), {})
    g('A12 blocked register complete', mpi <= srcs and dna <= srcs and set(erb.get('blocked_records', [])) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'}, f'{len(srcs)} sources')
    lost = sorted(set(x['key'] for x in cm['rows'] if x['path_in_r4_package'] and not x['path_in_r4_4_package']))
    rep_ok = all(x['path_in_r4_5_package'] and x['path_in_r4_6_package'] for x in cm['rows'] if x['key'] in lost) and br.get('repaired_in_r4_5') == lost
    g('A13 packaging finding complete; every lost file carried by r4.5 at its cited path', lost == br['lost_in_packaging'] and all(k in br['packaging_finding'] for k in lost) and rep_ok, f'{len(lost)} files')
    st_ok = all(x['status'] in ('VERIFIED', 'OWNER_REPORTED', 'HISTORICAL', 'BLOCKED') and x['status'] == B.status_of(x) for x in cm['rows'])
    vh_ok = all((x['verified_current_hash'] is None) or (x['current_owner_evidence'] in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER') and x['verified_current_hash'] == x['current_owner_sha256']) for x in cm['rows'])
    ver_ok = all(x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in cm['rows'] if x['status'] == 'VERIFIED')
    g('A14 receiver status vocabulary and verified-hash discipline', st_ok and vh_ok and ver_ok)
    xw = json.loads(B.rd('inputs/RECEIVER_GAP_REFERENCE_CROSSWALK_20261019.json'))
    jg = [(gp['id'], q['line']) for gp in reg['gap_entries'] for q in gp['references']]
    mg = [(r['id'], l) for r in mr if r['id'] in gaps for l in r['lines'] if l.startswith('Reference:')]
    rows_g = [x for x in cm['rows'] if x['row_kind'] == 'GAP_REFERENCE']
    g('A15 gap-reference coverage (13; equals receiver crosswalk; editor disposition received, per-reference audit pending)', len(mg) == 13 and jg == mg and sorted(l for _, l in mg) == sorted(r['reference_text'] for r in xw['rows'])
      and len(rows_g) == 13 and all(x.get('interface_questions', '').startswith('EDITOR_DISPOSITION_RECEIVED') and x.get('gap_reference_review') == 'PENDING_PER_REFERENCE_AUDIT' and 'phaseC_disposition' not in x for x in rows_g), f'{len(rows_g)} rows')
    CSK = json.loads(B.rd('catalog_sources.json'))['keys']
    def auth(x):
        if x['bytes_status'] == 'BYTE_VERIFIED_MATCH': return 'BYTE_VERIFIED_HERE'
        if CSK.get(x['key'], {}).get('receiver_byte_verified'): return 'RECEIVER_BYTE_VERIFIED'
        return 'HASH_PRINTED_UNVERIFIED' if x['cited_sha256'] else 'UNAUTHENTICATED_NO_HASH'
    g2 = [x for x in cm['rows'] if x['key'] == 'G2NOTE04']
    g('A16 authentication vocabulary; G2NOTE04 unauthenticated', all(x['authentication'] == auth(x) for x in cm['rows']) and bool(g2) and all(x['authentication'] == 'UNAUTHENTICATED_NO_HASH' for x in g2))
    def target(l):
        i = l.index('['); depth = 0
        for k in range(i, len(l)):
            depth += (l[k] == '[') - (l[k] == ']')
            if depth == 0: break
        assert l[k + 1] == '(' or l[k + 1:k + 3] == ' ('
        j = l.index('(', k + 1); return __import__('urllib.parse').parse.unquote(l[j + 1:l.index(')', j)])
    gp = [(x['cited_path'], target(next(q['line'] for gg in reg['gap_entries'] if gg['id'] == x['record'] for q in [gg['references'][x['n']]]))) for x in rows_g]
    g('A17 gap-reference paths: 13/13 non-null and equal to the link target', len(gp) == 13 and all(p and p == t for p, t in gp), f'{sum(1 for p, t in gp if p and p == t)}/13')
    Q7 = json.loads(B.rd('inputs/rrf_editor_q7_hashes.json'))
    bys = __import__('collections').defaultdict(lambda: {'blocked_records': []}, {b['source']: b for b in br['blocked']})
    g('A18 Q7 custody in the blocked register; ZIP unhashed; ER-2B still blocked',
      bys['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md'].get('rrf_editor_sha256') == Q7['RTG_RRF_RESPONSE_TO_OFN_COINCIDENCE_v0_2.md']
      and bys['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md'].get('rrf_editor_sha256') == Q7['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']
      and 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip' in bys and 'rrf_editor_sha256' not in bys['ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip']
      and set(bys['RTG_ER2B_CONSOLIDATED_STUDY_v0_2.md']['blocked_records']) == {'RER-ER2B-T6D', 'RER-ER2B-CARRIER'})
    KV = json.loads(B.rd('inputs/owner_versions_known.json'))
    oc = cm['owner_current']
    meta = cm.get('owner_catalog', {})
    g('A19 owner currency equals the frozen catalog; Dyadic v6.4.15/v6.4.16 and OFN v0.9 not current; catalog date/scope/authority recorded', all(oc.get(o, {}).get('version') == v for o, v in KV.items() if not o.startswith('_'))
      and oc['Dyadic']['version'] not in ('6.4.15', '6.4.16', '6.4.17') and oc['RECOG']['version'] == '0.3.21' and oc['OFN']['version'] == '0.10' and all(x['current_owner_version'] == oc[x['owner']]['version'] for x in cm['rows'] if x['owner'] in oc)
      and meta.get('checked') == KV['_catalog_checked'] and meta.get('scope') == KV['_scope'] and 'not live release discovery' in meta.get('scope', '')
      and meta.get('source_authority') == KV['_source_authority'] and set(KV['_source_authority']) == set(oc), f"Dyadic {oc['Dyadic']['version']}, OFN {oc['OFN']['version']}")
    g('A20 RRF editor response pinned', sha(B.rd('inputs/RRF_EDITOR_RESPONSE_TO_RER_PHASEA_v0_2_20261019.md')) == '413a869b49a295652af1379510fbece2d10619daffd5874c1320e1d686113084')
    avail = {sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) for f in os.listdir(os.path.join(HERE, 'sources_available')) if f not in withhold}
    ev_ok = all(v['evidence'] in ('BYTE_VERIFIED', 'HASH_VERIFIED_BY_RECEIVER', 'OWNER_REPORTED', 'PRINTED_ONLY') and (v['evidence'] != 'BYTE_VERIFIED' or v['sha256'] in avail) for v in oc.values())
    o = oc['OFN']
    ofn_ok = (o['evidence'] == 'OWNER_REPORTED' and o['sha256'] == 'acb70a8cfc7962abcc047dedffb59e9ceca8f2e9843d6203df6eba54f5ed5dfa'
              and o.get('superseded', {}).get('version') == '0.9' and o['superseded'].get('sha256') == '5ae8fdabad35a370f5709afa4d5dca6491e154c75f8a6f15fbb32d251fe59795'
              and all(x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['currency'] != 'CURRENT' for x in cm['rows'] if x['owner'] == 'OFN'))
    g('A21 owner-current evidence discipline; OFN v0.10 owner-reported only', ev_ok and ofn_ok)
    CU = json.loads(B.rd('inputs/source_custody_r6.json'))['files']
    cited = {}
    for x in cm['rows']: cited.setdefault(x['key'], set()).add(x['cited_sha256'])
    cu_ok = len(CU) == 14 and all(os.path.isfile(os.path.join(HERE, 'sources_available', f)) and sha(open(os.path.join(HERE, 'sources_available', f), 'rb').read()) == e['sha256'] and cited.get(e['key']) == {e['sha256']} and f.startswith(e['key'] + '__') and e.get('container') for f, e in CU.items())
    er_rec = [x for x in cm['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'RECORD_IMPORT']
    er_gap = [x for x in cm['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'GAP_REFERENCE']
    er_ok = (len(er_rec) == 3 and all(x['status'] == 'BLOCKED' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' for x in er_rec)
             and [(x['record'], x['n']) for x in er_gap] == [('RER-G8', 0)] and all(x['status'] == 'HISTORICAL' and x['currency'] == 'SNAPSHOT_RECHECK_IN_PHASE_B' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['gap_reference_review'] == 'PENDING_PER_REFERENCE_AUDIT' for x in er_gap)
             and json.loads(B.rd('inputs/source_custody_r6.json')).get('container_chain_status', '').startswith('PREPARER_DECLARED'))
    g('A22 r6 source custody (container chain preparer-declared); ER01 record rows blocked, G8/0 historical', cu_ok and er_ok, f'{len(CU)} custody entries')
    dy = oc['Dyadic']; D17 = 'e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'
    dyrows = [x for x in cm['rows'] if x['owner'] == 'Dyadic']
    C9 = json.loads(B.rd('inputs/source_custody_r9.json')); f9 = C9['files'].get('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md', {})
    sc = B.rd('inputs/dyad_v6_4_17_section_check/compare_output.txt').decode('utf-8')
    sc_ok = (sc.count('IDENTICAL') == 5 and 'RESULT: PASS' in sc and 'DIFFERENT' not in sc and 'v6.4.16 33c14c5cc27625c17a2b78be74e070ae61b5c7399ded49a1538098735ab559e0 MATCH' in sc
             and f'v6.4.17 {D17} MATCH' in sc)
    D18 = 'f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'
    dy_ok = (dy['version'] == '6.4.18' and dy['sha256'] == D18 and dy['evidence'] == 'OWNER_REPORTED' and D18 not in avail and D17 in avail
             and f9.get('key') == 'DYAD617' and f9.get('sha256') == D17 and sc_ok
             and dy.get('history', {}).get('phaseA_r8', {}).get('evidence') == 'OWNER_REPORTED' and dy['history'].get('phaseA_r9_r11', {}).get('evidence') == 'BYTE_VERIFIED' and dy['history']['phaseA_r9_r11'].get('sha256') == D17
             and dy.get('superseded', {}).get('version') == '6.4.17' and dy['superseded'].get('sha256') == D17 and dy['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and len(dyrows) >= 1 and all(x['verified_current_hash'] is None and x['current_owner_evidence'] == 'OWNER_REPORTED' and x['current_owner_version'] == '6.4.18' and x['currency'] == 'RECHECK_IN_PHASE_B' and x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' for x in dyrows)
             and all(x['cited_version'] == '6.4.13' and x['cited_sha256'] == '5958f7fe8a3e0ec94546cb7e915c5f690d09827a3d680d13a17c9d880b968542' and x['authentication'] == 'RECEIVER_BYTE_VERIFIED' for x in dyrows if x['key'] == 'DYAD6413'))
    g('A23 Dyadic v6.4.18 owner-reported; v6.4.17 byte-verified identity kept as superseded (file, custody, section check); history kept; RER pins stay v6.4.13', dy_ok, f'{len(dyrows)} Dyadic row(s)')
    m9 = json.loads(B.rd('inputs/phaseA_r9_outputs/SOURCE_CURRENCY_MATRIX.json')); r9 = json.loads(B.rd('inputs/phaseA_r9_outputs/RER_REGISTRY_v0_2_r4_6_PHASEA.json'))
    ident = lambda x: tuple((None if (x.get('owner') in ('Dyadic', 'RECOG') and k in ('currency', 'status', 'current_owner_version', 'verified_current_hash')) else x.get(k)) for k in ('record', 'row_kind', 'n', 'key', 'cited_version', 'cited_sha256', 'bytes_status', 'authentication', 'currency', 'status', 'current_owner_version', 'verified_current_hash'))  # r12: owner-currency fields of Dyadic/RECOG rows are checked by A23/A26
    new = [x for x in cm['rows'] if ident(x) not in set(ident(y) for y in m9['rows'])]; gone = [y for y in m9['rows'] if ident(y) not in set(ident(x) for x in cm['rows'])]
    add = new[0] if len(new) == 1 else {}
    rows_ok = (not gone and len(cm['rows']) == len(m9['rows']) + 1 and len(new) == 1 and add.get('record') == 'RER-DYAD-FORMAL-INVOLUTION' and add.get('row_kind') == 'RECORD_IMPORT'
               and add.get('n') == 2 and add.get('key') == 'RRF083' and add.get('cited_version') == '0.8.3' and add.get('cited_sha256') == 'b393657e75e78ce46aea8920f4e5c25480e523caaa105589920a34ee55d4a187'
               and add.get('currency') == 'CURRENT' and add.get('authentication') == 'RECEIVER_BYTE_VERIFIED' and add.get('status') == 'OWNER_REPORTED' and all('path_in_r4_7_package' in x and 'path_in_r4_8_package' in x for x in cm['rows']))
    sm = reg['source_markdown']
    src_ok = (sm['file'].endswith('_r4_8.md') and sm['sha256'] == B.MD_SHA == '2dfebebfd7884d2e1711d353e8b5e9bee756f16416d857bb0ad8124b9bf60e3e' and sm['package_zip_sha256'] == '26efafc9efd3c3c5208c4e7238d99162bc99fd755357b436fa89f6d2db654a9f'
              and sm.get('base_r4_7_sha256') == '110729e54a2c960e93150a8d38fc75cbd6794c62ec00d2375dae80d20382cd1d' and sm.get('base_r4_7_package_zip_sha256') == '9ab6393e94001d5c513f68af64e32d63afb0548b31879afcfc3912911ecfc14f'
              and sm.get('base_r4_6_sha256') == '2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772' and cm['source_markdown_sha256'] == B.MD_SHA and br['source_markdown_sha256'] == B.MD_SHA)
    R9 = {x['id']: x for x in r9['records']}; R10 = {x['id']: x for x in reg['records']}
    oth = [k for k in R9 if k != 'RER-DYAD-FORMAL-INVOLUTION']
    dy9, dy10 = R9.get('RER-DYAD-FORMAL-INVOLUTION', {}), R10.get('RER-DYAD-FORMAL-INVOLUTION', {})
    rec_ok = (set(R9) == set(R10) and len(oth) == 19 and all(R9[k] == R10[k] for k in oth) and dy9 != dy10
              and all(dy9.get(f) == dy10.get(f) for f in ('exactness_codes', 'exactness_text', 'task', 'open_items', 'registry_owner_adoption')) and len(dy10.get('imports', [])) == len(dy9.get('imports', [])) + 1
              and dy9.get('primary_grade') == dy10.get('primary_grade') == '[THM] (owner grade)' and dy9.get('grade_tags') == dy10.get('grade_tags') == ['THM'])  # r11: R10-F1 closed by r4.8
    g('A24 r4.8 source pass: sources pinned; matrix = r9 + one RRF083 row; registry differs from r9 only in RER-DYAD-FORMAL-INVOLUTION text (grade parse as r9)', src_ok and rows_ok and rec_ok, f'{len(cm["rows"])} rows, {len(new)} new, {len(gone)} gone')
    H10 = 'inputs/phaseA_r10_outputs/'
    m10 = json.loads(B.rd(H10 + 'SOURCE_CURRENCY_MATRIX.json')); g10 = json.loads(B.rd(H10 + 'RER_REGISTRY_v0_2_r4_7_PHASEA.json'))
    i10 = [ident(x) for x in m10['rows']]; i11 = [ident(x) for x in cm['rows']]
    m_ok = i10 == i11 and len(i11) == 90 and all('path_in_r4_8_package' in x for x in cm['rows'])
    A10 = {x['id']: x for x in g10['records']}; A11 = {x['id']: x for x in reg['records']}
    a, c = A10.get('RER-DYAD-FORMAL-INVOLUTION', {}), A11.get('RER-DYAD-FORMAL-INVOLUTION', {})
    diff = sorted(k for k in set(a) | set(c) if a.get(k) != c.get(k))
    newu = [l for l in c.get('unclassified_lines', []) if l not in a.get('unclassified_lines', [])]
    r_ok = (set(A10) == set(A11) and all(A10[k] == A11[k] for k in A10 if k != 'RER-DYAD-FORMAL-INVOLUTION')
            and set(diff) <= {'primary_grade', 'primary_grade_line', 'grade_tags', 'unclassified_lines'} and {'primary_grade', 'grade_tags'} <= set(diff)
            and c.get('primary_grade') == '[THM] (owner grade)' and c.get('grade_tags') == ['THM'] and a.get('grade_tags') == ['ALG', 'THM']
            and len(newu) == 1 and newu[0].startswith('**Owner grades per imported RID** (source note;') and '`DYAD-ALG-CENT-KERNEL` [ALG]' in newu[0])
    g('A25 r10 equality: 90 rows unchanged; only the R10-F1 fields of RER-DYAD-FORMAL-INVOLUTION differ (grade [THM], tags [THM], source note with CENT-KERNEL [ALG])', m_ok and r_ok, f'DYAD fields differing from r10: {diff}')
    rc = oc['RECOG']; G21 = 'a3459522c8f58204f83f5e65e3d1a99912f9651d1c17cc4fb0c090196f670ae3'; G20 = 'fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'
    rr_ = [x for x in cm['rows'] if x['owner'] == 'RECOG']
    rc_ok = (rc['version'] == '0.3.21' and rc['sha256'] == G21 and rc['evidence'] == 'OWNER_REPORTED' and G21 not in avail and G20 in avail
             and rc.get('superseded', {}).get('version') == '0.3.20' and rc['superseded'].get('sha256') == G20 and rc['superseded'].get('evidence', '').startswith('BYTE_VERIFIED')
             and rc['superseded'].get('frozen', '').startswith('FROZEN 19 Oct 2026 — OWNER_REPORTED') and rc.get('history', {}).get('phaseA_r6_r11', {}).get('evidence') == 'BYTE_VERIFIED'
             and len(rr_) == 2 and all(x['cited_version'] == '0.3.20' and x['bytes_status'] == 'BYTE_VERIFIED_MATCH' and x['authentication'] == 'BYTE_VERIFIED_HERE' and x['currency'] == 'UNCHANGED_OWNER_REPORTED'
                                       and x['status'] == 'OWNER_REPORTED' and x['verified_current_hash'] is None and x['current_owner_version'] == '0.3.21' for x in rr_))
    g('A26 RECOG v0.3.21 owner-reported; v0.3.20 byte-verified bytes kept, frozen status owner-reported; RECOG rows not CURRENT', rc_ok, f'{len(rr_)} RECOG rows')
    mdl = md.split('\n'); W = [w for w in cm.get('scientific_sync_warnings', []) if w.get('id') == 'SYNC-DYAD-OPEN20-BINF']
    w = W[0] if len(W) == 1 else {}
    present = bool(w.get('rer_lines')) and all(l in mdl for l in w['rer_lines'])
    w_ok = (len(W) == 1 and w.get('record') == 'RER-DYAD-FORMAL-INVOLUTION' and w.get('key') == 'DYAD6413' and w.get('owner_version') == '6.4.18' and w.get('owner_evidence') == 'OWNER_REPORTED'
            and len(w.get('rer_lines', [])) == 2 and w['rer_lines'][0].startswith('[OPEN] OPEN 20 B-∞ existence:') and present and w.get('rer_lines_present') == [True, True]
            and w.get('status', '').startswith('OPEN') and 'CLOSED' not in w.get('status', '') and 'catalog change alone does not close it' in w.get('closes_only_when', '')
            and all(x.get('sync_warning') == 'SYNC-DYAD-OPEN20-BINF' for x in cm['rows'] if x['key'] == 'DYAD6413'))
    g('A27 scientific sync warning SYNC-DYAD-OPEN20-BINF open while the r4.8 B-∞ lines are present; not closed by Phase A', w_ok, w.get('status', 'missing'))
    return all(res), res

outs = {p: open(os.path.join(HERE, p), 'rb').read() for p in B.build()}
ok, res = gates(outs); print(f'\n{sum(res)}/{len(res)} gates PASS')
if '--tamper' in sys.argv:
    print('\nnegative controls (each must FAIL the named gate):')
    def mut(path, f):
        o = dict(outs); d = json.loads(o[path]); f(d); o[path] = B.dump(d); return o
    R, C, K = 'out/RER_REGISTRY_v0_2_r4_8_PHASEA.json', 'out/SOURCE_CURRENCY_MATRIX.json', 'out/BLOCKED_SOURCE_REGISTER.json'
    T = [('A3 drop a record', 2, mut(R, lambda d: d['records'].pop(5))),
         ('A4 change a contract cell', 3, mut(R, lambda d: d['records'][0]['contract'].__setitem__('Closure status', 'CLOSED'))),
         ('A6 false byte claim', 5, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY').update(bytes_status='BYTE_VERIFIED_MATCH', available_file='sources_available/none'))),
         ('A7 stale pin marked CURRENT', 6, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'GEN287').update(currency='CURRENT'))),
         ('A8 ER-2B unblocked', 7, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-ER2B-T6D').update(phaseA_status='ACTIVE', accepted_cohort_eligible=True))),
         ('A9 promote adoption', 8, mut(R, lambda d: d['records'][3].update(adoption_status='ADOPTED'))),
         ('A12 drop a blocked source', 11, mut(K, lambda d: d['blocked'].pop(0))),
         ('A14 printed-only row labelled VERIFIED', 13, mut(C, lambda d: next(x for x in d['rows'] if x['bytes_status'] == 'PRINTED_ONLY' and x['currency'] != 'BLOCKED').update(status='VERIFIED'))),
         ('A4 alter one import line', 3, mut(R, lambda d: d['records'][3]['imports'][0].__setitem__('line', d['records'][3]['imports'][0]['line'].replace('SHA-256', 'SHA256', 1)))),
         ('A4 drop an unclassified line', 3, mut(R, lambda d: next(x for x in d['records'] if x['unclassified_lines'])['unclassified_lines'].pop())),
         ('A15 drop a gap reference row', 14, mut(C, lambda d: d['rows'].remove(next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE')))),
         ('A16 G2NOTE04 labelled hash-printed', 15, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'G2NOTE04').update(authentication='HASH_PRINTED_UNVERIFIED'))),
         ('A17 null a gap-reference path', 16, mut(C, lambda d: next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE' and x['record'] == 'RER-G9').update(cited_path=None))),
         ('A19 Dyadic v6.4.15 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.15'))),
         ('A15 gap row back to PENDING_RRF_EDITOR', 14, mut(C, lambda d: next(x for x in d['rows'] if x['row_kind'] == 'GAP_REFERENCE').update(phaseC_disposition='PENDING_RRF_EDITOR'))),
         ('A18 give the ZIP an editor hash', 17, mut(K, lambda d: next(b for b in d['blocked'] if b['source'] == 'ER2B_COINCIDENCE_SIXSTEP_AUDIT_v0_1.zip').update(rrf_editor_sha256='0' * 64))),
         ('A19 OFN v0.9 claimed current', 18, mut(C, lambda d: d['owner_current']['OFN'].update(version='0.9'))),
         ('A19 catalog scope presented as live discovery', 18, mut(C, lambda d: d['owner_catalog'].update(scope='LIVE_RELEASE_DISCOVERY'))),
         ('A21 OFN v0.10 reported hash promoted to BYTE_VERIFIED_HERE', 20, mut(C, lambda d: d['owner_current']['OFN'].update(evidence='BYTE_VERIFIED_HERE'))),
         ('A21 OFN v0.10 promoted to BYTE_VERIFIED without bytes', 20, mut(C, lambda d: d['owner_current']['OFN'].update(evidence='BYTE_VERIFIED'))),
         ('A22 ER01 record-import row unblocked', 21, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'RECORD_IMPORT').update(status='HISTORICAL'))),
         ('A22 G8/0 back to BLOCKED', 21, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'ER01' and x['row_kind'] == 'GAP_REFERENCE').update(status='BLOCKED', currency='BLOCKED'))),
         ('A21 OFN row given a verified current hash', 20, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'OFN').update(verified_current_hash='acb70a8cfc7962abcc047dedffb59e9ceca8f2e9843d6203df6eba54f5ed5dfa'))),
         ('A19 Dyadic v6.4.16 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.16'))),
         ('A23 v6.4.18 promoted to BYTE_VERIFIED without bytes', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED'))),
         ('A23 Dyadic evidence relabelled BYTE_VERIFIED_HERE (not catalog vocabulary)', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(evidence='BYTE_VERIFIED_HERE'))),
         ('A23 v6.4.18 hash replaced', 22, mut(C, lambda d: d['owner_current']['Dyadic'].update(sha256='0' * 64))),
         ('A23 Dyadic row given the v6.4.18 hash as verified', 22, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'Dyadic').update(verified_current_hash='f70308f19f5955c0597c03a27b572abfd4c8746aef6922c959675eb0d56e458d'))),
         ('A23 DYAD6413 currency left UNCHANGED_OWNER_REPORTED', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(currency='UNCHANGED_OWNER_REPORTED', status='OWNER_REPORTED'))),
         ('A23 r9-r11 BYTE_VERIFIED history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r9_r11'))),
         ('A19 Dyadic v6.4.17 claimed current', 18, mut(C, lambda d: d['owner_current']['Dyadic'].update(version='6.4.17'))),
         ('A19 RECOG v0.3.20 claimed current', 18, mut(C, lambda d: d['owner_current']['RECOG'].update(version='0.3.20'))),
         ('A26 RECOG v0.3.21 promoted to BYTE_VERIFIED without bytes', 25, mut(C, lambda d: d['owner_current']['RECOG'].update(evidence='BYTE_VERIFIED'))),
         ('A26 RECOG row left CURRENT/VERIFIED', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(currency='CURRENT', status='VERIFIED'))),
         ('A26 RECOG row given a verified current hash', 25, mut(C, lambda d: next(x for x in d['rows'] if x['owner'] == 'RECOG').update(verified_current_hash='fdb8c9a72cbea67bae339a890f440b7d67c608979f7886279e2cd00bdabfb8df'))),
         ('A26 v0.3.20 frozen statement dropped', 25, mut(C, lambda d: d['owner_current']['RECOG']['superseded'].pop('frozen'))),
         ('A26 v0.3.20 byte-verified identity dropped', 25, mut(C, lambda d: d['owner_current']['RECOG'].pop('superseded'))),
         ('A27 sync warning removed', 26, mut(C, lambda d: d.update(scientific_sync_warnings=[]))),
         ('A27 sync warning marked CLOSED while the B-∞ line is present', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(status='CLOSED — catalog updated'))),
         ('A27 sync warning lines altered (no longer tied to the source)', 26, mut(C, lambda d: d['scientific_sync_warnings'][0].update(rer_lines=['[OPEN] OPEN 20 B-∞ existence: (paraphrased)', d['scientific_sync_warnings'][0]['rer_lines'][1]]))),
         ('A27 DYAD6413 row loses its sync_warning link', 26, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').pop('sync_warning'))),
         ('A23 r8 history dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic']['history'].pop('phaseA_r8'))),
         ('A24 r9 matrix rows re-used (RRF083 row absent)', 23, mut(C, lambda d: d.update(rows=json.loads(B.rd('inputs/phaseA_r9_outputs/SOURCE_CURRENCY_MATRIX.json'))['rows']))),
         ('A24 RRF083 row dropped', 23, mut(C, lambda d: d['rows'].remove(next(x for x in d['rows'] if x['key'] == 'RRF083')))),
         ('A24 RRF083 row promoted to BYTE_VERIFIED_HERE', 23, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(authentication='BYTE_VERIFIED_HERE'))),
         ('A24 source recorded as r4.6', 23, mut(R, lambda d: d['source_markdown'].update(sha256='2fa878ffa32c0d4d725f53f17b86b9a43d5161f16a7adce9686cb374063a4772'))),
         ('A24 another record silently changed', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C01').update(task='CLOSED'))),
         ('A24 DYAD grade changed', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(primary_grade='[ALG]'))),
         ('A24 grade tags back to the r4.7 parse [ALG, THM]', 23, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(grade_tags=['ALG', 'THM']))),
         ('A25 r10 registry re-used (r4.7 parse)', 24, mut(R, lambda d: d.update(records=json.loads(B.rd('inputs/phaseA_r10_outputs/RER_REGISTRY_v0_2_r4_7_PHASEA.json'))['records']))),
         ('A25 source note dropped from the DYAD record', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION').update(unclassified_lines=[l for l in next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')['unclassified_lines'] if not l.startswith('**Owner grades per imported RID**')]))),
         ('A25 CENT-KERNEL relabelled [THM] in the note', 24, mut(R, lambda d: (lambda r: r.update(unclassified_lines=[l.replace('`DYAD-ALG-CENT-KERNEL` [ALG]', '`DYAD-ALG-CENT-KERNEL` [THM]') for l in r['unclassified_lines']]))(next(x for x in d['records'] if x['id'] == 'RER-DYAD-FORMAL-INVOLUTION')))),
         ('A25 one matrix row altered vs r10', 24, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'RRF083').update(currency='UNCHANGED_OWNER_REPORTED'))),
         ('A25 another record altered vs r10', 24, mut(R, lambda d: next(x for x in d['records'] if x['id'] == 'RER-GEN-C02').update(title='x'))),
         ('A23 DYAD6413 pin silently moved to v6.4.17', 22, mut(C, lambda d: next(x for x in d['rows'] if x['key'] == 'DYAD6413').update(cited_version='6.4.17', cited_sha256='e07cf2b93b532554d9e1d05d2bfef3be34829b7cb892627c0bb03d1d182d4bfc'))),
         ('A23 superseded v6.4.17 record dropped', 22, mut(C, lambda d: d['owner_current']['Dyadic'].pop('superseded')))]
    allf = True
    for n, i, o in T:
        _, rr = gates(o, verbose=False); good = not rr[i]; allf &= good
        print(f'  tamper {n}: {"FAILS (good)" if good else "still passes (BAD)"}')
    _, rr = gates(outs, verbose=False, withhold=('DYAD617__RTG_DYADIC_OSCILLATOR_DSN_v6_4_17.md',)); good = not rr[22]; allf &= good
    print(f'  file control A23 v6.4.17 file withheld from sources_available: {"FAILS (good)" if good else "still passes (BAD)"}')
    ok = ok and allf
sys.exit(0 if ok else 1)
