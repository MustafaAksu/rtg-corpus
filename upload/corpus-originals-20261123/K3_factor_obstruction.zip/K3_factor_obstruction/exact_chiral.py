import sympy as sp
w1,w2,W1,W2=sp.symbols('w1 w2 W1 W2'); s3=sp.sqrt(3)
nu=sp.Rational(1,6)-sp.I*s3/3; chi=sp.Rational(1,3)
w=[w1,w2,-w1-w2]; W=[W1,W2,-W1-W2]
S0=(w[0]*W[1]-W[0]*w[1])/(2*sp.I)
cub=[w[e]**2*W[e] for e in range(3)]; mean=sum(cub)/3
f=[nu*(cub[e]-mean)+(2*sp.I*chi/3)*(w[(e+1)%3]-w[(e-1)%3])*S0 for e in range(3)]
N=sum(w[e]*W[e] for e in range(3))
for sgn in (1,-1):
    om=sp.exp(sgn*sp.I*sp.pi/3); omb=sp.exp(-sgn*sp.I*sp.pi/3)
    l=w1+om*w2; L=W1+omb*W2
    c=sp.Rational(1,6)+sp.I*s3/9; beta=2*s3/9
    d=sp.expand(f[0]+om*f[1]-(c*l**2*L-sp.I*beta*N*l))
    print("chirality",sgn,": defect =",sp.simplify(sp.expand_complex(d)))
