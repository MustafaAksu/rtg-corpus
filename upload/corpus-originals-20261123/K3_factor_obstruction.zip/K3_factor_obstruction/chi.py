import numpy as np
Fn=np.load('/tmp/fac/Fn.npy'); P=np.load('/tmp/fac/P.npy'); s3=np.sqrt(3)
W=np.c_[P,-P.sum(axis=1)]; N=np.sum(abs(W)**2,axis=1)
for name,ph in [("l+",np.pi/3),("l-",-np.pi/3)]:
    a=np.array([1,np.exp(1j*ph)]); l=P@a; lf=Fn[:,:2]@a
    X=np.c_[l*abs(l)**2, 1j*N*l]; coef,*_=np.linalg.lstsq(X,lf,rcond=None)
    # restrict: is second coef purely imaginary-real? report
    r=np.linalg.norm(X@coef-lf)/np.linalg.norm(lf)
    print(name,"c =",coef[0],"  i*beta coef (beta) =",coef[1]," resid",r)
    print("   modulus autonomy: max |Re(conj(l)*(lf - c l|l|^2))|/|l|^4 =",np.max(abs(np.real(np.conj(l)*(lf-coef[0]*l*abs(l)**2)))/abs(l)**4))
print("2sqrt3/9 =",2*s3/9)
