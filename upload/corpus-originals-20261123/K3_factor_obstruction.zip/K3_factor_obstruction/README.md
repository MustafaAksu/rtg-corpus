# Projected K3 (kappa=1): no rank-2 C^3 factor onto any planar germ with linear part A

f = resonant cubic of the six-step map F1^6 on C = {w1+w2+w3=0} (eigenframe W = rho - eta/2 + i*sqrt3*eta/2):
  f_e = nu (w_e|w_e|^2 - mean) + (2i chi/3)(w_{e+1}-w_{e-1}) Im(w_1 conj w_2),  nu = 1/6 - i sqrt3/3, chi = 1/3

- k3.py : extracts the resonant cubic of the TRUE map P_C T^{x3} (6 steps, odd-part + Richardson, rotation-averaged),
          fits f_num = s f_model + gamma N w  ->  s = 1, gamma = 0 (rel. resid 5e-9). Dyad check: mu_num = -1/2 - 2i sqrt3/3.
- fac.py : exact Groebner basis for  l(f) = c l|l|^2  (l complex-linear, c free)  ->  only l = 0.
- num.py / chi.py : numeric confirmation (min rel. residual ~0.14-0.17 > 0); near-miss with a hidden i*beta*N*w term.
- exact_chiral.py : exact identity for chiral (Z3-Fourier) modes l_pm = w1 + e^{±i pi/3} w2:
      l_pm(f) = (1/6 + i sqrt3/9) l_pm |l_pm|^2  -  i (2 sqrt3/9) N l_pm ,   N = sum_e |w_e|^2
  => |l_pm|^2 autonomous at cubic order; obstruction to a planar factor = phase coupling beta* = 2 sqrt3/9 != 0.
