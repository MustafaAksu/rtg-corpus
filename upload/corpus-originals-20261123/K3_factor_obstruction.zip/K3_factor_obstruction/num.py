import numpy as np
from scipy.optimize import minimize
s3=np.sqrt(3); nu=1/6-1j*s3/3; chi=1/3
rng=np.random.default_rng(0)
P=rng.normal(size=(400,2))+1j*rng.normal(size=(400,2))
def fvec(w1,w2):
    w=[w1,w2,-w1-w2]; S0=np.imag(w[0]*np.conj(w[1]))
    cub=[x*abs(x)**2 for x in w]; m=sum(cub)/3
    return [nu*(cub[e]-m)+(2j*chi/3)*(w[(e+1)%3]-w[(e-1)%3])*S0 for e in range(3)]
F=np.array([fvec(*p) for p in P])
def res(t,ret=False):
    th,ph=t; a=np.array([np.cos(th),np.sin(th)*np.exp(1j*ph)])
    lf=F[:,0]*a[0]+F[:,1]*a[1]; l=P@a; g=l*abs(l)**2
    c=np.vdot(g,lf)/np.vdot(g,g); r=np.linalg.norm(lf-c*g)/np.linalg.norm(lf)
    return (r,c,a) if ret else r
best=min((minimize(res,x0,method='Nelder-Mead') for x0 in rng.uniform(0,np.pi*2,(60,2))),key=lambda o:o.fun)
r,c,a=res(best.x,True); print("min relative residual",r," c",c," a",a)
# reference: raw edge l=w1
for name,a in [("w1",[1,0]),("w1-w2",[1,-1]),("w1-w3=2w1+w2",[2,1])]:
    a=np.array(a,complex);a/=np.linalg.norm(a);lf=F[:,0]*a[0]+F[:,1]*a[1];l=P@a;g=l*abs(l)**2
    c=np.vdot(g,lf)/np.vdot(g,g);print(name,np.linalg.norm(lf-c*g)/np.linalg.norm(lf))
print("--- with hidden uniform phase term i*beta*N*w_e, beta free real ---")
Nv=np.sum(np.abs(np.c_[P,-P[:,0]-P[:,1]])**2,axis=1)
def res2(t,ret=False):
    th,ph,be=t; a=np.array([np.cos(th),np.sin(th)*np.exp(1j*ph)])
    lf=F[:,0]*a[0]+F[:,1]*a[1]+1j*be*Nv*(P@a); l=P@a; g=l*abs(l)**2
    c=np.vdot(g,lf)/np.vdot(g,g); r=np.linalg.norm(lf-c*g)/np.linalg.norm(lf)
    return (r,c,a) if ret else r
best=min((minimize(res2,np.r_[x0,b0],method='Nelder-Mead',options={'maxiter':4000,'xatol':1e-10,'fatol':1e-12}) for x0 in rng.uniform(0,np.pi*2,(40,2)) for b0 in (-2,0,2)),key=lambda o:o.fun)
r,c,a=res2(best.x,True); print("min residual",r," beta",best.x[2]," c",c)
print("a =",a, " ratio a2/a1 =",a[1]/a[0], " beta*2-check 2sqrt3/9=",2*s3/9)
mu=-0.5-2j*s3/3; print("c/mu =",c/mu)
for be in [-1,-0.5,0,0.2,0.35,2*s3/9,0.42,0.6,1.0]:
    bb=min((minimize(lambda t:res2(np.r_[t,be]),x0,method='Nelder-Mead') for x0 in rng.uniform(0,2*np.pi,(30,2))),key=lambda o:o.fun)
    print(f"beta={be:.4f} min residual={bb.fun:.3e}")
