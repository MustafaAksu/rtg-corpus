import numpy as np
from mpmath import mp
from scipy.optimize import minimize
s3=np.sqrt(3); lam=np.exp(1j*np.pi/3)
def T(r):  # r: (3,2)
    rho,eta=r[:,0],r[:,1]
    return np.c_[rho-np.sin(eta), eta+np.expm1(rho)-np.sin(eta)]
def N1(r):
    t=T(r); return t-t.mean(axis=0)
def F6(r):
    for _ in range(6): r=N1(r)
    return r
def toW(r): return r[:,0]-r[:,1]/2+1j*s3*r[:,1]/2
def fromW(W): eta=2*W.imag/s3; return np.c_[W.real+eta/2, eta]
def f3(w):  # w: (2,) complex -> cubic coefficient field, components e=1,2
    W=np.array([w[0],w[1],-w[0]-w[1]])
    def g(eps):
        a=toW(F6(fromW(eps*W))); b=toW(F6(fromW(-eps*W)))
        return ((a-b)/2-eps*W)/eps**3
    e1,e2=2e-2,1e-2
    return (4*g(e2)-g(e1))/3   # Richardson (error eps^2)
def fres(w):
    return sum(lam**(-k)*f3(lam**k*np.asarray(w)) for k in range(6))/6
rng=np.random.default_rng(1)
P=rng.normal(size=(60,2))+1j*rng.normal(size=(60,2)); P/=np.linalg.norm(P,axis=1)[:,None]
Fn=np.array([fres(p) for p in P])   # (60,3)
print("closure check max|sum|:",np.abs(Fn.sum(axis=1)).max())
# model
nu=1/6-1j*s3/3; chi=1/3
def fmod(w1,w2):
    w=[w1,w2,-w1-w2]; S0=np.imag(w[0]*np.conj(w[1]))
    cub=[x*abs(x)**2 for x in w]; m=sum(cub)/3
    return np.array([nu*(cub[e]-m)+(2j*chi/3)*(w[(e+1)%3]-w[(e-1)%3])*S0 for e in range(3)])
Fm=np.array([fmod(*p) for p in P]); Wfull=np.c_[P,-P.sum(axis=1)]; Nv=np.sum(abs(Wfull)**2,axis=1)
# fit Fn ~ s*Fm + 1j*beta*N*w  (s complex, beta complex then check)
X=np.c_[Fm.reshape(-1), (Nv[:,None]*Wfull).reshape(-1)]
coef,res,_,_=np.linalg.lstsq(X,Fn.reshape(-1),rcond=None)
print("fit s, gamma(N w coef):",coef," rel resid:",np.linalg.norm(X@coef-Fn.reshape(-1))/np.linalg.norm(Fn))
np.save('/tmp/fac/Fn.npy',Fn); np.save('/tmp/fac/P.npy',P)
# direct factor test on numeric resonant cubic
def res(t,ret=False):
    th,ph=t; a=np.array([np.cos(th),np.sin(th)*np.exp(1j*ph)])
    lf=Fn[:,0]*a[0]+Fn[:,1]*a[1]; l=P@a; g=l*abs(l)**2
    c=np.vdot(g,lf)/np.vdot(g,g); r=np.linalg.norm(lf-c*g)/np.linalg.norm(lf)
    return (r,c,a) if ret else r
best=sorted((minimize(res,x0,method='Nelder-Mead',options={'xatol':1e-10,'fatol':1e-14}) for x0 in rng.uniform(0,2*np.pi,(80,2))),key=lambda o:o.fun)
seen=[]
for o in best:
    r,c,a=res(o.x,True); ratio=a[1]/a[0] if abs(a[0])>1e-8 else np.inf
    key=(round(r,6),)
    if key in seen: continue
    seen.append(key); print(f"resid={r:.3e} c={c:.6f} a2/a1={ratio:.6f}")
    if len(seen)>4: break
# dyad six-step cubic for comparison (single edge, kappa=0)
def Td(r):
    for _ in range(6): r=np.array([r[0]-np.sin(r[1]), r[1]+np.expm1(r[0])-np.sin(r[1])])
    return r
def f3d(z):
    def g(eps):
        a=Td(np.array([ (eps*z).real+ (2*(eps*z).imag/s3)/2, 2*(eps*z).imag/s3]))
        b=Td(np.array([ (-eps*z).real+ (2*(-eps*z).imag/s3)/2, 2*(-eps*z).imag/s3]))
        A=a[0]-a[1]/2+1j*s3*a[1]/2; B=b[0]-b[1]/2+1j*s3*b[1]/2
        return ((A-B)/2-eps*z)/eps**3
    return (4*g(1e-2)-g(2e-2))/3
z=np.exp(0.7j); fd=sum(lam**(-k)*f3d(lam**k*z) for k in range(6))/6
print("dyad six-step resonant cubic coef mu_num =",fd/(z*abs(z)**2))
