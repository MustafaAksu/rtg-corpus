import sympy as sp
w1,w2,W1,W2=sp.symbols('w1 w2 W1 W2')  # W = conj(w), treated independent
a1,a2,c=sp.symbols('a1 a2 c')
s3=sp.sqrt(3)
nu=sp.Rational(1,6)-sp.I*s3/3; chi=sp.Rational(1,3)
w=[w1,w2,-w1-w2]; W=[W1,W2,-W1-W2]
S0=(w[0]*W[1]-W[0]*w[1])/(2*sp.I)
cub=[w[e]*w[e]*W[e] for e in range(3)]; mean=sum(cub)/3
f=[sp.expand(nu*(cub[e]-mean)+(2*sp.I*chi/3)*(w[(e+1)%3]-w[(e-1)%3])*S0) for e in range(3)]
print("sum f =",sp.simplify(sum(f)))
# l = a1 w1 + a2 w2 ; l(f) = a1 f1 + a2 f2 ; lbar uses conj(a)
A1,A2=sp.symbols('A1 A2')  # conj(a1),conj(a2)
l=a1*w1+a2*w2; L=A1*W1+A2*W2
expr=sp.expand(a1*f[0]+a2*f[1]-c*l*l*L)
P=sp.Poly(expr,w1,w2,W1,W2)
eqs=[sp.expand(co) for co in P.coeffs()]
print(len(eqs),"equations")
# treat A1,A2 as conj: substitute a=x+iy
x1,y1,x2,y2,cr,ci=sp.symbols('x1 y1 x2 y2 cr ci',real=True)
sub={a1:x1+sp.I*y1,A1:x1-sp.I*y1,a2:x2+sp.I*y2,A2:x2-sp.I*y2,c:cr+sp.I*ci}
reqs=[]
for e in eqs:
    e2=sp.expand(e.subs(sub)); reqs+= [sp.re(e2),sp.im(e2)]
reqs=[sp.simplify(r) for r in reqs if sp.simplify(r)!=0]
G=sp.groebner(reqs,cr,ci,x1,y1,x2,y2,order='lex')
print(G)
