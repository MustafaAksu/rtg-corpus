#!/usr/bin/env python3
"""P2-B v2: exact degree-nine vector-jet sharpening, fixed degree-six h.

New working certificate, not an owner-DSN amendment. All acceptance decisions
use exact fractions and integer square-root ceilings. Baseline input files
are read only. No fit or sampled trajectory enters the uniform proof.
"""
from __future__ import annotations
import argparse, importlib.util, json, sys
from pathlib import Path
from fractions import Fraction as R
from math import factorial, isqrt
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'inputs/baseline/DYAD_RETURN_ENCLOSURE_P2A_v2_P2B_v1'
spec=importlib.util.spec_from_file_location('p1_kernel',BASE/'inputs/p1_exact_kernel_and_audit.py')
p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
K=p.K
checks=[]
def check(label,condition):
    ok=bool(condition); checks.append({'label':label,'pass':ok})
    print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok: raise AssertionError(label)
def ceil_grid(x,den=10**80):
    return R(-((-x.numerator*den)//x.denominator),den)
def sqrt_upper(x,den=10**10):
    if x<0: raise ValueError('negative modulus square')
    n=isqrt(x.numerator*den*den//x.denominator)
    if R(n,den)**2<x: n+=1
    y=R(n,den)
    if y*y<x: raise ArithmeticError('bad square-root enclosure')
    return y
def ms(poly): return sum((sqrt_upper(c.a*c.a+3*c.b*c.b) for c in poly.values()),R(0))
def conv(a,b,N=None):
    if N is None: N=len(a)+len(b)-2
    r=[R(0)]*(N+1)
    for i,x in enumerate(a):
        if not x: continue
        for j,y in enumerate(b):
            if i+j<=N and y: r[i+j]+=x*y
    return r
def compose(a,b,N=None):
    if N is None: N=(len(a)-1)*(len(b)-1)
    r=[R(0)]*(N+1); bp=[R(1)]
    for x in a:
        if x:
            for j,y in enumerate(bp): r[j]+=x*y
        bp=conv(bp,b,N)
    return r
def ep(a,s):
    r=R(0)
    for x in reversed(a): r=r*s+x
    return r
def dp(a): return [n*a[n] for n in range(1,len(a))]
def scalar_series(N):
    a=R(7,6)
    psi=[R(0),R(1)]+[R(1+n%2,factorial(n))*a**n for n in range(2,N+1)]
    S=[R(0)]*(N+1);S[1]=R(1)
    for _ in range(6): S=compose(psi,S,N)
    return S
def psi_upper(u):
    x=R(7,6)*u;N=30
    if not 0<=x<1:raise ValueError('majorant tail domain')
    finite=u+sum((R(1+n%2,factorial(n))*x**n for n in range(2,N+1)),R(0))
    tail=2*x**(N+1)/factorial(N+1)/(1-x/R(N+2))
    return ceil_grid(finite+tail)
def orbit_upper(r):
    u=[r]
    for _ in range(6):u.append(psi_upper(u[-1]))
    return u
def pack(poly):return {f'{a},{b}':[str(c.a),str(c.b)] for (a,b),c in sorted(poly.items())}
def unpack(poly):return {tuple(map(int,k.split(','))):K(R(v[0]),R(v[1])) for k,v in poly.items()}
def serial(o):
    if isinstance(o,R):return str(o)
    if isinstance(o,dict):return {str(k):serial(v) for k,v in o.items()}
    if isinstance(o,list):return [serial(v) for v in o]
    return o

def reconstruct():
    N=9;X,Y=p.X,p.Y;ch=K(0,1);om=(-1+ch)/2;lam=(1+ch)/2
    ri=p.add(p.sc(X,K(R(1,2),-R(1,6))),p.sc(Y,K(R(1,2),R(1,6))))
    ei=p.add(p.sc(X,-ch/3),p.sc(Y,ch/3))
    f=p.add(X,p.sc(p.psin(ei,N),om.conj()),p.sc(p.pexp(ri,N),om))
    F=p.it(f,6,N)
    check('degree-nine primitive return: identity linear part',p.sl(F,1)==X)
    check('degree-nine primitive return: no quadratic part',not p.sl(F,2))
    check('degree-nine primitive return: cubic mu',p.sl(F,3)=={(2,1):K(-R(1,2),-R(2,3))})
    h=X;nf=p.sc(X,lam)
    for n in range(2,7):
        err=p.sl(p.sub(p.ccomp(f,h,6),p.ccomp(h,nf,6)),n)
        hn={};nn={}
        for (a,b),c in err.items():
            den=lam**(a-b)-lam
            if den:hn[a,b]=c/den
            else:nn[a,b]=c
        h=p.add(h,hn);nf=p.add(nf,nn)
        check(f'one-step homological identity through degree {n}',not p.cut(p.sub(p.ccomp(f,h,6),p.ccomp(h,nf,6)),n))
    J=p.it(nf,6,6)
    baseline=json.loads((BASE/'outputs/certificate.json').read_text())
    for label,obj,key in [('raw low jet',p.cut(F,6),'F6_primitive'),('same fixed h',h,'h_degree6'),('same fixed J',J,'J_normal_through6')]:
        check('exact equality with verified baseline: '+label,obj==unpack(baseline['jet'][key]))
    check('h is not extended or changed at degrees 7--9',max(map(sum,h))==6)
    check('all nonresonant J terms absent through degree six',set(p.sub(J,X))=={(2,1),(3,2),(0,5)})
    defect=p.sub(p.ccomp(p.cut(F,6),h,9),p.ccomp(h,J,9))
    check('finite conjugacy defect has no degree <=6 terms',not p.cut(defect,6))
    check('finite defect (0,7) coefficient retained',p.cget(defect,(0,7))==K(R(31,9720),-R(77,19440)))
    return f,F,h,J,defect,baseline

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--tail10',type=int,default=332000)
    ap.add_argument('--c7',type=int,default=100)
    ap.add_argument('--cder6',type=int,default=1000)
    args=ap.parse_args()
    f,F,h,J,defect,baseline=reconstruct()
    check('a=7/6 majorizes inverse coordinate row sums',R(7,6)**2>R(4,3))
    raw_sums={d:ms(p.sl(F,d)) for d in range(3,10)}
    B={3:R(1259,1000),4:R(173,100),5:R(469,500),6:R(248,125),7:R(2079,1000),8:R(577,500),9:R(1763,1000)}
    for d,v in B.items():check(f'raw vector degree {d} coefficient modulus ceiling',raw_sums[d]<v)
    S=scalar_series(9)
    check('S6 coefficients through 7 match verified baseline',S[:8]==list(map(R,baseline['P2A']['S0_to_S7'])))
    rw=R(1,16);raw_orbit=orbit_upper(rw)
    k10_calc=(raw_orbit[-1]-ep(S,rw))/rw**10;k10=R(args.tail10)
    check(f'analytic degree >=10 raw vector tail <{k10}',0<k10_calc<k10)
    M=[R(0),R(0),R(7,12),R(39,500),R(14,125),R(11,250),R(1,20)]
    H=M[:];H[1]=R(1)
    Pa=[R(0),R(1),R(0)]+[B[n] for n in range(3,7)]
    Ja=[R(0),R(1),R(0),B[3],R(0),R(1099,1000)]
    for m,v in [((2,0),R(1,6)),((1,1),R(1,3)),((0,2),R(1,12))]:
        c=p.cget(h,m);check(f'h2 exact modulus {m}',c.a*c.a+3*c.b*c.b==v*v)
    for n in range(3,7):check(f'fixed h degree {n} rational modulus ceiling',ms(p.sl(h,n))<M[n])
    check('J quintic modulus ceiling',ms(p.sl(J,5))<Ja[5])
    Rinv=R(1,10);sigma=R(9,100);L=R(8,7);kap=ep(dp(M),Rinv);M2=ep(dp(dp(M)),Rinv)
    check('same inverse derivative bound kappa<1/8',kap==R(358439,3000000)<R(1,8))
    check('same inverse target disk radius 9/100',sigma+ep(M,Rinv)<Rinv)
    check('same co-Lipschitz bound',1/(1-kap)<L)
    check('same relative coordinate bound 15/16..17/16',ep(M,Rinv)/Rinv<R(1,16))
    Aa=compose(Pa,H);Bb=compose(H,Ja);Bb += [R(0)]*(len(Aa)-len(Bb))
    Dmaj=[a+b if n>=7 else R(0) for n,(a,b) in enumerate(zip(Aa,Bb))]
    check('finite polynomial defect majorant unchanged',Dmaj==list(map(R,baseline['P2B']['finite_defect_majorant'])))
    profiles={}
    for name,rz,C7,CD in [('enlarged',R(1,20),R(args.c7),R(args.cder6)),('small',R(1,40),R(30),R(250))]:
        hw=ep(H,rz);b=hw/rz;jz=ep(Ja,rz);fhorbit=orbit_upper(hw)
        polyC=ep(Dmaj,rz)/rz**7;polyd=ep(dp(Dmaj),rz)/rz**6
        rawC=B[7]+B[8]*hw+B[9]*hw**2+k10*hw**3
        rawD=7*B[7]+8*B[8]*hw+9*B[9]*hw**2+10*k10*hw**3
        value=L*(rawC*b**7+polyC)
        dE=rawD*b**6*ep(dp(H),rz)+polyd
        dvalue=L*(dE+M2*C7*rz*ep(dp(Ja),rz))
        check(f'{name}: h evaluation inside raw radius',hw<rw)
        check(f'{name}: derivative tail radius ratio <=10/11',hw/rw<=R(10,11))
        check(f'{name}: F_W(h(z)) inside inverse target',fhorbit[-1]<sigma)
        check(f'{name}: J(z) inside injectivity disk',jz<Rinv)
        check(f'{name}: h(J(z)) inside inverse target',ep(H,jz)<sigma)
        check(f'{name}: normalized C7<{C7}',value<C7)
        check(f'{name}: normalized derivative C6<{CD}',dvalue<CD)
        # A corollary in the NORMALIZED amplitude, not the primitive observable.
        qmax=rz**2;u=B[3];A=Ja[5]+C7*qmax
        radial_error=(R(19,12)+2*(1+u*qmax)*A+qmax**2*A**2)*qmax
        check(f'{name}: normalized disk radial contraction margin <1/2',radial_error<R(1,2))
        check(f'{name}: normalized lower radial bound positive',1-R(3,2)*qmax>0)
        profiles[name]={'radius':rz,'C7_NF_vec':C7,'C6_NF_derivative':CD,
          'value_rational_upper':value,'derivative_rational_upper':dvalue,'H_eval':hw,'J_eval':jz,'b':b,
          'Fh_orbit_upper':fhorbit,'hJ_upper':ep(H,jz),'raw_remainder_coefficient_at_H':rawC,
          'raw_derivative_coefficient_at_H':rawD,'Cpoly_at_radius':polyC,'Cpoly_derivative_at_radius':polyd,
          'C_E_derivative':dE,'normalized_radial_margin':radial_error}
        print('DISPLAY',name,'C7=',float(value),'CD=',float(dvalue),'radial margin=',float(radial_error),flush=True)
    # Full verified P2-A v2 tube, not the smaller v1 evaluation sub-tube.
    tube=orbit_upper(R(1,25));seedq=R(19,250000)
    check('full P2-A tube raw image bound 47/1000',max(tube[:6])<R(47,1000)<R(1,20))
    check('full P2-A tube inverse fits enlarged NF disk',R(16,15)*max(tube[:6])<R(1,20))
    check('exact seed inside original full primitive base disk',seedq<R(1,625))
    check('exact seed admission ratio 400/19',R(1,625)/seedq==R(400,19))
    # Revalidate P2-A v2 algebra/majorant without changing its operative profile.
    dq=p.sub(p.mul(p.cut(F,6),p.cj(p.cut(F,6)),7),{(1,1):K(1)})
    rc={5:R(16931,10000),6:R(6671,5000),7:R(3567,1000)}
    for n,c in rc.items():check(f'P2-A v2 radial coefficient ceiling {n}',ms(p.sl(dq,n))<c)
    check('P2-A v2 complete degree-seven radial polynomial matches',dq==unpack(baseline['jet']['deltaQ_through7']))
    Br=conv(S[:8],S[:8],7);rr=R(1,20);radial_orbit=orbit_upper(rr)
    k8=(radial_orbit[-1]**2-ep(Br,rr))/rr**8
    check('P2-A v2 radial analytic K8<42355',k8<42355)
    check('P2-A v2 C6prim108 retained',rc[6]+rc[7]*rr+42355*rr**2<108)
    check('P2-A v2 exact full margin retained',rc[5]*rr+rc[6]*rr**2+rc[7]*rr**3+42355*rr**4==R(2825241,8000000)<R(1,2))
    report={'version':'P2-B v2','date':'2026-09-22','status':'NEW WORKING CERTIFICATE; NOT OWNER ADOPTED',
      'primitive_profile_unchanged':{'version':'P2-A v2','C6_prim_rad':R(108),'q_ctr':R(1,400),'q_in':R(1,625),'c':R(1,2)},
      'normalizer_convention':'fixed additive degree-six h; resonant h_n=0 in one-step homological equation; h7=h8=h9=0',
      'tail':{'retained_degree':9,'radius':rw,'K10':k10,'K10_rational_upper':k10_calc,'orbit_upper':raw_orbit,
        'S6_through9':S,'raw_vector_coefficient_ceilings':B,'raw_vector_modulus_sum_upper':raw_sums},
      'coordinate':{'M':M,'H':H,'P6major':Pa,'Jmajor':Ja,'Dpoly_major':Dmaj,'R':Rinv,'sigma':sigma,'kappa':kap,'L':L,'M2':M2},
      'profiles':profiles,'tube':{'q_base':R(1,625),'orbit_upper':tube,'inverse_radius_upper':R(16,15)*max(tube[:6]),'seed_q':seedq},
      'jets':{'one_step_through9':pack(f),'F6_through9':pack(F),'h_degree6':pack(h),'J_through6':pack(J),'Dpoly_through9':pack(defect)},
      'P2A_recheck':{'radial_orbit_upper':radial_orbit,'K8_rational_upper':k8},
      'checks':checks,'all_checks_pass':True,
      'limits':['No RECOG manifold-entry theorem','No full-map memory comparison theorem','No GAP-LOCK angular-domain certificate',
                'No historical Phi1 byte identity','No optimum claim','No external review of this new v2 yet']}
    (ROOT/'outputs/certificate.json').write_text(json.dumps(serial(report),indent=2)+'\n')
    print('DISPLAY K10=',float(k10_calc),'full normalized tube radius=',float(report['tube']['inverse_radius_upper']))
    print('CERTIFICATE PASS',len(checks),'checks',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        print('CERTIFICATE FAIL',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
