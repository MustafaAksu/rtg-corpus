from pathlib import Path
from fractions import Fraction as R
import importlib.util,json,time
ROOT=Path(__file__).resolve().parents[1]
base=ROOT/'inputs/baseline/DYAD_RETURN_ENCLOSURE_P2A_v2_P2B_v1'
spec=importlib.util.spec_from_file_location('baseline_calc',base/'scripts/certify.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p,K=b.p,b.K;X,Y=p.X,p.Y
w=K(0,1);om=(-1+w)/2
ri=p.add(p.sc(X,K(R(1,2),-R(1,6))),p.sc(Y,K(R(1,2),R(1,6))))
ei=p.add(p.sc(X,-w/3),p.sc(Y,w/3))
t=time.monotonic();N=9
f=p.add(X,p.sc(p.psin(ei,N),om.conj()),p.sc(p.pexp(ri,N),om))
F=p.it(f,6,N)
print('degree9 composition secs',time.monotonic()-t,flush=True)
F6,dq,h,J=b.jet_data();assert p.cut(F,6)==F6
fs={n:b.modulus_sum(p.sl(F,n)) for n in range(3,N+1)}
print('raw vector sums', {n:float(x) for n,x in fs.items()},flush=True)
M=[R(0),R(0),R(7,12),R(39,500),R(14,125),R(11,250),R(1,20)];H=M[:];H[1]=R(1)
P=[R(0),R(1),R(0),R(1259,1000),R(173,100),R(469,500),R(248,125)]
Ja=[R(0),R(1),R(0),R(1259,1000),R(0),R(1099,1000)]
D1=b.compose(P,H);D2=b.compose(H,Ja);D2 += [R(0)]*(len(D1)-len(D2));D=[a+c if n>=7 else R(0) for n,(a,c) in enumerate(zip(D1,D2))]
S,_=b.majorant_series(N)
for rz in [R(1,40),R(1,20)]:
 x=b.eval_poly(H,rz);bh=x/rz
 print('RZ',str(rz),'H',float(x),'Fh enclosure',float(b.orbit_upper(x)[-1]),'JH',float(b.eval_poly(H,b.eval_poly(Ja,rz))),flush=True)
 polyC=b.eval_poly(D,rz)/rz**7;dpoly=b.eval_poly(b.derivative(D),rz)/rz**6
 for rw in [R(1,20),R(1,18),R(1,17),R(3,50),R(1,16),R(1,15)]:
  up=b.orbit_upper(rw)[-1];k10=(up-b.eval_poly(S,rw))/rw**10
  raw7=sum(fs[n]*x**(n-7) for n in (7,8,9))+k10*x**3
  c7=R(8,7)*(raw7*bh**7+polyC)
  prime=sum(n*fs[n]*x**(n-7) for n in (7,8,9))+10*k10*x**3
  ep=prime*bh**6*b.eval_poly(b.derivative(H),rz)+dpoly
  dp=R(8,7)*(ep+b.eval_poly(b.derivative(b.derivative(M)),R(1,10))*c7*rz*b.eval_poly(b.derivative(Ja),rz))
  print('rw',str(rw),'K10',float(k10),'C7',float(c7),'dC6',float(dp),'alpha',float(x/rw),'pass',x/rw<=R(10,11),flush=True)
(rootout:=ROOT/'outputs/exploration.json').write_text(json.dumps({'f9':b.pack(f),'F9':b.pack(F),'modulus_upper':b.strings(fs),'S':b.strings(S)},indent=2)+'\n')
print('TOTAL SECS',time.monotonic()-t,flush=True)
