#!/usr/bin/env python3
"""Run reproducible positive tests and required failing controls; exit gated."""
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parents[1]
JOBS=[
 ('certify',[sys.executable,str(ROOT/'scripts/certify_sharpened.py')],0),
 ('independent',[sys.executable,str(ROOT/'scripts/verify_independently.py')],0),
 ('numerical_sanity',[sys.executable,str(ROOT/'scripts/numerical_sanity.py')],0),
 ('negative_tail10',[sys.executable,str(ROOT/'scripts/certify_sharpened.py'),'--tail10','300000'],1),
 ('negative_C7',[sys.executable,str(ROOT/'scripts/certify_sharpened.py'),'--c7','10'],1),
 ('negative_derivative',[sys.executable,str(ROOT/'scripts/certify_sharpened.py'),'--cder6','100'],1),
 ('negative_raw_lattice',[sys.executable,str(ROOT/'scripts/verify_independently.py'),'--tamper-lattice'],1),
]
status=[]
for name,cmd,want in JOBS:
    cp=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    (ROOT/'logs'/f'{name}.log').write_text(cp.stdout)
    ok=cp.returncode==want
    status.append({'name':name,'expected_exit':want,'actual_exit':cp.returncode,'pass':ok})
    print(('PASS' if ok else 'FAIL'),name,cp.returncode,flush=True)
(ROOT/'outputs/run_status.json').write_text(json.dumps(status,indent=2)+'\n')
if not all(row['pass'] for row in status):sys.exit(1)
