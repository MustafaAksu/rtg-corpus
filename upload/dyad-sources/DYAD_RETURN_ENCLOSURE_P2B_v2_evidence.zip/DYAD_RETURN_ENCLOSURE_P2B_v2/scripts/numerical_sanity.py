#!/usr/bin/env python3
"""90-digit exact-map sanity checks; not used in any uniform certificate."""
from pathlib import Path
from fractions import Fraction
import json,sys
import mpmath as mp
mp.mp.dps=90
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'outputs/certificate.json').read_text())
def rat(s):
    q=Fraction(s);return mp.mpf(q.numerator)/q.denominator
def load(poly):return {tuple(map(int,k.split(','))):rat(c[0])+mp.j*mp.sqrt(3)*rat(c[1]) for k,c in poly.items()}
h=load(d['jets']['h_degree6']);J=load(d['jets']['J_through6'])
def evaluate(poly,z):return sum((c*z**a*mp.conj(z)**b for (a,b),c in poly.items()),mp.mpc(0))
def jac(poly,z):
    p=sum((c*a*z**(a-1)*mp.conj(z)**b for (a,b),c in poly.items() if a),mp.mpc(0))
    q=sum((c*b*z**a*mp.conj(z)**(b-1) for (a,b),c in poly.items() if b),mp.mpc(0))
    x=p+q;y=mp.j*(p-q)
    return mp.matrix([[mp.re(x),mp.re(y)],[mp.im(x),mp.im(y)]])
L=mp.matrix([[1,-mp.mpf(1)/2],[0,mp.sqrt(3)/2]]);Li=L**-1

def full_return(w):
    v=Li*mp.matrix([mp.re(w),mp.im(w)]);D=mp.eye(2)
    for _ in range(6):
        rho,eta=v[0],v[1];s=mp.sin(eta);er=mp.exp(rho)
        DT=mp.matrix([[1,-mp.cos(eta)],[er,1-mp.cos(eta)]])
        D=DT*D;v=mp.matrix([rho-s,eta+er-1-s])
    u=L*v;return mp.mpc(u[0],u[1]),L*D*Li

def inverse(w):
    z=w
    for _ in range(160):
        zn=w-(evaluate(h,z)-z)
        if abs(zn-z)<mp.mpf('1e-85'):return zn
        z=zn
    raise RuntimeError('sanity inverse iteration failed')
def norm2(A):
    C=A.T*A;tr=C[0,0]+C[1,1];disc=(C[0,0]-C[1,1])**2+4*C[0,1]**2
    return mp.sqrt((tr+mp.sqrt(disc))/2)
rows=[]
for rad in ['1/100','1/40','1/20']:
    r=rat(rad)
    for k in range(12):
        theta=2*mp.pi*k/12;z=r*mp.exp(mp.j*theta)
        w=evaluate(h,z);fw,Dfw=full_return(w);g=inverse(fw)
        Dg=(jac(h,g)**-1)*Dfw*jac(h,z)
        v=abs(g-evaluate(J,z))/r**7;dv=norm2(Dg-jac(J,z))/r**6
        if v>100 or dv>1000:raise AssertionError('published envelope violated by numerical probe')
        q=abs(z)**2;qp=abs(g)**2
        if not q-mp.mpf('1.5')*q*q<=qp<=q-mp.mpf('0.5')*q*q:raise AssertionError('normalized radial check')
        rows.append({'radius':rad,'phase_index':k,'value_scaled':mp.nstr(v,35),'derivative_scaled':mp.nstr(dv,35)})
report={'scope':'NUMERICAL sanity only, not proof; exact map evaluated at 90 dps','points':len(rows),'rows':rows,
        'max_scaled_value':max(float(r['value_scaled']) for r in rows),
        'max_scaled_derivative':max(float(r['derivative_scaled']) for r in rows)}
(ROOT/'outputs/numerical_sanity.json').write_text(json.dumps(report,indent=2)+'\n')
print('NUMERICAL SANITY PASS',len(rows),'points; max value ratio',report['max_scaled_value'],'max derivative ratio',report['max_scaled_derivative'])
