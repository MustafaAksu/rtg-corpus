#!/usr/bin/env python3
"""Second arithmetic implementation of P2-B v2 (not an external peer review).

Does not import the producer or its polynomial kernel. Rebuilds the primitive
map in real coordinates through degree nine with the supplied reviewer Q/P
backend; solves h independently; verifies all published rational constants.
Uses independent exponential recurrences and separate analytic exp/sinh tails.
"""
from __future__ import annotations
import argparse,importlib.util,json,sys
from fractions import Fraction as R
from pathlib import Path
from math import factorial
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'inputs/baseline/DYAD_RETURN_ENCLOSURE_P2A_v2_P2B_v1'
spec=importlib.util.spec_from_file_location('reviewer_QP',BASE/'inputs/dyad_return_qchi_exact.py')
bk=importlib.util.module_from_spec(spec);spec.loader.exec_module(bk)
Q,P=bk.Q,bk.P
checks=[]
def check(label,condition):
    ok=bool(condition);checks.append({'label':label,'pass':ok});print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok:raise AssertionError(label)
def qp(a,n):
    r=Q(1)
    for _ in range(n):r=r*a
    return r
def decode(d,N):return P({tuple(map(int,k.split(','))):Q(R(v[0]),R(v[1])) for k,v in d.items()},N)
def reconstruct():
    N=9;X=P({(1,0):Q(1)},N);Y=P({(0,1):Q(1)},N)
    def step(r,e):
        a=P({},N);b=P({},N)
        for n in range(1,N+1):
            b=b+r.pw(n).scale(Q(R(1,factorial(n))))
            if n%2:a=a+e.pw(n).scale(Q(R((-1)**((n-1)//2),factorial(n))))
        return r-a,e+b-a
    r,e=X,Y
    r1,e1=step(r,e)
    for _ in range(6):r,e=step(r,e)
    om=Q(-R(1,2),R(1,2));lam=Q(R(1,2),R(1,2))
    ri=X.scale(Q(R(1,2),-R(1,6)))+Y.scale(Q(R(1,2),R(1,6)))
    ei=X.scale(Q(0,-R(1,3)))+Y.scale(Q(0,R(1,3)))
    f=r1.compose(ri,ei)+e1.compose(ri,ei).scale(om)
    F=r.compose(ri,ei)+e.compose(ri,ei).scale(om)
    check('real recurrence coefficients rational before frame change',all(c.b==0 for pp in (r,e) for c in pp.d.values()))
    h=P(X.d,6);nf=P(X.scale(lam).d,6);f6=P({k:v for k,v in f.d.items() if sum(k)<=6},6)
    for n in range(2,7):
        err=(f6.compose(h,h.conj())-h.compose(nf,nf.conj())).deg(n)
        hh={};nn={}
        for (a,b),c in err.d.items():
            den=qp(lam,(a-b)%6)-lam
            if den.iszero():nn[a,b]=c
            else:hh[a,b]=c/den
        h=h+P(hh,6);nf=nf+P(nn,6)
    J=P(X.d,6)
    for _ in range(6):J=nf.compose(J,J.conj())
    return f,F,h,J

def sqrt_bisect(q,scale=10**12):
    lo=0;hi=1
    if q==0:return R(0)
    while R(hi,scale)**2<q:hi*=2
    while hi-lo>1:
        mid=(hi+lo)//2
        if R(mid,scale)**2>=q:hi=mid
        else:lo=mid
    return R(hi,scale)
def ms(poly):return sum((sqrt_bisect(c.a*c.a+3*c.b*c.b) for c in poly.d.values()),R(0))
def exp_coeff(a,N):
    e=[R(1)]+[R(0)]*N
    for n in range(1,N+1):e[n]=sum((k*a[k]*e[n-k] for k in range(1,n+1)),R(0))/n
    return e
def scalar_series(N):
    s=[R(0)]*(N+1);s[1]=R(1);a=R(7,6)
    for _ in range(6):
        x=[a*v for v in s];ex=exp_coeff(x,N);em=exp_coeff([-v for v in x],N)
        s=[R(0)]+[s[n]+ex[n]+(ex[n]-em[n])/2-2*x[n] for n in range(1,N+1)]
    return s
def psi_alt(u):
    x=R(7,6)*u
    if not 0<=x<1:raise ValueError('analytic exp/sinh tail domain')
    er=sum((x**n/factorial(n) for n in range(2,37)),R(0))+x**37/factorial(37)/(1-x/38)
    sh=sum((x**n/factorial(n) for n in range(3,37,2)),R(0))+x**37/factorial(37)/(1-x*x/(38*39))
    return u+er+sh

def sparse(a):return {n:R(c) for n,c in enumerate(a) if R(c)}
def mul(a,b):
    c={}
    for n,u in a.items():
        for m,v in b.items():c[n+m]=c.get(n+m,R(0))+u*v
    return {n:v for n,v in c.items() if v}
def comp(a,b):
    r={}
    for n in range(max(a),-1,-1):
        r=mul(r,b)
        if a.get(n):r[0]=r.get(0,R(0))+a[n]
    return r
def ep(a,s):return sum((v*s**n for n,v in a.items()),R(0))
def dp(a):return {n-1:n*v for n,v in a.items() if n}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--tamper-lattice',action='store_true');args=ap.parse_args()
    d=json.loads((ROOT/'outputs/certificate.json').read_text());jets=d['jets'];T=d['tail'];C=d['coordinate']
    f,F,h,J=reconstruct()
    for name,obj,key in [('one-step through nine',f,'one_step_through9'),('six-step through nine',F,'F6_through9'),('degree-six h',h,'h_degree6'),('normalized J',J,'J_through6')]:
        check('independent complete coefficient equality: '+name,obj.d==decode(jets[key],obj.N).d)
    if args.tamper_lattice:J.d[(0,5)]=F.get((0,5))
    F6=P({k:v for k,v in F.d.items() if sum(k)<=6},9);h9=P(h.d,9);J9=P(J.d,9)
    defect=F6.compose(h9,h9.conj())-h9.compose(J9,J9.conj())
    check('exact conjugacy cancellation at every degree <=6',all(not defect.deg(n).d for n in range(7)))
    check('finite defect through nine matches',defect.d==decode(jets['Dpoly_through9'],9).d)
    check('finite defect (0,7) independently reproduced',defect.get((0,7))==Q(R(31,9720),-R(77,19440)))
    b={int(n):R(v) for n,v in T['raw_vector_coefficient_ceilings'].items()}
    for n,c in b.items():check(f'degree {n} modulus bound by independent rational bisection',ms(F.deg(n))<c)
    S=scalar_series(9)
    check('degree-nine scalar majorant by exponential recurrence',S==list(map(R,T['S6_through9'])))
    orbitsets={'raw':T['orbit_upper'],'tube':d['tube']['orbit_upper'],'radial':d['P2A_recheck']['radial_orbit_upper']}
    orbitsets.update({name:pp['Fh_orbit_upper'] for name,pp in d['profiles'].items()})
    for name,arr in orbitsets.items():
        vals=list(map(R,arr))
        for j in range(6):check(f'separate exp/sinh analytic tails: {name}/{j+1}',psi_alt(vals[j])<=vals[j+1])
    rw=R(T['radius']);K10=R(T['K10']);rawU=list(map(R,T['orbit_upper']))
    calc=(rawU[-1]-ep(sparse(S),rw))/rw**10
    check('analytic raw tail constant recalculated',calc==R(T['K10_rational_upper'])<K10)
    M=sparse(C['M']);H=sparse(C['H']);Pa=sparse(C['P6major']);Ja=sparse(C['Jmajor'])
    for n in range(3,7):check(f'coordinate modulus majorant degree {n}',ms(h.deg(n))<M[n])
    check('exact h2 moduli, no floating test',all(c.a*c.a+3*c.b*c.b==v*v for c,v in [(h.get((2,0)),R(1,6)),(h.get((1,1)),R(1,3)),(h.get((0,2)),R(1,12))]))
    check('J majorant independently valid',ms(J.deg(3))<Ja[3] and ms(J.deg(5))<Ja[5])
    Rinv=R(C['R']);sigma=R(C['sigma']);L=R(C['L']);kap=ep(dp(M),Rinv);M2=ep(dp(dp(M)),Rinv)
    check('inverse map existence hypotheses',kap<R(1,8) and sigma+ep(M,Rinv)<Rinv)
    check('inverse Lipschitz and observable bridge',1/(1-kap)<L and ep(M,Rinv)/Rinv<R(1,16))
    D1,D2=comp(Pa,H),comp(H,Ja)
    Dmaj={n:D1.get(n,R(0))+D2.get(n,R(0)) for n in set(D1)|set(D2) if n>=7}
    check('Dpoly positive tail majorant independently reconstructed',Dmaj==sparse(C['Dpoly_major']))
    for name,pp in d['profiles'].items():
        rz=R(pp['radius']);C7=R(pp['C7_NF_vec']);CD=R(pp['C6_NF_derivative']);x=ep(H,rz);bh=x/rz
        poly=ep(Dmaj,rz)/rz**7;polyd=ep(dp(Dmaj),rz)/rz**6
        v=b[7]+b[8]*x+b[9]*x*x+K10*x**3
        dv=7*b[7]+8*b[8]*x+9*b[9]*x*x+10*K10*x**3
        value=L*(v*bh**7+poly)
        derivative=L*(dv*bh**6*ep(dp(H),rz)+polyd+M2*C7*rz*ep(dp(Ja),rz))
        check(f'{name}: value constant reproduced exactly',value==R(pp['value_rational_upper'])<C7)
        check(f'{name}: derivative constant reproduced exactly',derivative==R(pp['derivative_rational_upper'])<CD)
        check(f'{name}: correct high-tail derivative separation',x/rw<=R(10,11))
        check(f'{name}: composition domains',x<rw and ep(Ja,rz)<Rinv and ep(H,ep(Ja,rz))<sigma and R(pp['Fh_orbit_upper'][-1])<sigma)
        q=rz*rz;aa=Ja[5]+C7*q
        margin=q*(R(19,12)+2*(1+Ja[3]*q)*aa+aa**2*q*q)
        check(f'{name}: normalized disk invariance with radial bounds',margin==R(pp['normalized_radial_margin'])<R(1,2) and 1-R(3,2)*q>0)
    maxt=max(map(R,d['tube']['orbit_upper'][:6]))
    check('FULL P2-A primitive tube lies in enlarged normalized disk',R(16,15)*maxt<R(1,20))
    check('exact seed remains admitted, margin 400/19',R(d['tube']['q_base'])/R(d['tube']['seed_q'])==R(400,19))
    dq=P(F6.d,7)*P(F6.d,7).conj()-P({(1,1):Q(1)},7)
    for n,c in {5:R(16931,10000),6:R(6671,5000),7:R(3567,1000)}.items():check(f'P2-A radial ceiling independently retained degree {n}',ms(dq.deg(n))<c)
    rr=R(1,20);SS=S[:8];BB=mul(sparse(SS),sparse(SS));Blow={n:c for n,c in BB.items() if n<=7}
    k8=(R(d['P2A_recheck']['radial_orbit_upper'][-1])**2-ep(Blow,rr))/rr**8
    check('P2-A v2 K8 independently retained',k8==R(d['P2A_recheck']['K8_rational_upper'])<42355)
    check('P2-A v2 full exact contraction margin retained',R(16931,10000)*rr+R(6671,5000)*rr**2+R(3567,1000)*rr**3+42355*rr**4==R(2825241,8000000)<R(1,2))
    out={'all_checks_pass':True,'checks':checks,'scope':'separate exact-arithmetic implementation of same proof, not external peer review','count':len(checks)}
    (ROOT/'outputs/independent_validation.json').write_text(json.dumps(out,indent=2)+'\n')
    print('INDEPENDENT VALIDATOR PASS',len(checks),'checks',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        print('INDEPENDENT VALIDATOR FAIL',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
