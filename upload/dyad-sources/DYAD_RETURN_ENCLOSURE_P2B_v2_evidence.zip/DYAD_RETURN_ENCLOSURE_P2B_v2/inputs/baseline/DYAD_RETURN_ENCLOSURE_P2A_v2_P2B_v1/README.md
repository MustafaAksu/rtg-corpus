# DYAD RETURN-ENCLOSURE — P2-A v2 / P2-B v1

**Date:** 2026-09-21. **Status:** Working proofs and exact-arithmetic certificates, not an adopted owner DSN or RID release.

## Results

**P2-A v2, primitive coordinates:**
- `C6_prim_rad = 108`, `q_ctr = 1/400`, `q_in = 1/625`, contraction `c = 1/2`.
- The nonzero exact radial degree-7 jet is retained. Only radial degree >=8 is majorized; the tail coefficient is bounded by 42355 on `|W| <= 1/20`.
- All six phase images of the base lie in `|W| < 47/1000`.
- The exact NUMGEN seed `(1/100,1/250)` is in the base.

**P2-B v1, the direct-polynomial normalizer `W=h(z,conj(z))`:**
- h is injective on `|z| <= 1/10`; its image contains `|W| <= 9/100`.
- `||Dh-I|| < 1/8`, `||Dh^{-1}|| < 8/7`, `||Dh^{-1}-I|| < 1/7` on the stated domains.
- `(15/16)|z| <= |h(z)| <= (17/16)|z|` on the h domain.
- On `|z| <= 1/40`, normalized vector remainder `<=8000|z|^7` and first real-derivative remainder `<=60000|z|^6`.
- These bounds include the nonzero finite polynomial conjugacy defect, not only transport of the primitive tail.
- A smaller primitive base `Q <= 1/2500` produces a conjugate invariant tube lying entirely inside the normalized evaluation domain and containing the transformed exact seed.

## Read first

1. `notes/REVIEW_DISPOSITION.md`: correction of the unsupported 64/256/1024 delivery record, disposition of the review, and scope.
2. `notes/P2A_V2_PRIMITIVE_PROOF.md`: full primitive proof and exact constant definitions.
3. `notes/P2B_V1_COORDINATE_AND_REMAINDER_PROOF.md`: real inverse-domain proof, finite conjugacy defect, normalized value and first-derivative bounds.

The previous documented 1560/3600/10000 certificate is preserved in `inputs/` and its rerun logs are included. The original archive was not overwritten. The withdrawn earlier 64-set is **not** declared numerically false; it lacked its delivered proof, and the review's 375 power-count argument is not a disproof.

## Reproduce

```bash
python -m pip install -r requirements.txt
python scripts/run_all.py
```

The main producer reconstructs the map and normalizer using the preserved P1 exact polynomial kernel; it does not infer a jet from a fitted table. The validator imports neither the producer nor that kernel. It uses the supplied reviewer arithmetic backend, real-coordinate construction, a separate exponential-series recurrence, separate exponential/sinh upper bounds, and sparse Horner composition.

Expected: 61 producer checks, 63 separate-validator checks, and three correctly rejected negative controls. The baseline reruns contribute separate historical checks (24 + 19). Counts are execution coverage, not independent theorem counts.

Optional, noncertifying finite diagnostic:

```bash
python scripts/numerical_sanity.py
```

It directly evaluates the exact map and inverse at 80 decimal digits on 12 states, checking both value and first-derivative remainder estimates. It is not used to prove uniformity.

## Files and provenance

- `outputs/certificate.json`: exact coefficients, rational majorants, upper endpoints, constants and check ledger. All decimal log numbers are display-only.
- `outputs/independent_validation.json`: second implementation's checks.
- `outputs/run_status.json`: positive/negative exit-code gates.
- `inputs/DYAD_P2A_PRIMITIVE_CONTRACTION_REVIEW.md`: unchanged reviewer contribution.
- `inputs/dyad_return_qchi_exact.py`: unchanged reviewer arithmetic classes, not a test driver.
- `inputs/p1_exact_kernel_and_audit.py`: unchanged earlier P1 kernel/audit, used as a library by the new producer.
- `inputs/coordinate_h_deg6_reconstructed.json`: earlier independently reconstructed polynomial for coefficient-by-coefficient comparison; not the old historical numerical Phi1 output.
- `source_integrity.json`: byte-for-byte check of the 43 files present before this work.
- `package_manifest.json`: SHA-256 list for this package, excluding itself and cache files.

## Not claimed

No owner adoption, DSN/RID modification, optimized radius, extra GAP-LOCK angular-domain proof, saddle-manifold entry certificate, full-map retained-memory theorem, complete R11 observable/backbone reconciliation, arbitrary higher-derivative estimates, or historical Phi1 byte identity. Claude supplied the review and the P2-A sharpening idea; no Claude review of these newly derived P2-B bounds is claimed.
