# Review + contribution: P2-A primitive contraction / six-phase tube
**Reviewer:** Claude · **Date:** 21 Sep 2026 · **Inputs:** P2-A message (two blocks) + `PRIMITIVE_CONTRACTION_PROOF.md`
**Status:** independent verification + criticism + a sharpened working result. Not a DSN amendment; no RID; nothing promoted.

## A. What I reproduced (exact / high-precision, my own code)

| Claim (documented 1560-version) | Check | Result |
|---|---|---|
| Majorant $B_2..B_5 = 1,\ \tfrac{49}{6},\ \tfrac{1372}{27},\ \tfrac{17385641}{62208}$ | exact rational recursion, $a=7/6$ | **match** (also $B_6=\tfrac{24025892219}{16796160}$, $B_7\approx6970.7$, $B_8\approx32750$) |
| $(S_6(r)^2-\sum_{n\le5}B_nr^n)/r^6<1560$ at $r=1/60$ | 60-digit eval of the nonnegative series | $1556.4634575\ldots$ **< 1560** |
| $S_j(1/100)<21/2000$, $j\le5$ | same | $\max S_5=0.0103526$ **< 0.0105** |
| $C_5=\tfrac78+\tfrac{53\sqrt3}{72}<\tfrac{43}{20}$ and it bounds $\|P_5\|/Q^{5/2}$ | $459^2-3\cdot265^2=6$; numeric phase-max | valid; **true max is 1.639** (bound has 31% slack) |
| $\tfrac{43}{20}\tfrac1{60}+\tfrac{1560}{3600}=\tfrac{563}{1200}<\tfrac12$; fallback $\tfrac{10289}{20736}<\tfrac12$ | exact | both hold (fallback margin is thin: 0.4962) |
| Majorization argument ($\|c\|=1/\sqrt3$ per inverse-row entry, $2/\sqrt3<7/6$; $\sin\preceq\sinh$, $e^x-1-x$) | read | sound; uniform in $\theta$ |
| Recovered solver convention $=$ owner convention | $6\bar\lambda n_{21}=\mu$, $6\bar\lambda B_6=a_{05}$, $3\Re n_{32}+3\sqrt3\Im n_{32}=\tfrac1{54}$ | **all exact** — matches DYAD-ALG-BRIDGE-LEMMA $\mu_p=p\bar\lambda\nu_3^{(1,p)}$; identification is by the ledger lemma, not by filename |

Bonus consistency check from my exact degree-6 radial jet: the $Q^3$ coefficient of $\Delta Q$ (the $(3,3)$ term) is **exactly $47/54$** — the certified asymptotic backbone coefficient (Dyadic §6.5). The $(6,0)$ term is $\overline{c_{05}^{\rm raw}}$. The primitive radial calculation and the owner ledger agree where they overlap.

## B. Criticisms

**B1. Two inconsistent constant sets, one undocumented.** The message's first block asserts $C_6=64,\ q_{\rm ctr}=1/256,\ q_{\rm in}=1/1024$; the second block and the attached proof assert $C_{6,\rm rad}=1560,\ q_{\rm ctr}=1/3600,\ q_{\rm in}=1/10000$. Only the 1560-version is in the attachment. Worse, the 64-version as summarized does not close on its face: a vector tail $6000|W|^7$ on $|W|\le1/16$ contributes $\le6000\cdot\tfrac1{16}\,|W|^6=375\,|W|^6$ to the radial remainder, which cannot yield "$53.3<64$." Either the full derivation differs from the summary or the number is wrong. **Do not cite both. The documented result is the 1560/3600/10000 one; the 64-version should be withdrawn or fully documented before it is used anywhere.**

**B2. The majorant is ~two orders of magnitude loose, and this is what makes the radius tiny.** Compare majorant vs. truth, phase-uniform on $Q=1$:
- degree 4: $B_4=50.8$ vs. exact $-1$;
- degree 5: $B_5=279.5$ vs. $|P_5|\le1.64$ (source used $2.15$);
- degree 8 tail: $K_8\approx4\times10^4$ vs. observed $|R_{\ge8}|/t^8\sim10^2$–$10^3$.
The scalar majorant $\Psi^{\circ6}$ cannot see the six-step cancellations that make the raw six-step return start at degree 3 with $F_2=0$. Using it from degree 6 throws away everything the exact P1 jet already knows. **Since the P0–P1 package already has the exact six-step jet, the remainder should be majorized only beyond the highest exact degree available.** That is the whole gain below.

**B3. Terminology to tighten.** "$C_6$" in the message denotes a *radial* degree-$\ge6$ constant; RECOG's $C_7$ is a *vector* degree-$\ge7$ constant in *normalized* coordinates. The proof says this correctly; the message's boxed "$C_6$" would read as the same object to a downstream consumer. Suggest always writing $C_{6,\rm rad}^{\rm prim}$.

**B4. Certificate-grade discipline is right but thin at one point.** The self-contained fallback margin $10289/20736=0.49619$ is $0.0038$ below $\tfrac12$. It holds; it should be noted as tight so nobody "rounds" $a$ or $r$ later.

**B5. Scope statements are correct and should be preserved verbatim** — primitive $Q$ only; exact rational seed only; GAP-LOCK angular inequalities not discharged; $\Phi_1$ byte-identity not recovered (convention identity now established via the bridge lemma instead, which is the stronger statement).

## C. Contribution 1 — sharpened primitive contraction (working result, same proof scheme)

Use the exact six-step jet through degree 6 (available from P1), so that $\Delta Q_5=P_5$, $\Delta Q_6$, $\Delta Q_7$ are **exact signed polynomials**, and majorize only $\sum_{n\ge8}B_nt^n\le t^8K_8(r)$, $K_8(r)=(S_6(r)^2-\sum_{n\le7}B_nr^n)/r^8$.

Rigorous phase-uniform bounds on $Q=1$ from coefficient-modulus sums (since $|W|=|\bar W|=1$):
$$|P_5|\le1.6931\,Q^{5/2},\qquad |\Delta Q_6|\le1.3342\,Q^{3},\qquad |\Delta Q_7|\le3.5670\,Q^{7/2}$$
(exact $\Delta Q_7$ coefficients: $(2,5)\!:\!-\tfrac{317}{480}+\tfrac{19}{160}i\sqrt3$, $(3,4)\!:\!\tfrac{26}{27}+\tfrac{337}{1296}i\sqrt3$, $(1,6)\!:\!-\tfrac{7}{864}+\tfrac{119}{12960}i\sqrt3$, $(0,7)\!:\!-\tfrac1{120}+\tfrac{13}{3240}i\sqrt3$, + conjugates.)

Contraction with $c=\tfrac12$ requires $1.6931\,t+1.3342\,t^2+3.5670\,t^3+K_8(r)\,t^4\le\tfrac12$ for $t=\sqrt Q\le r$:

| $r$ | $q=r^2$ | $K_8(r)$ | LHS | $c=\tfrac12$ |
|---|---|---|---|---|
| $1/60$ | $1/3600$ | $35442$ | $0.031$ | ✓ (P2-A's domain) |
| $1/25$ | $1/625$ | $40021$ | $0.173$ | ✓ |
| **$1/20$** | **$1/400$** | $42354$ | **$0.353$** | ✓ |
| $1/19$ | $1/361$ | $43012$ | $0.423$ | ✓ (edge) |
| $1/18$ | $1/324$ | $43767$ | $0.516$ | ✗ |

$$\boxed{\ q_{\rm ctr}=\tfrac1{400},\quad c=\tfrac12,\quad C_{6,\rm rad}^{\rm eff}=1.334+3.567\,r+K_8(r)\,r^2\approx107\ \ (r=\tfrac1{20})\ }$$
— **~9–10× the domain of $1/3600$ and ~13× smaller $C_6$**, by the same majorant proof with the exact low degrees inserted. Tube: $q_{\rm in}=1/625$ gives $S_5(\sqrt{q_{\rm in}})=0.0463<\tfrac1{20}$, so $U=\{0<Q\le1/625\}$ is admissible and the seed ($Q=19/250000$) is inside with 12× margin.

*What to do to make this certificate-grade in the package's own discipline:* (i) replace my float coefficient-modulus sums by rational ceilings of $\sqrt{a^2+3b^2}$ (or, cheaper, use $|a|+|b|\sqrt3$ with $\sqrt3<\tfrac{459}{265}$); (ii) evaluate $S_6(r)$ with the package's outward-rounded rational scheme at $r=1/20$; (iii) keep $B_7$ in the subtracted polynomial (as I did). Nothing else changes. My scripts (`dyad_return_qchi_exact.py` backend + the driver in this note's log) do the exact jet in 0.1 s.

*Diminishing returns beyond this:* the residual slack is now entirely $K_8$. Going to exact degree 9 (the engine handles it in seconds) and majorizing from degree 10 should roughly double the radius again; beyond that, an honest gain needs a majorant that respects $F_2=0$ (e.g. majorize the six-step composition symbolically rather than the one-step scalar).

## D. Contribution 2 — the route for P2-B (quantitative $h^{-1}$ domain), same technique

The normalizer $h(z)=z+\sum_{n=2}^6h_n$ is an explicit polynomial. Let $M(s)=\sum_{n=2}^6\big(\sum_{a+b=n}|h_{ab}|\big)s^n$ be its scalar majorant (rational ceilings). Then:
- **Injectivity/inverse domain:** the scalar equation $\sigma=s-M(s)$ has a unique nonnegative-coefficient inverse series $s=\phi(\sigma)$ (Lagrange inversion of a majorant) converging for $\sigma<\sigma^*=\max_s(s-M(s))$, attained where $M'(s)=1$. Standard majorant inversion then gives: on $|z|<s^*$, $h$ is injective and $|h^{-1}(w)|\le\phi(|w|)$ for $|w|<\sigma^*$. Both $s^*,\sigma^*$ are explicit algebraic numbers from a degree-5 equation — computable exactly.
- **Derivative remainder:** $\|Dh-I\|\le M'(|z|)$ and $\|Dh^{-1}-I\|\le M'(\phi(|w|))/(1-M'(\phi(|w|)))$ on the same disk.
- **Normalized $C_7$:** with the raw vector remainder bounded by the same $\Psi^{\circ6}$ device (majorize $F_W-\sum_{k\le6}F_k$ from degree 7 — this is the *vector* tail, exactly what RECOG asked for), transport through $h$ on the inverse-domain disk: $|\widehat F-\mathcal J_{\le6}|\le C_7|z|^7$ with $C_7$ a product of the raw tail constant and the Lipschitz constants above.

This closes the three "OPEN" rows of the table (inverse domain, derivative bounds, normalized $C_7$) with the same exact-rational majorant discipline already built, and no new analytic idea.

## E. Bottom line
The documented P2-A result ($1560,\ 1/3600,\ 1/10000$) is **correct and reproduced**; the tube/seed argument is sound; the solver convention is now pinned to the owner ledger by an exact identity. The undocumented $64/256/1024$ block must be withdrawn or proved. The radius is far from optimal only because the majorant is applied too early; inserting the exact degrees the programme already has gives $q_{\rm ctr}=1/400$ at no new risk, and the same machinery is the direct route to P2-B.

*Self-correction recorded:* in an intermediate step I reported $\Delta Q_7=0$; that was a truncation artifact of a degree-6 product. The numeric remainder test ($|R-\Delta Q_6|/t^7$ stable at $\approx3.07$) caught it; the exact degree-7 polynomial above is the corrected value.
