# P2A: explicit primitive contraction and six-phase tube

**Status:** New independently computed exact-rational majorant result. Working proof/certificate; no owner RID assigned and no DSN changed.
**Scope:** The selected primitive continuous map, p=6, K=1, a local lifted phase chart. Not a normalized-coordinate or physical-generator-selection theorem.
**Source input:** `NG_L1_PRIMITIVE_CONTRACTION_CERT_v1.md` and its script give the homogeneous radial identities. The identities are independently rebuilt over rational coefficients in the new certificate.

## 1. Statement

Let
\[
T(\rho,\eta)=(\rho-\sin\eta,\ \eta+e^\rho-1-\sin\eta),\quad F=T^6,
\qquad Q=\rho^2-\rho\eta+\eta^2.
\]
Put
\[
P_5(\rho,\eta)=\frac{Q}{24}(5\eta^3-43\eta^2\rho+4\eta\rho^2-5\rho^3),
\quad R_{\ge6}(x)=Q(Fx)-Q(x)+Q(x)^2-P_5(x).
\]
Then the bound verified below is
\[
\boxed{|R_{\ge6}(x)|\le1560Q(x)^3\quad\text{for }0\le Q(x)\le1/3600.}
\]
Consequently,
\[
\boxed{Q-\tfrac32Q^2\le Q(Fx)\le Q-\tfrac12Q^2,\qquad 0<Q\le1/3600.}
\]
In particular the lower bound is positive and the upper bound is strictly less than Q.

An explicit T-invariant punctured tube is
\[
U=\{x:0<Q(x)\le1/10000\},\qquad U_T=\bigcup_{j=0}^{5}T^j(U).
\]
It satisfies
\[
T(U_T)\subseteq U_T,\qquad
0<Q(y)<\frac{441}{4000000}<\frac1{3600}\quad(y\in U_T).
\]
Every point of U is a sufficient scalar-certified member of U_T. The exact seed
\[
(\rho,\eta)=(1/100,1/250),\qquad Q=19/250000,
\]
belongs to U. This statement concerns the exact rational seed, not unrecorded floating-point perturbations of it.

## 2. Complexified primitive pair, not nonlinear normal-form coordinates

Set
\[
\omega=\frac{-1+i\sqrt3}{2},\quad\lambda=\frac{1+i\sqrt3}{2},
\quad W=\rho+\omega\eta,\quad V=\rho+\bar\omega\eta.
\]
On real states, V is the complex conjugate of W and WV=Q. For analytic power-series arguments treat W,V as independent complex variables. The inverse linear map is
\[
\rho=(\tfrac12-\tfrac{i\sqrt3}{6})W+(\tfrac12+\tfrac{i\sqrt3}{6})V,
\qquad\eta=-\tfrac{i\sqrt3}{3}W+\tfrac{i\sqrt3}{3}V.
\]
Each coefficient in both rows has modulus 1/sqrt(3). The exact W-component is
\[
f_W(W,V)=\lambda W+\omega(e^\rho-1-\rho)
+\bar\omega(\sin\eta-\eta).
\]
The V-component is its conjugate polynomial/analytic expression with W,V exchanged. All three scalar complex constants have unit modulus.

## 3. Coefficientwise scalar majorant

Fix a real angle theta and initialize
\[
W_0(t)=e^{i\theta}t,\qquad V_0(t)=e^{-i\theta}t.
\]
Take the rational number a=7/6; it exceeds 2/sqrt(3), as a^2=49/36>4/3.
Define a nonnegative-coefficient entire series
\[
\Psi(s)=s+e^{as}-1-as+\sinh(as)-as
=s+\sum_{n\ge2}\frac{1+\mathbf1_{n\text{ odd}}}{n!}(as)^n,
\]
and S_0(t)=t, S_{j+1}(t)=Psi(S_j(t)).

For every fixed theta, the absolute values of the coefficients of W_j(t) and V_j(t) are dominated coefficientwise by S_j(t). Proof is induction: the linear part multiplies by a unit; the inverse coordinate rows cost at most a; exponential and sine nonlinear tails are majorized by exp(as)-1-as and sinh(as)-as, respectively. The comparison is uniform in theta.

Let B_n=[t^n]S_6(t)^2. Multiplication preserves coefficientwise majorization. Thus the absolute values of the degree-n coefficients of Q(T^6x), along every primitive radial ray, are at most B_n.
The independently checked exact low-order polynomial is
\[
\sum_{n=0}^{5}B_nt^n
=t^2+\frac{49}{6}t^3+\frac{1372}{27}t^4
+\frac{17385641}{62208}t^5.
\]
This is the majorant polynomial, NOT the signed primitive radial jet.

The signed radial identities, rebuilt from T, are degree-four -Q^2 and degree-five P_5. Therefore, for t=sqrt(Q) and 0<t<=r,
\[
|R_{\ge6}(x)|\le\sum_{n\ge6}B_nt^n
\le\frac{t^6}{r^6}\left(S_6(r)^2-\sum_{n=0}^{5}B_nr^n\right).
\]
The last inequality uses B_n>=0. It does not subtract a signed primitive polynomial from an unrelated norm bound.

## 4. Exact rational evaluation at r=1/60

The certificate bounds S_j(r) from above without numerical transcendental evaluation. For x=au, M=16 and x<M+2,
\[
\Psi(u)\le u+\sum_{n=2}^{M}\frac{1+\mathbf1_{n\text{ odd}}}{n!}x^n
+\frac{2x^{M+1}}{(M+1)!}\frac1{1-x/(M+2)}.
\]
This follows because every omitted coefficient is <=2/n!, and the successive factorial-term ratios are <=x/(M+2).
After each update, the upper value is rounded UP to the rational grid 10^(-60), using an integer ceiling. Positivity and monotonicity of Psi preserve the upper enclosure at the next update.

The full rational U_j values are in `outputs/primitive_contraction_certificate.json`. Decimal displays only are
\[
\begin{array}{c|c}
j&U_j\ \hline
0&0.0166666666666667\\
1&0.0168581664392954\\
2&0.0170541211033959\\
3&0.0172546880068104\\
4&0.0174600319978731\\
5&0.0176703258778094\\
6&0.0178857508862851
\end{array}
\]
The acceptance comparison is EXACT rational arithmetic:
\[
\boxed{
\frac{U_6^2-r^2-\frac{49}{6}r^3-\frac{1372}{27}r^4
-\frac{17385641}{62208}r^5}{r^6}<1560.
}
\]
The left side displays as 1556.4634575243315..., but the decimal is not used to decide the inequality. This proves the announced remainder bound for every phase and every Q<=1/3600.

An independent arithmetic validator checks the same certificate with a recurrence for the low-degree coefficients and separate exp/sinh tails through order 20. It does not import the producer script. This is independent arithmetic implementation of the same majorant proof, not a claimed independent external mathematical review.

## 5. Contraction margin

The source's phase-uniform bound is
\[
|P_5|\le C_5Q^{5/2},\qquad C_5=\frac78+\frac{53\sqrt3}{72}<\frac{43}{20}.
\]
The last inequality follows exactly from sqrt(3)<459/265, whose squared numerator gap is 459^2-3*265^2=6>0.
For Q<=1/3600,
\[
\frac{|P_5+R_{\ge6}|}{Q^2}
\le\frac{43}{20}\frac1{60}+\frac{1560}{3600}
=\frac{563}{1200}<\frac12.
\]
There is also a self-contained weaker check that does not use the imported trigonometric bound: from |rho|,|eta|<=a sqrt(Q), the printed C3 polynomial gives
\[
|P_5|\le \frac{57a^3}{24}Q^{5/2}=\frac{6517}{1728}Q^{5/2},
\]
and
\[
\frac{6517}{1728}\frac1{60}+\frac{1560}{3600}
=\frac{10289}{20736}<\frac12.
\]
This alone already establishes c=1/2; the sharper source harmonic bound improves the margin but is not essential.

Hence the upper and lower contraction bounds in Section 1. A sharper upper coefficient 637/1200 follows from this margin, but the advertised result conservatively uses c=1/2.
The lower bound is positive because 1-(3/2)/3600>0.

## 6. Six-phase tube and exact seed

Repeat the same one-step upper-majorant recursion starting at r_in=1/100. For j=0,...,5, exact rational checks give
\[
S_j(1/100)<21/2000<1/60.
\]
Thus Q(T^j x)<(21/2000)^2=441/4000000 for x in U. In addition,
\[
|\rho|,|\eta|\le a|W|<\frac{7}{6}\frac{21}{2000}=\frac{49}{4000}<\frac1{50},
\]
so the entire tube is in a small lifted chart with no phase-wrap seam.

Since F contracts Q on U, F(U) is a subset of U. If some intermediate T^j x were zero, F(x)=0 would contradict strict positivity. The union is therefore punctured, and
\[
T\Big(\bigcup_{j=0}^{5}T^jU\Big)
\subseteq\bigcup_{j=1}^{5}T^jU\cup FU\subseteq U_T.
\]
For the exact Number Genesis small seed, Q=19/250000<1/10000. No floating-point orbit membership test is needed.

## 7. Consequences and explicit limits

For q_m=Q(F^m x) in the contraction domain,
\[
q_m\le\frac{q_0}{1+(q_0/2)m},\qquad
\sum_{m\ge0}q_m^3\le2q_0^2.
\]
The first follows by reciprocating q_{m+1}<=q_m(1-q_m/2); the second by summing
q_m^2-q_{m+1}^2>=(q_m-q_{m+1})q_m>=q_m^3/2.
These bounds are in the primitive Q observable. Normalized-coordinate memory transfer still needs its own chart and derivative estimates.

Every trajectory in U_T converges to the origin; there is no nonzero periodic trajectory in the tube. These statements remain conditional on the selected map T, not a physical-generator-selection theorem.

Not established here: an optimal radius; explicit invertibility/domain of the nonlinear normalizer h; normalized C7 or derivative-remainder bounds; interval-enclosed P2 manifold entry; full-map lattice memory; all additional angular inequalities needed to instantiate GAP-LOCK on this same numerical tube. The canonical seed's radial/tube membership is now established, but that does not silently discharge those separate premises.
