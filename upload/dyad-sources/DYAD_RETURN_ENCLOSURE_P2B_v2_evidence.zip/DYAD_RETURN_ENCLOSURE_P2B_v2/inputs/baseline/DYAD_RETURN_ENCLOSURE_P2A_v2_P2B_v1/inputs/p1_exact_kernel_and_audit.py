#!/usr/bin/env python3
"""Exact, independent P1 audit for the uploaded RTG return-map artifacts.
All polynomial operations use fractions in Q(omega), omega^2=-3; omega=i sqrt(3).
No numerical coefficient reconstruction or tolerance pruning is used.
New outputs are review/reconstruction artifacts, not historical owner exports.
"""
from __future__ import annotations
from fractions import Fraction as Q
from pathlib import Path
import ast, json, math, time
import sympy as sp

ROOT=Path(__file__).resolve().parents[1]
D=6
class K:
    __slots__=('a','b')
    def __init__(self,a=0,b=0):
        if isinstance(a,K): self.a,self.b=a.a,a.b
        else: self.a,self.b=Q(a),Q(b)
    def __add__(self,v):
        v=asK(v);return K(self.a+v.a,self.b+v.b)
    __radd__=__add__
    def __neg__(self):return K(-self.a,-self.b)
    def __sub__(self,v):return self+-asK(v)
    def __rsub__(self,v):return asK(v)+-self
    def __mul__(self,v):
        v=asK(v);return K(self.a*v.a-3*self.b*v.b,self.a*v.b+self.b*v.a)
    __rmul__=__mul__
    def conj(self):return K(self.a,-self.b)
    def __truediv__(self,v):
        v=asK(v);den=v.a*v.a+3*v.b*v.b
        if not den:raise ZeroDivisionError
        r=self*v.conj();return K(r.a/den,r.b/den)
    def __rtruediv__(self,v):return asK(v)/self
    def __pow__(self,n):
        if n<0:return (1/self)**(-n)
        r=K(1)
        for _ in range(n):r=r*self
        return r
    def __bool__(self):return bool(self.a or self.b)
    def __eq__(self,v):
        v=asK(v);return self.a==v.a and self.b==v.b
    def __repr__(self):
        if not self.b:return str(self.a)
        return f'({self.a}) + ({self.b})*sqrt(3)*I'
def asK(v):return v if isinstance(v,K) else K(v)
def clean(p):return {k:asK(v) for k,v in p.items() if v}
def add(*ps):
    out={}
    for p in ps:
        for k,v in p.items():out[k]=out.get(k,K())+v
    return clean(out)
def sc(p,c):return clean({k:v*c for k,v in p.items()})
def sub(p,q):return add(p,sc(q,-1))
def cut(p,d=D):return {k:v for k,v in p.items() if sum(k)<=d and v}
def sl(p,n):return {k:v for k,v in p.items() if sum(k)==n and v}
def mul(p,q,d=D):
    out={}
    for (a,b),x in p.items():
        for (c,e),y in q.items():
            if a+b+c+e<=d:
                k=(a+c,b+e);out[k]=out.get(k,K())+x*y
    return clean(out)
def pw(p,n,d=D):
    out={(0,0):K(1)}
    for _ in range(n):out=mul(out,p,d)
    return out
def comp(p,x,y,d=D):
    xp=[pw(x,n,d) for n in range(d+1)];yp=[pw(y,n,d) for n in range(d+1)]
    return add(*(sc(mul(xp[a],yp[b],d),c) for (a,b),c in p.items() if a+b<=d))
def cj(p):return {(b,a):c.conj() for (a,b),c in p.items()}
def ccomp(f,g,d=D):return comp(f,g,cj(g),d)
def it(f,n,d=D):
    g=X
    for _ in range(n):g=ccomp(f,g,d)
    return g
def deriv(p,i):return clean({tuple(v-1 if j==i else v for j,v in enumerate(k)):c*k[i] for k,c in p.items() if k[i]>0})
def act(v,p,d=D):return add(mul(deriv(p,0),v,d),mul(deriv(p,1),cj(v),d))
def inv(h,d=D):
    delta=sub(h,X);k=X
    for _ in range(d):k=sub(X,ccomp(delta,k,d))
    assert ccomp(h,k,d)==X and ccomp(k,h,d)==X
    return k
def conjmap(f,h,d=D):return ccomp(inv(h,d),ccomp(f,h,d),d)
def expmap(v,d=D):
    r=X;term=X
    for k in range(1,d+1):
        term=act(v,term,d)
        if not term:break
        r=add(r,sc(term,Q(1,math.factorial(k))))
    return r
def psin(p,d=D):return add(*(sc(pw(p,n,d),Q((-1)**((n-1)//2),math.factorial(n))) for n in range(1,d+1,2)))
def pexp(p,d=D):return add(*(sc(pw(p,n,d),Q(1,math.factorial(n))) for n in range(1,d+1)))
def dump(name,p,metadata=None):
    obj={str(k):str(c) for k,c in sorted(p.items())}
    (ROOT/'outputs'/name).write_text(json.dumps(obj,indent=2)+'\n')
    if metadata:(ROOT/'outputs'/(name+'.meta.json')).write_text(json.dumps(metadata,indent=2)+'\n')
def cget(p,k):return p.get(k,K())
X={(1,0):K(1)};Y={(0,1):K(1)};w=K(0,1);om=(-1+w)/2;lam=(1+w)/2
checks=[]
def check(name,v):
    ok=bool(v);checks.append({'check':name,'pass':ok});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok:raise AssertionError(name)

def main():
    t=time.perf_counter()
    # Route A: primitive real-variable recurrence, Q-rational coefficients.
    r,e=X,Y
    for _ in range(6):
        s=psin(e);u=pexp(r);r,e=sub(r,s),add(e,u,sc(s,-1))
    check('real primitive coefficients are rational',all(c.b==0 for p in [r,e] for c in p.values()))
    ri=add(sc(X,K(Q(1,2),-Q(1,6))),sc(Y,K(Q(1,2),Q(1,6))))
    ei=add(sc(X,-w/3),sc(Y,w/3))
    rW,eW=comp(r,ri,ei),comp(e,ri,ei)
    f6_from_real=add(rW,sc(eW,om))
    # Route B: directly build the one-step complex polynomial from T.
    f1=add(X,sc(psin(ei),om.conj()),sc(pexp(ri),om))
    f6=it(f1,6)
    check('two independent primitive/complex construction routes agree through degree 6',f6==f6_from_real)
    check('six-step linear part is identity',sl(f6,1)==X)
    check('six-step quadratic part vanishes',not sl(f6,2))
    mu=K(-Q(1,2),-Q(2,3))
    check('six-step cubic coefficient and full support',sl(f6,3)=={(2,1):mu})
    # Supplied JSON: exact parsing, comparing every retained monomial.
    data=json.loads((ROOT/'inputs/jet1_deg5.json').read_text());given={}
    for key,text in data.items():
        k=ast.literal_eval(key);v=sp.expand(sp.sympify(text))
        a=sp.simplify(sp.re(v));b=sp.simplify(sp.im(v)/sp.sqrt(3))
        given[k]=K(Q(int(a.p),int(a.q)),Q(int(b.p),int(b.q)))
    check('uploaded jet1_deg5.json exactly equals RAW one-step W jet',given==cut(f1,5))
    check('uploaded jet1 is NOT a quadratic-free normal form',bool(sl(given,2)))
    # Real radial polynomial through degree 6.
    q0=add(mul(X,X),sc(mul(X,Y),-1),mul(Y,Y))
    dq=sub(add(mul(r,r),sc(mul(r,e),-1),mul(e,e)),q0)
    check('radial homogeneous degree 4 is -Q^2',sl(dq,4)==sc(mul(q0,q0),-1))
    c3={(0,3):K(5),(1,2):K(-43),(2,1):K(4),(3,0):K(-5)}
    check('NG L1 radial degree 5 exactly reproduced',sl(dq,5)==sc(mul(q0,c3),Q(1,24)))
    check('raw real-ray quartic W correction',sum((c for k,c in sl(f6,4).items()),K())==K(-Q(5,48),-Q(25,48)))
    # Exact operations corresponding to the archival 'exact' mpmath script.
    f5=cut(f6,5);u=sub(f5,X);v3=sl(u,3);v4=sl(u,4)
    v5=sub(sl(u,5),sc(act(v3,v3,5),Q(1,2)))
    logf=add(v3,v4,v5)
    check('log/re-exponentiation identity holds when U2=0',expmap(logf,5)==f5)
    vnr={k:c for k,c in logf.items() if (k[0]-k[1]-1)%6}
    harch=add(X,vnr)
    garch=conjmap(f5,harch,5)
    check('archival O(4) coordinate map leaves ALL raw coefficients through degree 5 unchanged',garch==f5)
    check('archival map leaves nonzero quartic channels',bool(sl(garch,4)))
    keep={(2,1),(3,2),(0,5)};logproj={k:c for k,c in logf.items() if k in keep}
    gproj=expmap(logproj,5)
    check('projected-log map has only selected channels',set(sub(gproj,X))==keep)
    check('projected-log map retains raw resonant quintic coefficients',all(cget(gproj,k)==cget(f5,k) for k in [(3,2),(0,5)]))
    # Phi6 exported by generic script is exp(projected log), not a conjugating map.
    g_as_phi=conjmap(f5,gproj,5)
    check('using projected DYNAMICS as Phi6 leaves raw return unchanged through degree 5',g_as_phi==f5)
    check('that coordinate conjugacy is NOT the projected dynamical map',g_as_phi!=gproj)
    # Actual one-step homological coordinate normalization: f o H = H o N.
    h=X;nf=sc(X,lam)
    for n in range(2,D+1):
        residual=sl(sub(ccomp(f1,h),ccomp(h,nf)),n)
        hn={};gn={}
        for (a,b),c in residual.items():
            den=lam**(a-b)-lam
            if den:hn[(a,b)]=c/den
            else:gn[(a,b)]=c
        h=add(h,hn);nf=add(nf,gn)
        check(f'one-step homological identity through degree {n}',not cut(sub(ccomp(f1,h),ccomp(h,nf)),n))
    nh2=sl(h,2)
    h2_expected={(2,0):-(1+w)/12,(1,1):K(-Q(1,3)),(0,2):(1-w)/24}
    check('exact h2 matches declared DYAD convention',nh2==h2_expected)
    fhat=conjmap(f6,h)
    check('normalized one-step iterate equals conjugated full six-step jet',fhat==it(nf,6))
    check('normalized degree 2,4,6 vanish',all(not sl(fhat,n) for n in (2,4,6)))
    check('normalized support through degree 6',set(sub(fhat,X))==keep)
    c32n=K(-Q(97,432),Q(197,324));c05n=K(-Q(49,8640),-Q(307,25920))
    check('normalized c32 exact independently reproduced',cget(fhat,(3,2))==c32n)
    check('normalized c05 exact independently reproduced',cget(fhat,(0,5))==c05n)
    check('one-step normalized A6 matches bridge constant',cget(nf,(2,1))==K(Q(1,8),-Q(7,72)))
    check('one-step normalized C6 matches bridge constant',cget(nf,(3,2))==K(-Q(5,432),Q(23,3888)))
    check('one-step normalized B6 matches exact form of bridge decimal',cget(nf,(0,5))==K(Q(43,17280),-Q(227,155520)))
    # For comparison: H2 only, and gauge-free lattice obstruction.
    h2map=add(X,nh2);posth2=conjmap(f5,h2map,5)
    check('H2 alone removes quartic return',not sl(posth2,4))
    check('H2 alone produces same resonant quintics in direct zero-kernel normalization',all(cget(posth2,k)==cget(fhat,k) for k in [(3,2),(0,5)]))
    # Linear system over Q for a generic real quadratic coordinate change.
    columns=[]
    monos4=[(a,4-a) for a in range(5)]
    for m in [(2,0),(1,1),(0,2)]:
        for c in [K(1),w]:
            hh={m:c};br=sub(act(hh,v3,4),act(v3,hh,4))
            columns.append([v for k in monos4 for v in [cget(br,k).a,cget(br,k).b]])
    mat=sp.Matrix.hstack(*(sp.Matrix(x) for x in columns))
    check('quadratic conjugacy action on quartic return has full real rank 6',mat.rank()==6)
    check('h2 uniquely cancels the raw quartic term',not add(v4,sub(act(nh2,v3,4),act(v3,nh2,4))))
    # No cubic h3 bracket changes the pure anti-holomorphic quintic.
    for a in range(4):
        for c in [K(1),w]:
            hh={(a,3-a):c};br=sub(act(hh,v3,5),act(v3,hh,5))
            check(f'cubic coordinate basis ({a},{3-a}), imag={bool(c.b)}, cannot change (0,5)',not cget(br,(0,5)))
    delta=cget(f5,(0,5))-c05n
    check('projected-versus-normalized lattice discrepancy is (-13+3*i*sqrt3)/576',delta==K(-Q(13,576),Q(1,192)))
    # Export exact data and the separately reconstructed (not historical) Phi1.
    for name,p in [('primitive_rho_deg6.json',r),('primitive_eta_deg6.json',e),('radial_deltaQ_deg6.json',dq),('jet1_deg6_reconstructed.json',f1),('jet6_deg6_reconstructed.json',f6),('jet6_deg5_reconstructed.json',f5),('coordinate_h_deg6_reconstructed.json',h),('normalized_onestep_deg6.json',nf),('normalized_sixstep_deg6.json',fhat),('archival_coordinate_deg5.json',harch),('archival_conjugated_return_deg5.json',garch),('projected_log_model_deg5.json',gproj),('post_h2_return_deg5.json',posth2)]:
        dump(name,p,{'provenance':'independent exact reconstruction in this audit','not_historical_owner_artifact':True})
    phi1={'metadata':{'provenance':'INDEPENDENT RECONSTRUCTION; NOT HISTORICAL Phi1','convention':'direct polynomial H, resonant h_n=0, f o H = H o normalized_f'}}
    for n in range(2,6):phi1['h'+str(n)]={str(k):str(c) for k,c in sl(h,n).items()}
    (ROOT/'outputs/phi1_deg5_reconstructed.json').write_text(json.dumps(phi1,indent=2)+'\n')
    facts={
      'checks':checks,'seconds':time.perf_counter()-t,'exact_field':'Q(i sqrt(3))','degree':D,
      'raw_c32':str(cget(f5,(3,2))),'raw_c05':str(cget(f5,(0,5))),
      'normalized_c32':str(c32n),'normalized_c05':str(c05n),
      'lattice_mismatch':str(delta),'quartic_homological_rank':int(mat.rank()),
      'raw_quartic':{str(k):str(v) for k,v in v4.items()},
      'input_jet_role':'RAW one-step polynomial in primitive linear W frame',
      'analytic_enclosure':'NOT COMPUTED','original_sources_modified':False}
    (ROOT/'outputs/exact_audit_results.json').write_text(json.dumps(facts,indent=2)+'\n')
    print('EXACT AUDIT COMPLETE',len(checks),'checks',facts['seconds'],'seconds',flush=True)
if __name__=='__main__':main()
