#!/usr/bin/env python3
"""Run positive certificates and expected-to-fail controls with exit-code gates."""
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parents[1]
JOBS=[
 ('certify',[sys.executable,str(ROOT/'scripts/certify.py')],0),
 ('independent',[sys.executable,str(ROOT/'scripts/verify_independently.py')],0),
 ('negative_k8',[sys.executable,str(ROOT/'scripts/certify.py'),'--k8','42000'],1),
 ('negative_normal_C7',[sys.executable,str(ROOT/'scripts/certify.py'),'--c7','6000'],1),
 ('negative_raw_lattice',[sys.executable,str(ROOT/'scripts/verify_independently.py'),'--tamper-lattice'],1)]
status=[]
for name,cmd,expected in JOBS:
    cp=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    (ROOT/'logs'/f'{name}.log').write_text(cp.stdout)
    ok=cp.returncode==expected
    status.append({'job':name,'expected_exit':expected,'actual_exit':cp.returncode,'pass':ok})
    print(('PASS ' if ok else 'FAIL ')+name+f' (exit {cp.returncode}, expected {expected})',flush=True)
    if not ok:
        print(cp.stdout[-4000:]);sys.exit(1)
(ROOT/'outputs/run_status.json').write_text(json.dumps(status,indent=2)+'\n')
print('RUN SUITE PASS: two positive certificates, three correctly rejected negative controls.')
