#!/usr/bin/env python3
"""P2-A v2 and P2-B v1. Exact rational/algebraic working certificates.

New calculations, not a DSN amendment. Uses the preserved P1 exact polynomial
kernel, reconstructs T rather than fitting coefficients, and uses no floats in
acceptance decisions. Decimal log entries are displays only.
"""
from __future__ import annotations
import argparse, ast, importlib.util, json, sys
from pathlib import Path
from fractions import Fraction as R
from math import factorial, isqrt
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('preserved_p1',ROOT/'inputs/p1_exact_kernel_and_audit.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
K=p.K
checks=[]
def check(label,condition):
    ok=bool(condition);checks.append({'label':label,'pass':ok})
    print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok:raise AssertionError(label)
def ceil_grid(x,den=10**80):
    return R(-((-x.numerator*den)//x.denominator),den)
def sqrt_upper(x,den=10**9):
    if x<0:raise ValueError('negative squared modulus')
    n=isqrt((x.numerator*den*den)//x.denominator)
    if R(n,den)**2<x:n+=1
    u=R(n,den)
    if u*u<x:raise ArithmeticError('square-root enclosure')
    return u

def modulus_sum(poly):
    return sum((sqrt_upper(c.a*c.a+3*c.b*c.b) for c in poly.values()),R(0))
def conv(x,y,N=None):
    if N is None:N=len(x)+len(y)-2
    out=[R(0)]*(N+1)
    for i,c in enumerate(x):
        for j,d in enumerate(y):
            if i+j<=N:out[i+j]+=c*d
    return out

def compose(x,y,N=None):
    if N is None:N=(len(x)-1)*(len(y)-1)
    out=[R(0)]*(N+1);power=[R(1)]
    for c in x:
        for n,b in enumerate(power):out[n]+=c*b
        power=conv(power,y,N)
    return out

def eval_poly(x,t):return sum((c*t**n for n,c in enumerate(x)),R(0))
def derivative(x):return [n*x[n] for n in range(1,len(x))]
def majorant_series(N):
    a=R(7,6);psi=[R(0),R(1)]+[a**n*R(1+(n%2),factorial(n)) for n in range(2,N+1)]
    S=[R(0)]*(N+1);S[1]=R(1)
    for _ in range(6):S=compose(psi,S,N)
    return S,conv(S,S,N)

def psi_upper(u,cutoff=24):
    x=R(7,6)*u
    if not 0<=x<1:raise ValueError('majorant exponential-tail domain')
    finite=u+sum((R(1+n%2,factorial(n))*x**n for n in range(2,cutoff+1)),R(0))
    tail=2*x**(cutoff+1)/factorial(cutoff+1)/(1-x/R(cutoff+2))
    return ceil_grid(finite+tail)
def orbit_upper(r):
    U=[r]
    for _ in range(6):U.append(psi_upper(U[-1]))
    return U

def jet_data():
    X,Y=p.X,p.Y;ch=K(0,1);om=(-1+ch)/2;lam=(1+ch)/2
    ri=p.add(p.sc(X,K(R(1,2),-R(1,6))),p.sc(Y,K(R(1,2),R(1,6))))
    ei=p.add(p.sc(X,-ch/3),p.sc(Y,ch/3))
    f=p.add(X,p.sc(p.psin(ei,6),om.conj()),p.sc(p.pexp(ri,6),om))
    F=p.it(f,6,6)
    dq=p.sub(p.mul(F,p.cj(F),7),{(1,1):K(1)}) # product degree 7, inputs degree 6
    check('primitive linear return is identity',p.sl(F,1)==X)
    check('primitive degree 2 cancels',not p.sl(F,2))
    check('radial degree 4 is -Q^2',p.sl(dq,4)=={(2,2):K(-1)})
    check('no lower radial drift',not p.cut(dq,3))
    check('raw angular-average degree 6 coefficient is 47/54',p.cget(dq,(3,3))==K(R(47,54)))
    prescribed={(2,5):K(-R(317,480),R(19,160)),(3,4):K(R(26,27),R(337,1296)),
                (1,6):K(-R(7,864),R(119,12960)),(0,7):K(-R(1,120),R(13,3240))}
    expected=p.add(prescribed,p.cj(prescribed))
    check('all corrected reviewer degree 7 coefficients match exactly',p.sl(dq,7)==expected)
    check('degree 7 polynomial is nonzero',bool(p.sl(dq,7)))
    h=X;nmap=p.sc(X,lam)
    for n in range(2,7):
        E=p.sl(p.sub(p.ccomp(f,h,6),p.ccomp(h,nmap,6)),n)
        hn={};nn={}
        for (a,b),c in E.items():
            den=lam**(a-b)-lam
            if den:hn[a,b]=c/den
            else:nn[a,b]=c
        h=p.add(h,hn);nmap=p.add(nmap,nn)
        check(f'one-step polynomial conjugacy through degree {n}',not p.cut(p.sub(p.ccomp(f,h,6),p.ccomp(h,nmap,6)),n))
    J=p.it(nmap,6,6)
    check('full six-step conjugacy defect vanishes through degree 6',not p.sub(p.ccomp(F,h,6),p.ccomp(h,J,6)))
    check('normalized J has exactly the three nonlinear channels',set(p.sub(J,X))=={(2,1),(3,2),(0,5)})
    check('normalized a32',p.cget(J,(3,2))==K(-R(97,432),R(197,324)))
    check('normalized a05',p.cget(J,(0,5))==K(-R(49,8640),-R(307,25920)))
    # Compare the historical-reconstruction polynomial, without executing its producer.
    archived={}
    import sympy as sp
    for key,value in json.loads((ROOT/'inputs/coordinate_h_deg6_reconstructed.json').read_text()).items():
        z=sp.expand(sp.sympify(value));aa=sp.simplify(sp.re(z));bb=sp.simplify(sp.im(z)/sp.sqrt(3))
        archived[ast.literal_eval(key)]=K(R(int(aa.p),int(aa.q)),R(int(bb.p),int(bb.q)))
    check('h equals preserved P1 degree 6 polynomial in every coefficient',h==archived)
    return F,dq,h,J

def pack(poly):return {f'{a},{b}':[str(c.a),str(c.b)] for (a,b),c in sorted(poly.items())}
def strings(x):
    if isinstance(x,R):return str(x)
    if isinstance(x,dict):return {str(k):strings(v) for k,v in x.items()}
    if isinstance(x,list):return [strings(v) for v in x]
    return x

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--k8',type=int,default=42355)
    ap.add_argument('--c7',type=int,default=8000)
    ap.add_argument('--inverse-derivative-cap',type=R,default=R(1,8))
    args=ap.parse_args()
    F,dq,h,J=jet_data();a=R(7,6)
    check('rational a dominates both primitive inverse rows',a*a>R(4,3))
    coeff_bounds={5:R(16931,10000),6:R(6671,5000),7:R(3567,1000)}
    sums={}
    for d,b in coeff_bounds.items():
        sums[d]=modulus_sum(p.sl(dq,d))
        check(f'phase-uniform radial degree {d} modulus-sum bound',sums[d]<b)
    S,B=majorant_series(7)
    check('B2 through B5 reproduce baseline',B[2:6]==[R(1),R(49,6),R(1372,27),R(17385641,62208)])
    check('B6 reviewer exact coefficient',B[6]==R(24025892219,16796160))
    check('B7 retained in tail subtraction',B[7]==R(8429875678889,1209323520))
    # Independently rerun the conservative baseline with a tighter exp enclosure.
    oldr=R(1,60);oldU=orbit_upper(oldr)
    oldC=(oldU[-1]**2-eval_poly(B[:6],oldr))/oldr**6
    check('documented P2A-v1 C6<1560 baseline reproduces',oldC<1560)
    r=R(1,20);U=orbit_upper(r)
    k8calc=(U[-1]**2-eval_poly(B,r))/r**8;k8=R(args.k8)
    check(f'outward rational degree >=8 tail < {k8}',0<k8calc<k8)
    C6calc=coeff_bounds[6]+coeff_bounds[7]*r+k8*r*r;C6=R(108)
    check('primitive radial C6 coefficient <108',C6calc<C6)
    delta=coeff_bounds[5]*r+coeff_bounds[6]*r*r+coeff_bounds[7]*r**3+k8*r**4
    check('sharp signed-jet contraction margin below 1/2',delta<R(1,2))
    check('rounded C6=108 also yields contraction',coeff_bounds[5]*r+C6*r*r<R(1,2))
    check('positive lower radial bound on all of Q<=1/400',1-R(3,2)*r*r>0)
    rin=R(1,25);Utube=orbit_upper(rin);rtube=R(47,1000)
    check('every six-phase image from qin=1/625 lies below 47/1000',max(Utube[:6])<rtube<r)
    check('tube remains in primitive rho/eta chart of size 0.06',a*rtube<R(3,50))
    seedq=R(1,100)**2-R(1,100)*R(1,250)+R(1,250)**2
    check('exact seed lies in new base disk',seedq==R(19,250000) and seedq<rin*rin)
    check('seed squared-amplitude margin is 400/19, not 12',rin*rin/seedq==R(400,19))
    # P2B: conservative rational polynomial majorants.
    M=[R(0),R(0),R(7,12),R(39,500),R(14,125),R(11,250),R(1,20)]
    # degree-two moduli are exact 1/6,1/3,1/12; avoid rounding loss.
    check('exact quadratic h modulus sum is 7/12',all(c.a*c.a+3*c.b*c.b==v*v for c,v in
          [(p.cget(h,(2,0)),R(1,6)),(p.cget(h,(1,1)),R(1,3)),(p.cget(h,(0,2)),R(1,12))]))
    for n in range(3,7):check(f'h degree {n} rational majorant',modulus_sum(p.sl(h,n))<M[n])
    H=M[:];H[1]=R(1)
    P=[R(0),R(1),R(0),R(1259,1000),R(173,100),R(469,500),R(248,125)]
    Ja=[R(0),R(1),R(0),R(1259,1000),R(0),R(1099,1000)]
    for n in range(3,7):check(f'raw vector degree {n} modulus majorant',modulus_sum(p.sl(F,n))<P[n])
    for n in (3,5):check(f'normalized degree {n} modulus majorant',modulus_sum(p.sl(J,n))<Ja[n])
    Rinv=R(1,10);sig=R(9,100);rn=R(1,40)
    kap=eval_poly(derivative(M),Rinv)
    check('Dh-I operator norm <1/8 on |z|<=1/10',kap<args.inverse_derivative_cap)
    check('inverse image disk |w|<=9/100 fits contraction map',sig+eval_poly(M,Rinv)<Rinv)
    check('relative coordinate error <1/16',eval_poly(M,Rinv)/Rinv<R(1,16))
    Hrn=eval_poly(H,rn);Jrn=eval_poly(Ja,rn);FhU=orbit_upper(Hrn)
    check('h evaluation stays in raw vector tail domain',Hrn<r)
    check('F_W(h(z)) remains inside inverse-image target disk',FhU[-1]<sig)
    check('J(z) remains in normalizer injectivity disk',Jrn<Rinv)
    check('h(J(z)) remains inside inverse target disk',eval_poly(H,Jrn)<sig)
    # Actual finite polynomial defect is not zero; use an explicit majorant for its >=7 tail.
    degree7_defect=p.sl(p.sub(p.ccomp(F,h,7),p.ccomp(h,J,7)),7)
    check('finite polynomial conjugacy defect at degree 7 is nonzero',bool(degree7_defect))
    Q1=compose(P,H);Q2=compose(H,Ja)
    Q2 += [R(0)]*(len(Q1)-len(Q2))
    Dmajor=[u+v if n>=7 else R(0) for n,(u,v) in enumerate(zip(Q1,Q2))]
    dconst=eval_poly(Dmajor,rn)/rn**7
    check('finite conjugacy-defect majorant Cpoly<16',dconst<16)
    k7calc=(U[-1]-eval_poly(S[:7],r))/r**7;k7=R(5600)
    check('primitive vector Taylor tail K7<5600 on |W|<=1/20',0<k7calc<k7)
    b=Hrn/rn;L=R(8,7)
    check('inverse Lipschitz constant 8/7 follows',1/(1-kap)<L)
    c7calc=L*(k7*b**7+dconst);c7=R(args.c7)
    check(f'normalized vector remainder C7<{c7}',c7calc<c7)
    # Termwise derivative tail: n alpha^(n-7)<=7 for alpha<=7/8 and n>=7.
    check('raw derivative-tail radius separation H(r)/rW<7/8',Hrn/r<R(7,8))
    dpoly=eval_poly(derivative(Dmajor),rn)/rn**6
    eprime=7*k7*b**6*eval_poly(derivative(H),rn)+dpoly
    M2=eval_poly(derivative(derivative(M)),Rinv)
    cdcalc=L*(eprime+M2*c7*rn*eval_poly(derivative(Ja),rn));cd=R(60000)
    check('normalized first derivative remainder Cder6<60000',cdcalc<cd)
    bridge_rin=R(1,50);bridgeU=orbit_upper(bridge_rin)
    check('a smaller primitive invariant tube fits entirely in normalized evaluation disk',R(16,15)*max(bridgeU[:6])<rn)
    check('exact seed belongs to that smaller primitive base',seedq<bridge_rin**2)
    report={'status':'working certificates, independently arithmetically checked; not owner-adopted',
      'arithmetic':'exact fractions and Q(i sqrt(3)); floats below are display-only',
      'checks':checks,'all_checks_pass':True,
      'P2A':{'q_ctr':r*r,'q_in':rin*rin,'C6_prim_rad':C6,'c':R(1,2),
       'radial_homogeneous_bounds':coeff_bounds,'sqrt_enclosed_modulus_sums':sums,
       'B0_to_B7':B,'S0_to_S7':S,'k8_bound':k8,'k8_rational_upper':k8calc,
       'sharp_margin':delta,'rounded_margin':coeff_bounds[5]*r+C6*r*r,
       'effective_C6_upper':C6calc,'outer_orbit_upper':U,'tube_orbit_upper':Utube,
       'tube_W_bound':rtube,'seedQ':seedq,'seed_Q_margin':rin*rin/seedq,
       'baseline_C6_rational_upper':oldC},
      'P2B':{'h_domain_radius':Rinv,'inverse_target_radius':sig,'normal_eval_radius':rn,
       'h_derivative_upper':R(1,8),'hinv_Lipschitz':L,'hinv_derivative_minus_I_upper':R(1,7),
       'coordinate_norm_lower':R(15,16),'coordinate_norm_upper':R(17,16),
       'normal_C7':c7,'normal_derivative_C6':cd,'raw_vector_radius':r,'raw_vector_K7':k7,
       'M':M,'H':H,'P':P,'Jmajor':Ja,'finite_defect_majorant':Dmajor,
       'kappa_exact_upper':kap,'H_eval':Hrn,'J_eval':Jrn,'Fh_orbit_upper':FhU,
       'Cpoly':dconst,'Dpoly_derivative_constant':dpoly,'raw_K7_rational_upper':k7calc,
       'normal_C7_rational_upper':c7calc,'normal_derivative_C6_rational_upper':cdcalc,
       'M_second_derivative_upper':M2,'smaller_tube_base_Q':bridge_rin**2,'smaller_tube_orbit_upper':bridgeU},
      'jet':{'F6_primitive':pack(F),'deltaQ_through7':pack(dq),'h_degree6':pack(h),'J_normal_through6':pack(J),
       'finite_defect_degree7':pack(degree7_defect)},
      'limits':['not an optimized radius','no P2 manifold entry certificate','no full-map memory theorem',
        'no GAP-LOCK angular-domain instantiation','no DSN/RID modification','reviewer did not review this new P2B certificate']}
    (ROOT/'outputs/certificate.json').write_text(json.dumps(strings(report),indent=2)+'\n')
    print('DISPLAY k8 =',float(k8calc),'sharp margin =',float(delta),'C6 upper =',float(C6calc))
    print('DISPLAY P2B Cpoly =',float(dconst),'C7 =',float(c7calc),'Cder6 =',float(cdcalc))
    print('CERTIFICATE PASS',len(checks),'checks',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        print('CERTIFICATE FAIL',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
