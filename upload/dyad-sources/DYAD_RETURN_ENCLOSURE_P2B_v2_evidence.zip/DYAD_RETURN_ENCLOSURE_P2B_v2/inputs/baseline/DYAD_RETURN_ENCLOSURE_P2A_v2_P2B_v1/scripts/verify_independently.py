#!/usr/bin/env python3
"""Separate validator. Does not import certify.py or its polynomial kernel.

Uses the supplied reviewer Q/P backend unchanged, real-coordinate recurrence,
independent exp-series recurrence, separate exp/sinh analytic tails, and Horner
polynomial majorants. It verifies the same proof, not an external peer review.
"""
from __future__ import annotations
import argparse, importlib.util, json, sys
from fractions import Fraction as R
from pathlib import Path
from math import factorial
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('reviewer_backend',ROOT/'inputs/dyad_return_qchi_exact.py')
bk=importlib.util.module_from_spec(spec);spec.loader.exec_module(bk)
Q,P=bk.Q,bk.P
checks=[]
def check(label,ok):
    ok=bool(ok);checks.append({'label':label,'pass':ok});print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok:raise AssertionError(label)
def decode(poly,N=6):return P({tuple(map(int,k.split(','))):Q(R(v[0]),R(v[1])) for k,v in poly.items()},N)
def qp(q,n):
    z=Q(1)
    for _ in range(n):z=z*q
    return z

def rederive():
    N=6;X=P({(1,0):Q(1)},N);Y=P({(0,1):Q(1)},N)
    def step(r,e):
        se=P({},N);er=P({},N)
        for j in range(1,N+1):
            er=er+r.pw(j).scale(Q(R(1,factorial(j))))
            if j%2:se=se+e.pw(j).scale(Q(R((-1)**((j-1)//2),factorial(j))))
        return r-se,e+er-se
    r,e=X,Y
    r1,e1=step(r,e)
    for _ in range(6):r,e=step(r,e)
    chi=Q(0,1);om=Q(-R(1,2),R(1,2));lam=Q(R(1,2),R(1,2))
    ri=X.scale(Q(R(1,2),-R(1,6)))+Y.scale(Q(R(1,2),R(1,6)))
    ei=X.scale(Q(0,-R(1,3)))+Y.scale(Q(0,R(1,3)))
    F=r.compose(ri,ei)+e.compose(ri,ei).scale(om)
    f=r1.compose(ri,ei)+e1.compose(ri,ei).scale(om)
    check('second implementation: primitive quadratic cancellation',not F.deg(2).d)
    # lift product precision explicitly; F through degree 6 suffices for radial degree 7.
    FP=P(F.d,7);dq=FP*FP.conj()-P({(1,1):Q(1)},7)
    h=X;nmap=X.scale(lam)
    for k in range(2,7):
        E=(f.compose(h,h.conj())-h.compose(nmap,nmap.conj())).deg(k)
        hh={};nn={}
        for (a,b),c in E.d.items():
            v=qp(lam,(a-b)%6)-lam
            if v.iszero():nn[a,b]=c
            else:hh[a,b]=c/v
        h=h+P(hh,N);nmap=nmap+P(nn,N)
    J=X
    for _ in range(6):J=nmap.compose(J,J.conj())
    return F,dq,h,J

def sqrthi(x):
    den=10**10
    lo=0;hi=1
    while R(hi,den)**2<x:hi*=2
    while hi-lo>1:
        mid=(hi+lo)//2
        if R(mid,den)**2>=x:hi=mid
        else:lo=mid
    if x==0:return R(0)
    return R(hi,den)
def ms(poly):return sum((sqrthi(c.a*c.a+3*c.b*c.b) for c in poly.d.values()),R(0))
def exp_series(c,N):
    out=[R(0)]*(N+1);out[0]=R(1)
    for n in range(1,N+1):out[n]=sum((k*c[k]*out[n-k] for k in range(1,n+1)),R(0))/n
    return out

def majorants():
    N=7;a=R(7,6);S=[R(0)]*8;S[1]=R(1)
    for _ in range(6):
        A=[a*x for x in S];E=exp_series(A,N);Em=exp_series([-x for x in A],N)
        S=[R(0)]+[S[n]+E[n]+(E[n]-Em[n])/2-2*A[n] for n in range(1,N+1)]
    B=[sum((S[j]*S[n-j] for j in range(n+1)),R(0)) for n in range(8)]
    return S,B

def psi_alt(u):
    x=R(7,6)*u
    if not 0<=x<1:raise ValueError('validator analytic-tail domain')
    er=sum((x**n/factorial(n) for n in range(2,29)),R(0))+x**29/factorial(29)/(1-x/30)
    sh=sum((x**n/factorial(n) for n in range(3,29,2)),R(0))+x**29/factorial(29)/(1-x*x/(30*31))
    return u+er+sh

def sparse(poly):return {n:R(c) for n,c in enumerate(poly) if R(c)}
def mul(a,b):
    r={}
    for i,c in a.items():
        for j,d in b.items():r[i+j]=r.get(i+j,R(0))+c*d
    return {k:v for k,v in r.items() if v}
def comp(a,b):
    r={}
    for n in range(max(a),-1,-1):
        r=mul(r,b)
        if a.get(n):r[0]=r.get(0,R(0))+a[n]
    return r
def ep(poly,s):return sum((c*s**n for n,c in poly.items()),R(0))
def dp(poly):return {n-1:n*c for n,c in poly.items() if n}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--tamper-lattice',action='store_true');args=ap.parse_args()
    data=json.loads((ROOT/'outputs/certificate.json').read_text());A=data['P2A'];B=data['P2B'];jets=data['jet']
    F,dq,h,J=rederive()
    for label,obj,key in [('F6',F,'F6_primitive'),('radial degree 7',dq,'deltaQ_through7'),('h',h,'h_degree6'),('J',J,'J_normal_through6')]:
        check('independent full coefficient equality: '+label,obj.d==decode(jets[key],obj.N).d)
    check('full radial degree 7 is retained',bool(dq.deg(7).d))
    if args.tamper_lattice:J.d[(0,5)]=F.get((0,5))
    check('independent full conjugacy identity through degree 6',not (F.compose(h,h.conj())-h.compose(J,J.conj())).d)
    F7,h7,J7=P(F.d,7),P(h.d,7),P(J.d,7)
    defect7=(F7.compose(h7,h7.conj())-h7.compose(J7,J7.conj())).deg(7)
    check('nonzero finite degree 7 conjugacy defect matches',bool(defect7.d) and defect7.d==decode(jets['finite_defect_degree7'],7).d)
    S,BB=majorants()
    check('majorant S coefficients via exponential recurrence',S==list(map(R,A['S0_to_S7'])))
    check('majorant B through degree 7 via independent recurrence',BB==list(map(R,A['B0_to_B7'])))
    for label,arr in [('outer',A['outer_orbit_upper']),('tube',A['tube_orbit_upper']),('Fh',B['Fh_orbit_upper']),('normalized-tube',B['smaller_tube_orbit_upper'])]:
        U=list(map(R,arr))
        for j in range(6):check(f'outward step bound {label}/{j+1} via separate tails',psi_alt(U[j])<=U[j+1])
    for d,v in A['radial_homogeneous_bounds'].items():check(f'radial modulus bounds, separate integer bisection, degree {d}',ms(dq.deg(int(d)))<R(v))
    r=R(1,20);U=list(map(R,A['outer_orbit_upper']))
    k8=(U[-1]**2-sum((c*r**n for n,c in enumerate(BB)),R(0)))/r**8
    k7=(U[-1]-sum((c*r**n for n,c in enumerate(S[:7])),R(0)))/r**7
    check('independent K8 <42355',k8<R(A['k8_bound']))
    check('independent raw vector K7 <5600',k7<R(B['raw_vector_K7']))
    c5,c6,c7=(R(A['radial_homogeneous_bounds'][str(n)]) for n in (5,6,7))
    check('radial remainder C6=108 follows',c6+c7*r+R(A['k8_bound'])*r*r<R(A['C6_prim_rad']))
    check('sharp contraction exact margin',c5*r+c6*r*r+c7*r**3+R(A['k8_bound'])*r**4==R(A['sharp_margin'])<R(1,2))
    check('rounded contraction exact margin',c5*r+R(A['C6_prim_rad'])*r*r==R(A['rounded_margin'])<R(1,2))
    check('seed margin exact',R(A['q_in'])/R(A['seedQ'])==R(400,19))
    M=sparse(B['M']);H=sparse(B['H']);Pa=sparse(B['P']);Ja=sparse(B['Jmajor'])
    # Exact treatment of the rational quadratic norm sum; all others by independent squared ceilings.
    check('h quadratic sum bound',h.get((2,0))==Q(-R(1,12),-R(1,12)) and h.get((1,1))==Q(-R(1,3)) and h.get((0,2))==Q(R(1,24),-R(1,24)) and M[2]==R(7,12))
    for d in range(3,7):
        check(f'h majorant degree {d}',ms(h.deg(d))<M[d])
        check(f'F majorant degree {d}',ms(F.deg(d))<Pa[d])
    for d in (3,5):check(f'J majorant degree {d}',ms(J.deg(d))<Ja[d])
    Rinv=R(B['h_domain_radius']);sig=R(B['inverse_target_radius']);rn=R(B['normal_eval_radius']);L=R(B['hinv_Lipschitz'])
    kap=ep(dp(M),Rinv)
    check('inverse contraction derivative bound',kap<R(1,8) and 1/(1-kap)<L)
    check('inverse image contains target disk',sig+ep(M,Rinv)<Rinv)
    check('relative coordinate bounds',ep(M,Rinv)/Rinv<R(1,16))
    Q1,Q2=comp(Pa,H),comp(H,Ja)
    Qd={n:Q1.get(n,R(0))+Q2.get(n,R(0)) for n in set(Q1)|set(Q2) if n>=7}
    check('finite defect majorant via independent sparse Horner composition',Qd==sparse(B['finite_defect_majorant']))
    polyC=ep(Qd,rn)/rn**7;bh=ep(H,rn)/rn;K7=R(B['raw_vector_K7']);C7=R(B['normal_C7'])
    check('nonlinear compositions lie in inverse domain',R(B['Fh_orbit_upper'][-1])<sig and ep(H,ep(Ja,rn))<sig and ep(Ja,rn)<Rinv)
    check('normalized vector C7 follows with polynomial defect INCLUDED',L*(K7*bh**7+polyC)<C7)
    check('derivative tail separation',ep(H,rn)/r<R(7,8))
    D1=7*K7*bh**6*ep(dp(H),rn)+ep(dp(Qd),rn)/rn**6
    D2=ep(dp(dp(M)),Rinv)*C7*rn*ep(dp(Ja),rn)
    check('normalized derivative remainder follows',L*(D1+D2)<R(B['normal_derivative_C6']))
    tmax=max(map(R,B['smaller_tube_orbit_upper'][:6]))
    check('smaller conjugate invariant tube fits normalized domain',R(16,15)*tmax<rn)
    print('INDEPENDENT VALIDATOR PASS',len(checks),'checks')
    (ROOT/'outputs/independent_validation.json').write_text(json.dumps({'all_checks_pass':True,'checks':checks,'scope':'independent arithmetic implementation of the same proof; no external peer review claimed'},indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except Exception as e:
        print('INDEPENDENT VALIDATOR FAIL',type(e).__name__,str(e),file=sys.stderr);sys.exit(1)
