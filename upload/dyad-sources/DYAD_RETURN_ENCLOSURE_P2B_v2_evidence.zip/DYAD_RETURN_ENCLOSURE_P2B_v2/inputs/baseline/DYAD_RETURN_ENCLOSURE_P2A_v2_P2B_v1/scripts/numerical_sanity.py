#!/usr/bin/env python3
"""High-precision finite spot checks ONLY; not proof of uniform bounds."""
from pathlib import Path
import json
import mpmath as m
m.mp.dps=80
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'outputs/certificate.json').read_text())
def rational(s):
 a,*b=s.split('/');return m.mpf(a)/(m.mpf(b[0]) if b else 1)
def load(k):return {tuple(map(int,s.split(','))):rational(v[0])+1j*m.sqrt(3)*rational(v[1]) for s,v in data['jet'][k].items()}
h=load('h_degree6');J=load('J_normal_through6')
def val(p,z):return sum((c*z**a*m.conj(z)**b for (a,b),c in p.items()),m.mpc(0))
def derivatives(p,z):
 A=sum((a*c*z**(a-1)*m.conj(z)**b for (a,b),c in p.items() if a),m.mpc(0))
 B=sum((b*c*z**a*m.conj(z)**(b-1) for (a,b),c in p.items() if b),m.mpc(0))
 return A,B
def matrix(p,z):
 A,B=derivatives(p,z);return m.matrix([[m.re(A+B),-m.im(A-B)],[m.im(A+B),m.re(A-B)]])
def inverse(w):
 z=w
 for _ in range(16):
  e=val(h,z)-w;A,B=derivatives(h,z)
  z -= (m.conj(A)*e-B*m.conj(e))/(abs(A)**2-abs(B)**2)
 if abs(val(h,z)-w)>m.mpf('1e-70'):raise ArithmeticError('inverse residual')
 return z
L=m.matrix([[1,-m.mpf(1)/2],[0,m.sqrt(3)/2]])
rows=[]
for r in [m.mpf(1)/40,m.mpf(1)/80,m.mpf(1)/160]:
 for theta in [0,m.mpf('.3'),1,m.mpf('2.2')]:
  z=r*m.exp(1j*theta);w=val(h,z);rho=m.re(w)+m.im(w)/m.sqrt(3);eta=2*m.im(w)/m.sqrt(3)
  A=m.eye(2)
  for _ in range(6):
   D=m.matrix([[1,-m.cos(eta)],[m.exp(rho),1-m.cos(eta)]])
   A=D*A;s=m.sin(eta);rho,eta=rho-s,eta+m.expm1(rho)-s
  wf=rho-eta/2+1j*m.sqrt(3)*eta/2;zn=inverse(wf)
  Dhf=matrix(h,zn)**-1*L*A*L**-1*matrix(h,z)
  err=abs(zn-val(J,z))/r**7;derr=m.norm(Dhf-matrix(J,z))/r**6
  if not (err<8000 and derr<60000):raise AssertionError('finite sanity bound')
  rows.append({'r':str(r),'theta':str(theta),'scaled_value_error':m.nstr(err,20),'scaled_derivative_Frobenius_error':m.nstr(derr,20)})
print('NUMERICAL SANITY PASS',len(rows),'sampled states; not a uniform certificate')
print('Max scaled value error:',max(float(v['scaled_value_error']) for v in rows))
print('Max scaled derivative Frobenius error:',max(float(v['scaled_derivative_Frobenius_error']) for v in rows))
(ROOT/'outputs/numerical_sanity.json').write_text(json.dumps({'scope':'finite 80-digit diagnostic, not used by certificates','samples':rows},indent=2)+'\n')
