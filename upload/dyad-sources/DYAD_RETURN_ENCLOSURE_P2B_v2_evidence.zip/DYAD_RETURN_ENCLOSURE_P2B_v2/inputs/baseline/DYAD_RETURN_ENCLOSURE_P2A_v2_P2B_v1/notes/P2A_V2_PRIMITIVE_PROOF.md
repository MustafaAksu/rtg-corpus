# P2-A v2 — signed-jet primitive contraction certificate

**Date:** 2026-09-21.  
**Status:** New working proof and exact-arithmetic certificate. Not owner-adopted; no RID assigned and no DSN amended.  
**Contributors:** Claude supplied the preserved review and proposed retaining the exact signed radial degrees 5–7 before majorizing the tail. ChatGPT independently reconstructed those polynomials, supplied rational upper bounds, and implemented the certificate and a separate validator. Claude has not reviewed this new package.  
**Scope:** The selected continuous map, p=6, K=1, primitive lifted coordinates. No physical generator selection, normalized-amplitude identification, or global claim.

## 1. Single operative constant set for this revision

Let
\[
T(\rho,\eta)=(\rho-\sin\eta,\eta+e^\rho-1-\sin\eta),\quad F=T^6,
\quad Q=\rho^2-\rho\eta+\eta^2.
\]
Define
\[
P_5=\frac{Q}{24}(5\eta^3-43\eta^2\rho+4\eta\rho^2-5\rho^3),
\qquad R_{\ge6}^{\rm prim}=Q(Fx)-Q+Q^2-P_5.
\]
The constants delivered here are
\[
\boxed{q_{\rm ctr}=1/400,\quad C_{6,\rm rad}^{\rm prim}=108,
\quad c=1/2,\quad q_{\rm in}=1/625.}
\]
They imply, on the entire real disk \(0\le Q\le1/400\),
\[
|R_{\ge6}^{\rm prim}|\le108Q^3.
\]
On its punctured part,
\[
\boxed{0<Q-\tfrac32Q^2\le Q(Fx)\le Q-\tfrac12Q^2<Q.}
\]
The documented previous set (1560,1/3600,1/10000) remains a valid weaker certificate. The unsupported delivery record for the earlier (64,1/256,1/1024) claim is withdrawn; see `REVIEW_DISPOSITION.md`. No claim here says that those numerical inequalities are false.

## 2. Exact primitive jet, with product precision stated

Write
\[
W=\rho-\eta/2+i\sqrt3\eta/2,\quad V=\bar W,\quad Q=WV.
\]
For analytic majorization W,V can be treated as independent variables; on the real state plane V is the conjugate of W. All exact polynomial coefficients are in \(\mathbb Q(\chi)\), \(\chi=i\sqrt3\), \(\chi^2=-3\).

The six-step vector jet through degree 6 determines the radial jet through degree 7: multiply at degree **7**, not at the vector truncation degree 6. Unknown vector degree 7 first contributes to radial degree 8. Both implementations verify
\[
Q(Fx)-Q=-Q^2+P_5+P_6+P_7+R_{\ge8}^{\rm prim}.
\]
All polynomials are exported in `outputs/certificate.json`. In particular, the coefficients of P7 for (W-power,V-power) are

| Powers | Coefficient |
|---|---|
| (2,5) | \(-317/480+(19/160)\chi\) |
| (3,4) | \(26/27+(337/1296)\chi\) |
| (1,6) | \(-7/864+(119/12960)\chi\) |
| (0,7) | \(-1/120+(13/3240)\chi\) |

The other four are obtained by exchanging powers and conjugating. P7 is **not zero**.

For P6, the (3,3) coefficient is 47/54. This is a raw homogeneous radial coefficient and the corresponding uniform-angle average at fixed primitive Q. Its equality with a number in an owner table does not independently identify it with a normalized coefficient or establish a long-orbit scalar backbone recursion.

## 3. Phase-uniform rational coefficient bounds

For a coefficient \(c=a+b\chi\), its modulus is \(\sqrt{a^2+3b^2}\). Each square root is bounded above on a rational grid by integer arithmetic, and the squared inequality is checked. Summing the bounds yields the following rational ceilings:
\[
\boxed{
|P_5|\le\frac{16931}{10000}Q^{5/2},\qquad
|P_6|\le\frac{6671}{5000}Q^3,\qquad
|P_7|\le\frac{3567}{1000}Q^{7/2}.
}
\]
The certificate's intermediate upper sums display as 1.693054688, 1.334193707, and 3.566973910. The acceptance tests use fractions and squared moduli, not these displays or a phase mesh. The second validator uses a separate integer-bisection enclosure.

## 4. Analytic majorant and exact tail subtraction

Let \(\omega=(-1+\chi)/2\), \(\lambda=(1+\chi)/2\). Inverse coordinate coefficients have modulus 1/sqrt(3), and
\[
f_W=\lambda W+\omega(e^\rho-1-\rho)
 +\bar\omega(\sin\eta-\eta).
\]
Take \(a=7/6>2/\sqrt3\) and define
\[
\Psi(s)=s+e^{as}-1-as+\sinh(as)-as,
\quad S_0(t)=t,\quad S_{j+1}(t)=\Psi(S_j(t)).
\]
For each homogeneous degree, the **sum of the moduli of the bivariate coefficients** of either component of the j-th iterate is bounded by the corresponding coefficient of Sj. This stronger coefficientwise statement follows inductively from the triangle inequality and convolution; it implies the phase-uniform ray bound and the termwise derivative bounds used in P2-B.

Set \(B_n=[t^n]S_6(t)^2\). The exact low coefficients are
\[
(B_0,\ldots,B_7)=
\left(0,0,1,\frac{49}{6},\frac{1372}{27},
\frac{17385641}{62208},\frac{24025892219}{16796160},
\frac{8429875678889}{1209323520}\right).
\]
These are **majorant** coefficients, not signed radial coefficients. Consequently,
\[
|R_{\ge8}^{\rm prim}(x)|
\le t^8\frac{S_6(r)^2-\sum_{n=0}^7B_nr^n}{r^8}
\quad(0\le t=\sqrt Q\le r).
\]
Retaining B7 in the subtracted polynomial is essential.

At r=1/20, the upper evaluation U6 of S6(r) gives
\[
\frac{U_6^2-\sum_{n=0}^7B_nr^n}{r^8}
=42354.2144769\ldots <42355.
\]
The equality is a decimal display of a full rational upper enclosure, stored in the certificate. Thus
\[
\boxed{|R_{\ge8}^{\rm prim}|\le42355 Q^4\quad(Q\le1/400).}
\]

The producer bounds Psi at a nonnegative rational u by summing through n=24 and appending
\[
\frac{2(au)^{25}}{25!}\frac1{1-au/26}.
\]
Every step is rounded upwards to the rational grid 10^-80. All evaluated arguments satisfy 0<=au<1. The validator separately bounds the exponential and sinh tails through degree 28, checking each upper step without importing the producer.

## 5. Remainder and contraction inequalities

For r=1/20,
\[
\frac{6671}{5000}+\frac{3567}{1000}r+42355r^2
=107.40005<108.
\]
This proves the announced \(C_{6,\rm rad}^{\rm prim}\).

Retaining all three exact-degree bounds gives
\[
\frac{16931}{10000}r+\frac{6671}{5000}r^2
+\frac{3567}{1000}r^3+42355r^4
=\frac{2825241}{8000000}
=0.353155125<\frac12.
\]
Even the rounded C6 version gives
\[
\frac{16931}{10000}r+108r^2
=\frac{70931}{200000}=0.354655<\frac12.
\]
Both imply the claimed upper and lower contraction inequalities. The lower bound is positive because 1-(3/2)/400>0.

The improvement over the documented baseline is exactly 9-fold in Q-domain, 3-fold in W-radius, and 1560/108=130/9 in the advertised radial constant. These are comparisons of sufficient certificates, not optimality claims.

## 6. Six-phase tube and seed

Define
\[
U=\{0<Q\le1/625\},\qquad U_T=\bigcup_{j=0}^5T^j(U).
\]
The outward rational recursion at sqrt(qin)=1/25 gives
\[
\max_{0\le j\le5}S_j(1/25)<47/1000<1/20.
\]
The maximum displays as 0.04632613708... . Consequently,
\[
0<Q(y)<2209/1000000<1/400\quad(y\in U_T),
\qquad T(U_T)\subseteq U_T.
\]
Indeed F(U) is a subset of U, and no intermediate point can equal zero since T(0)=0 and Q(Fx)>0. The entire tube has |rho|,|eta|< (7/6)(47/1000)<0.06, well inside a local lifted phase chart.

The exact seed \((1/100,1/250)\) has
\[
Q_0=19/250000<1/625,
\qquad\frac{q_{\rm in}}{Q_0}=\frac{400}{19}=21.0526\ldots.
\]
The review's '12x' seed margin is not the ratio of its stated Q values. This numerical wording does not affect the membership proof.

## 7. Consequences and exclusions

For block amplitudes in the contraction domain,
\[
q_m\le\frac{q_0}{1+(q_0/2)m},\quad
\sum_{m\ge0}q_m^2\le2q_0,\quad
\sum_{m\ge0}q_m^3\le2q_0^2.
\]
These follow by reciprocal comparison and telescoping. Every trajectory in the six-phase tube tends to the origin and no nonzero periodic trajectory is contained there.

This proves neither the additional angular inequalities needed to instantiate GAP-LOCK on the same domain, nor an interval enclosure of a saddle manifold, nor a full-map memory theorem. Nonlinear normalized amplitude is not identified with primitive Q. The domain is sufficient, not optimized.
