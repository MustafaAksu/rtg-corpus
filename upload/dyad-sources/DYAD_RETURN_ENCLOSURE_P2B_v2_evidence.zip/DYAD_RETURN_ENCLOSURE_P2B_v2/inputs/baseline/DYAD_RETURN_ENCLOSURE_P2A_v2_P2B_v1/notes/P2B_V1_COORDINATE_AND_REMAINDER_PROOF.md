# P2-B v1 — explicit inverse domain and normalized vector remainder

**Date:** 2026-09-21.  
**Status:** New working proof/certificate by ChatGPT, with two arithmetic implementations. Not a result already present in Claude's review; not owner-adopted and no DSN or RID changed.  
**Inputs:** the selected primitive T, the rederived P1 direct-polynomial normalizer through degree 6, and the coefficientwise analytic majorant verified in P2-A v2.  
**Convention:** W=h(z,bar z), additive polynomial h, resonant coefficients of each h_n fixed to zero by the one-step homological equation. This is not the archival return-log projection.

## 1. Objects and claim

Let F_W be the exact six-step primitive return in the *linear* W-frame. Let h be the exact degree-six polynomial in `outputs/certificate.json`, rederived from
\[
f\circ h=h\circ n+O(|z|^7).
\]
For example,
\[
h_2=-\frac{1+i\sqrt3}{12}z^2-\frac13z\bar z
+\frac{1-i\sqrt3}{24}\bar z^2.
\]
All h3,...,h6 are included in the exported exact coefficient dictionary; h3 is not zero.

Define
\[
\widehat F=h^{-1}\circ F_W\circ h,
\quad J(z)=z+\mu z^2\bar z+a_{32}z^3\bar z^2+a_{05}\bar z^5,
\]
\[
\mu=-\frac12-\frac{2i\sqrt3}{3},\qquad
 a_{32}=-\frac{97}{432}+\frac{197i\sqrt3}{324},\qquad
 a_{05}=-\frac{49}{8640}-\frac{307i\sqrt3}{25920}.
\]
The result is
\[
\boxed{
|\widehat F(z)-J(z)|\le8000|z|^7,
\qquad
\|D\widehat F(z)-DJ(z)\|_2\le60000|z|^6
\quad(|z|\le1/40).
}
\]
Derivatives are real R2 derivatives with the Euclidean norm identified with complex modulus. No assertion of holomorphicity in z alone is made; h depends on bar z.

## 2. Coordinate majorant

Write h=id+u. The coefficient-modulus sums of h are bounded by
\[
M(s)=\frac7{12}s^2+\frac{39}{500}s^3+\frac{14}{125}s^4
+\frac{11}{250}s^5+\frac1{20}s^6.
\]
Set H(s)=s+M(s). Then on any real disk of radius R,
\[
|u(z)|\le M(|z|),\quad
\|Du(z)\|_2\le M'(|z|),\quad
\|D^2h(z)\|\le M''(|z|).
\]
These follow termwise from a monomial z^a bar(z)^b of total degree n: its first and second directional derivatives are bounded by n|c|s^(n-1) and n(n-1)|c|s^(n-2).

At R=1/10, exact rational arithmetic gives
\[
\kappa:=M'(R)=\frac{358439}{3000000}<\frac18,
\]
\[
R-M(R)=0.09407697666\ldots>\sigma:=9/100,
\quad M(R)/R<1/16,
\quad M''(R)=\frac{368381}{300000}.
\]
The displayed decimals are not used as acceptance bounds.

## 3. Inverse-domain proof without a formal-only inversion

For z1,z2 in the convex closed disk D_R, integration along their segment gives
\[
|h(z_1)-h(z_2)|\ge(1-\kappa)|z_1-z_2|.
\]
Thus h is injective there. For each |w|<=sigma, the map
\[
z\mapsto w-u(z)
\]
sends D_R strictly into itself since sigma+M(R)<R, and has Lipschitz constant at most kappa<1. Its unique fixed point is h^-1(w). This supplies an actual inverse, not only a formal inverse series.

Consequently, on the entire target disk |w|<=9/100,
\[
\|Dh^{-1}(w)\|_2\le\frac1{1-\kappa}<\frac87,
\qquad
\|Dh^{-1}(w)-I\|_2\le\frac{\kappa}{1-\kappa}<\frac17.
\]
Moreover, for |z|<=1/10,
\[
\boxed{\frac{15}{16}|z|\le|h(z)|\le\frac{17}{16}|z|.}
\]
In particular,
\[
\boxed{
\frac{225}{256}|z|^2\le
Q_{\rm prim}(\mathcal L^{-1}h(z))
\le\frac{289}{256}|z|^2.
}
\]
These are comparison inequalities, not an equality of observables.

Using a rational interior radius avoids the need to locate the algebraic maximum of s-M(s). The review's scalar inversion proposal is a route to sharper domains, not a prerequisite for this sufficient certificate.

## 4. Raw vector tail

Write
\[
F_W=P+R^{\rm prim}_{7,\rm vec},\qquad P=\mathcal J_{\le6}F_W.
\]
With the same nonnegative S6 series as P2-A, put s_n=[t^n]S6(t). At r_W=1/20, outward rational evaluation proves
\[
K^{\rm prim}_{7,\rm vec}:=
\frac{S_6(r_W)-\sum_{n=0}^6s_nr_W^n}{r_W^7}
<5600.
\]
The stored rational upper bound displays as 5533.62764796... . Therefore
\[
|R^{\rm prim}_{7,\rm vec}(w)|\le5600|w|^7
\quad(|w|\le1/20).
\]
This is a raw vector bound, distinct from the radial C6 and the final normalized C7.

For |w|/r_W<=7/8, termwise coefficient majorization also gives
\[
\|DR^{\rm prim}_{7,\rm vec}(w)\|_2\le7\cdot5600|w|^6.
\]
Indeed n alpha^(n-7)<=7 for every n>=7 when alpha<=7/8, so the weighted derivative tail is bounded by 7 times the tail sum at r_W. A function remainder bound alone would not imply this derivative bound; the coefficientwise majorant and radius separation do.

## 5. The finite polynomial defect must be included

The crucial correction to the abbreviated route in the review is
\[
E(z):=F_W(h(z))-h(J(z))
=R^{\rm prim}_{7,\rm vec}(h(z))+D_{\rm poly}(z),
\]
where
\[
D_{\rm poly}=P\circ h-h\circ J.
\]
The formal conjugacy verifies Dpoly has no terms of degree <=6. It is nevertheless **not identically zero**. For instance,
\[
[D_{\rm poly}]_{(0,7)}=\frac{31}{9720}-\frac{77}{19440}i\sqrt3\ne0.
\]
Multiplying a raw-tail constant by inverse Lipschitz constants alone omits this term.

The following positive polynomials bound the moduli of homogeneous coefficients:
\[
P^+(s)=s+\frac{1259}{1000}s^3+\frac{173}{100}s^4
 +\frac{469}{500}s^5+\frac{248}{125}s^6,
\]
\[
J^+(s)=s+\frac{1259}{1000}s^3+\frac{1099}{1000}s^5.
\]
Define the explicitly computed finite polynomial
\[
\mathcal D(s)=[P^+(H(s))+H(J^+(s))]_{\ge7}.
\]
It coefficientwise majorizes Dpoly and is of degree at most 36. Its removal of low degrees is justified by the independently checked **exact cancellation** of the actual Dpoly, not by subtracting a signed jet from a scalar upper bound.

At r_z=1/40,
\[
C_{\rm poly}:=\mathcal D(r_z)/r_z^7
=15.8181113166\ldots<16,
\]
\[
|D_{\rm poly}(z)|\le C_{\rm poly}|z|^7,
\qquad
\|DD_{\rm poly}(z)\|_2
\le\mathcal D'(r_z)|z|^6/r_z^6.
\]
The latter constant displays as 111.27449959... . All coefficients and comparisons are rational and exported.

## 6. Domain closure for every composition

The certificate verifies
\[
H(r_z)=0.0253658462752\ldots<r_W,
\qquad J^+(r_z)=0.0250196826074\ldots<R,
\]
\[
S_6(H(r_z))<0.029<\sigma,
\qquad H(J^+(r_z))<0.026<\sigma.
\]
The implementation checks the stronger underlying rational inequalities directly against sigma; the rounded decimal envelopes here are auxiliary displays.

Thus F_W(h(z)) and h(J(z)) both lie in the proven inverse target disk, while J(z) lies in the injectivity disk. It follows that h^-1(h(J(z)))=J(z), and the exact normalized map is well-defined on |z|<=r_z. Also H(r_z)/r_W<7/8, as required for the raw derivative tail.

## 7. Normalized remainder

Let b=H(r_z)/r_z, L=8/7. The co-Lipschitz bound on h gives
\[
|\widehat F(z)-J(z)|
\le L|E(z)|
\le L(5600b^7+C_{\rm poly})|z|^7.
\]
Exact rational calculation gives
\[
L(5600b^7+C_{\rm poly})
=7103.16841427\ldots<8000.
\]
This establishes the claimed normalized C7 including the finite polynomial defect.

## 8. First-derivative remainder

On |z|<=r_z,
\[
\|DE(z)\|_2\le C_{E,6}|z|^6,
\]
\[
C_{E,6}=7\cdot5600\,b^6H'(r_z)+\mathcal D'(r_z)/r_z^6.
\]
Differentiate h(hatF)=h(J)+E:
\[
D\widehat F-DJ
=Dh(\widehat F)^{-1}
\{[Dh(J)-Dh(\widehat F)]DJ+DE\}.
\]
Both J(z) and hatF(z) lie in D_R. Hence
\[
\|D\widehat F-DJ\|_2
\le L\left[C_{E,6}+M''(R)\,8000\,r_z(J^+)'(r_z)\right]|z|^6.
\]
The full rational coefficient displays as 50722.0032957... <60000. This proves the first-derivative remainder, not every possible higher-derivative bound a later application might require.

## 9. A conjugate invariant sub-tube containing the seed

To keep every future evaluation inside |z|<=1/40, use the smaller primitive base
\[
U'=\{0<Q_{\rm prim}\le1/2500\},\qquad
U'_T=\bigcup_{j=0}^5T^j(U').
\]
P2-A v2 applies to this subset. Its phase-image majorants satisfy
\[
\max_{0\le j\le5}S_j(1/50)=0.02146332471\ldots,
\qquad \frac{16}{15}\max_jS_j(1/50)<1/40.
\]
Therefore
\[
\widehat U_T=h^{-1}(\mathcal L(U'_T))
\]
is an invariant conjugate tube entirely inside the normalized evaluation domain. The exact primitive seed (1/100,1/250) lies in U', so its unique transformed state belongs to this tube. This argument does not assign the primitive seed coordinates directly to z.

For z_m in the tube and q_m=Qprim(L^-1 h(z_m)),
\[
\sum_m|z_m|^6\le(16/15)^6\sum_m q_m^3
\le2(16/15)^6 q_0^2.
\]
This summability is an input to possible downstream error estimates. It is not the comparison of two different dynamical histories needed for a full retained-memory theorem.

## 10. Remaining open scope

The new local inverse-domain, value-remainder, and first-derivative bounds are proved for the stated polynomial normalizer and domains. They do not close RECOG's unstable-manifold entry certificate, full-map memory theorem, or every coordinate/observable/backbone import in R11. The additional angular inequalities for a quantitative GAP-LOCK instantiation remain separate. No owner DSN or official result status has been changed, and no independent Claude review of this P2-B result is claimed.
