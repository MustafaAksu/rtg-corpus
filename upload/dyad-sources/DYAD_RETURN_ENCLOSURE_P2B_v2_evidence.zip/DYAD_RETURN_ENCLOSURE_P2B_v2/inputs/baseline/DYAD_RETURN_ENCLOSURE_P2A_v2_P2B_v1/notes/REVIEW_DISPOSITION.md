# Review disposition and correction record

**Date:** 2026-09-21. **Status:** Working record; not an owner DSN amendment. The immediately preceding ontology-finalization request was explicitly withdrawn by the user and is not acted on.

## 1. Unsupported earlier deliverable: withdrawn, not proved false

An earlier assistant message advertised C6=64, qctr=1/256, qin=1/1024 and a bound displaying as 53.3157. The subsequently delivered same-named proof/archive instead documented C6=1560, qctr=1/3600, qin=1/10000. The earlier stronger **certification claim is withdrawn as an unsupported delivery record**. It must not be imported on the authority of that message. No source DSN is changed by this correction.

The documented 1560 version was rerun here unchanged in a separate extraction directory: 24 producer checks and 19 independent-validator checks pass. Original input archives remain unchanged. The new package is given a distinct versioned filename; it does not overwrite that proof or silently replace its constants.

Two sufficient bounds on different domains would not be mathematically inconsistent if both were proved. The failure was supplying incompatible release descriptions without their corresponding evidence. Withdrawal is not a counterexample to the 64 inequality.

### Power-count qualification to the review

The review's numerical 375 argument does not disprove the stronger bound. If F_W=P+R, |R|<=6000 t^7, and |P|<=A_P t, then the correct radial conversion is
\[
\big||F_W|^2-|P|^2\big|
\le12000 A_P t^8+36000000 t^{14}.
\]
After division by t^6, its leading bound is 12000 A_P t^2, not 6000 t. At t=1/16 the former is 46.875 A_P. Other exact radial terms must also be included. A looser upper bound exceeding 64 cannot itself prove that 64 is impossible. This qualification does not repair the missing original delivery and is not used to reintroduce the withdrawn constant set.

## 2. Signed-jet sharpening: independently reproduced and made rigorous

The nonzero degree-7 polynomial in the corrected review is reproduced exactly. Its earlier reported zero was a truncation artifact and is not retained. The rational ceilings 1.6931, 1.3342, and 3.5670 are proved from squared coefficient moduli. The majorant is used only from radial degree 8. At r=1/20 the rigorously upward-rounded K8 is <42355, yielding the new sole operative P2-A v2 set
\[
(C^{\rm prim}_{6,\rm rad},q_{\rm ctr},q_{\rm in},c)=(108,1/400,1/625,1/2).
\]
The older 1560 certificate remains valid but is not the active profile of this revision. Domain gain relative to it is exactly 9 in Q, 3 in W radius; the advertised constant improves by 130/9. The seed's qin/Q ratio is 400/19, approximately 21.05, not 12.

The reviewer’s observed phase maximum and high-degree numeric remainder sizes were not used as proof bounds. The thin old fallback margin remains valid in exact arithmetic; the new proof has a larger explicit margin and does not use that fallback.

## 3. Raw 47/54 versus asymptotic/normalized identification

The raw radial coefficient [W^3 V^3] DeltaQ6 is 47/54. This validates that coefficient and its fixed-radius uniform-angle average. It does not independently prove an asymptotic backbone recursion or identify primitive Q with a nonlinear-normalized amplitude. The audit's earlier separation of these objects remains in force.

## 4. P2-B route: sufficient machinery, but not an already completed certificate

The scalar-majorant inverse route is mathematically useful. For a polynomial h(z,bar z), all derivative and inverse statements must be interpreted as real R2 maps (or as a paired complexification), not by holomorphic-in-z inversion. A rational interior disk with M'(R)<1 suffices and avoids computing the maximal algebraic radius.

The abbreviated normalized-C7 formula in the review omits the finite polynomial defect
\[
D_{\rm poly}=J_{\le6}F_W\circ h-h\circ J_{\le6}\widehat F.
\]
It has vanishing terms through degree 6 but is nonzero at degree 7. Hence raw-tail transport and inverse Lipschitz constants alone do not finish the estimate. Actual composition-domain inclusion and derivative remainder estimates are also required.

The present P2-B v1 proof supplies all three explicitly: inverse-domain existence by contraction mapping, a coefficientwise bound on Dpoly, and first-derivative control by the differentiated conjugacy equation. This is **new work in this package**; the reviewer did not approve or verify these new constants.

## 5. Present evidence boundary

Delivered: explicit primitive radial bounds and tube; normalizer inverse/coordinate bounds; normalized vector C7 and first-derivative remainder; a smaller conjugate invariant tube containing the exact rational seed.

Not delivered: RECOG manifold-entry theorem, full-map retained-memory theorem, GAP-LOCK's additional angular inequalities on the explicit numerical domain, optimal domains, higher-derivative bounds not stated, original historical Phi1 byte identity, or official DSN/RID changes.

The independent validator is a separate arithmetic implementation of this proof using the supplied reviewer backend and a different majorant recurrence/tail evaluator. It is not a new independent external review or a claim of reviewer participation in this release.
