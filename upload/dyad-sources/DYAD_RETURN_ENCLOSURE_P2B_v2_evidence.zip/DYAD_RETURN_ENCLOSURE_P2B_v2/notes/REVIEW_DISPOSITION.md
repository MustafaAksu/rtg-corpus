# Disposition of Claude's P2-A v2 / P2-B v1 review

**Date:** 22 September 2026. **Record type:** noncanonical review disposition and new-work boundary.

## Accepted review findings

The attached review is an explicit independent-verification record for P2-A v2 and P2-B v1. Its described reconstruction, constants, inverse-domain argument and finite-defect correction agree with the delivered proofs. P2-A v2 is retained as the primitive profile in this working package. P2-B v1 remains a verified weaker profile; neither old archive is overwritten.

The three accepted corrections remain recorded: the vector-tail/radial-tail degree distinction; seed ratio 400/19; and the necessary nonzero finite conjugacy defect. The earlier 64/256/1024 delivery remains withdrawn for lack of a delivered proof, not falsified.

The review's high-order vector-jet sharpening is implemented here as **new P2-B v2 work**. The normalizer remains the same degree-six polynomial, so the improvement does not change coordinate conventions or quintic coefficients. The local inverse theorem is retained, with all new composition domains checked.

## Two qualifications to the motivation, not to the verified certificates

1. The tail-dominance conclusion is right, but the quoted 87% compares a pre-inverse term with a post-inverse total. In the v1 formula `L*(raw+poly)`, `L=8/7`, the terms are `raw=6199.454251...` and `poly=15.818111...`. The raw share is therefore `raw/(raw+poly)=99.745496...%`, not 87%. This changes no certificate.
2. A better normalized C7 directly helps the local memory/error budget. RECOG's global saddle-manifold entry problem still needs validated continuation into an attracting region; it is not established merely by a smaller C7 or a larger normalized evaluation disk. The primitive contraction profile has not changed in this response.

The old sub-tube base `Qprim<=1/2500` was a sufficient choice imposed by the normalized evaluation radius, not a contraction limit. The new package checks (rather than assumes) that the whole P2-A v2 base `Qprim<=1/625` and its six images fit in the enlarged normalized disk.

## New version boundaries

| Item | Provenance / state |
|---|---|
| P2-A v2, C6prim=108, qctr=1/400, qin=1/625 | Existing result, independently verified in supplied review; rerun algebraically here |
| P2-B v1, C7=8000 and derivative 60000 on radius 1/40 | Existing result, independently verified in supplied review |
| P2-B v2, enlarged C7=100 and derivative 1000 on radius 1/20 | New proof and two arithmetic implementations in this response; no external review claimed |
| P2-B v2, tighter C7=30 and derivative 250 on radius 1/40 | Second radius-indexed profile of the new proof |
| Owner adoption / RID assignment | Not performed |
| RECOG entry and full-map memory; GAP-LOCK angular domain | Open |
| Historical Phi1 output byte identity; optimality | Open |

The review's expectation about attainable constants was a forecast, not a certificate. The new numerical claims come from exact-rational computations and their separate validation. The signed vector jet was extended to degree nine, but h was not extended: this is a certificate improvement in a fixed chart.
