# P2-B v2 — signed-vector-jet sharpening with a fixed normalizer

**Date:** 22 September 2026.  
**Author of the new derivation and package:** ChatGPT.  
**Status:** `[ALG]` working proof with executable exact-rational certification and a second arithmetic implementation; not an owner-DSN amendment, not an assigned owner RID, and not an external review of v2.  
**Review provenance:** `inputs/DYAD_P2A_V2_P2B_V1_REVIEW.md` independently verifies **P2-A v2 and P2-B v1**, not the new P2-B v2 calculation.  
**Unchanged primitive profile:** P2-A v2, `(C6_prim_rad,q_ctr,q_in,c)=(108,1/400,1/625,1/2)`.

## 1. Exact objects and the two certified profiles

The selected map is
\[
T(\rho,\eta)=(\rho-\sin\eta,\ \eta+e^\rho-1-\sin\eta),\quad F=T^6.
\]
Use the lifted local linear coordinate
\[
W=\mathcal L(\rho,\eta)=\rho-\eta/2+i\sqrt3\,\eta/2,
\quad Q_{\rm prim}=|W|^2.
\]
Let `F_W=L o F o L^{-1}`. The **same exact degree-six additive polynomial** `h` as P2-B v1 is retained. It is determined by the one-step homological construction with resonant coefficients of each `h_n` set to zero. In particular,
\[
h(z)=z+h_2+\cdots+h_6,\qquad
h_2=-\frac{1+i\sqrt3}{12}z^2-\frac13z\bar z
+\frac{1-i\sqrt3}{24}\bar z^2.
\]
No degree-seven, eight, or nine coordinate corrections are added. All 23 nonzero coefficients of `h` are provided as exact pairs of rational numbers in `outputs/certificate.json`.

Define the actual locally conjugated map and its degree-six jet:
\[
\widehat F=h^{-1}\circ F_W\circ h,\quad
J(z)=z+\mu z^2\bar z+a_{32}z^3\bar z^2+a_{05}\bar z^5,
\]
\[
\mu=-\frac12-\frac{2i\sqrt3}{3},\quad
 a_{32}=-\frac{97}{432}+\frac{197i\sqrt3}{324},\quad
 a_{05}=-\frac{49}{8640}-\frac{307i\sqrt3}{25920}.
\]
The two independently checkable bounds are:

| Profile | Normalized disk | Value remainder | First real-derivative remainder |
|---|---|---|---|
| **Enlarged** | `|z| <= 1/20` | `|hatF-J| <= 100 |z|^7` | `||DhatF-DJ||_2 <= 1000 |z|^6` |
| **Small / tighter constant** | `|z| <= 1/40` | `|hatF-J| <= 30 |z|^7` | `||DhatF-DJ||_2 <= 250 |z|^6` |

These are different, explicitly radius-indexed profiles of one proof, not competing claims for an unspecified common domain. They both concern the fixed polynomial `h`, not a projected-log dynamical model. Derivatives are real R2 derivatives and the norm is Euclidean, identified with complex modulus.

## 2. Independent exact jet construction through degree nine

The producer constructs the one-step map directly in the linear W-frame from the displayed T, then composes it six times in Q(chi), `chi^2=-3`, retaining total degree nine. The second implementation first composes T in real `(rho,eta)` coordinates, then changes frame. It uses the reviewer's Q/P arithmetic backend, not the producer's kernel.

All 48 one-step coefficients and all 46 nonzero six-step coefficients through degree nine agree exactly. Both implementations independently solve for `h` through degree six; its complete dictionary and `J` are identical to the verified baseline.

Write
\[
F_W=P+F_7+F_8+F_9+R^{\rm prim}_{\ge10,\rm vec},
\qquad P=\mathcal J_{\le6}F_W.
\]
Here `F_d` denotes a homogeneous vector term, represented by one complex component; its conjugate gives the other component of the complexified real map. Exact coefficient-modulus sums give the following rational ceilings:
\[
|F_7(W)|\le b_7|W|^7,\quad b_7=\frac{2079}{1000},
\]
\[
|F_8(W)|\le b_8|W|^8,\quad b_8=\frac{577}{500},
\]
\[
|F_9(W)|\le b_9|W|^9,\quad b_9=\frac{1763}{1000}.
\]
For reference, the computed upward sums display as `2.078832243`, `1.1531146037`, and `1.7621475456`. Every comparison is made with rational square-root enclosures of `sqrt(a^2+3b^2)`, not those decimal displays. The polynomial signs and six-step cancellations are retained before these sums are formed.

## 3. Analytic remainder begins at degree ten

As in the verified baseline, put
\[
a=\frac76>\frac2{\sqrt3},\quad
\Psi(t)=t+(e^{at}-1-at)+(\sinh(at)-at),\quad
S_0(t)=t,\quad S_{j+1}(t)=\Psi(S_j(t)).
\]
The inverse coordinate rows have coefficient-modulus sum `2/sqrt(3)`. Nonlinear primitive terms are consequently bounded coefficientwise by `Psi`; the linear eigenvalue has modulus one and is retained exactly as `t`. Thus `S_6` majorizes both complexified vector components and their homogeneous coefficient sums.

Let `s_n=[t^n]S_6(t)`. Set
\[
r_W=\frac1{16}.
\]
Outward rational evaluation proves
\[
K_{10}^{\rm vec}(r_W):=
\frac{S_6(r_W)-\sum_{n=0}^{9}s_n r_W^n}{r_W^{10}}
<332000.
\]
The rational upper enclosure displays as `331449.87164192495...`. It is computed by finite exponential/sinh series, analytic geometric bounds on their omitted positive tails, and upward rounding to rational endpoints. The independent validator uses a different coefficient recurrence and separate exp/sinh tail bounds.

Since every omitted scalar coefficient is nonnegative,
\[
\boxed{|R^{\rm prim}_{\ge10,\rm vec}(W)|\le332000|W|^{10}
\quad(|W|\le1/16).}
\]
This constant is not itself the requested normalized C7. Its contribution to a seventh-order bound has a factor `|W|^3`.

### Derivative tail

For `t/r_W <= 10/11`,
\[
n(t/r_W)^{n-10}\le10\quad(n\ge10).
\]
For example, the ratio of consecutive left sides is `(1+1/n)t/r_W <= 1`. Termwise differentiation of the convergent coefficient majorant therefore yields
\[
\|DR^{\rm prim}_{\ge10,\rm vec}(W)\|_2
\le10\cdot332000|W|^9.
\]
The finite homogeneous terms have their own derivative bounds `d b_d |W|^{d-1}`. No derivative estimate is inferred by differentiating a pointwise norm inequality.

## 4. Coordinate and inverse domains stay unchanged

Use
\[
M(s)=\frac7{12}s^2+\frac{39}{500}s^3+\frac{14}{125}s^4
+\frac{11}{250}s^5+\frac1{20}s^6,\qquad H(s)=s+M(s).
\]
All homogeneous coefficient ceilings of `h-id` are independently rechecked. At `R=1/10`,
\[
\kappa=M'(R)=\frac{358439}{3000000}<\frac18,
\quad \sigma=\frac9{100}<R-M(R),
\quad \frac{M(R)}R<\frac1{16}.
\]
Consequently `h` is injective on the closed disk of radius `R`, by integration of `Dh-I` along segments. For `|W|<=sigma`, the map `z -> W-(h(z)-z)` is a self-map and contraction on that disk. It supplies the actual inverse, with
\[
\|Dh^{-1}\|_2<\frac87=:L,
\quad \|Dh^{-1}-I\|_2<\frac17,
\quad M''(R)=\frac{368381}{300000}.
\]
The fixed observable comparison is
\[
\frac{15}{16}|z|\le|h(z)|\le\frac{17}{16}|z|,
\]
\[
\boxed{\frac{225}{256}|z|^2\le Q_{\rm prim}(\mathcal L^{-1}h(z))
\le\frac{289}{256}|z|^2.}
\]
Again, `Qprim` is not identified exactly with `|z|^2`.

## 5. The finite polynomial defect remains included

Define
\[
D_{\rm poly}=P\circ h-h\circ J.
\]
The exact low-degree identity proves `Dpoly` has no terms of degree <=6. It is not identically zero:
\[
[D_{\rm poly}]_{(0,7)}=\frac{31}{9720}-\frac{77i\sqrt3}{19440}.
\]
Use the unchanged positive polynomial ceilings
\[
P^+(s)=s+\frac{1259}{1000}s^3+\frac{173}{100}s^4
+\frac{469}{500}s^5+\frac{248}{125}s^6,
\]
\[
J^+(s)=s+\frac{1259}{1000}s^3+\frac{1099}{1000}s^5,
\]
\[
\mathcal D(s)=[P^+(H(s))+H(J^+(s))]_{\ge7}.
\]
This finite degree-at-most-36 polynomial majorizes `Dpoly` coefficientwise after the *actual* low-degree cancellation has been established. It is the same polynomial as in P2-B v1, but must be reevaluated at the enlarged radius.

At `r=1/20`,
\[
C_{\rm poly}(r)=\frac{\mathcal D(r)}{r^7}
=16.3789597879\ldots<17,
\]
\[
D_{\rm poly,6}(r)=\frac{\mathcal D'(r)}{r^6}
=115.8013886962\ldots<116.
\]
In particular, the old `Cpoly<16` at `r=1/40` is **not reused** on the larger disk.

## 6. All compositions fit the inverse domain

For the enlarged profile `r=1/20`, let `x=H(r)` and `b=x/r`. Exact rational comparisons establish
\[
x=0.05146879786458\ldots<r_W=1/16,
\quad x/r_W=0.8235007658\ldots<10/11,
\]
\[
J^+(r)=0.0501577184375<1/10,
\]
\[
S_6(H(r))<0.065234<\sigma,
\quad H(J^+(r))<0.051636<\sigma.
\]
All displayed decimal envelopes are finite rational upper bounds; the full stored rational endpoints are what the executables compare. Thus `F_W(h(z))` and `h(J(z))` lie in the inverse target disk; `J(z)` lies in the injectivity disk. This proves `h^{-1}(h(J(z)))=J(z)` on the whole evaluation domain.

Keeping the old raw radius `1/20` would not suffice: `H(1/20)>1/20`. The larger raw evaluation radius is an essential explicit part of this certificate. It is **not** a new primitive contraction radius.

## 7. Value and first-derivative constants

Let `K=332000`, and for `x=H(r)` define
\[
A(x)=b_7+b_8x+b_9x^2+Kx^3,
\]
\[
B(x)=7b_7+8b_8x+9b_9x^2+10Kx^3.
\]
The exact pre-inverse defect is
\[
E(z)=F_W(h(z))-h(J(z))
=D_{\rm poly}(z)+\sum_{n=7}^{9}F_n(h(z))
+R^{\rm prim}_{\ge10,\rm vec}(h(z)).
\]
Coefficient positivity implies `H(t)/t <= H(r)/r=b` for `0<t<=r`. Hence
\[
|E(z)|\le[A(x)b^7+C_{\rm poly}(r)]|z|^7,
\]
\[
\|DE(z)\|_2\le[B(x)b^6H'(r)+D_{\rm poly,6}(r)]|z|^6.
\]
Apply the inverse Lipschitz bound:
\[
|\widehat F-J|\le L[A(x)b^7+C_{\rm poly}(r)]|z|^7.
\]
For the enlarged disk, the coefficient is exactly the rational number stored in the report and displays as
\[
85.0731933471\ldots<100.
\]
Differentiate `h(hatF)=h(J)+E`:
\[
D\widehat F-DJ=Dh(\widehat F)^{-1}
\{[Dh(J)-Dh(\widehat F)]DJ+DE\}.
\]
Both arguments lie in the convex injectivity disk. With the advertised `C7=100`,
\[
\|D\widehat F-DJ\|_2\le
L\left[B(x)b^6H'(r)+D_{\rm poly,6}(r)
+M''(R)\,100\,r(J^+)'(r)\right]|z|^6.
\]
The coefficient displays as `812.8936249483... < 1000`.

Repeating the same rational calculation at `r=1/40` gives `27.6022209836... < 30` and, using `C7=30`, `216.7664114280... < 250`. These give the small profile in section 1.

## 8. The full P2-A v2 tube is now admitted

The primitive contraction result is unchanged. Set
\[
U=\{0<Q_{\rm prim}\le1/625\},\qquad U_T=\bigcup_{j=0}^{5}T^j(U).
\]
The independently rechecked P2-A estimate is
\[
\max_{0\le j\le5}S_j(1/25)=0.04632613708\ldots<47/1000.
\]
Its inverse-coordinate bound satisfies
\[
\boxed{\frac{16}{15}\max_jS_j(1/25)
=0.04941454622\ldots<1/20.}
\]
Thus the **entire original P2-A v2 tube**, not just the former base `Q<=1/2500`, fits inside the enlarged normalized domain:
\[
\widehat U_T=h^{-1}(\mathcal L(U_T))\subset\{|z|<1/20\}.
\]
It is invariant under the conjugated dynamics. The seed `(rho,eta)=(1/100,1/250)` is admitted because
\[
Q_0=19/250000<1/625,\qquad (1/625)/Q_0=400/19.
\]
The old `1/2500` was a sufficient application-domain choice, not a dynamical contraction limit. Enlargement still requires checking inverse and composition domains; it is not inferred from a smaller C7 alone.

## 9. Additional explicit normalized-amplitude corollary

This consequence uses the actual normalized map on its whole certified disk. It is separate from the primitive contraction statement.

For `q=|z|^2`, `z !=0`, write
\[
\widehat F(z)/z=1+\mu q+v,\qquad
|v|\le q^2(A_J+C_7q),\quad A_J=1099/1000.
\]
Set `u=1259/1000 > |mu|`. Since `2 Re(mu)=-1` and `|mu|^2=19/12`,
\[
\big||\widehat F(z)|^2-q+q^2\big|
\le q^3\left[\frac{19}{12}+2(1+uq)(A_J+C_7q)
+q^2(A_J+C_7q)^2\right].
\]
At `q<=1/400`, `C7=100`, the bracket times q is bounded by `0.010724591656 < 1/2`. Therefore
\[
\boxed{0<q-\frac32q^2\le |\widehat F(z)|^2
\le q-\frac12q^2<q\quad(0<q\le1/400).}
\]
The normalized disk is forward invariant under the six-step normalized return. In particular,
\[
q_m\le\frac{q_0}{1+q_0m/2},\qquad
\sum_{m\ge0}q_m^2\le2q_0,\qquad
\sum_{m\ge0}q_m^3\le2q_0^2.
\]
The last two bounds follow from telescoping and `q_m<=q_0`. A corresponding corollary could also have been established for the smaller P2-B v1 disk; no claim that v2 first creates normalized contraction is intended.

These one-orbit estimates do not compare two different dynamical histories and do not prove the retained-memory theorem.

## 10. Evidence and remaining scope

Producer: 67 positive exact-arithmetic checks. Independent implementation: 73 checks. The independent validator imports neither the producer nor its kernel; it reconstructs the full degree-nine primitive jet and solves h itself. This is implementation independence inside this response, not a new external Claude review.

Four negative controls must exit with code 1: an unsupported degree-ten tail bound, an unsupported advertised C7, an unsupported derivative bound, and insertion of raw c05 into J. The first three test certificate acceptance logic; failing to certify them does not prove those smaller bounds mathematically impossible. The last violates the exact low-degree conjugacy identity.

A 90-digit exact-map sanity test checks 36 states and analytic Jacobians. It is numerical and does not enter the uniform proof.

OPEN and unchanged: validated saddle-manifold continuation/entry; full-map retained-memory comparison; additional quantitative GAP-LOCK phase inequalities; historical Phi1 byte identity; optimal bounds. No owner DSN, formal RID, scientific status, or ontology was modified.
