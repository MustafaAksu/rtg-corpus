#!/usr/bin/env python3
"""DYAD -> NUMGEN L-PHASE angular remainder, row A (|z| <= 1/20): exact-rational certificate v0.1.

Target: for every block m of every primitive orbit started in U = {0 < Q <= 1/625},
    phi_hat_{6(m+1)} - phi_hat_{6m} = 2 pi - tau Q_m + r_m,   |r_m| <= C_* Q_m^{3/2},
with Q_m the primitive observable |W_m|^2.  Exact arithmetic in Q(omega), omega = i sqrt3, and Fractions; every
irrational quantity (sqrt3, tau, moduli, pi/2, e^x, (1-x)^{-3/2}) enters through a proved rational ceiling/floor.

Gates
  G-H   provenance: one-step normalizer h, normal form n regenerated exactly (resonant coefficients of h zero) and
        checked against the adopted DYAD-ALG-NF6 data (h2, n21, n32, n05, mu, a32, a05, 23 nonzero coefficients,
        per-degree modulus sums below the adopted M(s) ceilings of DYAD-THM-NF-INV)
  G-L   L_Theta recomputed as D(Im(h2/z))[mu q z] equals the adopted cartesian L_Theta; D3 = 2 Re(zb h2) equals the
        adopted trigonometric D3
  G-D   decomposition, leading order: Im(F4(W) Wb) = Lambda3(W) |W|^2 exactly (F4 = quartic part of the six-step
        return in W), Lambda3 = L_Theta + tau D3
  P-c   branch gate: one-step |W(Tx)/(lambda W) - 1| <= eps < 1/2 on U_T (|W| < 47/1000), so each step angle is in
        (pi/6, pi/2), W never vanishes, and the six-step lifted increment equals 2 pi + Arg(F_W(W)/W); (B2) on row A
  P-L   sup_Theta |Lambda3|/r^3 <= Lbar (rational) by rational points on the unit circle + second-derivative cells
  P-a1  |D_Q| <= c_Q q^{3/2};  P-a2  |D_Q - D3| <= c'_Q q^2  (exact polynomial D_Q of degrees 3..12)
  P-b   |Arg(J/z) + tau q| <= c_J q^2
  P-7   |Arg(Fhat/J)| <= c_7 q^3   (imported C_7 = 100, row A)
  S-T   imported K_Theta = 123/125 (row A)
  FIN   C_* = (1 - c_Q/20)^{-3/2} [Lbar + (K_Theta + tau c'_Q + c_J)/20 + c_7/8000], published as a rational ceiling
Negative controls (each must FAIL)
  N1 sign of S_Theta flipped (Lambda3 := -L_Theta + tau D3) breaks G-D
  N2 tau D_Q omitted (Lambda3 := L_Theta) breaks G-D
  N3 bridge removed: 'q <= Q on row A' is false (D3 < 0 on the positive real axis)
  N4 row-B pins (K_Theta = 909/1000, C_7 = 30) inserted into row A fail the pin gate
  N5 Lbar = 1400/1000 (below the true maximum) fails P-L
  N6 one-step bound inflated by 12 fails the (pi, 3 pi) window of P-c
"""
import sys, json, time
sys.path.insert(0, '.')
from fractions import Fraction as Fr
from math import isqrt
from qw import K, padd, pmul, pscal
from tzw import Tn_zw
t0 = time.time(); perf = {}
OM = K(0, 1)
# ---------------- rational enclosures
def sqrt_hi(x, k=12):                         # rational upper bound for sqrt(x), x >= 0 rational
    x = Fr(x); s = 10 ** k
    return Fr(isqrt(-(-x.numerator * s * s // x.denominator)) + 1, s)
def sqrt_lo(x, k=12):
    x = Fr(x); s = 10 ** k
    return Fr(isqrt(x.numerator * s * s // x.denominator), s)
S3_LO, S3_HI = sqrt_lo(3, 15), sqrt_hi(3, 15)
assert S3_LO * S3_LO < 3 < S3_HI * S3_HI
def mod_hi(c):                                 # |a + b omega| = sqrt(a^2 + 3 b^2)
    return sqrt_hi(c.a * c.a + 3 * c.b * c.b)
def mod_lo(c):
    return sqrt_lo(c.a * c.a + 3 * c.b * c.b)
def re_bounds(c):                              # value interval of a real number p + q sqrt3 (stored as K(p, q))
    lo = c.a + (c.b * S3_LO if c.b >= 0 else c.b * S3_HI); hi = c.a + (c.b * S3_HI if c.b >= 0 else c.b * S3_LO)
    return lo, hi
def exp_hi(x, terms=30):                       # e^x for 0 <= x <= 1, Taylor + geometric tail
    s = Fr(0); t = Fr(1)
    for k in range(terms):
        s += t; t = t * x / (k + 1)
    return s + 2 * t
PI_LO, PI_HI = Fr(314159265, 10 ** 8), Fr(314159266, 10 ** 8)
g_ = {}; neg = {}; data = {}
# ---------------- G-H: normalizer h and normal form n (one-step), exact
NH = 6
f_z, _ = Tn_zw(NH, 1)
lam = K(Fr(1, 2), Fr(1, 2))
def conjp(p): return {(b, a): v.conj() for (a, b), v in p.items()}
def comp(P, X, Y, N):                          # P(X, Y) truncated at total degree N
    mi = max(i for i, j in P); mj = max(j for i, j in P)
    PX = [{(0, 0): K(1)}]; PY = [{(0, 0): K(1)}]
    for _ in range(mi): PX.append(pmul(PX[-1], X, N))
    for _ in range(mj): PY.append(pmul(PY[-1], Y, N))
    r = {}
    for (i, j), v in P.items():
        if i + j <= N: r = padd(r, pscal(pmul(PX[i], PY[j], N), v))
    return r
def kpow(x, e):
    r = K(1)
    for _ in range(e): r = r * x
    return r
h = {(1, 0): K(1)}; n = {(1, 0): lam}
for k in range(2, NH + 1):
    R = padd(comp(f_z, h, conjp(h), k), comp(h, n, conjp(n), k), -1)
    for (a, b), v in sorted(R.items()):
        if a + b != k: continue
        if (a - b - 1) % 6 == 0:
            n[(a, b)] = v
        else:
            d = lam - kpow(lam, a) * kpow(lam.conj(), b)
            h[(a, b)] = -(v / d)
resid = padd(comp(f_z, h, conjp(h), NH), comp(h, n, conjp(n), NH), -1)
h_ok = not resid
h2 = {k: v for k, v in h.items() if sum(k) == 2}
h2_adopted = {(2, 0): K(Fr(-1, 12), Fr(-1, 12)), (1, 1): K(Fr(-1, 3)), (0, 2): K(Fr(1, 24), Fr(-1, 24))}
n_adopted = {(1, 0): lam, (2, 1): K(Fr(1, 8), Fr(-7, 72)), (3, 2): K(Fr(-5, 432), Fr(23, 3888)),
             (0, 5): K(Fr(43, 17280), Fr(-227, 155520))}
Mceil = {2: Fr(7, 12), 3: Fr(39, 500), 4: Fr(14, 125), 5: Fr(11, 250), 6: Fr(1, 20)}
moddeg = {d: sum(mod_hi(v) for k, v in h.items() if sum(k) == d) for d in range(2, 7)}
moddeg_lo = {d: sum(mod_lo(v) for k, v in h.items() if sum(k) == d) for d in range(2, 7)}
# J = n^6 (jet <= 5)
Jz = {(1, 0): K(1)}; nz = n
cur = {(1, 0): K(1)}
for _ in range(6): cur = comp(n, cur, conjp(cur), 5)
mu = K(Fr(-1, 2), Fr(-2, 3)); a32 = K(Fr(-97, 432), Fr(197, 324)); a05 = K(Fr(-49, 8640), Fr(-307, 25920))
J_ok = cur == {(1, 0): K(1), (2, 1): mu, (3, 2): a32, (0, 5): a05}
g_['G-H'] = (h_ok and h2 == h2_adopted and n == n_adopted and len(h) == 23 and J_ok
             and moddeg_lo[2] <= Mceil[2] <= moddeg[2] + Fr(1, 10 ** 9)
             and all(moddeg[d] <= Mceil[d] for d in range(3, 7)))
data['h_nonzero_coefficients'] = len(h)
data['h_modulus_sum_per_degree_ceiling'] = {d: str(moddeg[d]) for d in moddeg}
perf['h'] = round(time.time() - t0, 2)
# ---------------- G-L, G-D with sympy
import sympy as sp
X, Y = sp.symbols('X Y', real=True)
s3 = sp.sqrt(3); I = sp.I
zS = X + I * Y; zbS = X - I * Y
def Kc(c): return sp.Rational(c.a) + sp.Rational(c.b) * I * s3
def poly_eval(P, z, zb): return sum(Kc(v) * z ** a * zb ** b for (a, b), v in P.items())
qS = X ** 2 + Y ** 2
h2S = poly_eval(h2, zS, zbS)
D3S = sp.expand(2 * sp.re(sp.expand(zbS * h2S)))
DT1 = sp.expand(sp.im(sp.expand(h2S * zbS)))            # = q * Im(h2/z)
muS = Kc(mu); V = sp.expand(muS * qS * zS); Vx, Vy = sp.re(V), sp.im(V)
DT1q = DT1 / qS
LT_rec = sp.simplify(sp.diff(DT1q, X) * Vx + sp.diff(DT1q, Y) * Vy)
LT_ad = -s3 / 48 * X ** 3 - sp.Rational(47, 48) * X ** 2 * Y - 7 * s3 / 16 * X * Y ** 2 - sp.Rational(1, 16) * Y ** 3
r_, th = sp.symbols('r theta', positive=True)
D3_trig_ad = r_ ** 3 * (-sp.Rational(5, 6) * sp.cos(th) + s3 / 6 * sp.sin(th) + sp.Rational(1, 12) * sp.cos(3 * th)
                        - s3 / 12 * sp.sin(3 * th))
D3_trig = sp.expand_trig(D3S.subs({X: r_ * sp.cos(th), Y: r_ * sp.sin(th)}))
g_['G-L'] = (sp.simplify(sp.expand(LT_rec - LT_ad)) == 0
             and sp.simplify(sp.expand_trig(sp.expand(D3_trig - sp.expand_trig(D3_trig_ad)))) == 0)
tauS = 2 * s3 / 3
F6z, _ = Tn_zw(4, 6)
F4 = {k: v for k, v in F6z.items() if sum(k) == 4}
F3 = {k: v for k, v in F6z.items() if sum(k) == 3}
lhs = sp.expand(sp.im(sp.expand(poly_eval(F4, zS, zbS) * zbS)))
def gD(Lam): return sp.simplify(sp.expand(lhs - sp.expand(Lam * qS))) == 0
g_['G-D'] = gD(LT_ad + tauS * D3S) and F3 == {(2, 1): mu}
neg['N1'] = gD(-LT_ad + tauS * D3S)
neg['N2'] = gD(LT_ad)
perf['GLD'] = round(time.time() - t0, 2)
# ---------------- trig-polynomial sup certificate (harmonics 1 and 3), coefficients p + q sqrt3
def trig_sup_cert(cA, cB, cC, cD, bound, N=400):
    """sup |cA cos t + cB sin t + cC cos3t + cD sin3t| <= bound ? cX = K(p, q) meaning p + q sqrt3.
    Rational points t = 2 arctan s, s in [-1, 1] (odd harmonics: |g(t + pi)| = |g(t)|)."""
    hi = lambda c: max(abs(re_bounds(c)[0]), abs(re_bounds(c)[1]))
    L2 = hi(cA) + hi(cB) + 9 * (hi(cC) + hi(cD))
    def gval(s):
        c = (1 - s * s) / (1 + s * s); sn = 2 * s / (1 + s * s)
        c3 = 4 * c ** 3 - 3 * c; s3_ = 3 * sn - 4 * sn ** 3
        tot = cA * K(c) + cB * K(sn) + cC * K(c3) + cD * K(s3_)
        lo, hi_ = re_bounds(tot); return max(abs(lo), abs(hi_))
    pts = [Fr(-1) + Fr(2 * i, N) for i in range(N + 1)]
    vals = [gval(s) for s in pts]
    worst = Fr(0)
    for i in range(N):
        dtheta = 2 * (pts[i + 1] - pts[i])        # arctan is 1-Lipschitz, theta = 2 arctan s
        worst = max(worst, max(vals[i], vals[i + 1]) + L2 * dtheta * dtheta / 8)
    return worst <= bound, worst, max(vals)
# Lambda3 / r^3 = -(49 sqrt3/72) cos + (1/24) sin + (23 sqrt3/144) cos3 - (19/48) sin3
LAM = (K(0, Fr(-49, 72)), K(Fr(1, 24)), K(0, Fr(23, 144)), K(Fr(-19, 48)))
Lbar = Fr(1401, 1000)
okL, wL, maxL = trig_sup_cert(*LAM, Lbar, N=400)
g_['P-L'] = okL
neg['N5'] = trig_sup_cert(*LAM, Fr(1400, 1000), N=400)[0]
data['P-L'] = {'Lbar': str(Lbar), 'certified_cell_bound': float(wL), 'max_at_rational_points_lower_estimate': float(maxL)}
# D3 / r^3 = -(5/6) cos + (sqrt3/6) sin + (1/12) cos3 - (sqrt3/12) sin3
D3C = (K(Fr(-5, 6)), K(0, Fr(1, 6)), K(Fr(1, 12)), K(0, Fr(-1, 12)))
D3bar = Fr(774, 1000)
okD3, wD3, maxD3 = trig_sup_cert(*D3C, D3bar, N=400)
perf['trig'] = round(time.time() - t0, 2)
# ---------------- P-a1, P-a2: D_Q = |h|^2 - |z|^2 (degrees 3..12), coefficient moduli at s = 1/20
DQ = padd(pmul(h, conjp(h), 12), {(1, 1): K(1)}, -1)
degs = sorted({sum(k) for k in DQ})
md = {d: sum(mod_hi(v) for k, v in DQ.items() if sum(k) == d) for d in degs}
sA = Fr(1, 20)
D3_from_DQ = {k: v for k, v in DQ.items() if sum(k) == 3}
D3_check = D3_from_DQ == padd(pmul({(0, 1): K(1)}, h2, 3), pmul({(1, 0): K(1)}, conjp(h2), 3))
tail_c = sum(md[d] * sA ** (d - 4) for d in degs if d >= 4)          # c'_Q
cQ = D3bar + sA * tail_c                                               # c_Q = D3bar + sum_{d>=4} m_d s^{d-3}
g_['P-a'] = okD3 and min(degs) == 3 and max(degs) == 12 and D3_check
data['P-a'] = {'D3bar': str(D3bar), 'D3_cell_bound': float(wD3), "c'_Q": float(tail_c), 'c_Q': float(cQ),
               'degree_moduli': {d: float(md[d]) for d in degs}}
# ---------------- P-b: |Arg(J/z) + tau q| <= c_J q^2 on q <= 1/400
qA = Fr(1, 400)
mu_hi = mod_hi(mu); A2 = mod_hi(a32) + mod_hi(a05)
Ub = mu_hi * qA + A2 * qA * qA
lead = re_bounds(K(0, Fr(89, 324)))[1] + mod_hi(a05)             # sup |Im(a32 - mu^2/2) + Im(a05 e^{-6i th})|
imp = (a32 - mu * mu * Fr(1, 2))
assert imp.b == Fr(89, 324)                                       # Im(a32 - mu^2/2) = 89 sqrt3/324 (adopted chart law)
cross = A2 * (2 * mu_hi + A2 * qA) * qA / 2                       # |Im(u^2 - mu^2 q^2)|/2 / q^2
R3 = Ub ** 3 / (3 * (1 - Ub)) / (qA * qA)                         # |Log remainder| / q^2
cJ = lead + cross + R3
g_['P-b'] = Ub < Fr(1, 2) and cJ > 0
data['P-b'] = {'c_J': float(cJ), 'U(1/400)': float(Ub)}
# ---------------- P-7: |Arg(Fhat/J)| <= (pi/2) C7 q^3 / (1 - U)
C7A = Fr(100); KThA = Fr(123, 125)
def pins_ok(radius, C7, KTh): return radius == Fr(1, 20) and C7 == 100 and KTh == Fr(123, 125)
g_['S-T'] = pins_ok(Fr(1, 20), C7A, KThA)
neg['N4'] = pins_ok(Fr(1, 20), Fr(30), Fr(909, 1000))
x7 = C7A * qA ** 3 / (1 - Ub)
c7 = (PI_HI / 2) * C7A / (1 - Ub)
g_['P-7'] = x7 < Fr(1, 2)
data['P-7'] = {'c_7': float(c7)}
# ---------------- P-c: one-step branch gate on U_T (|W| < 47/1000) and (B2) on row A
def branch_gate(scale=1):
    wmax = Fr(47, 1000)
    inv_s3_hi = 1 / S3_LO
    m = 2 * inv_s3_hi * wmax                                      # |rho|, |eta| <= (2/sqrt3)|W|
    e2 = (2 * inv_s3_hi) ** 2 * exp_hi(m) / 2 * (1 + S3_HI) / 2
    e3 = (2 * inv_s3_hi) ** 3 / 6 * (1 + (1 + S3_HI) / 2)
    eps = scale * (e2 * wmax + e3 * wmax * wmax)                  # |W(Tx)/(lambda W) - 1| <= eps
    # arcsin(eps) <= eps/sqrt(1-eps^2); six steps: 6*arcsin(eps) < pi  <=  36 eps^2 < pi_lo^2 (1 - eps^2)
    step_ok = eps < Fr(1, 2)
    six_ok = 36 * eps * eps < PI_LO * PI_LO * (1 - eps * eps)
    return step_ok and six_ok, eps, e2, e3
okc, eps, e2, e3 = branch_gate()
B2 = Ub < Fr(1, 2) and x7 < Fr(1, 2)                              # each Arg < pi/6, sum < pi; nonvanishing
g_['P-c'] = okc and B2
neg['N6'] = branch_gate(12)[0]
data['P-c'] = {'eps_one_step': float(eps), 'c_T (|dT - pi/3| <= arcsin(c_T sqrt Q))': float(e2 + e3 * Fr(47, 1000)),
               'six_step_window_margin_rad': float(PI_LO - 6 * eps / sqrt_lo(1 - eps * eps))}
# ---------------- N3: bridge removed ('q <= Q' on row A) -> false: D3 < 0 at theta = 0
D3_at0 = Fr(-5, 6) + Fr(1, 12)
neg['N3'] = D3_at0 >= 0
# ---------------- FIN
tau_hi = 2 * S3_HI / 3
inner = Lbar + (KThA + tau_hi * tail_c + cJ) / 20 + c7 / 8000
xb = cQ / 20
yb = 1 / (1 - xb)
bridge = yb * sqrt_hi(yb)                                         # >= (1 - c_Q/20)^{-3/2}
Cstar = inner * bridge
Cpub = Fr(-(-Cstar.numerator * 1000 // Cstar.denominator), 1000)  # ceiling to 3 decimals
g_['FIN'] = xb < 1 and Cpub >= Cstar and all(g_.values())
data['FIN'] = {'inner_constant': float(inner), 'bridge_factor': float(bridge), 'C_star_exact_float': float(Cstar),
               'C_star_published': str(Cpub)}
perf['total'] = round(time.time() - t0, 2)
out = {'gates': g_, 'negative_controls_pass_should_be_false': neg, 'data': data,
       'note': 'row A: |z| <= 1/20 (q <= 1/400); block base points from U = {0 < Q <= 1/625}; omega = i sqrt3'}
txt = json.dumps(out, indent=1, sort_keys=True); print(txt)
open('lphase_rowA_certificate.json', 'w').write(txt + '\n'); open('lphase_rowA_perf.json', 'w').write(json.dumps(perf) + '\n')
ok = all(g_.values()) and not any(neg.values()); print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
