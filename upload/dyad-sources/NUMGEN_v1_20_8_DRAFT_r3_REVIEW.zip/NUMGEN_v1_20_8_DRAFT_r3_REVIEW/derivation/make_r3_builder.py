#!/usr/bin/env python3
"""Derive build_v1_20_8_r3.py from build_v1_20_8_r2.py by exact-once string replacements.
Only the declared fact-sync edits change: E01-E05 (edition markers, companion note, status summary),
E16 (L-PHASE OPEN sub-item), E27 (N15 receipt row), E28 (RECOG row), E29 (RRF row), E30 (changelog)."""
import sys
src = open(sys.argv[1], encoding="utf-8").read()
R = []
def rep(a, b): R.append((a, b))

# docstring / output names
rep('"""Build RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r2.md from frozen v1.20.7 by exact-once edits.\n',
    '"""Build RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r3.md from frozen v1.20.7 by exact-once edits.\n\n'
    'r3 (narrow fact synchronization after the co-owner acceptance of r2, 21 Oct 2026; PI choice): Dyadic v6.4.19,\n'
    'RECOG v0.3.22 and RRF v0.8.4 were adopted after r2. Only E01-E05, E16, E27, E28, E29 and E30 change;\n'
    'every other edit is byte-identical to r2. No constant is imported; Dyadic import pins stay at v6.4.18.\n')
rep('OUT = "RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r2.md"', 'OUT = "RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r3.md"')
rep('"v1_20_8_r2_edits.json"', '"v1_20_8_r3_edits.json"')

# E01-E03 edition markers
rep('"# RTG Number Genesis DSN v1.20.8 — DRAFT r2\\n"', '"# RTG Number Genesis DSN v1.20.8 — DRAFT r3\\n"')
rep('"**Date:** October 20, 2026 (DRAFT r2; v1.20.7 dated September 25, 2026)  \\n"',
    '"**Date:** October 21, 2026 (DRAFT r3; v1.20.7 dated September 25, 2026)  \\n"')
rep('"**Document status:** DRAFT r2 — not adopted.', '"**Document status:** DRAFT r3 — not adopted.')

# E04 companion line
rep("`RTG_DYADIC_OSCILLATOR_DSN_v6.4.18` · `RTG_DISCRETE_GENESIS_DSN_v2.12.13` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.9`. `[v1.20.8]` OFN, Dyadic and Genesis pointers were advanced after a claim-level check of every imported statement (§9.1); consumer and reference documents (`RTG_RELATIONAL_RECOGNITION_DSN_v0.3.21`, `RTG_RRF_REPRESENTATION_REGISTRY_v0.8.3`) are recorded in §9.  ",
    "`RTG_DYADIC_OSCILLATOR_DSN_v6.4.18` · `RTG_DISCRETE_GENESIS_DSN_v2.12.13` · `RTG_GENESIS_GEOMETRY_DSN_v2.8.9`. `[v1.20.8]` OFN, Dyadic and Genesis pointers were advanced after a claim-level check of every imported statement (§9.1). The current Dyadic edition is v6.4.19 (adopted 20 Oct 2026, `40c9e63f…6ec9`); it adds the §6.14 L-PHASE row-A theorem and leaves §§2–3, §6.1, §6.4, §6.11 and the DYAD-THM-PRIM-CTR passage byte-identical to v6.4.18, so the import pins stay at v6.4.18 until the L-PHASE import edition. Consumer and reference documents (`RTG_RELATIONAL_RECOGNITION_DSN_v0.3.22`, `RTG_RRF_REPRESENTATION_REGISTRY_v0.8.4`) are recorded in §9.  ")

# E05 status summary
rep("and the explicit L-PHASE constant is registered as an OPEN sub-item pending Dyadic owner adoption, with no constant entered.",
    "and the explicit L-PHASE constant is registered as an OPEN sub-item: Dyadic adopted the row-A theorem in v6.4.19, and its import by RID is deferred to a later NUMGEN edition; no constant is entered.")

# E16 L-PHASE OPEN sub-item
rep("\"`[OPEN]` `[target: THM]` `[v1.20.8]` **L-PHASE explicit constant — Dyadic row-A certificate, owner adoption pending.** An explicit rational `C` on the Dyadic tube `U = {0 < Q_true <= 1/625}` (block base points), with the one-step branch certified on `U_T`, is under Dyadic owner adoption (`DYAD_NUMGEN_LPHASE_ROWA_CERTIFICATE_SESSION_v0_1.md`, `775c6715…f233d`; reviewed at SESSION level). NUMGEN-side interface confirmation I1–I5 and a byte-identical receipt replay are recorded (§9.1 dispositions; execution pins in §9.2). No constant is entered here: the `C` of L-PHASE stays existential until Dyadic adopts the theorem and NUMGEN imports it by RID. An explicit-tube INF-1 would additionally need an explicit L-BACKBONE constant (NUMGEN-side; not started).\\n\\n\"",
    "\"`[OPEN]` `[target: THM]` `[v1.20.8]` **L-PHASE explicit constant — Dyadic row-A theorem adopted upstream; NUMGEN import deferred.** An explicit rational `C` on the Dyadic tube `U = {0 < Q_true <= 1/625}` (block base points), with the one-step branch certified on `U_T`, is an adopted Dyadic owner result: `DYAD-THM-LPHASE-ROWA-REMAINDER`, Dyadic v6.4.19 §6.14 (adopted 20 Oct 2026, `40c9e63f…6ec9`; notice N15). Its interface objects are the ones NUMGEN confirmed as I1–I5, and the NUMGEN receipt replay was byte-identical (§9.1 dispositions; execution pins in §9.2). No constant is entered in this edition: the `C` of L-PHASE stays existential here, and the import by RID is reserved for a NUMGEN edition after v1.20.8. An explicit-tube INF-1 would additionally need an explicit L-BACKBONE constant (NUMGEN-side; not started).\\n\\n\"")

# E27 N15 receipt row (after the L-PHASE row-A certificate row)
rep("execution pins in §9.2); no constant imported (§6.6 OPEN sub-item) |\\n\"\n",
    "execution pins in §9.2); no constant imported (§6.6 OPEN sub-item) |\\n\"\n"
    "\"| N15 — `DYAD-THM-LPHASE-ROWA-REMAINDER` | Dyadic (v6.4.19, `40c9e63f…6ec9`) | RECEIVED: owner theorem adopted 20 Oct 2026 at THM grade on the I1–I5 interface; import by RID deferred to a NUMGEN edition after v1.20.8 (§6.6 OPEN sub-item); no constant entered here. N3 status on the Dyadic side follows adoption of this edition |\\n\"\n")

# E28 RECOG row
rep("| known consumer (v1.20.8): `RECOG v0.3.21` (adopted 20 Oct 2026, `a3459522…0ae3`) | claim-level synchronized against v1.20.7 at RECOG v0.3.18 (L1 contraction, N-1C, defect-threshold ratio, GAP-LOCK Lemma 3, GATE 1, INF-1: identical); A1a session work imports INF-1 and `D_M` with `RID unavailable`, resolved by the v1.20.8 allocations `NUMGEN-RESULT-N5AS1-INF1` / `NUMGEN-DEF-N5AS1-DEFECT` (repin is RECOG's, after adoption of this edition) |",
    "| known consumer (v1.20.8): `RECOG v0.3.22` (adopted 20 Oct 2026, `0dcce9e4…bcd9`; project copy hashed; predecessor v0.3.21 `a3459522…0ae3`) | claim-level synchronized against v1.20.7 at RECOG v0.3.18 (L1 contraction, N-1C, defect-threshold ratio, GAP-LOCK Lemma 3, GATE 1, INF-1: identical); v0.3.22 §6.13b/§7 imports INF-1 and `D_M` from v1.20.7 §6.6 verbatim with `RID unavailable` and the recorded governance line, resolved by the v1.20.8 allocations `NUMGEN-RESULT-N5AS1-INF1` / `NUMGEN-DEF-N5AS1-DEFECT` (repin is RECOG's, in a separate revision after adoption of this edition) |")

# E29 RRF row
rep("| representation registry reference (v1.20.8) | `RTG_RRF_REPRESENTATION_REGISTRY_v0.8.3` (adopted working standard, 19 Oct 2026) supersedes the RRF v0.6 pointer above; it cites v1.20.7 §6.6 (M2-1, Census-1) correctly |",
    "| representation registry reference (v1.20.8) | `RTG_RRF_REPRESENTATION_REGISTRY_v0.8.4` (adopted working standard, 20 Oct 2026, `2fb0a0fe…afce`; predecessor v0.8.3 `b393657e…a187`) supersedes the RRF v0.6 pointer above; it cites v1.20.7 §6.6 (M2-1, Census-1), §6.4 N-3A and §6.8 NG-7A correctly |")

# E30 changelog
rep('"### v1.20.8 — DRAFT r2 — October 20, 2026 (not adopted)\\n\\n"', '"### v1.20.8 — DRAFT r3 — October 21, 2026 (not adopted)\\n\\n"')
rep("RRF v0.6 pointer superseded by v0.8.3 (adopted working standard); RECOG v0.3.21 recorded as consumer.",
    "RRF v0.6 pointer superseded by v0.8.4 (adopted working standard); RECOG v0.3.22 recorded as consumer. Dyadic v6.4.19 is recorded in the companion line; its consumed passages are byte-identical to v6.4.18, so the pins are not moved in this edition.")
rep('"**5. L-PHASE explicit constant registered as an OPEN sub-item** pending Dyadic owner adoption of the row-A certificate; no constant entered (co-owner constraint).\\n\\n"',
    '"**5. L-PHASE explicit constant registered as an OPEN sub-item.** Dyadic adopted the row-A theorem (`DYAD-THM-LPHASE-ROWA-REMAINDER`, v6.4.19); its import by RID is deferred to a later NUMGEN edition; no constant entered (co-owner constraint).\\n\\n"')
rep("N14 seen; OFN REQ-O09-03", "N14 seen; N15 received (import deferred); OFN REQ-O09-03")
rep("the receipt replay is pinned in §9.2 with record, certificate, helper and JSON hashes. No other change.\\n\\n\"",
    "the receipt replay is pinned in §9.2 with record, certificate, helper and JSON hashes. No other change. "
    "r2 (`423cd719…7b78`): co-owner review of 20 Oct 2026 — REVIEW ACCEPTED, PI adoption pending. r3 is a narrow fact synchronization for owner editions adopted after r2 (PI choice, 21 Oct 2026): the L-PHASE OPEN sub-item and the status summary record the Dyadic v6.4.19 adoption with the import deferred; N15 receipt row; RECOG v0.3.22 and RRF v0.8.4 rows; companion-line note on v6.4.19 with the pins kept at v6.4.18; edition markers. No constant imported; every other edit byte-identical to r2.\\n\\n\"")

for a, b in R:
    n = src.count(a)
    assert n == 1, (n, a[:90])
    src = src.replace(a, b)
open(sys.argv[2], "w", encoding="utf-8").write(src)
print("replacements:", len(R))
