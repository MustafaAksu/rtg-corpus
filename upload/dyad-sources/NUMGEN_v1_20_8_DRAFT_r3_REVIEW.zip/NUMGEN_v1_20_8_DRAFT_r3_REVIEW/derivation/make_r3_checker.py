#!/usr/bin/env python3
"""Derive check_v1_20_8_r3.py from check_v1_20_8_r2.py: same G1-G11, plus G12 (r2 -> r3 delta confinement)
and G13 (fact-sync content), and negative controls N8-N9."""
import sys
src = open(sys.argv[1], encoding="utf-8").read()
R = []
def rep(a, b): R.append((a, b))
rep('"""Checker for RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r2.md', '"""Checker for RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r3.md')
rep("G9 grade-qualifier preservation: outside the declared §1.1 re-types, no '[from: X]' / [THM] / [ALG] qualifier is\n   added, removed or changed by any edit\n",
    "G9 grade-qualifier preservation: outside the declared §1.1 re-types, no '[from: X]' / [THM] / [ALG] qualifier is\n   added, removed or changed by any edit\n"
    "G12 r2 -> r3 delta confinement: the r3 edit list equals the reviewed r2 edit list (r2 draft 423cd719…7b78) except the\n"
    "   declared fact-sync edits E01-E05, E16, E27-E30; for those the base anchor ('old') is unchanged; and every r2 -> r3\n"
    "   changed line lies inside one of their spans\n"
    "G13 fact-sync content: the L-PHASE OPEN sub-item names DYAD-THM-LPHASE-ROWA-REMAINDER and Dyadic v6.4.19 and no longer\n"
    "   says 'owner adoption pending'; N15 receipt row present; RECOG v0.3.22 (0dcce9e4…) and RRF v0.8.4 (2fb0a0fe…) rows present;\n"
    "   no live import pin names Dyadic v6.4.19 (pins stay at v6.4.18 in this edition)\n")
rep('DRAFT = "RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r2.md"',
    'DRAFT = "RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r3.md"\n'
    'R2 = "RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r2.md"; R2_SHA = "423cd7198c75ab7f39d3e1608c5e3bb85c0230dee795d13e03915dc0d4857b78"\n'
    'FACT = {"E01", "E02", "E03", "E04", "E05", "E16", "E27", "E28", "E29", "E30"}\n'
    'import difflib')
rep("def run(base_text, draft_text, edits):\n", "def run(base_text, draft_text, edits, r2_text=None, r2_edits=None):\n")
rep('    info = {"lost_blocks": len(lost),',
    '    # G12 delta confinement against the reviewed r2\n'
    '    if r2_text is not None:\n'
    '        e2 = {e["id"]: e for e in r2_edits}; e3 = {e["id"]: e for e in edits}\n'
    '        same_ids = list(e2) == list(e3)\n'
    '        unchanged = all(e3[i] == e2[i] for i in e3 if i not in FACT)\n'
    '        anchors = all(e3[i]["old"] == e2[i]["old"] for i in FACT)\n'
    '        sp = []\n'
    '        for i in FACT:\n'
    '            k = draft_text.find(e3[i]["new"]); s = draft_text.count("\\n", 0, k); sp.append((s, s + e3[i]["new"].count("\\n")))\n'
    '        a, b = r2_text.split("\\n"), draft_text.split("\\n")\n'
    '        hunks = [op for op in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes() if op[0] != "equal"]\n'
    '        conf = all(any(lo <= j <= hi for lo, hi in sp) for op in hunks for j in (range(op[3], op[4]) if op[4] > op[3] else [op[3]]))\n'
    '        g["G12"] = same_ids and unchanged and anchors and conf and sha(r2_text.encode()) == R2_SHA\n'
    '    # G13 fact-sync content\n'
    '    sub = [l for l in draft_text.split("\\n") if l.startswith("`[OPEN]` `[target: THM]` `[v1.20.8]` **L-PHASE explicit constant")]\n'
    '    pins = re.findall(r"\\[import: [^\\]]*\\]", draft_text)\n'
    '    g["G13"] = (len(sub) == 1 and "DYAD-THM-LPHASE-ROWA-REMAINDER" in sub[0] and "v6.4.19" in sub[0]\n'
    '                and "owner adoption pending" not in sub[0]\n'
    '                and "| N15 — `DYAD-THM-LPHASE-ROWA-REMAINDER` |" in draft_text\n'
    '                and "`RECOG v0.3.22` (adopted 20 Oct 2026, `0dcce9e4…bcd9`" in draft_text\n'
    '                and "`RTG_RRF_REPRESENTATION_REGISTRY_v0.8.4` (adopted working standard, 20 Oct 2026, `2fb0a0fe…afce`" in draft_text\n'
    '                and not any("v6.4.19" in p for p in pins))\n'
    '    info = {"lost_blocks": len(lost),')
rep('    edits = json.load(open("v1_20_8_r2_edits.json", encoding="utf-8"))\n',
    '    edits = json.load(open("v1_20_8_r3_edits.json", encoding="utf-8"))\n'
    '    r2 = open(R2, encoding="utf-8").read(); r2e = json.load(open("v1_20_8_r2_edits.json", encoding="utf-8"))\n')
rep('subprocess.run([sys.executable, "build_v1_20_8_r2.py"]', 'subprocess.run([sys.executable, "build_v1_20_8_r3.py"]')
rep("    g, info = run(base, draft, edits); g = {\"G2\": g2, **g}", "    g, info = run(base, draft, edits, r2, r2e); g = {\"G2\": g2, **g}")
# negative controls keep the original r2 call form; add N8/N9 with the r2 comparison active
rep('        print(json.dumps({"negative_controls_pass_should_be_false": negs}, indent=1))',
    '        e8 = [dict(e, new=e["new"].replace("v6.4.18 §6.11", "v6.4.19 §6.11")) if e["id"] == "E10" else e for e in edits]\n'
    '        bad = draft.replace(next(e["new"] for e in edits if e["id"] == "E10"), next(e["new"] for e in e8 if e["id"] == "E10")); negs["N8 undeclared r2 edit changed"] = all(run(base, bad, e8, r2, r2e)[0].values())\n'
    '        s9 = "Dyadic row-A theorem adopted upstream; NUMGEN import deferred."; t9 = "Dyadic row-A certificate, owner adoption pending."\n'
    '        bad = draft.replace(s9, t9); e9 = [dict(e, new=e["new"].replace(s9, t9)) for e in edits]; negs["N9 stale L-PHASE sub-item"] = all(run(base, bad, e9, r2, r2e)[0].values())\n'
    '        bad = draft.replace("| N15 — `DYAD-THM-LPHASE-ROWA-REMAINDER` |", "| N15 — (row removed) |"); e10 = [dict(e, new=e["new"].replace("| N15 — `DYAD-THM-LPHASE-ROWA-REMAINDER` |", "| N15 — (row removed) |")) for e in edits]; negs["N10 N15 receipt missing"] = all(run(base, bad, e10, r2, r2e)[0].values())\n'
    '        print(json.dumps({"negative_controls_pass_should_be_false": negs}, indent=1))')
rep('bad = draft.replace("No constant is entered here", "C = 403/250 is entered here"); e3 = [dict(e, new=e["new"].replace("No constant is entered here", "C = 403/250 is entered here")) for e in edits]',
    'bad = draft.replace("No constant is entered in this edition", "C = 403/250 is entered in this edition"); e3 = [dict(e, new=e["new"].replace("No constant is entered in this edition", "C = 403/250 is entered in this edition")) for e in edits]; assert bad != draft')
for a, b in R:
    n = src.count(a); assert n == 1, (n, a[:80]); src = src.replace(a, b)
open(sys.argv[2], "w", encoding="utf-8").write(src); print("replacements:", len(R))
