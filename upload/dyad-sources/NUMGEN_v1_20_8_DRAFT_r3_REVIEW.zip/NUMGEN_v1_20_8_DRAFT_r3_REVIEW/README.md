# NUMGEN v1.20.8 DRAFT r3 — delta review package

r3 is a narrow fact synchronization of the accepted r2 (`423cd719…7b78`). Owner editions adopted after r2: Dyadic v6.4.19, RECOG v0.3.22, RRF v0.8.4. Changed edits: E01–E05 (edition markers, companion note, status summary), E16 (L-PHASE OPEN sub-item), E27 (N15 receipt row), E28 (RECOG row), E29 (RRF row), E30 (changelog). Every other edit is byte-identical to r2. No constant is imported. Dyadic import pins stay at v6.4.18: the consumed v6.4.19 passages (§§2–3, §6.1, §6.4, §6.11, DYAD-THM-PRIM-CTR) are byte-identical to v6.4.18; the only §6.14 change is the inserted L-PHASE block.

Re-run, from this folder:

1. `python3 check_v1_20_8_r3.py --neg`
   - Builds r3 from the frozen base `RTG_NUMBER_GENESIS_DSN_v1_20_7.md` (`c4637e7a…ab28`).
   - G1–G11 as in r2; G12 r2→r3 delta confinement (edit list equal to r2 outside the declared edits, same anchors, every changed line inside their spans, r2 hash pinned); G13 fact-sync content.
   - Expected: G1–G13 PASS, N1–N10 FAIL, exit 0.
2. `python3 build_v1_20_8_r2.py` reproduces the accepted r2 byte-exactly (`423cd719…7b78`).
3. `python3 ng_inv_live_v1_1.py RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r3.md` → 0 live hits.
4. Receipt replay (unchanged from r2): `cd replay_inputs_dyad && python3 dyad_numgen_lphase_rowA_cert.py` → `RESULT: PASS`.

`derivation/` holds the scripts that derived the r3 builder and checker from the r2 ones by exact-once replacements. `SHA256SUMS.txt` lists every file.
