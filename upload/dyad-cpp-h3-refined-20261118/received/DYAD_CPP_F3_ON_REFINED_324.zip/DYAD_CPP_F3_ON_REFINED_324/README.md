# DYAD OPEN 20 — k=3 on 324 refined F2 candidates (SESSION)

## Scope

This archive compares **two conditional three-block necessary-condition filters on exactly the same 324 initial-fibre rectangles** retained by the owner-reviewed `refine2` run:

| Mode | Initial candidates | New evaluations | k | Partition |
|---|---:|---:|---:|---|
| `h3_324` | 324 | 324 | 3 | none |
| `h3_split2` | 324 | 1296 | 3 | each rectangle 2×2 |
| `compare` | both | 1620 | 3 | runs both; no k=5 |

The source-readback gates are strict: Stage2 JSON and three complete prior TSV files, fixed SHA-256; 400 previously recorded selected-F2 rows, 576 prior `refine2` rows, and **all 144+324 original F2 replays** checked against the frozen 256-bit integers and necessary-box intersections. Exactly 324 post-refine2 `RETAINED` rectangles advance. Earlier `924+256+252` exclusions are inherited, not rerun, and may be cited only along with the three prior full run hashes.

For each probe rectangle `B` (or 2×2 child of B), the code encloses it in a disk for **evaluation only**, computes three `F=T^6` blocks from the original lift, propagates the derivative without reset over that disk, takes a fresh `M3` upper bound on `X3 ∩ D0`, builds the established C1–C2 necessary disk, intersects its *box* with the original probe rectangle, and retains any unresolved probe unchanged. There is no k=3 sectorial graph certification; the necessary condition remains conditional on the tube/base hypotheses at k=3. The output `L1` radius overbounds Euclidean radius.

## Ubuntu command

Place the archive in `/root/` and verify its published SHA-256. Extract it via `unzip -n`. Requires the existing extracted dependency packages and the PI's three **unmodified** run directories:

- `/root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2`
- `/root/DYAD_CPP_FORWARD_METHOD_BENCHMARK`
- `/root/DYAD_CPP_F1_TUBE_CONTRACTOR`
- `/root/DYAD_CPP_F2_TUBE_CONTRACTOR`
- `/root/DYAD_CPP_F2_TERM_AUDIT_SUB8`
- `/root/DYAD_CPP_F2_SELECTIVE_REFINE`
- `/root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC`
- `/root/dyad-f2-term8-full` (full sub8 term results)
- `/root/dyad-f2-selective-run` (selective F2 PI results)
- `/root/dyad-horizon-compare` (**prior** H1–H5 comparison, including `refine2/details.tsv`)

```bash
bash /root/DYAD_CPP_F3_ON_REFINED_324/run_ubuntu_h3_refined.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TERM_AUDIT_SUB8 \
  /root/DYAD_CPP_F2_SELECTIVE_REFINE \
  /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC \
  /root/dyad-f2-term8-full \
  /root/dyad-f2-selective-run \
  /root/dyad-horizon-compare \
  /root/dyad-f3-refined-compare \
  compare

echo "exit=$?"
cat /root/dyad-f3-refined-compare/h3_324/summary.txt
cat /root/dyad-f3-refined-compare/h3_split2/summary.txt
cat /root/dyad-f3-refined-compare/comparison.txt
```

Single-mode alternatives (`h3_324`, `h3_split2`) require a **fresh empty output directory** each time. `compare` invokes **only** the two k=3 modes, **never** k=5 or 3c-b. Each mode has a 2400-second finite timeout. The code and runner stop with `3` on malformed source, `2` on unresolved/timeout/empty cover, `64` on invalid CLI and `0` only on full finite numerical structural PASS; **exit=0 is not a graph/tube certificate**. In case of timeout or errors, partial logs remain preserved; no numerical conclusion is claimed.

The runner compiles unchanged reviewed sources by inclusion, checks the 7 dependency-package manifests, all three prior run manifests, the `refine2` nested manifest, the four pinned SHA-256 values and the complete geometric/integer source chain. It imports φ40 from the pinned Stage2 JSON with its reviewed transfer pads and checks it byte-identical to the prior imports. It compiles an independent parser target (normal and ASan/UBSan), runs synthetic 324/1296-row coverage and 22 mutation controls, negative CLI tests, and an independent Python exact-integer checker for the new results. Environment-specific time/source-path strings are recorded and are *not expected* to be byte-identical in a reviewer replay; numerical details TSV must match.

## GitHub unchanged receipt

After verifying archive identity and running the actual source-backed comparison, use the included helper to push exact source/output bytes to separate `upload/*` branches (no `main` merge):

```bash
bash /root/DYAD_CPP_F3_ON_REFINED_324/upload_h3_refined_evidence.sh \
  package /root/rtg-corpus /root/DYAD_CPP_F3_ON_REFINED_324.zip \
  <PUBLISHED_SHA256> --push

bash /root/DYAD_CPP_F3_ON_REFINED_324/upload_h3_refined_evidence.sh \
  results /root/rtg-corpus /root/dyad-f3-refined-compare - --push
```

`upload/dyad-cpp-h3-refined-20261118` receives the ZIP without rewriting it. `upload/dyad-cpp-h3-refined-results-20261118` receives the complete PI output directory unchanged. The owner should review the package's `OWNER_REVIEW_REQUEST.md` (K1–K5), rerun in the same source profile and compare result file hashes, distinguish same-code cross-machine repeat from independent numerical implementation, and append a separate SESSION-only review note.

## Scientific and adoption boundary

Governing DYAD remains the independently tagged/adopted edition until a newer verified tag/release is found. The owner evidence reviewed here is PR #305 head `6f57202896fc22fd9aa82055a69befdb67a52d30` (Addendum 3, SESSION), not an adopted theorem. O-1 fixed-wall PR #312 is prepared and merge-ready but separate and not merged on the last check. No 3c-b production/replay, point-jump proof or B-an/B-6 closure is requested or implied.
