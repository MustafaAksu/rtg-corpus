# DYAD OPEN 20 — owner review request: third block on 324 refined F2 survivors (SESSION)

**Study:** A bounded, conditional k=3 horizon experiment. The source is the owner-reviewed three-log chain: the full F2 sub8 term audit (1024 rows), the selective F2 calculation (400 rows), and the `refine2` result of the previously owner-reviewed H1–H5 comparison (576 rows). Nothing is adopted by this request. PI authority controls scientific adoption and merges. 3c-b remains unauthorized; B-an and B-6 ACTIVE.

## Frozen source identities (all required)

- Stage2 `scout_N216_dps840.json`: SHA256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.
- `dyad-f2-term8-full/terms.tsv` (8×8, second subdivision 8): SHA256 `1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72`.
- `dyad-f2-selective-run/selective_children.tsv` (100 parent subtiles, 400 children): SHA256 `3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579`.
- `dyad-horizon-compare/refine2/details.tsv` (144 source F2 survivors, 576 children): SHA256 `bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a`.
- Included code uses the **unchanged** `DYAD_CPP_F3_HORIZON_DIAGNOSTIC/source/horizon.cpp`, which itself includes unchanged previously reviewed F2/selective/F1/engine sources. All package manifests checked in the runner.

## K1 — complete cumulative candidate cover

Read, hash and structurally validate all three prior TSVs (1024+400+576 rows). Reject malformed, duplicate, missing, or nonexact integer sources. The 924+256+252 previously excluded candidates remain excluded *by their original conditional necessary conditions*; they must not be re-evaluated or counted again. Check that exactly 324 `RETAINED` post-refine2 rectangles remain and every source `refine2` parent is the post-selective F2 final rectangle; all four children cover it. Re-run the unchanged F2 computation on each of the 144 parent survivors and 324 child survivors, requiring byte-identical seven C1–C2 arithmetic integers and the actual geometric intersection.

## K2 — two valid k=3 experiments

- **Mode `h3_324`:** evaluate a fresh k=3 necessary disk on each of the 324 frozen post-refine2 rectangles. Exactly 324 evaluations.
- **Mode `h3_split2`:** split each of the same 324 final rectangles by `f2::split_box(b,2)`; evaluate a fresh k=3 necessary disk on every one of 1296 children. Exactly 1296 evaluations.

In both modes, initialize with the *original lift*, propagate the tangent through 3 unreset `direct6` blocks over a disk enclosing the **current** rectangle, take `M3=ForwardTube::upper(X3)` as an upper bound for `sup_{X3∩D0}R0`, and apply the same C1–C2 necessary disk. Do not use an old parent's M3 or rebase the tangent. Reject a child ONLY if it is disjoint from its own necessary disk. On domain failure, retain that exact current rectangle. Any source replay mismatch aborts. Other exceptions abort (not an exclusion).

## K3 — complete, independent structural output

New TSV records exact 256-bit endpoints for source, probe, necessary disk and final intersection, the seven integer terms `(M3, Dr, D, r, |b|_lower, recenter_error, necessary_radius)` and `VALID/UNRESOLVED`, `EXCLUDED/RETAINED`. Independently check partition of each frozen parent, all status/transition logic, `Dr=ceil(D*r/2^256)`, `rad=err+ceil((M3+Dr)*2^256/lower_abs_b)`, full expected row counts, and final L1 hull inclusion. Distinguish the old full cover's *cumulative* exclusions from newly excluded rows. The final hull is a conservative **L1** radius, not the Euclidean radius and not a point jump.

## K4 — results/replay and method choice

The PI runs `compare` on the pinned real Stage2 source, with both modes. Owner reruns unchanged on a second machine and compares `details.tsv` byte-for-byte. Time, path, env and dependent manifest differences are expected and **must not** be misclassified as source numerical differences. Assess `M3`, `Dr/M3`, newly excluded and retained counts, L1-radius contraction, wall-time versus a fixed-horizon alternative. Neither outcome justifies extrapolation to k=5 or 3c-b without separate evidence and PI authorization.

## K5 — scope / provenance

This is a **same-engine conditional numerical development test**, not an independent interval-arithmetic implementation or a proof of the sectorial graph, stable tube or true jump. Both k=3 modes require the k=3 tube/base hypothesis in addition to the earlier F2 assumptions. Previous O-1 fixed dyadic wall correction is prepared separately as PR #312; do not claim that #312 has merged or been adopted unless independently verified. No canonical DYAD DSN edits, release tags, 3c-b run, or claim of B-an/B-6 closure.
