#!/usr/bin/env bash
# [SESSION] Byte-exact immutable upload of k=3 successor package and PI run to two new branches.
# Does NOT change main, merge, tag, adopt, or authorize 3c-b.
set -euo pipefail
if [[ $# -ne 5 || ( "$1" != package && "$1" != results ) || "$5" != --push ]];then
 echo 'Usage: upload_h3_refined_evidence.sh package REPO EXACT_ZIP EXPECTED_SHA256 --push' >&2
 echo '   or upload_h3_refined_evidence.sh results REPO RUN_DIRECTORY - --push' >&2
 exit 64
fi
kind=$1;repo=$(cd -- "$2" && pwd);input=$(realpath -- "$3")
if [[ "$kind" == package ]];then
 [[ -f "$input" ]] || { echo 'ZIP is missing' >&2; exit 3; }
 [[ "$4" =~ ^[a-f0-9]{64}$ ]] || { echo 'Invalid expected hash' >&2; exit 64; }
 echo "$4  $input" | sha256sum -c - >/dev/null
 branch=upload/dyad-cpp-h3-refined-20261118
else
 [[ -d "$input" ]] || { echo 'Run directory missing' >&2; exit 3; }
 (cd "$input" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
 seen=false
 for job in h3_324 h3_split2;do
  if [[ -d "$input/$job" ]];then
   (cd "$input/$job" && sha256sum -c SHA256SUMS.txt >/dev/null)
   [[ -s "$input/$job/summary.txt" ]] && seen=true
  fi
 done
 [[ "$seen" == true ]] || { echo 'No completed/partial checked mode directory' >&2;exit 3; }
 branch=upload/dyad-cpp-h3-refined-results-20261118
fi
git -C "$repo" fetch origin main >/dev/null
if git -C "$repo" show-ref --verify --quiet "refs/heads/$branch" || \
   git -C "$repo" show-ref --verify --quiet "refs/remotes/origin/$branch";then
 echo "STOP: intake branch already exists $branch" >&2; exit 3
fi
wt=$(mktemp -d /tmp/dyad-h3-refined-XXXXXX);rmdir "$wt"
cleanup(){ git -C "$repo" worktree remove --force "$wt" >/dev/null 2>&1 || true; }
trap cleanup EXIT
git -C "$repo" worktree add -b "$branch" "$wt" origin/main >/dev/null
if [[ "$kind" == package ]];then
 mkdir -p "$wt/$branch/received"
 cp -p -- "$input" "$wt/$branch/received/DYAD_CPP_F3_ON_REFINED_324.zip"
 (cd "$wt/$branch/received" && sha256sum DYAD_CPP_F3_ON_REFINED_324.zip > SHA256SUMS.txt)
else
 mkdir -p "$wt/$branch/pi-run"
 cp -a -- "$input/." "$wt/$branch/pi-run/"
 (cd "$wt/$branch/pi-run" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
fi
(
 cd "$wt"
 git add -- "$branch"
 git commit -m "upload/dyad: receive untouched refined F3 $kind (SESSION)" >/dev/null
 echo "BRANCH=$branch"
 echo "COMMIT=$(git rev-parse HEAD)"
 git push origin "refs/heads/$branch:refs/heads/$branch"
)
echo 'UPLOAD_ONLY; no main merge, tag, adopted claim, or 3c-b authorization'
