#!/usr/bin/env bash
# [SESSION] k=3, 324 refined F2 survivors: 324 direct versus 1296 split children.
# No 3c-b campaign, graph theorem, physical validation or point-jump claim.
set -euo pipefail
if [[ $# -ne 13 ]];then
 echo 'Usage: run_ubuntu_h3_refined.sh REPO V2 BENCH F1 F2 SUB8 SELECTIVE_PKG HORIZON_PKG SUB8_PI_RUN SELECTIVE_PI_RUN HORIZON_PI_RUN NEW_OUTPUT MODE(compare|h3_324|h3_split2)' >&2
 exit 64
fi
repo=$(cd -- "$1" && pwd);v2=$(cd -- "$2" && pwd);bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd);f2=$(cd -- "$5" && pwd);sub8=$(cd -- "$6" && pwd)
selpkg=$(cd -- "$7" && pwd);horpkg=$(cd -- "$8" && pwd)
sub8run=$(cd -- "$9" && pwd);selrun=$(cd -- "${10}" && pwd);horrun=$(cd -- "${11}" && pwd)
out=${12};mode=${13};pkg=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
case "$mode" in compare|h3_324|h3_split2) ;; *)echo 'Invalid mode' >&2;exit 64;;esac
if [[ -e "$out" ]];then
 if [[ ! -d "$out" || -n $(ls -A -- "$out") ]];then echo 'STOP: output must be new/empty' >&2;exit 64;fi
else mkdir -p -- "$out";fi
out=$(cd -- "$out" && pwd)
(cd "$pkg" && sha256sum -c SHA256SUMS.txt) > "$out/new_package_checks.txt"
for pair in "v2:$v2" "bench:$bench" "f1:$f1" "f2:$f2" "sub8:$sub8" "selective:$selpkg" "horizon:$horpkg";do
 n=${pair%%:*};f=${pair#*:};(cd "$f" && sha256sum -c SHA256SUMS.txt)> "$out/${n}_package_checks.txt"
done
(cd "$sub8run" && sha256sum -c RUN_SHA256SUMS.txt)> "$out/previous_sub8_run_checks.txt"
(cd "$selrun" && sha256sum -c RUN_SHA256SUMS.txt)> "$out/previous_selective_run_checks.txt"
(cd "$horrun" && sha256sum -c RUN_SHA256SUMS.txt)> "$out/previous_horizon_run_checks.txt"
(cd "$horrun/refine2" && sha256sum -c SHA256SUMS.txt)> "$out/previous_refine2_checks.txt"
S2="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
SUB8="$sub8run/terms.tsv";SELECT="$selrun/selective_children.tsv";OLD="$horrun/refine2/details.tsv"
# Three prior frozen run logs, individually pinned (plus stage2 source identity).
{ printf '%s  %s\n' '6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e' "$S2";
  printf '%s  %s\n' '1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72' "$SUB8";
  printf '%s  %s\n' '3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579' "$SELECT";
  printf '%s  %s\n' 'bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a' "$OLD";
} | sha256sum -c - > "$out/FOUR_FROZEN_SHA256_PINS.txt"
python3 "$sub8/source/check_terms.py" "$SUB8" > "$out/source_sub8_terms_check.txt"
python3 "$sub8/source/check_completion.py" "$sub8run/summary.txt" "$SUB8" 8 8 0 > "$out/source_sub8_completion_check.txt"
python3 "$selpkg/source/check_selective.py" "$SUB8" "$SELECT" "$selrun/summary.txt" > "$out/source_selective_check.txt"
python3 "$horpkg/source/check_horizon.py" "$SELECT" "$OLD" "$horrun/refine2/summary.txt" refine2 > "$out/source_refine2_check.txt"
python3 "$v2/source/import_phi40.py" --source "$S2" --out "$out/phi40_outer_256.txt" > "$out/import.log"
cmp "$out/phi40_outer_256.txt" "$selrun/phi40_outer_256.txt"
cmp "$out/phi40_outer_256.txt" "$horrun/phi40_outer_256.txt"
{
 printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
 printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
 printf 'GCC=';g++ --version|head -1
 printf 'PYTHON=';python3 --version
 printf 'SOURCE_SHA256=%s\n' '6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e'
 printf 'SUB8_TERMS_SHA256=%s\n' '1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72'
 printf 'SELECTIVE_CHILDREN_SHA256=%s\n' '3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579'
 printf 'REFINE2_576_SHA256=%s\n' 'bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a'
 printf 'MODE=%s; SESSION_ONLY; NO 3c-b production/replay, no certificate or jump\n' "$mode"
} > "$out/environment.txt"
includes=(-I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" -I "$selpkg/source" -I "$horpkg/source" -I "$pkg/source")
g++ -std=c++17 -O2 -Wall -Wextra -pedantic "${includes[@]}" "$pkg/source/h3_refined.cpp" -o "$out/h3_refined"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic "${includes[@]}" "$pkg/source/test_frozen_parser.cpp" -o "$out/test_frozen_parser"
python3 "$pkg/tests/test_h3_structure.py" "$out/test_frozen_parser" > "$out/structure_units.txt"
"$out/test_frozen_parser" "$SELECT" "$OLD" > "$out/source_cpp_parser.txt"
g++ -std=c++17 -O0 -g0 -fno-omit-frame-pointer -fsanitize=address,undefined \
 "${includes[@]}" "$pkg/source/test_frozen_parser.cpp" -o "$out/test_frozen_parser_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 60s \
 "$out/test_frozen_parser_sanitized" "$SELECT" "$OLD" > "$out/source_parser_sanitized.txt" 2> "$out/sanitizer_stderr.txt"
set +e
"$out/h3_refined" >/dev/null 2>&1;rc0=$?
"$out/h3_refined" "$S2" "$SELECT" "$OLD" h3_324 "$out/bad_transfer.tsv" >/dev/null 2>&1;rc1=$?
"$out/h3_refined" "$out/phi40_outer_256.txt" "$S2" "$OLD" h3_324 "$out/bad_source.tsv" >/dev/null 2>&1;rc2=$?
"$out/h3_refined" "$out/phi40_outer_256.txt" "$SELECT" "$S2" h3_324 "$out/bad_refine2.tsv" >/dev/null 2>&1;rc3=$?
"$out/h3_refined" "$out/phi40_outer_256.txt" "$SELECT" "$OLD" h5 "$out/bad_mode.tsv" >/dev/null 2>&1;rc4=$?
set -e
if [[ "$rc0,$rc1,$rc2,$rc3,$rc4" != '64,3,3,3,3' ]];then
 echo "STOP: negative CLI codes $rc0,$rc1,$rc2,$rc3,$rc4" >&2;exit 3
fi
printf 'NEGATIVE_CLI_PASS 64,3,3,3,3\n' > "$out/negative_controls.txt"
case "$mode" in compare)modes=(h3_324 h3_split2);;*)modes=("$mode");;esac
rcfinal=0
for job in "${modes[@]}";do
 mkdir -- "$out/$job"
 set +e
 timeout -k 20s 2400s "$out/h3_refined" "$out/phi40_outer_256.txt" \
  "$SELECT" "$OLD" "$job" "$out/$job/details.tsv" \
  > "$out/$job/summary.txt" 2> "$out/$job/stderr.txt"
 rc=$?
 set -e
 if [[ "$rc" == 0 || "$rc" == 2 ]];then
  if [[ -s "$out/$job/summary.txt" ]];then
   python3 "$pkg/source/check_h3_refined.py" "$SELECT" "$OLD" \
    "$out/$job/details.tsv" "$out/$job/summary.txt" "$job" > "$out/$job/structure_check.txt" \
    || { echo "STOP structure check $job" >&2;exit 3; }
  fi
 fi
 if [[ $rc -ne 0 ]];then
  echo "NONPASS $job exit=$rc (partial files retained); NO certificate" >&2
  if [[ $rc -eq 2 || $rc -eq 124 || $rc -eq 137 ]];then rcfinal=2;else rcfinal=3;fi
 fi
 (cd "$out/$job" && find . -maxdepth 1 -type f ! -name SHA256SUMS.txt -printf '%f\0'|sort -z|xargs -0 -r sha256sum > SHA256SUMS.txt)
 if [[ $rcfinal -eq 3 ]];then break;fi
done
if [[ "$mode" == compare && $rcfinal -eq 0 ]];then
 python3 "$pkg/source/compare_refined.py" "$out/h3_324/summary.txt" "$out/h3_split2/summary.txt" > "$out/comparison.txt"
fi
(cd "$out" && find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name h3_refined ! -name test_frozen_parser ! -name test_frozen_parser_sanitized -printf '%f\0'|sort -z|xargs -0 -r sha256sum > RUN_SHA256SUMS.txt)
for job in "${modes[@]}";do
 if [[ -f "$out/$job/summary.txt" ]];then cat "$out/$job/summary.txt";fi
 if [[ -f "$out/$job/structure_check.txt" ]];then cat "$out/$job/structure_check.txt";fi
done
if [[ "$mode" == compare && $rcfinal -eq 0 ]];then cat "$out/comparison.txt";fi
if [[ $rcfinal -eq 3 ]];then echo 'INPUT_FAIL; incomplete run preserved; SESSION_ONLY';exit 3;fi
if [[ $rcfinal -ne 0 ]];then echo 'INCONCLUSIVE; incomplete run preserved; SESSION_ONLY';exit 2;fi
echo 'PASS CONDITIONAL H3 REFINED SESSION COMPARISON; NO certificate or point jump.'
