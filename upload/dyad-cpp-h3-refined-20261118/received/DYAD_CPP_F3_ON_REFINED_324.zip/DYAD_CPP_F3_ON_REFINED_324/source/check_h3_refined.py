#!/usr/bin/env python3
"""[SESSION] Independent exact integer / full-cover checker for k=3 on 324 refined F2 survivors.

Checks the three-level frozen candidate chain for geometric and integer consistency, and
complete new output. Does NOT establish the analytic graph/tube hypotheses or the correctness
of the unchanged C++ elementary interval arithmetic.
"""
from pathlib import Path
from collections import Counter, defaultdict
from argparse import ArgumentParser
from importlib.util import spec_from_file_location, module_from_spec
import re

S=1<<256
HEADER=('tile parent_subtile child refine_subtile probe_subtile '
        'source_re_lo source_re_hi source_im_lo source_im_hi '
        'probe_re_lo probe_re_hi probe_im_lo probe_im_hi '
        'necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
        'final_re_lo final_re_hi final_im_lo final_im_hi '
        'M3_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')

def ceildiv(a,b):
    assert b>0
    return -(-a//b)

def meet(a,b):
    z=(max(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),min(a[3],b[3]))
    return z if z[0]<=z[1] and z[2]<=z[3] else None

def cut(parent,k):
    a,b,c,d=parent;dx=b-a;dy=d-c
    assert dx>=0 and dy>=0 and 0<=k<4
    i,j=divmod(k,2)
    return (a+(dx*i)//2,a+ceildiv(dx*(i+1),2),
            c+(dy*j)//2,c+ceildiv(dy*(j+1),2))

def hull(boxes):
    assert boxes
    return (min(b[0] for b in boxes),max(b[1] for b in boxes),
            min(b[2] for b in boxes),max(b[3] for b in boxes))

def radius(b):
    x=(b[0]+b[1])//2;y=(b[2]+b[3])//2
    return max(abs(x-b[0]),abs(x-b[1]))+max(abs(y-b[2]),abs(y-b[3]))

def load_refine2(selective,old_details):
    lines=Path(selective).read_text().splitlines()
    assert lines and lines[0].startswith('tile parent_subtile child parent_re_lo')
    source={};first=Counter()
    assert len(lines)==401
    for n,line in enumerate(lines[1:],1):
        w=line.split();assert len(w)==28,(n,len(w))
        ints=list(map(int,w[:26]));i,j,k=ints[:3];key=i,j,k
        assert key not in source and 0<=i<60 and 0<=j<64 and 0<=k<4
        parent=tuple(ints[3:7]);child=tuple(ints[7:11]);nd=tuple(ints[11:15]);fin=tuple(ints[15:19]);M,Dr,D,r,lb,e,rad=ints[19:26]
        assert w[26]=='VALID' and w[27] in ('RETAINED','EXCLUDED')
        assert M>0 and D>=0 and r>=0 and lb>0 and e>=0 and Dr>=0 and rad>=0
        assert Dr==ceildiv(D*r,S) and rad==e+ceildiv((M+Dr)*S,lb)
        assert nd[1]-nd[0]==nd[3]-nd[2]==2*rad and child==cut(parent,k)
        hit=meet(child,nd);assert (hit is None)==(w[27]=='EXCLUDED')
        assert fin==(hit if hit else (0,0,0,0))
        source[key]=fin if w[27]=='RETAINED' else None
        first[w[27]]+=1
    assert first==Counter({'EXCLUDED':256,'RETAINED':144})
    lines=Path(old_details).read_text().splitlines()
    assert lines and lines[0].startswith('tile parent_subtile child new_subtile source_re_lo')
    assert len(lines)==577
    seen=set();parents=defaultdict(set);chosen={};excluded=0
    for n,line in enumerate(lines[1:],1):
        w=line.split();assert len(w)==29,(n,len(w))
        a=list(map(int,w[:27]));i,j,k,s=a[:4];key=(i,j,k);ix=(i,j,k,s)
        assert key in source and source[key] is not None and 0<=s<4 and ix not in seen
        seen.add(ix);parents[key].add(s)
        root=tuple(a[4:8]);probe=tuple(a[8:12]);nd=tuple(a[12:16]);fin=tuple(a[16:20]);M,Dr,D,r,lb,e,rad=a[20:27]
        assert root==source[key] and probe==cut(root,s)
        assert w[27]=='VALID' and w[28] in ('RETAINED','EXCLUDED')
        assert M>0 and D>=0 and r>=0 and lb>0 and e>=0 and Dr>=0 and rad>=0
        assert Dr==ceildiv(D*r,S) and rad==e+ceildiv((M+Dr)*S,lb)
        assert nd[1]-nd[0]==nd[3]-nd[2]==2*rad
        hit=meet(probe,nd);assert (hit is None)==(w[28]=='EXCLUDED')
        assert fin==(hit if hit else (0,0,0,0))
        if hit is not None:chosen[ix]=fin
        else:excluded+=1
    assert len(parents)==144 and all(v=={0,1,2,3} for v in parents.values())
    assert len(chosen)==324 and excluded==252
    return chosen

def check(selective,old_details,new,summary,mode):
    assert mode in ('h3_324','h3_split2')
    chosen=load_refine2(selective,old_details)
    lines=Path(new).read_text().splitlines()
    assert lines and lines[0]==HEADER
    expect=324 if mode=='h3_324' else 1296
    assert len(lines)==expect+1,(len(lines),expect)
    seen=set();parent_keys=defaultdict(set);done=[];cnt=Counter();valid_rat=[];min_M=None;max_M=None
    for n,line in enumerate(lines[1:],1):
        w=line.split();assert len(w)==30,(n,len(w))
        a=list(map(int,w[:28]));i,j,k,s,t=a[:5];idx=(i,j,k,s);key=(i,j,k,s,t)
        assert idx in chosen and key not in seen and 0<=t<(1 if mode=='h3_324' else 4)
        seen.add(key);parent_keys[idx].add(t)
        parent=tuple(a[5:9]);probe=tuple(a[9:13]);need=tuple(a[13:17]);fin=tuple(a[17:21]);M,Dr,D,r,lb,e,rad=a[21:28];ev,action=w[28:]
        assert parent==chosen[idx]
        assert probe==(parent if mode=='h3_324' else cut(parent,t))
        assert ev in ('VALID','UNRESOLVED') and action in ('RETAINED','EXCLUDED')
        if ev=='VALID':
            assert M>0 and D>=0 and r>=0 and lb>0 and e>=0 and Dr>=0 and rad>=0
            assert Dr==ceildiv(D*r,S) and rad==e+ceildiv((M+Dr)*S,lb)
            assert need[1]-need[0]==need[3]-need[2]==2*rad
            hit=meet(probe,need)
            assert (hit is None)==(action=='EXCLUDED')
            assert fin==(hit if hit else (0,0,0,0))
            valid_rat.append((Dr,M))
            min_M=M if min_M is None or M<min_M else min_M
            max_M=M if max_M is None or M>max_M else max_M
        else:
            assert action=='RETAINED' and need==probe and fin==probe
            assert all(x==0 for x in (M,Dr,D,r,lb,e,rad))
        cnt[ev]+=1;cnt[action]+=1
        if action=='RETAINED':done.append(fin)
    assert len(parent_keys)==324 and set(parent_keys)==set(chosen)
    target={0} if mode=='h3_324' else {0,1,2,3}
    assert all(v==target for v in parent_keys.values())
    assert len(seen)==expect and cnt['VALID']+cnt['UNRESOLVED']==expect
    assert cnt['RETAINED']+cnt['EXCLUDED']==expect
    assert done,'empty outer candidate cover is not a graph nonexistence proof'
    old_r=radius(hull(list(chosen.values())))
    new_h=hull(done);new_r=radius(new_h)
    old_h=hull(list(chosen.values()))
    assert old_h[0]<=new_h[0] and new_h[1]<=old_h[1] and old_h[2]<=new_h[2] and new_h[3]<=old_h[3]
    assert new_r<=old_r
    txt=Path(summary).read_text();assert f'H3_ON_REFINED={mode};' in txt and 'NO_CERTIFICATE' in txt
    def findint(k):
        m=re.search(r'(?<!\S)'+re.escape(k)+r'=([0-9]+)(?=\s|$)',txt)
        assert m,k
        return int(m.group(1))
    for k,v in [('source_selective_rows',400),('source_horizon_rows',576),('prior_refine2_excluded',252),
                ('prior_refine2_retained',324),('checked_selective_retained',144),
                ('checked_refine2_retained',324),('evaluations',expect),('excluded',cnt['EXCLUDED']),
                ('retained',cnt['RETAINED']),('unresolved',cnt['UNRESOLVED']),
                ('prior_L1_256',old_r),('final_L1_256',new_r),
                ('Dr_gt_M3',sum(d>m for d,m in valid_rat))]:
        assert findint(k)==v,(k,findint(k),v)
    print('H3_REFINED_STRUCTURE_PASS mode=%s children=%d frozen_refine2_survivors=324'%(mode,expect))
    print('excluded=%d retained=%d unresolved=%d'%(cnt['EXCLUDED'],cnt['RETAINED'],cnt['UNRESOLVED']))
    print('prior_L1_256=%d final_L1_256=%d'%(old_r,new_r))
    print('prior_L1=%.12e final_L1=%.12e reduction=%.6f%%'%(old_r/S,new_r/S,100*(1-new_r/old_r)))
    if valid_rat:print('Dr_gt_M3=%d; M3_min_exact_256=%d M3_max_exact_256=%d'%(sum(d>m for d,m in valid_rat),min_M,max_M))
    print('SESSION_ONLY: preserved 924+256+252 inherited exclusions; graph/tube hypotheses conditional; no jump')

if __name__=='__main__':
    p=ArgumentParser();p.add_argument('selective_400');p.add_argument('refine2_576');p.add_argument('new_details');p.add_argument('new_summary');p.add_argument('mode',choices=('h3_324','h3_split2'))
    a=p.parse_args();check(a.selective_400,a.refine2_576,a.new_details,a.new_summary,a.mode)
