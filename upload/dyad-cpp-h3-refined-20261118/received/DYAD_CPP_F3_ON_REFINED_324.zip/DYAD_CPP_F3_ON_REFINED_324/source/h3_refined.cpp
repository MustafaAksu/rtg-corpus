// [SESSION] Conditional k=3 necessary-condition comparison on the 324 refined F2 survivors.
// This file includes the reviewed horizon, selective F2, F2 and F1 implementation
// unchanged. No invariant-graph proof, point-jump certificate or 3c-b execution.
#define DYAD_HORIZON_NO_MAIN
#include "horizon.cpp"
#include <chrono>
#include <iomanip>
#include <map>
#include <set>

namespace h3ref {
using namespace dyad;
using namespace dyad::centered;
using Group=horizon::Id;
struct Frozen {
  size_t tile=0, parent=0, child=0, refined=0;
  C previous=C(0), probe=C(0), necessary=C(0), final=C(0);
  Z M=0,Dr=0,D=0,r=0,lb=0,err=0,rad=0;
  bool kept=false;
};
bool equal(const C &a,const C &b){return horizon::same_box(a,b);}
std::vector<Frozen> load_frozen(const std::vector<horizon::Row>& base,const std::string& file){
  std::map<Group,const horizon::Row*> parent;
  for(const auto &s:base)if(s.kept)parent.emplace(Group(s.tile,s.parent,s.child),&s);
  if(parent.size()!=144)throw std::runtime_error("selected F2 parent count differs");
  std::ifstream f(file);if(!f)throw std::runtime_error("missing frozen horizon-refine2 details.tsv");
  std::string header;std::getline(f,header);
  std::ostringstream hs;horizon::output_header(hs);std::string want=hs.str();
  want.pop_back();
  if(header!=want)throw std::runtime_error("wrong frozen horizon-refine2 header");
  std::set<std::tuple<size_t,size_t,size_t,size_t>> uniq;
  std::map<Group,std::set<size_t>> covered;
  std::vector<Frozen> out;size_t count_kept=0,count_excluded=0;
  std::string line;
  while(std::getline(f,line)){
    if(line.empty())throw std::runtime_error("blank frozen horizon row");
    std::istringstream s(line);Frozen t;std::string evaluation,action,extra;
    auto rd_box=[&](C& b){Z x0,x1,y0,y1;
      if(!(s>>x0>>x1>>y0>>y1))throw std::runtime_error("incomplete horizon box");
      if(x0>x1||y0>y1)throw std::runtime_error("inverted horizon box");
      b=C(I(x0,x1),I(y0,y1));
    };
    if(!(s>>t.tile>>t.parent>>t.child>>t.refined))throw std::runtime_error("incomplete horizon identity");
    rd_box(t.previous);rd_box(t.probe);rd_box(t.necessary);rd_box(t.final);
    if(!(s>>t.M>>t.Dr>>t.D>>t.r>>t.lb>>t.err>>t.rad>>evaluation>>action)||(s>>extra))
      throw std::runtime_error("invalid horizon row fields");
    const Group key(t.tile,t.parent,t.child);
    if(t.tile>=60||t.parent>=64||t.child>=4||t.refined>=4||!parent.count(key)||
       !uniq.insert(std::make_tuple(t.tile,t.parent,t.child,t.refined)).second||
       evaluation!="VALID"||(action!="EXCLUDED"&&action!="RETAINED"))
      throw std::runtime_error("horizon IDs/status invalid, duplicated, or not selected");
    if(!equal(t.previous,parent.at(key)->final))throw std::runtime_error("horizon parent rectangle changed");
    if(!equal(t.probe,f2::split_box(t.previous,2).at(t.refined)))
      throw std::runtime_error("horizon child not exact dyadic subdivision");
    if(t.M<=0||t.D<0||t.r<0||t.lb<=0||t.err<0||t.Dr<0||t.rad<0||
       t.Dr!=cd(t.D*t.r,SCALE)||t.rad!=t.err+cd((t.M+t.Dr)*SCALE,t.lb)||
       t.necessary.re.h-t.necessary.re.l!=2*t.rad||
       t.necessary.im.h-t.necessary.im.l!=2*t.rad)
      throw std::runtime_error("horizon integer C1C2 identity failed");
    const auto hit=intersection(t.probe,t.necessary);
    if(action=="RETAINED"){
      if(!hit||!equal(*hit,t.final))throw std::runtime_error("frozen retained horizon intersection mismatch");
      t.kept=true;++count_kept;
    }else{
      if(hit||!equal(t.final,C(0)))throw std::runtime_error("frozen excluded horizon intersection mismatch");
      ++count_excluded;
    }
    covered[key].insert(t.refined);out.push_back(t);
  }
  if(out.size()!=576||uniq.size()!=576||covered.size()!=144||count_kept!=324||count_excluded!=252)
    throw std::runtime_error("frozen horizon-refine2 counts differ from published run");
  for(const auto& [key,indices]:covered)if(indices!=std::set<size_t>({0,1,2,3}))
    throw std::runtime_error("incomplete frozen horizon parent coverage");
  return out;
}
void replay_frozen(const Frozen& t,const Data& data,const f1::ForwardTube& tube){
  Disk di=ball(t.probe);
  State whole=f2::iter(tube.at_start(),di,data.phi,2);
  const Z M=tube.upper(whole.a.v).M;
  State point=f2::iter(tube.at_start(),Disk(di.c,0),data.phi,2);
  const C slope=mid(point.b.d);const Z lb=norm_lower(slope);
  if(lb<=0)throw std::runtime_error("frozen positive slope cannot be revalidated");
  const Z D=norm_upper(whole.b.d-slope),Dr=cd(D*di.r,SCALE);
  Disk nd=necessary_disk(di,point.b.v,whole.b.d,slope,M);
  const C shift=di.c-point.b.v/slope;
  Z err=norm_upper(shift-mid(shift));
  const auto hit=intersection(t.probe,nd.box());
  if(t.M!=M||t.Dr!=Dr||t.D!=D||t.r!=di.r||t.lb!=lb||
     t.err!=err||t.rad!=nd.r||!equal(t.necessary,nd.box())||
     !hit||!equal(*hit,t.final))
    throw std::runtime_error("frozen refine2 survivor is not reproduced bit-exactly");
}
void output_header(std::ostream& o){
  o<<"tile parent_subtile child refine_subtile probe_subtile "
    "source_re_lo source_re_hi source_im_lo source_im_hi "
    "probe_re_lo probe_re_hi probe_im_lo probe_im_hi "
    "necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi "
    "final_re_lo final_re_hi final_im_lo final_im_hi "
    "M3_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action\n";
}
void record(std::ostream& o,const Frozen& t,size_t k,const C& b,const C& need,const C& fin,
            Z M,Z Dr,Z D,Z r,Z lb,Z err,Z rad,const char* ev,const char* act){
  o<<t.tile<<' '<<t.parent<<' '<<t.child<<' '<<t.refined<<' '<<k<<' ';
  selective::print_box(o,t.final);o<<' ';selective::print_box(o,b);
  o<<' ';selective::print_box(o,need);o<<' ';selective::print_box(o,fin);
  o<<' '<<M<<' '<<Dr<<' '<<D<<' '<<r<<' '<<lb<<' '<<err<<' '<<rad
   <<' '<<ev<<' '<<act<<'\n';
}
struct Result{
 size_t replay_base=0,replay_frozen=0,evaluated=0,retained=0,excluded=0,unresolved=0,dr_gt_m=0;
 Z Mmin=0,Mmax=0;std::optional<C> old_hull,new_hull;std::vector<Z> q;double seconds=0;
};
Result run(const Data& data,const std::vector<horizon::Row>& original,
           const std::vector<Frozen>& frozen,const std::string& mode,const std::string& path){
 if(mode!="h3_324"&&mode!="h3_split2")throw std::invalid_argument("mode must be h3_324 or h3_split2");
 f1::ForwardTube tube(data.c);Result st;std::ofstream out(path);
 if(!out)throw std::runtime_error("cannot open output TSV");
 output_header(out);
 const auto tick=std::chrono::steady_clock::now();
 for(const auto& a:original)if(a.kept){horizon::replay(a,data,tube);++st.replay_base;}
 for(const auto& a:frozen){
  if(!a.kept)continue;
  replay_frozen(a,data,tube);++st.replay_frozen;
  f1::add_hull(st.old_hull,a.final);
  const auto probes=(mode=="h3_split2"?f2::split_box(a.final,2):std::vector<C>{a.final});
  for(size_t k=0;k<probes.size();++k){
   const C& b=probes[k];Disk di=ball(b);++st.evaluated;
   try{
    State whole=f2::iter(tube.at_start(),di,data.phi,3);
    const Z M=tube.upper(whole.a.v).M;
    State point=f2::iter(tube.at_start(),Disk(di.c,0),data.phi,3);
    const C slope=mid(point.b.d);const Z lb=norm_lower(slope);
    if(lb<=0)throw std::domain_error("third-block slope may vanish");
    const Z D=norm_upper(whole.b.d-slope),Dr=cd(D*di.r,SCALE);
    const Disk nd=necessary_disk(di,point.b.v,whole.b.d,slope,M);
    const C shift=di.c-point.b.v/slope;const Z err=norm_upper(shift-mid(shift));
    if(nd.r!=err+cd((M+Dr)*SCALE,lb))throw std::runtime_error("C1C2 radius contradiction");
    st.Mmin=(st.Mmin==0||M<st.Mmin?M:st.Mmin);
    if(M>st.Mmax)st.Mmax=M;
    if(Dr>M)++st.dr_gt_m;
    st.q.push_back(cd(Dr*SCALE,M));
    const auto hit=intersection(b,nd.box());
    if(hit){++st.retained;f1::add_hull(st.new_hull,*hit);
      record(out,a,k,b,nd.box(),*hit,M,Dr,D,di.r,lb,err,nd.r,"VALID","RETAINED");
    }else{++st.excluded;
      record(out,a,k,b,nd.box(),C(0),M,Dr,D,di.r,lb,err,nd.r,"VALID","EXCLUDED");}
   }catch(const std::domain_error& e){
    ++st.unresolved;f1::add_hull(st.new_hull,b);
    record(out,a,k,b,b,b,0,0,0,0,0,0,0,"UNRESOLVED","RETAINED");
    if(st.unresolved<=5)std::cerr<<"UNRESOLVED "<<a.tile<<','<<a.parent<<','<<a.child<<','<<a.refined<<','<<k<<" "<<e.what()<<'\n';
   }
  }
 }
 out.flush();if(!out)throw std::runtime_error("failed writing details TSV");
 const size_t expected=(mode=="h3_324"?324:1296);
 if(st.replay_base!=144||st.replay_frozen!=324||st.evaluated!=expected||
    st.retained+st.excluded+st.unresolved!=st.evaluated)
    throw std::runtime_error("replay/coverage accounting failed");
 if(!st.old_hull||!st.new_hull)throw std::domain_error("candidate cover empty: no graph nonexistence claim");
 const C& b=*st.old_hull;const C& c=*st.new_hull;
 if(c.re.l<b.re.l||c.re.h>b.re.h||c.im.l<b.im.l||c.im.h>b.im.h)
    throw std::runtime_error("new hull leaves the frozen old hull");
 st.seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-tick).count();
 return st;
}
} // namespace h3ref

#ifndef DYAD_H3_REFINED_NO_MAIN
int main(int argc,char**argv){
 if(argc!=6){std::cerr<<"Usage: h3_refined TRANSFER SELECTIVE_F2_400_TSV REFINE2_576_TSV MODE(h3_324|h3_split2) OUT_DETAILS_TSV\n";return 64;}
 try{
  const std::string mode=argv[4];
  if(mode!="h3_324"&&mode!="h3_split2")throw std::invalid_argument("invalid h3 refined mode");
  const Data data=read_data(argv[1]);
  const auto source=horizon::load_checked_source(argv[2]);
  const auto frozen=h3ref::load_frozen(source,argv[3]);
  auto st=h3ref::run(data,source,frozen,mode,argv[5]);
  const Z oldrad=enclosing_disk(*st.old_hull).r,newrad=enclosing_disk(*st.new_hull).r;
  std::sort(st.q.begin(),st.q.end());
  std::cout<<"MODE=SESSION_CONDITIONAL; H3_ON_REFINED="<<mode<<"; SOURCE=H3_REFINE2_576\n";
  std::cout<<"source_selective_rows=400 source_horizon_rows=576 prior_refine2_excluded=252 prior_refine2_retained=324 "
           <<"checked_selective_retained="<<st.replay_base<<" checked_refine2_retained="<<st.replay_frozen<<'\n';
  std::cout<<"evaluations="<<st.evaluated<<" excluded="<<st.excluded<<" retained="<<st.retained
           <<" unresolved="<<st.unresolved<<'\n';
  std::cout<<"M3_min="<<f1::outdec(st.Mmin)<<" M3_max="<<f1::outdec(st.Mmax)
           <<" Dr_gt_M3="<<st.dr_gt_m<<'\n';
  if(!st.q.empty())std::cout<<"Dr_over_M3_min="<<f1::outdec(st.q.front())
    <<" median="<<f1::outdec(st.q[st.q.size()/2])<<" max="<<f1::outdec(st.q.back())<<'\n';
  std::cout<<"prior_L1_256="<<oldrad<<" final_L1_256="<<newrad<<'\n';
  std::cout<<"prior_L1="<<f1::outdec(oldrad)<<" final_L1="<<f1::outdec(newrad)<<'\n';
  std::cout<<"elapsed_seconds="<<std::fixed<<std::setprecision(3)<<st.seconds<<'\n';
  std::cout<<"NO_CERTIFICATE; k=3 tube/graph hypotheses conditional; NO stage3c-b or point jump.\n";
  return st.unresolved?2:0;
 }catch(const std::domain_error& e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<'\n';return 2;}
 catch(const std::exception& e){std::cerr<<"INPUT_FAIL: "<<e.what()<<'\n';return 3;}
}
#endif
