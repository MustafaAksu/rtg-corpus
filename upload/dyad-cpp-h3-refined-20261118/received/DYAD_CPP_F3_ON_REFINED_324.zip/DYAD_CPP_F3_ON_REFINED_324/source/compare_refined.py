#!/usr/bin/env python3
"""[SESSION] Compare two complete three-block development trials on exactly the same frozen F2 survivors."""
from pathlib import Path
import re,sys
if len(sys.argv)!=3:raise SystemExit('Usage: compare_refined.py H3_324_SUMMARY H3_SPLIT2_SUMMARY')
def read(p):
 t=Path(p).read_text();assert 'NO_CERTIFICATE' in t
 d=dict(re.findall(r'(?<!\S)([A-Za-z0-9_]+)=([A-Za-z0-9_.+-]+)',t))
 assert d.get('unresolved')=='0' and d.get('checked_refine2_retained')=='324'
 assert d.get('checked_selective_retained')=='144' and d.get('source_horizon_rows')=='576'
 return d
x,y=map(read,sys.argv[1:]);assert x['H3_ON_REFINED']=='h3_324' and y['H3_ON_REFINED']=='h3_split2'
assert x['prior_L1_256']==y['prior_L1_256']
assert int(x['evaluations'])==324 and int(y['evaluations'])==1296
for a in (x,y):
 print(a['H3_ON_REFINED'],f"evaluations={a['evaluations']}",f"retained={a['retained']}",
       f"excluded={a['excluded']}",f"unresolved={a['unresolved']}",
       f"finalL1={a['final_L1']}",f"elapsed_seconds={a['elapsed_seconds']}",
       f"Dr_gt_M3={a['Dr_gt_M3']}",f"median_Dr_over_M3={a['median']}")
r0=int(x['prior_L1_256']);r1=int(x['final_L1_256']);r2=int(y['final_L1_256'])
t1=float(x['elapsed_seconds']);t2=float(y['elapsed_seconds'])
assert r0>0 and r1>0 and r2>0 and t1>0 and t2>0
print('h3_324_radius_reduction_pct=%.8f'%(100*(1-r1/r0)))
print('h3_split2_radius_reduction_pct=%.8f'%(100*(1-r2/r0)))
print('h3_split2_over_h3_324_radius_ratio=%.8f'%(r2/r1))
print('h3_split2_over_h3_324_elapsed_ratio=%.6f'%(t2/t1))
print('SESSION_ONLY; same-engine finite-precision campaign, graph/tube hypotheses conditional; no point jump')
