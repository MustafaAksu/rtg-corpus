// [SESSION] Parser-only structural control; no engine orbit or numerical claim.
#define DYAD_H3_REFINED_NO_MAIN
#include "h3_refined.cpp"
int main(int argc,char** argv){
 if(argc!=3)return 64;
 try{
  auto first=horizon::load_checked_source(argv[1]);
  auto second=h3ref::load_frozen(first,argv[2]);
  size_t a=0,b=0;for(const auto&x:first)if(x.kept)++a;
  for(const auto&x:second)if(x.kept)++b;
  if(first.size()!=400||second.size()!=576||a!=144||b!=324)return 3;
  std::cout<<"FROZEN_CHAIN_PARSER_PASS 400/144 -> 576/324\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 3;}
}
