#!/usr/bin/env python3
"""[SESSION] Complete synthetic 400→576→324→1296 arithmetic/coverage + mutation tests.
No actual DYAD dynamics; exact integers and data-structure fidelity only.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
import sys,subprocess
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import check_h3_refined as H
S=1<<256
PS=('tile parent_subtile child parent_re_lo parent_re_hi parent_im_lo parent_im_hi '
    'child_re_lo child_re_hi child_im_lo child_im_hi necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
    'final_re_lo final_re_hi final_im_lo final_im_hi M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
PR=('tile parent_subtile child new_subtile source_re_lo source_re_hi source_im_lo source_im_hi '
    'probe_re_lo probe_re_hi probe_im_lo probe_im_hi necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
    'final_re_lo final_re_hi final_im_lo final_im_hi M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
def box(b):return ' '.join(map(str,b))
def bounds(p,include,rad=1):
 x=(p[0]+p[1])//2;y=(p[2]+p[3])//2
 if not include:x+=10**8
 n=(x-rad,x+rad,y-rad,y+rad);v=H.meet(p,n)
 assert (v is not None)==include
 return n,v if v else (0,0,0,0)
def manufacture(folder):
 src=[PS];selected=[]
 for g in range(100):
  i,j=g//64,g%64
  p=(g*100,g*100+16,g*29,g*29+16)
  for k in range(4):
   c=H.cut(p,k);yes=len(src)-1<144;n,fin=bounds(c,yes)
   if yes:selected.append(((i,j,k),fin))
   src.append(f'{i} {j} {k} '+box(p)+' '+box(c)+' '+box(n)+' '+box(fin)+f' 1 0 0 0 {S} 0 1 VALID '+('RETAINED' if yes else 'EXCLUDED'))
 (folder/'selective.tsv').write_text('\n'.join(src)+'\n');assert len(selected)==144
 prior=[PR];survivors=[]
 for key,p in selected:
  for s in range(4):
   c=H.cut(p,s);yes=len(prior)-1<324;n,fin=bounds(c,yes)
   if yes:survivors.append((*key,s,fin))
   prior.append(' '.join(map(str,(*key,s)))+' '+box(p)+' '+box(c)+' '+box(n)+' '+box(fin)+f' 1 0 0 0 {S} 0 1 VALID '+('RETAINED' if yes else 'EXCLUDED'))
 (folder/'refine2.tsv').write_text('\n'.join(prior)+'\n');assert len(survivors)==324
 assert len(H.load_refine2(folder/'selective.tsv',folder/'refine2.tsv'))==324
 return survivors

def result(folder,survivors,mode):
 new=[H.HEADER];retained=[];fail=4 if mode=='h3_324' else 200;count=0
 for i,j,k,s,p in survivors:
  subs=[p] if mode=='h3_324' else [H.cut(p,t) for t in range(4)]
  for t,probe in enumerate(subs):
   yes=count>=fail
   need,fin=bounds(probe,yes,rad=2)
   if yes:retained.append(fin)
   new.append(f'{i} {j} {k} {s} {t} '+box(p)+' '+box(probe)+' '+box(need)+' '+box(fin)+f' 2 0 0 0 {S} 0 2 VALID '+('RETAINED' if yes else 'EXCLUDED'))
   count+=1
 (folder/'new.tsv').write_text('\n'.join(new)+'\n')
 old=H.radius(H.hull([x[4] for x in survivors]));fresh=H.radius(H.hull(retained))
 assert fresh<=old
 (folder/'summary.txt').write_text('MODE=SESSION_CONDITIONAL; H3_ON_REFINED='+mode+'; SOURCE=H3_REFINE2_576\n'
  'source_selective_rows=400 source_horizon_rows=576 prior_refine2_excluded=252 prior_refine2_retained=324 checked_selective_retained=144 checked_refine2_retained=324\n'
  f'evaluations={count} excluded={fail} retained={count-fail} unresolved=0\n'
  f'M3_min=2.0 M3_max=2.0 Dr_gt_M3=0\n'
  f'prior_L1_256={old} final_L1_256={fresh}\nNO_CERTIFICATE\n')
 H.check(folder/'selective.tsv',folder/'refine2.tsv',folder/'new.tsv',folder/'summary.txt',mode)
 # 8 distinct corruptions of new output; all must fail the check.
 org=(folder/'new.tsv').read_text().splitlines()
 for n in range(8):
  lines=list(org)
  if n==0:lines.pop()
  elif n==1:lines[-1]=lines[-2]
  else:
   w=lines[1].split()
   if n==2:w[5]=str(int(w[5])+1) # source box lower
   if n==3:w[9]=str(int(w[9])+1) # probe split
   if n==4:w[22]=str(int(w[22])+1) # Dr integer identity
   if n==5:w[27]=str(int(w[27])+1) # radius identity
   if n==6:w[-1]='RETAINED' if w[-1]=='EXCLUDED' else 'EXCLUDED'
   if n==7:w[4]='9' # wrong child index
   lines[1]=' '.join(w)
  (folder/'bad.tsv').write_text('\n'.join(lines)+'\n')
  try:H.check(folder/'selective.tsv',folder/'refine2.tsv',folder/'bad.tsv',folder/'summary.txt',mode)
  except (AssertionError,ValueError,KeyError):pass
  else:raise AssertionError('accepted corrupt new record '+str(n))
 print('STRUCTURE_MUTATION_PASS mode='+mode+' negative=8')
 return org

def main():
 with TemporaryDirectory() as d:
  p=Path(d);sv=manufacture(p)
  for mode in ('h3_324','h3_split2'):result(p,sv,mode)
  old=(p/'refine2.tsv').read_text().splitlines()
  mutations=[old[:-1],old+[old[-1]],old.copy(),old.copy(),old.copy()]
  x=mutations[2][1].split();x[4]=str(int(x[4])+1);mutations[2][1]=' '.join(x)
  x=mutations[3][1].split();x[25]=str(int(x[25])+1);mutations[3][1]=' '.join(x)
  x=mutations[4][1].split();x[-1]='EXCLUDED' if x[-1]=='RETAINED' else 'RETAINED';mutations[4][1]=' '.join(x)
  for n,bad in enumerate(mutations):
   (p/'badold.tsv').write_text('\n'.join(bad)+'\n')
   try:H.load_refine2(p/'selective.tsv',p/'badold.tsv')
   except (AssertionError,ValueError,KeyError):pass
   else:raise AssertionError('accepted corrupt frozen refine2 '+str(n))
  old=(p/'selective.tsv').read_text().splitlines()
  (p/'badselective.tsv').write_text('\n'.join(old[:-1])+'\n')
  try:H.load_refine2(p/'badselective.tsv',p/'refine2.tsv')
  except (AssertionError,ValueError,KeyError):pass
  else:raise AssertionError('accepted incomplete frozen 400 row source')
  print('FROZEN_MUTATION_PASS negative=6; TEST_H3_REFINED_STRUCTURE_PASS')
  if len(sys.argv)>1:
   exe=Path(sys.argv[1]);q=subprocess.run([str(exe),str(p/'selective.tsv'),str(p/'refine2.tsv')],capture_output=True,text=True)
   assert q.returncode==0,(q.returncode,q.stdout,q.stderr);print(q.stdout.strip())
   for f1,f2 in [('badselective.tsv','refine2.tsv'),('selective.tsv','badold.tsv')]:
    q=subprocess.run([str(exe),str(p/f1),str(p/f2)],capture_output=True,text=True)
    assert q.returncode==3,(f1,f2,q.returncode)
   print('CPP_PARSER_NEGATIVE_PASS')
if __name__=='__main__':main()
