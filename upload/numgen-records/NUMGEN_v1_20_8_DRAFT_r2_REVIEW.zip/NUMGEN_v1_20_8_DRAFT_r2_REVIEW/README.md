# NUMGEN v1.20.8 DRAFT r2 — review package

Re-run, from this folder:

1. `python3 check_v1_20_8_r2.py --neg`
   - Builds the draft from the frozen base `RTG_NUMBER_GENESIS_DSN_v1_20_7.md` (`c4637e7a…fab28`, included byte-exact).
   - Expected: G1–G11 PASS, N1–N7 FAIL, exit 0.
2. `python3 ng_inv_live_v1_1.py RTG_NUMBER_GENESIS_DSN_v1_20_8_DRAFT_r2.md`
   - Expected: 0 live hits.
3. Receipt replay of the Dyadic row-A certificate:
   - `cd replay_inputs_dyad && python3 dyad_numgen_lphase_rowA_cert.py`
   - Expected: `RESULT: PASS`, exit 0.
   - The regenerated `lphase_rowA_certificate.json` has SHA-256 `8697c697…a4fa`, byte-identical to the included Dyadic copy.
   - `replay_inputs_dyad/` holds unchanged copies of the Dyadic files: Dyadic owns them; they are included only for replay.

`SHA256SUMS.txt` lists every file in this package.
