// [SESSION] Budgeted conditional k>=4 adapter, starting at frozen h3_split2.
// This code does not certify the sectorial graph/tube assumptions or point jump.
#define DYAD_H3_REFINED_NO_MAIN
#include "h3_refined.cpp"
#include <deque>
#include <chrono>
#include <map>
#include <set>
#include <algorithm>
#include <iomanip>

namespace adapt {
using namespace dyad;
using namespace dyad::centered;
using Key = std::tuple<size_t,size_t,size_t,size_t>;
struct Seed {
 size_t tile=0,parent=0,child=0,refined=0,split=0;
 C source=C(0),probe=C(0),need=C(0),final=C(0);
 Z M=0,Dr=0,D=0,r=0,lb=0,err=0,rad=0;
 bool kept=false;
 std::string id()const{std::ostringstream o;o<<tile<<'.'<<parent<<'.'<<child<<'.'<<refined<<'.'<<split;return o.str();}
};
using Group=h3ref::Group;
bool same(const C&a,const C&b){return h3ref::equal(a,b);}
std::vector<Seed> load_seeds(const std::vector<h3ref::Frozen>& frozen,const std::string& path){
 std::map<Key,const h3ref::Frozen*> source;
 for(const auto& a:frozen)if(a.kept)source.emplace(Key(a.tile,a.parent,a.child,a.refined),&a);
 if(source.size()!=324)throw std::runtime_error("frozen refine2 survivors != 324");
 std::ifstream f(path);if(!f)throw std::runtime_error("frozen h3_split2 TSV is missing");
 std::ostringstream s;h3ref::output_header(s);auto header=s.str();header.pop_back();
 std::string line;std::getline(f,line);if(line!=header)throw std::runtime_error("frozen h3_split2 header mismatch");
 std::set<std::tuple<size_t,size_t,size_t,size_t,size_t>> seen;
 std::map<Key,std::set<size_t>> covered;
 std::vector<Seed> result;size_t kept=0,excluded=0;
 auto box=[&](std::istringstream& stream,C& dest){Z a,b,c,d;
  if(!(stream>>a>>b>>c>>d)||a>b||c>d)throw std::runtime_error("malformed source box");
  dest=C(I(a,b),I(c,d));};
 while(std::getline(f,line)){
  if(line.empty())throw std::runtime_error("empty h3_split2 source row");
  std::istringstream in(line);Seed x;std::string status,action,extra;
  if(!(in>>x.tile>>x.parent>>x.child>>x.refined>>x.split))throw std::runtime_error("bad source key");
  box(in,x.source);box(in,x.probe);box(in,x.need);box(in,x.final);
  if(!(in>>x.M>>x.Dr>>x.D>>x.r>>x.lb>>x.err>>x.rad>>status>>action)||(in>>extra))
   throw std::runtime_error("bad source row fields");
  Key key(x.tile,x.parent,x.child,x.refined);
  if(x.tile>=60||x.parent>=64||x.child>=4||x.refined>=4||x.split>=4||
     !source.count(key)||!seen.emplace(x.tile,x.parent,x.child,x.refined,x.split).second||
     status!="VALID"||(action!="RETAINED"&&action!="EXCLUDED"))
   throw std::runtime_error("invalid/duplicated source row or unresolved source");
  const C& root=source.at(key)->final;
  if(!same(x.source,root)||!same(x.probe,f2::split_box(root,2).at(x.split)))
   throw std::runtime_error("h3_split2 source partition not exact");
  if(x.M<=0||x.Dr<0||x.D<0||x.r<0||x.lb<=0||x.err<0||x.rad<0||
     x.Dr!=cd(x.D*x.r,SCALE)||x.rad!=x.err+cd((x.M+x.Dr)*SCALE,x.lb)||
     x.need.re.h-x.need.re.l!=2*x.rad||x.need.im.h-x.need.im.l!=2*x.rad)
   throw std::runtime_error("h3_split2 source C1-C2 identity mismatch");
  auto hit=intersection(x.probe,x.need);
  if(action=="RETAINED"){
   if(!hit||!same(*hit,x.final))throw std::runtime_error("source retained intersection differs");
   x.kept=true;++kept;
  }else{
   if(hit||!same(x.final,C(0)))throw std::runtime_error("source excluded intersection differs");
   ++excluded;
  }
  covered[key].insert(x.split);result.push_back(x);
 }
 if(result.size()!=1296||seen.size()!=1296||covered.size()!=324||kept!=324||excluded!=972)
  throw std::runtime_error("frozen h3_split2 count/coverage failure");
 for(const auto& kv:covered)if(kv.second!=std::set<size_t>({0,1,2,3}))
  throw std::runtime_error("incomplete h3_split2 parent partition");
 return result;
}
void replay_seed(const Seed& a,const Data&data,const f1::ForwardTube&tube){
 Disk di=ball(a.probe);
 State whole=f2::iter(tube.at_start(),di,data.phi,3);
 const Z M=tube.upper(whole.a.v).M;
 State point=f2::iter(tube.at_start(),Disk(di.c,0),data.phi,3);
 const C slope=mid(point.b.d);const Z lb=norm_lower(slope);
 if(lb<=0)throw std::runtime_error("h3_split2 source slope not verified");
 const Z D=norm_upper(whole.b.d-slope),Dr=cd(D*di.r,SCALE);
 const Disk need=necessary_disk(di,point.b.v,whole.b.d,slope,M);
 const C shift=di.c-point.b.v/slope;
 const Z err=norm_upper(shift-mid(shift));
 const auto hit=intersection(a.probe,need.box());
 if(a.M!=M||a.Dr!=Dr||a.D!=D||a.r!=di.r||a.lb!=lb||
    a.err!=err||a.rad!=need.r||!same(a.need,need.box())||!hit||!same(a.final,*hit))
  throw std::runtime_error("h3_split2 retained source not reproduced bit-exactly");
}
struct Work {std::string id;C box=C(0);size_t depth=0;};
struct Options{size_t first_k=4,max_k=5,budget=1500,max_depth=2,max_frontier=4096;};
struct Stats{
 size_t k=0,initial=0,evaluated=0,excluded=0,split=0,retained=0,unresolved=0,
        budget_kept=0,depth_kept=0,frontier_kept=0,dr_gt_m=0;
 Z Mmin=0,Mmax=0,oldrad=0,newrad=0;std::vector<Z> q;std::string stop;
};
void boxprint(std::ostream &out,const C&b){selective::print_box(out,b);}
void output_header(std::ostream& out){
 out<<"k id depth source_re_lo source_re_hi source_im_lo source_im_hi "
   "necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi "
   "final_re_lo final_re_hi final_im_lo final_im_hi "
   "M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action\n";
}
void record(std::ostream& out,size_t k,const Work&w,const C&need,const C&fin,
 Z M,Z Dr,Z D,Z r,Z lb,Z err,Z rad,const char*ev,const char*act){
 out<<k<<' '<<w.id<<' '<<w.depth<<' ';boxprint(out,w.box);
 out<<' ';boxprint(out,need);out<<' ';boxprint(out,fin);
 out<<' '<<M<<' '<<Dr<<' '<<D<<' '<<r<<' '<<lb<<' '<<err<<' '<<rad
    <<' '<<ev<<' '<<act<<'\n';
}
std::optional<C> hull(const std::vector<Work>& v){
 std::optional<C> h;
 for(const auto &w:v)f1::add_hull(h,w.box);
 return h;
}
Stats stage(const Data&data,const f1::ForwardTube&tube,
 std::vector<Work>&front,size_t k,const Options&opt,size_t&total,std::ostream&out){
 Stats st;st.k=k;st.initial=front.size();
 const auto old=hull(front);if(!old)throw std::domain_error("empty candidate cover; no non-existence claim");
 st.oldrad=enclosing_disk(*old).r;
 std::deque<Work> queue(front.begin(),front.end());
 std::vector<Work> kept;kept.reserve(front.size());
 while(!queue.empty()){
  Work w=queue.front();queue.pop_front();
  if(total>=opt.budget){
   st.budget_kept++;record(out,k,w,w.box,w.box,0,0,0,0,0,0,0,"NOT_EVALUATED","BUDGET_KEEP");
   kept.push_back(w);continue;
  }
  total++;st.evaluated++;
  try{
   const Disk di=ball(w.box);
   State whole=f2::iter(tube.at_start(),di,data.phi,static_cast<int>(k));
   const Z M=tube.upper(whole.a.v).M;
   State point=f2::iter(tube.at_start(),Disk(di.c,0),data.phi,static_cast<int>(k));
   const C slope=mid(point.b.d);const Z lb=norm_lower(slope);
   if(lb<=0)throw std::domain_error("slope may vanish");
   const Z D=norm_upper(whole.b.d-slope),Dr=cd(D*di.r,SCALE);
   const Disk nd=necessary_disk(di,point.b.v,whole.b.d,slope,M);
   const C shift=di.c-point.b.v/slope;const Z err=norm_upper(shift-mid(shift));
   if(M<=0||nd.r!=err+cd((M+Dr)*SCALE,lb))throw std::runtime_error("C1C2 radius contradiction");
   if(st.Mmin==0||M<st.Mmin)st.Mmin=M;
   if(M>st.Mmax)st.Mmax=M;
   if(Dr>M)++st.dr_gt_m;
   st.q.push_back(cd(Dr*SCALE,M));
   const auto hit=intersection(w.box,nd.box());
   if(!hit){st.excluded++;record(out,k,w,nd.box(),C(0),M,Dr,D,di.r,lb,err,nd.r,"VALID","EXCLUDED");continue;}
   // Split only the *post-contractor* intersection. This is a scheduling
   // heuristic, not a logical premise of any exclusion.
   const bool high=(2*Dr>M);
   const bool can_split=(w.depth<opt.max_depth &&
      queue.size()+kept.size()+4<=opt.max_frontier &&
      total+queue.size()+4<=opt.budget);
   if(high&&can_split){
    st.split++;record(out,k,w,nd.box(),*hit,M,Dr,D,di.r,lb,err,nd.r,"VALID","SPLIT");
    const auto children=f2::split_box(*hit,2);
    for(size_t j=0;j<4;j++)queue.push_back(Work{w.id+"/"+std::to_string(j),children[j],w.depth+1});
   }else{
    st.retained++;
    if(high){if(w.depth>=opt.max_depth)st.depth_kept++;
      else if(queue.size()+kept.size()+4>opt.max_frontier)st.frontier_kept++;
      else st.budget_kept++;}
    record(out,k,w,nd.box(),*hit,M,Dr,D,di.r,lb,err,nd.r,"VALID","RETAINED");
    kept.push_back(Work{w.id,*hit,w.depth});
   }
  }catch(const std::domain_error& e){
   st.unresolved++;st.retained++;
   record(out,k,w,w.box,w.box,0,0,0,0,0,0,0,"UNRESOLVED","RETAINED");
   kept.push_back(w);
   if(st.unresolved<=3)std::cerr<<"UNRESOLVED k="<<k<<" id="<<w.id<<" "<<e.what()<<'\n';
  }
 }
 if(st.evaluated+st.budget_kept<st.initial)throw std::runtime_error("stage accounting impossible");
 const auto nw=hull(kept);
 if(!nw)throw std::domain_error("outer candidate set empty; cannot infer no graph");
 if(nw->re.l<old->re.l||nw->re.h>old->re.h||nw->im.l<old->im.l||nw->im.h>old->im.h)
  throw std::runtime_error("adaptive hull expanded");
 st.newrad=enclosing_disk(*nw).r;
 if(st.budget_kept)st.stop="BUDGET";
 else if(st.depth_kept||st.frontier_kept)st.stop="REFINEMENT_CAP";
 else if(st.unresolved)st.stop="DOMAIN";
 else st.stop="READY";
 front.swap(kept);
 return st;
}
void frontier_header(std::ostream& out){out<<"id depth re_lo re_hi im_lo im_hi\n";}
void print_frontier(std::ostream&out,const std::vector<Work>&front){
 frontier_header(out);
 for(const auto&v:front){out<<v.id<<' '<<v.depth<<' ';boxprint(out,v.box);out<<'\n';}
}
void print_stats(std::ostream& out,const Stats&s){
 std::vector<Z> ratios=s.q;std::sort(ratios.begin(),ratios.end());
 out<<s.k<<' '<<s.initial<<' '<<s.evaluated<<' '<<s.excluded<<' '<<s.split
   <<' '<<s.retained<<' '<<s.unresolved<<' '<<s.budget_kept<<' '<<s.depth_kept
   <<' '<<s.frontier_kept<<' '<<s.oldrad<<' '<<s.newrad<<' '
   <<(ratios.empty()?Z(0):ratios[ratios.size()/2])<<' '<<s.dr_gt_m<<' '<<s.stop<<'\n';
}
int execute(const Data &data,const std::vector<horizon::Row>&original,
 const std::vector<h3ref::Frozen>&frozen,const std::vector<Seed>&seeds,
 const Options&opt,const std::string& prefix){
 f1::ForwardTube tube(data.c);
 size_t replay_base=0,replay_frozen=0,replay_seed=0;
 for(const auto&a:original)if(a.kept){horizon::replay(a,data,tube);replay_base++;}
 for(const auto&a:frozen)if(a.kept){h3ref::replay_frozen(a,data,tube);replay_frozen++;}
 std::vector<Work> frontier;
 for(const auto&a:seeds)if(a.kept){adapt::replay_seed(a,data,tube);replay_seed++;
  frontier.push_back(Work{a.id(),a.final,0});}
 if(replay_base!=144||replay_frozen!=324||replay_seed!=324||frontier.size()!=324)
  throw std::runtime_error("frozen source replay count mismatch");
 std::ofstream initial(prefix+"/initial_frontier.tsv");print_frontier(initial,frontier);initial.close();
 std::ofstream out(prefix+"/events.tsv"),stg(prefix+"/stages.tsv");
 if(!out||!stg)throw std::runtime_error("cannot open adaptive output files");
 output_header(out);
 stg<<"k input evaluated excluded split retained unresolved budget_kept depth_kept frontier_kept prior_L1_256 final_L1_256 median_ratio_256 Dr_gt_M stop\n";
 size_t total=0;std::string stop="MAX_K";size_t stages=0;
 for(size_t k=opt.first_k;k<=opt.max_k;k++){
  if(total>=opt.budget){stop="BUDGET";break;}
  for(auto& w:frontier)w.depth=0; // per-horizon subdivision depth; reset at each new k
  auto s=stage(data,tube,frontier,k,opt,total,out);print_stats(stg,s);stages++;
  out.flush();stg.flush();
  if(!out||!stg)throw std::runtime_error("cannot write adaptive results");
  std::cout<<"STAGE="<<k<<" evaluated="<<s.evaluated<<" excluded="<<s.excluded
           <<" split="<<s.split<<" retained="<<frontier.size()
           <<" unresolved="<<s.unresolved<<" budget_kept="<<s.budget_kept
           <<" depth_kept="<<s.depth_kept<<" frontier_kept="<<s.frontier_kept
           <<" L1="<<f1::outdec(s.newrad)<<" status="<<s.stop<<'\n';
  if(s.stop!="READY"){stop=s.stop;break;}
 }
 out.close();stg.close();
 std::ofstream fin(prefix+"/final_frontier.tsv");print_frontier(fin,frontier);fin.close();
 const auto hh=hull(frontier);if(!hh)throw std::runtime_error("empty adaptive frontier");
 const Z rad=enclosing_disk(*hh).r;
 std::cout<<"STATUS="<<stop<<" initial=324 replay_400="<<replay_base
          <<" replay_576="<<replay_frozen<<" replay_1296="<<replay_seed
          <<" stages="<<stages<<" total_evaluations="<<total<<" budget="<<opt.budget
          <<" final_boxes="<<frontier.size()<<" final_L1_256="<<rad
          <<" final_L1="<<f1::outdec(rad)<<'\n';
 std::cout<<"SESSION_ONLY; all candidates retained on budget/domain/cap; NO certificate, point jump or stage3c-b.\n";
 return (stop=="MAX_K"?0:2);
}
size_t arg(const std::string&s,const char*name,size_t lo,size_t hi){
 if(s.empty()||s.find_first_not_of("0123456789")!=std::string::npos)throw std::invalid_argument(std::string("invalid ")+name);
 size_t n=static_cast<size_t>(std::stoull(s));if(n<lo||n>hi)throw std::invalid_argument(std::string("out-of-range ")+name);return n;
}
} // namespace adapt

#ifndef DYAD_ADAPTIVE_NO_MAIN
int main(int argc,char**argv){
 if(argc!=11){std::cerr<<"Usage: adaptive TRANSFER SELECTIVE400 REFINE2_576 H3_SPLIT2_1296 OUTPUT_DIR START_K MAX_K EVAL_BUDGET MAX_SPLIT_DEPTH MAX_FRONTIER\n";return 64;}
 try{
  adapt::Options opt;
  opt.first_k=adapt::arg(argv[6],"START_K",4,20);
  opt.max_k=adapt::arg(argv[7],"MAX_K",opt.first_k,20);
  opt.budget=adapt::arg(argv[8],"EVAL_BUDGET",1,100000);
  opt.max_depth=adapt::arg(argv[9],"MAX_SPLIT_DEPTH",0,8);
  opt.max_frontier=adapt::arg(argv[10],"MAX_FRONTIER",324,20000);
  const Data data=read_data(argv[1]);
  const auto rows=horizon::load_checked_source(argv[2]);
  const auto frozen=h3ref::load_frozen(rows,argv[3]);
  const auto seeds=adapt::load_seeds(frozen,argv[4]);
  return adapt::execute(data,rows,frozen,seeds,opt,argv[5]);
 }catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<'\n';return 2;}
  catch(const std::exception&e){std::cerr<<"INPUT_FAIL: "<<e.what()<<'\n';return 3;}
}

#endif // DYAD_ADAPTIVE_NO_MAIN
