// [SESSION] Parser-only control; source/dyadic identity checks, no orbit evaluation.
#define DYAD_ADAPTIVE_NO_MAIN
#include "adaptive.cpp"

int main(int argc,char**argv){
 if(argc!=4)return 64;
 try{
  const auto a=horizon::load_checked_source(argv[1]);
  const auto b=h3ref::load_frozen(a,argv[2]);
  const auto c=adapt::load_seeds(b,argv[3]);
  size_t count=0;for(const auto &x:c)if(x.kept)++count;
  if(a.size()!=400||b.size()!=576||c.size()!=1296||count!=324)return 3;
  std::cout<<"ADAPTIVE_FROZEN_SOURCE_PARSE_PASS 400 -> 576 -> 1296 -> 324\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 3;}
}
