#!/usr/bin/env python3
"""[SESSION] Independent exact-integer audit of all adaptive events and frontier stages.

Runs independently of the C++ arithmetic engine. Checks finite records and
coverage, not the sectorial graph/tube hypotheses, nor C++ elementary enclosure correctness.
"""
from pathlib import Path
from collections import defaultdict, deque
import argparse, re
S=1<<256
HEADER='k id depth source_re_lo source_re_hi source_im_lo source_im_hi necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi final_re_lo final_re_hi final_im_lo final_im_hi M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action'
STAGES='k input evaluated excluded split retained unresolved budget_kept depth_kept frontier_kept prior_L1_256 final_L1_256 median_ratio_256 Dr_gt_M stop'
FRONT='id depth re_lo re_hi im_lo im_hi'

def cd(x,y):
    assert y>0
    return -(-x//y)

def meet(a,b):
    x=(max(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),min(a[3],b[3]))
    return x if x[0]<=x[1] and x[2]<=x[3] else None

def cut(p,k):
    a,b,c,d=p;dx=b-a;dy=d-c
    assert 0<=k<4 and dx>=0 and dy>=0
    i,j=divmod(k,2)
    return (a+dx*i//2,a+cd(dx*(i+1),2),c+dy*j//2,c+cd(dy*(j+1),2))

def hull(boxes):
    assert boxes
    return (min(b[0] for b in boxes),max(b[1] for b in boxes),min(b[2] for b in boxes),max(b[3] for b in boxes))

def radius(b):
    mx=(b[0]+b[1])//2;my=(b[2]+b[3])//2
    return max(abs(mx-b[0]),abs(mx-b[1]))+max(abs(my-b[2]),abs(my-b[3]))

def load_front(path):
    t=Path(path).read_text().splitlines()
    assert t[0]==FRONT
    rows=[]; seen=set()
    for i,x in enumerate(t[1:],1):
        w=x.split();assert len(w)==6,(i,len(w))
        id=w[0];d=int(w[1]);b=tuple(map(int,w[2:6]))
        assert id not in seen and d>=0 and b[0]<=b[1] and b[2]<=b[3]
        seen.add(id);rows.append((id,d,b))
    return rows

def load_seed(path):
    t=Path(path).read_text().splitlines()
    assert t[0].startswith('tile parent_subtile child refine_subtile probe_subtile ')
    assert len(t)==1297
    out={};source=defaultdict(set);ct=defaultdict(int)
    for i,line in enumerate(t[1:],1):
        w=line.split();assert len(w)==30,(i,len(w))
        a=list(map(int,w[:28]));tile,parent,child,refined,split=a[:5]
        assert 0<=tile<60 and 0<=parent<64 and 0<=child<4 and 0<=refined<4 and 0<=split<4
        root=tuple(a[5:9]);b=tuple(a[9:13]);need=tuple(a[13:17]);fin=tuple(a[17:21]);M,Dr,D,r,lb,e,rad=a[21:28]
        key=(tile,parent,child,refined,split)
        assert key not in source[(tile,parent,child,refined)]
        source[(tile,parent,child,refined)].add(key)
        assert b==cut(root,split) and w[28]=='VALID'
        assert M>0 and lb>0 and D>=0 and Dr>=0 and r>=0 and e>=0 and rad>=0
        assert Dr==cd(D*r,S) and rad==e+cd((M+Dr)*S,lb)
        assert need[1]-need[0]==2*rad and need[3]-need[2]==2*rad
        hit=meet(b,need);assert (hit is None)==(w[29]=='EXCLUDED')
        assert fin==(hit if hit is not None else (0,0,0,0))
        ct[w[29]]+=1
        if hit is not None:out['.'.join(map(str,key))]=(0,fin)
    assert len(source)==324 and all(len(x)==4 for x in source.values())
    assert ct=={'EXCLUDED':972,'RETAINED':324}
    return out

def audit(seedfile,initialfile,eventsfile,stagesfile,finalfile, budget,max_depth,max_frontier,start_k,max_k):
    seeds=load_seed(seedfile)
    initial=load_front(initialfile)
    assert len(initial)==324 and len(seeds)==324 and dict((id,(d,b)) for id,d,b in initial)==seeds
    ev=Path(eventsfile).read_text().splitlines();assert ev[0]==HEADER
    et=[]
    for i,line in enumerate(ev[1:],1):
        w=line.split();assert len(w)==24,(i,len(w))
        k=int(w[0]);id=w[1];depth=int(w[2]);nums=list(map(int,w[3:22]));evn,action=w[22:24]
        assert k>=start_k and k<=max_k and 0<=depth<=max_depth
        b=tuple(nums[0:4]);need=tuple(nums[4:8]);fin=tuple(nums[8:12]);M,Dr,D,r,lb,e,rad=nums[12:19]
        et.append((k,id,depth,b,need,fin,M,Dr,D,r,lb,e,rad,evn,action))
    stages=Path(stagesfile).read_text().splitlines();assert stages[0]==STAGES
    sr=[]
    for i,line in enumerate(stages[1:],1):
        w=line.split();assert len(w)==15,(i,len(w))
        sr.append(tuple(map(int,w[:14]))+(w[14],))
    assert len(sr)<=max_k-start_k+1 and len(sr)>=1
    frontier=initial; idx=0;total=0;lastk=start_k-1
    for sn,sc in enumerate(sr):
        k=sc[0]
        assert k==start_k+sn
        # reset local subdivision depth for the new horizon
        queue=deque((id,0,b) for id,_,b in frontier)
        old=radius(hull([x[2] for x in queue]));source_len=len(queue)
        kept=[];valid_q=[];excluded=split=retained=unresolved=budget_keep=depth_keep=frontier_keep=dr_gt=evals=0
        while queue:
            id,d,b=queue.popleft()
            assert idx<len(et),('missing event',idx,id)
            (kr,ir,dr,br,need,fin,M,Dr,D,r,lb,e,rad,evn,action)=et[idx];idx+=1
            assert kr==k and ir==id and dr==d and br==b,('wrong event',idx,id)
            if total>=budget:
                assert evn=='NOT_EVALUATED' and action=='BUDGET_KEEP'
                assert need==b and fin==b and all(x==0 for x in (M,Dr,D,r,lb,e,rad))
                budget_keep+=1;kept.append((id,d,b));continue
            total+=1;evals+=1
            if evn=='UNRESOLVED':
                assert action=='RETAINED' and need==b and fin==b and all(x==0 for x in (M,Dr,D,r,lb,e,rad))
                unresolved+=1;retained+=1;kept.append((id,d,b));continue
            assert evn=='VALID' and action in ('RETAINED','EXCLUDED','SPLIT')
            assert M>0 and lb>0 and D>=0 and Dr>=0 and r>=0 and e>=0 and rad>=0
            assert Dr==cd(D*r,S) and rad==e+cd((M+Dr)*S,lb)
            assert need[1]-need[0]==2*rad and need[3]-need[2]==2*rad
            valid_q.append(cd(Dr*S,M))
            if Dr>M:dr_gt+=1
            hit=meet(b,need)
            if hit is None:
                assert action=='EXCLUDED' and fin==(0,0,0,0)
                excluded+=1;continue
            assert hit==fin
            high=(2*Dr>M)
            can=(d<max_depth and len(queue)+len(kept)+4<=max_frontier and total+len(queue)+4<=budget)
            if high and can:
                assert action=='SPLIT'
                split+=1
                for j in range(4):queue.append((id+'/'+str(j),d+1,cut(hit,j)))
            else:
                assert action=='RETAINED'
                retained+=1
                if high:
                    if d>=max_depth:depth_keep+=1
                    elif len(queue)+len(kept)+4>max_frontier:frontier_keep+=1
                    else:budget_keep+=1
                kept.append((id,d,hit))
        newrad=radius(hull([x[2] for x in kept]));assert newrad<=old
        valid_q.sort()
        median=valid_q[len(valid_q)//2] if valid_q else 0
        stop='BUDGET' if budget_keep else ('REFINEMENT_CAP' if (depth_keep or frontier_keep) else ('DOMAIN' if unresolved else 'READY'))
        expected=(k,source_len,evals,excluded,split,retained,unresolved,budget_keep,depth_keep,frontier_keep,old,newrad,median,dr_gt,stop)
        assert sc==expected,('stage summary mismatch',sc,expected)
        frontier=kept
        lastk=k
        if stop!='READY':assert sn==len(sr)-1
    assert idx==len(et) and total<=budget
    actual=load_front(finalfile)
    assert actual==frontier,('final frontier mismatch',len(actual),len(frontier))
    finalrad=radius(hull([x[2] for x in frontier]))
    print('ADAPTIVE_INDEPENDENT_INTEGER_PASS initial=324 events=%d stages=%d evaluated=%d retained_final=%d L1_256=%d stop=%s'%(len(et),len(sr),total,len(frontier),finalrad,sr[-1][-1]))
    print('SESSION_ONLY; excludes rely on frozen source logs and unproved graph/tube hypotheses')
    return True

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('h3_source','initial','events','stages','final'):
        p.add_argument(name)
    p.add_argument('--budget',type=int,required=True)
    p.add_argument('--depth',type=int,required=True)
    p.add_argument('--frontier',type=int,required=True)
    p.add_argument('--start',type=int,default=4)
    p.add_argument('--max-k',type=int,required=True)
    a=p.parse_args()
    audit(a.h3_source,a.initial,a.events,a.stages,a.final,a.budget,a.depth,a.frontier,a.start,a.max_k)
