# DYAD OPEN 20 — bounded adaptive horizon, k=4..K (SESSION)

## Decision

An adaptive **development diagnostic**, not a certification or 3c-b run. The code starts from exactly 324 frozen `RETAINED` rectangles of the PI/owner-reviewed `h3_split2` two-way third-block campaign. It attempts horizons k=4,5,... up to an explicit `MAX_K`, under a **total successful/attempted evaluation budget**, a within-horizon 2×2 subdivision depth cap, a frontier cap and a wall-clock timeout.

The *mathematical* discard criterion is unchanged from the reviewed F1/F2/F3 code: necessary-disc box disjoint from the candidate rectangle. At each horizon k, compute `F^k` from the original lift, with derivative propagated without resetting and without using point samples; obtain a **fresh** `M_k` on that probe's `X_k ∩ D0`; intersect the C1–C2 necessary-disc box with the probe rectangle.

**Selection heuristic (not a theorem):** for a valid *retained* probe, if `2*Dr > M_k`, split its *post-contractor intersection* by exact `split_box(·, 2)` and reevaluate children **at the same k**; stop splitting if `2*Dr ≤ M_k`, a depth/frontier limit is reached, or budget cannot cover at least four new tasks. Unlike a global median threshold, this does not leave an unreported large-ratio tail. The per-stage median of all valid evaluated `Dr/M_k` remains available for reporting. `Dr/M_k` never determines whether to exclude a box.

**Never lose a candidate.** A domain error retains the current probe unchanged (`UNRESOLVED`). A budget-exhausted task is `NOT_EVALUATED/BUDGET_KEEP`; a valid high-Dr task kept by cap is recorded as retained, not discarded. After any `BUDGET`, `DOMAIN` or `REFINEMENT_CAP` stage, the driver stops instead of automatically progressing to higher k. All surviving exact rectangles remain in `final_frontier.tsv`. With full coverage and no stops, `STATUS=MAX_K` and exit 0 means only that the **bounded SESSION programme** reached its requested horizon; no jump proof or graph/tube certificate.

## Frozen source chain

1. Stage2 JSON `scout_N216_dps840.json`: `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.
2. Original 8×8 term run (1024 rows, 924 excluded): `terms.tsv` `1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72`.
3. Selective F2 (400 rows, 256 excluded): `selective_children.tsv` `3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579`.
4. F2 `refine2` successor (576 rows, 252 excluded): `details.tsv` `bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a`.
5. F3 `h3_split2` (1296 rows, 972 excluded, 324 retained): `details.tsv` `3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325`.

All five SHA gates are mandatory. The entire source chain's structural checks and nested run/package manifests are mandatory. The 144 retained F2 selective rows, 324 F2 `refine2` rows and 324 F3 `h3_split2` rows are recomputed with unchanged previous C++ code, and their seven integer fields plus necessary-box and intersection must agree bit-for-bit. Earlier eliminated rectangles are inherited, **not silently re-proved**; no source exclusions are counted again.

## Files produced

- `driver/initial_frontier.tsv`: 324 frozen rectangles, full 256-bit endpoints and stable source IDs.
- `driver/events.tsv`: every k-stage event with source, necessary disc, final boxes, M, Dr, D, r, |slope| lower, recenter error and radius (256-bit integer fields), evaluation and action. Internal nodes are explicitly `SPLIT`; excluded nodes are `EXCLUDED`; retained/error/budget nodes remain represented.
- `driver/stages.tsv`: one line per stage, complete accounting, exact old/new L1 outer radius and median Dr/M, counts, stop condition.
- `driver/final_frontier.tsv`: all remaining rectangles, regardless of stop reason.
- `driver/structure_check.txt`: **separate Python big-integer auditor** replays the event queue, exact split partitions, necessary-disc intersections, C1–C2 identities, hull and budget/frontier/depth decisions. No numerical dynamics reproduced here.
- `driver/summary.txt` and `driver/stderr.txt`; complete manifest and environment/provenance checks.

This package is a **same-engine, conditional numerical diagnostic**: no independent coefficient generation in C++, no proof of a sectorial graph, no certified point jump, and no authorization of stage 3c-b. Even an empty/failed numerical cover is not promoted to a non-existence theorem. The k>3 graph/tube premises require additional owner review; this code does not extend an adopted theorem.

## Ubuntu command

Place this ZIP in `/root`, verify SHA-256 printed with the archive link, and run `unzip -n`. The following directories must already exist, with their original checksummed package files:

```bash
bash /root/DYAD_CPP_ADAPTIVE_HORIZON/run_ubuntu_adaptive.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TERM_AUDIT_SUB8 \
  /root/DYAD_CPP_F2_SELECTIVE_REFINE \
  /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC \
  /root/DYAD_CPP_F3_ON_REFINED_324 \
  /root/dyad-f2-term8-full \
  /root/dyad-f2-selective-run \
  /root/dyad-horizon-compare \
  /root/dyad-f3-refined-compare \
  /root/dyad-adaptive-k4-k6 \
  6 1600 2 4096

echo "exit=$?"
cat /root/dyad-adaptive-k4-k6/driver/summary.txt
cat /root/dyad-adaptive-k4-k6/driver/structure_check.txt
```

Arguments at end: **MAX_K**, **TOTAL_EVAL_BUDGET**, **MAX_SPLIT_DEPTH_PER_K**, **MAX_FRONTIER**. Default recommended bounded pilot is `6 1600 2 4096`, NOT a guarantee that k=5 or k=6 will be reached. If k=4 consumes the budget, the driver returns exit 2 and preserves the full candidate cover. The runner has a 3600-second timeout; timeout is **incomplete**, never PASS. Budget may be increased in a **new output folder**, with separate provenance.

`exit=0`: all requested k stages and all independent checks complete, SESSION only. `exit=2`: meaningful **INCONCLUSIVE** state with retained cover (budget/domain/refinement cap); `exit=3`: input/computation/structure failure (do not use results); `exit=64`: CLI error. Hard timeout returns wrapper exit 2; partial logs never pass the exact-integer checker.

## Unchanged GitHub intake

`upload_adaptive_evidence.sh` accepts `package REPO EXACT_ZIP EXPECTED_SHA256 --push` or `results REPO RESULT_DIRECTORY - --push`. The first places ZIP bytes unchanged in `upload/dyad-cpp-adaptive-20261119/received/`, the second copies the run directory byte-exactly into `upload/dyad-cpp-adaptive-results-20261119/pi-run/`. Both use separate new branches and refuse existing branch names. These helpers are not automatically invoked by the runner; **nothing is merged, tagged or adopted**. The PI must authorize any future merge/release. The owner should independently review the C++ and repeat the source-backed pilot before accepting the session claim.
