#!/usr/bin/env python3
"""[SESSION] Exact-integer synthetic coverage, budget and corruption gates; no RTG numerics."""
import sys,tempfile,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'source'))
sys.path.insert(0,str(root.parent/'DYAD_CPP_F3_ON_REFINED_324/tests'))
import test_h3_structure as T
import check_adaptive as A


def prep(p):
    sv=T.manufacture(p)
    T.result(p,sv,'h3_split2')
    h3=p/'new.tsv'
    # Rewrite the synthetic H3 source to the *actual source shape*: 972 exclusions,
    # 324 retained (the older fixture intentionally chose 200 exclusions).
    lines=h3.read_text().splitlines()
    transformed=[lines[0]]
    for rowidx,row in enumerate(lines[1:]):
        w=row.split();probe=tuple(map(int,w[9:13]));yes=rowidx>=972
        need,fin=T.bounds(probe,yes,rad=2)
        w[13:17]=list(map(str,need));w[17:21]=list(map(str,fin))
        w[-1]='RETAINED' if yes else 'EXCLUDED'
        transformed.append(' '.join(w))
    h3.write_text('\n'.join(transformed)+'\n')
    s=A.load_seed(h3)
    assert len(s)==324
    initial=['id depth re_lo re_hi im_lo im_hi']
    for id,(d,b) in s.items():initial.append(id+' '+str(d)+' '+' '.join(map(str,b)))
    (p/'initial_frontier.tsv').write_text('\n'.join(initial)+'\n')
    return h3,s


def mk(p,seed,budget,high=False):
    target=p/'events.tsv';sumfile=p/'stages.tsv';last=p/'final_frontier.tsv'
    oldfront=list((id,0,b) for id,(d,b) in seed.items())
    events=[A.HEADER];stages=[A.STAGES];total=0
    for k in (4,5):
        init=len(oldfront);queue=list((id,0,b) for id,d,b in oldfront)
        current=[];i=0;evals=excluded=splits=retained=unres=budgetkeep=depthkeep=frontkeep=drgt=0;q=[]
        while i<len(queue):
            id,d,b=queue[i];i+=1
            if total>=budget:
                ev,action='NOT_EVALUATED','BUDGET_KEEP';M=Dr=D=r=lb=e=rad=0;need=fin=b;budgetkeep+=1;current.append((id,d,b))
            else:
                total+=1;evals+=1
                M=10**8;Dr=M if high else 0;D=Dr;r=A.S;lb=A.S;e=0;rad=M+Dr
                need=(-rad,rad,-rad,rad);fin=A.meet(b,need);assert fin
                ev,action='VALID','RETAINED';q.append(A.cd(Dr*A.S,M));
                if Dr>M:drgt+=1
                can=(d<1 and (len(queue)-i)+len(current)+4<=2000 and total+(len(queue)-i)+4<=budget)
                if high and can:
                    action='SPLIT';splits+=1
                    for z in range(4):queue.append((id+'/'+str(z),d+1,A.cut(fin,z)))
                else:
                    retained+=1;current.append((id,d,fin))
                    if high:
                        if d>=1:depthkeep+=1
                        else:budgetkeep+=1
            events.append(' '.join(map(str,(k,id,d,*b,*need,*fin,M,Dr,D,r,lb,e,rad,ev,action))))
        old=A.radius(A.hull([x[2] for x in oldfront]));new=A.radius(A.hull([x[2] for x in current]))
        assert new<=old
        stop='BUDGET' if budgetkeep else ('REFINEMENT_CAP' if (depthkeep or frontkeep) else ('DOMAIN' if unres else 'READY'))
        med=sorted(q)[len(q)//2] if q else 0
        stages.append(' '.join(map(str,(k,init,evals,excluded,splits,retained,unres,budgetkeep,depthkeep,frontkeep,old,new,med,drgt,stop))))
        oldfront=current
        if stop!='READY':break
    final=['id depth re_lo re_hi im_lo im_hi']
    for id,d,b in oldfront:final.append(' '.join(map(str,(id,d,*b))))
    target.write_text('\n'.join(events)+'\n');sumfile.write_text('\n'.join(stages)+'\n');last.write_text('\n'.join(final)+'\n')
    A.audit(p/'new.tsv',p/'initial_frontier.tsv',target,sumfile,last,budget,1,2000,4,5)
    return target


def main(exe=None):
    with tempfile.TemporaryDirectory() as t:
        p=Path(t);h3,s=prep(p)
        if exe:
            a=subprocess.run([str(exe),str(p/'selective.tsv'),str(p/'refine2.tsv'),str(h3)],capture_output=True,text=True)
            assert a.returncode==0,(a.returncode,a.stdout,a.stderr)
            print(a.stdout.strip())
        for high,budget in ((False,648),(False,400),(True,600)):
            f=mk(p,s,budget,high)
            src=f.read_text().splitlines()
            for n in range(6):
                lines=list(src)
                if n==0:lines.pop()
                else:
                    row=lines[1].split()
                    if n==1:row[3]=str(int(row[3])+1)  # source box coordinate
                    if n==2:row[16]=str(int(row[16])+1) # Dr identity
                    if n==3:row[21]=str(int(row[21])+1) # radius identity
                    if n==4:row[-1]='EXCLUDED' # false exclusion
                    if n==5:row[1]='not-source' # wrong ID
                    lines[1]=' '.join(row)
                bad=p/'bad.tsv';bad.write_text('\n'.join(lines)+'\n')
                try:A.audit(h3,p/'initial_frontier.tsv',bad,p/'stages.tsv',p/'final_frontier.tsv',budget,1,2000,4,5)
                except (AssertionError,ValueError,KeyError,IndexError):pass
                else:raise AssertionError('accepted corrupted adaptive record',n)
            print('ADAPTIVE_NEGATIVE_MUTATIONS_PASS=6 high=%s budget=%d'%(high,budget))
        print('ADAPTIVE_STRUCTURE_SYNTHETIC_PASS')

if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else None)
