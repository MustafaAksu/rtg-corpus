#!/usr/bin/env bash
# [SESSION] Bounded conditional adaptive k=4..K campaign, DEVELOPMENT ONLY.
# Original reviewed F1/F2/k3 sources are included unchanged at C++ compile time.
set -euo pipefail
if [[ $# -ne 18 ]];then
 echo 'Usage: run_ubuntu_adaptive.sh REPO V2 BENCH F1 F2 SUB8_PKG SELECTIVE_PKG HORIZON_PKG H3_PKG SUB8_RUN SELECTIVE_RUN HORIZON_RUN H3_RUN OUTPUT MAX_K EVAL_BUDGET MAX_SPLIT_DEPTH MAX_FRONTIER' >&2
 exit 64
fi
repo=$(cd -- "$1" && pwd);v2=$(cd -- "$2" && pwd);bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd);f2=$(cd -- "$5" && pwd);sub8=$(cd -- "$6" && pwd)
selpkg=$(cd -- "$7" && pwd);horpkg=$(cd -- "$8" && pwd);h3pkg=$(cd -- "$9" && pwd)
sub8run=$(cd -- "${10}" && pwd);selrun=$(cd -- "${11}" && pwd)
horrun=$(cd -- "${12}" && pwd);h3run=$(cd -- "${13}" && pwd)
out=${14};maxk=${15};budget=${16};depth=${17};maxfront=${18}
pkg=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
for v in "$maxk" "$budget" "$depth" "$maxfront"; do
 if [[ ! "$v" =~ ^[0-9]+$ ]];then echo "STOP: noninteger bounded parameter: $v" >&2;exit 64;fi
done
if ((maxk<4||maxk>20||budget<1||budget>100000||depth>8||maxfront<324||maxfront>20000));then
 echo 'STOP: out-of-range bounds' >&2;exit 64
fi
if [[ -e "$out" ]];then
 if [[ ! -d "$out" || -n $(ls -A -- "$out") ]];then echo 'STOP: output must be a new/empty directory' >&2;exit 64;fi
else mkdir -p -- "$out";fi
out=$(cd -- "$out" && pwd)
(cd "$pkg" && sha256sum -c SHA256SUMS.txt) > "$out/new_package_checks.txt"
for pair in "v2:$v2" "bench:$bench" "f1:$f1" "f2:$f2" "sub8:$sub8" "selective:$selpkg" "horizon:$horpkg" "h3:$h3pkg";do
 n=${pair%%:*};v=${pair#*:};(cd "$v" && sha256sum -c SHA256SUMS.txt) > "$out/${n}_package_checks.txt"
done
(cd "$sub8run" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/previous_sub8_run_checks.txt"
(cd "$selrun" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/previous_selective_run_checks.txt"
(cd "$horrun" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/previous_horizon_run_checks.txt"
(cd "$horrun/refine2" && sha256sum -c SHA256SUMS.txt) > "$out/previous_refine2_checks.txt"
(cd "$h3run" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/previous_h3_run_checks.txt"
(cd "$h3run/h3_split2" && sha256sum -c SHA256SUMS.txt) > "$out/previous_h3_split2_checks.txt"
S2="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
SUB8="$sub8run/terms.tsv";SELECT="$selrun/selective_children.tsv";REFINE="$horrun/refine2/details.tsv";H3="$h3run/h3_split2/details.tsv"
{
 printf '%s  %s\n' '6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e' "$S2"
 printf '%s  %s\n' '1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72' "$SUB8"
 printf '%s  %s\n' '3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579' "$SELECT"
 printf '%s  %s\n' 'bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a' "$REFINE"
 printf '%s  %s\n' '3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325' "$H3"
} | sha256sum -c - > "$out/FIVE_FROZEN_SHA256_PINS.txt"
python3 "$sub8/source/check_terms.py" "$SUB8" > "$out/source_sub8_terms_check.txt"
python3 "$sub8/source/check_completion.py" "$sub8run/summary.txt" "$SUB8" 8 8 0 > "$out/source_sub8_completion_check.txt"
python3 "$selpkg/source/check_selective.py" "$SUB8" "$SELECT" "$selrun/summary.txt" > "$out/source_selective_check.txt"
python3 "$horpkg/source/check_horizon.py" "$SELECT" "$REFINE" "$horrun/refine2/summary.txt" refine2 > "$out/source_refine2_check.txt"
python3 "$h3pkg/source/check_h3_refined.py" "$SELECT" "$REFINE" "$H3" "$h3run/h3_split2/summary.txt" h3_split2 > "$out/source_h3_check.txt"
python3 "$v2/source/import_phi40.py" --source "$S2" --out "$out/phi40_outer_256.txt" > "$out/import.log"
cmp "$out/phi40_outer_256.txt" "$selrun/phi40_outer_256.txt"
cmp "$out/phi40_outer_256.txt" "$horrun/phi40_outer_256.txt"
cmp "$out/phi40_outer_256.txt" "$h3run/phi40_outer_256.txt"
{
 printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
 printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
 printf 'GCC=';g++ --version|head -1
 printf 'PYTHON=';python3 --version
 printf 'SOURCE_SHA256=%s\n' '6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e'
 printf 'SUB8_TERMS_SHA256=%s\n' '1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72'
 printf 'SELECTIVE_CHILDREN_SHA256=%s\n' '3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579'
 printf 'REFINE2_576_SHA256=%s\n' 'bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a'
 printf 'H3_SPLIT2_1296_SHA256=%s\n' '3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325'
 printf 'K_START=4; MAX_K=%s; EVAL_BUDGET=%s; MAX_DEPTH=%s; MAX_FRONTIER=%s; Q_THRESHOLD=1/2\n' "$maxk" "$budget" "$depth" "$maxfront"
 printf 'SESSION_ONLY; NO 3c-b production/replay, certificate or point jump\n'
} > "$out/environment.txt"
includes=(-I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" -I "$selpkg/source" -I "$horpkg/source" -I "$h3pkg/source" -I "$pkg/source")
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pedantic "${includes[@]}" "$pkg/source/adaptive.cpp" -o "$out/adaptive"
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pedantic "${includes[@]}" "$pkg/source/test_source_parser.cpp" -o "$out/test_source_parser"
python3 "$pkg/tests/test_adaptive_structure.py" "$out/test_source_parser" > "$out/structure_units.txt"
"$out/test_source_parser" "$SELECT" "$REFINE" "$H3" > "$out/source_cpp_parser.txt"
g++ -std=c++17 -O0 -g0 -fno-omit-frame-pointer -fsanitize=address,undefined \
 "${includes[@]}" "$pkg/source/test_source_parser.cpp" -o "$out/test_source_parser_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 120s \
 "$out/test_source_parser_sanitized" "$SELECT" "$REFINE" "$H3" \
 > "$out/source_parser_sanitized.txt" 2> "$out/sanitizer_stderr.txt"
set +e
"$out/adaptive" >/dev/null 2>&1;rc0=$?
"$out/adaptive" "$S2" "$SELECT" "$REFINE" "$H3" "$out" 4 4 10 0 1000 >/dev/null 2>&1;rc1=$?
"$out/adaptive" "$out/phi40_outer_256.txt" "$S2" "$REFINE" "$H3" "$out" 4 4 10 0 1000 >/dev/null 2>&1;rc2=$?
"$out/adaptive" "$out/phi40_outer_256.txt" "$SELECT" "$S2" "$H3" "$out" 4 4 10 0 1000 >/dev/null 2>&1;rc3=$?
"$out/adaptive" "$out/phi40_outer_256.txt" "$SELECT" "$REFINE" "$S2" "$out" 4 4 10 0 1000 >/dev/null 2>&1;rc4=$?
"$out/adaptive" "$out/phi40_outer_256.txt" "$SELECT" "$REFINE" "$H3" "$out" 3 4 10 0 1000 >/dev/null 2>&1;rc5=$?
set -e
if [[ "$rc0,$rc1,$rc2,$rc3,$rc4,$rc5" != '64,3,3,3,3,3' ]];then
 echo "STOP: negative CLI codes $rc0,$rc1,$rc2,$rc3,$rc4,$rc5" >&2;exit 3
fi
printf 'NEGATIVE_CLI_PASS 64,3,3,3,3,3\n' > "$out/negative_controls.txt"
mkdir -- "$out/driver"
set +e
timeout -k 30s 3600s "$out/adaptive" "$out/phi40_outer_256.txt" \
 "$SELECT" "$REFINE" "$H3" "$out/driver" 4 "$maxk" "$budget" "$depth" "$maxfront" \
 > "$out/driver/summary.txt" 2> "$out/driver/stderr.txt"
rc=$?
set -e
if [[ "$rc" == 0 || "$rc" == 2 ]];then
 if [[ -s "$out/driver/events.tsv" && -s "$out/driver/stages.tsv" && -s "$out/driver/final_frontier.tsv" ]];then
  python3 "$pkg/source/check_adaptive.py" "$H3" \
   "$out/driver/initial_frontier.tsv" "$out/driver/events.tsv" \
   "$out/driver/stages.tsv" "$out/driver/final_frontier.tsv" \
   --budget "$budget" --depth "$depth" --frontier "$maxfront" --start 4 --max-k "$maxk" \
   > "$out/driver/structure_check.txt" || { echo 'STOP: adaptive structural check failed' >&2;exit 3; }
 fi
fi
(cd "$out/driver" && find . -maxdepth 1 -type f ! -name SHA256SUMS.txt -printf '%f\0'|sort -z|xargs -0 -r sha256sum > SHA256SUMS.txt)
(cd "$out" && find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name adaptive ! -name test_source_parser ! -name test_source_parser_sanitized -printf '%f\0'|sort -z|xargs -0 -r sha256sum > RUN_SHA256SUMS.txt)
cat "$out/driver/summary.txt"
[[ -f "$out/driver/structure_check.txt" ]] && cat "$out/driver/structure_check.txt"
if [[ $rc -ne 0 ]];then
 if [[ $rc == 2 || $rc == 124 || $rc == 137 ]];then
  echo "INCONCLUSIVE: rc=$rc; bounded development data only; retained candidates are never silently discarded";exit 2
 fi
 echo "INPUT_FAIL: rc=$rc; incomplete output is NOT PASS";exit 3
fi
if [[ ! -s "$out/driver/structure_check.txt" ]];then echo 'STOP: missing complete integer structure check' >&2;exit 3;fi
echo 'PASS: BOUNDED SESSION ADAPTIVE RUN (not a certificate or point jump).'
