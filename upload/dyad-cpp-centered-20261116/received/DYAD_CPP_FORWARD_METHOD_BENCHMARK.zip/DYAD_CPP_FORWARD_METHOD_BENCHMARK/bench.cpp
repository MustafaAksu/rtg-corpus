// SESSION feasibility comparison; no tube, sector, inverse or certification.
// APPROX_TRANSFER is not a verified source. Use only for cost comparisons.
#include "centered_evaluator.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <sstream>
#include <string>
#include <cmath>
using namespace dyad;
namespace ce=dyad::centered;
static const std::string expectedSha="6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e";

struct Data{ std::vector<C> phi; C c;};
Data read_data(const std::string& path){
 std::ifstream f(path);if(!f)throw std::runtime_error("missing file");
 std::string header,sha; if(!(f>>header>>sha)||header!="DYAD_PHI40_OUTER_V1"||sha!=expectedSha)throw std::runtime_error("wrong transfer header");
 Data a; a.phi.assign(41,C(0));
 for(int k=2;k<=40;++k){int idx;Z r0,r1,i0,i1;if(!(f>>idx>>r0>>r1>>i0>>i1)||idx!=k)throw std::runtime_error("bad coefficient");a.phi[k]=C(I(r0,r1),I(i0,i1));}
 std::string tag,fin;Z r0,r1,i0,i1;if(!(f>>tag>>r0>>r1>>i0>>i1>>fin)||tag!="C"||fin!="END")throw std::runtime_error("bad c");
 a.c=C(I(r0,r1),I(i0,i1));std::string trailing;if(f>>trailing)throw std::runtime_error("trailing input");return a;
}
C xstar(const C& c){return C(sqrt_i(I(3))/I(5),I::rat(1,5))/c;}

// Independent implementation of one-primitive centered MV1, using the same
// verified interval primitives, but a different enclosure schedule.
ce::Flow Tcentered(const ce::Flow& inp){
 ce::Vec boxes{inp.state[0].box(),inp.state[1].box()};
 ce::Vec centers{inp.state[0].c,inp.state[1].c};
 ce::Evaluation J=ce::primitive(boxes);
 ce::Evaluation ctr=ce::primitive(centers);
 ce::Disks state{ce::ball(ctr.value[0]),ce::ball(ctr.value[1])};
 ce::Disks tan{Disk(C(0),0),Disk(C(0),0)};
 for(size_t i=0;i<2;++i)for(size_t j=0;j<2;++j){
   state[i].r+=ce::product_upper(ce::abs_upper(J.jacobian[i][j]),inp.state[j].r);
   tan[i]=ce::add(tan[i],ce::multiply(ce::ball(J.jacobian[i][j]),inp.tangent[j]));
 }
 return {state,tan};
}
ce::Flow direct6(ce::Flow a){for(int i=0;i<6;++i) a=Tcentered(a);return a;}
Z fullwidth(const C& c){return std::max(Z(c.re.h-c.re.l),Z(c.im.h-c.im.l));}
std::string dec(const Z& x){std::ostringstream s;s<<std::scientific<<std::setprecision(6)<<(x.convert_to<long double>()/SCALE.convert_to<long double>());return s.str();}
C boxcenter(const C& c){return mid(c);}

// tiles of enclosing square [-r,r]^2; skip boxes provably outside disk.
std::vector<Disk> tiles(size_t N){
 Z r=cd(SCALE,Z(500)); Disk whole(C(0),r);std::vector<Disk> out;
 if(N==0) return {whole};
 for(size_t i=0;i<N;++i)for(size_t j=0;j<N;++j){
  Z rlo=fd((Z(2*i)-Z(N))*r,Z(N));Z rhi=cd((Z(2*(i+1))-Z(N))*r,Z(N));
  Z ilo=fd((Z(2*j)-Z(N))*r,Z(N));Z ihi=cd((Z(2*(j+1))-Z(N))*r,Z(N));
  C b(I(rlo,rhi),I(ilo,ihi));
  if(outside_disk(b,whole))continue;
  out.push_back(ce::ball(b));
 }
 return out;
}
#ifndef DYAD_BENCH_NO_MAIN
int main(int argc,char**argv){
 if(argc!=4 || (std::string(argv[2])!="adaptive" && std::string(argv[2])!="primitive" && std::string(argv[2])!="both")){std::cerr<<"Usage: bench IMPORTED_COEFS [adaptive|primitive|both] N_TILES_PER_SIDE\n";return 64;}
 try{
   Data dat=read_data(argv[1]);C x=xstar(dat.c);size_t N=std::stoul(argv[3]);
   if(N>20)throw std::runtime_error("N outside [0,20]");
   std::vector<Disk> t=tiles(N);
   std::cout<<"MODEL="<<argv[1]<<"\nTILES_GRID="<<N<<" ACTIVE="<<t.size()<<"\n";
   std::cout<<"strategy  grid tile_count done fail elapsed_s max_tangent_width max_deviation_width max_base_width max_state_radius max_deviation_abs proxyM03_keep proxyM03_hull proxyM05_keep proxyM05_hull\n";
   for(std::string strategy:{"adaptive","primitive"}){
    if(std::string(argv[2])!="both"&&std::string(argv[2])!=strategy)continue;
    auto start=std::chrono::steady_clock::now();
    size_t ok=0,failed=0, keep03=0,keep05=0; Z tw=0,dw=0,bw=0,mr=0,da=0;
    std::optional<C> hull03,hull05;
    Z ms03=cd(SCALE*Z(3),Z(10000)); // M=0.0003, exploratory ONLY
    Z ms05=cd(SCALE*Z(5),Z(10000)); // M=0.0005, exploratory ONLY
    auto update_hull=[](std::optional<C>& h,const C& b){
        if(!h){h=b;return;}h->re.l=std::min(h->re.l,b.re.l);h->re.h=std::max(h->re.h,b.re.h);
        h->im.l=std::min(h->im.l,b.im.l);h->im.h=std::max(h->im.h,b.im.h);
    };
    for(const Disk& di:t){
     try{
      ce::Flow f=ce::from_lift(x,di,dat.phi);
      f=(strategy=="adaptive"?ce::advance(std::move(f)):direct6(std::move(f)));
      State lifted=ce::lifted_readout(f,dat.phi);
      tw=std::max(tw,fullwidth(lifted.b.d));dw=std::max(dw,fullwidth(lifted.b.v));
      bw=std::max(bw,fullwidth(lifted.a.v));
      mr=std::max(mr,std::max(f.state[0].r,f.state[1].r));
      da=std::max(da,ce::abs_upper(lifted.b.v));
      ce::Flow p0=ce::from_lift(x,Disk(di.c,0),dat.phi);
      p0=(strategy=="adaptive"?ce::advance(std::move(p0)):direct6(std::move(p0)));
      State v0=ce::lifted_readout(p0,dat.phi);
      C slope=mid(v0.b.d);
      if(ce::abs_lower(slope)>0) {
        for(int h=0;h<2;++h){
          Disk contracted=necessary_disk(di,v0.b.v,lifted.b.d,slope,h==0?ms03:ms05);
          if(!outside_disk(di.box(),contracted)) {
             auto both=intersection(di.box(),contracted.box());
             if(both){if(h==0){++keep03;update_hull(hull03,*both);} else {++keep05;update_hull(hull05,*both);}}
          }
        }
      }
      if(ce::abs_lower(slope)<=0){++keep03;++keep05;update_hull(hull03,di.box());update_hull(hull05,di.box());}
      ++ok;
     }catch(const std::domain_error&e){++failed;
        if(failed<=3)std::cerr<<strategy<<" INCONCLUSIVE tile retained: "<<e.what()<<"\n";
        ++keep03;++keep05;update_hull(hull03,di.box());update_hull(hull05,di.box());
      }
    }
    auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::cout<<strategy<<" "<<N<<" "<<t.size()<<" "<<ok<<" "<<failed<<" "<<elapsed<<" "<<dec(tw)<<" "<<dec(dw)<<" "<<dec(bw)<<" "<<dec(mr)<<" "<<dec(da)<<" "<<keep03<<" "<<(hull03?dec(enclosing_disk(*hull03).r):"EMPTY")<<" "<<keep05<<" "<<(hull05?dec(enclosing_disk(*hull05).r):"EMPTY")<<"\n";
   }
 } catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 3;}
}

#endif // DYAD_BENCH_NO_MAIN
