# DYAD OPEN 20: first-forward-block C++ method benchmark

**Status:** SESSION, development benchmark. This package does not implement a tube bound, sector membership, the inverse branch, two-disc separation, or production/replay. It neither certifies a point jump nor changes B-an/B-6 status.

## Input provenance

The executable is compiled against the **unchanged** original `DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2` source package and imports the first 39 nonzero pilot-branch coefficients from the source `evidence/dyad/open20-an/stage2/scout_N216_dps840.json` **only after checking the exact source SHA-256** `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.

The existing `import_phi40.py` is reused unchanged; its *source-reported* coefficient midpoint padding `1e-65` and scaling-constant padding `1e-32` must still be accepted as adequate by the scientific owner. These are not newly derived exact Arb balls. The script rechecks the V2 package's own SHA256SUMS. Input provenance and computational certificate remain distinct.

## Methods

- `adaptive`: the existing V2 `centered::advance` logic (whole `F=T^6` Jacobian or its prescribed fallback on an intermediate budget error).
- `primitive`: a new centered mean-value propagation after **each** of the six primitive `T` maps, with rigorous ball arithmetic and full-polydisk Jacobians, using the SAME underlying exact-dyadic interval arithmetic.
- Both methods read out the lifted deviation and its tangent once at the end. Both keep the full initial base uncertainty and the coefficient boxes.

The initial fiber is the closed disk `|d| <= 0.002`. `grid=0` evaluates it as one disk. `grid=N>=1` covers the enclosing square by an `N x N` grid, omits only cells proved disjoint from the original disk, and replaces each retained square by an outer-enclosing disk. The covering can be redundant but cannot lose a candidate. The first-step image is evaluated once per retained tile.

`max_tangent_width` is the greatest **full rectangular component width** of the first lifted tangent enclosure across evaluated tiles; it is **not** the derivative variation `D` or a uniform lower/upper bound on the true derivative. `elapsed_s` includes the exploratory contractor and point-center evaluation on every tile; it is not only the evaluation cost. The output also reports base/deviation widths and retained/unresolved tiles.

## Exploratory necessary-condition proxy — not a tube result

The columns `proxyM03_*` and `proxyM05_*` *hypothetically* apply `|d_1| <= M` with M = 0.0003 and 0.0005. These values are **not** proved upper bounds for `sup_{X_1 intersect D_0} R_0`. They are sensitivity studies, not valid eliminations in the actual DYAD problem. For each tile, the same previously audited necessary-disk contractor is used with the derivative enclosed over that entire tile and a fresh center value. Any unresolved tile is retained in full. The `hull` radius comes from a simple rectangle-hull disk bound; because rectangle wrapping is allowed it can exceed `0.002` even with no candidates discarded.

For actual mathematical candidate elimination, first establish the sector, logarithm, pole, and wedge hypotheses needed to obtain an **independently validated** upper bound over the intersection `X_k intersect D_j`. Do not promote proxy reductions to certified results.

## Ubuntu CLI

```bash
unzip -q DYAD_CPP_FORWARD_METHOD_BENCHMARK.zip -d /root
bash /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK/run_ubuntu_benchmark.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/dyad-cpp-forward-benchmark
cat /root/dyad-cpp-forward-benchmark/benchmark_status.txt
cat /root/dyad-cpp-forward-benchmark/same_engine_cross_formula.txt
```

Dependencies: GCC C++17, Boost.Multiprecision headers, Python 3 standard library, coreutils `timeout` and `sha256sum`; no MPFR/Arb needed for this **C++** benchmark.

The output directory must be absent or empty. The runner performs no repository writes, merge, tag, branch, production or replay operation. The bounded experiments have a per-case process timeout. A nonzero status is `INCONCLUSIVE` or `INPUT_FAIL`, not evidence of nonexistence. All output hashes are stored in `RUN_SHA256SUMS.txt`.

## Local measurement, not source-verified

`SESSION_RESULTS_APPROX.txt` reports runs using the accompanying V2 **18-significant-digit approximate coefficients**, with a deliberately added `1e-15` component padding (instead of the exact source-imported 80-digit strings) and the original displayed scaling constant. This local proxy data is not included as a certified input. It is appropriate only for method selection and cost estimates, **not** for science decisions. `check_sample.cpp` independently compares the new primitive schedule with the original raw T^6 expression on 49 fixed dyadic fiber samples. This is **same-engine cross-formula checking**, not an external independent implementation or proof. Local sample result: 49/49 rectangular inclusions for base, deviation, and tangent on the one-step whole-fiber enclosure.

### Main qualitative observations from the local proxy

- One disk `r=0.002`: tangent widths 10.738 (V2 adaptive) and 7.455 (per-T).
- 60 outer tiles (8x8 square): 493.3 (adaptive) versus 0.7129 (per-T), nearly identical computation cost around four seconds.
- 96 outer tiles (10x10 square): 183.4 versus 0.5631, nearly identical cost around six seconds.
- 224 tiles (16x16): per-T width 0.3455; under the unproved M = 0.0003 proxy, rectangular-hull disk radius around 0.001013 (the initial *disk* radius was 0.002).
- The local note's 12-point derivative variation is not an enclosure. All comparative data should be rerun on the PI server with the pinned 80-digit coefficient transfer before owner acceptance.

**Suggested owner review:** all six primitive Jacobian applications, tile coverage, unresolved tile retention, true input import, and the difference between `proxyM` sensitivity and valid `R_0` evidence.
