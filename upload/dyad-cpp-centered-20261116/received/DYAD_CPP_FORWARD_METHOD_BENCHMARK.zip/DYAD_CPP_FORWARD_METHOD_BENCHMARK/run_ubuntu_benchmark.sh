#!/usr/bin/env bash
# SESSION developmental comparison only. Does not produce a certificate or jump.
set -euo pipefail
if [[ $# -ne 3 ]]; then
  echo 'Usage: bash run_ubuntu_benchmark.sh REPO_ROOT V2_EXTRACTED_DIR EMPTY_OUTPUT_DIR' >&2
  exit 64
fi
repo=$(cd -- "$1" && pwd)
v2=$(cd -- "$2" && pwd)
out=$3
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -e $out ]]; then
  if [[ ! -d $out || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output directory must not contain existing files' >&2
    exit 64
  fi
else
  mkdir -p -- "$out"
fi
out=$(cd -- "$out" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/benchmark_package_check.txt"
(cd "$v2" && sha256sum -c SHA256SUMS.txt) > "$out/v2_source_package_check.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
if ! printf '%s  %s\n' "$expected" "$source_json" | sha256sum -c -; then
  echo 'STOP: exact Stage-2 JSON source SHA-256 mismatch' >&2
  exit 4
fi
{
  date -u '+UTC=%Y-%m-%dT%H:%M:%SZ'
  git -C "$repo" rev-parse HEAD
  git -C "$repo" status --porcelain -- evidence/dyad/open20-an/stage2/scout_N216_dps840.json
  g++ --version | head -1
  python3 --version
  printf 'SOURCE_JSON_SHA256=%s\n' "$expected"
  printf 'SCOPE=SESSION comparative feasibility; no D_j/R_j/membership/certificate/jump\n'
} > "$out/environment.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" --out "$out/phi40_outer_256.txt" > "$out/import.log"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -I "$v2/source" \
  "$src/bench.cpp" -o "$out/bench"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -I "$v2/source" \
  "$src/check_sample.cpp" -o "$out/check_sample"
"$out/check_sample" "$out/phi40_outer_256.txt" > "$out/same_engine_cross_formula.txt"
failed=0
for spec in 'adaptive 0' 'primitive 0' 'adaptive 8' 'primitive 8' \
            'adaptive 10' 'primitive 10' 'primitive 16'; do
  read -r method grid <<< "$spec"
  logfile="$out/${method}_grid_${grid}.txt"
  set +e
  timeout -k 5s 75s "$out/bench" "$out/phi40_outer_256.txt" "$method" "$grid" \
    > "$logfile" 2> "$logfile.stderr"
  result=$?
  set -e
  if [[ $result -ne 0 ]]; then
    echo "INCONCLUSIVE method=$method grid=$grid exit=$result" | tee -a "$out/benchmark_status.txt"
    failed=1
  else
    grep -E "^(${method}) " "$logfile" | tee -a "$out/benchmark_status.txt"
  fi
done
(cd "$out" && sha256sum environment.txt import.log phi40_outer_256.txt \
  same_engine_cross_formula.txt benchmark_status.txt > RUN_SHA256SUMS.txt)
echo 'SESSION ONLY: proxy M=0.0003/0.0005 is NOT an established tube bound.'
echo 'No certification, no stage 3c-b execution, no B-an/B-6 conclusion.'
if [[ "$failed" -ne 0 ]]; then exit 2; fi
