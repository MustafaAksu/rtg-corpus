#define DYAD_BENCH_NO_MAIN
#include "bench.cpp"
int main(int argc,char**argv){
  try{
    if(argc!=2){std::cerr<<"usage: check_sample IMPORTED_COEFS\n";return 64;}
    auto data=read_data(argv[1]); C x=xstar(data.c);
    Z R=cd(SCALE,Z(500));
    ce::Flow all=direct6(ce::from_lift(x,Disk(C(0),R),data.phi));
    State big=ce::lifted_readout(all,data.phi);
    int total=0,covered=0,overlap=0;
    for(int i=-4;i<=4;++i) for(int j=-4;j<=4;++j){
      if(i*i+j*j>16) continue;
      C d(I::point(fd(Z(i)*R,Z(4))),I::point(fd(Z(j)*R,Z(4))));
      State raw=lifted_F({J(x),J(d,C(1))},data.phi);
      ++total;
      bool full=encloses(big.a.v,raw.a.v) && encloses(big.b.v,raw.b.v) && encloses(big.b.d,raw.b.d);
      bool ov=overlaps(big.a.v,raw.a.v)&&overlaps(big.b.v,raw.b.v)&&overlaps(big.b.d,raw.b.d);
      covered+=int(full);overlap+=int(ov);
    }
    std::cout<<"WHOLE_FIBRE_1STEP_SAME_ENGINE_RAW_EIGEN total="<<total<<" contained="<<covered<<" overlapped="<<overlap<<"\n";
    return total==covered?0:1;
  }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 3;}
}
