#!/usr/bin/env bash
# [SESSION] Bounded F2 term scaling diagnostic. NO stage3c-b, no certificate, no jump.
set -euo pipefail
if [[ $# -lt 8 || $# -gt 9 ]]; then
  echo 'Usage: run_ubuntu_sub8.sh REPO V2_DIR BENCH_DIR F1_DIR F2_DIR OUT GRID(8|10) SUBDIV(2|4|8) [MAX_SECOND(0=full)]' >&2
  exit 64
fi
repo=$(cd -- "$1" && pwd)
v2=$(cd -- "$2" && pwd)
bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd)
f2=$(cd -- "$5" && pwd)
out=$6
grid=$7
sub=$8
max_second=${9:-0}
if [[ "$grid" != 8 && "$grid" != 10 ]] || [[ "$sub" != 2 && "$sub" != 4 && "$sub" != 8 ]] || [[ ! "$max_second" =~ ^[0-9]+$ ]] || (( 10#$max_second > 1024 )); then
  echo 'STOP: unsupported bounded mode' >&2; exit 64
fi
if [[ -e "$out" ]]; then
  if [[ ! -d "$out" || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output must be a new or empty directory' >&2; exit 64
  fi
else
  mkdir -p -- "$out"
fi
out=$(cd -- "$out" && pwd)
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/sub8_package_checks.txt"
(cd "$f2" && sha256sum -c SHA256SUMS.txt) > "$out/f2_package_checks.txt"
(cd "$f1" && sha256sum -c SHA256SUMS.txt) > "$out/f1_package_checks.txt"
(cd "$bench" && sha256sum -c SHA256SUMS.txt) > "$out/benchmark_package_checks.txt"
(cd "$v2" && sha256sum -c SHA256SUMS.txt) > "$out/v2_package_checks.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
printf '%s  %s\n' "$expected" "$source_json" | sha256sum -c -
{
  printf 'UTC='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  printf 'REPO_HEAD='; git -C "$repo" rev-parse HEAD
  printf 'GCC='; g++ --version | head -1
  printf 'PYTHON='; python3 --version
  printf 'STAGE2_SHA256=%s\n' "$expected"
  printf 'GRID=%s SUBDIV=%s MAX_SECOND=%s\n' "$grid" "$sub" "$max_second"
  printf 'SESSION_ONLY=1; no stage 3c-b, point jump, or certificate\n'
} > "$out/environment.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" --out "$out/phi40_outer_256.txt" > "$out/import.log"
common=(-std=c++17 -O2 -Wall -Wextra -pedantic -I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source")
g++ "${common[@]}" "$src/source/f2_term_diagnostic_sub8.cpp" -o "$out/f2_term_diagnostic_sub8"
set +e
"$out/f2_term_diagnostic_sub8" >/dev/null 2>&1; rc_args=$?
"$out/f2_term_diagnostic_sub8" "$source_json" 8 2 0 "$out/negative_wrong.tsv" >/dev/null 2>&1; rc_source=$?
"$out/f2_term_diagnostic_sub8" "$out/phi40_outer_256.txt" 8 7 0 "$out/negative_subdiv.tsv" >/dev/null 2>&1; rc_subdiv=$?
set -e
if [[ "$rc_args" -ne 64 || "$rc_source" -ne 3 || "$rc_subdiv" -ne 3 ]]; then
  echo "STOP: negative CLI checks ($rc_args,$rc_source,$rc_subdiv) != (64,3,3)" >&2; exit 1
fi
# Bounded development only. Subdivision 8 has at most 1024 follow-up pieces with present tiles.
if (( max_second == 0 )); then timeout_seconds=1800; else timeout_seconds=300; fi
set +e
timeout -k 10s "${timeout_seconds}s" "$out/f2_term_diagnostic_sub8" "$out/phi40_outer_256.txt" "$grid" "$sub" "$max_second" "$out/terms.tsv" > "$out/summary.txt" 2> "$out/stderr.txt"
rc=$?
set -e
if [[ $rc -ne 0 ]]; then
  echo "INCONCLUSIVE: diagnostic exit=$rc; any partial terms.tsv is NOT a full run" >&2
  exit 2
fi
python3 "$src/source/check_terms.py" "$out/terms.tsv" > "$out/check_terms.txt"
python3 "$src/source/check_completion.py" "$out/summary.txt" "$out/terms.tsv" "$grid" "$sub" "$max_second" > "$out/completion_check.txt"
(
  cd "$out"
  find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name f2_term_diagnostic_sub8 -printf '%f\0' | sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt
)
cat "$out/summary.txt"
cat "$out/completion_check.txt"
if (( max_second == 0 )); then
  echo 'PASS: COMPLETE SESSION term diagnostic only; NO certification or jump'
else
  echo 'PARTIAL: bounded SESSION term sample, NOT a completed grid or hull'
fi
