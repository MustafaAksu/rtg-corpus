# DYAD — second-step term diagnostics, 8×8 subdivision (SESSION)

**Scope.** This package adds subdivision `8` (64 children per first-stage survivor) to the previously reviewed **diagnostic only**, keeping the F1/F2 solver files unchanged. It emits arithmetic diagnostics, *not a new exclusion algorithm*. Does not change the O-1 source-wall issue or authorize stage 3c-b.

## Provenance

Derived from `DYAD_CPP_F2_TERM_AUDIT.zip` (SHA256 `b2a0f428dbd46281ff889c7444851ac4221c9261e359651b02499b1c1ab1d6c0`). `source/check_terms.py` is byte-identical. `source/f2_term_diagnostic_sub8.cpp` changes **only** CLI usage (`SUBDIV(2|4|8)`), the sub=8 gate, and the maximum allowed second row count 256 → 1024. It includes the reviewed F2 source unchanged at compile time. The runner maintains all five source-manifest gates, pinned Stage2 JSON SHA256 and three negative CLI controls. Time budget is 1800 s for a full grid and 300 s for a bounded pilot. These are exit-status limits, not estimates of duration.

**Constraints:** `GRID` in {8,10}, `SUBDIV` in {2,4,8}; optional `MAX_SECOND` is 0 (full) or a positive count ≤1024. For a partial run, the output is flagged `PARTIAL` / `SAMPLED=YES`, full hull is intentionally omitted, and no whole-fibre conclusion may be drawn. The expected complete second-stage row count is `first_retained × subdiv²`, presently `16 × 8² = 1024`. Use a fresh output directory for every run.

## Ubuntu: 8×8 subdivision with pinned real source

Assumes the four already validated dependency packages are extracted under `/root` and `rtg-corpus` contains `evidence/dyad/open20-an/stage2/scout_N216_dps840.json` at SHA256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.

```bash
cd /root
unzip -n DYAD_CPP_F2_TERM_AUDIT_SUB8.zip

# Optional bounded pilot: only the first 64 second-stage rows; NOT a completed grid.
bash /root/DYAD_CPP_F2_TERM_AUDIT_SUB8/run_ubuntu_sub8.sh \
  /root/rtg-corpus /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR /root/dyad-f2-term8-pilot 8 8 64

# Full diagnostic, 1024 rows if 16 first-stage tiles survive.
bash /root/DYAD_CPP_F2_TERM_AUDIT_SUB8/run_ubuntu_sub8.sh \
  /root/rtg-corpus /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR /root/dyad-f2-term8-full 8 8
```

## Same-source matched comparison

Use the PI's completed 4×4 diagnostic `terms.tsv` from `/root/dyad-f2-terms-grid8/` and the completed 8×8 log. The checker groups each 8×8 subtile with its 4×4 parent and compares *separately* `r`, `D`, `Dr`, `M2` and `Dr/M2`. The 4×4 and 8×8 logs must have the same initial grid / F1 survivors, exact 256 and 1024 valid second-stage rows, respectively. It fails on unresolved or incomplete logs.

```bash
python3 /root/DYAD_CPP_F2_TERM_AUDIT_SUB8/source/matched_scaling.py \
  /root/dyad-f2-terms-grid8/terms.tsv \
  /root/dyad-f2-term8-full/terms.tsv
```

**Interpretation:** A ratio of medians of `Dr/M2` alone does not establish how `D` scales with radius, because `M2` and the population of tiles change. Use the matched `r`, `D`, `Dr`, `M2` ratios and runtime/cost before choosing subdivision vs a genuinely different jet/enclosure method. The existing evaluated implementation **already** centers every primitive `T` step.

## Reporting / safety

- `exit=0` with `FULL_DIAGNOSTIC_ROWS_PASS` = completed **SESSION-only** term measurement; not a certificate, theorem or jump.
- `exit=0` with `PARTIAL_DIAGNOSTIC_ROWS_PASS` = explicitly incomplete sample.
- `exit=2` = timeout, arithmetic unresolved, or incomplete; never interpret a partial TSV as a full run.
- `exit=3/64` = input or usage error.

Record source+package SHA256 and runtime; preserve source ZIPs, previous F1/F2 outputs and O-1 separate. Never merge/tag/adopt on diagnostic PASS.
