# DYAD F2 term diagnostic — review request (SESSION)

Review the bounded extension to subdivision 8, strictly distinct from the owner-reviewed F1/F2 mathematical contractor:

1. Verify the diff relative to `DYAD_CPP_F2_TERM_AUDIT`: only the diagnostic argument/row-limit checks changed. No change to F1/F2 source, candidate exclusion, tube formulas or derivative chain rule.
2. Verify full coverage accounting: source F1 yields `n` survivors, full F2 diagnostic has exactly `n × 8²` rows; partial pilot flagged; unresolved never silently discarded.
3. Verify matched 8-child→4-parent grouping, exact integer cross-check of `Dr=ceil(D*r)` and necessary radius; compare r, D, Dr, M2 and Dr/M2, not only medians.
4. Document running-time and limit status. Distinguish PI-run source-backed evidence from proxy, owner rerun, and same-engine checks.
5. No O-1 implementation, canonical DSN change, 3c-b authorization, or scientific point-jump inference.
