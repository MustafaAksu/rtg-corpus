#!/usr/bin/env python3
"""[SESSION] Matched-subtile scaling diagnostics, never infer full-orbit tube validity."""
import sys,collections,statistics
from decimal import Decimal,getcontext
from pathlib import Path
getcontext().prec=70
S=1<<256
if len(sys.argv)!=3:raise SystemExit('Usage: matched_scaling.py FULL_SUB4_TERMS_TSV FULL_SUB8_TERMS_TSV')
def load(p,sub):
 lines=Path(p).read_text().splitlines(); assert lines and lines[0].startswith('first_tile second_subtile')
 rows={}
 for line in lines[1:]:
  cols=line.split(); assert len(cols)==11
  i,j=map(int,cols[:2]);a=tuple(map(int,cols[2:9]));status,action=cols[9:]
  assert (i,j) not in rows and 0<=j<sub*sub
  assert status=='VALID' and action in ('RETAINED','EXCLUDED'), 'unresolved: no matching comparison'
  assert a[0]>0 and a[3]>0
  rows[i,j]=a
 return rows
p4=load(sys.argv[1],4);p8=load(sys.argv[2],8)
assert len(p4)==256 and len(p8)==1024,(len(p4),len(p8))
parents=set(i for i,j in p4)
assert len(parents)==16 and parents==set(i for i,j in p8)
ratios=collections.defaultdict(list)
for (i,j),v in p8.items():
 y,x=divmod(j,8);k=(y//2)*4+x//2
 if (i,k) not in p4:raise AssertionError('missing parent')
 vp=p4[i,k]
 for field,name in [(0,'M'),(1,'Dr'),(2,'D'),(3,'r')]:
  if vp[field]!=0:ratios[name].append(Decimal(v[field])/Decimal(vp[field]))
 q8=Decimal(v[1])/Decimal(v[0]);q4=Decimal(vp[1])/Decimal(vp[0]);ratios['q'].append(q8/q4)
assert all(len(v)==1024 for v in ratios.values())
print('MATCHED_SECOND_SUBTILE_GROUPING_OK 1024 children; 256 parents; 16 first-stage tiles')
for name in ('r','D','Dr','M','q'):
 vals=sorted(ratios[name]); n=len(vals)
 print(f'{name}_8_over_4 min={vals[0]:.8g} median={(vals[n//2-1]+vals[n//2])/2:.8g} max={vals[-1]:.8g}')
print('SESSION diagnostic only; sample distribution and M changes cannot establish a wrapping floor')
