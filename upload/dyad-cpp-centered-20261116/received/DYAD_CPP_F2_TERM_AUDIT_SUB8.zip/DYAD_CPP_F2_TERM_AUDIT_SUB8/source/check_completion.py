#!/usr/bin/env python3
"""[SESSION] Completeness gate for F2 term audit; does not establish tube theorems."""
from pathlib import Path
import re,sys
if len(sys.argv)!=6: raise SystemExit(64)
summary,details,grid,sub,max_second=sys.argv[1:]
grid=int(grid); sub=int(sub); max_second=int(max_second)
s=Path(summary).read_text()
lines=Path(details).read_text().splitlines()
assert lines and lines[0].startswith('first_tile second_subtile M2_256 Dr_256 ')
find=lambda name:int(re.search(r'\b'+re.escape(name)+r'=(\d+)\b',s).group(1))
assert find('grid')==grid and find('subdiv')==sub
first_retained=find('first_retained'); first_excluded=find('first_excluded'); first_unresolved=find('first_unresolved')
second_evaluated=find('second_evaluated'); second_unresolved=find('second_unresolved')
second_excluded=find('second_excluded'); second_retained=find('second_retained')
assert first_excluded+first_retained+first_unresolved==find('active')
assert second_evaluated+second_unresolved==len(lines)-1
assert second_excluded+second_retained==second_evaluated+second_unresolved
expected=first_retained*sub*sub
if max_second==0:
    assert 'SAMPLED=NO' in s
    assert first_unresolved==0 and second_unresolved==0
    assert second_evaluated==expected, (second_evaluated,expected)
    assert 'final_L1_hull=NOT_REPORTED_INCOMPLETE' not in s
    print(f'FULL_DIAGNOSTIC_ROWS_PASS first_retained={first_retained} second_evaluated={second_evaluated} expected={expected}')
else:
    if expected>max_second:
        assert 'SAMPLED=YES' in s
        assert second_evaluated+second_unresolved==max_second
        assert 'final_L1_hull=NOT_REPORTED_INCOMPLETE' in s
        print(f'PARTIAL_DIAGNOSTIC_ROWS_PASS rows={len(lines)-1} requested_max={max_second}; NOT a full-grid result')
    else:
        assert 'SAMPLED=NO' in s
        print(f'FULL_DIAGNOSTIC_ROWS_PASS under supplied limit expected={expected}')
