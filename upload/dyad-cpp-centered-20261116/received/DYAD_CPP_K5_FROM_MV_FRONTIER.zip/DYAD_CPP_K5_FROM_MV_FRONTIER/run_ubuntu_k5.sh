#!/usr/bin/env bash
# [SESSION] Recheck the frozen source chain and run k=5 only on 676 MV-k4 survivors.
set -euo pipefail
if [[ $# != 21 ]];then
 echo 'Usage: run_ubuntu_k5.sh REPO V2 BENCH F1 F2 SUB8_PKG SEL_PKG HORIZON_PKG H3_PKG ADAPT_PKG MV_PKG SUB8_RUN SEL_RUN HORIZON_RUN H3_RUN ADAPT_RUN MV_RESUME_RUN OUT BUDGET DEPTH FRONTIER' >&2; exit 64
fi
repo=$(cd -- "$1" && pwd);v2=$(cd -- "$2" && pwd);bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd);f2=$(cd -- "$5" && pwd);sub8=$(cd -- "$6" && pwd)
sel=$(cd -- "$7" && pwd);hor=$(cd -- "$8" && pwd);h3=$(cd -- "$9" && pwd)
adpkg=$(cd -- "${10}" && pwd);mvpkg=$(cd -- "${11}" && pwd)
s8run=$(cd -- "${12}" && pwd);selrun=$(cd -- "${13}" && pwd)
horrun=$(cd -- "${14}" && pwd);h3run=$(cd -- "${15}" && pwd)
adrun=$(cd -- "${16}" && pwd);mvrun=$(cd -- "${17}" && pwd)
out=${18};budget=${19};depth=${20};frontier=${21}
pkg=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
for n in "$budget" "$depth" "$frontier";do [[ "$n" =~ ^[0-9]+$ ]] || { echo 'STOP invalid integer CLI' >&2;exit 64;};done
if ((budget<676||budget>15000||depth>2||frontier<676||frontier>20000));then
 echo 'STOP out-of-range k5 parameters' >&2;exit 64
fi
if [[ -e "$out" ]];then
 [[ -d "$out" && -z $(ls -A -- "$out") ]] || { echo 'STOP output directory must be empty' >&2;exit 64;}
else mkdir -p -- "$out";fi
out=$(cd -- "$out" && pwd)
(cd "$pkg" && sha256sum -c SHA256SUMS.txt) > "$out/new_package_checks.txt"
for pair in "v2:$v2" "bench:$bench" "f1:$f1" "f2:$f2" "sub8:$sub8" "selective:$sel" "horizon:$hor" "h3:$h3" "adaptive:$adpkg" "mv:$mvpkg";do
 n=${pair%%:*};base=${pair#*:}; (cd "$base" && sha256sum -c SHA256SUMS.txt) > "$out/${n}_package_checks.txt"
done
for pair in "sub8:$s8run" "selective:$selrun" "horizon:$horrun" "h3:$h3run" "adaptive:$adrun" "mv:$mvrun";do
 n=${pair%%:*};base=${pair#*:}; (cd "$base" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/${n}_run_checks.txt"
done
(cd "$horrun/refine2" && sha256sum -c SHA256SUMS.txt) > "$out/refine2_checks.txt"
(cd "$h3run/h3_split2" && sha256sum -c SHA256SUMS.txt) > "$out/h3split_checks.txt"
(cd "$adrun/driver" && sha256sum -c SHA256SUMS.txt) > "$out/previous_adaptive_driver_checks.txt"
(cd "$mvrun/driver" && sha256sum -c SHA256SUMS.txt) > "$out/previous_mv_driver_checks.txt"
S2="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
SUB8="$s8run/terms.tsv";SELECT="$selrun/selective_children.tsv"
REFINE="$horrun/refine2/details.tsv";H3S="$h3run/h3_split2/details.tsv"
AD_EVENTS="$adrun/driver/events.tsv";AD_FRONT="$adrun/driver/final_frontier.tsv"
MV_EVENTS="$mvrun/driver/events.tsv";MV_INIT="$mvrun/driver/initial_frontier.tsv"
MV_FINAL="$mvrun/driver/final_frontier.tsv"
{
 printf '%s  %s\n' 6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e "$S2"
 printf '%s  %s\n' 1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72 "$SUB8"
 printf '%s  %s\n' 3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579 "$SELECT"
 printf '%s  %s\n' bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a "$REFINE"
 printf '%s  %s\n' 3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325 "$H3S"
 printf '%s  %s\n' 276701a085aefcc528290e496a721f83080780fabab5aafd78f3f7b3cc0a8a1f "$AD_EVENTS"
 printf '%s  %s\n' 4cb41a4f4fa860763f1f992acd7caeee53f48acf9e9e335d2263281e453d5c2f "$AD_FRONT"
 printf '%s  %s\n' 2646cf7c0f7509d266a35dcbc13571b4de1cffee5fd13b2b9fc0b9b1827501c0 "$MV_EVENTS"
 printf '%s  %s\n' 6eccf6268602bd79dea722298abbe83e498eaeec905a9327a68d9a86e50185e1 "$MV_FINAL"
 printf '%s  %s\n' fcca8378ec376c6d3b9278f40f5706d0d007035debaf1a97d07e38d557b14942 "$mvrun/driver/stages.tsv"
} | sha256sum -c - > "$out/TEN_FROZEN_SHA256_PINS.txt"
# Before k5 use the unchanged independent prior-stage checkers, not just hashes.
python3 "$adpkg/source/check_adaptive.py" "$H3S" "$adrun/driver/initial_frontier.tsv" "$AD_EVENTS" "$adrun/driver/stages.tsv" "$AD_FRONT" \
 --budget 1600 --depth 2 --frontier 4096 --start 4 --max-k 6 > "$out/old_adaptive_integer_check.txt"
python3 "$mvpkg/source/check_mv_resume.py" resume "$AD_FRONT" "$MV_EVENTS" \
 --initial "$MV_INIT" --stages "$mvrun/driver/stages.tsv" --final "$MV_FINAL" \
 --budget 4200 --depth 2 --cap 4096 --max-k 4 > "$out/old_mv_integer_check.txt"
python3 "$sub8/source/check_terms.py" "$SUB8" > "$out/sub8_check.txt"
python3 "$sub8/source/check_completion.py" "$s8run/summary.txt" "$SUB8" 8 8 0 > "$out/sub8_completion.txt"
python3 "$sel/source/check_selective.py" "$SUB8" "$SELECT" "$selrun/summary.txt" > "$out/selective_check.txt"
python3 "$hor/source/check_horizon.py" "$SELECT" "$REFINE" "$horrun/refine2/summary.txt" refine2 > "$out/refine2_check.txt"
python3 "$h3/source/check_h3_refined.py" "$SELECT" "$REFINE" "$H3S" "$h3run/h3_split2/summary.txt" h3_split2 > "$out/h3_check.txt"
python3 "$v2/source/import_phi40.py" --source "$S2" --out "$out/phi40_outer_256.txt" > "$out/import.log"
cmp "$out/phi40_outer_256.txt" "$mvrun/phi40_outer_256.txt"
{
 printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
 printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
 printf 'GCC=';g++ --version | head -1
 printf 'PYTHON=';python3 --version
 printf 'MODE=K5_ONLY BUDGET=%s MAX_DEPTH=%s MAX_FRONTIER=%s\n' "$budget" "$depth" "$frontier"
 printf 'MV_EVENTS_SHA256=2646cf7c0f7509d266a35dcbc13571b4de1cffee5fd13b2b9fc0b9b1827501c0\n'
 printf 'MV_FRONTIER_SHA256=6eccf6268602bd79dea722298abbe83e498eaeec905a9327a68d9a86e50185e1\n'
 printf 'MODE=SESSION_ONLY; no graph/tube proof, 3c-b or point jump\n'
} > "$out/environment.txt"
inc=(-I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" -I "$sel/source" -I "$hor/source" -I "$h3/source" -I "$adpkg/source" -I "$mvpkg/source" -I "$pkg/source")
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pedantic "${inc[@]}" "$pkg/source/k5.cpp" -o "$out/k5"
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pedantic "${inc[@]}" "$pkg/source/test_k4_checkpoint.cpp" -o "$out/test_k4_checkpoint"
"$out/test_k4_checkpoint" "$MV_EVENTS" "$MV_FINAL" parser > "$out/source_parser_check.txt"
# Sanitizer on source parser only; full k5 remains a separate scientific run.
g++ -std=c++17 -O0 -g0 -fsanitize=address,undefined -fno-omit-frame-pointer "${inc[@]}" \
 "$pkg/source/test_k4_checkpoint.cpp" -o "$out/test_k4_checkpoint_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 120s \
 "$out/test_k4_checkpoint_sanitized" "$MV_EVENTS" "$MV_FINAL" parser \
 > "$out/source_parser_sanitized.txt" 2> "$out/sanitizer_stderr.txt"
python3 "$pkg/tests/test_k5_structure.py" "$pkg/source/check_k5.py" > "$out/structure_units.txt"
set +e
"$out/k5" >/dev/null 2>&1; neg1=$?
"$out/k5" "$out/phi40_outer_256.txt" "$SELECT" "$REFINE" "$H3S" "$AD_EVENTS" "$AD_FRONT" "$MV_EVENTS" "$MV_INIT" "$MV_FINAL" "$out" 1 0 4096 >/dev/null 2>&1;neg2=$?
"$out/k5" "$out/phi40_outer_256.txt" "$SELECT" "$REFINE" "$H3S" "$AD_EVENTS" "$AD_FRONT" "$MV_EVENTS" "$MV_INIT" "$MV_FINAL" "$out" 3600 3 4096 >/dev/null 2>&1;neg3=$?
set -e
[[ "$neg1,$neg2,$neg3" == '64,3,3' ]] || { echo "STOP unexpected negative CLI codes $neg1,$neg2,$neg3" >&2;exit 3; }
printf 'NEGATIVE_CLI_PASS 64,3,3\n' > "$out/negative_controls.txt"
mkdir "$out/driver"
set +e
timeout -k 30s 5400s "$out/k5" "$out/phi40_outer_256.txt" "$SELECT" "$REFINE" "$H3S" "$AD_EVENTS" "$AD_FRONT" "$MV_EVENTS" "$MV_INIT" "$MV_FINAL" "$out/driver" \
 "$budget" "$depth" "$frontier" > "$out/driver/summary.txt" 2> "$out/driver/stderr.txt"
rc=$?
set -e
if [[ "$rc" == 0 || "$rc" == 2 ]];then
 if [[ -s "$out/driver/initial_frontier.tsv" && -s "$out/driver/events.tsv" && -s "$out/driver/stages.tsv" && -s "$out/driver/final_frontier.tsv" ]];then
  python3 "$pkg/source/check_k5.py" "$MV_FINAL" "$out/driver/initial_frontier.tsv" "$out/driver/events.tsv" \
   "$out/driver/stages.tsv" "$out/driver/final_frontier.tsv" "$out/driver/summary.txt" \
   --budget "$budget" --depth "$depth" --cap "$frontier" > "$out/driver/structure_check.txt" || exit 3
 fi
fi
(cd "$out/driver" && find . -maxdepth 1 -type f ! -name SHA256SUMS.txt -printf '%f\0' | sort -z | xargs -0 -r sha256sum > SHA256SUMS.txt)
(cd "$out" && find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name k5 ! -name test_k4_checkpoint ! -name test_k4_checkpoint_sanitized -printf '%f\0' | sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt)
cat "$out/driver/summary.txt"
[[ -s "$out/driver/structure_check.txt" ]] && cat "$out/driver/structure_check.txt"
if [[ $rc != 0 ]];then
 if [[ $rc == 2 && -s "$out/driver/structure_check.txt" ]];then
  echo 'INCONCLUSIVE: checked bounded k5 cover, no target theorem or jump';exit 2
 fi
 echo "INCOMPLETE/FAILURE rc=$rc; do NOT claim finished checked cover";exit 3
fi
[[ -s "$out/driver/structure_check.txt" ]] || { echo 'STOP k5 integer audit missing' >&2;exit 3; }
echo 'PASS: COMPLETE BOUNDED SESSION k5 STAGE ONLY; NOT a graph/tube or jump certificate'
