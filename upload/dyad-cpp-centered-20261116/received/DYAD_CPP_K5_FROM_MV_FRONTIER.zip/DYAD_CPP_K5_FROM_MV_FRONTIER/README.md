# DYAD OPEN 20 — k=5 from the exact 676-box mean-value k=4 frontier

## Scope and status

**SESSION development only.** This package implements a bounded **one-horizon k=5** conditional fibre necessary-condition contraction. It has **not** been run on the real Stage-2 transfer in the preparing environment. It is neither a certificate, a point-jump calculation, an independent implementation of `T`, nor authorization for stage 3c-b. The graph/tube hypotheses for **all k=1,2,3,4,5** remain conditional. The method only makes valid deductions **if** every alleged true candidate meets those hypotheses at the relevant image bases.

Input: the fixed previous k=4 MV continuation `final_frontier.tsv` (676 exact dyadic boxes, reported 3.223882e-5 L1 outer radius). All previous 924+256+252+972+384+2576 exclusions are **inherited**, not re-evaluated or recounted. The root of the chain is the Stage-2 N216/dps840 JSON.

## Mandatory SHA-256 sources

1. Stage2 JSON: `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`
2. F2 8x8 `terms.tsv` (1024): `1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72`
3. F2 `selective_children.tsv` (400): `3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579`
4. k3 comparison F2 `refine2/details.tsv` (576): `bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a`
5. F3 `h3_split2/details.tsv` (1296): `3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325`
6. First adaptive k4 `events.tsv` (1600): `276701a085aefcc528290e496a721f83080780fabab5aafd78f3f7b3cc0a8a1f`
7. First adaptive `final_frontier.tsv` (897): `4cb41a4f4fa860763f1f992acd7caeee53f48acf9e9e335d2263281e453d5c2f`
8. MV k4 continuation `events.tsv` (4037): `2646cf7c0f7509d266a35dcbc13571b4de1cffee5fd13b2b9fc0b9b1827501c0`
9. MV k4 continuation `final_frontier.tsv` (676): `6eccf6268602bd79dea722298abbe83e498eaeec905a9327a68d9a86e50185e1`
10. MV k4 `stages.tsv`: `fcca8378ec376c6d3b9278f40f5706d0d007035debaf1a97d07e38d557b14942`

All ten are checked with `sha256sum -c` before compiling. The dependency ZIP's own `SHA256SUMS`, existing `RUN_SHA256SUMS` and nested stage manifests are also checked. The wrapper re-runs earlier **independent integer auditors** for the adaptive and MV checkpoints, then uses the identical source-backed coefficient transfer as the previous runs.

## What is replayed and what is not

The C++ input parser reads and checks all 4037 k4 MV records for exact C1–C2 arithmetic, candidate retention, unique work ID, action and full FIFO split order, and reconstructs the complete 676-box final frontier **bit-exactly** from the frozen original 897-box initial frontier. Its exact L1 radius must equal the logged numerator `3732999916436855825052688974102440895822637379942020182587183471355933763/2^256`. This is a **source log reconstruction**, NOT an expensive re-evaluation of the 4037 k4 map orbits. The 144+324+324 earlier source survivors are independently re-evaluated through the unchanged F1/F2/F3 engine, as in the preceding package. Thus numerical provenance of inherited exclusions is pinned and owner-reviewed, not newly certified.

At the *new* horizon, the 676 rectangles are transferred unchanged except their per-horizon split depth is reset to zero. Each k5 probe disc undergoes exactly five full `F=T^6` blocks from the original lift with the derivative tangent never reset. The **same** reviewed MV base enclosure, per-box M5 on its own X5∩D0, whole-disc fibre derivative and C1–C2 necessary disc are used. A child is discarded only if the candidate rectangle and necessity disc have empty intersection. Split candidates use the **post-contractor** rectangle and exact dyadic 2x2 coverage. `2Dr>M5` is a scheduling heuristic, **not a theorem prerequisite**. `domain_error`, budget, depth and frontier-cap failure preserve candidates. Final L1 outer hull must not expand; cannot assert nonexistence if all candidates disappear from an apparent proof attempt.

## Bounded configuration

Suggested first production-*development* run parameters: `BUDGET=3600 MAX_DEPTH=1 MAX_FRONTIER=4096` (not 3c-b production). The first stage evaluates 676 roots; if every one splits, at most 2704 children are added, so the **worst-case evaluation total is 3380**, below 3600. Nevertheless `REFINEMENT_CAP` or `DOMAIN` may yield **exit 2 / INCONCLUSIVE** because a valid child still has high `Dr/M5` at depth one. `exit 0` denotes `READY` in this bounded k5 experiment only, not any form of mathematical adoption. Exit 3 denotes an input/code discrepancy or unexpected exception, not a valid scientific conclusion. The 5400s watchdog may stop an incomplete output; an output without `K5_INDEPENDENT_INTEGER_PASS` is not a complete audited run.

## Ubuntu CLI

Place the ZIP in `/root/`; check the announced SHA256 and `unzip -n`. Run:

```bash
bash /root/DYAD_CPP_K5_FROM_MV_FRONTIER/run_ubuntu_k5.sh \
 /root/rtg-corpus \
 /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
 /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
 /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
 /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
 /root/DYAD_CPP_F2_TERM_AUDIT_SUB8 \
 /root/DYAD_CPP_F2_SELECTIVE_REFINE \
 /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC \
 /root/DYAD_CPP_F3_ON_REFINED_324 \
 /root/DYAD_CPP_ADAPTIVE_HORIZON \
 /root/DYAD_CPP_MV_RESUME \
 /root/dyad-f2-term8-full \
 /root/dyad-f2-selective-run \
 /root/dyad-horizon-compare \
 /root/dyad-f3-refined-compare \
 /root/dyad-adaptive-k4-k6 \
 /root/dyad-mv-resume-k4 \
 /root/dyad-k5-from-mv \
 3600 1 4096

echo "exit=$?"
cat /root/dyad-k5-from-mv/driver/summary.txt
cat /root/dyad-k5-from-mv/driver/structure_check.txt
```

Each run needs a fresh output directory. The `driver/` directory contains exact integer `initial_frontier.tsv`, `events.tsv`, `stages.tsv`, `final_frontier.tsv`, and the independent `structure_check.txt`; the root and nested SHA256 manifests accompany it. Original evidence files are never modified.

## Evidence intake

When the ZIP and run directory have been prepared, **the PI** may upload the exact ZIP and, only after a checked run, the untouched outputs through `upload_k5_evidence.sh`. The paths are **distinct**:

- `upload/dyad-cpp-k5-20261120` for the exact ZIP.
- `upload/dyad-cpp-k5-results-20261120` for the full output directory.

A push creates an intake record, **not** approval of mathematics, merging or any adopted DSN. Full scientific source review, same-engine replay and byte comparison are separate owner K5-X1–X6 obligations.
