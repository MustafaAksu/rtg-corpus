#!/usr/bin/env python3
"""[SESSION] Synthetic complete checkpoint and bounded k5 recorder regression.

No real DYAD arithmetic. Requires exactly supplied checker and optional parser binary.
"""
import argparse, importlib.util, tempfile, subprocess
from pathlib import Path
from collections import deque
S=1<<256
RAD=3732999916436855825052688974102440895822637379942020182587183471355933763
FHEAD='id depth re_lo re_hi im_lo im_hi'
EVHEAD=('k id depth source_re_lo source_re_hi source_im_lo source_im_hi '
        'necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
        'final_re_lo final_re_hi final_im_lo final_im_hi '
        'M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
STHEAD=('k input evaluated excluded split retained unresolved budget_pending budget_valid_no_split depth_cap frontier_cap prior_L1_256 final_L1_256 median_ratio_256 Dr_gt_M stop')

def bf(v):return ' '.join(map(str,v))
def write(p,head,rows):p.write_text(head+'\n'+'\n'.join(map(bf,rows))+'\n')
def box(d):return (-RAD,RAD,0,0)
def nbox(far):return ((100*RAD-2*RAD,100*RAD+2*RAD, -2*RAD,2*RAD) if far else (-2*RAD,2*RAD,-2*RAD,2*RAD))
def erec(k,id,dep,b,need,final,M,Dr,D,r,lb,e,R,event,action):
 return (k,id,dep,*b,*need,*final,M,Dr,D,r,lb,e,R,event,action)

def source_fixture(folder,ck):
 initial=[('b'+str(i),0 if i==0 else 1,box(0)) for i in range(897)]
 q=deque(initial);events=[];kept=[];n=0;splits=0;excluded=0
 while q:
  id,d,b=q.popleft();far=(id=='b0' or (not '/' in id and int(id[1:])>785) or ('/' in id and n-897>=676))
  if '/' not in id and 1<=int(id[1:])<=785:action='SPLIT'
  else:action='EXCLUDED' if far else 'RETAINED'
  need=nbox(far)
  final=(0,0,0,0) if far else b
  events.append(erec(4,id,d,b,need,final,2*RAD,0,0,0,S,0,2*RAD,'VALID',action))
  n+=1
  if action=='SPLIT':
   splits+=1
   for j in range(4):q.append((id+'/'+str(j),d+1,ck.cut(b,j)))
  elif action=='RETAINED':kept.append((id,d,final))
  else:excluded+=1
 assert (len(events),splits,excluded,len(kept))==(4037,785,2576,676)
 assert all(w[1]==2 for w in kept)
 assert ck.hull_rad([v[2] for v in kept])==RAD
 root=folder/'old';root.mkdir()
 files=[root/'initial897.tsv',root/'events4037.tsv',root/'final676.tsv']
 write(files[0],FHEAD,[(id,d,*b) for id,d,b in initial])
 write(files[1],EVHEAD,events)
 write(files[2],FHEAD,[(id,d,*b) for id,d,b in kept])
 return files,kept

def k5_fixture(folder,ck,old,budget,depth,cap):
 root=folder/('new'+str(budget));root.mkdir()
 init=[(id,0,b) for id,d,b in old];q=deque(init);events=[];kept=[]
 total=excluded=split=ret=unres=pending=vb=dc=fc=gt=0;rat=[]
 while q:
  id,d,b=q.popleft()
  if total>=budget:
   pending+=1;kept.append((id,d,b))
   events.append(erec(5,id,d,b,b,b,0,0,0,0,0,0,0,'NOT_EVALUATED','BUDGET_KEEP'))
   continue
  total+=1
  M=RAD;Dr=RAD;D=RAD*S;r=1;lb=S;e=0;R=2*RAD
  far=('/' in id and (total%3==0))
  need=nbox(far);hit=ck.boxhit(b,need)
  rat.append(ck.ceil(Dr*S,M));gt+=Dr>M
  if hit is None:
   excluded+=1;action='EXCLUDED';fin=(0,0,0,0)
  else:
   fin=hit
   high=True
   canfront=len(q)+len(kept)+4<=cap
   canbudget=total+len(q)+4<=budget
   if high and d<depth and canfront and canbudget:
    action='SPLIT';split+=1
    for j in range(4):q.append((id+'/'+str(j),d+1,ck.cut(hit,j)))
   else:
    action='RETAINED';ret+=1
    if d>=depth:dc+=1
    elif not canfront:fc+=1
    else:vb+=1
    kept.append((id,d,fin))
  events.append(erec(5,id,d,b,need,fin,M,Dr,D,r,lb,e,R,'VALID',action))
 assert len(events)==total+pending
 stop='BUDGET' if pending or vb else 'REFINEMENT_CAP' if dc or fc else 'DOMAIN' if unres else 'READY'
 oldrad=ck.hull_rad([v[2] for v in init]);newrad=ck.hull_rad([v[2] for v in kept])
 stages=[(5,len(init),total,excluded,split,ret,unres,pending,vb,dc,fc,oldrad,newrad,ck.ceil(Dr*S,M),gt,stop)]
 write(root/'initial_frontier.tsv',FHEAD,[(id,d,*b) for id,d,b in init])
 write(root/'events.tsv',EVHEAD,events)
 write(root/'stages.tsv',STHEAD,stages)
 write(root/'final_frontier.tsv',FHEAD,[(id,d,*b) for id,d,b in kept])
 (root/'summary.txt').write_text(f'STATUS={stop} source_boxes=676 evaluations={total} budget={budget} stages=1 final_boxes={len(kept)} L1_256={newrad}\n')
 return root,stop

def row_edit(lines, index, value):
    fields=lines[1].split();fields[index]=str(value(fields[index]) if callable(value) else value)
    lines[1]=' '.join(fields)

def assert_reject(ck,old,paths,params):
 try:ck.verify(old,*paths,**params)
 except (AssertionError,ValueError,IndexError):return
 raise AssertionError('corrupted fixture incorrectly accepted')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('checker');ap.add_argument('--cpp',default=None);a=ap.parse_args()
 spec=importlib.util.spec_from_file_location('k5_checker',a.checker);ck=importlib.util.module_from_spec(spec);spec.loader.exec_module(ck)
 with tempfile.TemporaryDirectory(prefix='dyad-k5-tests-') as tmp:
  folder=Path(tmp);oldfiles,last=source_fixture(folder,ck)
  if a.cpp:
   ok=subprocess.run([a.cpp,str(oldfiles[1]),str(oldfiles[2]),'full',str(oldfiles[0])],capture_output=True,text=True)
   assert ok.returncode==0,(ok.stderr,ok.stdout)
   print(ok.stdout.strip())
  cases=[(3400,1,4096),(680,1,4096),(676,0,4096)]
  for budget,depth,cap in cases:
   d,expect=k5_fixture(folder,ck,last,budget,depth,cap)
   args=(d/'initial_frontier.tsv',d/'events.tsv',d/'stages.tsv',d/'final_frontier.tsv',d/'summary.txt')
   result=ck.verify(oldfiles[2],*args,budget,depth,cap)
   assert result==expect
   print('K5_SYNTHETIC_PASS',budget,depth,'stop',expect)
  d=folder/'new3400'
  orig=(d/'events.tsv').read_text().splitlines();st=(d/'stages.tsv').read_text().splitlines()
  args=(d/'initial_frontier.tsv',d/'events.tsv',d/'stages.tsv',d/'final_frontier.tsv',d/'summary.txt')
  count=0
  for key,modify in [
    ('header',lambda x:x.__setitem__(0,'invalid header')),
    ('truncate',lambda x:x.pop()),
    ('duplicate',lambda x:x.append(x[1])),
    ('wrong_key',lambda x:row_edit(x,1,'bad')),
    ('non_integer',lambda x:x.__setitem__(1,x[1].replace('VALID','BAD'))),
    ('bad_Dr',lambda x:row_edit(x,16,lambda y:int(y)+1)),
    ('false_exclude',lambda x:x.__setitem__(1,x[1].replace('SPLIT','EXCLUDED'))),
    ('bad_final',lambda x:x.__setitem__(1,x[1].replace('SPLIT','RETAINED'))),
    ('bad_depth',lambda x:row_edit(x,2,2)),
  ]:
   z=orig.copy();modify(z);assert z!=orig,key;(d/'events.tsv').write_text('\n'.join(z)+'\n')
   assert_reject(ck,oldfiles[2],args,dict(budget=3400,maxdepth=1,cap=4096));count+=1
  (d/'events.tsv').write_text('\n'.join(orig)+'\n')
  for n in (0,1,2,3,4,5,6,7,8):
   z=st.copy();v=z[1].split();v[n]=str(int(v[n])+1);z[1]=' '.join(v)
   (d/'stages.tsv').write_text('\n'.join(z)+'\n');assert_reject(ck,oldfiles[2],args,dict(budget=3400,maxdepth=1,cap=4096));count+=1
  (d/'stages.tsv').write_text('\n'.join(st)+'\n')
  print('K5_MUTATIONS_REJECTED',count)

if __name__=='__main__':main()
