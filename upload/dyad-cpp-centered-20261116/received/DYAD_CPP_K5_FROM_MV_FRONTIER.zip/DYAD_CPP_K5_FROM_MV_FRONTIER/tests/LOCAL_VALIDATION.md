# Local validation (pre-PI source-backed k5 run)

- C++17 normal `g++ -O2 -Wall -Wextra -Werror -pedantic`: PASS for the k5 binary and source checkpoint parser.
- C++ source parser under ASan/UBSan using a *synthetic* 4037-row/676-box frozen k4 FIFO fixture: PASS. Synthetic raw k4 897-box initial frontier and kept rectangles have the recorded shape/count and exact final L1 numerator but are **not** the actual DYAD k4 orbit.
- Independent Python integer k5 checker under synthetic bounded k5 sessions: 3400-budget / depth1 `REFINEMENT_CAP`, 680-budget `BUDGET`, and 676-budget / depth0 `REFINEMENT_CAP`; all PASS with full event/partition/retention/hull replay.
- 18 deliberate corruptions of event/stage input rejected; expected wrong CLI exits 64,3,3.
- Ten locally packaged prerequisite ZIP inner SHA256SUMS checks PASS. These are source-identity tests, not proof of their source mathematics.
- Real pinned Stage2 numerical k5 run: **NOT EXECUTED** in preparation environment; package, runner and exact dependency chain will be validated on PI Ubuntu before any new numerical claim.
- No authorized 3c-b production or replay; no jump, graph existence, tube proof or DSN scientific adoption.
- **Independent GitHub-data readback** (source bytes in PR #305-related `upload/dyad-cpp-mv-resume-results-20261119`): all 4037 real k4 MV event rows from blob `28000437dc7c375ecea0a2feb28707ca3f55385e` reconstructed the 676-row frontier from blob `bb8fd0876791b6a4a68f4c1cc3c4875eb78bba21` with *zero* coverage or C1–C2 integer mismatches (source initial 897 blob `40282d1c84148eb537efae06b4505f73c3e83160`). Real final L1 numerator matched the pinned `3732999916436855825052688974102440895822637379942020182587183471355933763`. This is independent **record arithmetic only**, NOT an independent rerun of the k4 dynamical flow or the new k5 numerical campaign.
- Isolated dummy Git remote tested the receipt helper with byte-exact ZIP intake and separate output branch, leaving dummy `main` unchanged. No branch was created in the actual GitHub repository by the package preparer.
