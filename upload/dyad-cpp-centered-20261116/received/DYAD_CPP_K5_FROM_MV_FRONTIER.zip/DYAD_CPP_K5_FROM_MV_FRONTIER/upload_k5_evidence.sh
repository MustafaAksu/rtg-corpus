#!/usr/bin/env bash
# [SESSION] Receive untouched k5 ZIP and run directory on distinct upload/* branches.
set -euo pipefail
if [[ $# != 5 || ( "$1" != package && "$1" != results ) || "$5" != --push ]];then
 echo 'Usage: upload_k5_evidence.sh package REPO EXACT_ZIP EXPECTED_SHA256 --push' >&2
 echo '   or upload_k5_evidence.sh results REPO OUTPUT_DIR - --push' >&2
 exit 64
fi
kind=$1;repo=$(cd -- "$2" && pwd);input=$(realpath -- "$3")
if [[ "$kind" == package ]];then
 [[ -f "$input" && "$4" =~ ^[a-f0-9]{64}$ ]] || exit 3
 printf '%s  %s\n' "$4" "$input" | sha256sum -c - >/dev/null
 branch='upload/dyad-cpp-k5-20261120'
else
 [[ -d "$input" ]] || exit 3
 (cd "$input" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
 (cd "$input/driver" && sha256sum -c SHA256SUMS.txt >/dev/null)
 grep -q '^K5_INDEPENDENT_INTEGER_PASS ' "$input/driver/structure_check.txt" || {
  echo 'STOP no verified k5 frontier; cannot upload results' >&2;exit 3; }
 branch='upload/dyad-cpp-k5-results-20261120'
fi
git -C "$repo" fetch origin main >/dev/null
if git -C "$repo" show-ref --verify --quiet "refs/heads/$branch" || \
   git -C "$repo" show-ref --verify --quiet "refs/remotes/origin/$branch";then
 echo "STOP branch already exists: $branch" >&2;exit 3
fi
wt=$(mktemp -d /tmp/dyad-k5-receipt-XXXXXX);rmdir "$wt"
cleanup(){ git -C "$repo" worktree remove --force "$wt" >/dev/null 2>&1 || true; }
trap cleanup EXIT
git -C "$repo" worktree add -b "$branch" "$wt" origin/main >/dev/null
if [[ "$kind" == package ]];then
 mkdir -p "$wt/$branch/received"
 cp -p -- "$input" "$wt/$branch/received/DYAD_CPP_K5_FROM_MV_FRONTIER.zip"
 (cd "$wt/$branch/received" && sha256sum DYAD_CPP_K5_FROM_MV_FRONTIER.zip > SHA256SUMS.txt)
else
 mkdir -p "$wt/$branch/pi-run"
 cp -a -- "$input/." "$wt/$branch/pi-run/"
 (cd "$wt/$branch/pi-run" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
fi
(cd "$wt";git add -- "$branch";git commit -m "upload/dyad: receive untouched k5 $kind SESSION evidence" >/dev/null
 echo "BRANCH=$branch";echo "COMMIT=$(git rev-parse HEAD)"
 git push origin "refs/heads/$branch:refs/heads/$branch")
echo 'UPLOAD_ONLY; no main merge, tag, DSN adoption, 3c-b or point-jump authorization'
