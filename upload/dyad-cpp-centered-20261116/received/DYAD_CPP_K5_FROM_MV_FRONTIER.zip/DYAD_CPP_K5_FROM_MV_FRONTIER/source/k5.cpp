// [SESSION] Conditional k=5 experiment from the byte-pinned, complete k=4 MV frontier.
// Earlier F1/F2/F3/adaptive/MV dynamics are included unchanged and never re-executed
// for the 4037 previously completed k=4 events. No sectorial-graph proof or jump.
#define DYAD_MV_NO_MAIN
#include "mv_resume.cpp"

namespace k5front {
using namespace dyad;
using namespace dyad::centered;
using Work=adapt::Work;
using Event=mvresume::Event;

std::vector<Event> load_k4_events(const std::string&path){
 std::ifstream f(path);if(!f)throw std::runtime_error("missing fixed MV k4 event file");
 std::ostringstream hh;adapt::output_header(hh);std::string hdr=hh.str();hdr.pop_back();
 std::string line;std::getline(f,line);if(line!=hdr)throw std::runtime_error("k4 MV events header mismatch");
 std::vector<Event> out;std::set<std::string> ids;
 auto getbox=[&](std::istringstream&in,C&box){Z a,b,c,d;
  if(!(in>>a>>b>>c>>d)||a>b||c>d)throw std::runtime_error("k4 bad box");
  box=C(I(a,b),I(c,d));};
 size_t spl=0,excl=0,ret=0;
 while(std::getline(f,line)){
  if(line.empty())throw std::runtime_error("k4 blank row");
  std::istringstream in(line);Event e;std::string extra;
  if(!(in>>e.k>>e.id>>e.depth))throw std::runtime_error("k4 invalid ID");
  getbox(in,e.input);getbox(in,e.need);getbox(in,e.final);
  if(!(in>>e.M>>e.Dr>>e.D>>e.r>>e.lb>>e.err>>e.R>>e.ev>>e.action)||(in>>extra))
   throw std::runtime_error("k4 wrong field count");
  if(e.k!=4||e.depth>2||e.ev!="VALID"||
    (e.action!="SPLIT"&&e.action!="RETAINED"&&e.action!="EXCLUDED")||
    !ids.insert(e.id).second||e.M<=0||e.lb<=0||e.D<0||e.Dr<0||e.r<0||e.R<0||e.err<0||
    e.Dr!=cd(e.D*e.r,SCALE)||e.R!=e.err+cd((e.M+e.Dr)*SCALE,e.lb)||
    e.need.re.h-e.need.re.l!=2*e.R||e.need.im.h-e.need.im.l!=2*e.R)
   throw std::runtime_error("k4 event invalid or integer radius mismatch");
  auto hit=intersection(e.input,e.need);
  if((e.action=="EXCLUDED"&&(hit||!adapt::same(e.final,C(0))))||
     (e.action!="EXCLUDED"&&(!hit||!adapt::same(*hit,e.final))))
   throw std::runtime_error("k4 event false discard/intersection mismatch");
  spl+=e.action=="SPLIT";excl+=e.action=="EXCLUDED";ret+=e.action=="RETAINED";
  out.push_back(e);
 }
 if(out.size()!=4037||spl!=785||excl!=2576||ret!=676)
  throw std::runtime_error("k4 MV run exact 4037/785/2576/676 counts not met");
 return out;
}
std::vector<Work> load_k4_end(const std::string&path){
 std::ifstream f(path);if(!f)throw std::runtime_error("missing fixed 676 frontier");
 std::ostringstream hh;adapt::frontier_header(hh);std::string hdr=hh.str();hdr.pop_back();
 std::string line;std::getline(f,line);if(line!=hdr)throw std::runtime_error("k4 MV final header mismatch");
 std::vector<Work> out;std::set<std::string> ids;
 while(std::getline(f,line)){
  std::istringstream in(line);Work w;Z a,b,c,d;std::string extra;
  if(line.empty()||!(in>>w.id>>w.depth>>a>>b>>c>>d)||(in>>extra)||
     w.depth!=2||a>b||c>d||!ids.insert(w.id).second)
   throw std::runtime_error("k4 MV final wrong row/ID/depth");
  w.box=C(I(a,b),I(c,d));out.push_back(w);
 }
 if(out.size()!=676)throw std::runtime_error("k4 MV final expected 676 boxes");
 return out;
}
void verify_mv_fifo(const std::vector<Work>&init,const std::vector<Event>&ev,
                    const std::vector<Work>&last){
 if(init.size()!=897||ev.size()!=4037||last.size()!=676)
  throw std::runtime_error("k4 MV source size mismatch");
 std::deque<Work> q(init.begin(),init.end());std::vector<Work> kept;size_t idx=0;
 while(!q.empty()){
  if(idx>=ev.size())throw std::runtime_error("k4 MV events truncated FIFO");
  const Work w=q.front();q.pop_front();const Event&e=ev[idx++];
  if(e.id!=w.id||e.depth!=w.depth||!adapt::same(e.input,w.box))
   throw std::runtime_error("k4 MV event FIFO or box mismatch");
  if(e.action=="SPLIT"){
   const auto child=f2::split_box(e.final,2);
   for(size_t j=0;j<4;++j)
    q.push_back(Work{w.id+"/"+std::to_string(j),child[j],w.depth+1});
  }else if(e.action=="RETAINED")kept.push_back(Work{w.id,e.final,w.depth});
 }
 if(idx!=ev.size()||kept.size()!=last.size())throw std::runtime_error("k4 MV FIFO cardinality mismatch");
 for(size_t j=0;j<last.size();++j)
  if(kept[j].id!=last[j].id||kept[j].depth!=last[j].depth||
     !adapt::same(kept[j].box,last[j].box))
   throw std::runtime_error("k4 MV final exact frontier mismatch");
 const auto h=adapt::hull(kept);
 if(!h||enclosing_disk(*h).r!=Z("3732999916436855825052688974102440895822637379942020182587183471355933763"))
  throw std::runtime_error("k4 MV final exact radius mismatch");
}
int run_k5(const Data&data,const f1::ForwardTube&tube,std::vector<Work>front,
           size_t budget,size_t depth,size_t cap,const std::string&dir){
 for(auto&w:front)w.depth=0; // a NEW horizon, old k4 depth 2 was verified, now reset.
 std::ofstream initial(dir+"/initial_frontier.tsv");adapt::print_frontier(initial,front);initial.close();
 std::ofstream ev(dir+"/events.tsv"),stg(dir+"/stages.tsv");
 if(!ev||!stg)throw std::runtime_error("cannot write k5 results");
 adapt::output_header(ev);mvresume::stage_header(stg);
 adapt::Options opt;opt.first_k=5;opt.max_k=5;opt.budget=budget;
 opt.max_depth=depth;opt.max_frontier=cap;
 size_t total=0;
 const auto s=mvresume::stage(data,tube,front,5,opt,total,ev);
 mvresume::stage_line(stg,s);ev.close();stg.close();
 std::ofstream final(dir+"/final_frontier.tsv");adapt::print_frontier(final,front);final.close();
 if(!ev||!stg||!final)throw std::runtime_error("k5 output write failed");
 const auto hh=adapt::hull(front);if(!hh)throw std::runtime_error("k5 null output hull");
 std::cout<<"STAGE=5 source=MV_K4_676 evaluated="<<s.evaluated<<" excluded="<<s.excluded
  <<" split="<<s.split<<" retained="<<front.size()<<" unresolved="<<s.unresolved
  <<" budget_pending="<<s.pending<<" budget_valid_no_split="<<s.valid_budget
  <<" depth_cap="<<s.depth_cap<<" frontier_cap="<<s.frontier_cap
  <<" finalL1="<<f1::outdec(s.after)<<" stop="<<s.stop<<'\n';
 std::cout<<"STATUS="<<s.stop<<" source_boxes=676 evaluations="<<total<<" budget="<<budget
  <<" stages=1 final_boxes="<<front.size()<<" L1_256="<<enclosing_disk(*hh).r
  <<" finalL1="<<f1::outdec(enclosing_disk(*hh).r)<<'\n';
 std::cout<<"SESSION_ONLY; k5 candidate cover conditional on graph/tube; "
  "NO stage 3c-b, jump, or certificate.\n";
 return s.stop=="READY"?0:2;
}
} // namespace k5front

#ifndef DYAD_K5_NO_MAIN
int main(int argc,char**argv){
 if(argc!=14){
  std::cerr<<"Usage: k5 TRANSFER SELECT400 REFINE576 H3SPLIT1296 ADAPTIVE1600_EVENTS "
   "ADAPTIVE897_FRONT MV4037_EVENTS MV897_INITIAL MV676_FINAL OUTDIR BUDGET DEPTH FRONTIER\n";
  return 64;
 }
 try{
  const size_t budget=adapt::arg(argv[11],"BUDGET",676,15000);
  const size_t depth=adapt::arg(argv[12],"MAX_DEPTH",0,2);
  const size_t cap=adapt::arg(argv[13],"MAX_FRONTIER",676,20000);
  const Data data=read_data(argv[1]);
  const auto select=horizon::load_checked_source(argv[2]);
  const auto refine=h3ref::load_frozen(select,argv[3]);
  const auto h3=adapt::load_seeds(refine,argv[4]);
  const auto old=mvresume::load_events(argv[5]);
  const auto oldfront=mvresume::load_frontier(argv[6]);
  mvresume::replay_frozen_events(old,oldfront);
  const auto init=mvresume::load_frontier(argv[8]);
  if(init.size()!=oldfront.size())throw std::runtime_error("source 897 initial count changed");
  for(size_t j=0;j<init.size();++j)
   if(init[j].id!=oldfront[j].id||init[j].depth!=oldfront[j].depth||
      !adapt::same(init[j].box,oldfront[j].box))
    throw std::runtime_error("MV k4 initial diverges from frozen adaptive 897 frontier");
  const auto mvEv=k5front::load_k4_events(argv[7]);
  const auto end=k5front::load_k4_end(argv[9]);
  k5front::verify_mv_fifo(init,mvEv,end);
  f1::ForwardTube tube(data.c);
  size_t n0=0,n1=0,n2=0;
  for(const auto&r:select)if(r.kept){horizon::replay(r,data,tube);n0++;}
  for(const auto&r:refine)if(r.kept){h3ref::replay_frozen(r,data,tube);n1++;}
  for(const auto&r:h3)if(r.kept){adapt::replay_seed(r,data,tube);n2++;}
  if(n0!=144||n1!=324||n2!=324)throw std::runtime_error("inherited graph source replay missing");
  return k5front::run_k5(data,tube,end,budget,depth,cap,argv[10]);
 }catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<'\n';return 2;}
  catch(const std::exception&e){std::cerr<<"INPUT_FAIL: "<<e.what()<<'\n';return 3;}
}
#endif
