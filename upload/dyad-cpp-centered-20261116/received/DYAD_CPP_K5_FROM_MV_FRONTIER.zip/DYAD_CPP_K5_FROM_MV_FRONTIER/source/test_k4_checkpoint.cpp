// [SESSION] Parser-only test; no full k5 numerical engine execution.
#define DYAD_K5_NO_MAIN
#include "k5.cpp"
int main(int argc,char**argv){
 if(argc!=4 && argc!=5)return 64;
 try{
  const auto ev=k5front::load_k4_events(argv[1]);
  const auto last=k5front::load_k4_end(argv[2]);
  if(std::string(argv[3])=="parser"){
   std::cout<<"K4_MV_CHECKPOINT_PARSER_PASS events="<<ev.size()<<" final="<<last.size()<<'\n';return 0;
  }
  if(std::string(argv[3])!="full" || argc!=5)return 64;
  const auto init=mvresume::load_frontier(argv[4]);
  k5front::verify_mv_fifo(init,ev,last);
  std::cout<<"K4_MV_CHECKPOINT_FIFO_PASS events="<<ev.size()<<" final="<<last.size()<<'\n';
  return 0;
 }catch(const std::exception&e){std::cerr<<"SOURCE_REJECT: "<<e.what()<<'\n';return 3;}
}
