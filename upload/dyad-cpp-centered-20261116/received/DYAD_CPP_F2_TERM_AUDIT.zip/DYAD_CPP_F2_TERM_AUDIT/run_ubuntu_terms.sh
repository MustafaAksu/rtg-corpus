#!/usr/bin/env bash
# [SESSION] DYAD F2 term diagnostic; no production, certification, replay or result adoption.
set -euo pipefail
if [[ $# -ne 8 ]]; then
  echo 'Usage: run_ubuntu_terms.sh REPO V2_DIR BENCH_DIR F1_DIR F2_DIR OUTPUT_DIR GRID(8|10) SUBDIV(2|4)' >&2
  exit 64
fi
repo=$(cd -- "$1" && pwd)
v2=$(cd -- "$2" && pwd)
bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd)
f2=$(cd -- "$5" && pwd)
out=$6
grid=$7
sub=$8
if [[ "$grid" != 8 && "$grid" != 10 ]] || [[ "$sub" != 2 && "$sub" != 4 ]]; then
  echo 'STOP: unsupported bounded mode' >&2; exit 64
fi
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -e "$out" ]]; then
  if [[ ! -d "$out" || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output path must be new or empty' >&2; exit 64
  fi
else mkdir -p -- "$out"; fi
out=$(cd -- "$out" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/audit_package_checks.txt"
(cd "$f2" && sha256sum -c SHA256SUMS.txt) > "$out/f2_package_checks.txt"
(cd "$f1" && sha256sum -c SHA256SUMS.txt) > "$out/f1_package_checks.txt"
(cd "$bench" && sha256sum -c SHA256SUMS.txt) > "$out/benchmark_package_checks.txt"
(cd "$v2" && sha256sum -c SHA256SUMS.txt) > "$out/v2_package_checks.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
if ! printf '%s  %s\n' "$expected" "$source_json" | sha256sum -c -; then
  echo 'STOP: Stage2 input SHA256 mismatch' >&2; exit 4
fi
{
  printf 'UTC='; date -u '+%Y-%m-%dT%H:%M:%SZ'
  printf 'REPO_HEAD='; git -C "$repo" rev-parse HEAD
  printf 'GCC='; g++ --version | head -1
  printf 'PYTHON='; python3 --version
  printf 'STAGE2_SOURCE_SHA256=%s\n' "$expected"
  printf 'GRID=%s SUBDIV=%s\n' "$grid" "$sub"
  printf 'SESSION_DIAGNOSTIC_ONLY=1; no scientific certificate or stage 3c-b\n'
} > "$out/environment.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" --out "$out/phi40_outer_256.txt" > "$out/import.log"
common=(-std=c++17 -O2 -Wall -Wextra -pedantic -I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source")
g++ "${common[@]}" "$src/source/f2_term_diagnostic.cpp" -o "$out/f2_term_diagnostic"
set +e
"$out/f2_term_diagnostic" >/dev/null 2>&1; rc_args=$?
"$out/f2_term_diagnostic" "$source_json" 8 2 0 "$out/negative_wrong.tsv" >/dev/null 2>&1; rc_source=$?
"$out/f2_term_diagnostic" "$out/phi40_outer_256.txt" 8 7 0 "$out/negative_subdiv.tsv" >/dev/null 2>&1; rc_subdiv=$?
set -e
if [[ "$rc_args" -ne 64 || "$rc_source" -ne 3 || "$rc_subdiv" -ne 3 ]]; then
  echo "STOP: negative CLI checks ($rc_args,$rc_source,$rc_subdiv) != (64,3,3)" >&2; exit 1
fi
echo "F2 TERM DIAGNOSTIC: grid=$grid subdivision=$sub (SESSION only)"
set +e
timeout -k 5s 300s "$out/f2_term_diagnostic" "$out/phi40_outer_256.txt" "$grid" "$sub" 0 "$out/terms.tsv" > "$out/summary.txt" 2> "$out/stderr.txt"
rc=$?
set -e
if [[ $rc -ne 0 ]]; then
  echo "INCONCLUSIVE: diagnostic exit=$rc; the partial TSV, if any, is not a completed run"
  exit 2
fi
python3 "$src/source/check_terms.py" "$out/terms.tsv" > "$out/check_terms.txt"
if ! grep -Fq "second_evaluated=256 second_unresolved=0" "$out/summary.txt"; then
  echo 'INCONCLUSIVE: expected complete 256 subtiles; inspect logs' >&2; exit 2
fi
(
 cd "$out"
 find . -maxdepth 1 -type f ! -name 'RUN_SHA256SUMS.txt' ! -name 'f2_term_diagnostic' -printf '%f\0' |
  sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt
)
cat "$out/summary.txt"
echo 'PASS SESSION_TERM_DIAGNOSTIC; only quantifies M2 and Dr; NO certification or jump.'
