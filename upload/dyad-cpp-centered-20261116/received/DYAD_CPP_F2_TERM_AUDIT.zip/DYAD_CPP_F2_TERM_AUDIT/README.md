# DYAD OPEN 20 — independent C++ F2 term diagnostics (SESSION)

**Author:** ChatGPT, DYAD co-owner. **Date:** 17 November 2026.  
**Scope:** Measure the numerical contributions of `M2` and the derivative-spread term `D*r` in the **already-reviewed** F2 necessary-condition contractor. **No candidate is discarded by this diagnostic**, and this package does not compute a jump, produce a certificate, authorize stage 3c-b, or establish the sectorial invariant graph/tube.

## Dependencies and provenance

This diagnostic **does not copy or modify** source files from the four frozen dependencies; it includes the unchanged F2 implementation at compile time. The runnable command SHA-checks `SHA256SUMS.txt` in each extracted package and the authoritative stage-2 JSON:

- `DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2` SHA256 of the received ZIP: `98390698d1492f78aa02ae01e0d1984101d7634635ce6bd42bb2bfabf5cb6ecc`.
- `DYAD_CPP_FORWARD_METHOD_BENCHMARK`: `6079c11b03c61e852689f5dd318f8e93438a66eb19a9dae68c83b1ae00f8176d`.
- `DYAD_CPP_F1_TUBE_CONTRACTOR`: `f8e66093fa2980ef48d96cd7d975aceca4532c9ca47dcdb05138c19961a5a567`.
- `DYAD_CPP_F2_TUBE_CONTRACTOR`: `b30dda66278ee6e21fde8b040f80abebb9ad534c906e3cb9613112b5e30d378e`.
- `evidence/dyad/open20-an/stage2/scout_N216_dps840.json`: `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.

The source is the reviewable main file `source/f2_term_diagnostic.cpp`, which uses the pinned 80-digit transfer routine without independent coefficient regeneration. It calls exactly the F1 and F2 functions already reviewed by the owner; its extra operation is reporting the pieces of the radius formula.

## Mathematical object

For a second-stage box `part` with enclosing disk `B = B(a,r)`, let `f(d) = d_2(d)` and

- `M2`: rigorous `ForwardTube::upper(X2)` for `X2 \cap D0`, under the fixed-branch/tube hypotheses;
- `b`: midpoint of an enclosure of `f'(a)` from a fresh point-orbit;
- `D := norm_upper(f'(B)-b)`, enclosing the derivative spread **on the entire disk**;
- `Dr := ceil(D*r)` in units scaled by `2^256`;
- `E`: radius of the recentered interval for `a - f(a)/b`;
- `B_needed`: the F2 necessary-condition disk with radius `E + ceil((M2+Dr)/|b|_lower)`.

`Dr` and `M2` use the *same C1–C2 computation* as F2, not a fitted derivative. The program asserts the exact integer identity for `B_needed` on each evaluated subtile. A large `Dr/M2` demonstrates overestimation in this **particular enclosure**, not rapid growth of the mathematical derivative.

The `terms.tsv` gives exact 256-bit integer endpoints for every valid subtile, including `M2`, `Dr`, `D`, the disk radius `r`, lower bound on `|b|`, recentering error, necessary radius and the conditional intersection action. Unresolved arithmetic retains the current part. The text summary contains counts and ratios rounded for display only.

## Ubuntu command

Place this archive under `/root/`, extract it, and keep the four dependency packages in the already extracted directories. Then:

```bash
unzip -q -n /root/DYAD_CPP_F2_TERM_AUDIT.zip -d /root
bash /root/DYAD_CPP_F2_TERM_AUDIT/run_ubuntu_terms.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
  /root/dyad-f2-terms-grid8 8 4
```

For grid 10, use a **new output directory** and replace the last arguments by `/root/dyad-f2-terms-grid10 10 4`.

`exit=0` means the bounded term diagnostic completed with no unresolved tile. It is **not** scientific adoption. `exit=2` means unresolved or incomplete, and partial output must not be treated as a full campaign. `exit=3` is an input/runtime failure; `exit=64` an invalid request. The runner never edits the source repository, frozen dependencies or F2 results.

For review:

```bash
cat /root/dyad-f2-terms-grid8/summary.txt
cat /root/dyad-f2-terms-grid8/check_terms.txt
sha256sum -c /root/dyad-f2-terms-grid8/RUN_SHA256SUMS.txt   # run from output directory instead if relative entries
```

The `RUN_SHA256SUMS.txt` contains paths relative to its own output directory. Execute `cd /root/dyad-f2-terms-grid8 && sha256sum -c RUN_SHA256SUMS.txt` for an actual verification.

## Development checks and limits

A local, **proxy only** run using 18-significant-digit coefficients with ±1e-15 pads completed grid 8 / 2×2: 64/64 second subtiles evaluated; `Dr>M2` on 64/64 and `Dr>2M2` on 64/64; median `Dr/M2 = 12.32366`; output hull `1.526195e-3` (matches the previously reported proxy F2 count). The new exact-integer checker passed all 64 rows and the program passed negative CLI controls `(64,3,3)`.

A second proxy grid 8 / 4×4 run was **interrupted by the local execution-time limit** after 240 complete second-subtile rows of 256. On those **240 rows only**, `Dr>2M2` throughout and median `Dr/M2 ≈ 4.54165`; those are **incomplete statistics**, not a full benchmark result. The remaining 16 rows and real source-backed run are not claimed.

The owner in PR #305 accepted F1/F2 development scope; O-1 is an independent owner-side correction. No new code from this package is an owner-approved theorem or adopted canonical content.
