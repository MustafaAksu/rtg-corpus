# Review request — C++ F2 derivative-spread / tube-bound diagnostic

**Status:** [SESSION] implementation proposal, not an owner or PI accepted result.  
**Basis:** accepted F1/F2 packages, owner PR #305 head `771a7484c36614ef06179f0c3e6ead55ffcc369a`; scientific owner proof record §§1, 5, 9 (DYAD v6.4.24).

## Requested owner checks

1. Confirm this wrapper includes the untouched reviewed `real_f2_tube.cpp` and faithfully uses the same first-step intersection, `split_box`, `ball(part)`, 2-block `iter`, and `ForwardTube::upper` calls.
2. Validate that `D=norm_upper(R2.b.d - b)`, `Dr=ceil(D*r)` and `M2` are *exactly* the quantities entering `necessary_disk`, with the same scale `2^256` and the same lower bound `norm_lower(b)`.
3. Check the exact-integer identity `necessary.r == center_error + ceil((M2+Dr)/lower)` and verify the independent `check_terms.py` row consistency check.
4. Verify that `UNRESOLVED` parts are not elided or mistakenly claimed discarded, that any limited or interrupted run is not marked complete, and that stdout summary counts match actual F2 source-backed run counts.
5. Confirm that the interpretation `Dr/M2` is an **enclosure pessimism diagnostic**, not the actual derivative variation. Review the choice of subdivision vs longer horizon only after the PI has run actual pinned-transfer input. The source-transfer check is inherited, not independently reconstructed.

## Separate owner obligation: O-1

PI's earlier numbered reply in this conversation was **"1- koydum / 2- öneri uygun / 3- aşağıda paylaşıyorum"**, responding to the owner's numbered list (upload, O-1, package/review). Co-owner interpreted item 2 as permission to **prepare**, not adopt, a fixed-dyadic `c_j` correction. Please record the PI interpretation accurately and develop O-1 on a separate owner branch; a constant must be *fixed at a specified profile and exact rational endpoint* and the source library's variable `cw.upper()` usages need explicit cross-profile checks, before recommending any changes to the proof record.
