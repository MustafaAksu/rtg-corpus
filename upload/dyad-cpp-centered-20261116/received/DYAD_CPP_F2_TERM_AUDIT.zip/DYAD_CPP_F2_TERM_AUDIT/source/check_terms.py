#!/usr/bin/env python3
"""SESSION: independent exact-integer cross-check of fixed-point F2 diagnostic rows.
Does not assess analytic/tube hypotheses. A diagnostic may be incomplete or conditional.
"""
import argparse
from pathlib import Path
S=1<<256

def cd(a,b):return -(-a//b)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('details')
    a=p.parse_args()
    l=Path(a.details).read_text().splitlines()
    assert l and l[0]==('first_tile second_subtile M2_256 Dr_256 D_256 r_256 '
      'lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
    counts={'VALID':0,'UNRESOLVED':0,'EXCLUDED':0,'RETAINED':0};gt=gt2=0
    inds=set()
    for line in l[1:]:
        cols=line.split(); assert len(cols)==11, cols
        ti,si,M,Dr,D,r,lb,e,rad=map(int,cols[:9]); stat,action=cols[9:]
        assert (ti,si) not in inds;inds.add((ti,si))
        assert stat in ('VALID','UNRESOLVED')
        assert action in ('RETAINED','EXCLUDED')
        counts[stat]+=1;counts[action]+=1
        if stat=='VALID':
            assert M>0 and Dr>=0 and D>=0 and r>=0 and lb>0 and e>=0 and rad>=0
            assert Dr==cd(D*r,S), ('directed product',ti,si)
            assert rad==e+cd((M+Dr)*S,lb), ('C1C2 radius formula',ti,si)
            gt+=Dr>M;gt2+=Dr>2*M
        else:
            assert action=='RETAINED'
    assert sum(counts[k] for k in ('VALID','UNRESOLVED'))==len(l)-1
    print('SESSION_F2_TERM_ROWS_OK',len(l)-1,counts,'Dr_gt_M',gt,'Dr_gt_2M',gt2)
if __name__=='__main__':main()
