// [SESSION] Inspect numerical tightness of the already-reviewed F2 C1-C2
// necessary-condition radius. NO new theorem, tube assumption, or candidate discard.
// Compile with the original reviewed F2 source on the include path; never edit it.
#define DYAD_F2_NO_MAIN
#include "real_f2_tube.cpp"
#include <algorithm>
#include <numeric>

namespace diag {
using namespace dyad;
using namespace dyad::centered;
struct Row {
  size_t i, j;
  Z m, dr, D, tile_radius, slope_lower, centre_error, necessary_radius;
  bool eligible, hit;
};
struct Stat {
  size_t active=0, first_unresolved=0, first_excluded=0, first_retained=0,
         second_evaluated=0, second_unresolved=0, second_excluded=0, second_retained=0,
         dr_gt_m=0, dr_2m=0, dr_5m=0, dr_10m=0;
  std::vector<Z> ratios; std::optional<C> hull;
};
void write_row(std::ostream &o,const Row&v){
  o<<v.i<<' '<<v.j<<' '<<v.m<<' '<<v.dr<<' '<<v.D<<' '<<v.tile_radius<<' '
   <<v.slope_lower<<' '<<v.centre_error<<' '<<v.necessary_radius<<' '
   <<(v.eligible?"VALID":"UNRESOLVED")<<' '<<(v.hit?"RETAINED":"EXCLUDED")<<'\n';
}
Z safe_ratio(Z num,Z den){if(den<=0)throw std::domain_error("ratio denominator zero");return cd(num*SCALE,den);}

Stat measure(const Data&data,size_t grid,size_t sub,size_t limit,const std::string&outname){
  f1::ForwardTube TB(data.c);Stat st;
  const auto tilelist=tiles(grid);st.active=tilelist.size();
  std::ofstream out(outname);if(!out)throw std::runtime_error("cannot open output file");
  out<<"first_tile second_subtile M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action\n";
  bool limit_reached=false;
  for(size_t i=0;i<tilelist.size();++i){
    const Disk&tile=tilelist[i]; C first=tile.box();
    try {
      State R=f2::iter(TB.at_start(),tile,data.phi,1);
      Z M1=TB.upper(R.a.v).M;
      State P=f2::iter(TB.at_start(),Disk(tile.c,0),data.phi,1);
      C b1=mid(P.b.d); if(norm_lower(b1)<=0)throw std::domain_error("first b cannot exclude zero");
      Disk ND=necessary_disk(tile,P.b.v,R.b.d,b1,M1);
      auto hit1=intersection(first,ND.box());
      if(!hit1){++st.first_excluded;continue;}
      ++st.first_retained;
      const auto parts=f2::split_box(*hit1,sub);
      for(size_t j=0;j<parts.size();++j){
        if(limit && st.second_evaluated+st.second_unresolved >= limit){limit_reached=true;break;}
        C part=parts[j]; Disk D=ball(part);
        try {
          State R2=f2::iter(TB.at_start(),D,data.phi,2);
          Z M2=TB.upper(R2.a.v).M;
          State P2=f2::iter(TB.at_start(),Disk(D.c,0),data.phi,2);
          C b2=mid(P2.b.d);
          Z lb=norm_lower(b2);
          if(lb<=0)throw std::domain_error("second slope can be zero");
          Z DD=norm_upper(R2.b.d-b2);
          Z Dr=cd(DD*D.r,SCALE);
          Disk necessary=necessary_disk(D,P2.b.v,R2.b.d,b2,M2);
          C shifted=D.c-P2.b.v/b2;
          Z center_error=norm_upper(shifted-mid(shifted));
          Z expected_radius = center_error + cd((M2+Dr)*SCALE,lb);
          if(necessary.r != expected_radius) throw std::runtime_error("C1-C2 radius identity failed");
          auto hit2=intersection(part,necessary.box());
          Row row{i,j,M2,Dr,DD,D.r,lb,center_error,necessary.r,true,hit2.has_value()};
          write_row(out,row);
          ++st.second_evaluated;
          if(Dr>M2)++st.dr_gt_m;
          if(Dr>2*M2)++st.dr_2m;
          if(Dr>5*M2)++st.dr_5m;
          if(Dr>10*M2)++st.dr_10m;
          st.ratios.push_back(safe_ratio(Dr,M2));
          if(hit2){++st.second_retained;f1::add_hull(st.hull,*hit2);}
          else ++st.second_excluded;
        } catch(const std::domain_error& e){
          ++st.second_unresolved;
          f1::add_hull(st.hull,part);
          out<<i<<' '<<j<<" 0 0 0 0 0 0 0 UNRESOLVED RETAINED\n";
          if(st.second_unresolved<=4)std::cerr<<"UNRESOLVED i="<<i<<" j="<<j<<" : "<<e.what()<<'\n';
        }
      }
      if(limit_reached)break;
    } catch(const std::domain_error& e){
      ++st.first_unresolved;
      f1::add_hull(st.hull,first);
      if(st.first_unresolved<=4)std::cerr<<"UNRESOLVED F1 i="<<i<<" : "<<e.what()<<'\n';
    }
  }
  std::sort(st.ratios.begin(),st.ratios.end());
  std::cout<<"MODE=SESSION_ONLY; F2_TERM_DIAGNOSTIC; LIMIT="<<limit<<"; SAMPLED="<<(limit_reached?"YES":"NO")<<"\n";
  std::cout<<"grid="<<grid<<" subdiv="<<sub<<" active="<<st.active
           <<" first_excluded="<<st.first_excluded<<" first_retained="<<st.first_retained
           <<" first_unresolved="<<st.first_unresolved
           <<" second_evaluated="<<st.second_evaluated<<" second_unresolved="<<st.second_unresolved
           <<" second_excluded="<<st.second_excluded<<" second_retained="<<st.second_retained<<"\n";
  std::cout<<"Dr_gt_M2="<<st.dr_gt_m<<" Dr_gt_2M2="<<st.dr_2m
           <<" Dr_gt_5M2="<<st.dr_5m<<" Dr_gt_10M2="<<st.dr_10m<<"\n";
  if(!st.ratios.empty()){
    std::cout<<"Dr_over_M2_min="<<f1::outdec(st.ratios[0])
             <<" median="<<f1::outdec(st.ratios[st.ratios.size()/2])
             <<" max="<<f1::outdec(st.ratios.back())<<"\n";
  }
  if(!limit_reached && st.first_unresolved==0 && st.second_unresolved==0 && st.hull){
    std::cout<<"final_L1_hull="<<f1::outdec(enclosing_disk(*st.hull).r)<<"\n";
  } else std::cout<<"final_L1_hull=NOT_REPORTED_INCOMPLETE\n";
  std::cout<<"NO_CERTIFICATE; the F1/F2 contractor is conditional on owner tube/graph hypotheses.\n";
  return st;
}
} // namespace diag

int main(int argc,char**argv){
  if(argc!=6){std::cerr<<"usage: f2_term_diagnostic TRANSFER GRID(8|10) SUBDIV(2|4) MAX_SECOND(0=full) OUTPUT_TSV\n";return 64;}
  try{
    size_t g=std::stoul(argv[2]);size_t s=std::stoul(argv[3]),m=std::stoul(argv[4]);
    if((g!=8&&g!=10)||(s!=2&&s!=4)||m>256)throw std::invalid_argument("invalid bounded parameters");
    const Data data=read_data(argv[1]);
    auto st=diag::measure(data,g,s,m,argv[5]);
    if(st.first_unresolved || st.second_unresolved)return 2;
    return 0;
  }catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE "<<e.what()<<'\n';return 2;}
   catch(const std::exception&e){std::cerr<<"INPUT_FAIL "<<e.what()<<'\n';return 3;}
}
