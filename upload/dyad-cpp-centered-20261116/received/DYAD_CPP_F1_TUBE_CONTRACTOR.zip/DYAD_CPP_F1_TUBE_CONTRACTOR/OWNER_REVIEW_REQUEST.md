# Owner mathematical and code review — C++ first-block M(X∩D0) and contractor

**Status:** [SESSION] co-owner development request. No adoption, production, or certification requested.

Please inspect the new `source/real_f1_tube.cpp` against DYAD stage 3c-a proof record §§1, 4–5, 9 and the 17 Nov PR #301 §3.5:

1. **R1 (main):** Check that `M(X)` upper-bounds `R0` on **X∩D0**, including the alpha coefficient signs, `|ξ|²` log conversion, chart principal-argument cap, exact decimal `τ`, `first` and `second` floors, and `ε` cancellation at ξ*.
2. **R2:** Independently check the directed-rounding bounds in `pi_interval`, `atan_interval`, `log_positive_interval`, algebraic `exp(i3π/8)`, and `exp_c` (existing engine). A sample check is not sufficient for semantic proof.
3. **R3:** Check the whole-tile derivative assumption in `necessary_disk`, the exact centre and radius transfer, the complete grid coverage, and no false discard when an enclosure is unavailable. Inspect the `details_grid_*.tsv` and the negative controls.
4. **R4:** Review the **input dependence** on Stage 2 displayed 80-digit midpoint strings with source-reported `ball_radius_a_k`; the unchanged import currently assumes ±1e-65 / ±1e-32. Before theorem-grade use, verify the display method or regenerate raw interval endpoints unchanged from Arb.
5. **R5:** Distinguish the conditional graph/seed hypothesis from the theorem on `M(X)` and from the numerical 8×8/10×10 campaign. Compare the PI Ubuntu outputs with the local proxy only at [NUM]/SESSION scope.

The C++ base code, `Tcentered`, and the C1–C2 necessary contractor remain unchanged; no stage 3c-b execution is authorized. A finding that weakens a bound or leaves all tiles unresolved is useful and should be recorded, not replaced by an unsound shrink.
