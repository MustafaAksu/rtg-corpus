#!/usr/bin/env python3
"""Independent mpmath spot-check of first-step R0 <= imported C++ M1.

SESSION numerical validation only: sampled points and transfer midpoints, NOT a
proof of interval bounds, a tube theorem, or a candidate-selection verdict.
"""
import argparse
import math
from pathlib import Path
import mpmath as mp

SCALE = 1 << 256
SHA = '6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e'

def load_transfer(path):
    s = Path(path).read_text().splitlines()
    assert len(s) == 43 and s[0] == 'DYAD_PHI40_OUTER_V1' and s[1] == SHA
    p = [mp.mpc(0), mp.mpc(0)]
    for k, line in enumerate(s[2:-2], 2):
        a = line.split()
        assert len(a) == 5 and int(a[0]) == k
        endpoints = [int(v) for v in a[1:]]
        p.append(mp.mpc(mp.mpf(endpoints[0]+endpoints[1])/(2*SCALE),
                        mp.mpf(endpoints[2]+endpoints[3])/(2*SCALE)))
    a = s[-2].split()
    assert a[0] == 'C' and len(a) == 5 and s[-1] == 'END'
    q = list(map(int, a[1:]))
    c = mp.mpc(mp.mpf(q[0]+q[1])/(2*SCALE), mp.mpf(q[2]+q[3])/(2*SCALE))
    return p, c

def polynom(a, x):
    z = mp.mpc(0)
    for k in reversed(a):
        z = z*x + k
    return z

def image(x, d, phi):
    omega = mp.e**(2*mp.pi*1j/3)
    z, w = x, polynom(phi,x)+x*x*d
    eta = (z-w)/(omega-omega.conjugate())
    rho = z-omega*eta
    for _ in range(6):
        ss = mp.sin(eta)
        rho, eta = rho-ss, eta+mp.exp(rho)-1-ss
    return rho+omega*eta

def tau(x):
    return (mp.mpc('-3.32788058725899','-0.681896765229739')/x**3+
            mp.mpc('0.536700186091055','1.61148875597112')/x**2+
            mp.mpc('-0.135079834899795','0.153567697075599')/x+
            mp.mpc('1.81162096236788','0.0896653995437725')*mp.log(x))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--transfer',required=True)
    parser.add_argument('--tiles',required=True)
    args=parser.parse_args()
    mp.mp.dps = 110
    coeff,c=load_transfer(args.transfer)
    xi_star=mp.mpc(mp.sqrt(3)/5, mp.mpf(1)/5)
    xstar=xi_star/c
    tstar=tau(xstar)
    rot=mp.e**(3*mp.pi*1j/8)
    second_star=mp.re(rot*tstar)
    wall=second_star-mp.mpf('0.15')
    alpha=mp.mpc(-mp.mpf(102)/19,-16*mp.sqrt(3)/19)
    counted=0;valid=0;maxratio=mp.mpf(0);first_bad=None
    rows=Path(args.tiles).read_text().splitlines()
    assert rows[0].startswith('tile center_re_256 ') and len(rows)>1
    choices=(mp.mpc(0),mp.mpc(1)/2,-mp.mpc(1)/2,
             mp.mpc(1)/2,-mp.mpc(1)/2, mp.mpc(1,1)/4, mp.mpc(-1,1)/4)
    for line in rows[1:]:
        a=line.split()
        assert len(a)==10, f'format: {a[:3]}'
        idx=int(a[0]);center=mp.mpc(mp.mpf(int(a[1]))/SCALE,mp.mpf(int(a[2]))/SCALE)
        radius=mp.mpf(int(a[3]))/SCALE
        if a[4]=='NA':continue
        M=mp.mpf(int(a[4]))/SCALE
        for direction in choices:
            d=center+radius*direction
            if abs(d)>mp.mpf('0.002'):continue
            counted+=1
            x1=image(xstar,d,coeff)
            xi=c*x1
            theta=mp.arg(xi)
            if abs(xi)>=mp.mpf('0.60') or not (-mp.pi/5<theta<mp.mpf(3)*mp.pi/10):continue
            t=tau(x1)
            first=mp.re(t-tstar)+mp.mpf('1.25')
            second=mp.re(rot*t)
            if first<=1 or second<=wall:continue
            valid+=1
            multiplier=mp.exp(mp.re(alpha*(mp.log(xi)-mp.log(xi_star))))
            R=mp.mpf('0.002')*multiplier*(mp.mpf('1.25')/first)**3*(second_star/second)**3
            ratio=R/M
            maxratio=max(maxratio,ratio)
            if R>M and first_bad is None:
                first_bad=(idx,mp.nstr(R,22),mp.nstr(M,22))
    print(f'SAMPLED={counted} WITHIN_D0={valid} MAX_R_OVER_CERTIFIED_M={mp.nstr(maxratio,20)}')
    if valid==0:
        print('NO_D0_WITNESSES: numerical check inconclusive')
        return 2
    if first_bad:
        print('FAIL SAMPLE R_OVER_M',first_bad)
        return 1
    print('PASS_SAMPLES: supports but does NOT certify interval M bounds or candidate elimination')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
