// [SESSION] DYAD OPEN 20: conditional one-step F-leg tube outer contractor.
// The original dyadic arithmetic, initial fibre tiling and per-primitive-T mean value schedule
// remain in the previously reviewed source files, compiled through the unchanged bench.cpp.
// This is NOT a certificate of a sectorial curve, a point jump, or stage 3c-b.
#define DYAD_BENCH_NO_MAIN
#include "bench.cpp"
#include <cassert>
#include <cctype>
#include <climits>
#include <limits>
#include <map>

namespace f1 {
using namespace dyad;
using namespace dyad::centered;

// All decimal input is interpreted as an exact rational number, then outward-rounded.
I decimal(const std::string& s) {
    if (s.empty()) throw std::invalid_argument("empty decimal");
    bool neg=false; size_t i=0;
    if(s[0]=='-'||s[0]=='+'){neg=s[0]=='-';++i;}
    Z n=0,d=1; bool dot=false,any=false;
    for(;i<s.size();++i){char ch=s[i]; if(ch=='.') {if(dot) throw std::invalid_argument("two dots");dot=true;continue;}
       if(ch<'0'||ch>'9') throw std::invalid_argument("decimal syntax");
       any=true;n=n*10+(ch-'0');if(dot)d*=10;
    }
    if(!any)throw std::invalid_argument("no decimal digits");
    if(neg)n=-n;
    return I(fd(n*SCALE,d),cd(n*SCALE,d));
}
I point_interval(const Z& endpoint) {return I::point(endpoint);}
Z ceil_mag(const I&x){return au(x);}

// atan(t) for 0<=t<=1. Directed interval evaluation and first-omitted-term bound.
// Leibniz series is alternating with decreasing positive terms on [0,1].
I atan_nonnegative_point(const I& u) {
  if(!u.exact() || u.l<0 || u.h>SCALE)throw std::domain_error("atan point domain");
  constexpr long N=320; // sufficient for |u| around 0.5; safe (but may be broad) up to 1
  I term=u,uu=u*u,sum(0);
  for(long k=0;k<N;++k){I q=term/I(2*k+1);sum=(k&1)?sum-q:sum+q;term=term*uu;}
  I err=term/I(2*N+1);
  return (N&1)?I(sum.l-err.h,sum.h):I(sum.l,sum.h+err.h);
}
I atan_interval(const I&u);
I pi_interval(){
  static const I p=I(16)*atan_interval(I::rat(1,5))-I(4)*atan_interval(I::rat(1,239));
  return p;
}
I atan_interval(const I&u);
I atan_point(const I& u){
  if(!u.exact()) throw std::invalid_argument("atan_point exact argument required");
  if(u.l<0)return -atan_point(-u);
  if(u.l<=SCALE)return atan_nonnegative_point(u);
  return pi_interval()/I(2)-atan_interval(I(1)/u);
}
I atan_interval(const I&u){
  I lo=atan_point(I::point(u.l)),hi=atan_point(I::point(u.h));
  return I(lo.l,hi.h); // monotonic atan
}
// log(u) = 2 sum_{k=0}^{N-1} q^(2k+1)/(2k+1) + R,
// q=(u-1)/(u+1), |R|<=2|q|^(2N+1)/((2N+1)(1-q²)), valid |q|<1.
I log_positive_point(const I& u){
  if(!u.exact() || u.l<=0)throw std::domain_error("log point positive");
  I q=(u-I(1))/(u+I(1)), q2=q*q,term=q,sum(0);
  constexpr long N=240;
  for(long k=0;k<N;++k){sum=sum+term/I(2*k+1);term=term*q2;}
  I rem=I::point(ceil_mag(term));
  I den=I(1)-q2;
  if(den.l<=0)throw std::domain_error("log range budget");
  I err=I(2)*rem/(I(2*N+1)*den);
  I doubled=I(2)*sum; return I(doubled.l-err.h,doubled.h+err.h);
}
I log_positive_interval(const I&u){
  if(u.l<=0)throw std::domain_error("log interval contains zero");
  I a=log_positive_point(I::point(u.l)),b=log_positive_point(I::point(u.h));
  return I(a.l,b.h);
}
I atan2_right_halfplane(const C&u){
  if(u.re.l<=0)throw std::domain_error("arg requires positive Re");
  return atan_interval(u.im/u.re);
}
C clog_right_halfplane(const C&u){
  if(u.re.l<=0)throw std::domain_error("principal log requires Re>0");
  I r2=sq(u.re)+sq(u.im);
  return C(log_positive_interval(r2)/I(2),atan2_right_halfplane(u));
}
C tau_of_x(const C& x){
  // Fixed decimal Tau of owner W8, not re-derived Fatou coefficients.
  const C A3(decimal("-3.32788058725899"),decimal("-0.681896765229739"));
  const C A2(decimal("0.536700186091055"),decimal("1.61148875597112"));
  const C A1(decimal("-0.135079834899795"),decimal("0.153567697075599"));
  const C KA(decimal("1.81162096236788"),decimal("0.0896653995437725"));
  C inv=C(1)/x;
  return ((A3*inv+A2)*inv+A1)*inv+KA*clog_right_halfplane(x);
}
C rotation_3pi8(){
  I two(2),s2=sqrt_i(two);
  I cost=sqrt_i(two-s2)/I(2),sint=sqrt_i(two+s2)/I(2);
  return C(cost,sint);
}
// max(M, B): exact integer lower bound on unknown value on domain D0.
Z max_z(const Z&a,const Z&b){return std::max(a,b);}
I cube(const I&i){return i*i*i;}
Z positive_sup(const I& i){if(i.h<0)throw std::domain_error("negative radius upper");return i.h;}
struct TubeBound {
  Z M; Z first_lower,second_lower; Z rho2_lower; Z theta_upper;
  bool used_tau=false,used_local_angle=false;
};
class ForwardTube {
  C c,xstar,tau_star,rot; I second_star,cwall,pi;
public:
  explicit ForwardTube(const C&cc):c(cc),xstar(::xstar(c)),tau_star(tau_of_x(xstar)),rot(rotation_3pi8()),pi(pi_interval()) {
    second_star=(rot*tau_star).re; cwall=second_star-decimal("0.15");
    if(cwall.l<=0 || second_star.l<=0)throw std::domain_error("cwall not proven positive");
  }
  TubeBound upper(const C& X)const{
    // X is the entire computed base enclosure, NOT assumed subset D0.
    // For any x in X intersect D0, first>1 and second>cwall.
    Z fl=SCALE,sl=cwall.l;bool tau_used=false;
    try {
      C q=tau_of_x(X);
      I first=q.re-tau_star.re+I::rat(5,4);
      I second=(rot*q).re;
      fl=max_z(fl,first.l);sl=max_z(sl,second.l);
      tau_used=true;
    }catch(const std::domain_error&){ /* valid global D0 floors; do not exclude tile */ }
    if(fl<=0 || sl<=0)throw std::domain_error("M denominator nonpositive");
    C xi=c*X;
    I rho2=sq(xi.re)+sq(xi.im);
    if(rho2.l<=0)throw std::domain_error("cannot exclude xi=0 in X; retain tile");
    // Only the upper angular endpoint is needed: Im(alpha)<0.
    // On D0: -pi/5<arg xi<3*pi/10. If local atan cannot be proved,
    // the full D0 chart upper bound remains rigorous.
    Z theta_hi=(I::rat(3,10)*pi).h;bool local_angle=false;
    try{
      I local=atan2_right_halfplane(xi);
      theta_hi=std::min(theta_hi,local.h);
      local_angle=true;
    }catch(const std::domain_error&){}
    // α = -102/19 - (16 sqrt3/19)i; ξ*=0.4 exp(iπ/6).
    // |xi^α|/|xi*^α| = exp[-(51/19) log(|xi|²/0.16)
    //                                  +(16sqrt3/19)(arg xi -π/6)].
    I ratio2=rho2/I::rat(4,25);
    I lograd=log_positive_interval(ratio2);
    I bh=I::rat(16,19)*sqrt_i(I(3));
    I exponent=I::rat(-51,19)*lograd + bh*(I::point(theta_hi)-pi/I(6));
    I e=exp_c(C(exponent)).re;
    // First(x*)=1.25; second(x*)=second_star. All factors nonnegative.
    I M=I::rat(1,500)*e*cube(I::rat(5,4)/I::point(fl))*cube(second_star/I::point(sl));
    if(M.h<0)throw std::domain_error("invalid M");
    return {M.h,fl,sl,rho2.l,theta_hi,tau_used,local_angle};
  }
  const C& at_start()const{return xstar;}
  const I& at_start_second()const{return second_star;}
};

struct Stats{size_t active=0,done=0,unresolved=0,discarded=0,kept=0,empty=0;
  Z maxM=0,minM=0, maxD=0;std::optional<C> hull;};
void add_hull(std::optional<C>&h,const C&b){
  if(!h){h=b;return;}h->re.l=std::min(h->re.l,b.re.l);h->re.h=std::max(h->re.h,b.re.h);
  h->im.l=std::min(h->im.l,b.im.l);h->im.h=std::max(h->im.h,b.im.h);
}
std::string outdec(const Z& v){return ::dec(v);}
Stats contract(Data dat,size_t grid,bool verbose,const std::string& detail_path){
  ForwardTube TB(dat.c);
  auto ts=tiles(grid);Stats S;S.active=ts.size();S.minM=0;
  std::ofstream details(detail_path);
  if(!details)throw std::runtime_error("cannot open tile details");
  details<<"tile center_re_256 center_im_256 radius_256 M1_256 base_re_lo_256 base_re_hi_256 base_im_lo_256 base_im_hi_256 action\n";
  if(verbose){std::cerr<<"TUBE_SECOND_STAR_INTERVAL=" << outdec(TB.at_start_second().l) << "," << outdec(TB.at_start_second().h)<<"\n";}
  for(size_t n=0;n<ts.size();++n){const Disk& tile=ts[n];
    try{
      auto F=direct6(ce::from_lift(TB.at_start(),tile,dat.phi));
      State r=ce::lifted_readout(F,dat.phi);
      TubeBound B=TB.upper(r.a.v);
      ++S.done;
      details<<n<<' '<<tile.c.re.l<<' '<<tile.c.im.l<<' '<<tile.r<<' '<<B.M<<' '
             <<r.a.v.re.l<<' '<<r.a.v.re.h<<' '<<r.a.v.im.l<<' '<<r.a.v.im.h<<' ';
      S.maxM=std::max(S.maxM,B.M);if(S.minM==0 || B.M<S.minM)S.minM=B.M;
      // b is a nonzero dyadic point from the centre of a fresh point-orbit tangent.
      auto P=direct6(ce::from_lift(TB.at_start(),Disk(tile.c,0),dat.phi));
      State p=ce::lifted_readout(P,dat.phi);
      C slope=mid(p.b.d);
      if(ce::abs_lower(slope)<=0) throw std::domain_error("zero slope, retain");
      Disk necessary=necessary_disk(tile,p.b.v,r.b.d,slope,B.M);
      C bv=tile.box(),nb=necessary.box();auto hit=intersection(bv,nb);
      if(!hit){details<<"DISCARDED\n";++S.discarded;continue;}
      details<<"KEPT\n";add_hull(S.hull,*hit);++S.kept;
      if(verbose && n<8)
        std::cerr<<"TILE "<<n<<" M="<<outdec(B.M)<<" D="<<outdec(ce::abs_upper(r.b.d-slope))
                 <<" FL="<<outdec(B.first_lower)<<" SL="<<outdec(B.second_lower)
                 <<" T="<<B.used_tau<<" A="<<B.used_local_angle<<"\n";
    }catch(const std::domain_error& e){++S.unresolved;add_hull(S.hull,tile.box());
      details<<n<<' '<<tile.c.re.l<<' '<<tile.c.im.l<<' '<<tile.r<<" NA NA NA NA NA UNRESOLVED\n";
      if(verbose && S.unresolved<=6)std::cerr<<"UNRESOLVED tile="<<n<<" reason="<<e.what()<<"\n";
    }
  }
  if(!S.hull)throw std::domain_error("EMPTY COVER: inconsistent with conditional existing-graph use; no certificate");
  return S;
}
} // namespace f1

int main(int argc,char** argv){
  if(argc!=4){std::cerr<<"Usage: real_f1_tube TRANSFER GRID(8|10|16) TILE_DETAILS_OUTPUT\n";return 64;}
  try {
    unsigned grid=std::stoul(argv[2]);if(grid!=8&&grid!=10&&grid!=16)throw std::invalid_argument("grid=8,10,16 only");
    Data data=read_data(argv[1]);
    // Analytic-constant interval controls. These are local arithmetic assertions,
    // not a proof that source JSON midpoint strings contain the exact a_k.
    auto P=f1::pi_interval();
    if(!(P.l> Z(3)*SCALE && P.h< Z(4)*SCALE))throw std::runtime_error("pi range fail");
    f1::ForwardTube tb(data.c);auto B=tb.upper(tb.at_start());
    if(B.M < SCALE/600 || B.M > SCALE/400)throw std::runtime_error("initial tube normalization fail");
    f1::Stats stats=f1::contract(data,grid,true,argv[3]);
    std::cout<<"METHOD=primitive_per_T; stage1_real_M; status=SESSION_CONDITIONAL\n";
    std::cout<<"grid active done unresolved discarded kept M_min M_max hull_radius\n";
    std::cout<<grid<<' '<<stats.active<<' '<<stats.done<<' '<<stats.unresolved<<' '<<stats.discarded<<' '<<stats.kept
             <<' '<<f1::outdec(stats.minM)<<' '<<f1::outdec(stats.maxM)<<' '
             <<(stats.hull?f1::outdec(enclosing_disk(*stats.hull).r):"EMPTY")<<"\n";
    std::cout<<"NO_CERTIFICATE; requires graph/seed/hypotheses, no 3c-b or jump claim\n";
    return stats.unresolved?2:0;
  } catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<"\n";return 2;}
    catch(const std::exception&e){std::cerr<<"INPUT_FAIL: "<<e.what()<<"\n";return 3;}
}
