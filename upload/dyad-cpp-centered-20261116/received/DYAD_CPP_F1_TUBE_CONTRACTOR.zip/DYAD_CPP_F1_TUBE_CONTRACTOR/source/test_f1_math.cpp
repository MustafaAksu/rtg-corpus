// [SESSION] Bounded arithmetic controls for standalone first-step M(X∩D0).
#define main f1_main_renamed
#include "real_f1_tube.cpp"
#undef main
int main(int argc,char**argv){
  if(argc!=2)return 64;
  try {
    using namespace dyad;
    I pi=f1::pi_interval();
    if(!(pi.l>I::rat(314159,100000).h && pi.h<I::rat(314160,100000).l))throw std::runtime_error("pi interval");
    I a=f1::atan_interval(I::rat(1,2));
    if(!(a.l>I::rat(46,100).h && a.h<I::rat(47,100).l))throw std::runtime_error("atan interval");
    I lg=f1::log_positive_interval(I::rat(1,2));
    if(!(lg.l>I::rat(-70,100).h && lg.h<I::rat(-69,100).l))throw std::runtime_error("log interval");
    Data d=read_data(argv[1]);f1::ForwardTube TB(d.c);
    auto B=TB.upper(TB.at_start());
    if(!(B.M > I::rat(199,100000).h && B.M < I::rat(201,100000).l))throw std::runtime_error("normalized Rstar");
    std::cout<<"F1_UNIT PASS pi atan log Rstar; negative input path checked separately; SESSION\n";
    return 0;
  }catch(const std::exception&e){std::cerr<<"F1_UNIT FAIL: "<<e.what()<<"\n";return 1;}
}
