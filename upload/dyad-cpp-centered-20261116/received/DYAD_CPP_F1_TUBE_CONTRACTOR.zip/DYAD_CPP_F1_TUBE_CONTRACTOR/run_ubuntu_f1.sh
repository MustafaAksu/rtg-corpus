#!/usr/bin/env bash
# SESSION-only first-block bound and contractor development run.
# No production, no certification, no release or repo writes.
set -euo pipefail
if [[ $# -ne 4 ]]; then
  echo 'Usage: bash run_ubuntu_f1.sh REPO_ROOT V2_SOURCE_DIR BENCHMARK_SOURCE_DIR EMPTY_OUTPUT_DIR' >&2
  exit 64
fi
repo=$(cd -- "$1" && pwd)
v2=$(cd -- "$2" && pwd)
bench=$(cd -- "$3" && pwd)
out=$4
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -e "$out" ]]; then
  if [[ ! -d "$out" || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output directory must be new or empty' >&2
    exit 64
  fi
else
  mkdir -p -- "$out"
fi
out=$(cd -- "$out" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/new_package_checks.txt"
(cd "$v2" && sha256sum -c SHA256SUMS.txt) > "$out/v2_package_checks.txt"
(cd "$bench" && sha256sum -c SHA256SUMS.txt) > "$out/benchmark_package_checks.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
if ! printf '%s  %s\n' "$expected" "$source_json" | sha256sum -c -; then
  echo 'STOP: pinned source Stage-2 JSON SHA mismatch' >&2
  exit 4
fi
{
  printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
  printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
  g++ --version | head -1
  python3 --version
  printf 'SOURCE_SHA256=%s\n' "$expected"
  printf 'STATUS=SESSION; conditional on source midpoint enclosures and sectorial graph hypotheses; not 3c-b\n'
} > "$out/environment.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" --out "$out/phi40_outer_256.txt" > "$out/import.log"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic \
  -I "$v2/source" -I "$bench" \
  "$src/source/real_f1_tube.cpp" -o "$out/real_f1_tube"
# Negative controls: wrong data and wrong CLI must fail loudly.
set +e
g++ -std=c++17 -O2 -Wall -Wextra -pedantic \
  -I "$v2/source" -I "$bench" \
  "$src/source/test_f1_math.cpp" -o "$out/test_f1_math"
"$out/test_f1_math" "$out/phi40_outer_256.txt" > "$out/f1_math_unit.txt"
# Sanitizer is limited to the bounded arithmetic gates, not the costly full grid.
g++ -std=c++17 -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined \
  -I "$v2/source" -I "$bench" \
  "$src/source/test_f1_math.cpp" -o "$out/test_f1_math_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  timeout -k 5s 30s "$out/test_f1_math_sanitized" "$out/phi40_outer_256.txt" > "$out/sanitizer_unit.txt" 2> "$out/sanitizer_unit.stderr.txt"
"$out/real_f1_tube" > "$out/negative_cli.txt" 2>&1
neg_cli=$?
"$out/real_f1_tube" "$source_json" 8 "$out/invalid_data_tiles.tsv" > "$out/negative_transfer.txt" 2>&1
neg_input=$?
set -e
if [[ "$neg_cli" != 64 || "$neg_input" != 3 ]]; then
  echo "STOP: negative controls failed ($neg_cli,$neg_input)" >&2
  exit 1
fi
failed=0
for grid in 8 10; do
  set +e
  timeout -k 5s 160s "$out/real_f1_tube" "$out/phi40_outer_256.txt" "$grid" "$out/details_grid_${grid}.tsv" \
      > "$out/grid_${grid}.stdout.txt" 2> "$out/grid_${grid}.stderr.txt"
  status=$?
  set -e
  if [[ "$status" != 0 ]]; then
    printf 'INCONCLUSIVE grid=%s exit=%s\n' "$grid" "$status" | tee -a "$out/summary.txt"
    failed=1
    continue
  fi
  grep -A1 '^grid active done unresolved' "$out/grid_${grid}.stdout.txt" | tail -1 | tee -a "$out/summary.txt"
  # Independent raw T^6 and tube-radius sampling; NOT a proof.
  if ! python3 "$src/source/check_m_samples.py" \
      --transfer "$out/phi40_outer_256.txt" \
      --tiles "$out/details_grid_${grid}.tsv" > "$out/oracle_grid_${grid}.txt"; then
    printf 'INCONCLUSIVE numerical independent spot-check grid=%s\n' "$grid" | tee -a "$out/summary.txt"
    failed=1
  fi
done
(
  cd "$out"
  find . -maxdepth 1 -type f ! -name 'RUN_SHA256SUMS.txt' ! -name 'real_f1_tube' -printf '%f\0' | \
   sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt
)
printf 'STATUS=SESSION; no 3c-b, no curve existence assertion, no point jump\n'
if [[ $failed == 1 ]]; then exit 2; fi
printf 'PASS: conditional first-F-block bounds completed on both grids (SESSION only)\n'
