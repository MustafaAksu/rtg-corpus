# Local approximate input regression (SESSION only)

This file reports **not** the actual Stage 2 JSON import. It uses 18-significant-digit rounded pilot coefficients and a per-component padding of 1e-15. The intended main run imports 80-digit source data on the PI's Ubuntu server, after SHA-256 checks.

| Grid | Active | Evaluated | Unresolved | Excluded | Retained | M_min | M_max | Outer hull radius |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 8 | 60 | 60 | 0 | 44 | 16 | 2.708876e-04 | 2.987379e-04 | 1.526195e-03 |
| 10 | 96 | 96 | 0 | 80 | 16 | 2.516209e-04 | 2.783942e-04 | 1.198130e-03 |
| 16 | 224 | 224 | 0 | 208 | 16 | 2.270769e-04 | 2.500506e-04 | 8.404199e-04 |

Independent high-precision sampling against direct raw T^6, using the representative midpoint constants: 8-grid 352/352 eligible samples and 10-grid 562/562 samples satisfied `R0(x1) <= M1_i`. The largest ratios were 0.7115855 and 0.7645096, respectively; *sampling does not establish the universal bound*. Full universal validity follows, conditional on correct imported source enclosures, from directed interval calculations and inequalities documented in `README.md`.

The new C++ arithmetic gate test (pi, atan, log, Rstar) passed in an optimized build and with AddressSanitizer + UndefinedBehaviorSanitizer. A full sanitizer grid run was not completed (its computational cost is high); this is a non-blocking limitation for this exploratory stage, not an asserted PASS.
