# DYAD OPEN 20 — one-step C++ tube bound and conditional fibre contractor

**Status:** [SESSION] exploratory implementation and mathematical argument, not adopted, not a stage 3c-b production/replay run, not a certified point jump.

## Sources and identity

- Governing scientific owner: `dyad-v6.4.24` plus release record. Analytical definitions: `records/dyad/DYAD_OPEN20_AN_STAGE3C_A_PROOF_RECORD.md` §§1, 4–5, 9–10, 12–13 (read as targeted sections); working design: stage-3b design §3; owner numerical scale note: PR #301 head `3de7ab633e3f9fad3c11cefa38656aaf9818df2c` §3.5.
- Transfer: `evidence/dyad/open20-an/stage2/scout_N216_dps840.json`, SHA-256 **`6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`**. The unchanged V2 `import_phi40.py` requires this exact SHA before writing 39 coefficient and one `c` boxes.
- Existing, unchanged C++ libraries: `DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2` and `DYAD_CPP_FORWARD_METHOD_BENCHMARK`. The new source includes the benchmark's `bench.cpp` without changing its arithmetic, coverage, or `direct6` implementation.
- **Input limitation:** Stage 2 JSON stores ~80-significant-digit displayed midpoint strings and *separate reported ball radii*, not raw Arb balls. The existing transfer uses component padding `1e-65` (coefficients) / `1e-32` (`c`); owner acceptance of the source-printing interpretation remains required for mathematical certification. A successful SHA check is not a mathematical proof of these outer inputs.

## One-step mathematical bound (auditable)

`ξ*=0.4 exp(iπ/6)`, `x*=ξ*/c`, `α=-102/19-(16√3/19)i`, and the Stage 3c-a **exact decimal** coefficients define

`τ(x)=A3/x³+A2/x²+A1/x+κ Log(x)` on the principal branch. Let

`u(x)=Re τ(x)-Re τ(x*)+1.25`, `v(x)=Re(exp(3πi/8)τ(x))`, `v*=v(x*)`, `cw=v*-0.15>0`.

For each complete first-block base enclosure `X`, the implementation computes rigorous lower bounds

`L_u=max(1, inf_X u)` (or 1 when its log cannot be safely evaluated),
`L_v=max(cw_lower, inf_X v)` (or cw_lower when unavailable).

These hold for every `x in X intersect D0` because `u>1`, `v>cw` on `D0`. In the same intersection, `arg ξ` lies in the owner chart sector `(-π/5, 3π/10)`, and `|ξ|²` has a positive lower bound from the entire box `cX`. Taking the minimum of the **local** angular upper bound (if certified) and `3π/10` gives `θ_+`. Then

```
|ξ^α|/|ξ*^α|
= exp( -(51/19) log(|ξ|² / (4/25))
       +(16√3/19)(arg ξ - π/6) ).
```

The upper endpoint of this exponential interval is `E_+`. Finally,

```
M(X) = 0.002 · E_+ · (1.25/L_u)^3 · (v*_upper/L_v)^3
>= sup_{x in X intersect D0} R0(x).
```

`ε` cancels in the ratio since `R0(x*)=0.002`. The code uses exact 256-bit dyadic integer endpoint arithmetic with directed rounding, `π=16 atan(1/5)-4 atan(1/239)`, the alternating `atan` series with a first-omitted-term bound, the `atanh` expansion of the real logarithm with an explicit geometric-tail bound, the algebraic rotation `exp(3πi/8)`, and the existing residual Taylor enclosure for real exponentiation. Any unbounded or undefined case is **retained**, not discarded.

A direct C1–C2 necessary-condition contractor then uses `f(d)=d_1(d)`, a centre evaluation, the derivative enclosure over the **entire** original tile disk, and `M(X)`. The logical premise that the sectorial solution follows `D0` and obeys `|d1|<=R0` comes from the **conditional** owner tube/seed argument; the computed one-step radius and exclusion are not an unconditional proof of the curve.

## Ubuntu command

After extracting the new package as `/root/DYAD_CPP_F1_TUBE_CONTRACTOR`, retaining the existing V2 and benchmark directories:

```bash
bash /root/DYAD_CPP_F1_TUBE_CONTRACTOR/run_ubuntu_f1.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/dyad-f1-tube-run
```

The last output directory must be new or empty. The script checks all three package manifests and the Stage 2 SHA, imports the coefficients afresh, builds the C++17 program, runs bounded arithmetic gate tests including a sanitizer build, 60- and 96-tile first-block comparisons, negative controls, and an **independent mpmath sample-only check**. It writes `summary.txt`, per-grid detail TSVs, and `RUN_SHA256SUMS.txt`. `exit 0` means the **SESSION** bounds/contractor evaluations completed, not a certificate; `exit 2` means unresolved/timeout; `exit 4` means source-hash mismatch. `gcc/g++` with AddressSanitizer and UndefinedBehaviorSanitizer, Boost headers, Python 3 + mpmath, `sha256sum`, and `timeout` are required.

## Prior local approximate test — NOT pinned real source

With deliberately approximate 18-significant-digit `a_k,c` and ±1e-15 component pads (NOT a transfer from the stage-2 JSON), the direct C++ candidate screen produced:

| Grid | Total active | Evaluated | Unresolved | Excluded | Retained | M1 min–max | Outer hull radius |
|---|---:|---:|---:|---:|---:|---|---:|
| 8×8 | 60 | 60 | 0 | 44 | 16 | 2.708876e-4–2.987379e-4 | 1.526195e-3 |
| 10×10 | 96 | 96 | 0 | 80 | 16 | 2.516209e-4–2.783942e-4 | 1.198130e-3 |
| 16×16 (optional) | 224 | 224 | 0 | 208 | 16 | 2.270769e-4–2.500506e-4 | 8.404199e-4 |

An independently coded mpmath direct-raw-`T^6` sampler checked `R0(x1)<=M(X1)` on 352/352 and 562/562 eligible sample locations for the first two grids. These are **non-rigorous samples**, not the mathematical proof or an independent exact-arithmetic engine. The **real, checksum-pinned 80-digit source** results must be collected on the PI's Ubuntu machine. Local proxy fixtures are intentionally omitted from the delivery ZIP to prevent them being mistaken for source-backed evidence.

## Scientific limitations / acceptance

No candidate is discarded unless the one-step necessary-condition disk is **provably disjoint** from the tile; unresolved tiles are retained. Final hull radius may overestimate the true candidate set and is not a uniqueness/existence result. The benchmark does not check `D0` membership of arbitrary orbits; it uses the conditional fact that the *true* sectorial candidate lies in `D0`, and bounds the radius over `X intersect D0`. The C++ phi40 transfer is conditional on midpoint-display semantics. No inverse `G`, no entire 334-block leg, no two-disc separation, no new theorem, no change to B-an/B-6.
