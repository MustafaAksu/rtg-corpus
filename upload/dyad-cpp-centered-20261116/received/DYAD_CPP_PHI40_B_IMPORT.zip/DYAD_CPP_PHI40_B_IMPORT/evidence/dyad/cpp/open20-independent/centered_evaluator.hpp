// SESSION / development evaluator responding to PR #288 F1.
// Independent six-step, centred mean-value enclosure. No tube or inverse adapter.
// Uses the reviewed dyadic arithmetic and contractor, not Python campaign code.
#pragma once
#ifndef DYAD_CORE_NO_MAIN
#define DYAD_CORE_NO_MAIN
#endif
#include "independent_core.cpp"

namespace dyad::centered {
using Vec = std::array<C,2>;
using Mat = std::array<std::array<C,2>,2>;
using Disks = std::array<Disk,2>;

Z ceil_sqrt(const Z& x) {
    Z r=isqrt(x); if(r*r<x) ++r; return r;
}
// Euclidean modulus bounds at the exact fixed dyadic scale.
Z abs_upper(const C& z) { Z a=au(z.re),b=au(z.im); return ceil_sqrt(a*a+b*b); }
Z abs_lower(const C& z) { Z a=al(z.re),b=al(z.im); return isqrt(a*a+b*b); }
Z product_upper(const Z& a,const Z& b) {
    if(a<0||b<0) throw std::invalid_argument("nonnegative bounds required");
    return cd(a*b,SCALE);
}
C divide_integer(const C& a,long k) {
    if(k<=0) throw std::invalid_argument("positive divisor required");
    return C(a.re/I(k),a.im/I(k));
}
Disk ball(const C& box) { C c=mid(box); return Disk(c,abs_upper(box-c)); }
Disk add(const Disk&a,const Disk&b) {
    Disk q=ball(a.c+b.c); q.r+=a.r+b.r; return q;
}
Disk multiply(const Disk&a,const Disk&b) {
    Disk q=ball(a.c*b.c);
    q.r+=product_upper(abs_upper(a.c),b.r)+product_upper(abs_upper(b.c),a.r)+product_upper(a.r,b.r);
    return q;
}

// E = exp(z)-1-z, E' = exp(z)-1, S = sin(z)-z, S' = cos(z)-1.
// The linear terms are never inserted and then subtracted as independent boxes.
// E1 bounds all omitted terms after degree 160 by the exponential majorant.
struct ExpResidual { C value,derivative; };
struct SinResidual { C value,derivative; };
I tail_bound(const I& M,const I& scalar,long N) {
    return (scalar*M/I(N+1))/(I(1)-M/I(N+2));
}
ExpResidual exp_residual(const C& z) {
    constexpr long N=160;
    const I M=I::point(norm_upper(z));
    if(M.h>Z(8)*SCALE) throw std::domain_error("residual exponential range budget");
    C t(1),v(0),d(0); I scalar(1);
    for(long k=1;k<=N;++k) {
        t=divide_integer(t*z,k); scalar=scalar*M/I(k);
        d=d+t; if(k>=2) v=v+t;
    }
    I e=tail_bound(M,scalar,N);
    return {inflate(v,e.h),inflate(d,e.h)};
}
SinResidual sin_residual(const C& z) {
    constexpr long N=160;
    const I M=I::point(norm_upper(z));
    if(M.h>Z(8)*SCALE) throw std::domain_error("residual sine range budget");
    C t(1),v(0),d(0); I scalar(1);
    for(long k=1;k<=N;++k) {
        t=divide_integer(t*z,k); scalar=scalar*M/I(k);
        if(k>=3 && k%2) v = (k%4==1)?v+t:v-t;
        if(k>=2 && k%2==0) d = (k%4==0)?d+t:d-t;
    }
    I e=tail_bound(M,scalar,N);
    return {inflate(v,e.h),inflate(d,e.h)};
}

// Holomorphic two-variable first jet in z,w. Variables are independent complex
// variables; no conjugacy constraint is imposed on the input state.
struct Jet2 { C v; Vec d; };
Jet2 plus(const Jet2&a,const Jet2&b) { return {a.v+b.v,{a.d[0]+b.d[0],a.d[1]+b.d[1]}}; }
Jet2 minus(const Jet2&a,const Jet2&b) { return {a.v-b.v,{a.d[0]-b.d[0],a.d[1]-b.d[1]}}; }
Jet2 times(const C&c,const Jet2&a) { return {c*a.v,{c*a.d[0],c*a.d[1]}}; }
Jet2 divided(const Jet2&a,const C&c) { return {a.v/c,{a.d[0]/c,a.d[1]/c}}; }
Jet2 exp_residual_j(const Jet2& a) {
    auto e=exp_residual(a.v); return {e.value,{e.derivative*a.d[0],e.derivative*a.d[1]}};
}
Jet2 sin_residual_j(const Jet2& a) {
    auto e=sin_residual(a.v); return {e.value,{e.derivative*a.d[0],e.derivative*a.d[1]}};
}
struct Chart {
    C omega,lambda,ii3;
    Chart():omega(I::rat(-1,2),sqrt_i(I(3))/I(2)),lambda(C(1)+omega),ii3(I(0),sqrt_i(I(3))){}
};
struct Evaluation { Vec value; Mat jacobian; };
Evaluation block(const Vec& input) {
    static const Chart k;
    Jet2 z{input[0],{C(1),C(0)}},w{input[1],{C(0),C(1)}};
    for(int t=0;t<6;++t) {
        Jet2 eta=divided(minus(z,w),k.ii3);
        Jet2 rho=divided(plus(plus(z,w),eta),C(2));
        Jet2 e=exp_residual_j(rho),s=sin_residual_j(eta);
        // T_z = lambda*z + omega*(exp(rho)-1-rho) - lambda*(sin(eta)-eta).
        Jet2 zp=minus(plus(times(k.lambda,z),times(k.omega,e)),times(k.lambda,s));
        Jet2 wp=minus(plus(times(conj(k.lambda),w),times(conj(k.omega),e)),times(conj(k.lambda),s));
        z=std::move(zp); w=std::move(wp);
    }
    return {{z.v,w.v},{z.d,w.d}};
}

struct Flow { Disks state; Disks tangent; };
Flow advance(const Flow& input) {
    Vec boxes{input.state[0].box(),input.state[1].box()};
    Vec centres{input.state[0].c,input.state[1].c};
    // The Jacobian is bounded on a rectangle containing the WHOLE input
    // polydisc, not on its midpoint. F is entire, and that polydisc is convex.
    Evaluation whole=block(boxes),centre=block(centres);
    Disks out{ball(centre.value[0]),ball(centre.value[1])};
    Disks v{Disk(C(0),0),Disk(C(0),0)};
    for(size_t i=0;i<2;++i) for(size_t j=0;j<2;++j) {
        out[i].r+=product_upper(abs_upper(whole.jacobian[i][j]),input.state[j].r);
        v[i]=add(v[i],multiply(ball(whole.jacobian[i][j]),input.tangent[j]));
    }
    return {out,v};
}

Flow from_raw(const Vec& raw,const Vec& tangent) {
    State q=raw_to_zw({J(raw[0],tangent[0]),J(raw[1],tangent[1])});
    return {{ball(q.a.v),ball(q.b.v)},{ball(q.a.d),ball(q.b.d)}};
}
State raw_readout(const Flow& f) {
    return zw_to_raw({J(f.state[0].box(),f.tangent[0].box()),J(f.state[1].box(),f.tangent[1].box())});
}
Flow from_lift(const C& x,const Disk& d,const std::vector<C>& phi) {
    // x is independent of the initial fibre parameter d. Polynomial intervals
    // enclose fixed coefficients; their generation is NOT part of this kernel.
    J xx(x),dd(d.box(),C(1)); J w=polynomial(phi,xx)+xx*xx*dd;
    return {{ball(x),ball(w.v)},{Disk(C(0),0),ball(w.d)}};
}
State lifted_readout(const Flow& f,const std::vector<C>& phi) {
    J z(f.state[0].box(),f.tangent[0].box()),w(f.state[1].box(),f.tangent[1].box());
    if(abs_lower(z.v)<=0) throw std::domain_error("lift pole not excluded");
    return {z,(w-polynomial(phi,z))/(z*z)};
}
// No R_j call exists here. A future necessary-condition adapter must prove
// full-base membership in D_j, including sector/log/pole/wedge checks (F2).
// No proof of membership -> no tube bound -> retain/subdivide, never exclude.
} // namespace dyad::centered
