"""Cheap local controls; no source identity is bypassed by the production CLI."""
import importlib.util,pathlib,json,tempfile,hashlib,sys
p=pathlib.Path(__file__).with_name('import_phi40.py')
s=importlib.util.spec_from_file_location('transfer',p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
checks=0
def ck(t):
 global checks
 assert t
 checks+=1
ck(m.fraction('1.25e-2') == m.Fraction(1,80))
ck(m.endpoints('0',m.Fraction(1,10**65))[0] < 0 < m.endpoints('0',m.Fraction(1,10**65))[1])
ck(m.floor_scaled(m.Fraction(-1,3))*3 <= -m.SCALE)
ck(m.ceil_scaled(m.Fraction(-1,3))*3 >= -m.SCALE)
with tempfile.TemporaryDirectory() as td:
 t=pathlib.Path(td);source=t/'fixture.json';out=t/'outer.txt'
 j={'all_pass':True,'args':{'N':216,'dps':840},'info':{'coefficients':{str(i):['1.23456789012345678901234567890123456789012345678901234567890e-7','-1.0e-7'] for i in range(2,41)},'ball_radius_a_k':{str(i):'1e-800' for i in range(2,41)},'c_pil':['0.2569865578799318588169076556597560705731','0.3830143551608473660816508425826991073407']}}
 source.write_text(json.dumps(j)); sha=hashlib.sha256(source.read_bytes()).hexdigest()
 real=m.EXPECTED_SHA
 try:
  m.EXPECTED_SHA=sha
  sys.argv=['test','--source',str(source),'--out',str(out)]
  m.main(); lines=out.read_text().splitlines()
  ck(len(lines)==43 and lines[-1]=='END')
  ck(lines[1]==sha)
  k,lo,hi,li,ui=map(int,lines[2].split())
  ck(k==2 and lo<=m.floor_scaled(m.fraction(j['info']['coefficients']['2'][0]))<=hi)
  ck(li<=m.floor_scaled(m.fraction(j['info']['coefficients']['2'][1]))<=ui)
  try:m.main();blocked=False
  except SystemExit:blocked=True
  ck(blocked)
 finally: m.EXPECTED_SHA=real
print(f'{checks} controlled transfer/rounding tests PASS; actual source identity requires stage2 source file')
