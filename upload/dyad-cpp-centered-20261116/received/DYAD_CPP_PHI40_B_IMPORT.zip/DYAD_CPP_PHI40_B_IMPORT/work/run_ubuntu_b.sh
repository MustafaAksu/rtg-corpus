#!/usr/bin/env bash
# SESSION-only phi40 import and bounded real-input forward feasibility probe.
set -euo pipefail
repo=${1:?Usage: run_ubuntu_b.sh REPO_DIRECTORY EMPTY_OUTPUT_DIRECTORY}
out=${2:?Usage: run_ubuntu_b.sh REPO_DIRECTORY EMPTY_OUTPUT_DIRECTORY}
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd -- "$repo" && pwd)
if [[ -e $out ]]; then
  if [[ ! -d $out || -n $(ls -A -- "$out") ]]; then
    echo 'Refusing to use nonempty output path.' >&2; exit 64
  fi
else mkdir -p -- "$out"; fi
out=$(cd -- "$out" && pwd)
file="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
actual=$(sha256sum "$file" | cut -d' ' -f1)
if [[ $actual != "$expected" ]]; then
  echo "STOP: input mismatch $actual" >&2;exit 4
fi
{
  date -u '+UTC=%Y-%m-%dT%H:%M:%SZ'
  git -C "$repo" rev-parse HEAD
  git -C "$repo" status --porcelain -- evidence/dyad/open20-an/stage2/scout_N216_dps840.json
  g++ --version | head -n 1
  python3 --version
} > "$out/environment.txt"
python3 "$src/import_phi40.py" --source "$file" --out "$out/phi40_outer_256.txt" > "$out/import.log"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -I "$src/../evidence/dyad/cpp/open20-independent" \
  "$src/real_phi40_forward_probe.cpp" -o "$out/real_phi40_forward_probe"
set +e
"$out/real_phi40_forward_probe" --development-probe "$out/phi40_outer_256.txt" "$out/forward.tsv" > "$out/probe.log" 2>&1
rc=$?
set -e
printf 'exit=%d\n' "$rc" | tee "$out/status.txt"
printf 'The runner has NO production/replay/certification mode.\n'
cat "$out/probe.log"
# A scientifically useful negative/inconclusive result returns 2 and is retained as evidence.
exit "$rc"
