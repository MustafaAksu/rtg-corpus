// SESSION: B-path source-pinned phi40 transfer; bounded forward feasibility only.
// No tube membership, no invariant graph, no inverse G, no certification or jump assertion.
#include "centered_evaluator.hpp"
#include <fstream>
#include <iomanip>
#include <sstream>
using namespace dyad;
namespace ce = dyad::centered;
static constexpr const char* EXPECTED_SHA="6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e";

Z fullwidth(const C& z) { return std::max(Z(z.re.h-z.re.l),Z(z.im.h-z.im.l)); }
std::string display(const Z& v) {
    std::ostringstream s;
    s<<std::setprecision(9)<<std::scientific<<(v.convert_to<long double>()/SCALE.convert_to<long double>());
    return s.str();
}
Z radius_002() { return cd(SCALE,Z(500)); }
struct Data { std::vector<C> phi; C c; };
Data read_data(const std::string& path) {
    std::ifstream f(path);
    if(!f)throw std::runtime_error("source-pinned coefficients file not found");
    std::string magic,sha;
    if(!(f>>magic>>sha)||magic!="DYAD_PHI40_OUTER_V1"||sha!=EXPECTED_SHA)
        throw std::runtime_error("source identity or format mismatch");
    Data d; d.phi.resize(41,C(0));
    for(int expect=2;expect<=40;++expect) {
        int k=-1; Z rl,rh,il,ih;
        if(!(f>>k>>rl>>rh>>il>>ih)||k!=expect||rl>rh||il>ih)
            throw std::runtime_error("coefficient order or bounds invalid");
        d.phi[k]=C(I(rl,rh),I(il,ih));
    }
    std::string tag,end;Z rl,rh,il,ih;
    if(!(f>>tag>>rl>>rh>>il>>ih>>end)||tag!="C"||end!="END"||rl>rh||il>ih)
        throw std::runtime_error("missing or invalid c interval");
    std::string extra;if(f>>extra)throw std::runtime_error("unexpected input after END");
    d.c=C(I(rl,rh),I(il,ih));
    return d;
}
// Exact xi* = (sqrt(3) + i)/5. x*=xi*/c; sqrt3/c are outer ball enclosures.
C xstar(const C&c) { return C(sqrt_i(I(3))/I(5),I::rat(1,5))/c; }

int main(int argc,char**argv) {
    if(argc!=4||std::string(argv[1])!="--development-probe") {
        std::cerr<<"Usage: real_phi40_forward_probe --development-probe COEFFICIENTS.txt OUTPUT.tsv\n"
                 <<"Not a DYAD production/replay/certification mode.\n";return 64;
    }
    try {
        Data d=read_data(argv[2]);
        C x=xstar(d.c);
        std::ofstream o(argv[3]);if(!o)throw std::runtime_error("output cannot be opened");
        o<<"mode\tstep\tstatus\tbase_width\tdeviation_width\ttangent_width\tstate_radius0\tstate_radius1\tinfo\n";
        bool all=true;
        for(int mode=0;mode<2;++mode) {
            const char* name=mode==0?"point_d0":"whole_initial_fibre";
            int reached=0;
            try {
                Disk initial(C(0),mode==0?Z(0):radius_002());
                ce::Flow flow=ce::from_lift(x,initial,d.phi);
                for(int step=1;step<=20;++step) {
                    flow=ce::advance(flow);
                    auto lifted=ce::lifted_readout(flow,d.phi);
                    reached=step;
                    if(step==1||step==2||step==5||step==10||step==20) {
                        o<<name<<'\t'<<step<<"\tENCLOSED\t"<<display(fullwidth(lifted.a.v))
                         <<'\t'<<display(fullwidth(lifted.b.v))
                         <<'\t'<<display(fullwidth(lifted.b.d))
                         <<'\t'<<display(flow.state[0].r)<<'\t'<<display(flow.state[1].r)
                         <<"\tno_tube_test\n";
                    }
                }
                std::cout<<name<<": completed 20 F blocks; no tube or membership test\n";
            } catch(const std::exception& e) {
                all=false;o<<name<<'\t'<<(reached+1)<<"\tINCONCLUSIVE\tNA\tNA\tNA\tNA\tNA\t"<<e.what()<<'\n';
                std::cout<<name<<": INCONCLUSIVE at step "<<(reached+1)<<": "<<e.what()<<"\n";
            }
        }
        std::cout<<"STATUS "<<(all?"FEASIBILITY_ENCLOSURES":"INCONCLUSIVE")
                 <<"; not a certificate or two-disc test\n";
        return all?0:2;
    } catch(const std::exception& e) { std::cerr<<"INPUT_FAIL "<<e.what()<<'\n';return 3; }
}
