# DYAD OPEN 20 — B-path, source-pinned coefficient import (SESSION)

This is a **development feasibility probe**; it neither certifies stage 3c-b nor makes a claim about the sectorial jump. It does not replicate the Arb coefficient-generation recursion. It imports the Stage 2 owner's printed midpoint data, wraps it in conservative exact dyadic enclosures, and uses the existing independent Boost-centered evaluator.

## Source

- Owner of the mathematical objects: DYAD v6.4.24, proof record §§1, 9, 12–13 (the computations remain SESSION).
- Frozen source: `evidence/dyad/open20-an/stage2/scout_N216_dps840.json`, SHA-256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e` from stage 3c-b manifest.
- `info.coefficients["2"]` through `["40"]`, printed by `stage2_scout.py` using `mid().str(80,radius=False)`; `info.ball_radius_a_k` is *separate* and not embedded in those displayed strings.
- `info.c_pil` is a 40-digit center display. The full original Arb-ball state is **not** preserved in this JSON.

## Representation-level conditions

Under the documented display convention of decimal rounding at the printed precision and the source-reported radii, the importer adds a **conservative absolute ±1e-65 to each real and imaginary coefficient component**, and **±1e-32 to each component of c**. These exceed the printed rounding and source-reported radii for k=2..40. All decimal parsing is exact Python `Fraction(Decimal(...))`; bounds are directed-rounded to integer endpoints divided by 2^256. There is *no* conversion through Python binary float. Printed midpoint accuracy is a **source convention**, not independently reconstructed from exact Arb internals. The importer refuses all unexpected source hashes.

The output is `DYAD_PHI40_OUTER_V1` plus source hash, exactly 39 coefficient boxes and one c box. All coefficient boxes are independent; correlation with exact recursively defined coefficients is dropped.

## Exact point and bounded probe

Use `ξ* = 0.4 exp(iπ/6) = (sqrt(3)+i)/5`, `x*=ξ*/c`, `φ_40=Σ_{k=2}^{40}a_k x^k`, and `d=(w-φ_40(z))/z²`.

Two tests: `d=0` and **the entire** disk `|d| ≤ 0.002` at the input (not subdivision). The existing `centered::advance()` evaluates up to 20 blocks of `F=T^6`; `lifted_readout()` is used for diagnostics. Outputs at k=1,2,5,10,20 retain interval widths and no tube claims. A range refusal or pole issue is logged as **INCONCLUSIVE**, never as exclusion of a sectorial candidate.

**Important**: `d=0` is a reference center, not an invariant curve. The whole-fibre disk is guaranteed to contain the unknown two sectorial values only conditionally on the owner's tube/seeding statements. This probe **does not** evaluate R_j along the orbit, implement `D_j` membership, contract candidates, or identify an inverse branch G.

## Ubuntu CLI

With repository at `/root/rtg-corpus` and this package unpacked to `/root/dyad-phi40-b`:

```sh
bash /root/dyad-phi40-b/work/run_ubuntu_b.sh /root/rtg-corpus /root/dyad-phi40-b-result
```

Requires: `g++` C++17, Boost.Multiprecision headers, Python 3 standard library. An output directory must be nonexistent or empty. Exit `0` = both 20-block enclosures completed; exit `2` = inconclusive, `3` = input parse error, `4` = source mismatch. An exit 0 is **not** a DYAD scientific PASS.

## Next criteria (owner review)

1. Check printed midpoint error and additive radii against the source formatting convention; verify interval inclusion for all 39 coefficients and c independently if possible.
2. Retain input-source identity, generated transfer hash, complete logs, and any INCONCLUSIVE status.
3. For scientific candidate elimination, add rigorous `sup_{X_k∩D_j} R_j` with domain and branch checks (F2 refinement); **do not** assume a box is entirely in D_j.
4. Bound the analytic derivative on the *entire candidate disk* before applying the necessary-condition contractor; unresolved subsets remain.
5. If full-fibre propagation fails, subdivide first without calling the failure a disproof.

The package contains a byte-identical copy of the previously reviewed Boost-centered original ZIP. No canonical DSN or frozen Python code is modified. No production/replay run is authorized by this work.
