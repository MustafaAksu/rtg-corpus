# DYAD OPEN 20 — requested owner review: option (b) transfer

Status: SESSION development input adapter, not a certificate; no claims for B-an/B-6.

**Sources:** DYAD governing `dyad-v6.4.24` (release record), Stage 3c-a proof record §§1, 9, 12–13, Stage 2 `scout_N216_dps840.json` at SHA-256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`, Stage 2 serialization `stage2_scout.py` (`mid().str(80,radius=False)`), prior centered evaluator review PR #288 §7–§8.

## Owner questions

1. Confirm `info.coefficients["2".."40"]` is the correct φ₄₀ branch and matches `Consts.a` and `coefficients(K,40)` branch convention. Its coefficient balls are represented by an 80-digit midpoint display plus `ball_radius_a_k`, **not** by literal decimal coefficients. Is ±1e-65 component padding sufficient for all 39 under this formatting, and is ±1e-32 sufficient for c from `c_pil` (40-digit)? If this cannot be established, keep the import UNVERIFIED rather than claiming exact-bounded coefficients.
2. Independently verify the converter's exact Decimal→Fraction→outward dyadic endpoint map at P=256, including negative values and scientific notation; test source tampering rejection.
3. Check that `x*=(sqrt(3)+i)/(5c)` and `φ₄₀(z)=Σ₂⁴⁰ a_kz^k` match the proof record's `ξ*=0.40e^{iπ/6}` and chart; verify lift input tangent and output `d` readout.
4. Distinguish `d=0` reference trajectory from the true sectorial unknown; full `|d|≤0.002` represents only the starting fiber. No R_j estimates are made at steps 1–20; no elimination occurs. If full-disk evaluation fails, preserve INCONCLUSIVE and permit controlled subdivision later.
5. In a follow-up, implement source-justified `sup_{X_k∩D_j}R_j`, with log branch and true-orbit membership hypotheses; verify the entire candidate disk derivative before any contraction.

**Development acceptance criterion:** source SHA lock passes; coefficient import is shown to contain the source balls; 10/20-block diagnostics on the real branch log exact intervals or an explicit first inconclusive step. This is an algorithmic feasibility checkpoint, not the proof of a point jump.
