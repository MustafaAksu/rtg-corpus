# Request to DYAD owner — scoped C++ fallback review (SESSION)

Please audit the six-primitive centred Jacobian enclosure and error fallback in `source/centered_evaluator.hpp`, and the optional bounded-horizon development runner. The original source-pinned coefficient importer and baseline kernel are unchanged. Check the whole-initial-polydisk inclusion argument, chain matrix product, upward rounding, and preservation of exceptions. The local oracle covers only 65 points in a representative (18-significant-digit) input, not the actual Stage-2 source.

After reviewing, test **the actual frozen Stage-2 input** at the first `F` block on the PI's Ubuntu environment. If the resulting enclosure is valid, record the actual width; any second-step failure is a negative development finding. A real 20/334 step contraction needs a separate tube bound over `X_k intersect D_j` and contractor integration. This record must not be represented as a DYAD point-jump certificate or as closure of B-an/B-6.
