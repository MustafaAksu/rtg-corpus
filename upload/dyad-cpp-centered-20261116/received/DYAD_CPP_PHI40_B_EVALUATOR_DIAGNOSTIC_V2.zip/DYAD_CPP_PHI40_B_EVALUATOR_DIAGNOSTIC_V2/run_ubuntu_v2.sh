#!/usr/bin/env bash
# SESSION: bounded C++ forward-enclosure diagnostic; not certification or replay.
set -euo pipefail
repo=${1:?Usage: bash run_ubuntu_v2.sh REPO_DIR EMPTY_OUTPUT_DIR [HORIZON]}
out=${2:?Usage: bash run_ubuntu_v2.sh REPO_DIR EMPTY_OUTPUT_DIR [HORIZON]}
steps=${3:-1}
case "$steps" in 1|2|5|10|20);; *) echo 'HORIZON must be 1, 2, 5, 10 or 20' >&2; exit 64;; esac
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd -- "$repo" && pwd)
if [[ -e $out ]]; then
  if [[ ! -d $out || -n $(ls -A -- "$out") ]]; then
    echo 'STOP: output directory must be empty.' >&2;exit 64
  fi
else mkdir -p -- "$out";fi
out=$(cd -- "$out" && pwd)
(cd -- "$src" && sha256sum -c SHA256SUMS.txt) > "$out/package_check.log"
f="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
expected=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
actual=$(sha256sum "$f"|cut -d' ' -f1)
if [[ "$actual" != "$expected" ]]; then
 echo "STOP: Stage-2 source hash mismatch: $actual" >&2;exit 4
fi
{
 date -u '+UTC=%Y-%m-%dT%H:%M:%SZ'
 echo "source_SHA256=$actual"
 echo "horizon=$steps"
 g++ --version | head -1
 python3 --version
 git -C "$repo" rev-parse HEAD
 git -C "$repo" status --porcelain -- evidence/dyad/open20-an/stage2/scout_N216_dps840.json
} > "$out/environment.txt"
python3 "$src/source/import_phi40.py" --source "$f" --out "$out/phi40_outer_256.txt" > "$out/import.log"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -I "$src/source" \
 "$src/source/real_phi40_forward_probe.cpp" -o "$out/phi40_probe"
set +e
"$out/phi40_probe" --development-probe "$out/phi40_outer_256.txt" "$out/forward.tsv" \
 --max-steps "$steps" > "$out/probe.log" 2>&1
rc=$?
set -e
printf 'exit=%d\n' "$rc" | tee "$out/status.txt"
cat "$out/probe.log"
echo 'SESSION evaluator only; no D_j membership, R_j, invariant graph, inverse, certificate or point jump.'
exit "$rc"
