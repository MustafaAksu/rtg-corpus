// SESSION research prototype. No DYAD point-jump or certification mode exists.
// Authored from the mathematical definitions, not translated from Python.
// See the design note for provenance, proofs, and the unimplemented adapters.
#include <boost/multiprecision/cpp_int.hpp>
#include <algorithm>
#include <array>
#include <functional>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace dyad {
using Z = boost::multiprecision::cpp_int;
constexpr unsigned PREC = 256;
const Z SCALE = Z(1) << PREC;
Z az(const Z& z) { return z < 0 ? Z(-z) : z; }
Z fd(Z n, Z d) {
    if (d == 0) throw std::domain_error("division by zero");
    if (d < 0) { n = -n; d = -d; }
    Z q = n / d;
    if (n < 0 && n % d != 0) --q;
    return q;
}
Z cd(const Z& n, const Z& d) { return -fd(-n, d); }
Z isqrt(const Z& n) {
    if (n < 0) throw std::domain_error("negative square root");
    if (n == 0) return 0;
    Z x = Z(1) << ((boost::multiprecision::msb(n) + 2) / 2);
    for (;;) { Z y = (x + n / x) / 2; if (y >= x) return x; x = y; }
}

// Endpoints are integers divided by 2^PREC. No floating-point decisions.
struct I {
    Z l, h;
    I() : l(0), h(0) {}
    I(long n) : l(Z(n)*SCALE), h(l) {}
    I(Z a, Z b) : l(std::move(a)), h(std::move(b)) {
        if (l > h) throw std::invalid_argument("reversed interval");
    }
    static I rat(long n, long d) { return I(fd(Z(n)*SCALE,Z(d)), cd(Z(n)*SCALE,Z(d))); }
    static I point(const Z& z) { return I(z,z); }
    bool zero_in() const { return l <= 0 && h >= 0; }
    bool exact() const { return l == h; }
};
I operator+(const I& a,const I& b) { return I(a.l+b.l,a.h+b.h); }
I operator-(const I& a) { return I(-a.h,-a.l); }
I operator-(const I& a,const I& b) { return a + (-b); }
I operator*(const I& a,const I& b) {
    std::array<Z,4> p={Z(a.l*b.l),Z(a.l*b.h),Z(a.h*b.l),Z(a.h*b.h)};
    auto mm=std::minmax_element(p.begin(),p.end());
    return I(fd(*mm.first,SCALE),cd(*mm.second,SCALE));
}
I operator/(const I& a,const I& b) {
    if (b.zero_in()) throw std::domain_error("unresolved denominator");
    std::array<Z,4> lo,hi; unsigned k=0;
    for (const Z& x: {a.l,a.h}) for (const Z& y: {b.l,b.h}) {
        lo[k]=fd(x*SCALE,y); hi[k]=cd(x*SCALE,y); ++k;
    }
    return I(*std::min_element(lo.begin(),lo.end()),*std::max_element(hi.begin(),hi.end()));
}
I sq(const I& a) {
    Z low = a.zero_in() ? Z(0) : std::min(Z(a.l*a.l),Z(a.h*a.h));
    return I(fd(low,SCALE),cd(std::max(Z(a.l*a.l),Z(a.h*a.h)),SCALE));
}
I sqrt_i(const I& a) {
    if (a.l < 0) throw std::domain_error("negative interval");
    Z lo=isqrt(a.l*SCALE), hi=isqrt(a.h*SCALE);
    if (hi*hi != a.h*SCALE) ++hi;
    return I(lo,hi);
}
Z au(const I& a) { return std::max(az(a.l),az(a.h)); }
Z al(const I& a) { return a.zero_in() ? Z(0) : std::min(az(a.l),az(a.h)); }
bool encloses(const I& a,const I& b) { return a.l <= b.l && a.h >= b.h; }

struct C {
    I re,im;
    C() = default;
    C(long n) : re(n),im(0) {}
    C(I r,I i=I(0)) : re(std::move(r)),im(std::move(i)) {}
    bool exact() const { return re.exact() && im.exact(); }
};
C operator+(const C&a,const C&b) { return C(a.re+b.re,a.im+b.im); }
C operator-(const C&a) { return C(-a.re,-a.im); }
C operator-(const C&a,const C&b) { return a+(-b); }
C operator*(const C&a,const C&b) { return C(a.re*b.re-a.im*b.im,a.re*b.im+a.im*b.re); }
C conj(const C&a) { return C(a.re,-a.im); }
C operator/(const C&a,const C&b) {
    I den=sq(b.re)+sq(b.im);
    if (den.l <= 0) throw std::domain_error("complex denominator not bounded away from zero");
    C n=a*conj(b); return C(n.re/den,n.im/den);
}
C mid(const C&a) { return C(I::point(fd(a.re.l+a.re.h,Z(2))),I::point(fd(a.im.l+a.im.h,Z(2)))); }
C inflate(const C&a,const Z&r) {
    if (r < 0) throw std::invalid_argument("negative radius");
    return C(I(a.re.l-r,a.re.h+r),I(a.im.l-r,a.im.h+r));
}
Z norm_upper(const C&a) { return au(a.re)+au(a.im); } // L1 >= Euclidean norm
Z norm_lower(const C&a) { return std::max(al(a.re),al(a.im)); } // Linfinity <= Euclidean norm
bool encloses(const C&a,const C&b) { return encloses(a.re,b.re)&&encloses(a.im,b.im); }
bool overlaps(const C&a,const C&b) {
    return a.re.l<=b.re.h && b.re.l<=a.re.h && a.im.l<=b.im.h && b.im.l<=a.im.h;
}
std::optional<C> intersection(const C&a,const C&b) {
    if (!overlaps(a,b)) return std::nullopt;
    return C(I(std::max(a.re.l,b.re.l),std::min(a.re.h,b.re.h)),
             I(std::max(a.im.l,b.im.l),std::min(a.im.h,b.im.h)));
}

// Independent elementary-function enclosure. For |z|<=M and N+2>M,
// sum_{k>N}|z|^k/k! <= M^(N+1)/(N+1)! / (1-M/(N+2)).
// Refusing a large argument is an unresolved evaluation, never an exclusion.
C exp_c(const C& z) {
    const I M=I::point(norm_upper(z));
    if (M.h > Z(8)*SCALE) throw std::domain_error("elementary evaluator range budget");
    constexpr long N=160;
    C term(1),sum(1); I scalar(1);
    for (long k=1;k<=N;++k) { term=term*z/C(k); sum=sum+term; scalar=scalar*M/I(k); }
    I tail=(scalar*M/I(N+1))/(I(1)-M/I(N+2));
    return inflate(sum,tail.h);
}
std::pair<C,C> sincos_c(const C&z) {
    const C ii(I(0),I(1)); C p=exp_c(ii*z),m=exp_c(-ii*z);
    return {(p-m)/C(I(0),I(2)),(p+m)/C(2)};
}

// First-order complex automatic differentiation. All values and derivatives
// are rectangular enclosures; the independent variable is the initial fibre.
struct J {
    C v,d;
    J(C value=C(0),C deriv=C(0)) : v(std::move(value)),d(std::move(deriv)) {}
    J(long n) : v(n),d(0) {}
};
J operator+(const J&a,const J&b) { return J(a.v+b.v,a.d+b.d); }
J operator-(const J&a) { return J(-a.v,-a.d); }
J operator-(const J&a,const J&b) { return a+(-b); }
J operator*(const J&a,const J&b) { return J(a.v*b.v,a.d*b.v+a.v*b.d); }
J operator/(const J&a,const J&b) { return J(a.v/b.v,(a.d*b.v-a.v*b.d)/(b.v*b.v)); }
J exp_j(const J&a) { C e=exp_c(a.v); return J(e,e*a.d); }
J sin_j(const J&a) { auto sc=sincos_c(a.v); return J(sc.first,sc.second*a.d); }
struct State { J a,b; };
State T(const State&p) {
    J s=sin_j(p.b);
    return {p.a-s,p.b+exp_j(p.a)-J(1)-s};
}
State F(State p) { for(int k=0;k<6;++k) p=T(p); return p; }
State zw_to_raw(const State&p) {
    const C ii3(I(0),sqrt_i(I(3)));
    J eta=(p.a-p.b)/J(ii3), rho=(p.a+p.b+eta)/J(2);
    return {rho,eta};
}
State raw_to_zw(const State&p) {
    const C omega(I::rat(-1,2),sqrt_i(I(3))/I(2));
    return {p.a+J(omega)*p.b,p.a+J(conj(omega))*p.b};
}
J polynomial(const std::vector<C>& coefficients,const J& x) {
    J s(0); for(auto it=coefficients.rbegin();it!=coefficients.rend();++it) s=s*x+J(*it); return s;
}
State lifted_F(const State&p,const std::vector<C>& phi) {
    J w=polynomial(phi,p.a)+p.a*p.a*p.b;
    State q=raw_to_zw(F(zw_to_raw({p.a,w})));
    return {q.a,(q.b-polynomial(phi,q.a))/(q.a*q.a)};
}

struct Disk {
    C c; Z r;
    Disk(C centre,Z radius) : c(std::move(centre)),r(std::move(radius)) {
        if (!c.exact() || r<0) throw std::invalid_argument("disk requires exact dyadic centre and nonnegative radius");
    }
    C box() const { return inflate(c,r); }
};
Disk enclosing_disk(const C& box) { C c=mid(box); return Disk(c,norm_upper(box-c)); }
bool contains_point(const Disk& D,const C& p) {
    if (!p.exact()) throw std::invalid_argument("point must be exact");
    Z x=p.re.l-D.c.re.l,y=p.im.l-D.c.im.l;
    return x*x+y*y<=D.r*D.r;
}
bool outside_disk(const C&B,const Disk&D) {
    C delta=B-D.c; Z x=al(delta.re),y=al(delta.im);
    return x*x+y*y>D.r*D.r;
}
bool separated(const Disk&A,const Disk&B) {
    // Strict comparison in integer arithmetic. Tangency is not separation.
    Z x=A.c.re.l-B.c.re.l,y=A.c.im.l-B.c.im.l,r=A.r+B.r;
    return x*x+y*y>r*r;
}

// [SESSION, conditional theorem] If f is holomorphic on B(a,r),
// f(a) in f_at_a, f'(B) in derivative, and |f(d*)| <= terminal_radius,
// then d* belongs to the returned disk. The necessary-condition bound must
// cover ALL feasible base points, not just the nominal orbit. No uniqueness
// assertion, existence assertion or DYAD dependency discharge is made here.
Disk necessary_disk(const Disk&B,const C&f_at_a,const C&derivative,
                    const C&b,const Z&terminal_radius) {
    if(!b.exact() || terminal_radius<0) throw std::invalid_argument("invalid contractor input");
    const Z lower=norm_lower(b);
    if(lower<=0) throw std::domain_error("unresolved slope");
    C new_c_box=B.c-f_at_a/b, c=mid(new_c_box);
    Z centre_error=norm_upper(new_c_box-c), D=norm_upper(derivative-b);
    Z product_upper=cd(D*B.r,SCALE);
    Z radial_upper=cd((terminal_radius+product_upper)*SCALE,lower);
    return Disk(c,centre_error+radial_upper);
}

// A sound outer-cover engine. The callback must satisfy the mathematical
// contractor contract. An exception/failed enclosure RETAINS the tile.
// Budget exhaustion RETAINS the pending queue. An empty cover is an error
// for the intended conditional-existing-curve use, never a zero-jump proof.
struct Cover { std::vector<C> leaves; size_t visited=0; bool budget_hit=false; };
using Contract=std::function<std::optional<C>(const C&)>;
std::pair<C,C> bisect(const C&b) {
    C l=b,r=b;
    if(b.re.h-b.re.l>=b.im.h-b.im.l) {
        Z m=fd(b.re.l+b.re.h,Z(2)); l.re.h=m;r.re.l=m;
    } else { Z m=fd(b.im.l+b.im.h,Z(2));l.im.h=m;r.im.l=m; }
    return {l,r};
}
Cover outer_cover(const Disk&initial,const Contract&contract,const Z&width,size_t budget) {
    if(width<1 || budget<1) throw std::invalid_argument("positive budget and width required");
    Cover result; std::vector<C> todo{initial.box()};
    while(!todo.empty()) {
        if(result.visited>=budget) {
            result.budget_hit=true;result.leaves.insert(result.leaves.end(),todo.begin(),todo.end());break;
        }
        C tile=todo.back();todo.pop_back();++result.visited;
        if(outside_disk(tile,initial)) continue;
        std::optional<C> reduced;
        try { reduced=contract(tile); }
        catch(const std::domain_error&) {
            // F3: unresolved is not empty. Subdivide while above the size limit;
            // if the budget expires, the complete pending queue is retained.
            if(tile.re.h-tile.re.l>width || tile.im.h-tile.im.l>width) {
                auto halves=bisect(tile);
                todo.push_back(halves.second);todo.push_back(halves.first);
            } else result.leaves.push_back(tile);
            continue;
        }
        if(!reduced) continue;
        reduced=intersection(tile,*reduced);
        if(!reduced) continue;
        if(reduced->re.h-reduced->re.l<=width && reduced->im.h-reduced->im.l<=width) {
            result.leaves.push_back(*reduced);continue;
        }
        auto halves=bisect(*reduced); todo.push_back(halves.second);todo.push_back(halves.first);
    }
    return result;
}
Disk hull_disk(const Cover& c) {
    if(c.leaves.empty()) throw std::domain_error("empty cover: conditional existence/input inconsistency");
    C h=c.leaves.front();
    for(const auto& b:c.leaves) {
        h.re.l=std::min(h.re.l,b.re.l);h.re.h=std::max(h.re.h,b.re.h);
        h.im.l=std::min(h.im.l,b.im.l);h.im.h=std::max(h.im.h,b.im.h);
    }
    return enclosing_disk(h);
}
} // namespace dyad

#ifndef DYAD_CORE_NO_MAIN
int main(int argc,char**argv) {
    using namespace dyad;
    if(argc!=2 || std::string(argv[1])!="--unit-tests") {
        std::cerr<<"Usage: independent_core --unit-tests\nNo DYAD run, inverse adapter or certification mode is implemented.\n";
        return 64;
    }
    unsigned tests=0;
    auto require=[&](bool ok,const char*name) {
        ++tests;if(!ok) throw std::runtime_error(name);std::cout<<name<<" PASS\n";
    };
    try {
        require(fd(Z(-1),Z(3))==-1 && cd(Z(-1),Z(3))==0,"ROUND_SIGN");
        require(encloses(I::rat(1,3)*I(3),I(1)),"ROUND_MUL");
        require(encloses(sq(sqrt_i(I(3))),I(3)),"SQRT");
        bool refused=false;try{(void)(I(1)/I(Z(-1),Z(1)));}catch(const std::domain_error&){refused=true;}
        require(refused,"ZERO_DENOMINATOR_REJECTED");
        require(encloses(exp_c(C(0)),C(1)),"EXP_ZERO");
        C e=exp_c(C(I::rat(1,8)));
        require(e.re.l>I::rat(9,8).h && e.re.h<I::rat(8,7).l,"EXP_RATIONAL_BRACKET");
        auto sc=sincos_c(C(I::rat(1,8),I::rat(1,16)));
        require(encloses(sc.first*sc.first+sc.second*sc.second,C(1)),"TRIG_IDENTITY");
        State p=F({J(C(0),C(1)),J(0)}),q=F({J(0),J(C(0),C(1))});
        require(encloses(p.a.v,C(0))&&encloses(p.b.v,C(0)),"F_ORIGIN");
        require(encloses(p.a.d,C(1))&&encloses(p.b.d,C(0))&&
                encloses(q.a.d,C(0))&&encloses(q.b.d,C(1)),"DF_ORIGIN_IDENTITY");
        C z(I::rat(1,64),I::rat(1,128)),w(I::rat(1,4096),I::rat(-1,8192));
        State round=raw_to_zw(zw_to_raw({J(z),J(w)}));
        require(encloses(round.a.v,z)&&encloses(round.b.v,w),"CHART_ROUNDTRIP");
        std::vector<C> phi{C(0),C(0),C(I::rat(1,2))};
        State lf=lifted_F({J(z),J(C(0),C(1))},phi);
        State raw=raw_to_zw(F(zw_to_raw({J(z),polynomial(phi,J(z))})));
        require(overlaps(lf.a.v,raw.a.v)&&overlaps(lf.a.v*lf.a.v*lf.b.v+polynomial(phi,lf.a).v,raw.b.v),"LIFT_DEFINITION");
        Disk A(C(0),SCALE), tangent(C(2),SCALE), apart(C(3),SCALE);
        require(!separated(A,tangent)&&separated(A,apart)&&!separated(A,A),"STRICT_SEPARATION");
        C root(I::rat(1,16),I::rat(-1,32));Disk input(C(0),SCALE);
        Disk contracted=necessary_disk(input,-C(7)*root,C(7),C(7),0);
        require(contains_point(contracted,root)&&contracted.r<SCALE/1000,"LINEAR_CONTRACTOR");
        // Check all dyadic witnesses satisfying |7(d-root)|<=terminal radius.
        Z rr=SCALE/64;Disk dc=necessary_disk(input,-C(7)*root,C(7),C(7),rr);
        bool witnesses=true;
        for(long a=-16;a<=16;++a)for(long b=-16;b<=16;++b){
            C x=root+C(I::rat(a,16384),I::rat(b,16384));
            C fx=C(7)*(x-root);
            if(au(fx.re)*au(fx.re)+au(fx.im)*au(fx.im)<=rr*rr) witnesses &= contains_point(dc,x);
        }
        require(witnesses,"CONTRACTOR_WITNESSES");
        auto linear=[&](const C&tile)->std::optional<C>{
            Disk B=enclosing_disk(tile);C v=C(7)*(B.c-root);
            return necessary_disk(B,v,C(7),C(7),0).box();
        };
        Cover cv=outer_cover(input,linear,SCALE/1000000,100);
        require(!cv.budget_hit&&contains_point(hull_disk(cv),root),"FIBRE_COVER");
        Contract unresolved=[](const C&)->std::optional<C>{throw std::domain_error("unresolved");};
        Cover unknown=outer_cover(input,unresolved,Z(1),10);
        require(unknown.budget_hit&&encloses(hull_disk(unknown).box(),input.box()),"UNRESOLVED_SUBDIVIDED_RETAINED");
        Contract identity=[](const C&b)->std::optional<C>{return b;};
        Cover cap=outer_cover(input,identity,Z(1),1);
        require(cap.budget_hit && encloses(hull_disk(cap).box(),input.box()),"BUDGET_RETAINED");
        Cover empty;
        refused=false;try{(void)hull_disk(empty);}catch(const std::domain_error&){refused=true;}
        require(refused,"EMPTY_COVER_REJECTED");
        auto tiny=necessary_disk(Disk(root,SCALE/16),C(0),C(1),C(1),SCALE/1024);
        require(!separated(tiny,tiny),"ZERO_JUMP_NEGATIVE_CONTROL");
        refused=false;try{(void)necessary_disk(input,C(0),C(1),C(0),0);}catch(const std::domain_error&){refused=true;}
        require(refused,"SLOPE_ZERO_REJECTED");
        std::cout<<"RESULT PASS "<<tests<<" tests; SESSION prototype; no DYAD point jump computed\n";
        return 0;
    } catch(const std::exception&e) {
        std::cerr<<"RESULT FAIL after "<<tests<<" tests: "<<e.what()<<"\n";return 1;
    }
}

#endif // DYAD_CORE_NO_MAIN
