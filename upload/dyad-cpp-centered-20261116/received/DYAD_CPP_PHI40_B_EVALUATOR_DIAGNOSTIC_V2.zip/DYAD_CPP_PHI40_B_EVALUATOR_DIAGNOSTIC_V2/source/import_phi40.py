#!/usr/bin/env python3
"""SESSION-only, source-pinned transfer of published midpoint strings to outer dyadic boxes.
Not a replay of the Arb computation. Does not assume 80-digit strings are exact coefficients.
"""
import argparse, hashlib, json, pathlib, sys
from fractions import Fraction
from decimal import Decimal

EXPECTED_SHA='6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e'
SOURCE='evidence/dyad/open20-an/stage2/scout_N216_dps840.json'
SCALE=1<<256
COEFF_PAD=Fraction(1,10**65)
C_PAD=Fraction(1,10**32)

def fraction(s):
    return Fraction(Decimal(str(s)))

def ceil_div(x,d): return -(-x//d)
def floor_scaled(x): return x.numerator*SCALE//x.denominator
def ceil_scaled(x): return ceil_div(x.numerator*SCALE,x.denominator)
def endpoints(s,pad):
    v=fraction(s)
    return floor_scaled(v-pad),ceil_scaled(v+pad)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',required=True)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    f=pathlib.Path(a.source); raw=f.read_bytes()
    got=hashlib.sha256(raw).hexdigest()
    if got!=EXPECTED_SHA: raise SystemExit('FAIL source SHA256: '+got+' expected '+EXPECTED_SHA)
    j=json.loads(raw)
    assert j['all_pass'] is True and j['args']['N']>=40 and j['args']['dps']>=400
    info=j['info']; co=info['coefficients']; rad=info['ball_radius_a_k']
    assert all(str(k) in co and str(k) in rad for k in range(2,41))
    assert all(fraction(rad[str(k)]) < Fraction(1,10**300) for k in range(2,41))
    assert len(info['c_pil'])==2
    # The 80-significant-digit midpoint display is not a full Arb ball. Conservatively
    # add 1e-65 in each component (> its decimal rounding and source-reported radius).
    # The 40-digit c midpoint similarly gets 1e-32. These representation assumptions
    # remain explicit and need owner acceptance before this is 'certified' input.
    lines=['DYAD_PHI40_OUTER_V1',EXPECTED_SHA]
    for k in range(2,41):
        u=co[str(k)]; assert len(u)==2
        bounds=[*endpoints(u[0],COEFF_PAD),*endpoints(u[1],COEFF_PAD)]
        lines.append(' '.join(map(str,[k,*bounds])))
    lines.append('C '+' '.join(map(str,[*endpoints(info['c_pil'][0],C_PAD),*endpoints(info['c_pil'][1],C_PAD)])))
    lines.append('END')
    out=pathlib.Path(a.out)
    if out.exists(): raise SystemExit('Refusing to overwrite '+str(out))
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text('\n'.join(lines)+'\n',encoding='ascii')
    print('TRANSFER_SOURCE_SHA256',got)
    print('COUNT 39 coefficient boxes and one c box')
    print('DISPLAY_PADS coeff=1e-65; c=1e-32; source Arb radii reported below 1e-300')
    print('OUTPUT_SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
    print('STATUS SESSION input adaptation only; coefficients not independently regenerated')
if __name__=='__main__':main()
