# DYAD OPEN 20 — bounded evaluator fallback (b), development checkpoint v2

**Status:** SESSION code; **not owner-reviewed**. No certificate, no B-an/B-6 disposition, no 3c-b run, no inverse G or jump calculation.

## Provenance

- Unchanged prior package: `received/DYAD_CPP_PHI40_B_IMPORT.zip`, SHA-256 `63398e38f6197bfb35bd27ae307ec4a6c81754393fc1ce245f57a2de1fabc6d8`.
- Frozen input: `evidence/dyad/open20-an/stage2/scout_N216_dps840.json`, SHA-256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`, from the source owner's repository.
- `independent_core.cpp` and `import_phi40.py` are unchanged. `centered_evaluator.hpp` adds a fallback for interval range-budget errors; `real_phi40_forward_probe.cpp` adds an optional 1/2/5/10/20-block horizon, default 20.
- Imported coefficients remain 80-digit displayed midpoint strings with protective pads, not independently reconstructed exact Arb balls. The original import scope is unchanged.

## Verified implication of the fallback

The original `block(boxes)` evaluates six primitive maps on one interval rectangle and loses dependencies. With the whole initial fibre, it can refuse `|rho| > 8` during the **first** `F=T^6` block without demonstrating that a true orbit leaves the computational domain.

`centered_block_jacobian` instead encloses each of the six primitive T images in a *separate centred polydisk* and encloses the full Jacobian using the chain rule. At primitive step `t`, the interval Jacobian `J_t` contains `D T` at every point of the current polydisk, and the next polydisk contains every image by the complex mean-value theorem. Thus the interval product `J_5 ... J_0` bounds `D(T^6)` over the **whole initial disk**, conditional on completing the arithmetic. The outer six-step update uses this bound around an interval enclosure of the centre orbit. This fallback activates only on `residual exponential range budget` or `residual sine range budget`; other exceptions remain loud failures.

This fixes only an **evaluation refusal**, not the need to restrict the initial fibre. At the next step, the broad unpruned set may still intersect the lift pole or exceed elementary range budgets. Such cases remain **INCONCLUSIVE**; they are not discarded.

## Development tests (no source-pinned DYAD source available locally)

A fixture was assembled from 18-significant-digit approximations to the source-reported coefficients, with larger protective pads. It is **not** the source-pinned Stage-2 JSON. Against this representative fixture:
- Old full-fibre evaluator refused at block 1.
- New fallback encloses one full-fibre block. At block 2, it returns INCONCLUSIVE (`complex denominator not bounded away from zero`).
- 65 independently sampled initial fibre values at radii 0, 0.001 and 0.002; value and derivative of six primitive iterations independently computed using 170-digit mpmath; **260/260 complex enclosure checks pass** for block 1.
- Unchanged original-core unit tests **20/20**, centred tests **15/15** under standard compilation and sanitizer compilation; no sanitizer diagnosis.

**All success/failure statements are scoped to this representative local fixture, not the user's complete source-pinned run.**

## Ubuntu CLI

Requirements: `g++` (C++17), Boost headers, Python 3, `sha256sum`, clean new output directory. The script checks the exact Stage-2 source SHA-256 before importing.

```bash
unzip -q /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2.zip -d /root
bash /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2/run_ubuntu_v2.sh \
  /root/rtg-corpus /root/dyad-phi40-v2-1step 1
cat /root/dyad-phi40-v2-1step/forward.tsv
```

For longer horizons, use a **different empty output directory** and change `1` to `2`, `5`, `10` or `20`. `exit=0` means both unpruned *enclosures* completed only that horizon, **not** a tube test. `exit=2` means INCONCLUSIVE. `exit=3` source input format error; `exit=4` source SHA mismatch; `exit=64` invalid CLI/output path.

## Next research gate

To shrink the true initial fibre, connect the reviewed necessary-condition contractor to a rigorous bound of `R_j` over `X_k intersect D_j`, preserving the proof record's chart sector, principal log branch and pole conditions. An input tile whose eligibility cannot be proved must be **retained**, not excluded. Successful mere evaluation of the entire initial fibre for one block does not prove any orbit condition, nor a jump. The selected inverse G, true two-disc test and any scientific adoption remain OPEN.
