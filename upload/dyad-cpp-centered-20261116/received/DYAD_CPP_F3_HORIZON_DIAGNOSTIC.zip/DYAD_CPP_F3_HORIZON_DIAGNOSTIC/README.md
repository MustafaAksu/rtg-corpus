# DYAD OPEN 20 — bounded horizon-3 versus further-selective-F2 comparison (SESSION)

## Purpose

The owner-reviewed C++ F2 selected-refinement successor reduced the outer initial-fibre hull to approximately 2.501176e-4 on the PI server (144 retained final rectangles from 400 children, after 924+256 prior exclusions). Its measured `Dr/M2` on these child evaluations is <0.555. The next question is whether extending the **same retained initial-fibre cover** to 3 blocks beats spending the budget on one more 2×2 second-block refinement. This archive implements an **experimental comparison**, not a scientific or 3c-b run.

### Modes

| Mode | Input sets | Conditions | Evaluations (not counting 144 exact F2 replays) |
|---|---|---|---:|
| `h3` | 144 frozen retained initial-fibre rectangles | three F blocks, fresh M3, whole-disk derivative | 144 |
| `refine2` | the same 144 rectangles split 2×2 | two F blocks, fresh M2, whole-child derivative | 576 |
| `h5` | the same 144 rectangles | five F blocks, fresh M5, whole-disk derivative | 144 |
| `compare` | h3 followed by refine2 | separate output directories; no automatic h5 | 720 |

No previous exclusions are revisited. Before each mode, all 144 source-retained rows are replayed with the original owner-reviewed F2 engine and compared to the source's **seven exact integer terms and necessary box**. Original initial-fibre parent/child intersections and their provenance are audited against the full prior 1,024-row log. The 256 previously excluded source-selected children are not re-executed; their validity is inherited from the fully verified source selective campaign.

For each tested set E, the necessary condition is applied only conditionally:

\[
\text{candidate }d^*\in E,\ x_k(d^*)\in D_0,\ |d_k(d^*)|\le R_0(x_k(d^*)) \implies
 d^*\in E\cap B\Bigl(a-f_k(a)/b,\,(M_k+D r)/|b|\Bigr),
\]

where `M_k=ForwardTube::upper(X_k)` is valid **on X_k∩D0**, not a sampled tube radius; `D` encloses \(|f'_k-b|\) over the entire circumscribing evaluation disk. Each output is a **rectangle intersection**, while a disk is used for evaluation only. On a domain failure, the current initial-fibre child rectangle is retained. Every printed radius is a conservative **L1** radius, and final hull inclusion in source is checked. A full run requires 144 source replays, all requested evaluations, and the independent integer structural checker.

## Ubuntu CLI

Prerequisites: existing extracted, SHA-manifest-verified directories on the PI's Ubuntu server:

- `/root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2`
- `/root/DYAD_CPP_FORWARD_METHOD_BENCHMARK`
- `/root/DYAD_CPP_F1_TUBE_CONTRACTOR`
- `/root/DYAD_CPP_F2_TUBE_CONTRACTOR`
- `/root/DYAD_CPP_F2_TERM_AUDIT_SUB8`
- `/root/DYAD_CPP_F2_SELECTIVE_REFINE`

and exact original run directories `/root/dyad-f2-term8-full`, `/root/dyad-f2-selective-run`. These inputs have been uploaded on `upload/dyad-cpp-f2-selective-20261118` and `upload/dyad-cpp-f2-selective-results-20261118` respectively. Exact pins:

- Stage 2 JSON: SHA-256 `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`
- Prior full sub8 `terms.tsv`: SHA-256 `1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72`
- Prior selective `selective_children.tsv`: SHA-256 `3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579`

Place this archive in `/root/`, verify the announced SHA-256 and extract with `unzip -n`. For both default comparison modes:

```bash
bash /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC/run_ubuntu_horizon.sh \
  /root/rtg-corpus \
  /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
  /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
  /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
  /root/DYAD_CPP_F2_TERM_AUDIT_SUB8 \
  /root/DYAD_CPP_F2_SELECTIVE_REFINE \
  /root/dyad-f2-term8-full \
  /root/dyad-f2-selective-run \
  /root/dyad-horizon-compare \
  compare

echo "exit=$?"
cat /root/dyad-horizon-compare/h3/summary.txt
cat /root/dyad-horizon-compare/refine2/summary.txt
cat /root/dyad-horizon-compare/comparison.txt
```

`h5` is available **only by explicitly specifying** `h5` instead of `compare` and choosing a new empty output directory. It must not be triggered automatically by a h3 failure. The runner executes independent source/unit/negative/ASan-UBSan parser checks. Each computation has a 1,800 s timeout with partial output preserved.

**Exit codes:** `0` means complete development-only structural PASS (not scientific certificate); `2` means unresolved/timeout/empty cover, partial outputs saved; `3` means an input/arithmetical identity/source mismatch; `64` means invalid CLI. The source log and output must remain unchanged for the owner comparison. The numerical runs are *same-engine* executions; neither oracle sampling nor compiler cross-machine identity proves physical RTG claims.

## Optional unchanged GitHub intake

After copying the exact ZIP onto the PI server, its SHA-256 should be verified against the delivery value published alongside the ZIP. The following commands deposit immutable files on **two separate, new `upload/*` branches**; they never merge or alter `main`:

```bash
bash /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC/upload_horizon_evidence.sh \
  package /root/rtg-corpus /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC.zip \
  <SHA256_FROM_DELIVERY> --push

# Only after a completed PI run (can also preserve partial results if separately labelled):
bash /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC/upload_horizon_evidence.sh \
  results /root/rtg-corpus /root/dyad-horizon-compare - --push
```

The branches are `upload/dyad-cpp-f3-horizon-20261118` and `upload/dyad-cpp-f3-horizon-results-20261118`. The upload helper was tested against a synthetic local Git bare remote; this is **not a GitHub push**. The owner can independently read the exact source bytes and full run files by those refs. Do not tag or merge either branch as a release.

## Local evidence boundary

The co-owner has compiled the new C++17 source and run synthetic full-record format controls and mutated-record tests with an independent Python exact-integer checker. A complete 18-significant-digit **proxy** diagnostic and source selective campaign was recreated; local h3 yielded the limited result described in `tests/LOCAL_PROXY_RESULTS.md`. These numbers are intentionally not the PI's pinned Stage 2 coefficient input; no real three-block or comparison result is claimed until the Ubuntu run.

## Provenance and review

- **Governing adopted DYAD**: `dyad-v6.4.24` + owner release record; not based on unadopted PR #312.
- **Scientific owner context**: stage3c-a proof record §§1, 5, 9; owner F1/F2 and selected-F2 reviews in PR #305, working records only.
- **Implementation dependency**: unchanged `DYAD_CPP_F2_SELECTIVE_REFINE/source/selective_f2.cpp`, which includes unchanged F1/F2/Boost code. No source files in older received packages are modified.
- **Independence**: changed evaluator schedule? **No**. This is the same F1/F2 implementation with new horizon and selection logic, not a third independent mathematical implementation.
- **Open obligations**: owner checks H1–H5 in `OWNER_REVIEW_REQUEST.md`, actual source-backed PI run and reviewer replay, plus independent O-1 wall correction task (PR #312).

No full 3c-b production or replay has been authorized, no point-jump certificate exists and B-an/B-6 remain ACTIVE.
