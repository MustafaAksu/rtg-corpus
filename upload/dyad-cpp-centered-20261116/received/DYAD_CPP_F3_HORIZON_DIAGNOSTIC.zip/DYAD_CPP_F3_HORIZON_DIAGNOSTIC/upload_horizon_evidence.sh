#!/usr/bin/env bash
# [SESSION] Immutable intake of C++ horizon comparison source/results. No main modification.
set -euo pipefail
if [[ $# -ne 5 || ( "$1" != package && "$1" != results ) || "$5" != --push ]]; then
 echo 'Usage: upload_horizon_evidence.sh package REPO PACKAGE_ZIP ZIP_SHA256 --push' >&2
 echo '   or upload_horizon_evidence.sh results REPO RUN_OUTPUT_DIR - --push' >&2
 exit 64
fi
kind=$1;repo=$(cd -- "$2" && pwd);input=$(realpath -- "$3")
if [[ "$kind" == package ]];then
 [[ -f "$input" ]] || { echo 'missing original ZIP' >&2; exit 3; }
 # The incoming original ZIP remains unchanged; its recorded hash is exact.
 expected=$4
 [[ "$expected" =~ ^[0-9a-f]{64}$ ]] || { echo "expected SHA-256 must be 64 lowercase hexadecimal characters" >&2; exit 64; }
 echo "$expected  $input" | sha256sum -c - >/dev/null
 branch=upload/dyad-cpp-f3-horizon-20261118
else
 [[ -d "$input" ]] || { echo 'missing result directory' >&2; exit 3; }
 (cd "$input" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
 has_completed=false
 for job in h3 refine2 h5;do
  if [[ -d "$input/$job" ]];then
   (cd "$input/$job" && sha256sum -c SHA256SUMS.txt >/dev/null)
   [[ -s "$input/$job/summary.txt" ]] && has_completed=true
  fi
 done
 [[ "$has_completed" == true ]] || { echo 'no inspected mode summary' >&2; exit 3; }
 branch=upload/dyad-cpp-f3-horizon-results-20261118
fi
# No force pushes, main edits, or modification of received files.
git -C "$repo" fetch origin main >/dev/null
if git -C "$repo" show-ref --verify --quiet "refs/heads/$branch" || \
   git -C "$repo" show-ref --verify --quiet "refs/remotes/origin/$branch";then
 echo "STOP upload branch already exists: $branch" >&2; exit 3
fi
folder=$(mktemp -d /tmp/dyad-horizon-in-XXXXXX);rmdir "$folder"
cleanup() { git -C "$repo" worktree remove --force "$folder" >/dev/null 2>&1 || true; }
trap cleanup EXIT
git -C "$repo" worktree add -b "$branch" "$folder" origin/main >/dev/null
if [[ "$kind" == package ]];then
 mkdir -p "$folder/$branch/received"
 cp -p -- "$input" "$folder/$branch/received/DYAD_CPP_F3_HORIZON_DIAGNOSTIC.zip"
 (cd "$folder/$branch/received" && sha256sum DYAD_CPP_F3_HORIZON_DIAGNOSTIC.zip > SHA256SUMS.txt)
else
 mkdir -p "$folder/$branch/pi-run"
 cp -a -- "$input/." "$folder/$branch/pi-run/"
 (cd "$folder/$branch/pi-run" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
fi
(
 cd "$folder"
 git add -- "$branch"
 git commit -m "upload/dyad: receive untouched C++ horizon $kind (SESSION)" >/dev/null
 echo "CREATED_BRANCH=$branch";echo "COMMIT=$(git rev-parse HEAD)"
 git push origin "refs/heads/$branch:refs/heads/$branch"
)
echo 'UPLOAD_ONLY; no merge, tag, 3c-b authorization or adopted scientific result.'
