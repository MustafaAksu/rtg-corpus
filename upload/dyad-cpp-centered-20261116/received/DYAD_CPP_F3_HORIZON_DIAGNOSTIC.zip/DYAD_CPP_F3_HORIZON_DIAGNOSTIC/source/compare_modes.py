#!/usr/bin/env python3
"""[SESSION] Compare complete same-source C++ development runs, no theorem or certification."""
import re,sys
from pathlib import Path
if len(sys.argv)!=3:raise SystemExit('Usage: compare_modes.py H3_SUMMARY REFINE2_SUMMARY')
def read(p):
 d={}
 for k,v in re.findall(r'(?<!\S)([a-zA-Z0-9_]+)=([+0-9.a-zA-Z_-]+)',Path(p).read_text()):d[k]=v
 assert 'NO_CERTIFICATE' in Path(p).read_text()
 assert d['unresolved']=='0' and d['source_retained']=='144' and d['checked_retained']=='144'
 return d
h,r=map(read,sys.argv[1:]);assert h['HORIZON_COMPARISON']=='h3' and r['HORIZON_COMPARISON']=='refine2'
assert h['prior_L1_256']==r['prior_L1_256']
for x in (h,r):
 print(x['HORIZON_COMPARISON'],f"evaluations={x['evaluations']}",f"retained={x['retained']}",f"unresolved={x['unresolved']}",f"finalL1={x['final_L1']}",f"seconds={x['elapsed_seconds']}")
print('H3_vs_refine2_radius_ratio=%.6f'%(float(h['final_L1'])/float(r['final_L1'])))
print('H3_vs_refine2_elapsed_ratio=%.6f'%(float(h['elapsed_seconds'])/float(r['elapsed_seconds'])))
print('SESSION_ONLY, comparison may favour neither; graph/tube hypotheses conditional.')
