// [SESSION] Conditional horizon-vs-refinement experiment after selective F2.
// Deliberately includes the previously reviewed F1/F2/selective sources UNCHANGED.
// This is a necessary-condition outer cover, not a certificate of a curve or point jump.
#define DYAD_SELECTIVE_NO_MAIN
#include "selective_f2.cpp"
#include <chrono>
#include <iomanip>
#include <map>
#include <set>

namespace horizon {
using namespace dyad;
using namespace dyad::centered;
struct Row {
 size_t tile=0, parent=0, child=0;
 C source_parent=C(0), child_box=C(0), necessary=C(0), final=C(0);
 Z M=0, Dr=0,D=0,r=0,lb=0,err=0,rad=0;
 bool kept=false;
};
using Id=std::tuple<size_t,size_t,size_t>;
using Group=std::pair<size_t,size_t>;
bool same_box(const C& a,const C& b);
std::vector<Row> load_checked_source(const std::string& name){
 std::ifstream f(name);if(!f)throw std::runtime_error("missing frozen selective F2 TSV");
 std::string hdr;std::getline(f,hdr);
 if(hdr!="tile parent_subtile child parent_re_lo parent_re_hi parent_im_lo parent_im_hi "
         "child_re_lo child_re_hi child_im_lo child_im_hi "
         "necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi "
         "final_re_lo final_re_hi final_im_lo final_im_hi "
         "M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action")
   throw std::runtime_error("wrong frozen selective TSV header");
 std::set<Id> keys;std::map<Group,C> parents;std::map<Group,std::set<size_t>> children;
 std::vector<Row> rows;size_t excluded=0,retained=0;
 std::string line;
 while(std::getline(f,line)){
  if(line.empty())throw std::runtime_error("empty source row");
  std::istringstream s(line);Row a;std::string eval,action,extra;
  auto box=[&](C& c){Z x0,x1,y0,y1;if(!(s>>x0>>x1>>y0>>y1))throw std::runtime_error("incomplete box");if(x0>x1||y0>y1)throw std::runtime_error("inverted box");c=C(I(x0,x1),I(y0,y1));};
  if(!(s>>a.tile>>a.parent>>a.child))throw std::runtime_error("missing row IDs");
  box(a.source_parent);box(a.child_box);box(a.necessary);box(a.final);
  if(!(s>>a.M>>a.Dr>>a.D>>a.r>>a.lb>>a.err>>a.rad>>eval>>action)||(s>>extra))
    throw std::runtime_error("bad source row terms/trailing data");
  if(a.tile>=60||a.parent>=64||a.child>=4||eval!="VALID"||
     (action!="EXCLUDED"&&action!="RETAINED")||
     !keys.emplace(a.tile,a.parent,a.child).second)
    throw std::runtime_error("invalid/duplicate source IDs or unresolved row");
  if(a.M<=0||a.D<0||a.r<0||a.lb<=0||a.err<0||a.Dr<0||a.rad<0||
     a.Dr!=cd(a.D*a.r,SCALE)||a.rad!=a.err+cd((a.M+a.Dr)*SCALE,a.lb)||
     a.necessary.re.h-a.necessary.re.l!=2*a.rad||a.necessary.im.h-a.necessary.im.l!=2*a.rad)
    throw std::runtime_error("source integer radius identity mismatch");
  auto p=std::make_pair(a.tile,a.parent);
  if(!parents.count(p))parents.emplace(p,a.source_parent);
  else if(!same_box(parents.at(p),a.source_parent))throw std::runtime_error("parent changed among children");
  children[p].insert(a.child);
  auto splits=f2::split_box(a.source_parent,2);
  if(!same_box(splits.at(a.child),a.child_box))throw std::runtime_error("invalid source child subdivision");
  auto hit=intersection(a.child_box,a.necessary);
  if(action=="RETAINED"){
    if(!hit||!same_box(*hit,a.final))throw std::runtime_error("source retained cell intersection mismatch");
    a.kept=true;++retained;
  }else{
    if(hit||!same_box(a.final,C(0)))throw std::runtime_error("source exclusion intersection mismatch");
    ++excluded;
  }
  rows.push_back(a);
 }
 if(rows.size()!=400||retained!=144||excluded!=256||parents.size()!=100||keys.size()!=400)
   throw std::runtime_error("frozen source row counts changed");
 for(const auto& kv:children)if(kv.second!=std::set<size_t>({0,1,2,3}))
   throw std::runtime_error("incomplete source parent coverage");
 return rows;
}
bool same_box(const C& a,const C& b){return a.re.l==b.re.l&&a.re.h==b.re.h&&a.im.l==b.im.l&&a.im.h==b.im.h;}

void replay(const Row& a,const Data& data,const f1::ForwardTube& tube){
 Disk disk=ball(a.child_box);
 State whole=f2::iter(tube.at_start(),disk,data.phi,2);
 Z M=tube.upper(whole.a.v).M;
 State point=f2::iter(tube.at_start(),Disk(disk.c,0),data.phi,2);
 C slope=mid(point.b.d);Z lb=norm_lower(slope);
 if(lb<=0)throw std::runtime_error("source retained slope no longer nonzero");
 Z D=norm_upper(whole.b.d-slope),Dr=cd(D*disk.r,SCALE);
 Disk necessary=necessary_disk(disk,point.b.v,whole.b.d,slope,M);
 C shift=disk.c-point.b.v/slope;
 Z e=norm_upper(shift-mid(shift));
 if(a.M!=M||a.Dr!=Dr||a.D!=D||a.r!=disk.r||a.lb!=lb||a.err!=e||
    a.rad!=necessary.r||a.rad!=e+cd((M+Dr)*SCALE,lb)||
    !same_box(a.necessary,necessary.box()))
   throw std::runtime_error("source retained child differs from exact F2 computation");
 auto hit=intersection(a.child_box,necessary.box());
 if(!hit || !same_box(*hit,a.final))throw std::runtime_error("source retained box mismatch");
}

void output_header(std::ostream& o){
 o<<"tile parent_subtile child new_subtile source_re_lo source_re_hi source_im_lo source_im_hi "
    "probe_re_lo probe_re_hi probe_im_lo probe_im_hi "
    "necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi "
    "final_re_lo final_re_hi final_im_lo final_im_hi "
    "M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action\n";
}
void row_out(std::ostream& out,const Row& source,size_t sub,const C& probe,const C& necessary,const C& fin,
 Z M,Z Dr,Z D,Z r,Z lb,Z e,Z radius,const char* eval,const char* action){
 out<<source.tile<<' '<<source.parent<<' '<<source.child<<' '<<sub<<' ';
 selective::print_box(out,source.final);out<<' ';selective::print_box(out,probe);
 out<<' ';selective::print_box(out,necessary);out<<' ';selective::print_box(out,fin);
 out<<' '<<M<<' '<<Dr<<' '<<D<<' '<<r<<' '<<lb<<' '<<e<<' '<<radius
    <<' '<<eval<<' '<<action<<'\n';
}
struct Result {
 size_t checked=0, evaluations=0,retained=0,excluded=0,unresolved=0;
 size_t dr_gt_m=0;std::vector<Z> q;std::optional<C> prior_hull,final_hull;
 Z Mmin=0,Mmax=0;double seconds=0;
};
Result run(const Data& data,const std::vector<Row>& rows,const std::string& mode,
 const std::string& output){
 const int blocks=(mode=="h3"?3:mode=="h5"?5:2);
 if(mode!="h3"&&mode!="h5"&&mode!="refine2")throw std::invalid_argument("invalid mode");
 f1::ForwardTube tube(data.c);
 Result st;std::ofstream out(output);if(!out)throw std::runtime_error("cannot create output");
 output_header(out);auto t0=std::chrono::steady_clock::now();
 for(const auto& source:rows){
  if(!source.kept)continue; // prior 256 eliminated cells NOT reevaluated
  replay(source,data,tube);++st.checked;
  f1::add_hull(st.prior_hull,source.final);
  const auto probes=(mode=="refine2"?f2::split_box(source.final,2):std::vector<C>{source.final});
  for(size_t j=0;j<probes.size();++j){
   const C& b=probes[j];const Disk di=ball(b);++st.evaluations;
   try{
    State whole=f2::iter(tube.at_start(),di,data.phi,blocks);
    const Z M=tube.upper(whole.a.v).M;
    State point=f2::iter(tube.at_start(),Disk(di.c,0),data.phi,blocks);
    const C slope=mid(point.b.d);const Z lb=norm_lower(slope);
    if(lb<=0)throw std::domain_error("evaluation slope may be zero");
    const Z D=norm_upper(whole.b.d-slope),Dr=cd(D*di.r,SCALE);
    const Disk nd=necessary_disk(di,point.b.v,whole.b.d,slope,M);
    const C shift=di.c-point.b.v/slope;const Z e=norm_upper(shift-mid(shift));
    if(nd.r!=e+cd((M+Dr)*SCALE,lb))throw std::runtime_error("C1C2 radius changed");
    if(st.Mmin==0||M<st.Mmin)st.Mmin=M;
    if(M>st.Mmax)st.Mmax=M;
    if(Dr>M)++st.dr_gt_m;
    st.q.push_back(cd(Dr*SCALE,M));
    auto cut=intersection(b,nd.box());
    if(cut){++st.retained;f1::add_hull(st.final_hull,*cut);
      row_out(out,source,j,b,nd.box(),*cut,M,Dr,D,di.r,lb,e,nd.r,"VALID","RETAINED");
    } else {++st.excluded;
      row_out(out,source,j,b,nd.box(),C(0),M,Dr,D,di.r,lb,e,nd.r,"VALID","EXCLUDED");
    }
   }catch(const std::domain_error& e){
    ++st.unresolved;f1::add_hull(st.final_hull,b);
    row_out(out,source,j,b,b,b,0,0,0,0,0,0,0,"UNRESOLVED","RETAINED");
    if(st.unresolved<=5)std::cerr<<"UNRESOLVED "<<source.tile<<','<<source.parent<<','<<source.child<<','<<j<<" "<<e.what()<<'\n';
   }
  }
 }
 if(st.checked!=144 || st.evaluations!=(mode=="refine2"?576U:144U) ||
    st.retained+st.excluded+st.unresolved!=st.evaluations)
    throw std::runtime_error("coverage/accounting mismatch");
 if(!st.prior_hull || !st.final_hull)throw std::domain_error("empty candidate cover not a proof");
 const C& old=*st.prior_hull;const C& now=*st.final_hull;
 if(now.re.l<old.re.l||now.re.h>old.re.h||now.im.l<old.im.l||now.im.h>old.im.h)
   throw std::runtime_error("final hull outside source hull");
 st.seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();
 return st;
}
} // namespace horizon

#ifndef DYAD_HORIZON_NO_MAIN
int main(int argc,char** argv){
 if(argc!=5){std::cerr<<"Usage: horizon TRANSFER VALIDATED_SELECTIVE_F2_TSV MODE(h3|h5|refine2) OUT_DETAILS_TSV\n";return 64;}
 try{
  std::string mode=argv[3];if(mode!="h3"&&mode!="h5"&&mode!="refine2")
    throw std::invalid_argument("mode must be h3|h5|refine2");
  const Data data=read_data(argv[1]);
  const auto rows=horizon::load_checked_source(argv[2]);
  auto s=horizon::run(data,rows,mode,argv[4]);
  const Z before=enclosing_disk(*s.prior_hull).r,after=enclosing_disk(*s.final_hull).r;
  std::sort(s.q.begin(),s.q.end());
  std::cout<<"MODE=SESSION_CONDITIONAL; HORIZON_COMPARISON="<<mode<<"; SOURCE=SELECTIVE_F2\n";
  std::cout<<"source_rows=400 source_retained=144 source_excluded=256 checked_retained="<<s.checked<<'\n';
  std::cout<<"evaluations="<<s.evaluations<<" retained="<<s.retained<<" excluded="<<s.excluded<<" unresolved="<<s.unresolved<<'\n';
  std::cout<<"M_min="<<f1::outdec(s.Mmin)<<" M_max="<<f1::outdec(s.Mmax)
           <<" Dr_gt_M="<<s.dr_gt_m<<'\n';
  if(!s.q.empty())std::cout<<"Dr_over_M_min="<<f1::outdec(s.q.front())
    <<" median="<<f1::outdec(s.q[s.q.size()/2])<<" max="<<f1::outdec(s.q.back())<<'\n';
  std::cout<<"prior_L1_256="<<before<<" final_L1_256="<<after<<'\n';
  std::cout<<"prior_L1="<<f1::outdec(before)<<" final_L1="<<f1::outdec(after)<<'\n';
  std::cout<<"elapsed_seconds="<<std::fixed<<std::setprecision(3)<<s.seconds<<'\n';
  std::cout<<"NO_CERTIFICATE; conditional graph/tube hypotheses; no 3c-b run, jump or B-an/B-6 decision.\n";
  return s.unresolved?2:0;
 }catch(const std::domain_error& e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<'\n';return 2;}
 catch(const std::exception& e){std::cerr<<"INPUT_FAIL: "<<e.what()<<'\n';return 3;}
}
#endif
