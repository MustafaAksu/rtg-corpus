// [SESSION] Strict source parser and coverage tests only, no scientific propagation.
#define DYAD_HORIZON_NO_MAIN
#include "horizon.cpp"
int main(int argc,char** argv){
 if(argc!=2)return 64;
 try{
  auto rows=horizon::load_checked_source(argv[1]);
  size_t kept=0;for(const auto& a:rows)kept+=a.kept;
  if(rows.size()!=400||kept!=144)throw std::runtime_error("fixture coverage changed");
  std::cout<<"HORIZON_SOURCE_PARSER_PASS 400/400 selected=144\n";
  return 0;
 }catch(const std::exception& e){std::cerr<<"PARSER_REJECTED: "<<e.what()<<'\n';return 3;}
}
