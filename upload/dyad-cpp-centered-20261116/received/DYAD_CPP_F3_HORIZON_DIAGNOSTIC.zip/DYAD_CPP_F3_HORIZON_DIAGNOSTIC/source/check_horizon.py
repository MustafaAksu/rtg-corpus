#!/usr/bin/env python3
"""[SESSION] Separate exact-integer audit for a bounded horizon/refine comparison.
Checks frozen selective source structure, full retained cover, geometrical partition,
necessary-disc intersection, integer-radius identities, and hull inclusion.
Does NOT prove that the analytic tube bound or invariant sectorial graph exists.
"""
from pathlib import Path
from collections import Counter,defaultdict
from argparse import ArgumentParser
import re

S=1<<256
SOURCE=('tile parent_subtile child parent_re_lo parent_re_hi parent_im_lo parent_im_hi '
        'child_re_lo child_re_hi child_im_lo child_im_hi '
        'necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
        'final_re_lo final_re_hi final_im_lo final_im_hi '
        'M2_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
NEW=('tile parent_subtile child new_subtile source_re_lo source_re_hi source_im_lo source_im_hi '
     'probe_re_lo probe_re_hi probe_im_lo probe_im_hi '
     'necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
     'final_re_lo final_re_hi final_im_lo final_im_hi '
     'M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
def cd(n,d):return -(-n//d)
def meet(a,b):
 c=(max(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),min(a[3],b[3]))
 return c if c[0]<=c[1] and c[2]<=c[3] else None
def cut(p,k):
 xl,xh,yl,yh=p;dx=xh-xl;dy=yh-yl;i,j=divmod(k,2)
 return (xl+(dx*i)//2,xl+cd(dx*(i+1),2),yl+(dy*j)//2,yl+cd(dy*(j+1),2))
def hull(boxes):
 assert boxes
 return (min(v[0] for v in boxes),max(v[1] for v in boxes),
         min(v[2] for v in boxes),max(v[3] for v in boxes))
def radius(b):
 c0=(b[0]+b[1])//2;c1=(b[2]+b[3])//2
 return max(abs(b[0]-c0),abs(b[1]-c0))+max(abs(b[2]-c1),abs(b[3]-c1))

def load_source(path):
 ls=Path(path).read_text().splitlines();assert ls and ls[0]==SOURCE
 rows={};parents=defaultdict(list)
 counts=Counter()
 for n,line in enumerate(ls[1:],1):
  w=line.split();assert len(w)==28,(n,len(w))
  a=list(map(int,w[:26]));tile,sub,ch=a[:3]
  parent=tuple(a[3:7]);child=tuple(a[7:11]);need=tuple(a[11:15]);fin=tuple(a[15:19]);
  M,Dr,D,r,lb,err,rad=a[19:26];ev,action=w[26:]
  key=(tile,sub,ch);assert key not in rows and 0<=tile<60 and 0<=sub<64 and 0<=ch<4
  assert ev=='VALID' and action in ('RETAINED','EXCLUDED')
  assert M>0 and Dr>=0 and D>=0 and r>=0 and lb>0 and err>=0 and rad>=0
  assert Dr==cd(D*r,S) and rad==err+cd((M+Dr)*S,lb)
  assert need[1]-need[0]==2*rad and need[3]-need[2]==2*rad
  assert child==cut(parent,ch)
  hit=meet(child,need)
  assert (hit is None)==(action=='EXCLUDED')
  assert fin==(hit if hit is not None else (0,0,0,0))
  rows[key]=(parent,child,fin,action)
  parents[(tile,sub)].append((ch,parent))
  counts[action]+=1
 assert len(rows)==400 and counts['EXCLUDED']==256 and counts['RETAINED']==144
 assert len(parents)==100
 for vv in parents.values():assert sorted(q for q,p in vv)==[0,1,2,3] and len(set(p for q,p in vv))==1
 return rows

def check(source,new,summary,mode):
 original=load_source(source)
 selected={key:a for key,a in original.items() if a[3]=='RETAINED'}
 ls=Path(new).read_text().splitlines();assert ls and ls[0]==NEW
 counts=Counter();seen=set();finals=[];parent_keys=defaultdict(set)
 for n,line in enumerate(ls[1:],1):
  w=line.split();assert len(w)==29,(n,len(w))
  a=list(map(int,w[:27]));tile,sub,ch,k=a[:4];key=(tile,sub,ch)
  assert key in selected and (tile,sub,ch,k) not in seen
  seen.add((tile,sub,ch,k));parent_keys[key].add(k)
  parent=tuple(a[4:8]);probe=tuple(a[8:12]);need=tuple(a[12:16]);fin=tuple(a[16:20]);
  M,Dr,D,r,lb,err,rad=a[20:27];ev,action=w[27:]
  assert action in ('RETAINED','EXCLUDED') and ev in ('VALID','UNRESOLVED')
  assert parent==selected[key][2]
  if mode=='refine2':assert 0<=k<4 and probe==cut(parent,k)
  else:assert k==0 and probe==parent
  if ev=='VALID':
   assert M>0 and Dr>=0 and D>=0 and r>=0 and lb>0 and err>=0 and rad>=0
   assert Dr==cd(D*r,S) and rad==err+cd((M+Dr)*S,lb)
   assert need[1]-need[0]==2*rad and need[3]-need[2]==2*rad
   hit=meet(probe,need)
   assert (hit is None)==(action=='EXCLUDED')
   assert fin==(hit if hit is not None else (0,0,0,0))
  else:
   assert action=='RETAINED' and fin==probe and need==probe
   assert all(v==0 for v in (M,Dr,D,r,lb,err,rad))
  counts[action]+=1;counts[ev]+=1
  if action=='RETAINED':finals.append(fin)
 assert len(parent_keys)==144 and set(parent_keys)==set(selected)
 assert all(v==set(range(4)) if mode=='refine2' else v=={0} for v in parent_keys.values())
 expected=576 if mode=='refine2' else 144
 assert len(seen)==expected and len(ls)-1==expected and counts['VALID']+counts['UNRESOLVED']==expected
 assert counts['RETAINED']+counts['EXCLUDED']==expected
 assert finals,'empty result cover is not a proof of graph nonexistence'
 old=radius(hull([v[2] for v in selected.values()]));new_rad=radius(hull(finals))
 assert new_rad<=old
 s=Path(summary).read_text()
 assert f'HORIZON_COMPARISON={mode};' in s and 'NO_CERTIFICATE' in s
 def number(field):
  mm=re.search(r'(?<!\S)'+re.escape(field)+r'=([0-9]+)(?=\s|$)',s);assert mm,field
  return int(mm.group(1))
 for name,expected_v in [('source_rows',400),('source_retained',144),('source_excluded',256),
   ('checked_retained',144),('evaluations',expected),('retained',counts['RETAINED']),
   ('excluded',counts['EXCLUDED']),('unresolved',counts['UNRESOLVED']),
   ('prior_L1_256',old),('final_L1_256',new_rad)]:
  assert number(name)==expected_v,(name,number(name),expected_v)
 print(f'HORIZON_STRUCTURE_PASS mode={mode} children={expected} parent_rows=144')
 print(f"evaluated={counts['VALID']} excluded={counts['EXCLUDED']} retained={counts['RETAINED']} unresolved={counts['UNRESOLVED']}")
 print('previous_L1_256=',old,'next_L1_256=',new_rad)
 print('previous_L1=%.12e next_L1=%.12e reduction=%.4f%%'%(old/S,new_rad/S,100*(1-new_rad/old)))
 print('SESSION_ONLY; conditional graph/tube premises; not certification or jump')

if __name__=='__main__':
 p=ArgumentParser();p.add_argument('source');p.add_argument('new');p.add_argument('summary');p.add_argument('mode',choices=('h3','h5','refine2'));a=p.parse_args();check(a.source,a.new,a.summary,a.mode)
