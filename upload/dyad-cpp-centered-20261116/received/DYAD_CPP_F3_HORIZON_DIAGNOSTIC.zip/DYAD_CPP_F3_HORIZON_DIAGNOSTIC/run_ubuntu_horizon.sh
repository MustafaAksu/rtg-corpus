#!/usr/bin/env bash
# [SESSION] Source-pinned 3-block vs further 2-block selective refinement.
# NO stage3c-b production, replay, certification, or point-jump calculation.
set -euo pipefail
if [[ $# -ne 11 ]]; then
 echo 'Usage: run_ubuntu_horizon.sh REPO V2_DIR BENCH_DIR F1_DIR F2_DIR SUB8_DIR SELECTIVE_PKG_DIR SUB8_FULL_RUN SELECTIVE_PI_RUN NEW_OUTPUT MODE(compare|h3|refine2|h5)' >&2
 exit 64
fi
repo=$(cd -- "$1" && pwd);v2=$(cd -- "$2" && pwd);bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd);f2=$(cd -- "$5" && pwd);sub8=$(cd -- "$6" && pwd)
selective=$(cd -- "$7" && pwd);sub8run=$(cd -- "$8" && pwd);prior=$(cd -- "$9" && pwd)
out=${10};mode=${11};src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
case "$mode" in compare|h3|refine2|h5) ;; *) echo 'Invalid mode; available: compare,h3,refine2,h5' >&2;exit 64;;esac
if [[ -e "$out" ]]; then
 if [[ ! -d "$out" || -n $(ls -A -- "$out") ]]; then echo 'STOP output must be new or empty' >&2;exit 64;fi
else mkdir -p -- "$out";fi
out=$(cd -- "$out" && pwd)
(cd "$src" && sha256sum -c SHA256SUMS.txt) > "$out/horizon_package_checks.txt"
for arg in "v2:$v2" "benchmark:$bench" "f1:$f1" "f2:$f2" "sub8:$sub8" "selective:$selective"; do
 name=${arg%%:*};root=${arg#*:};(cd "$root" && sha256sum -c SHA256SUMS.txt) > "$out/${name}_package_checks.txt"
done
(cd "$sub8run" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/source_sub8_run_checks.txt"
(cd "$prior" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/source_selective_run_checks.txt"
source_json="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
source_sha=6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e
sub8_sha=1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72
selective_sha=3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579
printf '%s  %s\n' "$source_sha" "$source_json" | sha256sum -c - > "$out/stage2_sha_check.txt"
printf '%s  %s\n' "$sub8_sha" "$sub8run/terms.tsv" | sha256sum -c - > "$out/sub8_terms_sha_check.txt"
printf '%s  %s\n' "$selective_sha" "$prior/selective_children.tsv" | sha256sum -c - > "$out/selective_children_sha_check.txt"
python3 "$sub8/source/check_terms.py" "$sub8run/terms.tsv" > "$out/source_sub8_terms_check.txt"
python3 "$sub8/source/check_completion.py" "$sub8run/summary.txt" "$sub8run/terms.tsv" 8 8 0 > "$out/source_sub8_completion_check.txt"
python3 "$selective/source/check_selective.py" "$sub8run/terms.tsv" "$prior/selective_children.tsv" "$prior/summary.txt" > "$out/source_selective_structure_check.txt"
python3 "$v2/source/import_phi40.py" --source "$source_json" --out "$out/phi40_outer_256.txt" > "$out/import.log"
cmp "$out/phi40_outer_256.txt" "$prior/phi40_outer_256.txt"
cmp "$out/phi40_outer_256.txt" "$sub8run/phi40_outer_256.txt"
{
 printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
 printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
 printf 'GCC=';g++ --version|head -1
 printf 'PYTHON=';python3 --version
 printf 'SOURCE_SHA256=%s\nSUB8_TERMS_SHA256=%s\nSELECTIVE_CHILDREN_SHA256=%s\n' "$source_sha" "$sub8_sha" "$selective_sha"
 printf 'MODE=%s; SESSION_ONLY; NO 3c-b production/replay, jump or certification\n' "$mode"
} > "$out/environment.txt"
common=(-std=c++17 -O2 -Wall -Wextra -pedantic -I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" -I "$selective/source")
g++ "${common[@]}" "$src/source/horizon.cpp" -o "$out/horizon"
g++ "${common[@]}" "$src/source/test_horizon_parser.cpp" -o "$out/test_horizon_parser"
python3 "$src/tests/test_horizon_structure.py" > "$out/structure_units.txt"
"$out/test_horizon_parser" "$prior/selective_children.tsv" > "$out/cpp_parser_unit.txt"
g++ -std=c++17 -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined \
 -I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" -I "$selective/source" \
 "$src/source/test_horizon_parser.cpp" -o "$out/test_horizon_parser_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 45s \
 "$out/test_horizon_parser_sanitized" "$prior/selective_children.tsv" > "$out/sanitizer_parser.txt" 2> "$out/sanitizer_stderr.txt"
set +e
"$out/horizon" >/dev/null 2>&1;rc_args=$?
"$out/horizon" "$source_json" "$prior/selective_children.tsv" h3 "$out/negative_transfer.tsv" >/dev/null 2>&1;rc_transfer=$?
"$out/horizon" "$out/phi40_outer_256.txt" "$source_json" h3 "$out/negative_source.tsv" >/dev/null 2>&1;rc_source=$?
"$out/horizon" "$out/phi40_outer_256.txt" "$prior/selective_children.tsv" bogus "$out/negative_mode.tsv" >/dev/null 2>&1;rc_mode=$?
set -e
if [[ "$rc_args,$rc_transfer,$rc_source,$rc_mode" != '64,3,3,3' ]]; then
 echo "STOP CLI negative results $rc_args,$rc_transfer,$rc_source,$rc_mode" >&2;exit 3
fi
printf 'CLI_NEGATIVE_PASS 64,3,3,3\n' > "$out/negative_controls.txt"
case "$mode" in compare) modes=(h3 refine2) ;; *) modes=("$mode") ;;esac
final_rc=0
for job in "${modes[@]}";do
 mkdir "$out/$job"
 set +e
 timeout -k 10s 1800s "$out/horizon" "$out/phi40_outer_256.txt" \
  "$prior/selective_children.tsv" "$job" "$out/$job/details.tsv" \
  > "$out/$job/summary.txt" 2> "$out/$job/stderr.txt"
 rc=$?
 set -e
 if [[ $rc -eq 0 || $rc -eq 2 ]]; then
  # A complete but unresolved campaign can still have structurally valid output.
  if [[ -s "$out/$job/summary.txt" ]]; then
   python3 "$src/source/check_horizon.py" "$prior/selective_children.tsv" \
    "$out/$job/details.tsv" "$out/$job/summary.txt" "$job" > "$out/$job/structure_check.txt" || { echo 'STOP checker' >&2; exit 3; }
  fi
 fi
 if [[ $rc -ne 0 ]]; then
  echo "NONPASS $job exit=$rc; preserve partial files; no completed PASS" >&2
  if [[ $rc -eq 2 || $rc -eq 124 || $rc -eq 137 ]]; then final_rc=2
  else final_rc=3; fi
 fi
 (cd "$out/$job" && find . -maxdepth 1 -type f ! -name SHA256SUMS.txt -printf '%f\0' | sort -z |xargs -0 -r sha256sum >SHA256SUMS.txt)
 if [[ $final_rc -eq 3 ]];then break;fi
done
if [[ "$mode" == compare && $final_rc -eq 0 ]]; then
 python3 "$src/source/compare_modes.py" "$out/h3/summary.txt" "$out/refine2/summary.txt" > "$out/comparison.txt"
fi
(cd "$out" && find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name horizon ! -name test_horizon_parser ! -name test_horizon_parser_sanitized -printf '%f\0' |sort -z|xargs -0 -r sha256sum >RUN_SHA256SUMS.txt)
for job in "${modes[@]}";do cat "$out/$job/summary.txt";cat "$out/$job/structure_check.txt" 2>/dev/null||true; if [[ $final_rc -eq 3 ]];then break;fi
done
if [[ "$mode" == compare && $final_rc -eq 0 ]];then cat "$out/comparison.txt";fi
if [[ $final_rc -eq 3 ]];then echo 'INPUT_FAIL SESSION_ONLY; preserved incomplete output';exit 3;fi
if [[ $final_rc -ne 0 ]];then echo 'INCONCLUSIVE SESSION_ONLY; not a certification';exit 2;fi
echo 'PASS CONDITIONAL SESSION HORIZON COMPARISON ONLY; not a certificate or jump.'
