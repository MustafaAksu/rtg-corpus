# Local proxy-only run results (SESSION; not the pinned Stage-2 source)

**Input and provenance.** Recreated the complete 8×8/8 second-stage diagnostic with the earlier `approximate_18sig_coefs.txt` values (per-complex-component padding ±1e-15; c padding ±1e-30), not the pinned Stage2 transfer. Diagnostic: 1,024/1,024 rows, 924 `EXCLUDED`, 100 `RETAINED`; exact integer and completion checkers PASS. Recreated selective F2 on the frozen proxy input, replayed all 100 retained source parents, 400/400 children, 256 `EXCLUDED`, 144 `RETAINED`, 0 unresolved. Proxy source L1 radius `2.501193769493e-4`.

| Mode on same 144 boxes | New evaluations | Excluded | Retained | Unresolved | Median Dr/Mk | End L1 radius | Seconds, Debian/GCC 14.2 |
|---|---:|---:|---:|---:|---:|---:|---:|
| horizon=3, no further partition | 144/144 | 4 | 140 | 0 | 8.392210 | `2.499549586971e-4` | 45.796 |
| horizon=2, 2×2 split of retained boxes | 576/576 | 252 | 324 | 0 | 0.143574 | `1.707140211120e-4` | 92.989 |

Both independent exact-integer structure checkers PASS, with zero row/coverage identity failures. The extra 2×2 refinement reduced the prior L1 radius by approximately **31.747%**, while the 3-block horizon without a further split decreased it by approximately **0.0657%**. At this proxy scale the derivative spread became dominant again at k=3: `Dr>M3` in 140/144 rows. This reverses the owner's expectation that a bare horizon increase necessarily beats partitioning; it is only a **negative feasibility finding for the current evaluator and these initial boxes**, not a result on the actual invariant curve.

**Cost accounting.** Each mode also replays the 144 earlier F2-retained children for exact source binding. The measured times include that same replay cost; `refine2` has 576 new evaluations vs 144 for `h3`, not merely an equal-cost comparison. The `h5` option was intentionally NOT run after the negative `h3` proxy result.

**Acceptance restriction.** None of these proxy conclusions may be substituted for the PI's source-backed 80-digit experiment. The real Ubuntu script deliberately gates the original Stage2 JSON by SHA-256 and the immutable source logs by their own SHA-256. A 3-block failure to enclose keeps the prior box and returns `INCONCLUSIVE`, not a false exclusion. The next scientific decision follows only after independent owner review of the actual pinned run and cost/output comparison.
