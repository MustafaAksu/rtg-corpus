#!/usr/bin/env python3
"""[SESSION] Synthetic fixture for source/child record checking, not a DYAD run."""
from pathlib import Path
import tempfile,sys,subprocess
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import check_horizon as H
S=1<<256
HEADER_SOURCE=H.SOURCE; HEADER_NEW=H.NEW

def txt_b(b):return ' '.join(map(str,b))
def make_source():
 rows=[HEADER_SOURCE];retained=[]
 for p in range(100):
  i=p//64;j=p%64
  # All parent rectangles disjoint, 8x8 exact-dyadic integers.
  parent=(p*20,p*20+8,p*5,p*5+8)
  for k in range(4):
   child=H.cut(parent,k)
   want=(p*4+k)<144
   cx=(child[0]+child[1])//2;cy=(child[2]+child[3])//2
   if not want:cx+=10000000
   need=(cx-1,cx+1,cy-1,cy+1)
   hit=H.meet(child,need);assert bool(hit)==want
   fin=hit if want else (0,0,0,0)
   if want:retained.append((i,j,k,fin))
   rows.append(f'{i} {j} {k} '+txt_b(parent)+' '+txt_b(child)+' '+txt_b(need)+' '+txt_b(fin)+f' 1 0 0 0 {S} 0 1 VALID '+('RETAINED' if want else 'EXCLUDED'))
 return '\n'.join(rows)+'\n',retained

def make_child(source,mode):
 selected=H.load_source(source);rows=[HEADER_NEW];out=[]
 for (i,j,k),(_,_,parent,act) in selected.items():
  if act!='RETAINED':continue
  parts=[parent] if mode!='refine2' else [H.cut(parent,z) for z in range(4)]
  for zz,probe in enumerate(parts):
   cx=(probe[0]+probe[1])//2;cy=(probe[2]+probe[3])//2
   if (i+j+k+zz)%11==0:cx+=10000000
   need=(cx-2,cx+2,cy-2,cy+2)
   hit=H.meet(probe,need)
   fin=hit if hit else (0,0,0,0)
   if hit:out.append(hit)
   rows.append(f'{i} {j} {k} {zz} '+txt_b(parent)+' '+txt_b(probe)+' '+txt_b(need)+' '+txt_b(fin)+f' 2 0 0 0 {S} 0 2 VALID '+('RETAINED' if hit else 'EXCLUDED'))
 old=H.radius(H.hull([v[2] for v in selected.values() if v[3]=='RETAINED']))
 new=H.radius(H.hull(out));assert new<=old
 summary=f'MODE=SESSION_CONDITIONAL; HORIZON_COMPARISON={mode}; SOURCE=SELECTIVE_F2\n'+f'source_rows=400 source_retained=144 source_excluded=256 checked_retained=144\n'+f'evaluations={len(rows)-1} retained={len(out)} excluded={len(rows)-1-len(out)} unresolved=0\n'+f'prior_L1_256={old} final_L1_256={new}\nNO_CERTIFICATE\n'
 return '\n'.join(rows)+'\n',summary

def run():
 with tempfile.TemporaryDirectory() as t:
  d=Path(t);source,keys=make_source();assert len(keys)==144
  (d/'src.tsv').write_text(source);assert len(H.load_source(d/'src.tsv'))==400
  for mode in ('h3','refine2','h5'):
   new,summary=make_child(d/'src.tsv',mode)
   (d/'new.tsv').write_text(new);(d/'summary.txt').write_text(summary)
   H.check(d/'src.tsv',d/'new.tsv',d/'summary.txt',mode)
   print('POSITIVE',mode)
   # Five independent structural negative controls, rejection must be observed.
   for mutation in range(5):
    a=(d/'new.tsv').read_text().splitlines()
    if mutation==0:a.pop()
    elif mutation==1:a[-1]=a[-2]
    elif mutation==2:
     v=a[1].split();v[4]=str(int(v[4])+1);a[1]=' '.join(v)
    elif mutation==3:
     v=a[1].split();v[26]=str(int(v[26])+1);a[1]=' '.join(v)
    elif mutation==4:
     v=a[1].split();v[-1]='EXCLUDED' if v[-1]=='RETAINED' else 'RETAINED';a[1]=' '.join(v)
    (d/'bad.tsv').write_text('\n'.join(a)+'\n')
    try:H.check(d/'src.tsv',d/'bad.tsv',d/'summary.txt',mode)
    except (AssertionError,ValueError,KeyError):pass
    else:raise AssertionError('mutation not rejected: '+str((mode,mutation)))
   print('NEGATIVES',mode,5)
  # Source invalidity gate.
  bad=source.splitlines();bad.pop();(d/'bad_source.tsv').write_text('\n'.join(bad)+'\n')
  try:H.load_source(d/'bad_source.tsv')
  except AssertionError:pass
  else:raise AssertionError('source truncation passed')
  print('SOURCE_TRUNCATION_REJECTED; STRUCTURE_TESTS_PASS')
if __name__=='__main__':run()
