#!/usr/bin/env python3
"""[SESSION] Proxy only: convert earlier 18-significant-digit approximate complex coefficients to outward dyadic boxes.
The SHA string is a format discriminator; not a claim of same source identity.
"""
from fractions import Fraction
from decimal import Decimal
from pathlib import Path
import argparse
S=1<<256
p=argparse.ArgumentParser();p.add_argument('approx');p.add_argument('out');x=p.parse_args()
lines=Path(x.approx).read_text().splitlines(); assert len(lines)==40
co={};c=None
for line in lines:
 a=line.split();assert len(a)==3
 if a[0]=='C': c=a[1:]
 else:co[int(a[0])]=a[1:]
assert c is not None and len(co)==39 and set(co)==set(range(2,41))
def ep(s,pad):
 v=Fraction(Decimal(s)); pad=Fraction(Decimal(pad));a=v-pad;b=v+pad
 return (a.numerator*S//a.denominator,-(-b.numerator*S//b.denominator))
rows=['DYAD_PHI40_OUTER_V1','6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e']
for k in range(2,41):
 rows.append(' '.join(map(str,[k,*ep(co[k][0],'1e-15'),*ep(co[k][1],'1e-15')])))
rows.append('C '+' '.join(map(str,[*ep(c[0],'1e-30'),*ep(c[1],'1e-30')])))
rows.append('END')
Path(x.out).write_text('\n'.join(rows)+'\n')
print('PROXY_ONLY 18sig, NOT pinned Stage2; 39 coefficients')
