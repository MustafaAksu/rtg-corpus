# Local validation receipt — SESSION, 19 November 2026

- `mv_resume.cpp` and both test binaries: compile under C++17, `-Wall -Wextra -Werror -pedantic` PASS.
- Independent Python structural checker: 1600-row *synthetic* old log and its 897 final leaves, 1600-row *synthetic* MV pilot, 897-row resumed stage with budget 2 (INCONCLUSIVE), and 897-row resumed stage with budget 897 (READY) PASS.
- Deliberate invalid records: 11 frozen events, 7 frozen frontier and 10 new pilot mutations = **28 rejected** by the source parser/independent pilot checker.
- The same synthetic test battery under ASan/UBSan source-parser binary: PASS; no sanitizer failure.
- Additional bounded 18-digit coefficient proxy only: `k=4`, fibre `[-1/200000,1/200000]^2` (dyadic enclosing rectangle), original base tube M = `3978076620196768317495363533672178455845791915792611571076861668140280744 / 2^256`, refined MV tube M = `901390669304254161943087291778045979919865656451662574722494332929577550 / 2^256`, ratio ≈0.2265896. **Not Stage 2 source-backed; not a proof of effectiveness on the 1600 real boxes**.
- Unchanged dependency sources from the previously reviewed ZIPs. New file only includes them at compile time; source hashes are checked by the Ubuntu runner.
- No complete real Stage2 1600-event experiment or continuation was executed locally; none is claimed.
