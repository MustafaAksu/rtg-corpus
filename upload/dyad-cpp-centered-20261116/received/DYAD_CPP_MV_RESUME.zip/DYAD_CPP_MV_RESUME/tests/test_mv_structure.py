#!/usr/bin/env python3
"""[SESSION] Synthetic source, parser and independent integer auditor controls only."""
import sys,subprocess,tempfile,random
from collections import deque
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import check_mv_resume as chk
S=1<<256

def old_source(root):
 root=Path(root);root.mkdir(parents=True,exist_ok=True)
 E=root/'events.tsv';F=root/'final_frontier.tsv';I=root/'initial.tsv'
 q=deque((f'a{x}',0,(-S//4,S//4,-S//4,S//4)) for x in range(324))
 events=[];kept=[];initial=list(q);n0=n1=0
 while q:
  name,d,b=q.popleft()
  if d==0:
   split=n0<319;excluded=319<=n0<323;n0+=1
  else:
   split=False;excluded=n1<380;n1+=1
  if excluded:
   # A disjoint but internally sound necessary disk of radius S/8.
   rad=S//8;n=(4*S-rad,4*S+rad,4*S-rad,4*S+rad)
   fin=(0,0,0,0);act='EXCLUDED'
  else:
   rad=S;n=(-S,S,-S,S);fin=b;act='SPLIT' if split else 'RETAINED'
  M=rad;Dr=0;D=0;r=0;lb=S;e=0;R=rad
  line=' '.join(map(str,[4,name,d,*b,*n,*fin,M,Dr,D,r,lb,e,R,'VALID',act]))
  events.append(line)
  if split:
   for j in range(4):q.append((name+'/'+str(j),d+1,chk.cut(fin,j)))
  elif not excluded:kept.append((name,d,fin))
 assert len(events)==1600 and n0==324 and n1==1276 and len(kept)==897
 E.write_text(chk.EVHEADER+'\n'+'\n'.join(events)+'\n')
 F.write_text(chk.FH+'\n'+'\n'.join(' '.join(map(str,[name,d,*b])) for name,d,b in kept)+'\n')
 I.write_text(chk.FH+'\n'+'\n'.join(' '.join(map(str,[name,d,*b])) for name,d,b in initial)+'\n')
 return E,F

def pilot_from_old(old,out,count):
 ev=chk.events(old);rows=[]
 for rec in ev[:count]:
  _,name,d,b,n,fin,M,Dr,D,r,lb,e,R,_,act=rec
  # Effective M chosen half of old M and MV subbox subset of raw X,
  # assuming Xraw [-3,3]^2, Xmv [-2,2]^2, Xeff = [-2,2]^2.
  m=M//2;newR=e+chk.ceil((m+Dr)*S,lb)
  centre=((n[0]+n[1])//2,(n[2]+n[3])//2)
  newN=(centre[0]-newR,centre[0]+newR,centre[1]-newR,centre[1]+newR)
  hit=chk.intersect(b,newN)
  vals=[name,d,M,m,m,m,Dr,D,r,lb,e,R,newR,0,
        *(-3*S,3*S,-3*S,3*S),*(-2*S,2*S,-2*S,2*S),*(-2*S,2*S,-2*S,2*S),
        *newN,*(hit if hit is not None else (0,0,0,0)),act,'RETAINED' if hit else 'EXCLUDED']
  rows.append(' '.join(map(str,vals)))
 out.write_text(chk.PH+'\n'+'\n'.join(rows)+'\n')
 return out

def resume_synthetic(old,front,out,number=1,kind='budget'):
 kept=chk.front(front);p=Path(out);p.mkdir(exist_ok=True,parents=True)
 i=p/'initial_frontier.tsv';E=p/'events.tsv';T=p/'stages.tsv';F=p/'final_frontier.tsv'
 i.write_text(Path(front).read_text())
 # no new split in fixture; either choose not to split by Dr=0 or exhaust budget
 budget=number
 lines=[];fin=[];evals=0;pending=0;ret=0;valid_no_split=0
 for name,d,b in kept:
  if evals>=budget:
   lines.append(' '.join(map(str,[4,name,d,*b,*b,*b,0,0,0,0,0,0,0,'NOT_EVALUATED','BUDGET_KEEP'])));pending+=1
  else:
   rad=S;n=(-S,S,-S,S);M=rad;Dr=0;D=0;r=0;lb=S;e=0;R=rad
   lines.append(' '.join(map(str,[4,name,d,*b,*n,*b,M,Dr,D,r,lb,e,R,'VALID','RETAINED'])));evals+=1;ret+=1
  fin.append((name,d,b))
 E.write_text(chk.EVHEADER+'\n'+'\n'.join(lines)+'\n')
 T.write_text(chk.SH+'\n'+ ' '.join(map(str,[4,897,evals,0,0,ret,0,pending,0,0,0,
                                       chk.hrad([b for _,_,b in kept]),chk.hrad([b for _,_,b in kept]),0,0,
                                       'BUDGET' if pending else 'READY']))+'\n')
 F.write_text(chk.FH+'\n'+'\n'.join(' '.join(map(str,[name,d,*b])) for name,d,b in fin)+'\n')
 return p,budget

def main():
 parser=sys.argv[1]
 with tempfile.TemporaryDirectory() as tmp:
  p=Path(tmp);ev,f=old_source(p)
  r=subprocess.run([parser,str(ev),str(f)],capture_output=True,text=True)
  assert r.returncode==0,(r.returncode,r.stdout,r.stderr)
  r=subprocess.run([parser,str(ev)+'!bad',str(f)],capture_output=True)
  assert r.returncode==3
  negative=0
  for i in range(11):
   arr=ev.read_text().splitlines()
   if i==0:arr[0]+='x'
   elif i==1:arr.pop()
   elif i==2:arr.append(arr[-1])
   else:
    j=1+i*9;xs=arr[j].split();xs[3+i%4]=str(int(xs[3+i%4])+1);arr[j]=' '.join(xs)
   bad=p/'bad_events.tsv';bad.write_text('\n'.join(arr)+'\n')
   r=subprocess.run([parser,str(bad),str(f)],capture_output=True)
   assert r.returncode==3,(i,r.returncode);negative+=1
  for i in range(7):
   arr=f.read_text().splitlines()
   if i==0:arr[0]+='x'
   elif i==1:arr.pop()
   elif i==2:arr.append(arr[-1])
   else:
    j=1+i;xs=arr[j].split();xs[2+i%4]=str(int(xs[2+i%4])+1);arr[j]=' '.join(xs)
   bad=p/'bad_front.tsv';bad.write_text('\n'.join(arr)+'\n')
   r=subprocess.run([parser,str(ev),str(bad)],capture_output=True)
   assert r.returncode==3,(i,r.returncode);negative+=1
  new=pilot_from_old(ev,p/'pilot.tsv',1600);chk.check_pilot(ev,new,1600)
  for i in range(10):
   arr=new.read_text().splitlines();j=2+i*11;w=arr[j].split();positions=[2,5,6,8,9,12,14,22,26,30];w[positions[i]]=str(int(w[positions[i]])+(10*S if i in (6,7,8,9) else 1));arr[j]=' '.join(w)
   bad=p/'bad_pilot.tsv';bad.write_text('\n'.join(arr)+'\n')
   try:chk.check_pilot(ev,bad,1600)
   except AssertionError:negative+=1
   else:raise AssertionError('bad pilot accepted '+str(i))
  for budget in (2,897):
   sub,limit=resume_synthetic(ev,f,p/('resume'+str(budget)),budget)
   chk.check_resume(f,sub/'initial_frontier.tsv',sub/'events.tsv',sub/'stages.tsv',sub/'final_frontier.tsv',limit,2,4096,4)
  print(f'MV_STRUCTURE_UNIT_PASS parser=1 pilot_rows=1600 resume_budget=(2,897) negative_mutations={negative}')
  print('SESSION_ONLY: structural fixtures, not actual F4 numerics')
if __name__=='__main__':main()
