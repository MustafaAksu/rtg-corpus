#!/usr/bin/env bash
# [SESSION] Byte-exact incoming ZIP and PI-run output on two distinct upload branches.
set -euo pipefail
if [[ $# -ne 5 || ( "$1" != package && "$1" != results ) || "$5" != --push ]];then
 echo 'Usage: upload_mv_evidence.sh package REPO EXACT_ZIP EXPECTED_SHA256 --push' >&2
 echo '   or upload_mv_evidence.sh results REPO OUTPUT_DIRECTORY - --push' >&2
 exit 64
fi
kind=$1; repo=$(cd -- "$2" && pwd); input=$(realpath -- "$3")
if [[ "$kind" == package ]];then
 [[ -f "$input" && "$4" =~ ^[a-f0-9]{64}$ ]] || exit 3
 printf '%s  %s\n' "$4" "$input" | sha256sum -c - >/dev/null
 branch='upload/dyad-cpp-mv-resume-20261119'
else
 [[ -d "$input" ]] || exit 3
 (cd "$input" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
 (cd "$input/driver" && sha256sum -c SHA256SUMS.txt >/dev/null)
 [[ -s "$input/driver/structure_check.txt" ]] || { echo 'STOP: missing checked run/pilot' >&2;exit 3; }
 branch='upload/dyad-cpp-mv-resume-results-20261119'
fi
git -C "$repo" fetch origin main >/dev/null
if git -C "$repo" show-ref --verify --quiet "refs/heads/$branch" || \
   git -C "$repo" show-ref --verify --quiet "refs/remotes/origin/$branch";then
 echo "STOP: intake branch already exists: $branch" >&2;exit 3
fi
wt=$(mktemp -d /tmp/dyad-mv-receipt-XXXXXX);rmdir "$wt"
cleanup(){ git -C "$repo" worktree remove --force "$wt" >/dev/null 2>&1 || true; }
trap cleanup EXIT
git -C "$repo" worktree add -b "$branch" "$wt" origin/main >/dev/null
if [[ "$kind" == package ]];then
 mkdir -p "$wt/$branch/received"
 cp -p -- "$input" "$wt/$branch/received/DYAD_CPP_MV_RESUME.zip"
 (cd "$wt/$branch/received" && sha256sum DYAD_CPP_MV_RESUME.zip > SHA256SUMS.txt)
else
 mkdir -p "$wt/$branch/pi-run"
 cp -a -- "$input/." "$wt/$branch/pi-run/"
 (cd "$wt/$branch/pi-run" && sha256sum -c RUN_SHA256SUMS.txt >/dev/null)
fi
(cd "$wt";git add -- "$branch";git commit -m "upload/dyad: receive untouched mean-value $kind SESSION" >/dev/null
 echo "BRANCH=$branch";echo "COMMIT=$(git rev-parse HEAD)"
 git push origin "refs/heads/$branch:refs/heads/$branch")
echo 'UPLOAD_ONLY; no main merge, tag, adopted claim, or 3c-b authorization'
