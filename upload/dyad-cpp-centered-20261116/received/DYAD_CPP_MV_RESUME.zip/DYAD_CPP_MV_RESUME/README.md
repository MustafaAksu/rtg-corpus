# DYAD OPEN 20 — mean-value base bound and checkpoint continuation (SESSION)

## Scope and decision

This is a **separate, conditional development experiment**, not a modification of any adopted DYAD DSN, existing F1/F2/F3/arithmetic sources, certificate, proof of a sectorial invariant graph, jump, or authorization to run stage 3c-b. It responds to owner Addendum 5 at PR #305 head `16664d73af5df858fc53086647f040f2858063ea`. The new source includes the unchanged, reviewed `adaptive.cpp` by C++ inclusion; it does not modify the old k=4 run or any frozen evidence.

The **first step is the pilot**: recompute all **1600** original k=4 work-box evaluations from their exact event log, verify each original value/derivative/C1–C2 field bit-for-bit, and compare the original base enclosure with a new centred base enclosure. A second, *independently invoked* `resume` mode consumes the complete old 897-box final frontier **without re-running the original 1600 tasks**. `resume` re-evaluates those 897 valid boxes with the new, potentially tighter k=4 base bound, then may split them and eventually advance through k up to `MAX_K` if its per-horizon refinement rule completes. It does **not** silently use the pilot results as a new adopted source. Always retain the original source files.

## Mathematical enclosure

For a whole-disc derivative enclosure `A_k = whole.a.d`, a centred image enclosure `x_{k,c} = point.a.v`, and a candidate disc `B(c,r)`, holomorphy on the entire disc and convexity give, for any `d ∈ B(c,r)`:

\[
 x_k(d)-x_k(c)= (d-c)\int_0^1 x_k'(c+t(d-c))\,dt,
 \quad |x_k(d)-x_k(c)| \le \sup_{A_k}|z|\,r.
\]

The C++ arithmetic computes `Aabs = centered::abs_upper(whole.a.d)` with directed integer square-root rounding, then `rad = ceil(Aabs * r / 2^256)` in 256-bit scaled integers. Let

- `X_whole = whole.a.v`;
- `X_MV = inflate(point.a.v, rad)` (rectangular **outer** enclosure of the Euclidean disc);
- `X_intersect = X_whole ∩ X_MV`, required nonempty.

Then every feasible base lies in `X_intersect`. The tube upper bounds are evaluated independently on `X_whole`, `X_MV`, and `X_intersect`, and their **minimum** is also a valid upper bound on `R_0` over `X_intersect ∩ D_0`. Optional bounds that raise `domain_error` fall back to the already-valid old bound, **never** exclude a candidate. If the two actual base enclosures are disjoint, execution halts as an arithmetic inconsistency (exit 3), **not** as a proof that no candidate exists. This is a C1–C2 contractor with only its `M_k` input refined; original fibre derivative, tangent and original lift are unchanged.

## Frozen dependency manifest

**Seven mandatory SHA256 source/file gates**, with extra per-package and per-run manifests:

1. Stage2 JSON: `6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e`.
2. 8×8 / 1024 F2 term log: `1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72`.
3. 400 selective F2 children: `3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579`.
4. 576 F2 refine2 children: `bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a`.
5. 1296 F3 h3_split2 children: `3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325`.
6. Original adaptive k4 **1600-event** log: `276701a085aefcc528290e496a721f83080780fabab5aafd78f3f7b3cc0a8a1f`.
7. Original adaptive k4 **897-box** frontier: `4cb41a4f4fa860763f1f992acd7caeee53f48acf9e9e335d2263281e453d5c2f`.

These pin inherited 924 + 256 + 252 + 972 + 384 prior exclusions. The 1600 old records also carry SPLIT internal-node status, not retained leaves. `replay_frozen_events` reconstructs the entire prior FIFO split history and checks **exact** equality with the final 897-box frontier; it cannot re-label previously excluded boxes.

## Two modes (not automatic successors)

**`pilot`**: all 1600 frozen events, original computation verified against all 7 exact fields and original necessary boxes, new `M4` and necessary-disc field computed for the same original probe. TSV has exact integer fields for old/MV/intersection base enclosures, new disc and intersection, and old/new actions; separate checker validates exact subset properties and disc formulas. A shorter `LIMIT` results in exit 2 **INCONCLUSIVE**, never full PASS.

**`resume`**: frozen 897 boxes (including one old depth-0 and 896 old depth-1 leaves). They retain their existing depth for k=4; depth resets only on *new* horizon k≥5. A valid candidate is excluded **only** when its box misses the C1–C2 necessary-disc box. On high `2Dr > M_k`, the **post-contractor** rectangle may be subdivided 2×2 at the same horizon, subject to budget/frontier/depth. `domain_error` retains the current rectangle (`UNRESOLVED`). Other exceptions abort without a PASS. New summary records **two separate counters**: `budget_pending` for never-evaluated boxes and `budget_valid_no_split` for already-evaluated boxes held because the four-child reservation would exceed budget. Every stage preserves the complete candidate cover. If any budget, refinement cap or domain stop occurs, do **not** auto-advance k. With `MAX_K` reached, exit 0 denotes only completion of the bounded session experiment, not proof/adoption.

There is no restart from within *this new* run's own partially completed stage; `resume` starts from the **original** frozen k=4 checkpoint, not an arbitrary later checkpoint. For a second run use a fresh output directory and keep the old one unchanged. This is the documented limit of the resume functionality.

## Ubuntu commands

Place `DYAD_CPP_MV_RESUME.zip` in `/root/`, verify its announced SHA256, and unzip with `-n`.

Argument order is identical for both modes:

```
bash /root/DYAD_CPP_MV_RESUME/run_ubuntu_mv_resume.sh \
 /root/rtg-corpus \
 /root/DYAD_CPP_PHI40_B_EVALUATOR_DIAGNOSTIC_V2 \
 /root/DYAD_CPP_FORWARD_METHOD_BENCHMARK \
 /root/DYAD_CPP_F1_TUBE_CONTRACTOR \
 /root/DYAD_CPP_F2_TUBE_CONTRACTOR \
 /root/DYAD_CPP_F2_TERM_AUDIT_SUB8 \
 /root/DYAD_CPP_F2_SELECTIVE_REFINE \
 /root/DYAD_CPP_F3_HORIZON_DIAGNOSTIC \
 /root/DYAD_CPP_F3_ON_REFINED_324 \
 /root/DYAD_CPP_ADAPTIVE_HORIZON \
 /root/dyad-f2-term8-full \
 /root/dyad-f2-selective-run \
 /root/dyad-horizon-compare \
 /root/dyad-f3-refined-compare \
 /root/dyad-adaptive-k4-k6 \
 /root/dyad-mv-base-pilot \
 pilot 4 0 0 4096 1600
```

Run this **first**; inspect `driver/summary.txt` and `driver/structure_check.txt`. It reuses original source hashes, dynamically replays each candidate on the real Stage2 coefficient transfer, and computes M4 on precisely the old 1600 boxes. The old results remain unchanged.

A **separate optional** `resume` command uses the same paths but changes the output directory and the last five arguments; for a bounded pilot:

```
 /root/dyad-mv-resume-k4  resume 4 1800 2 4096 1600
```

This new evaluation **revisits the 897 surviving boxes only**; it does not recompute the original 1600-event campaign. `exit=2` is expected when budget/cap limits refinement; the new 256-bit exact cover is still recorded. Each mode has a 5400-second watchdog and full independent integer check before any structurally complete claim.

**Results**: `driver/base_pilot.tsv` for pilot; `driver/initial_frontier.tsv`, `driver/events.tsv`, `driver/stages.tsv`, `driver/final_frontier.tsv` for resume. Both contain `driver/summary.txt`, `driver/structure_check.txt`, root and nested SHA256 manifests, source/version fingerprints and explicit `SESSION_ONLY` caveats.

No real Stage2 test results have yet been produced here; only local structural fixtures and a *separate 18-digit coefficient proxy smoke test* (not source-backed) have been run.

## GitHub intake

`upload_mv_evidence.sh` places the incoming unchanged ZIP on `upload/dyad-cpp-mv-resume-20261119` and a run directory on `upload/dyad-cpp-mv-resume-results-20261119` (one output run per intake). The helper refuses already existing destination branches, so do not reuse it without a new branch/receipt. Neither helper merges, tags, changes a DSN or authorizes 3c-b. Owner should review R1–R6 and reproduce source-backed results on a second machine.
