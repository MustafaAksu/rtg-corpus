# Owner review request — mean-value base and adaptive checkpoint (SESSION)

**Prepared successor, not adopted:** `DYAD_CPP_MV_RESUME.zip`. Governing source PR #305 Addendum 5, head `16664d73af5df858fc53086647f040f2858063ea`, originally owner-reviewed A1–A6. All previous canonical owner claims and all supplied old results are unmodified.

## R1 — analytic inclusion and directed arithmetic

Confirm the **holomorphic** x_k(d) along the convex evaluation disc and derivative enclosure `whole.a.d` on every point of the disc. Verify the 256-bit Euclidean bound `abs_upper` and integer ceiling, centre value's interval semantics, the intersection `Xwhole ∩ Xmv`, and that the minimum of separately valid `ForwardTube::upper` values is still valid for Xintersect∩D0. Domain failures of optional subbounds retain the valid raw bound. Disjoint computed enclosures must abort (never certify emptiness).

## R2 — old k4 reproducibility and source pins

Verify seven SHA-256 pins, nested package/run manifests, original 1600-event FIFO and 897-frontier completeness and that the 792 original source survivors (144 + 324 + 324) replay exactly before any pilot/resume calculation. In pilot, validate each original M4, D, Dr, r, |b4|, recentering error, radius, necessary box and action, with exact integers; changed new M4 must not falsify an old exclusion.

## R3 — checked pilot and changes to the contractor

For all original 1600 input discs, record `M4_raw`, `M4_mv`, `M4_intersection`, `M4_effective` with base enclosure endpoints and the two necessary discs. Check that the new disc is a subset of the old disc and the new intersection is a subset of the original candidate rectangle. Review input source identity and any true numerical M4 reduction, keeping [NUM] distinct from proof/adoption.

## R4 — exact frontier continuation

`resume` must begin from **exactly the 897 original final rectangles** with their prior depth (one at depth 0, 896 at depth 1), preserving source order, never replaying old 1600 dynamics. At k=4 re-evaluate them using the new base bound, and split only post-contractor intersections; for k≥5 reset depth and re-evaluate with fresh M_k and original unreset tangent. Ensure all budget, cap and domain paths retain candidates and no heuristic threshold ever excludes a candidate.

## R5 — independent integer checker and budget accounting

Repeat C1–C2 integer identities, exact dyadic partition coverage, FIFO chronology and hull inclusion on pilot/resume outputs. Distinguish never-evaluated `budget_pending` and already-evaluated high-ratio `budget_valid_no_split`. Budget and hard timeout must never yield a misleading development PASS. Check advertised numeric timeout and result statuses, no missing output treated as valid.

## R6 — byte-level replay and scope

Verify source ZIP SHA-256 and all manifests, rerun actual SHA-pinned Stage2 pilot and (if selected) a bounded resume, compare deposited TSVs byte-for-byte except environment/speeds/binary artifacts. Same-engine replay is not independent mathematical regeneration. The still-unproved sectorial graph/tube hypotheses for k≥4, point jump, 3c-b and B-an/B-6 stay outside this experiment. O-1 PR #312 is a separate merge-ready item; no merge or tag is authorized by this request.

**Completion criterion:** Explicit owner verdict *development session only*, negative findings preserved, PI decides subsequent scientific and release actions.
