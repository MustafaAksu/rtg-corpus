// [SESSION] Proxy-only bounded arithmetic smoke test for the new mean-value enclosure.
#define DYAD_MV_NO_MAIN
#include "mv_resume.cpp"
int main(int argc,char**argv){
 if(argc!=2)return 64;
 try{
  Data data=read_data(argv[1]);f1::ForwardTube tube(data.c);
  const Z r=cd(SCALE,Z(200000));
  const C B(I(-r,r),I(-r,r));
  mvresume::Work w{"proxy0",B,0};
  auto m=mvresume::measure(w,4,data,tube);
  if(!encloses(m.base.raw,m.base.effective)||m.base.effective_M>m.base.raw_M||
     !encloses(m.oldNd.box(),m.newNd.box()))throw std::runtime_error("enclosure test failed");
  std::cout<<"MV_PROXY_ARITHMETIC_PASS k=4 old_M_256="<<m.base.raw_M
           <<" new_M_256="<<m.base.effective_M
           <<" ratio="<<f1::outdec(cd(m.base.effective_M*SCALE,m.base.raw_M))<<"\n";
  std::cout<<"PROXY_18_SIG_ONLY; NO REAL SOURCE VALIDATION\n";
  return 0;
 }catch(const std::exception&e){std::cerr<<"MV_PROXY_FAIL: "<<e.what()<<'\n';return 3;}
}
