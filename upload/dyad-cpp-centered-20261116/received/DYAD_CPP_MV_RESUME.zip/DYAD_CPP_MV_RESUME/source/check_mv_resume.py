#!/usr/bin/env python3
"""[SESSION] Independent integer checker for pilot and resumed stage records.

Does NOT independently evaluate the 4-block complex dynamical map or prove
sectorial graph/tube hypotheses.
"""
import argparse
from collections import deque
from pathlib import Path
S=1<<256
EVHEADER=('k id depth source_re_lo source_re_hi source_im_lo source_im_hi '
          'necessary_re_lo necessary_re_hi necessary_im_lo necessary_im_hi '
          'final_re_lo final_re_hi final_im_lo final_im_hi '
          'M_256 Dr_256 D_256 r_256 lower_abs_b_256 recenter_error_256 necessary_radius_256 evaluation action')
FH='id depth re_lo re_hi im_lo im_hi'
SH='k input evaluated excluded split retained unresolved budget_pending budget_valid_no_split depth_cap frontier_cap prior_L1_256 final_L1_256 median_ratio_256 Dr_gt_M stop'
PH=('id depth original_M_256 MV_M_256 intersection_M_256 improved_M_256 '
    'Dr_256 D_256 r_256 lb_256 error_256 old_rad_256 new_rad_256 Aabs_256 '
    'old_base_re_lo old_base_re_hi old_base_im_lo old_base_im_hi '
    'mv_base_re_lo mv_base_re_hi mv_base_im_lo mv_base_im_hi '
    'intersection_base_re_lo intersection_base_re_hi intersection_base_im_lo intersection_base_im_hi '
    'new_need_re_lo new_need_re_hi new_need_im_lo new_need_im_hi '
    'new_final_re_lo new_final_re_hi new_final_im_lo new_final_im_hi old_action new_action')
def ceil(a,b):assert b>0;return -(-a//b)
def intersect(a,b):
 c=(max(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),min(a[3],b[3]))
 return c if c[0]<=c[1] and c[2]<=c[3] else None
def contains(a,b):return a[0]<=b[0]<=b[1]<=a[1] and a[2]<=b[2]<=b[3]<=a[3]
def cut(a,j):
 assert j in range(4)
 x=j//2;y=j%2;dx=a[1]-a[0];dy=a[3]-a[2]
 return a[0]+dx*x//2,a[0]+ceil(dx*(x+1),2),a[2]+dy*y//2,a[2]+ceil(dy*(y+1),2)
def load(path,header):
 lines=Path(path).read_text().splitlines();assert lines and lines[0]==header,('bad header',path)
 assert all(line.strip() for line in lines[1:])
 return [line.split() for line in lines[1:]]
def front(path):
 rows=[];ids=set()
 for w in load(path,FH):
  assert len(w)==6
  name=w[0];depth=int(w[1]);b=tuple(map(int,w[2:6]));assert name not in ids and depth>=0 and b[0]<=b[1] and b[2]<=b[3]
  ids.add(name);rows.append((name,depth,b))
 return rows
def events(path):
 rows=[]
 for w in load(path,EVHEADER):
  assert len(w)==24
  a=list(map(int,[w[0],w[2]]+w[3:22]));k,depth=a[:2];b=tuple(a[2:6]);n=tuple(a[6:10]);fin=tuple(a[10:14]);M,Dr,D,r,lb,e,R=a[14:21]
  rows.append((k,w[1],depth,b,n,fin,M,Dr,D,r,lb,e,R,w[22],w[23]))
 return rows
def hrad(boxes):
 assert boxes
 a=min(b[0] for b in boxes);b=max(b[1] for b in boxes);c=min(b[2] for b in boxes);d=max(b[3] for b in boxes)
 mx=(a+b)//2;my=(c+d)//2
 return max(abs(a-mx),abs(b-mx))+max(abs(c-my),abs(d-my))
def radcheck(rec):
 (k,name,d,b,n,fin,M,Dr,D,r,lb,e,R,ev,act)=rec
 if ev=='UNRESOLVED':
  assert act=='RETAINED' and n==b and fin==b and all(v==0 for v in (M,Dr,D,r,lb,e,R));return None
 if ev=='NOT_EVALUATED':
  assert act=='BUDGET_KEEP' and n==b and fin==b and all(v==0 for v in (M,Dr,D,r,lb,e,R));return None
 assert ev=='VALID' and act in ('SPLIT','RETAINED','EXCLUDED')
 assert M>0 and Dr>=0 and D>=0 and r>=0 and lb>0 and e>=0 and R>=0
 assert Dr==ceil(D*r,S) and R==e+ceil((M+Dr)*S,lb)
 assert n[1]-n[0]==2*R and n[3]-n[2]==2*R
 hit=intersect(b,n)
 if act=='EXCLUDED':assert hit is None and fin==(0,0,0,0)
 else:assert hit is not None and fin==hit
 return hit
def check_pilot(oldpath,pilotpath,limit):
 old=events(oldpath);new=load(pilotpath,PH)
 assert len(old)==1600 and len(new)==limit and 1<=limit<=1600
 seen=set();improved=0;exclold=exclnew=0;rat=[]
 for i,(orig,w) in enumerate(zip(old,new)):
  assert len(w)==36,(i,len(w))
  k,id,depth,b,n,fin,M,Dr,D,r,lb,e,R,ev,act=orig
  assert k==4 and ev=='VALID' and id==w[0] and depth==int(w[1]) and id not in seen;seen.add(id)
  vals=list(map(int,w[2:34]));Mold,Mmv,Mi,Mbest,Drn,Dn,rn,lbn,en,Rold,Rnew,A=vals[:12]
  raw=tuple(vals[12:16]);mv=tuple(vals[16:20]);eff=tuple(vals[20:24]);newN=tuple(vals[24:28]);newFin=tuple(vals[28:32]);
  assert (Mold,Drn,Dn,rn,lbn,en,Rold)==(M,Dr,D,r,lb,e,R)
  assert Mi>0 and Mmv>0 and Mbest==min(M,Mmv,Mi) and A>=0 and Mbest<=M
  assert contains(raw,eff) and contains(mv,eff) and eff==intersect(raw,mv)
  assert Rnew==e+ceil((Mbest+Dr)*S,lb) and Rnew<=R
  oldmid=((n[0]+n[1])//2,(n[2]+n[3])//2)
  assert newN==(oldmid[0]-Rnew,oldmid[0]+Rnew,oldmid[1]-Rnew,oldmid[1]+Rnew)
  hit=intersect(b,newN)
  assert newFin==(hit if hit is not None else (0,0,0,0)) and w[34]==act
  assert w[35]==('RETAINED' if hit is not None else 'EXCLUDED')
  assert not(act=='EXCLUDED' and hit is not None)
  improved+=Mbest<M;exclold+=act=='EXCLUDED';exclnew+=hit is None
  rat.append(ceil(Mbest*S,M))
 rat.sort()
 print(f'MV_PILOT_INTEGER_PASS rows={len(new)} complete={len(new)==1600} improved={improved} old_excluded={exclold} new_excluded={exclnew} median_ratio_256={rat[len(rat)//2]}')
 print('SESSION_ONLY: no independent propagation of complex dynamics; graph/tube conditional')

def check_resume(prior,initialf,newf,stagesf,finalf,budget,maxdepth,cap,maxk):
 frozen=front(prior);initial=front(initialf)
 assert len(frozen)==897 and frozen==initial and sum(d==0 for _,d,_ in initial)==1
 ev=events(newf);strows=load(stagesf,SH)
 assert strows and len(strows)<=maxk-3
 current=initial;idx=0;total=0;stats=[]
 for s,w in enumerate(strows):
  assert len(w)==16
  k=int(w[0]);assert k==4+s
  queue=deque((id,depth if s==0 else 0,b) for id,depth,b in current)
  oldrad=hrad([b for _,_,b in queue]);kept=[];statsq=[]
  evals=excl=splits=retained=unresolved=pending=validbudget=depthcap=frontcap=gt=0
  while queue:
   assert idx<len(ev)
   item=queue.popleft();rec=ev[idx];idx+=1
   rk,id,d,b,n,fin,M,Dr,D,r,lb,e,R,event,act=rec
   assert (rk,id,d,b)==(k,*item)
   hit=radcheck(rec)
   if total>=budget:
    assert event=='NOT_EVALUATED' and act=='BUDGET_KEEP'
    pending+=1;kept.append(item);continue
   total+=1;evals+=1
   if event=='UNRESOLVED':
    unresolved+=1;retained+=1;kept.append(item);continue
   assert event=='VALID'
   gt+=Dr>M;statsq.append(ceil(Dr*S,M))
   if hit is None:
    excl+=1;continue
   high=2*Dr>M
   canfront=len(queue)+len(kept)+4<=cap
   canbudget=total+len(queue)+4<=budget
   if high and d<maxdepth and canfront and canbudget:
    assert act=='SPLIT';splits+=1
    for j in range(4):queue.append((id+'/'+str(j),d+1,cut(hit,j)))
   else:
    assert act=='RETAINED';retained+=1
    if high:
     if d>=maxdepth:depthcap+=1
     elif not canfront:frontcap+=1
     else:validbudget+=1
    kept.append((id,d,hit))
  newrad=hrad([b for _,_,b in kept]);assert newrad<=oldrad
  statsq.sort();med=statsq[len(statsq)//2] if statsq else 0
  stop=('BUDGET' if (pending or validbudget) else
        ('REFINEMENT_CAP' if (depthcap or frontcap) else ('DOMAIN' if unresolved else 'READY')))
  expected=(k,len(current),evals,excl,splits,retained,unresolved,pending,validbudget,depthcap,frontcap,oldrad,newrad,med,gt,stop)
  parsed=tuple(map(int,w[:15]))+(w[15],)
  assert expected==parsed,(expected,parsed)
  current=kept;stats.append(stop)
  if stop!='READY':assert s==len(strows)-1
 assert idx==len(ev) and total<=budget
 assert front(finalf)==current
 print(f'MV_RESUME_INTEGER_PASS input=897 events={len(ev)} stages={len(strows)} evaluated={total} final={len(current)} L1_256={hrad([b for _,_,b in current])} stop={stats[-1]}')
 print('SESSION_ONLY: exclusions conditional on frozen sources and graph/tube premises')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','resume'])
 p.add_argument('oldfile');p.add_argument('newfile');p.add_argument('--limit',type=int,default=1600)
 p.add_argument('--initial');p.add_argument('--stages');p.add_argument('--final');p.add_argument('--budget',type=int,default=0)
 p.add_argument('--depth',type=int,default=2);p.add_argument('--cap',type=int,default=4096);p.add_argument('--max-k',type=int,default=4)
 a=p.parse_args()
 if a.mode=='pilot':check_pilot(a.oldfile,a.newfile,a.limit)
 else:check_resume(a.oldfile,a.initial,a.newfile,a.stages,a.final,a.budget,a.depth,a.cap,a.max_k)
