// [SESSION] Structural only. No flow dynamics or certificate.
#define DYAD_MV_NO_MAIN
#include "mv_resume.cpp"
int main(int argc,char**argv){
 if(argc!=3)return 64;
 try{
  auto events=mvresume::load_events(argv[1]);
  auto front=mvresume::load_frontier(argv[2]);
  mvresume::replay_frozen_events(events,front);
  std::cout<<"MV_FROZEN_SOURCE_PARSER_PASS events="<<events.size()<<" frontier="<<front.size()<<"\n";
  return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 3;}
}
