// [SESSION] Verified mean-value base enclosure and resumable conditional k>=4 contractor.
// Uses unchanged centered F1/F2/F3/adaptive engine via compile-time include.
#define DYAD_ADAPTIVE_NO_MAIN
#include "adaptive.cpp"
#include <deque>
#include <unordered_set>
#include <numeric>

namespace mvresume {
using namespace dyad;
using namespace dyad::centered;
using Work=adapt::Work;
using Options=adapt::Options;
struct BaseResult {C raw, mv, effective; Z raw_M=0,mv_M=0,effective_M=0,absA=0;};
BaseResult base_bound(const f1::ForwardTube &tube,const State&whole,const State&point,const Disk&di){
 // The disc B(di.c,di.r) is convex; the analytic map x_k has its derivative
 // represented by whole.a.d on that entire disc. Hence x_k(z) is in
 // x_k(di.c) + B(0, sup|Dx_k|*di.r). The point value is itself an enclosure.
 Z norm_A=abs_upper(whole.a.d);
 C mv=inflate(point.a.v,cd(norm_A*di.r,SCALE));
 auto both=intersection(whole.a.v,mv);
 if(!both)throw std::runtime_error("whole and centred MV base enclosures are disjoint");
 Z oldM=tube.upper(whole.a.v).M;
 Z mvM=oldM,effM=oldM;
 // Failed optional bounds never invalidate the original sound bound.
 try{mvM=tube.upper(mv).M;}catch(const std::domain_error&){}
 try{effM=tube.upper(*both).M;}catch(const std::domain_error&){}
 // The intersection with the old enclosure is always sound. Even if the
 // nonlinear upper-bound implementation is not inclusion monotone, the
 // minimum of two VALID upper bounds is still a VALID upper bound.
 Z best=std::min({oldM,mvM,effM});
 if(best<=0)throw std::runtime_error("nonpositive tube bound");
 return {whole.a.v,mv,*both,oldM,mvM,best,norm_A};
}
struct Event {size_t k=0,depth=0;std::string id,ev,action;C input=C(0),need=C(0),final=C(0);
 Z M=0,Dr=0,D=0,r=0,lb=0,err=0,R=0;};
std::vector<Event> load_events(const std::string&path){
 std::ifstream f(path);if(!f)throw std::runtime_error("missing frozen adaptive events");
 std::ostringstream h;adapt::output_header(h);std::string head=h.str();head.pop_back();
 std::string line;std::getline(f,line);if(line!=head)throw std::runtime_error("frozen events header mismatch");
 std::vector<Event> events;std::set<std::string> ids;
 auto read_box=[&](std::istringstream& in,C& box){Z a,b,c,d;
  if(!(in>>a>>b>>c>>d)||a>b||c>d)throw std::runtime_error("bad frozen event box");
  box=C(I(a,b),I(c,d));};
 while(std::getline(f,line)){
  if(line.empty())throw std::runtime_error("empty frozen event line");
  std::istringstream in(line);Event e;std::string extra;
  if(!(in>>e.k>>e.id>>e.depth))throw std::runtime_error("bad event ID");
  read_box(in,e.input);read_box(in,e.need);read_box(in,e.final);
  if(!(in>>e.M>>e.Dr>>e.D>>e.r>>e.lb>>e.err>>e.R>>e.ev>>e.action)||(in>>extra))
   throw std::runtime_error("bad event fields");
  if(e.k!=4||e.depth>1||e.ev!="VALID"||
     (e.action!="SPLIT"&&e.action!="RETAINED"&&e.action!="EXCLUDED")||
     !ids.insert(e.id).second||e.M<=0||e.lb<=0||e.D<0||e.Dr<0||e.r<0||e.R<0||e.err<0||
     e.Dr!=cd(e.D*e.r,SCALE)||e.R!=e.err+cd((e.M+e.Dr)*SCALE,e.lb)||
     e.need.re.h-e.need.re.l!=2*e.R||e.need.im.h-e.need.im.l!=2*e.R)
   throw std::runtime_error("malformed frozen event or C1-C2 identity");
  auto hit=intersection(e.input,e.need);
  if((e.action=="EXCLUDED"&& (hit||!adapt::same(e.final,C(0))))||
     (e.action!="EXCLUDED"&&(!hit||!adapt::same(*hit,e.final))))
   throw std::runtime_error("frozen event intersection/action mismatch");
  events.push_back(e);
 }
 if(events.size()!=1600)throw std::runtime_error("expected exactly 1600 frozen events");
 return events;
}
std::vector<Work> load_frontier(const std::string&path){
 std::ifstream in(path);if(!in)throw std::runtime_error("missing frozen frontier");
 std::ostringstream hh;adapt::frontier_header(hh);std::string header=hh.str();header.pop_back();
 std::string line;std::getline(in,line);if(line!=header)throw std::runtime_error("wrong frontier header");
 std::vector<Work> v;std::set<std::string> ids;
 while(std::getline(in,line)){
  if(line.empty())throw std::runtime_error("blank frontier row");
  std::istringstream s(line);Work w;Z a,b,c,d;std::string extra;
  if(!(s>>w.id>>w.depth>>a>>b>>c>>d)||(s>>extra)||!ids.insert(w.id).second||
     w.depth>1||a>b||c>d)throw std::runtime_error("bad frozen frontier row");
  w.box=C(I(a,b),I(c,d));v.push_back(w);
 }
 if(v.size()!=897)throw std::runtime_error("frozen final frontier expected 897");
 return v;
}
void replay_frozen_events(const std::vector<Event>&events,const std::vector<Work>&front){
 std::map<std::string,Event> eventMap;
 for(const auto&e:events)eventMap.emplace(e.id,e);
 size_t initial=0,split=0,excl=0,ret=0;
 for(const auto&e:events){if(e.depth==0)++initial;if(e.action=="SPLIT")++split;
  if(e.action=="EXCLUDED")++excl;
  if(e.action=="RETAINED")++ret;}
 if(initial!=324||split!=319||excl!=384||ret!=897||ret!=front.size())
  throw std::runtime_error("frozen A1-A6 event counts do not match");
 size_t idx=0;std::deque<Work> q;
 // Original 324 input IDs are the depth-0 rows at the front of the event stream.
 for(const auto&e:events)if(e.depth==0)q.push_back(Work{e.id,e.input,0});
 // Queue chronology must be the original FIFO: depth-zero events first.
 std::vector<Work> kept;
 while(!q.empty()){
  if(idx>=events.size())throw std::runtime_error("truncated frozen event queue");
  Work w=q.front();q.pop_front();const Event&e=events[idx++];
  if(w.id!=e.id||w.depth!=e.depth||!adapt::same(w.box,e.input))
   throw std::runtime_error("frozen FIFO event replay mismatch");
  if(e.action=="SPLIT"){
   const auto children=f2::split_box(e.final,2);
   for(size_t j=0;j<4;++j)q.push_back(Work{w.id+"/"+std::to_string(j),children[j],w.depth+1});
  }else if(e.action=="RETAINED")kept.push_back(Work{w.id,e.final,w.depth});
 }
 if(idx!=events.size()||kept.size()!=front.size())throw std::runtime_error("frozen replay count mismatch");
 for(size_t i=0;i<kept.size();++i)
  if(kept[i].id!=front[i].id||kept[i].depth!=front[i].depth||!adapt::same(kept[i].box,front[i].box))
   throw std::runtime_error("frozen final frontier not reconstructed exactly");
}
struct Measured {BaseResult base;State whole,point;Disk di;C slope;Z D,Dr,lb,err;Disk oldNd,newNd;
 Measured(BaseResult b,State w,State p,Disk d,C s,Z D_,Z Dr_,Z lb_,Z e_,Disk old_,Disk nw_):
 base(std::move(b)),whole(std::move(w)),point(std::move(p)),di(std::move(d)),slope(std::move(s)),
 D(std::move(D_)),Dr(std::move(Dr_)),lb(std::move(lb_)),err(std::move(e_)),oldNd(std::move(old_)),newNd(std::move(nw_)){}
};
Measured measure(const Work&w,size_t k,const Data& data,const f1::ForwardTube&tube){
 Disk di=ball(w.box);
 State whole=f2::iter(tube.at_start(),di,data.phi,static_cast<int>(k));
 State point=f2::iter(tube.at_start(),Disk(di.c,0),data.phi,static_cast<int>(k));
 auto base=base_bound(tube,whole,point,di);
 const C slope=mid(point.b.d);const Z lb=norm_lower(slope);
 if(lb<=0)throw std::domain_error("slope may vanish");
 const Z D=norm_upper(whole.b.d-slope),Dr=cd(D*di.r,SCALE);
 const Disk oldNd=necessary_disk(di,point.b.v,whole.b.d,slope,base.raw_M);
 const Disk newNd=necessary_disk(di,point.b.v,whole.b.d,slope,base.effective_M);
 const C shift=di.c-point.b.v/slope;const Z err=norm_upper(shift-mid(shift));
 if(oldNd.r!=err+cd((base.raw_M+Dr)*SCALE,lb)||
    newNd.r!=err+cd((base.effective_M+Dr)*SCALE,lb))
  throw std::runtime_error("MV radius identity failure");
 if(!encloses(whole.a.v,base.effective)||!encloses(base.mv,base.effective)||
    !encloses(oldNd.box(),newNd.box()))
  throw std::runtime_error("MV base/necessity subset failed");
 return Measured(std::move(base),std::move(whole),std::move(point),di,slope,D,Dr,lb,err,oldNd,newNd);
}
void printbox(std::ostream&o,const C&b){adapt::boxprint(o,b);}
void pilot_header(std::ostream&o){o<<"id depth original_M_256 MV_M_256 intersection_M_256 improved_M_256 Dr_256 D_256 r_256 lb_256 error_256 old_rad_256 new_rad_256 Aabs_256 "
"old_base_re_lo old_base_re_hi old_base_im_lo old_base_im_hi "
"mv_base_re_lo mv_base_re_hi mv_base_im_lo mv_base_im_hi "
"intersection_base_re_lo intersection_base_re_hi intersection_base_im_lo intersection_base_im_hi "
"new_need_re_lo new_need_re_hi new_need_im_lo new_need_im_hi "
"new_final_re_lo new_final_re_hi new_final_im_lo new_final_im_hi old_action new_action\n";}
int pilot(const Data&data,const f1::ForwardTube&tube,const std::vector<Event>&ev,const std::string&dir,size_t limit){
 std::ofstream out(dir+"/base_pilot.tsv");if(!out)throw std::runtime_error("cannot open pilot TSV");
 pilot_header(out);
 size_t count=0,reduced=0,excluded=0,previous_excluded=0;std::vector<Z> ratios;
 for(const auto&e:ev){if(count>=limit)break;
  Work w{e.id,e.input,e.depth};
  Measured m=measure(w,4,data,tube);
  auto oldhit=intersection(e.input,m.oldNd.box());
  if(m.base.raw_M!=e.M||m.Dr!=e.Dr||m.D!=e.D||m.di.r!=e.r||m.lb!=e.lb||
     m.err!=e.err||m.oldNd.r!=e.R||!adapt::same(m.oldNd.box(),e.need)||
     ((e.action=="EXCLUDED")!=(oldhit==std::nullopt))||
     (oldhit&&!adapt::same(*oldhit,e.final)))
   throw std::runtime_error("frozen old event numerical replay mismatch: "+e.id);
  auto hit=intersection(e.input,m.newNd.box());
  if(e.action=="EXCLUDED")previous_excluded++;
  if(!hit)excluded++;
  if(m.base.effective_M<e.M)reduced++;
  ratios.push_back(cd(m.base.effective_M*SCALE,e.M));
  out<<e.id<<' '<<e.depth<<' '<<e.M<<' '<<m.base.mv_M<<' '<<tube.upper(m.base.effective).M<<' '
     <<m.base.effective_M<<' '<<m.Dr<<' '<<m.D<<' '<<m.di.r<<' '<<m.lb<<' '<<m.err<<' '<<m.oldNd.r<<' '<<m.newNd.r<<' '<<m.base.absA<<' ';
  printbox(out,m.base.raw);out<<' ';printbox(out,m.base.mv);out<<' ';printbox(out,m.base.effective);out<<' ';
  printbox(out,m.newNd.box());out<<' ';printbox(out,hit?*hit:C(0));
  out<<' '<<e.action<<' '<<(hit?"RETAINED":"EXCLUDED")<<'\n';
  count++;
 }
 if(!out)throw std::runtime_error("pilot TSV write failure");
 std::sort(ratios.begin(),ratios.end());
 std::cout<<"PILOT rows="<<count<<" expected=1600 improved_M="<<reduced<<" original_excluded="<<previous_excluded
          <<" new_excluded="<<excluded<<" M_ratio_median_256="<<(ratios.empty()?Z(0):ratios[ratios.size()/2])<<"\n";
 std::cout<<"SESSION_ONLY: MV base bound, old exact replay, no graph/tube certificate or point jump.\n";
 return count==ev.size()?0:2;
}
struct Stage{size_t k=0,initial=0,evaluated=0,excluded=0,split=0,retained=0,unresolved=0,
 pending=0,valid_budget=0,depth_cap=0,frontier_cap=0,dr_gt_m=0;
 Z before=0,after=0;std::vector<Z> q;std::string stop;};
void stage_header(std::ostream&out){out<<"k input evaluated excluded split retained unresolved budget_pending budget_valid_no_split depth_cap frontier_cap prior_L1_256 final_L1_256 median_ratio_256 Dr_gt_M stop\n";}
void stage_line(std::ostream&out,const Stage&s){auto ratios=s.q;std::sort(ratios.begin(),ratios.end());
 out<<s.k<<' '<<s.initial<<' '<<s.evaluated<<' '<<s.excluded<<' '<<s.split<<' '<<s.retained<<' '<<s.unresolved<<' '
 <<s.pending<<' '<<s.valid_budget<<' '<<s.depth_cap<<' '<<s.frontier_cap<<' '<<s.before<<' '<<s.after<<' '
 <<(ratios.empty()?Z(0):ratios[ratios.size()/2])<<' '<<s.dr_gt_m<<' '<<s.stop<<'\n';}
Stage stage(const Data&data,const f1::ForwardTube&tube,std::vector<Work>&front,
 size_t k,const Options&opt,size_t&total,std::ostream&out){
 Stage st;st.k=k;st.initial=front.size();
 const auto old=adapt::hull(front);if(!old)throw std::domain_error("no candidate input cover");
 st.before=enclosing_disk(*old).r;
 std::deque<Work> q(front.begin(),front.end());std::vector<Work> kept;
 while(!q.empty()){
  Work w=q.front();q.pop_front();
  if(total>=opt.budget){st.pending++;adapt::record(out,k,w,w.box,w.box,0,0,0,0,0,0,0,"NOT_EVALUATED","BUDGET_KEEP");kept.push_back(w);continue;}
  ++total;++st.evaluated;
  try{
   Measured m=measure(w,k,data,tube);const Z M=m.base.effective_M;
   st.q.push_back(cd(m.Dr*SCALE,M));if(m.Dr>M)st.dr_gt_m++;
   auto hit=intersection(w.box,m.newNd.box());
   if(!hit){st.excluded++;adapt::record(out,k,w,m.newNd.box(),C(0),M,m.Dr,m.D,m.di.r,m.lb,m.err,m.newNd.r,"VALID","EXCLUDED");continue;}
   bool high=2*m.Dr>M;
   bool canfront=q.size()+kept.size()+4<=opt.max_frontier;
   bool canbudget=total+q.size()+4<=opt.budget;
   if(high&&w.depth<opt.max_depth&&canfront&&canbudget){
    st.split++;adapt::record(out,k,w,m.newNd.box(),*hit,M,m.Dr,m.D,m.di.r,m.lb,m.err,m.newNd.r,"VALID","SPLIT");
    auto parts=f2::split_box(*hit,2);
    for(size_t j=0;j<4;++j)q.push_back(Work{w.id+"/"+std::to_string(j),parts[j],w.depth+1});
   }else{
    st.retained++;if(high){if(w.depth>=opt.max_depth)st.depth_cap++;
      else if(!canfront)st.frontier_cap++;else st.valid_budget++;}
    adapt::record(out,k,w,m.newNd.box(),*hit,M,m.Dr,m.D,m.di.r,m.lb,m.err,m.newNd.r,"VALID","RETAINED");
    kept.push_back(Work{w.id,*hit,w.depth});
   }
  }catch(const std::domain_error&e){st.unresolved++;st.retained++;adapt::record(out,k,w,w.box,w.box,0,0,0,0,0,0,0,"UNRESOLVED","RETAINED");kept.push_back(w);
    if(st.unresolved<=2)std::cerr<<"UNRESOLVED k="<<k<<" id="<<w.id<<" reason="<<e.what()<<'\n';}
 }
 const auto nw=adapt::hull(kept);if(!nw)throw std::domain_error("empty cover; no nonexistence claim");
 if(!encloses(*old,*nw))throw std::runtime_error("stage outer cover expanded");
 st.after=enclosing_disk(*nw).r;
 if(st.pending||st.valid_budget)st.stop="BUDGET";
 else if(st.depth_cap||st.frontier_cap)st.stop="REFINEMENT_CAP";
 else if(st.unresolved)st.stop="DOMAIN";
 else st.stop="READY";
 front.swap(kept);return st;
}
int resume(const Data&data,const f1::ForwardTube&tube,std::vector<Work>front,
 const Options&opt,const std::string&dir){
 // Resume the actual preserved depth-1 k4 frontier. No original 1600-event
 // dynamics are executed, and the initial 897 boxes are never silently removed.
 std::ofstream initial(dir+"/initial_frontier.tsv");adapt::print_frontier(initial,front);initial.close();
 std::ofstream ev(dir+"/events.tsv"),stg(dir+"/stages.tsv");
 if(!ev||!stg)throw std::runtime_error("cannot create run output");
 adapt::output_header(ev);stage_header(stg);
 size_t total=0,stages=0;std::string stop="MAX_K";
 for(size_t k=4;k<=opt.max_k;k++){
  if(total>=opt.budget){stop="BUDGET";break;}
  if(k>4)for(auto &w:front)w.depth=0;
  Stage s=mvresume::stage(data,tube,front,k,opt,total,ev);stage_line(stg,s);ev.flush();stg.flush();stages++;
  if(!ev||!stg)throw std::runtime_error("adaptive MV run output failure");
  std::cout<<"STAGE="<<k<<" evaluated="<<s.evaluated<<" excluded="<<s.excluded<<" split="<<s.split
   <<" retained_final="<<front.size()<<" unresolved="<<s.unresolved<<" budget_pending="<<s.pending
   <<" budget_valid_no_split="<<s.valid_budget<<" depth_cap="<<s.depth_cap<<" frontier_cap="<<s.frontier_cap
   <<" finalL1="<<f1::outdec(s.after)<<" stop="<<s.stop<<'\n';
  if(s.stop!="READY"){stop=s.stop;break;}
 }
 ev.close();stg.close();std::ofstream fin(dir+"/final_frontier.tsv");adapt::print_frontier(fin,front);fin.close();
 const auto h=adapt::hull(front);if(!h)throw std::runtime_error("final frontier empty");
 std::cout<<"STATUS="<<stop<<" input=897 stages="<<stages<<" evaluations="<<total<<" budget="<<opt.budget
  <<" final_boxes="<<front.size()<<" L1_256="<<enclosing_disk(*h).r<<" finalL1="<<f1::outdec(enclosing_disk(*h).r)<<'\n';
 std::cout<<"SESSION_ONLY; valid C1C2 exclusions conditional on graph/tube premises.\n";
 return stop=="MAX_K"?0:2;
}
}
#ifndef DYAD_MV_NO_MAIN
int main(int argc,char**argv){
 if(argc!=14){std::cerr<<"Usage: mv_resume TRANSFER SELECT400 REFINE576 H3SPLIT1296 OLD_EVENTS OLD_FRONTIER OUTDIR MODE(pilot|resume) MAX_K BUDGET DEPTH FRONTIER LIMIT\n";return 64;}
 try{
  const std::string mode=argv[8];if(mode!="pilot"&&mode!="resume")throw std::invalid_argument("MODE invalid");
  const size_t maxk=adapt::arg(argv[9],"MAX_K",4,20);
  const size_t budget=adapt::arg(argv[10],"BUDGET",0,100000);
  const size_t depth=adapt::arg(argv[11],"MAX_DEPTH",0,8);
  const size_t maxfront=adapt::arg(argv[12],"MAX_FRONTIER",324,20000);
  const size_t limit=adapt::arg(argv[13],"LIMIT",1,1600);
  if(mode=="pilot"&&(maxk!=4||budget!=0||depth!=0||limit>1600))throw std::invalid_argument("pilot options invalid");
  if(mode=="resume"&&(budget<1||limit!=1600))throw std::invalid_argument("resume options invalid");
  const Data data=read_data(argv[1]);
  const auto base=horizon::load_checked_source(argv[2]);
  const auto frozen=h3ref::load_frozen(base,argv[3]);
  const auto seeds=adapt::load_seeds(frozen,argv[4]);
  const auto logs=mvresume::load_events(argv[5]);
  const auto front=mvresume::load_frontier(argv[6]);
  mvresume::replay_frozen_events(logs,front);
  f1::ForwardTube tube(data.c);
  size_t n0=0,n1=0,n2=0;
  for(const auto&x:base)if(x.kept){horizon::replay(x,data,tube);n0++;}
  for(const auto&x:frozen)if(x.kept){h3ref::replay_frozen(x,data,tube);n1++;}
  for(const auto&x:seeds)if(x.kept){adapt::replay_seed(x,data,tube);n2++;}
  if(n0!=144||n1!=324||n2!=324)throw std::runtime_error("frozen source replays incomplete");
  if(mode=="pilot")return mvresume::pilot(data,tube,logs,argv[7],limit);
  adapt::Options opt;opt.first_k=4;opt.max_k=maxk;opt.budget=budget;opt.max_depth=depth;opt.max_frontier=maxfront;
  return mvresume::resume(data,tube,front,opt,argv[7]);
 }catch(const std::domain_error&e){std::cerr<<"INCONCLUSIVE: "<<e.what()<<'\n';return 2;}
 catch(const std::exception&e){std::cerr<<"INPUT_FAIL: "<<e.what()<<'\n';return 3;}
}

#endif // DYAD_MV_NO_MAIN
