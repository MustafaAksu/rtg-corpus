#!/usr/bin/env bash
# [SESSION] Mean-value base M4 pilot OR checkpoint continuation; NOT 3c-b.
set -euo pipefail
if [[ $# -ne 22 ]];then
 echo 'Usage: run_ubuntu_mv_resume.sh REPO V2 BENCH F1 F2 SUB8_PKG SELECTIVE_PKG HORIZON_PKG H3_PKG ADAPTIVE_PKG SUB8_RUN SELECTIVE_RUN HORIZON_RUN H3_RUN ADAPTIVE_RUN OUT pilot|resume MAX_K BUDGET MAX_DEPTH MAX_FRONTIER LIMIT' >&2
 exit 64
fi
repo=$(cd -- "$1" && pwd);v2=$(cd -- "$2" && pwd);bench=$(cd -- "$3" && pwd)
f1=$(cd -- "$4" && pwd);f2=$(cd -- "$5" && pwd);sub8=$(cd -- "$6" && pwd)
sel=$(cd -- "$7" && pwd);hor=$(cd -- "$8" && pwd);h3=$(cd -- "$9" && pwd)
adpkg=$(cd -- "${10}" && pwd)
s8run=$(cd -- "${11}" && pwd);selrun=$(cd -- "${12}" && pwd)
horrun=$(cd -- "${13}" && pwd);h3run=$(cd -- "${14}" && pwd);adrun=$(cd -- "${15}" && pwd)
out=${16};mode=${17};maxk=${18};budget=${19};depth=${20};frontier=${21};limit=${22}
pkg=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ "$mode" != pilot && "$mode" != resume ]];then echo 'STOP: mode pilot|resume' >&2;exit 64;fi
for n in "$maxk" "$budget" "$depth" "$frontier" "$limit";do
 [[ "$n" =~ ^[0-9]+$ ]] || { echo 'STOP: invalid integer parameter' >&2;exit 64; }
done
if (( maxk<4||maxk>20||budget>100000||depth>8||frontier<897||frontier>20000||limit<1||limit>1600 ));then
 echo 'STOP: out-of-range parameters' >&2;exit 64
fi
if [[ "$mode" == pilot ]];then
 if ((maxk!=4||budget!=0||depth!=0));then echo 'STOP: pilot uses 4 0 0 MAX_FRONTIER LIMIT' >&2;exit 64;fi
else
 if (( budget<1||limit!=1600||depth<1 ));then echo 'STOP: resume needs positive budget, depth>=1, LIMIT=1600' >&2;exit 64;fi
fi
if [[ -e "$out" ]];then
 [[ -d "$out" && -z $(ls -A -- "$out") ]] || { echo 'STOP: output must be a new/empty directory' >&2;exit 64; }
else mkdir -p -- "$out";fi
out=$(cd -- "$out" && pwd)
(cd "$pkg" && sha256sum -c SHA256SUMS.txt) > "$out/new_package_checks.txt"
for pair in "v2:$v2" "bench:$bench" "f1:$f1" "f2:$f2" "sub8:$sub8" "selective:$sel" "horizon:$hor" "h3:$h3" "adaptive:$adpkg";do
 n=${pair%%:*};base=${pair#*:}; (cd "$base" && sha256sum -c SHA256SUMS.txt) > "$out/${n}_package_checks.txt"
done
for pair in "sub8:$s8run" "selective:$selrun" "horizon:$horrun" "h3:$h3run" "adaptive:$adrun";do
 n=${pair%%:*};base=${pair#*:}; (cd "$base" && sha256sum -c RUN_SHA256SUMS.txt) > "$out/${n}_run_checks.txt"
done
(cd "$horrun/refine2" && sha256sum -c SHA256SUMS.txt) > "$out/refine2_checks.txt"
(cd "$h3run/h3_split2" && sha256sum -c SHA256SUMS.txt) > "$out/h3split_checks.txt"
(cd "$adrun/driver" && sha256sum -c SHA256SUMS.txt) > "$out/previous_driver_checks.txt"
S2="$repo/evidence/dyad/open20-an/stage2/scout_N216_dps840.json"
SUB8="$s8run/terms.tsv";SELECT="$selrun/selective_children.tsv"
REFINE="$horrun/refine2/details.tsv";H3S="$h3run/h3_split2/details.tsv"
PREV_EVENTS="$adrun/driver/events.tsv";PREV_FRONT="$adrun/driver/final_frontier.tsv"
{
 printf '%s  %s\n' 6ca8c663061ce2fa9e062938a1e6046c932da4cbddccc6e3e2c3de4df68c477e "$S2"
 printf '%s  %s\n' 1f5fa762fb3150cfd4b07ad3b65973731f68b59e1b00d1f9bb4c0800db096e72 "$SUB8"
 printf '%s  %s\n' 3566a7c712c180eb785017f3162b4664441afac6c1b34f4132a227d1fbc26579 "$SELECT"
 printf '%s  %s\n' bf9d4507a41efc937207bc5105dd3ce72e42e2d9477f40d0343eb794fb807a1a "$REFINE"
 printf '%s  %s\n' 3f3ac0df96733f7213a93ebd60ed93e0f03f90b341259cfe58564f76e56a7325 "$H3S"
 printf '%s  %s\n' 276701a085aefcc528290e496a721f83080780fabab5aafd78f3f7b3cc0a8a1f "$PREV_EVENTS"
 printf '%s  %s\n' 4cb41a4f4fa860763f1f992acd7caeee53f48acf9e9e335d2263281e453d5c2f "$PREV_FRONT"
} | sha256sum -c - > "$out/SEVEN_FROZEN_SHA256_PINS.txt"
# Independent old-stage audit before consuming any checkpoint.
python3 "$adpkg/source/check_adaptive.py" "$H3S" \
 "$adrun/driver/initial_frontier.tsv" "$PREV_EVENTS" \
 "$adrun/driver/stages.tsv" "$PREV_FRONT" \
 --budget 1600 --depth 2 --frontier 4096 --start 4 --max-k 6 > "$out/old_stage_independent_check.txt"
python3 "$sub8/source/check_terms.py" "$SUB8" > "$out/sub8_check.txt"
python3 "$sub8/source/check_completion.py" "$s8run/summary.txt" "$SUB8" 8 8 0 > "$out/sub8_completion.txt"
python3 "$sel/source/check_selective.py" "$SUB8" "$SELECT" "$selrun/summary.txt" > "$out/selective_check.txt"
python3 "$hor/source/check_horizon.py" "$SELECT" "$REFINE" "$horrun/refine2/summary.txt" refine2 > "$out/refine2_check.txt"
python3 "$h3/source/check_h3_refined.py" "$SELECT" "$REFINE" "$H3S" "$h3run/h3_split2/summary.txt" h3_split2 > "$out/h3_check.txt"
python3 "$v2/source/import_phi40.py" --source "$S2" --out "$out/phi40_outer_256.txt" > "$out/import.log"
cmp "$out/phi40_outer_256.txt" "$adrun/phi40_outer_256.txt"
{
 printf 'UTC=';date -u '+%Y-%m-%dT%H:%M:%SZ'
 printf 'REPO_HEAD=';git -C "$repo" rev-parse HEAD
 printf 'GCC=';g++ --version | head -1
 printf 'PYTHON=';python3 --version
 printf 'MODE=%s MAX_K=%s BUDGET=%s MAX_DEPTH=%s MAX_FRONTIER=%s LIMIT=%s\n' "$mode" "$maxk" "$budget" "$depth" "$frontier" "$limit"
 printf 'PREVIOUS_EVENTS_SHA256=276701a085aefcc528290e496a721f83080780fabab5aafd78f3f7b3cc0a8a1f\n'
 printf 'PREVIOUS_FRONTIER_SHA256=4cb41a4f4fa860763f1f992acd7caeee53f48acf9e9e335d2263281e453d5c2f\n'
 printf 'MODE=SESSION_ONLY; no graph/tube certificate, 3c-b or point jump\n'
} > "$out/environment.txt"
inc=(-I "$v2/source" -I "$bench" -I "$f1/source" -I "$f2/source" -I "$sel/source" -I "$hor/source" -I "$h3/source" -I "$adpkg/source" -I "$pkg/source")
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pedantic "${inc[@]}" "$pkg/source/mv_resume.cpp" -o "$out/mv_resume"
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pedantic "${inc[@]}" "$pkg/source/test_frozen_parser.cpp" -o "$out/test_frozen_parser"
python3 "$pkg/tests/test_mv_structure.py" "$out/test_frozen_parser" > "$out/structure_units.txt"
"$out/test_frozen_parser" "$PREV_EVENTS" "$PREV_FRONT" > "$out/previous_cpp_parser.txt"
g++ -std=c++17 -O0 -g0 -fsanitize=address,undefined -fno-omit-frame-pointer \
 "${inc[@]}" "$pkg/source/test_frozen_parser.cpp" -o "$out/test_frozen_parser_sanitized"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 timeout -k 5s 120s \
 "$out/test_frozen_parser_sanitized" "$PREV_EVENTS" "$PREV_FRONT" \
 > "$out/parser_sanitized.txt" 2> "$out/sanitizer_stderr.txt"
set +e
"$out/mv_resume" > /dev/null 2>&1;neg1=$?
"$out/mv_resume" "$S2" "$SELECT" "$REFINE" "$H3S" "$PREV_EVENTS" "$PREV_FRONT" "$out" banana 4 0 0 4096 1600 > /dev/null 2>&1;neg2=$?
"$out/mv_resume" "$S2" "$SELECT" "$REFINE" "$H3S" "$PREV_EVENTS" "$PREV_FRONT" "$out" pilot 3 0 0 4096 1600 > /dev/null 2>&1;neg3=$?
"$out/mv_resume" "$S2" "$SELECT" "$REFINE" "$H3S" "$PREV_EVENTS" "$PREV_FRONT" "$out" pilot 4 0 0 4096 1601 > /dev/null 2>&1;neg4=$?
set -e
[[ "$neg1,$neg2,$neg3,$neg4" == '64,3,3,3' ]] || { echo "STOP: negative CLI $neg1,$neg2,$neg3,$neg4" >&2;exit 3; }
printf 'NEGATIVE_CLI_PASS 64,3,3,3\n' > "$out/negative_controls.txt"
mkdir -p "$out/driver"
set +e
timeout -k 30s 5400s "$out/mv_resume" "$out/phi40_outer_256.txt" \
 "$SELECT" "$REFINE" "$H3S" "$PREV_EVENTS" "$PREV_FRONT" "$out/driver" \
 "$mode" "$maxk" "$budget" "$depth" "$frontier" "$limit" \
 > "$out/driver/summary.txt" 2> "$out/driver/stderr.txt"
rc=$?
set -e
if [[ "$rc" == 0 || "$rc" == 2 ]];then
 if [[ "$mode" == pilot && -s "$out/driver/base_pilot.tsv" ]];then
  python3 "$pkg/source/check_mv_resume.py" pilot "$PREV_EVENTS" "$out/driver/base_pilot.tsv" --limit "$limit" > "$out/driver/structure_check.txt" || exit 3
 elif [[ "$mode" == resume && -s "$out/driver/events.tsv" && -s "$out/driver/stages.tsv" && -s "$out/driver/final_frontier.tsv" ]];then
  python3 "$pkg/source/check_mv_resume.py" resume "$PREV_FRONT" "$out/driver/events.tsv" \
   --initial "$out/driver/initial_frontier.tsv" --stages "$out/driver/stages.tsv" \
   --final "$out/driver/final_frontier.tsv" --budget "$budget" --depth "$depth" \
   --cap "$frontier" --max-k "$maxk" > "$out/driver/structure_check.txt" || exit 3
 fi
fi
(cd "$out/driver" && find . -maxdepth 1 -type f ! -name SHA256SUMS.txt -printf '%f\0' | sort -z | xargs -0 -r sha256sum > SHA256SUMS.txt)
(cd "$out" && find . -maxdepth 1 -type f ! -name RUN_SHA256SUMS.txt ! -name mv_resume ! -name test_frozen_parser ! -name test_frozen_parser_sanitized -printf '%f\0' | sort -z | xargs -0 -r sha256sum > RUN_SHA256SUMS.txt)
cat "$out/driver/summary.txt"
[[ -s "$out/driver/structure_check.txt" ]] && cat "$out/driver/structure_check.txt"
if [[ $rc != 0 ]];then
 if [[ $rc == 2 ]];then echo 'INCONCLUSIVE: bounded SESSION result with complete checked frontier/pilot records';exit 2;fi
 echo "INCOMPLETE/FAILURE: rc=$rc; not a structural PASS or valid continuation";exit 3
fi
[[ -s "$out/driver/structure_check.txt" ]] || { echo 'STOP: no complete independent integer check' >&2;exit 3; }
echo 'PASS: COMPLETE BOUNDED SESSION PILOT/RESUME ONLY; no graph, tube or point-jump proof'
