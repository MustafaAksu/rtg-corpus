# DYAD OPEN 20 — independent C++ logic and review contract

**Status:** SESSION / DEVELOPMENT CHECKPOINT. Not an adopted theorem, certificate or 3c-b run.
**Updated:** 16 November 2026, following PR #288 at `179a139567b0674d8839ccc70a274abcfe8c7ffe`.
**Author:** ChatGPT. **Requested reviewer:** Claude. **PI:** Mustafa Aksu.

## 1. Current scope and authority

The independent implementation targets a necessary-condition contractor in the **initial** fibre, not a translation of the Python four-update leg algorithm. Its prototype currently implements a forward evaluator and a sound initial-fibre cover; it does not yet compute the two DYAD sectorial values.

Governing owner: DYAD v6.4.24, `dyad-v6.4.24`; owner-file SHA-256 `10fbdacc19544596480acae03faeba076f21103a01b903a8d3305cfa8ed7bc16`. Baseline checked at `65a4f32230118c20afb528c67c21b8ebc52db97c`. Methodology v1.4; repository conventions apply. The current work is not a new source authority.

Original mathematical source cut: `2d898fdafedee7f5b3d4628fe0c08ef2871a8b0c`, proof record §§1–9, especially the primitive map, lift and leg containment contract. Current reading: original source/design full, owner review #288 full, conventions full, stage-3b design §3 targeted. Full version/provenance and original hashes are in `DYAD_OPEN20_CPP_CENTERED_FEASIBILITY.md` §1. The original received package remains byte-exact under `received/` in the handoff.

**Independence:** no Python campaign code was translated, imported or executed. Prior exposure to that code and the owner's centred-disc suggestion are disclosed. The arithmetic is exact-integer-directed dyadic interval arithmetic. This is neither a blind clean-room experiment nor a claim that the arithmetic kernel is independently certified. The original raw-box route failed as recorded in #288; that negative finding remains valid.

## 2. Objects and target

    T(rho,eta) = (rho-sin(eta), eta+exp(rho)-1-sin(eta)), F=T^6.
    z=rho+omega*eta, w=rho+conjugate(omega)*eta, omega=(-1+i*sqrt(3))/2.
    w=phi_40(x)+x^2*d, z=x, xi=c_plus*x.

The final target is two rigorous outer disks for d_0(xi-star),d_1(xi-star) in the same chart, with strict separation. Existence, selected branch, common overlap and tube hypotheses remain explicit shared conditional owner inputs. Local disk separation does not replace those inputs and does not decide B-an/B-6.

Excluded: Zone I/II recertification; scientific adoption; an independent arithmetic-library certification; production/replay; a harmonic scan; changes to the frozen Python r3 package.

## 3. [SESSION/THM, conditional] Contractor contract

For a holomorphic f on a neighbourhood of B(a,r), a nonzero exact slope b, D >= sup_B |f'-b| and a feasible point d-star with |f(d-star)| <= M,

    |d-star - (a-f(a)/b)| <= (M+D*r)/|b|.                       (C1)

Integrate f' along the straight segment in the convex disk and subtract b. No convergence, existence, uniqueness or D<|b| assumption is needed. The implementation encloses the new centre, recentres at an exact dyadic point, adds the centre error and divides by a positive lower bound of |b|. That implementation is unchanged by the evaluator revision.

The derivative must cover the circumscribed disk used by C1, and M every feasible endpoint base. Unproved candidates are retained; an empty cover is an inconsistency, never a vacuous jump proof.

## 4. Current evaluator

Use eigen-coordinates with the linear terms removed before interval evaluation:

    E(rho)=exp(rho)-1-rho, S(eta)=sin(eta)-eta, lambda=1+omega,
    z'=lambda*z+omega*E(rho)-lambda*S(eta),
    w'=conjugate(lambda)*w+conjugate(omega)*E(rho)-conjugate(lambda)*S(eta).

The residuals and their derivatives are enclosed by degree-160 series plus the explicit exponential majorant E1. Complex first jets form the **whole six-step** Jacobian. After each F block, propagate a centred polydisc by the mean-value bound

    r_i' >= centre_error_i + sum_j sup|partial_j F_i(P)| r_j.   (MV1)

Tangent disks propagate with the same whole-polydisc Jacobian, not merely its central value. `DYAD_OPEN20_CPP_CENTERED_FEASIBILITY.md` §§3–4 proves the formulas and states the rounding operations. This is a first-order centred mean-value method; it is not an implemented Lohner QR scheme.

The primitive map is evaluated without a normal-form truncation. Raw eigen-coordinates are transported and the lifted deviation is read out only when needed. Pole exclusion is explicit. The old direct raw-rectangle evaluator is retained solely as a reference/negative test.

## 5. Coverage and F2 boundary

Start from the entire true initial fibre, not a small disk suggested by the known Python answer. Every tile is discarded only through a proved necessary-condition exclusion or proved nonintersection with the initial disk. Domain-error tiles are now subdivided until the width or resource limit; at the limit all unresolved leaves and pending tiles survive. Infrastructure exceptions fail loudly.

**F2 must be enforced by the still-unimplemented adapter:** before using a tube radius R_j as M, prove full-base membership in D_j, including sector, pole, logarithm sheet and wedge conditions. If that proof is unavailable, retain/subdivide the candidate. No R_j or D_j implementation exists in the present evaluator; therefore no tube claim can result from its tests.

## 6. Implemented extent and remaining adapters

| Component | State |
|---|---|
| Directed dyadic arithmetic, entire-function bounds, original contractor | Implemented; original owner review accepts within its checked scope |
| Centred eigen-coordinate block evaluator and tangent transport | Implemented; implementer-run tests; new owner review pending |
| Initial-fibre cover including F3 | Implemented; test witnesses and budget handling checked |
| True phi_40 coefficient/pilot generator and xi-star parameterisation | Not implemented |
| Full-base D_j and R_j adapter | Not implemented |
| Selected full-target inverse branch G | Not implemented |
| Actual two-DYAD-leg feasibility and two-disk jump test | Not performed |
| L1/L3 and global tube hypotheses | Shared conditional dependencies, not discharged here |

An explicitly imported rigorous coefficient enclosure is possible but narrows the independence claim; it is not independent coefficient generation. A local inverse solve must identify the owner's chosen branch and cover the full target fibre. No inverse or Krawczyk result is claimed.

## 7. Current evidence and next review

At fixed 256-bit absolute resolution, the new evaluator completes 334 F blocks for the owner's raw test point and for a synthetic lift phi=x^2/2. It also encloses derivatives over a small initial disk. A broad synthetic disk with radius about 2e-3 is contracted to about 1.2012e-4 under an artificial terminal bound, not under R_j. Detailed exact-endpoint outputs, oracle comparisons, negative evidence and tests are in the centred-feasibility record and `centered-checkpoint/`.

**These results do not satisfy the complete actual-leg criterion at xi-star.** The real phi_40, terminal tube radius, domain membership and inverse leg are still absent. Current numerical oracles use direct raw T and are sampled consistency checks, not proof of the interval implementation.

Claude's requested scope is MV1/AD1 and code, residual/derivative tails, recentering, full-polydisc rather than midpoint Jacobian, lift/pole logic, and F3 preservation. After that review, implement a rigorously identified actual pilot input and a bounded forward test, then the domain/tube and selected inverse adapters. A full-fibre contractor result must precede comparison with the original Python disks.

No speedup, first harmonic, divergence result or B-an/B-6 closure is asserted. Production and replay remain separate PI decisions.
