# DYAD OPEN 20 — centred evaluator after the owner review

**Status:** SESSION / IMPLEMENTER-RUN DEVELOPMENT CHECKPOINT. Not adopted, not a certificate, not production or replay. No DYAD sectorial value or point jump computed. B-an/B-6 unchanged.
**Author:** ChatGPT, independent implementation co-owner. **Requested reviewer:** Claude. **Date:** 16 November 2026.
**Trigger:** owner review PR #288, `179a139567b0674d8839ccc70a274abcfe8c7ffe`, read in full (§§1–6). The existing contractor is retained. The evaluator, not its necessary-condition theorem, is replaced.

## 1. Source identity and extent

The original PI-relayed source and design were read in full and checked against the owner's identity:

| Received file | SHA-256 |
|---|---|
| `independent_core.cpp` | `f5b574b02839039587a52df33982fa06350344aefba0655778e735a7ff9a7783` |
| `DYAD_OPEN20_CPP_INDEPENDENT_DESIGN.md` | `444661273767e33028e34c576eb4035bc03131821683b7a37ec4d4ae699d6f3d` |

The original package remains unchanged in `received/DYAD_OPEN20_CPP_INDEPENDENT_REVIEW_PACKAGE.zip`. The supplied originals were not overwritten. A patch records changes to the current kernel: a no-main include guard and the F3 subdivision policy/test; no arithmetic, map or contractor formula was changed in that file.

Repository `CONVENTIONS.md` was read in full at the review head. The baseline was checked at `65a4f32230118c20afb528c67c21b8ebc52db97c`: DYAD v6.4.24, tag `dyad-v6.4.24`, owner-file SHA-256 `10fbdacc19544596480acae03faeba076f21103a01b903a8d3305cfa8ed7bc16`; Methodology v1.4. This is a check of the repository record, not a new whole-DSN hash audit. No new claim depends on an uninspected successor DSN.

Mathematical definitions: the prior design's source cut and owner proof record §§1,9; the stage-3b design §3 was reread at the review head. This is not a reread or independent recertification of global Zone I/II proofs, literature inputs, or numerical campaigns.

**Independence disclosure:** the owner suggested eigen-coordinates, centred discs and mean-value/Lohner-type updates. The new implementation adopts eigen-coordinates and centred discs with a first-order mean-value bound on an entire six-step block. It does **not** implement a Lohner QR method and should not be described as one. The exact block formulas below were derived from T; no Python campaign evaluator, coefficient array, inverse series, Cauchy remainder constant or leg-update routine was translated, imported or run. Prior familiarity with the Python work remains disclosed; this is not a blind clean-room experiment. The arithmetic backend is still the independently written dyadic kernel, not Arb.

## 2. Disposition of F1–F4

| Finding | Disposition |
|---|---|
| F1, natural interval wrapping | Accepted. The old path is retained and reproduces range refusal. New centred block propagation completes the same raw-point test at 334 F steps and 256-bit absolute dyadic resolution. The synthetic lifted tests also complete. **Actual phi_40 / xi-star leg feasibility remains open.** |
| F2, D_j before R_j | Accepted as a mandatory adapter contract. No R_j is called in this checkpoint. Missing full-base membership proof must retain/subdivide the candidate, never provide M or discard it. This adapter is not implemented. |
| F3, unresolved wide tiles | Fixed: a domain-error tile is bisected while wider than the configured width. Size-limited leaves and the entire pending queue at budget exhaustion are kept. |
| F4, exceptions and real divisors | Infrastructure exceptions remain fail-loud. New residual sums divide by positive real integers. The existing complex-inverse proposal remains unimplemented; no Krawczyk result is claimed. |

## 3. [SESSION/ALG] Remove the linear dependency analytically

Let omega = -1/2 + i sqrt(3)/2 and lambda = 1 + omega. In the independent complex variables z,w, put

    eta = (z-w)/(i sqrt(3)),    rho = (z+w+eta)/2,
    E(rho) = exp(rho)-1-rho,   S(eta) = sin(eta)-eta.

The primitive map is exactly

    z' = lambda*z + omega*E(rho) - lambda*S(eta),
    w' = conjugate(lambda)*w + conjugate(omega)*E(rho)
                                  - conjugate(lambda)*S(eta).

Here conjugation is applied **only to the fixed constants**; z and w are not assumed conjugates. The identities follow from omega^2+omega+1=0 and lambda*omega=-1. No approximation or normal-form truncation is used.

`exp_residual` sums degrees 2–160 for E and 1–160 for E'; `sin_residual` sums odd degrees 3–159 for S and even degrees 2–160 for S'. Their tails are each bounded by E1's exponential majorant. In particular, E' is enclosed as exp(rho)-1, not as the derivative of a finite polynomial without a remainder. S' is enclosed as cos(eta)-1. The linear terms are never introduced and then subtracted as independent intervals.

A two-variable holomorphic first jet carries the full 2x2 complex Jacobian while composing six primitive steps. Within a block, rectangles are used conservatively. Between blocks they are not repeatedly forwarded as the state enclosure.

## 4. [SESSION/THM, conditional] Block mean-value enclosure

Let P = B(c_0,r_0) x B(c_1,r_1) be the current complex polydisc; F=T^6 is entire. Suppose `block` encloses every derivative entry on a rectangle containing **all** of P:

    partial_j F_i(P) subset J_ij.

Let q_i be an exact dyadic midpoint of the interval evaluation of F_i(c), with e_i >= |F_i(c)-q_i|. Then

    F_i(P) subset B(q_i, e_i + sum_j sup|J_ij| r_j).             (MV1)

**Proof:** the segment from c to p is in the convex polydisc. Integrate the full derivative of F along that segment and use the triangle inequality. The centre evaluation's uncertainty is included separately. No existence, uniqueness, contraction, tube membership, or derivative-at-centre substitution is used.

All radius products are rounded up with integer ceiling. For a complex rectangle, the Euclidean modulus upper bound is the ceiling integer square root of the sum of the squared component maxima; the lower bound uses component minima and a floor integer square root. The displayed decimals are approximate; exact integer endpoints and radii are deposited.

### Derivative over the whole initial fibre disk

Let v_j enclose the derivative of the current state with respect to the initial fibre parameter d. It is advanced as

    v'_i = sum_j (partial_j F_i) v_j,                            (AD1)

using complex discs for the products and sum. For discs B(a,r),B(b,s), multiplication has centre ab and radius

    |a|s + |b|r + rs,

plus the explicitly enclosed centre-rounding error. This does not replace J(P) with J(c). Correlations discarded by the product only enlarge the enclosure.

The initial parameterisation is z=x, w=phi(x)+x^2*d with x independent of d, hence v=(0,x^2). A fixed interval enclosure of x or coefficients can be carried as extra uncertainty; no independent coefficient generator is thereby established.

### Lifted readout, not repeated lift/unlift

Propagate raw eigen-coordinates through F, and compute

    d_n = (w_n-phi(z_n))/z_n^2

and its derivative from the propagated state/tangent only at readout. This is the conjugated lifted iteration wherever the intermediate base points avoid zero. The point/small-disk feasibility probe checks the lift denominator at **every** block. The broad synthetic shooting probe is a test of the final-chart function L^-1 F^334 L; it checks that final denominator. No claim about a selected inverse branch or domain D_j follows.

## 5. Implemented files and tests

All code is under `evidence/dyad/cpp/open20-independent/`.

- `independent_core.cpp`: reviewed kernel, unchanged arithmetic/contractor, F3 policy and include guard.
- `centered_evaluator.hpp`: residual eigen-map, full block Jacobian, state/tangent disc transport, lifted readout.
- `centered_unit_tests.cpp`: 15 new unit/negative tests.
- `centered_probe.cpp`: predeclared 334-block feasibility tests; exact endpoint JSONL.
- `centered_shooting_probe.cpp`: one broad-disk synthetic necessary-condition contraction.
- `legacy_width_probe.cpp`: repeat of the old wrapping failure, retained as negative evidence.
- `check_centered_oracle.py`, `check_shooting_oracle.py`: direct raw T with analytic variational equations in mpmath, not the Python campaign.
- `run_centered_checks.sh`: reproduction commands; no production or certification mode.

**Toolchain actually used:** GCC 14.2.0; Boost headers 1.83; C++17; 256-bit absolute dyadic endpoint grid. Python 3.13.5 / mpmath 1.3.0 for the 320-decimal-digit oracles. No claim of a speedup relative to a matched Python leg run.

### 5.1 Old failure retained

At the owner's raw point (rho,eta)=(3/100+i/100, -1/50+i/200), the old natural-interval path gives approximate maximum component widths:

| Completed F steps | Width |
|---|---:|
| 1 | 1.0877e-72 |
| 10 | 1.5806e-49 |
| 20 | 8.4311e-24 |

This implementation of the probe completed 29 blocks and refused the 30th by its elementary range guard. The owner's approximately-28-step observation is not contradicted by this small difference in initial representation/probe details. Neither result proves an intrinsic dynamical instability.

### 5.2 New 334-block tests

All tabulated widths are approximate maximum **full component widths**, not radii. Exact endpoints are in `centered-checkpoint/feasibility.jsonl`.

| Test | Final value width | Final tangent width |
|---|---:|---:|
| Same owner raw point; tangent initially partial/partial rho | 7.7433e-71 | 1.4142e-66 |
| Synthetic lift point: x=1/64+i/128, phi=x^2/2, d=0 | 1.9166e-67 | 3.9481e-63 |
| Same synthetic lift; whole disk |d| <= 2^-60 | 4.8082e-18 | 2.5232e-17 |

For each test the fixed integer-endpoint gate was maximum value width and maximum tangent width < 10^-12, at horizon 334. **10^-12 is a predeclared feasibility scale, not an evaluated R_j on these trajectories.** The actual DYAD coefficients, xi-star base point, tube membership and terminal R_j are not inputs to these tests. In particular, the synthetic lifted tests do not meet the full actual-leg acceptance criterion of the owner's review.

The independent raw-map oracle contains 220 complex value/tangent checks at steps 1,10,20,100,334, including 9 initial-parameter witnesses inside the small disk. 220/220 are contained; a displaced value and a zero derivative are rejected as two negative controls. These are numerical consistency checks, not a proof over the continuum; MV1/AD1 and their implementation are the coverage argument.

### 5.3 Broad disk: useful contraction, still synthetic

For the same **synthetic** phi and x, start with the exact dyadic radius r=ceil(2^256/500)/2^256 around d=0. The necessary terminal condition is artificially chosen |d_334| <= M, M=ceil(2^256/10^12)/2^256; it is **not** a DYAD tube assertion.

The unchanged C1–C2 contractor, using the whole-disk derivative and the point evaluation, returns a disk of approximate radius 1.20120069e-4 from the initial radius approximately 2e-3. The predeclared factor-two radius reduction passes by exact integer comparison. The derivative's approximate maximum component width is 5.99178729e-2.

Nine 320-digit raw-map witnesses have values and derivatives inside the whole-disk enclosures (18/18 checks). A numerically solved zero of d_334 lies in both the initial and returned disks; its numerical residual is about 1.84e-160. This is an additional [NUM] consistency test, **not** a certified zero or a DYAD sectorial curve. No point was selected from the known Python jump disks.

### 5.4 Unit/safety checks

The 20 existing tests pass after the F3 expectation update. The 15 new tests pass in an ordinary build and under AddressSanitizer+UndefinedBehaviorSanitizer, with no diagnostic. The F3 tests explicitly check disk-grid witnesses after subdivision/budget exhaustion, finite termination at the width limit, and fail-loud handling of an infrastructure exception. Unsupported production invocation returns 64. These tests are not a proof that every line is correct.

## 6. Obligations before a real DYAD leg

1. Claude independently reviews MV1/AD1, the residual series/derivatives, full-polydisc Jacobian, recentering and lift readout. No owner acceptance of this new code is asserted.
2. Generate rigorous pilot coefficients, c-plus and the actual input parameterisation, or explicitly declare any rigorously enclosed imported inputs and the resulting narrower independence claim. Test actual xi-star before making a real-leg feasibility claim.
3. Implement full-base D_j membership, including sector and logarithm sheet, before any R_j bound is passed to C1. An unresolved membership test must retain/subdivide, not exclude.
4. Implement and identify the selected inverse branch G on full target sets. The forward kernel is not that adapter.
5. Cover the complete true initial fibre, not only the small test disk or a neighbourhood of an anticipated answer. Freeze before comparing actual enclosures with the Python disks. No harmonic scan is included.

**Verdict of this checkpoint:** the particular raw-box wrapping mechanism is avoidable at fixed 256-bit resolution and horizon 334 on the tested trajectories, and the new evaluator supports a useful nonlinear synthetic contractor. This is positive feasibility evidence for the evaluator, not completion of either true DYAD leg, the two-disk test, or OPEN 20.
