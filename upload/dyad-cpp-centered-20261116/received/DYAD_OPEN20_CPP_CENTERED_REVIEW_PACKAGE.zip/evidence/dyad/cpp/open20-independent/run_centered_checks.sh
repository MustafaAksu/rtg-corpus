#!/usr/bin/env bash
# SESSION development checks only; never a DYAD production/replay campaign.
set -euo pipefail
src=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
out=${1:?Usage: run_centered_checks.sh EMPTY_OUTPUT_DIRECTORY}
mkdir -p -- "$out"
out=$(cd -- "$out" && pwd)
if [[ -n $(ls -A -- "$out") ]]; then
  echo 'Refusing to overwrite a nonempty output directory.' >&2; exit 64
fi
cxx=${CXX:-g++}
for name in independent_core centered_unit_tests centered_probe centered_shooting_probe legacy_width_probe; do
  "$cxx" -std=c++17 -O2 -Wall -Wextra -pedantic "$src/$name.cpp" -o "$out/$name"
done
"$out/independent_core" --unit-tests > "$out/core_unit_tests.txt"
"$out/centered_unit_tests" > "$out/centered_unit_tests.txt"
"$out/legacy_width_probe" > "$out/legacy_width_probe.txt"
"$out/centered_probe" --feasibility "$out/feasibility.jsonl" > "$out/feasibility.stdout.txt"
"$out/centered_shooting_probe" --synthetic-shooting "$out/synthetic_shooting.json" > "$out/synthetic_shooting.stdout.txt"
python3 "$src/check_centered_oracle.py" "$out/feasibility.jsonl" "$out/oracle.json" > "$out/oracle.stdout.txt"
python3 "$src/check_shooting_oracle.py" "$out/synthetic_shooting.json" "$out/shooting_oracle.json" > "$out/shooting_oracle.stdout.txt"
"$cxx" -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer "$src/centered_unit_tests.cpp" -o "$out/centered_unit_tests_san"
ASAN_OPTIONS=detect_leaks=1 "$out/centered_unit_tests_san" > "$out/centered_unit_tests_san.txt" 2> "$out/centered_unit_tests_san.stderr.txt"
if "$out/centered_probe" --production unused > "$out/unsupported_mode.stdout.txt" 2> "$out/unsupported_mode.stderr.txt"; then
  echo 'Unexpected production acceptance.' >&2; exit 1
else
  rc=$?; printf 'unsupported_production_exit=%s\n' "$rc" > "$out/negative_cli_test.txt"
  [[ $rc == 64 ]]
fi
printf 'PASS: SESSION tests only; no DYAD phi_40, tube, inverse branch or jump calculated.\n'
