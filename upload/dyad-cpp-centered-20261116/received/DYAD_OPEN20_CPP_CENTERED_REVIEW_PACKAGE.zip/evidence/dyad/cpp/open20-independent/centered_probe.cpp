// SESSION / bounded F1 feasibility probes only. No production/certificate mode.
#include "centered_evaluator.hpp"
#include <fstream>
#include <iomanip>
#include <sstream>
using namespace dyad;
namespace ce=dyad::centered;

std::string sci(const Z& v) { // Display only. All decisions use integer endpoints.
    std::ostringstream s; s<<std::setprecision(8)<<std::scientific
      <<(v.convert_to<long double>()/SCALE.convert_to<long double>()); return s.str();
}
Z width(const C& c) { return std::max(Z(c.re.h-c.re.l),Z(c.im.h-c.im.l)); }
void component(std::ostream& o,const C& c) {
    o<<"[[\""<<c.re.l<<"\",\""<<c.re.h<<"\"],[\""<<c.im.l<<"\",\""<<c.im.h<<"\"]]";
}
void report(std::ostream& o,const char* tag,int n,const ce::Flow& flow,const State& r) {
    o<<"{\"case\":\""<<tag<<"\",\"step\":"<<n<<",\"precision\":"<<PREC<<",\"values\":[";
    component(o,r.a.v);o<<",";component(o,r.b.v);o<<"],\"tangents\":[";
    component(o,r.a.d);o<<",";component(o,r.b.d);o<<"],\"state_radius_units\":[\""
     <<flow.state[0].r<<"\",\""<<flow.state[1].r<<"\"],\"tangent_radius_units\":[\""
     <<flow.tangent[0].r<<"\",\""<<flow.tangent[1].r<<"\"],\"max_value_width_display\":\""
     <<sci(std::max(width(r.a.v),width(r.b.v)))<<"\",\"max_tangent_width_display\":\""
     <<sci(std::max(width(r.a.d),width(r.b.d)))<<"\"}\n";
}
int main(int argc,char**argv) {
    if(argc!=3||std::string(argv[1])!="--feasibility") {
        std::cerr<<"Usage: centered_probe --feasibility OUTPUT.jsonl\nNo DYAD production or certification mode.\n";return 64;
    }
    try {
        std::ofstream o(argv[2]);if(!o)throw std::runtime_error("cannot write output");
        // Predeclared: 334 blocks, absolute display/readout threshold 1e-12.
        // This threshold is NOT an evaluation or proof of a DYAD tube radius.
        const Z threshold=fd(SCALE,Z(1000000000000LL));
        bool all=true;
        std::vector<C> phi{C(0),C(0),C(I::rat(1,2))}; // synthetic, NOT phi_40
        C x(I::rat(1,64),I::rat(1,128));
        for(int test=0;test<3;++test) {
            const char* tag=test==0?"owner_raw_point":test==1?"synthetic_lift_point":"synthetic_lift_disk";
            ce::Flow f= test==0?
                ce::from_raw({C(I::rat(3,100),I::rat(1,100)),C(I::rat(-1,50),I::rat(1,200))},{C(1),C(0)}):
                ce::from_lift(x,Disk(C(0),test==2?(SCALE>>60):Z(0)),phi);
            for(int n=1;n<=334;++n) {
                f=ce::advance(f);
                State r=test==0?ce::raw_readout(f):ce::lifted_readout(f,phi);
                if(n==1||n==10||n==20||n==100||n==334)report(o,tag,n,f,r);
                if(n==334) {
                    Z vw=std::max(width(r.a.v),width(r.b.v));
                    Z dw=std::max(width(r.a.d),width(r.b.d));
                    // Fixed, intentionally modest feasibility gate. The disk
                    // derivative must also be narrow enough for potential use.
                    bool pass=vw<threshold && dw<threshold;
                    all=all&&pass;
                    std::cout<<tag<<" horizon=334 value_width_display="<<sci(vw)
                             <<" derivative_width_display="<<sci(dw)<<" "<<(pass?"PASS":"FAIL")<<"\n";
                }
            }
        }
        std::cout<<"RESULT "<<(all?"PASS":"FAIL")<<"; development feasibility only; synthetic lift, no DYAD tube or jump\n";
        return all?0:1;
    }catch(const std::exception& e){std::cerr<<"UNRESOLVED "<<e.what()<<"\n";return 2;}
}
