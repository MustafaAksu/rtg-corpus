// Synthetic finite-horizon necessary-condition test, NOT the DYAD phi_40 or R_j.
#define main centered_feasibility_main
#include "centered_probe.cpp"
#undef main
int main(int argc,char**argv) {
    if(argc!=3||std::string(argv[1])!="--synthetic-shooting")return 64;
    try {
        const std::vector<C> phi{C(0),C(0),C(I::rat(1,2))};
        const C x(I::rat(1,64),I::rat(1,128));
        const Z r=cd(SCALE,Z(500)),M=cd(SCALE,Z(1000000000000LL));
        ce::Flow point=ce::from_lift(x,Disk(C(0),0),phi);
        ce::Flow whole=ce::from_lift(x,Disk(C(0),r),phi);
        for(int n=0;n<334;++n){point=ce::advance(point);whole=ce::advance(whole);}
        const State pc=ce::lifted_readout(point,phi),wc=ce::lifted_readout(whole,phi);
        const C slope=mid(pc.b.d);
        const Disk result=necessary_disk(Disk(C(0),r),pc.b.v,wc.b.d,slope,M);
        // A predeclared useful contraction: at least a factor two in radius.
        const bool useful=2*result.r<r;
        std::ofstream o(argv[2]);if(!o)throw std::runtime_error("cannot write output");
        o<<"{\"scope\":\"SESSION synthetic horizon-334 shooting; phi=x^2/2; M=ceil(1e-12); not a DYAD tube\","
         <<"\"precision\":"<<PREC<<",\"horizon\":334,\"input_radius_units\":\""<<r<<"\","
         <<"\"terminal_radius_units\":\""<<M<<"\",\"point_value\":";component(o,pc.b.v);
        o<<",\"point_tangent\":";component(o,pc.b.d);
        o<<",\"whole_value\":";component(o,wc.b.v);
        o<<",\"whole_tangent\":";component(o,wc.b.d);
        o<<",\"contracted_center\":";component(o,result.c);
        o<<",\"contracted_radius_units\":\""<<result.r<<"\",\"factor_two\":"<<(useful?"true":"false")<<"}\n";
        std::cout<<"SYNTHETIC horizon=334 initial_radius="<<sci(r)<<" contracted_radius="<<sci(result.r)
                 <<" derivative_width="<<sci(width(wc.b.d))<<" factor_two="<<(useful?"PASS":"FAIL")<<"\n";
        return useful?0:1;
    }catch(const std::exception& e){std::cerr<<"UNRESOLVED "<<e.what()<<"\n";return 2;}
}
