// SESSION unit/negative tests. No production mode or scientific certificate.
#include "centered_evaluator.hpp"
#include <set>
using namespace dyad;
namespace ce=dyad::centered;
int main() {
    unsigned count=0;
    auto check=[&](bool pass,const char* name){++count;if(!pass)throw std::runtime_error(name);std::cout<<name<<" PASS\n";};
    try {
        check(ce::ceil_sqrt(Z(2))==2&&ce::ceil_sqrt(Z(4))==2,"EUCLIDEAN_CEILING");
        C q(I::rat(3,4),I(1));check(ce::abs_upper(q)==5*SCALE/4&&ce::abs_lower(q)==5*SCALE/4,"MODULUS_345");
        auto e=ce::exp_residual(C(0));auto s=ce::sin_residual(C(0));
        check(encloses(e.value,C(0))&&encloses(e.derivative,C(0))&&encloses(s.value,C(0))&&encloses(s.derivative,C(0)),"RESIDUALS_ORIGIN");
        C v(I::rat(1,8),I::rat(-1,16));auto ex=ce::exp_residual(v);auto si=ce::sin_residual(v);auto sc=sincos_c(v);
        check(overlaps(ex.value+v+C(1),exp_c(v))&&overlaps(ex.derivative+C(1),exp_c(v)),"EXP_RESIDUAL_IDENTITIES");
        check(overlaps(si.value+v,sc.first)&&overlaps(si.derivative+C(1),sc.second),"SIN_RESIDUAL_IDENTITIES");
        auto orig=ce::block({C(0),C(0)});
        check(encloses(orig.value[0],C(0))&&encloses(orig.value[1],C(0)),"EIGEN_F_ORIGIN");
        check(encloses(orig.jacobian[0][0],C(1))&&encloses(orig.jacobian[1][1],C(1))&&encloses(orig.jacobian[0][1],C(0))&&encloses(orig.jacobian[1][0],C(0)),"EIGEN_DF_ORIGIN");
        ce::Vec input{C(I::rat(1,32),I::rat(-1,64)),C(I::rat(-1,256),I::rat(1,512))};
        auto b=ce::block(input);bool same=true;
        for(size_t j=0;j<2;++j) {
            State raw=raw_to_zw(F(zw_to_raw({J(input[0],C(j==0)),J(input[1],C(j==1))})));
            same &= overlaps(b.value[0],raw.a.v)&&overlaps(b.value[1],raw.b.v)&&
                    overlaps(b.jacobian[0][j],raw.a.d)&&overlaps(b.jacobian[1][j],raw.b.d);
        }
        check(same,"RAW_EIGEN_VALUE_JACOBIAN_CONSISTENCY");
        ce::Flow f{{ce::ball(input[0]),ce::ball(input[1])},{Disk(C(0),0),Disk(C(1),0)}};
        auto n=ce::advance(f);
        check(overlaps(n.state[0].box(),b.value[0])&&overlaps(n.state[1].box(),b.value[1])&&overlaps(n.tangent[0].box(),b.jacobian[0][1])&&overlaps(n.tangent[1].box(),b.jacobian[1][1]),"ONE_BLOCK_TANGENT_CONSISTENCY");
        bool refused=false;try{ce::block({C(100),C(0)});}catch(const std::domain_error&){refused=true;}
        check(refused,"LARGE_ARGUMENT_UNRESOLVED");
        std::vector<C> phi{C(0),C(0),C(I::rat(1,2))};
        auto lift=ce::from_lift(input[0],Disk(C(0),0),phi);
        auto rd=ce::lifted_readout(lift,phi);
        check(encloses(rd.a.d,C(0))&&encloses(rd.b.d,C(1))&&encloses(rd.b.v,C(0)),"LIFT_TANGENT_INITIAL");
        refused=false;try{auto p=ce::from_lift(C(0),Disk(C(0),0),phi);ce::lifted_readout(p,phi);}catch(const std::domain_error&){refused=true;}
        check(refused,"LIFT_POLE_UNRESOLVED");
        // F3: test every dyadic witness inside the initial disk, not just hull.
        Disk initial(C(0),SCALE);
        Contract unresolved=[](const C&)->std::optional<C>{throw std::domain_error("unproved domain");};
        Cover cover=outer_cover(initial,unresolved,SCALE/16,60);bool kept=true;
        for(long i=-16;i<=16;++i)for(long j=-16;j<=16;++j) if(i*i+j*j<=256) {
            C p(I::rat(i,16),I::rat(j,16));bool found=false;
            for(const C& tile:cover.leaves) found|=encloses(tile,p);
            kept &= found;
        }
        check(cover.visited>1&&cover.budget_hit&&kept,"UNRESOLVED_SPLIT_NO_WITNESS_LOSS");
        Cover unlimited=outer_cover(initial,unresolved,SCALE/2,1000);
        check(!unlimited.budget_hit&&unlimited.visited>1,"UNRESOLVED_SPLIT_TERMINATES_AT_WIDTH");
        Contract fatal=[](const C&)->std::optional<C>{throw std::runtime_error("infrastructure error");};
        bool fatal_loud=false;try{outer_cover(initial,fatal,SCALE/16,100);}catch(const std::runtime_error&){fatal_loud=true;}
        check(fatal_loud,"INFRASTRUCTURE_EXCEPTION_FAILS_LOUD");
        std::cout<<"RESULT PASS "<<count<<" tests; SESSION kernel only\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<"FAIL after "<<count<<": "<<e.what()<<"\n";return 1;}
}
