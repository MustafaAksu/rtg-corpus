// Reproduce F1 with the retained natural-interval evaluator. Expected refusal.
#define DYAD_CORE_NO_MAIN
#include "independent_core.cpp"
#include <iomanip>
int main() {
    using namespace dyad;
    State p{J(C(I::rat(3,100),I::rat(1,100)),C(1)),J(C(I::rat(-1,50),I::rat(1,200)))};
    int completed=0;
    try {
        for(int n=1;n<=40;++n){p=F(p);completed=n;
            if(n==1||n==10||n==20){Z w=std::max({Z(p.a.v.re.h-p.a.v.re.l),Z(p.a.v.im.h-p.a.v.im.l),Z(p.b.v.re.h-p.b.v.re.l),Z(p.b.v.im.h-p.b.v.im.l)});
                std::cout<<"legacy_step="<<n<<" max_component_width="<<std::scientific<<std::setprecision(8)
                         <<w.convert_to<long double>()/SCALE.convert_to<long double>()<<"\n";
            }
        }
        std::cerr<<"UNEXPECTED no refusal through 40\n";return 1;
    }catch(const std::domain_error& e){std::cout<<"EXPECTED_REFUSAL completed="<<completed<<" next="<<(completed+1)<<" reason="<<e.what()<<"\n";return completed<40?0:1;}
}
