#!/usr/bin/env python3
"""Numerical checks of the synthetic broad-fibre horizon-334 contractor.
Direct raw map only; not a DYAD tube, independent implementation of a proof,
or a certificate. Values/derivatives are sampled, not an exhaustive coverage.
"""
import argparse
import json
from pathlib import Path
import mpmath as m


def run(inp, out):
    m.mp.dps=320
    data=json.loads(inp.read_text());scale=m.mpf(2)**data['precision']
    radius=m.mpf(int(data['input_radius_units']))/scale
    root3=m.sqrt(3);omega=(-1+1j*root3)/2
    x=m.mpc(m.mpf(1)/64,m.mpf(1)/128)
    def solve(d):
        w=x*x*(m.mpf(1)/2+d);eta=(x-w)/(1j*root3);rho=(x+w+eta)/2
        de=-(x*x)/(1j*root3);dr=(x*x+de)/2
        for _ in range(6*data['horizon']):
            s,c,e=m.sin(eta),m.cos(eta),m.exp(rho)
            rho,eta=rho-s,eta+e-1-s
            dr,de=dr-c*de,e*dr+(1-c)*de
        z,w=rho+omega*eta,rho+m.conj(omega)*eta
        vz,vw=dr+omega*de,dr+m.conj(omega)*de
        return w/(z*z)-m.mpf(1)/2, vw/(z*z)-2*w*vz/(z*z*z)
    def inside(v,bounds):
        return all(m.mpf(int(b[0]))/scale<=v0<=m.mpf(int(b[1]))/scale
                   for v0,b in zip((v.real,v.imag),bounds))
    ds=[m.mpc(0),radius,-radius,1j*radius,-1j*radius]
    ds += [radius*m.mpc(a,b)/2 for a in (-1,1) for b in (-1,1)]
    rows=[]
    for j,d in enumerate(ds):
        f,df=solve(d)
        rows.append(dict(witness=j,value=inside(f,data['whole_value']),derivative=inside(df,data['whole_tangent'])))
    root=m.mpc(0);iterations=0
    for k in range(10):
        f,df=solve(root);iterations=k+1
        if abs(f)<m.mpf('1e-100'):break
        root -= f/df
    f,df=solve(root)
    rc=m.mpc(m.mpf(int(data['contracted_center'][0][0]))/scale,m.mpf(int(data['contracted_center'][1][0]))/scale)
    rr=m.mpf(int(data['contracted_radius_units']))/scale
    root_check=dict(iterations=iterations,residual=m.nstr(abs(f),20),root=[m.nstr(root.real,50),m.nstr(root.imag,50)],
                    in_initial=abs(root)<=radius,in_returned=abs(root-rc)<=rr,residual_small=abs(f)<m.mpf('1e-100'))
    result=dict(scope='SESSION synthetic NUM oracle; no DYAD phi_40 or R_j',mpmath_version=m.__version__,decimal_digits=320,
                sampled_complex_bounds=2*len(rows),rows=rows,root_check=root_check,
                all_pass=all(r['value'] and r['derivative'] for r in rows) and root_check['in_initial'] and root_check['in_returned'] and root_check['residual_small'])
    out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print('SHOOTING_ORACLE','PASS' if result['all_pass'] else 'FAIL',f"{2*len(rows)} sampled bounds; numerical root in returned disk")
    if not result['all_pass']:raise SystemExit(1)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();run(a.input,a.output)
