#!/usr/bin/env python3
"""Independent raw-map mpmath oracle for the centred C++ feasibility output.
Sampling evidence, not a proof of the interval bounds or a DYAD certificate.
No original Python campaign code or results are imported.
"""
import argparse
import json
from pathlib import Path
import mpmath as mp


def run(input_path: Path, output_path: Path) -> None:
    mp.mp.dps = 320
    lines = [json.loads(s) for s in input_path.read_text().splitlines() if s.strip()]
    indexed = {(r['case'], r['step']): r for r in lines}
    assert len(indexed) == 15
    root3 = mp.sqrt(3)
    omega = (-1 + 1j*root3)/2
    x = mp.mpc(mp.mpf(1)/64, mp.mpf(1)/128)
    radius = mp.mpf(2)**(-60)
    witnesses = [mp.mpc(0), radius, -radius, 1j*radius, -1j*radius]
    witnesses += [radius*mp.mpc(a, b)/2 for a in (-1, 1) for b in (-1, 1)]
    checks = []

    def inside(z, bound, bits):
        scale = mp.mpf(2)**bits
        return all(mp.mpf(int(b[0]))/scale <= c <= mp.mpf(int(b[1]))/scale
                   for c, b in zip((z.real,z.imag), bound))

    for case in ('owner_raw_point', 'synthetic_lift_point', 'synthetic_lift_disk'):
        for witness, initial_d in enumerate(witnesses if case.endswith('_disk') else [mp.mpc(0)]):
            if case == 'owner_raw_point':
                rho = mp.mpc(mp.mpf(3)/100, mp.mpf(1)/100)
                eta = mp.mpc(-mp.mpf(1)/50, mp.mpf(1)/200)
                dr, de = mp.mpc(1), mp.mpc(0)
            else:
                w = x*x*(mp.mpf(1)/2+initial_d)
                eta=(x-w)/(1j*root3);rho=(x+w+eta)/2
                de=-(x*x)/(1j*root3);dr=(x*x+de)/2
            for n in range(1,335):
                for _ in range(6):
                    sine, cosine, exponential = mp.sin(eta),mp.cos(eta),mp.exp(rho)
                    rho, eta = rho-sine, eta+exponential-1-sine
                    dr, de = dr-cosine*de,exponential*dr+(1-cosine)*de
                if n not in (1,10,20,100,334):
                    continue
                record=indexed[case,n]
                if case == 'owner_raw_point':
                    values, derivatives = (rho,eta),(dr,de)
                else:
                    z,w=rho+omega*eta,rho+mp.conj(omega)*eta
                    vz,vw=dr+omega*de,dr+mp.conj(omega)*de
                    values=(z,w/(z*z)-mp.mpf(1)/2)
                    derivatives=(vz,vw/(z*z)-2*w*vz/(z*z*z))
                for field, actual in (('values',values),('tangents',derivatives)):
                    for component, val in enumerate(actual):
                        checks.append({'case':case,'witness':witness,'step':n,'field':field,
                                       'component':component,'contained':inside(val,record[field][component],record['precision'])})
                if case == 'synthetic_lift_point' and n == 334:
                    neg_value=not inside(values[1]+mp.mpf('1e-6'),record['values'][1],record['precision'])
                    neg_derivative=not inside(mp.mpc(0),record['tangents'][1],record['precision'])
    result={'scope':'SESSION numerical oracle, not a certificate; synthetic lift, not phi_40',
            'mpmath_version':mp.__version__,'decimal_digits':mp.mp.dps,'complex_checks':len(checks),
            'contained':sum(c['contained'] for c in checks),'witnesses_on_disk':len(witnesses),
            'negative_controls':{'shifted_value_rejected':neg_value,'zero_derivative_rejected':neg_derivative},
            'all_pass':all(c['contained'] for c in checks) and neg_value and neg_derivative,'checks':checks}
    output_path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(f"ORACLE {result['contained']}/{len(checks)} complex enclosures; two negative controls; "
          f"{'PASS' if result['all_pass'] else 'FAIL'}")
    if not result['all_pass']:
        raise SystemExit(1)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('input',type=Path);ap.add_argument('output',type=Path)
    a=ap.parse_args();run(a.input,a.output)
