# Independent C++ centred evaluator — SESSION checkpoint

This is a forward evaluator and synthetic feasibility test, **not** an actual DYAD point-jump verifier.

Read `records/dyad/DYAD_OPEN20_CPP_CENTERED_FEASIBILITY.md` and the current independent-design record. PR #288's negative finding for the old raw-box evaluator is retained, not erased.

Requirements used: GCC 14.2.0, Boost headers 1.83, C++17; Python with mpmath 1.3.0 for the numerical oracle. The C++ program links neither Python nor Arb. All mathematical decisions use exact integer endpoints on a 2^-256 grid; printed decimals are approximate displays.

From the package/repository root:

```bash
bash evidence/dyad/cpp/open20-independent/run_centered_checks.sh /tmp/dyad-cpp-centered-check
```

The output directory must be empty. This script compiles and runs kernel/synthetic tests only. It has no production, replay, inverse-leg, tube, or harmonic-scan mode. Exact integer endpoints are stored in JSON/JSONL; numeric oracle checks do not certify their correctness.

`centered-checkpoint/` contains the implementer's captured evidence. `received/` contains the previous handoff unchanged. Check the package-root SHA256SUMS before placement; external receipt should be unchanged through an `upload/*` branch. Do not overwrite prior frozen evidence. The current sources at the fixed paths are a successor, not a rewrite of the received archive.
