#!/usr/bin/env python3
"""DYAD O20-an P1-c-2b check v0.1 -- hypotheses of Baldoma-Fontich-Martin (BFM, DCDS 37 (2017), arXiv:1702.05961)
Theorem 3.1 for the formal curves Gamma_+- of the complexified F. Exact arithmetic in E = Q(omega)[a]/(A a^2+B a+C)
(omega = i sqrt3; a = a2 = either root; statements hold for both curves at once). Writes p1c2b_check.json
(deterministic) and p1c2b_perf.json (timings only).

Chart: one blow-up w = x*w1, then y = w1 - J(x), J = J_6(phi/x) (phi = formal curve of P1-c-5). In (x, y), compute
the full Taylor expansion of x o F and y o F through total degree D = 6 and test BFM form (3) with d = 1, d' = 0:
   x o F = x - a x^N + f_N(x,y) + O(deg N+1),  f_N(x,0) = 0
   y o F = y + B1 x^(M-1) y + g_M(x,y) + O(deg M+1),  g_M(x,0) = 0, d_y g_M(x,0) = 0
Gates
  B1  x o F - x: no terms of degree 2, 3; degree-4 part = ell x^4 + mu x^3 y   (N = 4, a = -ell, f_4(x,0) = 0)
  B2  y o F - y: no terms of degree 1 (other than y), 2, 3; degree-4 part has zero x^4 coefficient and
      x^3 y coefficient B1 = ell (k* - 1)                                       (M = 4, g_4(x,0) = d_y g_4(x,0) = 0)
  B3  BFM condition for N = M: B1 + l a != 0 for every integer l >= 2, i.e. -B1/a = k* - 1 is not an integer >= 2
      (it is non-real); ell != 0. Gevrey exponent gamma = 1/(N-1) = 1/3
  B4  the strict transform of Gamma is the graph y = O(x^7): the y-free part of y o F vanishes through degree D
Negative controls (must evaluate False)
  M1  form (3) holds in the original (z, w) coordinates (it must not: degree-3 term mu z^2 w)
  M2  form (3) holds without the jet subtraction (J = 0): the x^4 coefficient of y o F is then nonzero
  M3  the resonance test misses a planted resonance (B1 = 3 ell, a = -ell gives B1 + 3a = 0)
"""
import sys, json, time
sys.path.insert(0, '.')
from fractions import Fraction as Fr
from qw import K
from fzw import F_zw
from ext import Ext, setup
t0 = time.time(); perf = {}
D = 6; NF = D + 2
Fz, Fw = F_zw(NF); perf['F'] = round(time.time() - t0, 2)
mu = K(Fr(-1, 2), Fr(-2, 3)); kstar = K(Fr(-64, 19), Fr(-16, 19))
c40 = Fz[(4, 0)]
setup(mu.conj() - mu * 2, Fw[(3, 1)] - c40 * 2, Fw[(5, 0)])
a = Ext(0, 1); ell = Ext(c40) + Ext(mu) * a
# ---- formal curve phi (P1-c-5 recursion)
N = NF + 2
FzE = {k: Ext(v) for k, v in Fz.items()}; FwE = {k: Ext(v) for k, v in Fw.items()}
def mulu(x, y):
    r = [Ext()] * (N + 1)
    for i, xi in enumerate(x):
        if xi.iszero(): continue
        for j in range(N + 1 - i):
            if not y[j].iszero(): r[i + j] = r[i + j] + xi * y[j]
    return r
def subs(P, phi):
    pw = [[Ext(1)] + [Ext()] * N]
    for _ in range(max(j for i, j in P)): pw.append(mulu(pw[-1], phi))
    r = [Ext()] * (N + 1)
    for (i, j), v in P.items():
        for d in range(N + 1 - i):
            if not pw[j][d].iszero(): r[i + d] = r[i + d] + v * pw[j][d]
    return r
def ucomp(phi, g):
    r = [Ext()] * (N + 1); p = [Ext(1)] + [Ext()] * N
    for k in range(1, N + 1):
        p = mulu(p, g)
        if not phi[k].iszero():
            for d in range(N + 1): r[d] = r[d] + phi[k] * p[d]
    return r
def Eres(phi):
    Aw = subs(FwE, phi); g = subs(FzE, phi); Bc = ucomp(phi, g)
    return [Aw[d] - Bc[d] for d in range(N + 1)]
phi = [Ext()] * (N + 1); phi[2] = a
for k in range(3, N - 2):
    e0 = Eres(phi); phi[k] = Ext(1); e1 = Eres(phi); phi[k] = Ext()
    phi[k] = -(e0[k + 3] / (e1[k + 3] - e0[k + 3]))
perf['curve'] = round(time.time() - t0, 2)
# ---- bivariate truncated polynomials {(i,j): Ext}, total degree <= T
def padd(p, q, s=1):
    r = dict(p)
    for k, v in q.items():
        x = r.get(k, Ext()) + (v if s == 1 else -v)
        if x.iszero(): r.pop(k, None)
        else: r[k] = x
    return r
def pmul(p, q, T):
    r = {}
    for (i1, j1), v1 in p.items():
        for (i2, j2), v2 in q.items():
            if i1 + i2 + j1 + j2 <= T:
                k = (i1 + i2, j1 + j2); r[k] = r.get(k, Ext()) + v1 * v2
    return {k: v for k, v in r.items() if not v.iszero()}
def pscal(p, c): return {k: v * c for k, v in p.items() if not (v * c).iszero()}
def peval(P, X, W, T):
    mi = max(i for i, j in P); mj = max(j for i, j in P)
    PX = [{(0, 0): Ext(1)}]; PW = [{(0, 0): Ext(1)}]
    for _ in range(mi): PX.append(pmul(PX[-1], X, T))
    for _ in range(mj): PW.append(pmul(PW[-1], W, T))
    r = {}
    for (i, j), v in P.items():
        if i + j <= T: r = padd(r, pscal(pmul(PX[i], PW[j], T), v))
    return r
def divx(p):
    assert all(i >= 1 for i, j in p)
    return {(i - 1, j): v for (i, j), v in p.items()}
def inv1(p, T):          # 1/p, p = 1 + (no constant)
    h = padd(p, {(0, 0): Ext(1)}, -1); r = {(0, 0): Ext(1)}; pw = {(0, 0): Ext(1)}
    for _ in range(T):
        pw = pscal(pmul(pw, h, T), Ext(-1)); r = padd(r, pw)
    return r
X = {(1, 0): Ext(1)}; Y = {(0, 1): Ext(1)}
def chart(Jc, T=D):
    J = {(j, 0): c for j, c in Jc.items() if not c.iszero()}
    W1 = padd(J, Y); Wv = pmul(X, W1, T + 1)
    X1 = peval(FzE, X, Wv, T + 1); Wn = peval(FwE, X, Wv, T + 1)
    W1n = pmul(divx(Wn), inv1(divx(X1), T), T)
    JX = {}; pw = {(0, 0): Ext(1)}
    for j in range(1, max(Jc) + 1):
        pw = pmul(pw, X1, T)
        if j in Jc: JX = padd(JX, pscal(pw, Jc[j]))
    yF = padd(W1n, JX, -1)
    X1 = {k: v for k, v in X1.items() if sum(k) <= T}
    return X1, yF
def part(p, d): return {k: v for k, v in p.items() if sum(k) == d}
def form3(xF, yF):
    dx = padd(xF, X, -1); dy = padd(yF, Y, -1)
    low = all(not part(dx, d) for d in (0, 1, 2, 3)) and all(not part(dy, d) for d in (0, 1, 2, 3))
    fx4 = part(dx, 4); fy4 = part(dy, 4)
    return low and (4, 0) in fx4 and (4, 0) not in fy4, fx4, fy4
Jc = {j: phi[j + 1] for j in range(1, D + 1)}
xF, yF = chart(Jc)
ok3, fx4, fy4 = form3(xF, yF)
g_ = {}; neg = {}
g_['B1'] = ok3 and fx4 == {(4, 0): ell, (3, 1): Ext(mu)}
B1 = fy4.get((3, 1), Ext())
g_['B2'] = ok3 and B1 == ell * Ext(kstar - K(1))
def resonant(B1, aa):          # is -B1/aa an integer >= 2 ?
    r = -(B1 / aa)
    return r.q.iszero() and r.p.b == 0 and r.p.a.denominator == 1 and r.p.a >= 2
aBFM = -ell
g_['B3'] = (not resonant(B1, aBFM)) and not ell.norm().iszero() and not (-(B1 / aBFM)).p.b == 0
yfree = {k: v for k, v in yF.items() if k[1] == 0}
g_['B4'] = not yfree
neg['M3'] = not resonant(ell * Ext(3), aBFM)
# M1: original coordinates
xo = {k: Ext(v) for k, v in Fz.items() if sum(k) <= D}; yo = {k: Ext(v) for k, v in Fw.items() if sum(k) <= D}
neg['M1'] = form3(xo, yo)[0]
# M2: no jet subtraction
xF0, yF0 = chart({1: Ext()})
neg['M2'] = form3(xF0, yF0)[0]
perf['total'] = round(time.time() - t0, 2)
rep = lambda p: {str(k): repr(v) for k, v in sorted(p.items())}
out = {'gates': g_, 'negative_controls_pass_should_be_false': neg,
       'data': {'N': 4, 'M': 4, 'gamma': '1/3', 'a_BFM = -ell': repr(aBFM), 'B1': repr(B1),
                '-B1/a = k*-1': repr(-(B1 / aBFM)), 'f4 (x o F degree 4)': rep(fx4),
                'degree-4 part of y o F (B1 x^3 y + g4)': rep(fy4),
                'M2: x^4 coeff of y o F without jet': repr(part(padd(yF0, Y, -1), 4).get((4, 0), Ext()))},
       'note': 'omega = i*sqrt(3); a = a2 (either root, P1-c-5); chart w = x*(J6(phi/x) + y)'}
txt = json.dumps(out, indent=1, sort_keys=True); print(txt)
open('p1c2b_check.json', 'w').write(txt + '\n'); open('p1c2b_perf.json', 'w').write(json.dumps(perf) + '\n')
ok = all(g_.values()) and not any(neg.values()); print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
