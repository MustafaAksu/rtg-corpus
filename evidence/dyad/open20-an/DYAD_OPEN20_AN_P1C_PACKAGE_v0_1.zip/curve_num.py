import sys, json, time; sys.path.insert(0,'.')
import mpmath as mp
from fzw import F_zw
mp.mp.dps=60
N=int(sys.argv[1]) if len(sys.argv)>1 else 20
t0=time.time()
Fz,Fw=F_zw(N)
Fz={k:v.cx() for k,v in Fz.items()}; Fw={k:v.cx() for k,v in Fw.items()}
def mulu(a,b):
    r=[mp.mpc(0)]*(N+1)
    for i,x in enumerate(a):
        if x==0: continue
        for j,y in enumerate(b[:N+1-i]): r[i+j]+=x*y
    return r
def subs(P,phi):  # P(z,phi(z)) univariate list
    mj=max(j for i,j in P); pw=[[mp.mpc(1)]+[mp.mpc(0)]*N]
    for _ in range(mj): pw.append(mulu(pw[-1],phi))
    r=[mp.mpc(0)]*(N+1)
    for (i,j),v in P.items():
        for d in range(N+1-i): r[i+d]+=v*pw[j][d]
    return r
def ucomp(phi,g):
    r=[mp.mpc(0)]*(N+1); p=[mp.mpc(1)]+[mp.mpc(0)]*N
    for k in range(1,N+1):
        p=mulu(p,g)
        if phi[k]!=0:
            for d in range(N+1): r[d]+=phi[k]*p[d]
    return r
def E(phi):
    A=subs(Fw,phi); g=subs(Fz,phi); B=ucomp(phi,g)
    return [A[d]-B[d] for d in range(N+1)], g
w=mp.mpc(0,1)*mp.sqrt(3)
A=mp.mpf(1)/2+2*w; B=mp.mpf(11)/24-mp.mpf(5)/24*w; C=-mp.mpf(61)/2160+mp.mpf(43)/6480*w
mu=-mp.mpf(1)/2-mp.mpf(2)/3*w; c40=-mp.mpf(1)/16+mp.mpf(7)/144*w
kstar=-mp.mpf(64)/19-16*mp.sqrt(3)/19*mp.mpc(0,1)
out={}
for s in (1,-1):
    a2=(-B+s*mp.sqrt(B*B-4*A*C))/(2*A)
    phi=[mp.mpc(0)]*(N+1); phi[2]=a2
    lead=c40+mu*a2; maxres=mp.mpf(0); Lerr=mp.mpf(0)
    for k in range(3,N-2):
        e0,_=E(phi); phi[k]=mp.mpc(1); e1,_=E(phi); phi[k]=mp.mpc(0)
        L=e1[k+3]-e0[k+3]; Lerr=max(Lerr,abs(L-lead*(kstar-k)))
        phi[k]=-e0[k+3]/L
    e,g=E(phi)
    maxres=max(abs(x) for x in e[:N-2+3])  # orders fixed so far
    out['root%+d'%s]={'a2':[str(mp.nstr(a2.real,20)),str(mp.nstr(a2.imag,20))],
        'lead_ell':[str(mp.nstr(lead.real,15)),str(mp.nstr(lead.imag,15))],
        'max_|L_k-ell(k*-k)|':mp.nstr(Lerr,5),'max_residual_orders<=N':mp.nstr(maxres,5),
        'abs_a_k':{k:mp.nstr(abs(phi[k]),8) for k in range(2,N-2)},
        'root_test |a_k|^(1/k)':{k:mp.nstr(abs(phi[k])**(mp.mpf(1)/k),6) for k in range(2,N-2) if phi[k]!=0},
        'restricted_map_g_coeffs_abs':{d:mp.nstr(abs(g[d]),8) for d in range(1,N-2)}}
out['N']=N
out['baseline_F_root_test max_{|i+j|=d}|Fz_ij|^(1/d)']={d:mp.nstr(max([abs(v) for (i,j),v in Fz.items() if i+j==d]+[mp.mpf(0)])**(mp.mpf(1)/d),6) for d in range(2,N+1)}
open(f'curve_num_N{N}.json','w').write(json.dumps(out,indent=1)+'\n')
print('sec',round(time.time()-t0,1))
