#!/usr/bin/env python3
"""DYAD O20-an P1-c check v0.1 -- isolated fixed point (P1-c-3) and formal invariant curves tangent to [1:0] (P1-c-5).

Exact arithmetic (Fractions; Q(omega), omega = i*sqrt3; sympy for the quadratic extension); one mpmath consistency gate.
Requires qw.py, fzw.py, isolated.py, curve_num.py-free (self-contained apart from qw/fzw/isolated). Runtime ~15 s.
Writes p1c_check.json (deterministic) and p1c_perf.json (timings only).
Gates:
  G1  complexified F = T^6 in (z,w) = (W, Wbar): cubic part (mu z^2 w, conj(mu) z w^2); [F_z]_(3,2), [F_z]_(0,5) equal the adopted
      raw values; F_w is the conjugate-swap of F_z through degree 8 (real structure)
  G2  Nakayama criterion: m^K is NOT contained in (F-id) + m^{K+1} for K <= 6, and IS for K = 7, 8, 9 (exact, (rho,eta) coordinates)
      => m^7 in (F-id): 0 is an isolated fixed point; dim O/(F-id) = 13 (stable for K = 7, 8, 9)
  G3  invariance equation for w = phi(z) = a2 z^2 + ...: orders z^2..z^4 vanish identically; the z^5 coefficient is
      A a2^2 + B a2 + C with A = conj(mu) - 2 mu, B = [F_w]_(3,1) - 2 [F_z]_(4,0), C = [F_w]_(5,0) = conj(c05) != 0
  G4  discriminant D = B^2 - 4AC is not a square in Q(omega) (its norm is not a rational square)
  G5  k* := (num - k lead)-root: num - k* lead == 0 mod (A a^2 + B a + C) with k* = -64/19 - (16 sqrt3/19) i, Im k* != 0;
      lead = c40 + mu a2 != 0 for both roots; lead(+) + lead(-) = 2 c40 - mu B/A = 0  =>  L_k = lead (k* - k) != 0 for every integer k >= 3
  G6  [NUM consistency, 60 digits, N = 16] the numerically computed L_k equal lead (k* - k) to 1e-50; curve residual < 1e-50
Negative controls (must fail):
  M1  G2 run on the cubic part of F - id only (common factor Q): criterion fails for all K <= 9
  M2  G5 with the sign of the (conj(mu) - mu) term flipped: no k* in Q(omega) makes the remainder vanish
  M3  G1 with conj(c05) in place of c05
"""
import sys, json, time
sys.path.insert(0, '.')
from fractions import Fraction as Fr
import sympy as sp, mpmath as mp
from qw import K, OM
from fzw import F_zw
from isolated import jets, nakayama
t0 = time.time(); perf = {}
g = {}; neg = {}
# ---------- G1 ----------
Fz, Fw = F_zw(8)
mu = K(Fr(-1, 2), Fr(-2, 3))
c32 = K(Fr(-77, 216), Fr(97, 648)); c05 = K(Fr(-61, 2160), Fr(-43, 6480))
cub_ok = Fz.get((2, 1)) == mu and Fw.get((1, 2)) == mu.conj() and all(sum(k) != 3 or k == (2, 1) for k in Fz)
conjswap = all(Fw.get((j, i), K()) == v.conj() for (i, j), v in Fz.items()) and len(Fz) == len(Fw)
g['G1'] = cub_ok and Fz.get((3, 2)) == c32 and Fz.get((0, 5)) == c05 and conjswap
neg['M3'] = Fz.get((0, 5)) == c05.conj()
perf['G1'] = round(time.time() - t0, 2)
# ---------- G2 ----------
gg, mul = jets(9)
res = {}
for Kd in range(3, 10):
    gK = tuple({k: v for k, v in gi.items() if sum(k) <= Kd} for gi in gg)
    ok, rank = nakayama(gK, Kd, mul)
    res[Kd] = (ok, (Kd + 1) * (Kd + 2) // 2 - rank)   # dim O/(I + m^{K+1})
g['G2'] = all(not res[k][0] for k in range(3, 7)) and all(res[k][0] for k in (7, 8, 9)) and all(res[k][1] == 13 for k in (7, 8, 9))
cubic_only = tuple({k: v for k, v in gi.items() if sum(k) == 3} for gi in gg)
neg['M1'] = any(nakayama(cubic_only, Kd, mul)[0] for Kd in range(3, 10))
perf['G2'] = round(time.time() - t0, 2)
# ---------- G3 ----------
def subs_curve(P, phi, N):
    r = {}; pw = [{0: K(1)}]
    for _ in range(max(j for i, j in P)):
        nxt = {}
        for i, v in pw[-1].items():
            for j, u in phi.items():
                if i + j <= N: nxt[i + j] = nxt.get(i + j, K()) + v * u
        pw.append(nxt)
    for (i, j), v in P.items():
        for d, u in pw[j].items():
            if i + d <= N: r[i + d] = r.get(i + d, K()) + v * u
    return r
def ucomp(phi, gm, N):
    r = {}; pows = [{0: K(1)}]
    for _ in range(max(phi)):
        nxt = {}
        for i, v in pows[-1].items():
            for j, u in gm.items():
                if i + j <= N: nxt[i + j] = nxt.get(i + j, K()) + v * u
        pows.append(nxt)
    for k, a in phi.items():
        for d, u in pows[k].items():
            if d <= N: r[d] = r.get(d, K()) + a * u
    return r
def E(phi, N):
    A_ = subs_curve(Fw, phi, N); gm = subs_curve(Fz, phi, N); B_ = ucomp(phi, gm, N)
    return {d: A_.get(d, K()) - B_.get(d, K()) for d in range(N + 1)}
vals = {t: E({2: K(t)}, 5) for t in (0, 1, -1, 2)}
low_ok = all(vals[t][d].iszero() for t in vals for d in range(0, 5))
C = vals[0][5]; Aq = (vals[1][5] + vals[-1][5]) * Fr(1, 2) - C; Bq = (vals[1][5] - vals[-1][5]) * Fr(1, 2)
quad_ok = vals[2][5] == Aq * 4 + Bq * 2 + C   # exactly quadratic
c40 = Fz[(4, 0)]; Fw31 = Fw[(3, 1)]
g['G3'] = low_ok and quad_ok and Aq == mu.conj() - mu * 2 and Bq == Fw31 - c40 * 2 and C == Fw[(5, 0)] == c05.conj() and not C.iszero()
# ---------- G4 / G5 (sympy) ----------
w = sp.I * sp.sqrt(3)
tos = lambda x: sp.Rational(x.a.numerator, x.a.denominator) + w * sp.Rational(x.b.numerator, x.b.denominator)
A_s, B_s, C_s, mu_s, c40_s, F31_s = map(tos, (Aq, Bq, C, mu, c40, Fw31))
D = Bq * Bq - Aq * C * 4
nD = D.norm()
g['G4'] = not (sp.sqrt(sp.Integer(nD.numerator)).is_integer and sp.sqrt(sp.Integer(nD.denominator)).is_integer)
a, kk = sp.symbols('a kk')
quad = sp.expand(A_s * a**2 + B_s * a + C_s)
def kstar_solution(sign):
    num = F31_s + sign * 2 * (sp.conjugate(mu_s) - mu_s) * a; lead = c40_s + mu_s * a
    r = sp.Poly(sp.expand(sp.rem(sp.expand(num - kk * lead), quad, a)), a)
    return sp.solve([sp.expand(c) for c in r.all_coeffs()], kk, dict=True)
sol = kstar_solution(1)
kexp = -sp.Rational(64, 19) - 16 * sp.sqrt(3) * sp.I / 19
lead_nonzero = sp.simplify(quad.subs(a, -c40_s / mu_s)) != 0
g['G5'] = sp.simplify(2 * c40_s + mu_s * (-B_s / A_s)) == 0 and len(sol) == 1 and sp.simplify(sol[0][kk] - kexp) == 0 and sp.im(sp.expand(sol[0][kk])) != 0 and lead_nonzero
neg['M2'] = len(kstar_solution(-1)) > 0
perf['G3-G5'] = round(time.time() - t0, 2)
# ---------- G6 (numeric consistency) ----------
mp.mp.dps = 60; N = 16
FzN, FwN = F_zw(N)
FzN = {k: v.cx() for k, v in FzN.items()}; FwN = {k: v.cx() for k, v in FwN.items()}
def mulu(x, y):
    r = [mp.mpc(0)] * (N + 1)
    for i, xi in enumerate(x):
        if xi == 0: continue
        for j in range(N + 1 - i): r[i + j] += xi * y[j]
    return r
def subsN(P, phi):
    pw = [[mp.mpc(1)] + [mp.mpc(0)] * N]
    for _ in range(max(j for i, j in P)): pw.append(mulu(pw[-1], phi))
    r = [mp.mpc(0)] * (N + 1)
    for (i, j), v in P.items():
        for d in range(N + 1 - i): r[i + d] += v * pw[j][d]
    return r
def EN(phi):
    A_ = subsN(FwN, phi); gm = subsN(FzN, phi)
    r = [mp.mpc(0)] * (N + 1); p = [mp.mpc(1)] + [mp.mpc(0)] * N
    for k in range(1, N + 1):
        p = mulu(p, gm)
        if phi[k] != 0:
            for d in range(N + 1): r[d] += phi[k] * p[d]
    return [A_[d] - r[d] for d in range(N + 1)]
cx = lambda x: x.cx()
Ac, Bc, Cc, muc, c40c = map(cx, (Aq, Bq, C, mu, c40)); ks = complex(kexp)
ks = mp.mpc(-mp.mpf(64) / 19, -16 * mp.sqrt(3) / 19)
okN = True; summary = {}
for s in (1, -1):
    a2 = (-Bc + s * mp.sqrt(Bc * Bc - 4 * Ac * Cc)) / (2 * Ac); lead = c40c + muc * a2
    phi = [mp.mpc(0)] * (N + 1); phi[2] = a2; Lerr = mp.mpf(0)
    for k in range(3, N - 2):
        e0 = EN(phi); phi[k] = mp.mpc(1); e1 = EN(phi); phi[k] = mp.mpc(0)
        L = e1[k + 3] - e0[k + 3]; Lerr = max(Lerr, abs(L - lead * (ks - k))); phi[k] = -e0[k + 3] / L
    e = EN(phi); resid = max(abs(x) for x in e)
    okN = okN and Lerr < mp.mpf(10) ** -50 and resid < mp.mpf(10) ** -50
    summary['root%+d' % s] = {'a2': mp.nstr(a2, 15), 'ell=c40+mu*a2': mp.nstr(lead, 15)}
g['G6'] = okN
perf['total'] = round(time.time() - t0, 2)
out = {'gates': g, 'negative_controls_pass_should_be_false': neg,
       'isolated_fixed_point': {str(k): {'nakayama_holds': v[0], 'dim_O_mod_I_plus_m^(K+1)': v[1]} for k, v in res.items()},
       'quadratic': {'A': repr(Aq), 'B': repr(Bq), 'C': repr(C), 'D': repr(D), 'norm_D': str(nD)},
       'k_star': '-64/19 - (16*sqrt(3)/19) i', 'roots': summary, 'note': 'omega = i*sqrt(3) in the (a+b w) notation'}
txt = json.dumps(out, indent=1, sort_keys=True); print(txt)
open('p1c_check.json', 'w').write(txt + '\n'); open('p1c_perf.json', 'w').write(json.dumps(perf) + '\n')
ok = all(g.values()) and not any(neg.values()); print('RESULT:', 'PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
