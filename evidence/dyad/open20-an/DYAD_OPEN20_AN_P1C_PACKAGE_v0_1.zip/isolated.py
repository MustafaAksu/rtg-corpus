import sys
from fractions import Fraction as Fr
from math import factorial
def jets(N):
    def add(a,b,c=1):
        r=dict(a)
        for k,v in b.items():
            r[k]=r.get(k,0)+c*v
            if r[k]==0: del r[k]
        return r
    def mul(a,b):
        r={}
        for (i1,j1),v1 in a.items():
            for (i2,j2),v2 in b.items():
                if i1+i2+j1+j2<=N: k=(i1+i2,j1+j2); r[k]=r.get(k,0)+v1*v2
        return {k:v for k,v in r.items() if v!=0}
    def compose(p,m):
        mi=max([i for i,j in p]+[0]); mj=max([j for i,j in p]+[0])
        P0=[{(0,0):Fr(1)}]; P1=[{(0,0):Fr(1)}]
        for _ in range(mi): P0.append(mul(P0[-1],m[0]))
        for _ in range(mj): P1.append(mul(P1[-1],m[1]))
        r={}
        for (i,j),v in p.items(): r=add(r,{k:v*x for k,x in mul(P0[i],P1[j]).items()})
        return r
    sin_e={(0,k):Fr((-1)**((k-1)//2),factorial(k)) for k in range(1,N+1,2)}
    em1={(k,0):Fr(1,factorial(k)) for k in range(1,N+1)}
    T=(add({(1,0):Fr(1)},sin_e,-1), add(add({(0,1):Fr(1)},em1),sin_e,-1))
    m=({(1,0):Fr(1)},{(0,1):Fr(1)})
    for _ in range(6): m=(compose(T[0],m),compose(T[1],m))
    g=(add(m[0],{(1,0):Fr(1)},-1), add(m[1],{(0,1):Fr(1)},-1))
    return g, mul
def nakayama(g, K, mul):
    """True iff every monomial of degree K lies in span{x^a y^b g_i : a+b<=K-3} modulo degree > K."""
    mons=[(i,d-i) for d in range(0,K+1) for i in range(d+1)]
    idx={m:n for n,m in enumerate(mons)}
    rows=[]
    for gi in g:
        for d in range(0,K-2):
            for a in range(d+1):
                mono={(a,d-a):Fr(1)}
                pr={k:v for k,v in mul(mono,gi).items() if sum(k)<=K}
                if pr: rows.append({idx[k]:v for k,v in pr.items()})
    # Gaussian elimination (reduced, column pivot dict)
    piv={}
    def reduce(r):
        r=dict(r)
        while r:
            c=max(r)  # eliminate highest index first (consistent ordering)
            if c in piv:
                pr=piv[c]; f=r[c]
                for k,v in pr.items():
                    x=r.get(k,0)-f*v
                    if x==0: r.pop(k,None)
                    else: r[k]=x
            else: return r,c
        return None,None
    for r in rows:
        rr,c=reduce(r)
        if rr is not None:
            f=rr[c]; piv[c]={k:v/f for k,v in rr.items()}
    ok=True
    for i in range(K+1):
        rr,_=reduce({idx[(i,K-i)]:Fr(1)})
        if rr is not None: ok=False
    return ok, len(piv)
if __name__=='__main__':
    Kmax=int(sys.argv[1]) if len(sys.argv)>1 else 9
    g,mul=jets(Kmax)
    for K in range(3,Kmax+1):
        gK=tuple({k:v for k,v in gi.items() if sum(k)<=K} for gi in g)
        print(K, nakayama(gK,K,mul))
