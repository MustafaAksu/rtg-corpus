RECOG CELL-E2C stage 1 production bundle (RECOG-THM-TWIN-RADIAL-ACCESS)
Do NOT open/re-save the .py or .jsonl files in an editor or let git convert line endings: the hash gates will refuse.
PowerShell:
  py -3.12 -m pip install "python-flint==0.9.0"
  py -3.12 verify_hashes.py                      # all 9 lines must read OK
  py -3.12 run_chunks.py 4                        # remaining 24 chunks, 4 parallel jobs; safe to re-run
  py -3.12 surveil.py                             # optional monitoring
  py -3.12 e2c_production_gate.py --partial @((Get-ChildItem e2c_prod_*.jsonl).Name)
Final (29 chunk files present):
  py -3.12 e2c_production_gate.py @((Get-ChildItem e2c_prod_*.jsonl).Name)
  Get-FileHash -Algorithm SHA256 e2c_prod_*.jsonl, e2c_production_certificate.json | ForEach-Object { "$($_.Hash.ToLower())  $(Split-Path $_.Path -Leaf)" } | Set-Content final_hashes.sha256
Send back: gate output, e2c_production_certificate.json, final_hashes.sha256, surveil.py line, python version; anything in failures\ first.
