import hashlib, sys
H = {
 "recog_cell_r8_hetero_enclosure.py":   "1f8876a8a3fc31428d5ffb4873e62eb0780c08763b80281e1edeb8c1ab1223fd",
 "recog_cell_e2c_twin_radial_access.py":"e0522aec291a6d3573ccb15e28045ad42b32e4e7225b5a616eeae34a0e1a1b22",
 "e2c_production_driver.py":            "0c42131cf3ab209f7ea1f2b7fafddf96267cb5e0317fa334fde42d018074cb4b",
 "e2c_production_gate.py":              "d8364d439f876ac2df9fcad82a3ade609f9dbf55fefbd6eb34f315f72fc2fc40",
 "e2c_prod_0_6144.jsonl":               "223776b4ecc48ad69084ce23ced0297b20949ed5c333dbcfe8aa5f7c44968b9a",
 "e2c_prod_6144_12288.jsonl":           "5000776e8a7351ab1be5507583b33715aad71b3962ab52caf2767b6c5f001c36",
 "e2c_prod_12288_20480.jsonl":          "ca9da9bb191aac86ac4d61d03f133f0cfaa1c6b9e7a1ec53299064704e6070c6",
 "e2c_prod_20480_28672.jsonl":          "8ab6ce5e6bb048f3a20fc1a9daf8e1b51cb387d26f12b1e3d778e29273f80bd3",
 "e2c_prod_28672_32768.jsonl":          "3d362f457db1f56c2a88854eb8bb64bc852bd05639f4f36c853f1bec6a2dbbea"}
bad = 0
for f, h in H.items():
    try: got = hashlib.sha256(open(f, "rb").read()).hexdigest()
    except FileNotFoundError: got = "MISSING"
    ok = got == h; bad += not ok
    print(("OK   " if ok else "FAIL ") + f + ("" if ok else f"  (got {got[:16]}...)"))
sys.exit(1 if bad else 0)
