import subprocess, sys, os, glob, shutil, time
from concurrent.futures import ThreadPoolExecutor
JOBS = int(sys.argv[1]) if len(sys.argv) > 1 else 4
PY = sys.executable
for d in ("discarded", "failures", "logs"): os.makedirs(d, exist_ok=True)
def rng(f):
    k0, k1 = f[len("e2c_prod_"):-len(".jsonl")].split("_"); return int(k0), int(k1)
def nrec(f):
    with open(f, encoding="utf-8") as h: return sum(1 for _ in h) - 1
def park(f, d): shutil.move(f, os.path.join(d, f"{int(time.time())}_{f}"))
for f in glob.glob("e2c_prod_*.jsonl"):                    # pre-clean interrupted runs
    k0, k1 = rng(f)
    if nrec(f) != k1 - k0: park(f, "discarded"); print("pre-clean: moved incomplete", f)
def run_one(k0):
    k1 = k0 + 4096; f = f"e2c_prod_{k0}_{k1}.jsonl"
    if os.path.exists(f): return f"skip {f} (complete)"
    t = time.time()
    with open(os.path.join("logs", f"{k0}.log"), "w") as log:
        rc = subprocess.call([PY, "e2c_production_driver.py", str(k0), str(k1)], stdout=log, stderr=subprocess.STDOUT)
    n = nrec(f) if os.path.exists(f) else -1
    if n != 4096:
        if os.path.exists(f): park(f, "discarded")
        return f"INCOMPLETE [{k0},{k1}) -> rerun later (see logs\\{k0}.log)"
    if rc != 0:
        park(f, "failures"); return f"TILE FAILURE in [{k0},{k1}) -> failures\\ (investigate; do not rerun blindly)"
    return f"done {f}  ({time.time()-t:.0f}s)"
with ThreadPoolExecutor(JOBS) as ex:
    for msg in ex.map(run_one, range(32768, 131072, 4096)): print(msg, flush=True)
