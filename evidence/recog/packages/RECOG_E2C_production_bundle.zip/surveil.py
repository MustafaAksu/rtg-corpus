import json, glob
rs = []
for f in sorted(glob.glob("e2c_prod_*.jsonl")):
    rs += [json.loads(l) for l in open(f, encoding="utf-8")][1:]
pos = [r['margin'] for r in rs if r['margin'] is not None]
print(f"tiles {len(rs)} | max L {max(r['leaves'] for r in rs)} | max n_hit {max(r['n_hit'] for r in rs)} | "
      f"max wE {max(r['max_wE'] for r in rs):.4f} | min positive margin {min(pos):.3e} | "
      f"N_margin>0 {len(pos)} | N_empty_clip {sum(r['margin'] is None for r in rs)} | not ok {sum(not r['ok'] for r in rs)}")
