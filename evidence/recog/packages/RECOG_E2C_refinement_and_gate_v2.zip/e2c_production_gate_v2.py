#!/usr/bin/env python3
r"""
e2c_production_gate_v2.py — fail-closed completeness gate for RECOG CELL-E2C stage 1 WITH exact local refinement.
Usage: python e2c_production_gate_v2.py --chunks <chunk files...> --refine <refinement files...>
PASS (exit 0) only if:
 * every chunk file binds the same driver/core/R8 hashes and production parameters, and those files on disk hash to the bound values;
 * chunk ranges partition [0, 131072) exactly and every index occurs exactly once;
 * every chunk record with ok=true has n_hit <= 256, finite fields, margin > 0 or null (null = certified-empty clip);
 * every chunk record with ok=false (budget exhaustion) is a parent covered by exactly its M^2 children in a refinement file whose metadata
   binds the same core/R8 hashes and NMAX / WSPLIT / budget / q1 / q2 / clip, with child grid = parent grid * M, and whose refine-driver
   file hashes to the bound value; every child satisfies the same record conditions. Children partition the parent exactly (exact angle and
   Q edges), so the parent is certified.
Emits e2c_production_certificate_v2.json on PASS.
"""
import sys, json, math, hashlib, os
args = sys.argv[1:]; ci, ri = args.index("--chunks"), args.index("--refine")
chunks = args[ci+1:ri] if ci < ri else args[ci+1:]; refines = args[ri+1:] if ri > ci else args[ri+1:ci]
here = os.path.dirname(os.path.abspath(__file__)); NTOT = 4096*32; errs = []
def H(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def fin(v): return isinstance(v, (int, float)) and math.isfinite(v)
def rec_ok(r): return (r['ok'] and fin(r['n_hit']) and r['n_hit'] <= 256 and all(fin(r[k]) for k in ('leaves','peak','splits','clips','steps','max_wE'))
                       and (r['margin'] is None or (fin(r['margin']) and r['margin'] > 0)))
metas, recs = [], []
for f in chunks:
    L = [json.loads(l) for l in open(f, encoding="utf-8")]; m = [x for x in L if x.get('meta')]
    if len(m) != 1: errs.append(f"{f}: metadata"); continue
    rs = [x for x in L if not x.get('meta')]; lo, hi = m[0]['range']
    if sorted(r['i'] for r in rs) != list(range(lo, hi)): errs.append(f"{f}: records do not match declared range")
    metas.append(m[0]); recs += rs
keys = ('driver_sha256', 'core_sha256', 'r8_sha256', 'prec_bits', 'NTH', 'NR', 'NMAX', 'WSPLIT', 'LEAF_BUDGET', 'q1', 'q2', 'clip', 'flatten')
if len({tuple(m[k] for k in keys) for m in metas}) != 1: errs.append("chunks do not share one binding")
m0 = metas[0]
for name, key in (("e2c_production_driver.py", 'driver_sha256'), ("recog_cell_e2c_twin_radial_access.py", 'core_sha256'), ("recog_cell_r8_hetero_enclosure.py", 'r8_sha256')):
    p = os.path.join(here, name)
    if not os.path.exists(p) or H(p) != m0[key]: errs.append(f"{name} does not hash to the bound value")
ranges = sorted(tuple(m['range']) for m in metas)
if not ranges or ranges[0][0] != 0 or ranges[-1][1] != NTOT or any(ranges[j][1] != ranges[j+1][0] for j in range(len(ranges)-1)):
    errs.append("chunk ranges do not partition [0, 131072)")
ids = [r['i'] for r in recs]
if len(ids) != len(set(ids)) or sorted(ids) != list(range(NTOT)): errs.append("indices are not exactly 0..131071 once each")
children = {}; rmetas = []
for f in refines:
    L = [json.loads(l) for l in open(f, encoding="utf-8")]; rm = [x for x in L if x.get('meta')]
    if len(rm) != 1: errs.append(f"{f}: refinement metadata"); continue
    rm = rm[0]; rmetas.append(rm); Mf = rm['M']
    if (rm['core_sha256'], rm['r8_sha256'], rm['prec_bits'], rm['NMAX'], rm['WSPLIT'], rm['LEAF_BUDGET'], rm['q1'], rm['q2'], rm['clip']) != \
       (m0['core_sha256'], m0['r8_sha256'], m0['prec_bits'], m0['NMAX'], m0['WSPLIT'], m0['LEAF_BUDGET'], m0['q1'], m0['q2'], m0['clip']):
        errs.append(f"{f}: refinement binding differs from production binding")
    if rm['parent_grid'] != [m0['NTH'], m0['NR']] or rm['child_grid'] != [m0['NTH']*Mf, m0['NR']*Mf]: errs.append(f"{f}: grid mismatch")
    p = os.path.join(here, "e2c_refine_driver.py")
    if not os.path.exists(p) or H(p) != rm['refine_driver_sha256']: errs.append("e2c_refine_driver.py does not hash to the bound value")
    for x in L:
        if x.get('meta'): continue
        kt, kr = divmod(x['parent_i'], m0['NR'])
        if (x['kt'], x['kr'], x['NTH'], x['NR']) != (kt*Mf + x['a'], kr*Mf + x['b'], m0['NTH']*Mf, m0['NR']*Mf): errs.append(f"child index mismatch parent {x['parent_i']}"); break
        children.setdefault((x['parent_i'], Mf), []).append(x)
n_direct = n_refined = n_children = 0
for r in recs:
    if r['ok']:
        if not rec_ok(r): errs.append(f"i={r['i']}: record conditions"); break
        n_direct += 1; continue
    cands = [(k, v) for k, v in children.items() if k[0] == r['i']]
    good = False
    for (pi, Mf), ch in cands:
        if sorted((c['a'], c['b']) for c in ch) == [(a, b) for a in range(Mf) for b in range(Mf)] and all(rec_ok(c) for c in ch):
            good = True; n_children += len(ch); break
    if not good: errs.append(f"i={r['i']}: failed tile not covered by a certified exact refinement ({r.get('fail')})"); break
    n_refined += 1
print(f"tiles {len(set(ids))}/{NTOT}; certified directly {n_direct}; certified by refinement {n_refined} (children {n_children}); errors {len(errs)}")
for e in errs[:10]: print("  ERROR:", e)
if errs: print("E2C PRODUCTION GATE v2 FAIL"); sys.exit(1)
allrecs = [r for r in recs if r['ok']] + [c for v in children.values() for c in v]
cert = dict(rid="RECOG-THM-TWIN-RADIAL-ACCESS", status="PASS", gate="v2 (exact local refinement)", parent_tiles=NTOT,
            certified_directly=n_direct, certified_by_refinement=n_refined, refinement_children=n_children,
            refinement_M=sorted({rm['M'] for rm in rmetas}), binding={k: m0[k] for k in keys},
            chunk_files={os.path.basename(f): H(f) for f in chunks}, refinement_files={os.path.basename(f): H(f) for f in refines},
            refine_driver_sha256=H(os.path.join(here, "e2c_refine_driver.py")),
            max_leaves=max(r['leaves'] for r in allrecs), max_n_hit=max(r['n_hit'] for r in allrecs), max_wE=max(r['max_wE'] for r in allrecs),
            min_positive_margin=min(r['margin'] for r in allrecs if r['margin'] is not None),
            N_margin_positive=sum(r['margin'] is not None for r in allrecs), N_empty_clip=sum(r['margin'] is None for r in allrecs),
            gate_sha256=H(__file__))
json.dump(cert, open(os.path.join(here, "e2c_production_certificate_v2.json"), "w"), indent=1)
print("E2C PRODUCTION GATE v2 PASS"); sys.exit(0)
