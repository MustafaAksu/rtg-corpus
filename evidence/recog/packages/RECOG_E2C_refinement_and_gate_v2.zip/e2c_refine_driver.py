#!/usr/bin/env python3
r"""
e2c_refine_driver.py — local grid refinement for RECOG CELL-E2C stage 1 (RECOG-THM-TWIN-RADIAL-ACCESS).
A parent tile (kt, kr) of the 4096 x 32 production grid is covered EXACTLY by its m^2 children (kt*m + a, kr*m + b), 0 <= a, b < m,
on the (4096 m) x (32 m) grid: angle edges k pi / NTH and Q-edges q1 + (q2 - q1) k / NR are exact, so the children partition the parent.
Each child is certified by the UNCHANGED calibrated core (hash-gated: e0522aec...), same NMAX = 256, WSPLIT = 0.05, budget 4096, clipping.
Only the local grid resolution differs. Usage: python e2c_refine_driver.py M failures_file1.jsonl [failures_file2.jsonl ...]
Writes e2c_refine_m<M>.jsonl: metadata line, then one record per child (with parent_i, a, b).
"""
import sys, os, json, hashlib, importlib.util, time
CORE_SHA256 = "e0522aec291a6d3573ccb15e28045ad42b32e4e7225b5a616eeae34a0e1a1b22"
here = os.path.dirname(os.path.abspath(__file__)); core_path = os.path.join(here, "recog_cell_e2c_twin_radial_access.py")
if hashlib.sha256(open(core_path, 'rb').read()).hexdigest() != CORE_SHA256: print("[FAIL] calibrated core hash mismatch"); sys.exit(1)
spec = importlib.util.spec_from_file_location("e2c_core", core_path); core = importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
M = int(sys.argv[1]); srcs = sys.argv[2:]; NTH, NR = 4096, 32
assert (core.NMAX, core.WSPLIT, core.LEAF_BUDGET) == (256, 0.05, 4096) and M >= 2
parents = []
for f in srcs:
    for l in open(f, encoding="utf-8"):
        r = json.loads(l)
        if not r.get('meta') and not r['ok']: parents.append(r['i'])
parents = sorted(set(parents))
import flint
meta = dict(meta=True, rid="RECOG-THM-TWIN-RADIAL-ACCESS", role="refinement", refine_driver_sha256=hashlib.sha256(open(__file__, 'rb').read()).hexdigest(),
            core_sha256=CORE_SHA256, r8_sha256=core.R8_SHA256, flint=flint.__version__, prec_bits=120, parent_grid=[NTH, NR], M=M,
            child_grid=[NTH*M, NR*M], NMAX=core.NMAX, WSPLIT=core.WSPLIT, LEAF_BUDGET=core.LEAF_BUDGET, q1=str(core.q1), q2=str(core.q2), clip=True,
            parents=parents, sources={os.path.basename(f): hashlib.sha256(open(f, 'rb').read()).hexdigest() for f in srcs})
out = os.path.join(here, f"e2c_refine_m{M}.jsonl"); t0 = time.time(); bad = 0
with open(out, "w") as fo:
    fo.write(json.dumps(meta) + "\n")
    for pi in parents:
        kt, kr = divmod(pi, NR)
        for a in range(M):
            for b in range(M):
                r = core.run_tile(kt*M + a, kr*M + b, NTH*M, NR*M); r.update(parent_i=pi, a=a, b=b)
                fo.write(json.dumps(r) + "\n"); fo.flush()
                if not r['ok']: bad += 1; print("CHILD FAIL", pi, a, b, r.get('fail'), flush=True)
print(f"refinement M={M}: {len(parents)} parents, {len(parents)*M*M} children, {bad} child failures, {time.time()-t0:.1f}s -> {os.path.basename(out)}")
sys.exit(0 if bad == 0 else 1)
